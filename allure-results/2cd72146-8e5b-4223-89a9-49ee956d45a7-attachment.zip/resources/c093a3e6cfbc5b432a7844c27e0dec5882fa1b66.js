import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/monedas/pages/MonedasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/monedas/pages/MonedasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
export const MonedasDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error } = useCrudItem(monedasModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Moneda no encontrada." }, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: monedasModuleConfig, item }, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(MonedasDetailPage, "6YQMcrxNTGjd60HB6xOhIbiA4BI=", false, function() {
  return [useParams, useCrudItem];
});
_c = MonedasDetailPage;
var _c;
$RefreshReg$(_c, "MonedasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/monedas/pages/MonedasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/monedas/pages/MonedasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDJCQUF3QztBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBRXhCLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsR0FBRyxJQUFJUCxVQUEwQjtBQUN6QyxRQUFNLEVBQUVRLE1BQU1DLFNBQVNDLE1BQU0sSUFBSVAsWUFBb0JELHFCQUFxQkssRUFBRTtBQUU1RSxNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHFDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEI7QUFFNUMsU0FBTyx1QkFBQyxxQkFBa0IsUUFBUU4scUJBQXFCLFFBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkQ7QUFDdEU7QUFBRUksR0FUV0QsbUJBQWlCO0FBQUEsVUFDWEwsV0FDa0JHLFdBQVc7QUFBQTtBQUFBUSxLQUZuQ047QUFBaUIsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwibW9uZWRhc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiTG9hZGluZ1NwaW5uZXIiLCJNb25lZGFzRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJpdGVtIiwibG9hZGluZyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9uZWRhc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBtb25lZGFzTW9kdWxlQ29uZmlnLCB0eXBlIE1vbmVkYSB9IGZyb20gJy4uL21vbmVkYXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcblxuZXhwb3J0IGNvbnN0IE1vbmVkYXNEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxNb25lZGE+KG1vbmVkYXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWl0ZW0pIHJldHVybiA8ZGl2Pk1vbmVkYSBubyBlbmNvbnRyYWRhLjwvZGl2PjtcblxuICAgIHJldHVybiA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXttb25lZGFzTW9kdWxlQ29uZmlnfSBpdGVtPXtpdGVtfSAvPjtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9tb25lZGFzL3BhZ2VzL01vbmVkYXNEZXRhaWxQYWdlLnRzeCJ9