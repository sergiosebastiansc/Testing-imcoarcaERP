import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transportes/pages/TransportesEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/transportes/pages/TransportesEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const TransportesEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error, saveItem } = useCrudItem(transportesModuleConfig, id);
  const handleSave = async (data) => {
    const updatedItem = await saveItem(data);
    if (updatedItem) {
      toast.info(`Transporte actualizado con éxito!`);
      navigate(getListReturnPath(transportesModuleConfig.baseRoute));
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesEditPage.tsx",
    lineNumber: 41,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesEditPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Transporte no encontrado." }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesEditPage.tsx",
    lineNumber: 43,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: transportesModuleConfig,
      initialData: item,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/transportes/pages/TransportesEditPage.tsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
};
_s(TransportesEditPage, "G8hjKIGDzF+QHmsnD2By/ug4KkU=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = TransportesEditPage;
var _c;
$RefreshReg$(_c, "TransportesEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/transportes/pages/TransportesEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/transportes/pages/TransportesEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsK0JBQWdEO0FBQ3pELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx5QkFBeUI7QUFFM0IsYUFBTUMsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxFQUFFQyxHQUFHLElBQUlWLFVBQTBCO0FBQ3pDLFFBQU1XLFdBQVdWLFlBQVk7QUFDN0IsUUFBTSxFQUFFVyxNQUFNQyxTQUFTQyxPQUFPQyxTQUFTLElBQUlYLFlBQXdCRCx5QkFBeUJPLEVBQUU7QUFFOUYsUUFBTU0sYUFBYSxPQUFPQyxTQUFxQjtBQUMzQyxVQUFNQyxjQUFjLE1BQU1ILFNBQVNFLElBQUk7QUFDdkMsUUFBSUMsYUFBYTtBQUNiYixZQUFNYyxLQUFLLG1DQUFtQztBQUM5Q1IsZUFBU0osa0JBQWtCSix3QkFBd0JpQixTQUFTLENBQUM7QUFBQSxJQUNqRTtBQUFBLEVBQ0o7QUFFQSxNQUFJUCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHlDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFFaEQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVQ7QUFBQUEsTUFDUixhQUFhUztBQUFBQSxNQUNiLFFBQVFJO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJZTtBQUd2QjtBQUFFUCxHQXpCV0QscUJBQW1CO0FBQUEsVUFDYlIsV0FDRUMsYUFDMEJHLFdBQVc7QUFBQTtBQUFBaUIsS0FIN0NiO0FBQW1CLElBQUFhO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNGb3JtUGFnZSIsInRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJ0b2FzdCIsIkxvYWRpbmdTcGlubmVyIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJUcmFuc3BvcnRlc0VkaXRQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiaXRlbSIsImxvYWRpbmciLCJlcnJvciIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJ1cGRhdGVkSXRlbSIsImluZm8iLCJiYXNlUm91dGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUcmFuc3BvcnRlc0VkaXRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljRm9ybVBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVBhZ2UnO1xuaW1wb3J0IHsgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcsIHR5cGUgVHJhbnNwb3J0ZSB9IGZyb20gJy4uL3RyYW5zcG9ydGVzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgVHJhbnNwb3J0ZXNFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbSwgbG9hZGluZywgZXJyb3IsIHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxUcmFuc3BvcnRlPih0cmFuc3BvcnRlc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBUcmFuc3BvcnRlKSA9PiB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRJdGVtID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YSk7XG4gICAgICAgIGlmICh1cGRhdGVkSXRlbSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhgVHJhbnNwb3J0ZSBhY3R1YWxpemFkbyBjb24gw6l4aXRvIWApO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgodHJhbnNwb3J0ZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghaXRlbSkgcmV0dXJuIDxkaXY+VHJhbnNwb3J0ZSBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17dHJhbnNwb3J0ZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aXRlbX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3RyYW5zcG9ydGVzL3BhZ2VzL1RyYW5zcG9ydGVzRWRpdFBhZ2UudHN4In0=