import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { FaPencilAlt, FaRegTrashAlt, FaSave, FaSpinner, FaTimes } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { useModal } from "/src/context/ModalContext.tsx";
import {
  createItem,
  deleteItem,
  listItems,
  updateItem
} from "/src/services/accessoryTablesService.ts";
import {
  ACCESSORY_TABLES,
  DEFAULT_ACCESSORY_TABLE,
  getAccessoryTableConfig
} from "/src/features/tablas_accesorias/accessoryTables.config.ts";
function parseApiFieldErrors(error) {
  if (!error || typeof error !== "object" || !("response" in error)) return {};
  const data = error.response?.data;
  if (!data?.errors || typeof data.errors !== "object") return {};
  const mapped = {};
  for (const [field, messages] of Object.entries(data.errors)) {
    if (Array.isArray(messages) && messages[0]) {
      mapped[field] = messages[0];
    }
  }
  return mapped;
}
function parseApiMessage(error, fallback) {
  if (error && typeof error === "object" && "response" in error) {
    const data = error.response?.data;
    if (typeof data?.message === "string" && data.message.trim()) {
      return data.message.trim();
    }
  }
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}
const inputClass = "mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500";
const inputErrorClass = "mt-1 block w-full rounded-md border border-red-500 px-3 py-2 text-sm shadow-sm focus:border-red-500 focus:ring-red-500";
export const TablasAccesoriasPage = () => {
  _s();
  const { showConfirmationModal } = useModal();
  const [tableKey, setTableKey] = useState(DEFAULT_ACCESSORY_TABLE);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState();
  const [editingId, setEditingId] = useState(null);
  const [editingName, setEditingName] = useState("");
  const [savingId, setSavingId] = useState(null);
  const [editError, setEditError] = useState();
  const tableConfig = getAccessoryTableConfig(tableKey);
  const loadList = useCallback(async (endpoint) => {
    setLoading(true);
    try {
      const data = await listItems(endpoint);
      setItems(data);
    } catch (err) {
      toast.error(parseApiMessage(err, "No se pudo cargar el listado."));
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    setNewName("");
    setCreateError(void 0);
    setEditingId(null);
    setEditingName("");
    setEditError(void 0);
    void loadList(tableConfig.endpoint);
  }, [tableConfig.endpoint, loadList]);
  const handleTableChange = (key) => {
    setTableKey(key);
  };
  const handleCreate = async (e) => {
    e.preventDefault();
    const name = newName.trim();
    if (!name) {
      setCreateError("El nombre es obligatorio.");
      return;
    }
    setCreating(true);
    setCreateError(void 0);
    try {
      await createItem(tableConfig.endpoint, name);
      toast.success(`${tableConfig.label.slice(0, -1)} creada.`);
      setNewName("");
      await loadList(tableConfig.endpoint);
    } catch (err) {
      const fieldErrors = parseApiFieldErrors(err);
      if (fieldErrors.name) {
        setCreateError(fieldErrors.name);
      } else {
        toast.error(parseApiMessage(err, "No se pudo crear el registro."));
      }
    } finally {
      setCreating(false);
    }
  };
  const startEdit = (item) => {
    setEditingId(item.id);
    setEditingName(item.name);
    setEditError(void 0);
  };
  const cancelEdit = () => {
    setEditingId(null);
    setEditingName("");
    setEditError(void 0);
  };
  const handleSaveEdit = async (id) => {
    const name = editingName.trim();
    if (!name) {
      setEditError("El nombre es obligatorio.");
      return;
    }
    setSavingId(id);
    setEditError(void 0);
    try {
      await updateItem(tableConfig.endpoint, id, name);
      toast.success("Registro actualizado.");
      cancelEdit();
      await loadList(tableConfig.endpoint);
    } catch (err) {
      const fieldErrors = parseApiFieldErrors(err);
      if (fieldErrors.name) {
        setEditError(fieldErrors.name);
      } else {
        toast.error(parseApiMessage(err, "No se pudo actualizar el registro."));
      }
    } finally {
      setSavingId(null);
    }
  };
  const handleDelete = (item) => {
    showConfirmationModal({
      title: `Eliminar ${tableConfig.label.slice(0, -1).toLowerCase()}`,
      message: `¿Estás seguro de que deseas eliminar "${item.name}"? Esta acción no se puede deshacer.`,
      onConfirm: async () => {
        try {
          await deleteItem(tableConfig.endpoint, item.id);
          toast.info("Registro eliminado.");
          if (editingId === item.id) cancelEdit();
          await loadList(tableConfig.endpoint);
        } catch (err) {
          toast.error(parseApiMessage(err, "No se pudo eliminar el registro."));
        }
      }
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-3xl space-y-6 p-4 sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: "Tablas accesorias" }, void 0, false, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 195,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-600", children: "Administrá líneas, categorías y zonas usadas en el sistema." }, void 0, false, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 196,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 194,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "accessory-table", className: "block text-sm font-medium text-gray-700", children: "Tabla a administrar" }, void 0, false, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 202,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          id: "accessory-table",
          className: inputClass,
          value: tableKey,
          onChange: (e) => handleTableChange(e.target.value),
          children: ACCESSORY_TABLES.map(
            (t) => /* @__PURE__ */ jsxDEV("option", { value: t.key, children: t.label }, t.key, false, {
              fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
              lineNumber: 212,
              columnNumber: 11
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 205,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 201,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreate, autoComplete: "off", className: "flex flex-col gap-2 sm:flex-row sm:items-start", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "new-name", className: "sr-only", children: "Nombre nuevo" }, void 0, false, {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "new-name",
            type: "text",
            autoComplete: "off",
            className: createError ? inputErrorClass : inputClass,
            placeholder: `Nuevo nombre de ${tableConfig.label.toLowerCase()}`,
            value: newName,
            onChange: (e) => {
              setNewName(e.target.value);
              if (createError) setCreateError(void 0);
            },
            disabled: creating || loading,
            maxLength: 255
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 224,
            columnNumber: 21
          },
          this
        ),
        createError && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: createError }, void 0, false, {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 237,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 220,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          disabled: creating || loading,
          className: "inline-flex items-center justify-center gap-2 rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50",
          children: [
            creating ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin" }, void 0, false, {
              fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
              lineNumber: 244,
              columnNumber: 33
            }, this) : null,
            "Agregar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 239,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 219,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-12", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 251,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 250,
      columnNumber: 7
    }, this) : items.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "py-8 text-center text-sm text-gray-500", children: "No hay registros." }, void 0, false, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 254,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-md border border-gray-200", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500", children: "Nombre" }, void 0, false, {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 260,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-gray-500", children: "Acciones" }, void 0, false, {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 263,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 259,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 258,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200 bg-white", children: items.map((item) => {
        const isEditing = editingId === item.id;
        const isSaving = savingId === item.id;
        return /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: isEditing ? /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                autoComplete: "off",
                className: editError ? inputErrorClass : inputClass,
                value: editingName,
                onChange: (e) => {
                  setEditingName(e.target.value);
                  if (editError) setEditError(void 0);
                },
                disabled: isSaving,
                maxLength: 255,
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                lineNumber: 277,
                columnNumber: 53
              },
              this
            ),
            editError && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: editError }, void 0, false, {
              fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
              lineNumber: 290,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 276,
            columnNumber: 21
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-900", children: item.name }, void 0, false, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 294,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 274,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right", children: /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2", children: isEditing ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                title: "Guardar",
                disabled: isSaving,
                onClick: () => void handleSaveEdit(item.id),
                className: "rounded p-1.5 text-indigo-600 hover:bg-indigo-50 disabled:opacity-50",
                children: isSaving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin" }, void 0, false, {
                  fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                  lineNumber: 309,
                  columnNumber: 27
                }, this) : /* @__PURE__ */ jsxDEV(FaSave, {}, void 0, false, {
                  fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                  lineNumber: 311,
                  columnNumber: 27
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                lineNumber: 301,
                columnNumber: 57
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                title: "Cancelar",
                disabled: isSaving,
                onClick: cancelEdit,
                className: "rounded p-1.5 text-gray-500 hover:bg-gray-100 disabled:opacity-50",
                children: /* @__PURE__ */ jsxDEV(FaTimes, {}, void 0, false, {
                  fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                  lineNumber: 321,
                  columnNumber: 61
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                lineNumber: 314,
                columnNumber: 57
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 300,
            columnNumber: 23
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                title: "Editar",
                onClick: () => startEdit(item),
                className: "rounded p-1.5 text-indigo-600 hover:bg-indigo-50",
                children: /* @__PURE__ */ jsxDEV(FaPencilAlt, {}, void 0, false, {
                  fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                  lineNumber: 332,
                  columnNumber: 61
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                lineNumber: 326,
                columnNumber: 57
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                title: "Eliminar",
                onClick: () => handleDelete(item),
                className: "rounded p-1.5 text-red-600 hover:bg-red-50",
                children: /* @__PURE__ */ jsxDEV(FaRegTrashAlt, {}, void 0, false, {
                  fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                  lineNumber: 340,
                  columnNumber: 61
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
                lineNumber: 334,
                columnNumber: 57
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 325,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 298,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
            lineNumber: 297,
            columnNumber: 41
          }, this)
        ] }, item.id, true, {
          fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
          lineNumber: 273,
          columnNumber: 17
        }, this);
      }) }, void 0, false, {
        fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
        lineNumber: 268,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 257,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
      lineNumber: 256,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx",
    lineNumber: 193,
    columnNumber: 5
  }, this);
};
_s(TablasAccesoriasPage, "E7iRY9BwkhKDS67U1SIyfYGR0uc=", false, function() {
  return [useModal];
});
_c = TablasAccesoriasPage;
var _c;
$RefreshReg$(_c, "TablasAccesoriasPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0tnQixTQXlHb0MsVUF6R3BDOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9LaEIsU0FBU0EsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQ2pELFNBQVNDLGFBQWFDLGVBQWVDLFFBQVFDLFdBQVdDLGVBQWU7QUFDdkUsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDRztBQUNQO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FHRztBQUlQLFNBQVNDLG9CQUFvQkMsT0FBNkI7QUFDdEQsTUFBSSxDQUFDQSxTQUFTLE9BQU9BLFVBQVUsWUFBWSxFQUFFLGNBQWNBLE9BQVEsUUFBTyxDQUFDO0FBQzNFLFFBQU1DLE9BQVFELE1BQTBFRSxVQUNsRkQ7QUFDTixNQUFJLENBQUNBLE1BQU1FLFVBQVUsT0FBT0YsS0FBS0UsV0FBVyxTQUFVLFFBQU8sQ0FBQztBQUM5RCxRQUFNQyxTQUFzQixDQUFDO0FBQzdCLGFBQVcsQ0FBQ0MsT0FBT0MsUUFBUSxLQUFLQyxPQUFPQyxRQUFRUCxLQUFLRSxNQUFNLEdBQUc7QUFDekQsUUFBSU0sTUFBTUMsUUFBUUosUUFBUSxLQUFLQSxTQUFTLENBQUMsR0FBRztBQUN4Q0YsYUFBT0MsS0FBSyxJQUFJQyxTQUFTLENBQUM7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFDQSxTQUFPRjtBQUNYO0FBRUEsU0FBU08sZ0JBQWdCWCxPQUFnQlksVUFBMEI7QUFDL0QsTUFBSVosU0FBUyxPQUFPQSxVQUFVLFlBQVksY0FBY0EsT0FBTztBQUMzRCxVQUFNQyxPQUFRRCxNQUF5REUsVUFBVUQ7QUFDakYsUUFBSSxPQUFPQSxNQUFNWSxZQUFZLFlBQVlaLEtBQUtZLFFBQVFDLEtBQUssR0FBRztBQUMxRCxhQUFPYixLQUFLWSxRQUFRQyxLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNKO0FBQ0EsTUFBSWQsaUJBQWlCZSxTQUFTZixNQUFNYSxRQUFTLFFBQU9iLE1BQU1hO0FBQzFELFNBQU9EO0FBQ1g7QUFFQSxNQUFNSSxhQUNGO0FBQ0osTUFBTUMsa0JBQ0Y7QUFFRyxhQUFNQyx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUVDLHNCQUFzQixJQUFJN0IsU0FBUztBQUMzQyxRQUFNLENBQUM4QixVQUFVQyxXQUFXLElBQUl2QyxTQUE0QmMsdUJBQXVCO0FBQ25GLFFBQU0sQ0FBQzBCLE9BQU9DLFFBQVEsSUFBSXpDLFNBQTBCLEVBQUU7QUFDdEQsUUFBTSxDQUFDMEMsU0FBU0MsVUFBVSxJQUFJM0MsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzRDLFNBQVNDLFVBQVUsSUFBSTdDLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM4QyxVQUFVQyxXQUFXLElBQUkvQyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDZ0QsYUFBYUMsY0FBYyxJQUFJakQsU0FBNkI7QUFDbkUsUUFBTSxDQUFDa0QsV0FBV0MsWUFBWSxJQUFJbkQsU0FBd0IsSUFBSTtBQUM5RCxRQUFNLENBQUNvRCxhQUFhQyxjQUFjLElBQUlyRCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0QsVUFBVUMsV0FBVyxJQUFJdkQsU0FBd0IsSUFBSTtBQUM1RCxRQUFNLENBQUN3RCxXQUFXQyxZQUFZLElBQUl6RCxTQUE2QjtBQUUvRCxRQUFNMEQsY0FBYzNDLHdCQUF3QnVCLFFBQVE7QUFFcEQsUUFBTXFCLFdBQVc3RCxZQUFZLE9BQU84RCxhQUFxQjtBQUNyRGpCLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNekIsT0FBTyxNQUFNUCxVQUFVaUQsUUFBUTtBQUNyQ25CLGVBQVN2QixJQUFJO0FBQUEsSUFDakIsU0FBUzJDLEtBQUs7QUFDVnZELFlBQU1XLE1BQU1XLGdCQUFnQmlDLEtBQUssK0JBQStCLENBQUM7QUFDakVwQixlQUFTLEVBQUU7QUFBQSxJQUNmLFVBQUM7QUFDR0UsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFFTDVDLFlBQVUsTUFBTTtBQUNaOEMsZUFBVyxFQUFFO0FBQ2JJLG1CQUFlYSxNQUFTO0FBQ3hCWCxpQkFBYSxJQUFJO0FBQ2pCRSxtQkFBZSxFQUFFO0FBQ2pCSSxpQkFBYUssTUFBUztBQUN0QixTQUFLSCxTQUFTRCxZQUFZRSxRQUFRO0FBQUEsRUFDdEMsR0FBRyxDQUFDRixZQUFZRSxVQUFVRCxRQUFRLENBQUM7QUFFbkMsUUFBTUksb0JBQW9CQSxDQUFDQyxRQUEyQjtBQUNsRHpCLGdCQUFZeUIsR0FBRztBQUFBLEVBQ25CO0FBRUEsUUFBTUMsZUFBZSxPQUFPQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQixVQUFNQyxPQUFPeEIsUUFBUWIsS0FBSztBQUMxQixRQUFJLENBQUNxQyxNQUFNO0FBQ1BuQixxQkFBZSwyQkFBMkI7QUFDMUM7QUFBQSxJQUNKO0FBQ0FGLGdCQUFZLElBQUk7QUFDaEJFLG1CQUFlYSxNQUFTO0FBQ3hCLFFBQUk7QUFDQSxZQUFNckQsV0FBV2lELFlBQVlFLFVBQVVRLElBQUk7QUFDM0M5RCxZQUFNK0QsUUFBUSxHQUFHWCxZQUFZWSxNQUFNQyxNQUFNLEdBQUcsRUFBRSxDQUFDLFVBQVU7QUFDekQxQixpQkFBVyxFQUFFO0FBQ2IsWUFBTWMsU0FBU0QsWUFBWUUsUUFBUTtBQUFBLElBQ3ZDLFNBQVNDLEtBQUs7QUFDVixZQUFNVyxjQUFjeEQsb0JBQW9CNkMsR0FBRztBQUMzQyxVQUFJVyxZQUFZSixNQUFNO0FBQ2xCbkIsdUJBQWV1QixZQUFZSixJQUFJO0FBQUEsTUFDbkMsT0FBTztBQUNIOUQsY0FBTVcsTUFBTVcsZ0JBQWdCaUMsS0FBSywrQkFBK0IsQ0FBQztBQUFBLE1BQ3JFO0FBQUEsSUFDSixVQUFDO0FBQ0dkLGtCQUFZLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFFQSxRQUFNMEIsWUFBWUEsQ0FBQ0MsU0FBd0I7QUFDdkN2QixpQkFBYXVCLEtBQUtDLEVBQUU7QUFDcEJ0QixtQkFBZXFCLEtBQUtOLElBQUk7QUFDeEJYLGlCQUFhSyxNQUFTO0FBQUEsRUFDMUI7QUFFQSxRQUFNYyxhQUFhQSxNQUFNO0FBQ3JCekIsaUJBQWEsSUFBSTtBQUNqQkUsbUJBQWUsRUFBRTtBQUNqQkksaUJBQWFLLE1BQVM7QUFBQSxFQUMxQjtBQUVBLFFBQU1lLGlCQUFpQixPQUFPRixPQUFlO0FBQ3pDLFVBQU1QLE9BQU9oQixZQUFZckIsS0FBSztBQUM5QixRQUFJLENBQUNxQyxNQUFNO0FBQ1BYLG1CQUFhLDJCQUEyQjtBQUN4QztBQUFBLElBQ0o7QUFDQUYsZ0JBQVlvQixFQUFFO0FBQ2RsQixpQkFBYUssTUFBUztBQUN0QixRQUFJO0FBQ0EsWUFBTWxELFdBQVc4QyxZQUFZRSxVQUFVZSxJQUFJUCxJQUFJO0FBQy9DOUQsWUFBTStELFFBQVEsdUJBQXVCO0FBQ3JDTyxpQkFBVztBQUNYLFlBQU1qQixTQUFTRCxZQUFZRSxRQUFRO0FBQUEsSUFDdkMsU0FBU0MsS0FBSztBQUNWLFlBQU1XLGNBQWN4RCxvQkFBb0I2QyxHQUFHO0FBQzNDLFVBQUlXLFlBQVlKLE1BQU07QUFDbEJYLHFCQUFhZSxZQUFZSixJQUFJO0FBQUEsTUFDakMsT0FBTztBQUNIOUQsY0FBTVcsTUFBTVcsZ0JBQWdCaUMsS0FBSyxvQ0FBb0MsQ0FBQztBQUFBLE1BQzFFO0FBQUEsSUFDSixVQUFDO0FBQ0dOLGtCQUFZLElBQUk7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxRQUFNdUIsZUFBZUEsQ0FBQ0osU0FBd0I7QUFDMUNyQywwQkFBc0I7QUFBQSxNQUNsQjBDLE9BQU8sWUFBWXJCLFlBQVlZLE1BQU1DLE1BQU0sR0FBRyxFQUFFLEVBQUVTLFlBQVksQ0FBQztBQUFBLE1BQy9EbEQsU0FBUyx5Q0FBeUM0QyxLQUFLTixJQUFJO0FBQUEsTUFDM0RhLFdBQVcsWUFBWTtBQUNuQixZQUFJO0FBQ0EsZ0JBQU12RSxXQUFXZ0QsWUFBWUUsVUFBVWMsS0FBS0MsRUFBRTtBQUM5Q3JFLGdCQUFNNEUsS0FBSyxxQkFBcUI7QUFDaEMsY0FBSWhDLGNBQWN3QixLQUFLQyxHQUFJQyxZQUFXO0FBQ3RDLGdCQUFNakIsU0FBU0QsWUFBWUUsUUFBUTtBQUFBLFFBQ3ZDLFNBQVNDLEtBQUs7QUFDVnZELGdCQUFNVyxNQUFNVyxnQkFBZ0JpQyxLQUFLLGtDQUFrQyxDQUFDO0FBQUEsUUFDeEU7QUFBQSxNQUNKO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLDBDQUNYO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsaUNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCLDJFQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFdBQU0sU0FBUSxtQkFBa0IsV0FBVSwyQ0FBeUMsbUNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLElBQUc7QUFBQSxVQUNILFdBQVc1QjtBQUFBQSxVQUNYLE9BQU9LO0FBQUFBLFVBQ1AsVUFBVSxDQUFDNEIsTUFBTUgsa0JBQWtCRyxFQUFFaUIsT0FBT0MsS0FBMEI7QUFBQSxVQUVyRXZFLDJCQUFpQndFO0FBQUFBLFlBQUksQ0FBQ0MsTUFDbkIsdUJBQUMsWUFBbUIsT0FBT0EsRUFBRXRCLEtBQ3hCc0IsWUFBRWhCLFNBRE1nQixFQUFFdEIsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDSDtBQUFBO0FBQUEsUUFWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLFNBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBRUEsdUJBQUMsVUFBSyxVQUFVQyxjQUFjLGNBQWEsT0FBTSxXQUFVLGtEQUN2RDtBQUFBLDZCQUFDLFNBQUksV0FBVSxVQUNYO0FBQUEsK0JBQUMsV0FBTSxTQUFRLFlBQVcsV0FBVSxXQUFTLDRCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxjQUFhO0FBQUEsWUFBTSxXQUFXakIsY0FBY2Qsa0JBQWtCRDtBQUFBQSxZQUM5RCxhQUFhLG1CQUFtQnlCLFlBQVlZLE1BQU1VLFlBQVksQ0FBQztBQUFBLFlBQy9ELE9BQU9wQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ3NCLE1BQU07QUFDYnJCLHlCQUFXcUIsRUFBRWlCLE9BQU9DLEtBQUs7QUFDekIsa0JBQUlwQyxZQUFhQyxnQkFBZWEsTUFBUztBQUFBLFlBQzdDO0FBQUEsWUFDQSxVQUFVaEIsWUFBWUo7QUFBQUEsWUFDdEIsV0FBVztBQUFBO0FBQUEsVUFYZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXbUI7QUFBQSxRQUVsQk0sZUFBZSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSx5QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFdBakIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsVUFBVUYsWUFBWUo7QUFBQUEsVUFDdEIsV0FBVTtBQUFBLFVBRVRJO0FBQUFBLHVCQUFXLHVCQUFDLGFBQVUsV0FBVSxrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUMsSUFBTTtBQUFBLFlBQUk7QUFBQTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFFQ0osVUFDRyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1gsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUNBRixNQUFNK0MsV0FBVyxJQUNqQix1QkFBQyxPQUFFLFdBQVUsMENBQXlDLGlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVFLElBRXZFLHVCQUFDLFNBQUksV0FBVSxxREFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtGQUFnRixzQkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsbUZBQWlGLHdCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaL0MsZ0JBQU02QyxJQUFJLENBQUNYLFNBQVM7QUFDakIsY0FBTWMsWUFBWXRDLGNBQWN3QixLQUFLQztBQUNyQyxjQUFNYyxXQUFXbkMsYUFBYW9CLEtBQUtDO0FBQ25DLGVBQ0ksdUJBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxhQUNUYSxzQkFDRyx1QkFBQyxTQUNHO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsY0FBYTtBQUFBLGdCQUFNLFdBQVdoQyxZQUFZdEIsa0JBQWtCRDtBQUFBQSxnQkFDNUQsT0FBT21CO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2MsTUFBTTtBQUNiYixpQ0FBZWEsRUFBRWlCLE9BQU9DLEtBQUs7QUFDN0Isc0JBQUk1QixVQUFXQyxjQUFhSyxNQUFTO0FBQUEsZ0JBQ3pDO0FBQUEsZ0JBQ0EsVUFBVTJCO0FBQUFBLGdCQUNWLFdBQVc7QUFBQSxnQkFDWCxXQUFTO0FBQUE7QUFBQSxjQVZiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVhO0FBQUEsWUFFWmpDLGFBQ0csdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsdUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsZUFkNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkEsSUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQXlCa0IsZUFBS04sUUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQsS0FwQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsd0JBQ1YsaUNBQUMsU0FBSSxXQUFVLGtDQUNWb0Isc0JBQ0csbUNBQ0k7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxPQUFNO0FBQUEsZ0JBQ04sVUFBVUM7QUFBQUEsZ0JBQ1YsU0FBUyxNQUFNLEtBQUtaLGVBQWVILEtBQUtDLEVBQUU7QUFBQSxnQkFDMUMsV0FBVTtBQUFBLGdCQUVUYyxxQkFDRyx1QkFBQyxhQUFVLFdBQVUsa0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DLElBRW5DLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTztBQUFBO0FBQUEsY0FWZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTTtBQUFBLGdCQUNOLFVBQVVBO0FBQUFBLGdCQUNWLFNBQVNiO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVE7QUFBQTtBQUFBLGNBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQSxJQUVBLG1DQUNJO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTTtBQUFBLGdCQUNOLFNBQVMsTUFBTUgsVUFBVUMsSUFBSTtBQUFBLGdCQUM3QixXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUEsY0FOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLE9BQU07QUFBQSxnQkFDTixTQUFTLE1BQU1JLGFBQWFKLElBQUk7QUFBQSxnQkFDaEMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWM7QUFBQTtBQUFBLGNBTmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkEsS0E1Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4Q0EsS0EvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnREE7QUFBQSxhQXhFS0EsS0FBS0MsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUVBO0FBQUEsTUFFUixDQUFDLEtBaEZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpRkE7QUFBQSxTQTVGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkZBLEtBOUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRkE7QUFBQSxPQTlKUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0tBO0FBRVI7QUFBRXZDLEdBNVJXRCxzQkFBb0I7QUFBQSxVQUNLM0IsUUFBUTtBQUFBO0FBQUFrRixLQURqQ3ZEO0FBQW9CLElBQUF1RDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkZhUGVuY2lsQWx0IiwiRmFSZWdUcmFzaEFsdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhVGltZXMiLCJ0b2FzdCIsIkxvYWRpbmdTcGlubmVyIiwidXNlTW9kYWwiLCJjcmVhdGVJdGVtIiwiZGVsZXRlSXRlbSIsImxpc3RJdGVtcyIsInVwZGF0ZUl0ZW0iLCJBQ0NFU1NPUllfVEFCTEVTIiwiREVGQVVMVF9BQ0NFU1NPUllfVEFCTEUiLCJnZXRBY2Nlc3NvcnlUYWJsZUNvbmZpZyIsInBhcnNlQXBpRmllbGRFcnJvcnMiLCJlcnJvciIsImRhdGEiLCJyZXNwb25zZSIsImVycm9ycyIsIm1hcHBlZCIsImZpZWxkIiwibWVzc2FnZXMiLCJPYmplY3QiLCJlbnRyaWVzIiwiQXJyYXkiLCJpc0FycmF5IiwicGFyc2VBcGlNZXNzYWdlIiwiZmFsbGJhY2siLCJtZXNzYWdlIiwidHJpbSIsIkVycm9yIiwiaW5wdXRDbGFzcyIsImlucHV0RXJyb3JDbGFzcyIsIlRhYmxhc0FjY2Vzb3JpYXNQYWdlIiwiX3MiLCJzaG93Q29uZmlybWF0aW9uTW9kYWwiLCJ0YWJsZUtleSIsInNldFRhYmxlS2V5IiwiaXRlbXMiLCJzZXRJdGVtcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibmV3TmFtZSIsInNldE5ld05hbWUiLCJjcmVhdGluZyIsInNldENyZWF0aW5nIiwiY3JlYXRlRXJyb3IiLCJzZXRDcmVhdGVFcnJvciIsImVkaXRpbmdJZCIsInNldEVkaXRpbmdJZCIsImVkaXRpbmdOYW1lIiwic2V0RWRpdGluZ05hbWUiLCJzYXZpbmdJZCIsInNldFNhdmluZ0lkIiwiZWRpdEVycm9yIiwic2V0RWRpdEVycm9yIiwidGFibGVDb25maWciLCJsb2FkTGlzdCIsImVuZHBvaW50IiwiZXJyIiwidW5kZWZpbmVkIiwiaGFuZGxlVGFibGVDaGFuZ2UiLCJrZXkiLCJoYW5kbGVDcmVhdGUiLCJlIiwicHJldmVudERlZmF1bHQiLCJuYW1lIiwic3VjY2VzcyIsImxhYmVsIiwic2xpY2UiLCJmaWVsZEVycm9ycyIsInN0YXJ0RWRpdCIsIml0ZW0iLCJpZCIsImNhbmNlbEVkaXQiLCJoYW5kbGVTYXZlRWRpdCIsImhhbmRsZURlbGV0ZSIsInRpdGxlIiwidG9Mb3dlckNhc2UiLCJvbkNvbmZpcm0iLCJpbmZvIiwidGFyZ2V0IiwidmFsdWUiLCJtYXAiLCJ0IiwibGVuZ3RoIiwiaXNFZGl0aW5nIiwiaXNTYXZpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJsYXNBY2Nlc29yaWFzUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGYVBlbmNpbEFsdCwgRmFSZWdUcmFzaEFsdCwgRmFTYXZlLCBGYVNwaW5uZXIsIEZhVGltZXMgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyB1c2VNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbnRleHQvTW9kYWxDb250ZXh0JztcbmltcG9ydCB7XG4gICAgY3JlYXRlSXRlbSxcbiAgICBkZWxldGVJdGVtLFxuICAgIGxpc3RJdGVtcyxcbiAgICB1cGRhdGVJdGVtLFxufSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hY2Nlc3NvcnlUYWJsZXNTZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgQUNDRVNTT1JZX1RBQkxFUyxcbiAgICBERUZBVUxUX0FDQ0VTU09SWV9UQUJMRSxcbiAgICBnZXRBY2Nlc3NvcnlUYWJsZUNvbmZpZyxcbiAgICB0eXBlIEFjY2Vzc29yeUl0ZW0sXG4gICAgdHlwZSBBY2Nlc3NvcnlUYWJsZUtleSxcbn0gZnJvbSAnLi4vYWNjZXNzb3J5VGFibGVzLmNvbmZpZyc7XG5cbnR5cGUgRmllbGRFcnJvcnMgPSBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuXG5mdW5jdGlvbiBwYXJzZUFwaUZpZWxkRXJyb3JzKGVycm9yOiB1bmtub3duKTogRmllbGRFcnJvcnMge1xuICAgIGlmICghZXJyb3IgfHwgdHlwZW9mIGVycm9yICE9PSAnb2JqZWN0JyB8fCAhKCdyZXNwb25zZScgaW4gZXJyb3IpKSByZXR1cm4ge307XG4gICAgY29uc3QgZGF0YSA9IChlcnJvciBhcyB7IHJlc3BvbnNlPzogeyBkYXRhPzogeyBlcnJvcnM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gfSB9IH0pLnJlc3BvbnNlXG4gICAgICAgID8uZGF0YTtcbiAgICBpZiAoIWRhdGE/LmVycm9ycyB8fCB0eXBlb2YgZGF0YS5lcnJvcnMgIT09ICdvYmplY3QnKSByZXR1cm4ge307XG4gICAgY29uc3QgbWFwcGVkOiBGaWVsZEVycm9ycyA9IHt9O1xuICAgIGZvciAoY29uc3QgW2ZpZWxkLCBtZXNzYWdlc10gb2YgT2JqZWN0LmVudHJpZXMoZGF0YS5lcnJvcnMpKSB7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KG1lc3NhZ2VzKSAmJiBtZXNzYWdlc1swXSkge1xuICAgICAgICAgICAgbWFwcGVkW2ZpZWxkXSA9IG1lc3NhZ2VzWzBdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtYXBwZWQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlQXBpTWVzc2FnZShlcnJvcjogdW5rbm93biwgZmFsbGJhY2s6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgaWYgKGVycm9yICYmIHR5cGVvZiBlcnJvciA9PT0gJ29iamVjdCcgJiYgJ3Jlc3BvbnNlJyBpbiBlcnJvcikge1xuICAgICAgICBjb25zdCBkYXRhID0gKGVycm9yIGFzIHsgcmVzcG9uc2U/OiB7IGRhdGE/OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSB9IH0pLnJlc3BvbnNlPy5kYXRhO1xuICAgICAgICBpZiAodHlwZW9mIGRhdGE/Lm1lc3NhZ2UgPT09ICdzdHJpbmcnICYmIGRhdGEubWVzc2FnZS50cmltKCkpIHtcbiAgICAgICAgICAgIHJldHVybiBkYXRhLm1lc3NhZ2UudHJpbSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm1lc3NhZ2UpIHJldHVybiBlcnJvci5tZXNzYWdlO1xuICAgIHJldHVybiBmYWxsYmFjaztcbn1cblxuY29uc3QgaW5wdXRDbGFzcyA9XG4gICAgJ210LTEgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBweC0zIHB5LTIgdGV4dC1zbSBzaGFkb3ctc20gZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgZm9jdXM6cmluZy1pbmRpZ28tNTAwJztcbmNvbnN0IGlucHV0RXJyb3JDbGFzcyA9XG4gICAgJ210LTEgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHB4LTMgcHktMiB0ZXh0LXNtIHNoYWRvdy1zbSBmb2N1czpib3JkZXItcmVkLTUwMCBmb2N1czpyaW5nLXJlZC01MDAnO1xuXG5leHBvcnQgY29uc3QgVGFibGFzQWNjZXNvcmlhc1BhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBzaG93Q29uZmlybWF0aW9uTW9kYWwgfSA9IHVzZU1vZGFsKCk7XG4gICAgY29uc3QgW3RhYmxlS2V5LCBzZXRUYWJsZUtleV0gPSB1c2VTdGF0ZTxBY2Nlc3NvcnlUYWJsZUtleT4oREVGQVVMVF9BQ0NFU1NPUllfVEFCTEUpO1xuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8QWNjZXNzb3J5SXRlbVtdPihbXSk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW25ld05hbWUsIHNldE5ld05hbWVdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtjcmVhdGluZywgc2V0Q3JlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjcmVhdGVFcnJvciwgc2V0Q3JlYXRlRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgdW5kZWZpbmVkPigpO1xuICAgIGNvbnN0IFtlZGl0aW5nSWQsIHNldEVkaXRpbmdJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZWRpdGluZ05hbWUsIHNldEVkaXRpbmdOYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbc2F2aW5nSWQsIHNldFNhdmluZ0lkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0RXJyb3IsIHNldEVkaXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCB1bmRlZmluZWQ+KCk7XG5cbiAgICBjb25zdCB0YWJsZUNvbmZpZyA9IGdldEFjY2Vzc29yeVRhYmxlQ29uZmlnKHRhYmxlS2V5KTtcblxuICAgIGNvbnN0IGxvYWRMaXN0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKGVuZHBvaW50OiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0SXRlbXMoZW5kcG9pbnQpO1xuICAgICAgICAgICAgc2V0SXRlbXMoZGF0YSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IocGFyc2VBcGlNZXNzYWdlKGVyciwgJ05vIHNlIHB1ZG8gY2FyZ2FyIGVsIGxpc3RhZG8uJykpO1xuICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXROZXdOYW1lKCcnKTtcbiAgICAgICAgc2V0Q3JlYXRlRXJyb3IodW5kZWZpbmVkKTtcbiAgICAgICAgc2V0RWRpdGluZ0lkKG51bGwpO1xuICAgICAgICBzZXRFZGl0aW5nTmFtZSgnJyk7XG4gICAgICAgIHNldEVkaXRFcnJvcih1bmRlZmluZWQpO1xuICAgICAgICB2b2lkIGxvYWRMaXN0KHRhYmxlQ29uZmlnLmVuZHBvaW50KTtcbiAgICB9LCBbdGFibGVDb25maWcuZW5kcG9pbnQsIGxvYWRMaXN0XSk7XG5cbiAgICBjb25zdCBoYW5kbGVUYWJsZUNoYW5nZSA9IChrZXk6IEFjY2Vzc29yeVRhYmxlS2V5KSA9PiB7XG4gICAgICAgIHNldFRhYmxlS2V5KGtleSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNyZWF0ZSA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zdCBuYW1lID0gbmV3TmFtZS50cmltKCk7XG4gICAgICAgIGlmICghbmFtZSkge1xuICAgICAgICAgICAgc2V0Q3JlYXRlRXJyb3IoJ0VsIG5vbWJyZSBlcyBvYmxpZ2F0b3Jpby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRDcmVhdGluZyh0cnVlKTtcbiAgICAgICAgc2V0Q3JlYXRlRXJyb3IodW5kZWZpbmVkKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZUl0ZW0odGFibGVDb25maWcuZW5kcG9pbnQsIG5hbWUpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgJHt0YWJsZUNvbmZpZy5sYWJlbC5zbGljZSgwLCAtMSl9IGNyZWFkYS5gKTtcbiAgICAgICAgICAgIHNldE5ld05hbWUoJycpO1xuICAgICAgICAgICAgYXdhaXQgbG9hZExpc3QodGFibGVDb25maWcuZW5kcG9pbnQpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkRXJyb3JzID0gcGFyc2VBcGlGaWVsZEVycm9ycyhlcnIpO1xuICAgICAgICAgICAgaWYgKGZpZWxkRXJyb3JzLm5hbWUpIHtcbiAgICAgICAgICAgICAgICBzZXRDcmVhdGVFcnJvcihmaWVsZEVycm9ycy5uYW1lKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IocGFyc2VBcGlNZXNzYWdlKGVyciwgJ05vIHNlIHB1ZG8gY3JlYXIgZWwgcmVnaXN0cm8uJykpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHN0YXJ0RWRpdCA9IChpdGVtOiBBY2Nlc3NvcnlJdGVtKSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdJZChpdGVtLmlkKTtcbiAgICAgICAgc2V0RWRpdGluZ05hbWUoaXRlbS5uYW1lKTtcbiAgICAgICAgc2V0RWRpdEVycm9yKHVuZGVmaW5lZCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGNhbmNlbEVkaXQgPSAoKSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdJZChudWxsKTtcbiAgICAgICAgc2V0RWRpdGluZ05hbWUoJycpO1xuICAgICAgICBzZXRFZGl0RXJyb3IodW5kZWZpbmVkKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZUVkaXQgPSBhc3luYyAoaWQ6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBuYW1lID0gZWRpdGluZ05hbWUudHJpbSgpO1xuICAgICAgICBpZiAoIW5hbWUpIHtcbiAgICAgICAgICAgIHNldEVkaXRFcnJvcignRWwgbm9tYnJlIGVzIG9ibGlnYXRvcmlvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldFNhdmluZ0lkKGlkKTtcbiAgICAgICAgc2V0RWRpdEVycm9yKHVuZGVmaW5lZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCB1cGRhdGVJdGVtKHRhYmxlQ29uZmlnLmVuZHBvaW50LCBpZCwgbmFtZSk7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKCdSZWdpc3RybyBhY3R1YWxpemFkby4nKTtcbiAgICAgICAgICAgIGNhbmNlbEVkaXQoKTtcbiAgICAgICAgICAgIGF3YWl0IGxvYWRMaXN0KHRhYmxlQ29uZmlnLmVuZHBvaW50KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZEVycm9ycyA9IHBhcnNlQXBpRmllbGRFcnJvcnMoZXJyKTtcbiAgICAgICAgICAgIGlmIChmaWVsZEVycm9ycy5uYW1lKSB7XG4gICAgICAgICAgICAgICAgc2V0RWRpdEVycm9yKGZpZWxkRXJyb3JzLm5hbWUpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihwYXJzZUFwaU1lc3NhZ2UoZXJyLCAnTm8gc2UgcHVkbyBhY3R1YWxpemFyIGVsIHJlZ2lzdHJvLicpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldFNhdmluZ0lkKG51bGwpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZSA9IChpdGVtOiBBY2Nlc3NvcnlJdGVtKSA9PiB7XG4gICAgICAgIHNob3dDb25maXJtYXRpb25Nb2RhbCh7XG4gICAgICAgICAgICB0aXRsZTogYEVsaW1pbmFyICR7dGFibGVDb25maWcubGFiZWwuc2xpY2UoMCwgLTEpLnRvTG93ZXJDYXNlKCl9YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGDCv0VzdMOhcyBzZWd1cm8gZGUgcXVlIGRlc2VhcyBlbGltaW5hciBcIiR7aXRlbS5uYW1lfVwiPyBFc3RhIGFjY2nDs24gbm8gc2UgcHVlZGUgZGVzaGFjZXIuYCxcbiAgICAgICAgICAgIG9uQ29uZmlybTogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGRlbGV0ZUl0ZW0odGFibGVDb25maWcuZW5kcG9pbnQsIGl0ZW0uaWQpO1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5pbmZvKCdSZWdpc3RybyBlbGltaW5hZG8uJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlZGl0aW5nSWQgPT09IGl0ZW0uaWQpIGNhbmNlbEVkaXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgbG9hZExpc3QodGFibGVDb25maWcuZW5kcG9pbnQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihwYXJzZUFwaU1lc3NhZ2UoZXJyLCAnTm8gc2UgcHVkbyBlbGltaW5hciBlbCByZWdpc3Ryby4nKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy0zeGwgc3BhY2UteS02IHAtNCBzbTpwLTZcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlRhYmxhcyBhY2Nlc29yaWFzPC9oMT5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICBBZG1pbmlzdHLDoSBsw61uZWFzLCBjYXRlZ29yw61hcyB5IHpvbmFzIHVzYWRhcyBlbiBlbCBzaXN0ZW1hLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYWNjZXNzb3J5LXRhYmxlXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFRhYmxhIGEgYWRtaW5pc3RyYXJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJhY2Nlc3NvcnktdGFibGVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0YWJsZUtleX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVUYWJsZUNoYW5nZShlLnRhcmdldC52YWx1ZSBhcyBBY2Nlc3NvcnlUYWJsZUtleSl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7QUNDRVNTT1JZX1RBQkxFUy5tYXAoKHQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0LmtleX0gdmFsdWU9e3Qua2V5fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlfSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIHNtOmZsZXgtcm93IHNtOml0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctbmFtZVwiIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE5vbWJyZSBudWV2b1xuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmV3LW5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPXtjcmVhdGVFcnJvciA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YE51ZXZvIG5vbWJyZSBkZSAke3RhYmxlQ29uZmlnLmxhYmVsLnRvTG93ZXJDYXNlKCl9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmV3TmFtZShlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNyZWF0ZUVycm9yKSBzZXRDcmVhdGVFcnJvcih1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjcmVhdGluZyB8fCBsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyNTV9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHtjcmVhdGVFcnJvciAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNjAwXCI+e2NyZWF0ZUVycm9yfTwvcD59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0aW5nIHx8IGxvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIGJnLWluZGlnby02MDAgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjcmVhdGluZyA/IDxGYVNwaW5uZXIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgLz4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICBBZ3JlZ2FyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0xMlwiPlxuICAgICAgICAgICAgICAgICAgICA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBpdGVtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgcmVnaXN0cm9zLjwvcD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWJyZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWNjaW9uZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDAgYmctd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRWRpdGluZyA9IGVkaXRpbmdJZCA9PT0gaXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTYXZpbmcgPSBzYXZpbmdJZCA9PT0gaXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPXtlZGl0RXJyb3IgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ05hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ05hbWUoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVkaXRFcnJvcikgc2V0RWRpdEVycm9yKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyNTV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VkaXRFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC02MDBcIj57ZWRpdEVycm9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57aXRlbS5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR3VhcmRhclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVNhdmVFZGl0KGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBwLTEuNSB0ZXh0LWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNTYXZpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTYXZlIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNhbmNlbGFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NhbmNlbEVkaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHAtMS41IHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRpbWVzIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWRpdGFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0RWRpdChpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgcC0xLjUgdGV4dC1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVBlbmNpbEFsdCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVsaW1pbmFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgcC0xLjUgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJlZ1RyYXNoQWx0IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3RhYmxhc19hY2Nlc29yaWFzL3BhZ2VzL1RhYmxhc0FjY2Vzb3JpYXNQYWdlLnRzeCJ9