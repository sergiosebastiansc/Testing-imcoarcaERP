import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/leads/pages/LeadsFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/leads/pages/LeadsFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { leadsModuleConfig } from "/src/features/leads/leads.config.tsx";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
export const LeadsFormPage = ({ mode, initialData, onSave, loading, error }) => {
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando..." }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsFormPage.tsx",
    lineNumber: 34,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsFormPage.tsx",
    lineNumber: 35,
    columnNumber: 21
  }, this);
  const handleSaveWithValidation = (data) => {
    if (!data.cuit || data.cuit.trim() === "") {
      toast.error("El CUIT es obligatorio");
      return;
    }
    const hasEmail = data.email && data.email.trim() !== "";
    const hasWhatsapp = data.whatsapp && data.whatsapp.trim() !== "";
    if (!hasEmail && !hasWhatsapp) {
      toast.error("Debe ingresar al menos un Email o un WhatsApp");
      return;
    }
    onSave(data);
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      mode,
      config: leadsModuleConfig,
      initialData,
      onSave: handleSaveWithValidation,
      loading
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/leads/pages/LeadsFormPage.tsx",
      lineNumber: 59,
      columnNumber: 5
    },
    this
  );
};
_c = LeadsFormPage;
var _c;
$RefreshReg$(_c, "LeadsFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/leads/pages/LeadsFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/leads/pages/LeadsFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY3dCOzs7Ozs7Ozs7Ozs7Ozs7O0FBZHhCLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MseUJBQW9DO0FBQzdDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxhQUFhO0FBVWYsYUFBTUMsZ0JBQThDQSxDQUFDLEVBQUVDLE1BQU1DLGFBQWFDLFFBQVFDLFNBQVNDLE1BQU0sTUFBTTtBQUMxRyxNQUFJRCxRQUFTLFFBQU8sdUJBQUMsU0FBSSwyQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWdCO0FBQ3BDLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUd2RCxRQUFNQywyQkFBMkJBLENBQUNDLFNBQWU7QUFFN0MsUUFBSSxDQUFDQSxLQUFLQyxRQUFRRCxLQUFLQyxLQUFLQyxLQUFLLE1BQU0sSUFBSTtBQUN2Q1YsWUFBTU0sTUFBTSx3QkFBd0I7QUFDcEM7QUFBQSxJQUNKO0FBR0EsVUFBTUssV0FBV0gsS0FBS0ksU0FBU0osS0FBS0ksTUFBTUYsS0FBSyxNQUFNO0FBQ3JELFVBQU1HLGNBQWNMLEtBQUtNLFlBQVlOLEtBQUtNLFNBQVNKLEtBQUssTUFBTTtBQUU5RCxRQUFJLENBQUNDLFlBQVksQ0FBQ0UsYUFBYTtBQUMzQmIsWUFBTU0sTUFBTSwrQ0FBK0M7QUFDM0Q7QUFBQSxJQUNKO0FBR0FGLFdBQU9JLElBQUk7QUFBQSxFQUNmO0FBRUEsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0c7QUFBQSxNQUNBLFFBQVFWO0FBQUFBLE1BQ1I7QUFBQSxNQUNBLFFBQVFTO0FBQUFBLE1BQ1I7QUFBQTtBQUFBLElBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS3FCO0FBRzdCO0FBQUVRLEtBbENXZDtBQUEyQyxJQUFBYztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJsZWFkc01vZHVsZUNvbmZpZyIsIkdlbmVyaWNGb3JtUGFnZSIsInRvYXN0IiwiTGVhZHNGb3JtUGFnZSIsIm1vZGUiLCJpbml0aWFsRGF0YSIsIm9uU2F2ZSIsImxvYWRpbmciLCJlcnJvciIsImhhbmRsZVNhdmVXaXRoVmFsaWRhdGlvbiIsImRhdGEiLCJjdWl0IiwidHJpbSIsImhhc0VtYWlsIiwiZW1haWwiLCJoYXNXaGF0c2FwcCIsIndoYXRzYXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZHNGb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGxlYWRzTW9kdWxlQ29uZmlnLCB0eXBlIExlYWQgfSBmcm9tICcuLi9sZWFkcy5jb25maWcnO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuXG5pbnRlcmZhY2UgTGVhZHNGb3JtUGFnZVByb3BzIHtcbiAgICBtb2RlOiAnY3JlYXRlJyB8ICdlZGl0JztcbiAgICBpbml0aWFsRGF0YT86IExlYWQ7XG4gICAgb25TYXZlOiAoZGF0YTogTGVhZCkgPT4gdm9pZDtcbiAgICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgICBlcnJvcj86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBjb25zdCBMZWFkc0Zvcm1QYWdlOiBSZWFjdC5GQzxMZWFkc0Zvcm1QYWdlUHJvcHM+ID0gKHsgbW9kZSwgaW5pdGlhbERhdGEsIG9uU2F2ZSwgbG9hZGluZywgZXJyb3IgfSkgPT4ge1xuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kby4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICAvLyBWYWxpZGFjacOzbiBwZXJzb25hbGl6YWRhIGFudGVzIGRlIGd1YXJkYXJcbiAgICBjb25zdCBoYW5kbGVTYXZlV2l0aFZhbGlkYXRpb24gPSAoZGF0YTogTGVhZCkgPT4ge1xuICAgICAgICAvLyBWYWxpZGFyIENVSVQgb2JsaWdhdG9yaW9cbiAgICAgICAgaWYgKCFkYXRhLmN1aXQgfHwgZGF0YS5jdWl0LnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBDVUlUIGVzIG9ibGlnYXRvcmlvJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBWYWxpZGFyIHF1ZSBlbWFpbCBPIHdoYXRzYXBwIGVzdMOpbiBwcmVzZW50ZXNcbiAgICAgICAgY29uc3QgaGFzRW1haWwgPSBkYXRhLmVtYWlsICYmIGRhdGEuZW1haWwudHJpbSgpICE9PSAnJztcbiAgICAgICAgY29uc3QgaGFzV2hhdHNhcHAgPSBkYXRhLndoYXRzYXBwICYmIGRhdGEud2hhdHNhcHAudHJpbSgpICE9PSAnJztcblxuICAgICAgICBpZiAoIWhhc0VtYWlsICYmICFoYXNXaGF0c2FwcCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0RlYmUgaW5ncmVzYXIgYWwgbWVub3MgdW4gRW1haWwgbyB1biBXaGF0c0FwcCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gU2kgcGFzYSB0b2RhcyBsYXMgdmFsaWRhY2lvbmVzLCBndWFyZGFyXG4gICAgICAgIG9uU2F2ZShkYXRhKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgbW9kZT17bW9kZX1cbiAgICAgICAgICAgIGNvbmZpZz17bGVhZHNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbERhdGF9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmVXaXRoVmFsaWRhdGlvbn1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9sZWFkcy9wYWdlcy9MZWFkc0Zvcm1QYWdlLnRzeCJ9