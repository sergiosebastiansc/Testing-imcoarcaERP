import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/usuarios/pages/UsuariosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/usuarios/pages/UsuariosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { usuariosModuleConfig } from "/src/features/usuarios/usuarios.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const UsuarioDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: usuario, loading, error } = useCrudItem(usuariosModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del usuario..." }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  if (!usuario) return /* @__PURE__ */ jsxDEV("div", { children: "Usuario no encontrado." }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 24
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: usuariosModuleConfig, item: usuario }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosDetailPage.tsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(UsuarioDetailPage, "zE7sgRYGK2RsRygVx7v+dmUm+zU=", false, function() {
  return [useParams, useCrudItem];
});
_c = UsuarioDetailPage;
var _c;
$RefreshReg$(_c, "UsuarioDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/usuarios/pages/UsuariosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/usuarios/pages/UsuariosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDRCQUEwQztBQUNuRCxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBRXpDLFFBQU0sRUFBRU8sTUFBTUMsU0FBU0MsU0FBU0MsTUFBTSxJQUFJUCxZQUFxQkQsc0JBQXNCSSxFQUFFO0FBRXZGLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLCtDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0M7QUFDeEQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsUUFBUyxRQUFPLHVCQUFDLFNBQUksc0NBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQjtBQUVoRCxTQUFPLHVCQUFDLHFCQUFrQixRQUFRTixzQkFBc0IsTUFBTU0sV0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErRDtBQUMxRTtBQUFFSCxHQVZXRCxtQkFBaUI7QUFBQSxVQUNYSixXQUUyQkcsV0FBVztBQUFBO0FBQUFRLEtBSDVDUDtBQUFpQixJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwiR2VuZXJpY0RldGFpbFBhZ2UiLCJ1c3Vhcmlvc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwiVXN1YXJpb0RldGFpbFBhZ2UiLCJfcyIsImlkIiwiaXRlbSIsInVzdWFyaW8iLCJsb2FkaW5nIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc3Vhcmlvc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3VhcmlvRGV0YWlsUGFnZS50c3hcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyB1c3Vhcmlvc01vZHVsZUNvbmZpZywgdHlwZSBVc3VhcmlvIH0gZnJvbSAnLi4vdXN1YXJpb3MuY29uZmlnLnRzeCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcblxuZXhwb3J0IGNvbnN0IFVzdWFyaW9EZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICAvLyBSZWVtcGxhemFtb3MgbGEgYsO6c3F1ZWRhIG1hbnVhbCBjb24gbnVlc3RybyBob29rIHVzZUNydWRJdGVtXG4gICAgY29uc3QgeyBpdGVtOiB1c3VhcmlvLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08VXN1YXJpbz4odXN1YXJpb3NNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkZXRhbGxlIGRlbCB1c3VhcmlvLi4uPC9kaXY+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIXVzdWFyaW8pIHJldHVybiA8ZGl2PlVzdWFyaW8gbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gPEdlbmVyaWNEZXRhaWxQYWdlIGNvbmZpZz17dXN1YXJpb3NNb2R1bGVDb25maWd9IGl0ZW09e3VzdWFyaW99IC8+O1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3VzdWFyaW9zL3BhZ2VzL1VzdWFyaW9zRGV0YWlsUGFnZS50c3gifQ==