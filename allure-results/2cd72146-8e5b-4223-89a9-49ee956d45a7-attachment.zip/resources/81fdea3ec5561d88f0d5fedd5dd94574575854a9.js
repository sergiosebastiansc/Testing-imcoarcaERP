import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, getAll, searchByField } from "/src/services/apiService.ts";
import { notasCreditoCompraModuleConfig } from "/src/features/notas_credito_compra/notas_credito_compra.config.tsx";
import { comprasModuleConfig } from "/src/features/compras/compras.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const defaultInitial = {
  series: "B",
  purchase_id: 0,
  vendor_id: 0,
  vendor_name: "",
  vendor_code: "",
  currency_id: 1,
  issue_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  total_amount: 0,
  exchange_rate: 1,
  discount_percentage: 0,
  status: "DRAFT",
  rejection_reason: null,
  notes: null,
  has_item_level_taxes: false,
  items: [],
  taxes: [],
  withouttax_amount: 0
};
function calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes) {
  if (!vendorTaxes || vendorTaxes.length === 0) return [];
  const taxBase = Math.max(0, subtotal - withouttax_amount);
  return vendorTaxes.map((tax) => ({
    tax_id: tax.id,
    tax_name: tax.name,
    rate: tax.rate,
    amount: taxBase * (Number(tax.rate) / 100)
  }));
}
export const NotasCreditoCompraFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData } = useCrudItem(notasCreditoCompraModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(notasCreditoCompraModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitial);
  const [items, setItems] = useState([]);
  const [vendorTaxes, setVendorTaxes] = useState([]);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [perceptionRows, setPerceptionRows] = useState([]);
  const [perceptionTaxes, setPerceptionTaxes] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const [purchaseCodeInput, setPurchaseCodeInput] = useState("");
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      setFormData({
        ...defaultInitial,
        ...loadedData,
        vendor_name: loadedData.vendor_name ?? void 0,
        vendor_code: loadedData.vendor_code ?? void 0
      });
      setItems((loadedData.items || []).map((i) => ({ ...i, tempId: crypto.randomUUID() })));
      setPurchaseCodeInput(loadedData.purchase?.internal_voucher ?? String(loadedData.purchase_id ?? ""));
      if (loadedData.vendor_id) {
        getById(proveedoresModuleConfig.endpoint, loadedData.vendor_id).then((v) => setVendorTaxes(v.relatedTaxes || [])).catch(() => setVendorTaxes([]));
      }
      if (loadedData.taxes && Array.isArray(loadedData.taxes) && loadedData.taxes.length > 0) {
        const type1 = loadedData.taxes.filter((t) => t.tax_type !== 2);
        const type2 = loadedData.taxes.filter((t) => t.tax_type === 2);
        setAppliedTaxes(type1.map((t) => ({
          tax_id: t.tax_id,
          tax_name: t.tax_name,
          rate: t.rate,
          amount: Number(t.amount) || 0
        })));
        setPerceptionRows(type2.map((t) => ({
          tempId: crypto.randomUUID(),
          tax_id: t.tax_id,
          tax_name: t.tax_name ?? null,
          amount: Number(t.amount) || 0
        })));
      }
    }
  }, [mode, loadedData]);
  useEffect(() => {
    if (id) return;
    if (vendorTaxes.length === 0) {
      setAppliedTaxes([]);
      return;
    }
    if (vendorTaxes.length > 1) {
      setAppliedTaxes(vendorTaxes.map((t) => ({
        tax_id: t.id,
        tax_name: t.name,
        rate: t.rate,
        amount: 0
      })));
    }
  }, [id, vendorTaxes]);
  useEffect(() => {
    getAll("taxes", { type: "2" }).then((res) => setPerceptionTaxes(res.data || [])).catch(() => setPerceptionTaxes([]));
  }, []);
  useEffect(() => {
    if (id || vendorTaxes.length !== 1) return;
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const withouttax_amount = formData.withouttax_amount ?? 0;
    const calculated = calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes);
    setAppliedTaxes(calculated);
  }, [id, items, formData.withouttax_amount, vendorTaxes]);
  const handleUpdateAppliedTaxAmount = (tax_id, amount) => {
    setAppliedTaxes((prev) => prev.map((t) => t.tax_id === tax_id ? { ...t, amount } : t));
  };
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const totalTaxes = appliedTaxes.reduce((s, t) => s + (Number(t.amount) || 0), 0);
    const percepcionesTotal = perceptionRows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
    const total = subtotal + totalTaxes + percepcionesTotal;
    return { subtotal, totalTaxes, percepcionesTotal, total, withouttax_amount: formData.withouttax_amount ?? 0 };
  }, [items, appliedTaxes, perceptionRows, formData.withouttax_amount]);
  const aggregatedTaxes = useMemo(() => {
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const withouttax_amount = formData.withouttax_amount ?? 0;
    if (vendorTaxes.length === 1) {
      const applied = calculateNoteLevelTaxes(subtotal, withouttax_amount, vendorTaxes);
      return applied.map((t) => ({ tax_name: t.tax_name, rate: t.rate, amount: Number(t.amount), tax_id: t.tax_id }));
    }
    return appliedTaxes.map((t) => ({ tax_name: t.tax_name, rate: t.rate, amount: Number(t.amount), tax_id: t.tax_id }));
  }, [items, formData.withouttax_amount, vendorTaxes, appliedTaxes]);
  const clearForm = () => {
    setFormData({ ...defaultInitial });
    setItems([]);
    setVendorTaxes([]);
    setAppliedTaxes([]);
    setPerceptionRows([]);
    setPurchaseCodeInput("");
  };
  const handleVendorSelected = async (vendor) => {
    setLoading(true);
    try {
      const full = await getById(proveedoresModuleConfig.endpoint, vendor.id);
      const taxes = full.relatedTaxes || [];
      setVendorTaxes(taxes);
      setFormData((prev) => ({
        ...prev,
        vendor_id: full.id,
        vendor_name: full.name || "",
        vendor_code: full.vendor_code || "",
        purchase_id: 0,
        purchase: void 0,
        series: full.serie ?? prev?.series ?? "B",
        currency_id: prev?.currency_id ?? 1,
        exchange_rate: prev?.exchange_rate ?? 1
      }));
      setItems([]);
      setPurchaseCodeInput("");
      toast.success("Proveedor seleccionado. Elija la compra.");
    } catch (err) {
      console.error(err);
      toast.error("Error al cargar el proveedor.");
    } finally {
      setLoading(false);
    }
  };
  const handleVendorCodeSubmit = async () => {
    const code = formData.vendor_code?.trim();
    if (!code) {
      toast.info("Ingrese el código del proveedor.");
      return;
    }
    setLoading(true);
    try {
      const found = await searchByField(proveedoresModuleConfig.endpoint, [{ fieldName: "vendor_code", value: code }]);
      if (found) {
        await handleVendorSelected(found);
      } else {
        toast.error(`No se encontró proveedor con código "${code}".`);
      }
    } catch (e) {
      console.error(e);
      toast.error("Error al buscar proveedor.");
    } finally {
      setLoading(false);
    }
  };
  const handlePurchaseSelected = async (purchase) => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione primero un proveedor.");
      return;
    }
    setLoading(true);
    try {
      const full = await getById(comprasModuleConfig.endpoint, purchase.id);
      if (full.vendor_id !== formData.vendor_id) {
        toast.error("La compra no pertenece al proveedor seleccionado.");
        setLoading(false);
        return;
      }
      const vendorName = full.vendor?.name || full.vendor_name || "";
      setFormData((prev) => ({
        ...prev,
        purchase_id: full.id,
        purchase: { id: full.id, internal_voucher: full.internal_voucher || String(full.id), purchase_date: full.purchase_date },
        vendor_id: full.vendor_id,
        vendor_name: vendorName,
        series: full.series || prev?.series || "B",
        currency_id: full.currency_id ?? prev?.currency_id ?? 1,
        exchange_rate: full.exchange_rate ?? 1,
        has_item_level_taxes: false
      }));
      const products = full.products || [];
      const newItems = products.map((p, idx) => ({
        product_id: p.product_id,
        product_code: p.product_code,
        product_name: p.product_name,
        line_number: idx + 1,
        quantity: p.quantity,
        unit_price: p.price_cost,
        cost_price: p.price_cost,
        discount_percentage: 0,
        taxes: [],
        tempId: crypto.randomUUID()
      }));
      setItems(newItems);
      setPurchaseCodeInput(full.internal_voucher || String(full.id));
      toast.success("Compra cargada. Revise los ítems e impuestos.");
    } catch (err) {
      console.error(err);
      toast.error("Error al cargar la compra.");
    } finally {
      setLoading(false);
    }
  };
  const handlePurchaseCodeSubmit = async () => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione primero un proveedor.");
      return;
    }
    const code = purchaseCodeInput.trim();
    if (!code) {
      toast.info("Ingrese el número de la compra.");
      return;
    }
    setLoading(true);
    try {
      const found = await searchByField(comprasModuleConfig.endpoint, [{ fieldName: "internal_voucher", value: code }]);
      if (found) {
        await handlePurchaseSelected(found);
      } else {
        toast.error("No se encontró una compra con ese número.");
      }
    } catch (e) {
      console.error(e);
      toast.error("Error al buscar la compra.");
    } finally {
      setLoading(false);
    }
  };
  const handleSelectFromModal = (selected) => {
    if (editingTarget === "vendor") {
      handleVendorSelected(selected);
    } else {
      handlePurchaseSelected(selected);
    }
    setEditingTarget(null);
    setIsModalOpen(false);
  };
  const handleItemChange = (index, field, value) => {
    setItems((prev) => prev.map((item, i) => i === index ? { ...item, [field]: value } : item));
  };
  const handleRemoveItem = (index) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };
  const handleSave = async () => {
    if (!formData.vendor_id) {
      toast.warn("Seleccione un proveedor.");
      return;
    }
    if (!formData.purchase_id) {
      toast.warn("Seleccione una compra.");
      return;
    }
    if (!formData.series) {
      toast.warn("La serie es obligatoria.");
      return;
    }
    if (items.length === 0) {
      toast.warn("Debe haber al menos un ítem.");
      return;
    }
    const taxesType1 = appliedTaxes.filter((t) => Number(t.amount) > 0).map((t) => ({ ...t, tax_type: 1 }));
    const taxesType2 = perceptionRows.filter((r) => r.tax_id != null && Number(r.amount) > 0).map((r) => ({
      tax_id: r.tax_id,
      tax_name: r.tax_name ?? void 0,
      rate: 0,
      amount: r.amount,
      tax_type: 2
    }));
    const payload = {
      ...formData,
      series: formData.series || "B",
      purchase_id: formData.purchase_id,
      vendor_id: formData.vendor_id,
      vendor_code: formData.vendor_code ?? void 0,
      currency_id: formData.currency_id ?? 1,
      issue_date: formData.issue_date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      total_amount: calculatedTotals.total,
      exchange_rate: formData.exchange_rate ?? 1,
      discount_percentage: formData.discount_percentage ?? 0,
      status: formData.status || "DRAFT",
      rejection_reason: formData.rejection_reason ?? null,
      notes: formData.notes ?? null,
      has_item_level_taxes: false,
      withouttax_amount: formData.withouttax_amount ?? 0,
      items: items.map(({ tempId, ...rest }) => ({ ...rest, taxes: rest.taxes ?? [] })),
      taxes: [...taxesType1, ...taxesType2]
    };
    try {
      await saveItem(payload);
      toast.success("Nota de Crédito (Compra) guardada.");
      navigate(getListReturnPath(notasCreditoCompraModuleConfig.baseRoute));
    } catch (e) {
      toast.error("Error al guardar.");
    }
  };
  if (loadingData) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
    lineNumber: 404,
    columnNumber: 27
  }, this);
  const inputStyle = "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm focus:ring-indigo-500 focus:border-indigo-500";
  const purchaseModalConfig = formData.vendor_id ? { ...comprasModuleConfig, initialFilters: { vendor_id: formData.vendor_id } } : comprasModuleConfig;
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6 relative", children: [
    (isLoading || saving) && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px]", children: [
      /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-8 h-8 text-indigo-600 animate-spin mb-2" }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 416,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Procesando..." }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 417,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 415,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Nueva Nota de Crédito (Compra)" : `Editar Nota ${formData.voucher_number || id}` }, void 0, false, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 421,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Proveedor (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 427,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: formData.vendor_code || "",
            nameValue: formData.vendor_name || null,
            onCodeChange: (c) => setFormData((prev) => ({ ...prev, vendor_code: c || "" })),
            onCodeSubmit: handleVendorCodeSubmit,
            onSearchClick: () => {
              setModalConfig(proveedoresModuleConfig);
              setEditingTarget("vendor");
              setIsModalOpen(true);
            },
            onClearClick: clearForm
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 428,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 426,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 438,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: formData.series || "B",
            onChange: (e) => setFormData((prev) => ({ ...prev, series: e.target.value })),
            className: inputStyle,
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A" }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 444,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B" }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 445,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C" }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 446,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "X", children: "X" }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 447,
                columnNumber: 25
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 439,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 437,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Factura (*)" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 451,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: purchaseCodeInput,
            nameValue: formData.purchase_id ? formData.purchase?.internal_voucher ?? `Compra #${formData.purchase_id}` : null,
            onCodeChange: (c) => setPurchaseCodeInput(c ?? ""),
            onCodeSubmit: handlePurchaseCodeSubmit,
            onSearchClick: () => {
              setModalConfig(purchaseModalConfig);
              setEditingTarget("purchase");
              setIsModalOpen(true);
            },
            onClearClick: () => {
              setFormData((prev) => ({ ...prev, purchase_id: 0, purchase: void 0 }));
              setItems([]);
              setPurchaseCodeInput("");
            },
            disabled: !formData.vendor_id
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 452,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 450,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 463,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: formData.issue_date || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, issue_date: e.target.value })),
            className: inputStyle,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 464,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 462,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Motivo rechazo" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 471,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: formData.rejection_reason || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, rejection_reason: e.target.value || null })),
            className: inputStyle,
            placeholder: "Opcional",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 472,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 470,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 480,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 2,
            value: formData.notes || "",
            onChange: (e) => setFormData((prev) => ({ ...prev, notes: e.target.value || null })),
            className: inputStyle,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 481,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 479,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 425,
      columnNumber: 13
    }, this),
    items.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-4", children: "Ítems" }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 491,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 496,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 497,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 498,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 499,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase hidden", children: "Acción" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 500,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 495,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 494,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
          const lineSub = Number(item.quantity) * Number(item.unit_price);
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-gray-900", children: [
              item.product_name,
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 509,
                columnNumber: 69
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 508,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                min: 0,
                value: item.quantity,
                onChange: (num) => handleItemChange(index, "quantity", num),
                className: "w-20 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 512,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 511,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                step: "0.01",
                value: item.unit_price,
                onChange: (num) => handleItemChange(index, "unit_price", num),
                className: "w-24 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 520,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 519,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-medium", children: formatValue(lineSub, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 527,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-center hidden", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveItem(index), className: "p-1 text-red-600 hover:text-red-900", children: "Eliminar" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 529,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 528,
              columnNumber: 45
            }, this)
          ] }, item.tempId, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 507,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 503,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 493,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 492,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 490,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-800", children: "Impuestos aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 542,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid grid-cols-3 items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 col-span-2", children: "Valor No Gravado (no gravado)" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 544,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              step: "0.01",
              value: formData.withouttax_amount,
              onChange: (num) => setFormData((prev) => ({ ...prev, withouttax_amount: num ?? 0 })),
              className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
              placeholder: "0"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 545,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 543,
          columnNumber: 21
        }, this),
        aggregatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 558,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 559,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 560,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 557,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 556,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: aggregatedTaxes.map(
            (tax, idx) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 566,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: tax.rate }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 567,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: vendorTaxes.length > 1 && typeof tax.tax_id === "number" ? /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: tax.amount,
                  onChange: (num) => handleUpdateAppliedTaxAmount(tax.tax_id, num ?? 0),
                  className: "w-24 px-2 py-1 text-right border border-gray-300 rounded text-sm"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                  lineNumber: 570,
                  columnNumber: 21
                },
                this
              ) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 577,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 568,
                columnNumber: 45
              }, this)
            ] }, tax.tax_id ?? idx, true, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 565,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 563,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 555,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 554,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-gray-500", children: "No hay impuestos aplicados." }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 586,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 mt-4 border-t border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium text-gray-800 mb-2", children: "Percepciones" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 589,
            columnNumber: 25
          }, this),
          perceptionTaxes.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No hay percepciones configuradas." }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 591,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: perceptionRows.map(
              (row) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: row.tax_id ?? "",
                    onChange: (e) => {
                      const val = e.target.value;
                      if (!val) {
                        setPerceptionRows((prev) => prev.map((r) => r.tempId === row.tempId ? { ...r, tax_id: null, tax_name: null } : r));
                        return;
                      }
                      const tax = perceptionTaxes.find((t) => t.id === Number(val));
                      if (!tax) return;
                      const alreadyUsed = perceptionRows.some((r) => r.tempId !== row.tempId && r.tax_id === tax.id);
                      if (alreadyUsed) {
                        toast.warn("Esa percepción ya está en la lista. No se puede repetir.");
                        return;
                      }
                      setPerceptionRows((prev) => prev.map(
                        (r) => r.tempId === row.tempId ? { ...r, tax_id: tax.id, tax_name: tax.name } : r
                      ));
                    },
                    className: "col-span-2 w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm sm:text-sm",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccione percepción" }, void 0, false, {
                        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                        lineNumber: 618,
                        columnNumber: 49
                      }, this),
                      perceptionTaxes.map(
                        (tax) => /* @__PURE__ */ jsxDEV("option", { value: tax.id, disabled: perceptionRows.some((r) => r.tempId !== row.tempId && r.tax_id === tax.id), children: tax.name }, tax.id, false, {
                          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                          lineNumber: 620,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                    lineNumber: 597,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    DecimalInput,
                    {
                      value: row.amount,
                      onChange: (num) => setPerceptionRows((prev) => prev.map(
                        (r) => r.tempId === row.tempId ? { ...r, amount: num ?? 0 } : r
                      )),
                      className: "w-full px-2 py-1 text-right border border-gray-300 rounded-md shadow-sm sm:text-sm",
                      placeholder: "0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                      lineNumber: 626,
                      columnNumber: 49
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setPerceptionRows((prev) => prev.filter((r) => r.tempId !== row.tempId)),
                      className: "text-red-500 hover:text-red-700 p-1",
                      title: "Quitar",
                      children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                        lineNumber: 640,
                        columnNumber: 53
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                      lineNumber: 634,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                  lineNumber: 625,
                  columnNumber: 45
                }, this)
              ] }, row.tempId, true, {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 596,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
              lineNumber: 594,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setPerceptionRows((prev) => [...prev, { tempId: crypto.randomUUID(), tax_id: null, tax_name: null, amount: 0 }]),
                className: "inline-flex items-center px-3 py-2 mt-2 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700",
                children: [
                  /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
                    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                    lineNumber: 651,
                    columnNumber: 37
                  }, this),
                  " Agregar percepción"
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
                lineNumber: 646,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 593,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 588,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 541,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 658,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 658,
            columnNumber: 115
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 658,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-gray-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Valor No Gravado (no gravado):" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 659,
            columnNumber: 81
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(calculatedTotals.withouttax_amount ?? 0, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 659,
            columnNumber: 124
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 659,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Impuestos:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 660,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: [
            "+ ",
            formatValue(calculatedTotals.totalTaxes, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 660,
            columnNumber: 116
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 660,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Percepciones:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 661,
            columnNumber: 67
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: [
            "+ ",
            formatValue(calculatedTotals.percepcionesTotal, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 661,
            columnNumber: 119
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 661,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900", children: "Total:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 662,
            columnNumber: 78
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-indigo-600", children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
            lineNumber: 662,
            columnNumber: 133
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 662,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 657,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 540,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(notasCreditoCompraModuleConfig.baseRoute)), className: "px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 667,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: isLoading || saving || items.length === 0, className: "inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50", children: [
        /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2" }, void 0, false, {
          fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
          lineNumber: 669,
          columnNumber: 21
        }, this),
        " Guardar"
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
        lineNumber: 668,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 666,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => {
      setIsModalOpen(false);
      setEditingTarget(null);
    }, onSelect: handleSelectFromModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
      lineNumber: 674,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx",
    lineNumber: 413,
    columnNumber: 5
  }, this);
};
_s(NotasCreditoCompraFormPage, "laHC6utpIZmL4Pmq9vWweRVsjRU=", false, function() {
  return [useParams, useNavigate, useCrudItem, useCrudItem];
});
_c = NotasCreditoCompraFormPage;
var _c;
$RefreshReg$(_c, "NotasCreditoCompraFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1k0QixTQTZMQSxVQTdMQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvWDVCLFNBQVNBLFVBQVVDLFdBQVdDLGVBQWU7QUFDN0MsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsV0FBV0MsUUFBUUMsZUFBZTtBQUNuRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBU0MsUUFBUUMscUJBQXFCO0FBQy9DLFNBQVNDLHNDQUE0RjtBQUNyRyxTQUFTQywyQkFBMkI7QUFFcEMsU0FBU0MsK0JBQStDO0FBQ3hELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFJNUIsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLGlCQUE4QztBQUFBLEVBQ2hEQyxRQUFRO0FBQUEsRUFDUkMsYUFBYTtBQUFBLEVBQ2JDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQUEsRUFDYkMsYUFBYTtBQUFBLEVBQ2JDLGFBQWE7QUFBQSxFQUNiQyxhQUFZLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pEQyxjQUFjO0FBQUEsRUFDZEMsZUFBZTtBQUFBLEVBQ2ZDLHFCQUFxQjtBQUFBLEVBQ3JCQyxRQUFRO0FBQUEsRUFDUkMsa0JBQWtCO0FBQUEsRUFDbEJDLE9BQU87QUFBQSxFQUNQQyxzQkFBc0I7QUFBQSxFQUN0QkMsT0FBTztBQUFBLEVBQ1BDLE9BQU87QUFBQSxFQUNQQyxtQkFBbUI7QUFDdkI7QUFXQSxTQUFTQyx3QkFBd0JDLFVBQWtCRixtQkFBMkJHLGFBQXlDO0FBQ25ILE1BQUksQ0FBQ0EsZUFBZUEsWUFBWUMsV0FBVyxFQUFHLFFBQU87QUFDckQsUUFBTUMsVUFBVUMsS0FBS0MsSUFBSSxHQUFHTCxXQUFXRixpQkFBaUI7QUFDeEQsU0FBT0csWUFBWUssSUFBSSxDQUFBQyxTQUFRO0FBQUEsSUFDM0JDLFFBQVFELElBQUlFO0FBQUFBLElBQ1pDLFVBQVVILElBQUlJO0FBQUFBLElBQ2RDLE1BQU1MLElBQUlLO0FBQUFBLElBQ1ZDLFFBQVFWLFdBQVdXLE9BQU9QLElBQUlLLElBQUksSUFBSTtBQUFBLEVBQzFDLEVBQUU7QUFDTjtBQUVPLGFBQU1HLDZCQUE2QkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVDLFFBQU0sRUFBRVAsR0FBRyxJQUFJbEQsVUFBMEI7QUFDekMsUUFBTTBELFdBQVczRCxZQUFZO0FBQzdCLFFBQU00RCxPQUFPVCxLQUFLLFNBQVM7QUFFM0IsUUFBTSxFQUFFVSxNQUFNQyxZQUFZQyxTQUFTQyxZQUFZLElBQUl6RCxZQUFnQ0ksZ0NBQWdDd0MsRUFBRTtBQUNySCxRQUFNLEVBQUVjLFVBQVVGLFNBQVNHLE9BQU8sSUFBSTNELFlBQWdDSSxnQ0FBZ0N3QyxFQUFFO0FBRXhHLFFBQU0sQ0FBQ2dCLFVBQVVDLFdBQVcsSUFBSXZFLFNBQXNDdUIsY0FBYztBQUNwRixRQUFNLENBQUNrQixPQUFPK0IsUUFBUSxJQUFJeEUsU0FBcUIsRUFBRTtBQUNqRCxRQUFNLENBQUM4QyxhQUFhMkIsY0FBYyxJQUFJekUsU0FBdUIsRUFBRTtBQUMvRCxRQUFNLENBQUMwRSxjQUFjQyxlQUFlLElBQUkzRSxTQUF1QixFQUFFO0FBQ2pFLFFBQU0sQ0FBQzRFLGdCQUFnQkMsaUJBQWlCLElBQUk3RSxTQUEwQixFQUFFO0FBQ3hFLFFBQU0sQ0FBQzhFLGlCQUFpQkMsa0JBQWtCLElBQUkvRSxTQUFnQixFQUFFO0FBQ2hFLFFBQU0sQ0FBQ2dGLFdBQVdDLFVBQVUsSUFBSWpGLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNrRixhQUFhQyxjQUFjLElBQUluRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDb0YsYUFBYUMsY0FBYyxJQUFJckYsU0FBbUMsSUFBSTtBQUM3RSxRQUFNLENBQUNzRixlQUFlQyxnQkFBZ0IsSUFBSXZGLFNBQXVDLElBQUk7QUFDckYsUUFBTSxDQUFDd0YsbUJBQW1CQyxvQkFBb0IsSUFBSXpGLFNBQVMsRUFBRTtBQUU3REMsWUFBVSxNQUFNO0FBQ1osUUFBSThELFNBQVMsVUFBVUUsWUFBWTtBQUMvQk0sa0JBQVk7QUFBQSxRQUNSLEdBQUdoRDtBQUFBQSxRQUNILEdBQUcwQztBQUFBQSxRQUNIdEMsYUFBYXNDLFdBQVd0QyxlQUFlK0Q7QUFBQUEsUUFDdkM5RCxhQUFhcUMsV0FBV3JDLGVBQWU4RDtBQUFBQSxNQUMzQyxDQUFDO0FBQ0RsQixnQkFBVVAsV0FBV3hCLFNBQVMsSUFBSVUsSUFBSSxDQUFBd0MsT0FBTSxFQUFFLEdBQUdBLEdBQUdDLFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxFQUFFLENBQUM7QUFDbkZMLDJCQUFxQnhCLFdBQVc4QixVQUFVQyxvQkFBb0JDLE9BQU9oQyxXQUFXeEMsZUFBZSxFQUFFLENBQUM7QUFDbEcsVUFBSXdDLFdBQVd2QyxXQUFXO0FBQ3RCZixnQkFBbUJLLHdCQUF3QmtGLFVBQVVqQyxXQUFXdkMsU0FBUyxFQUNwRXlFLEtBQUssQ0FBQUMsTUFBSzNCLGVBQWUyQixFQUFFQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQzlDQyxNQUFNLE1BQU03QixlQUFlLEVBQUUsQ0FBQztBQUFBLE1BQ3ZDO0FBQ0EsVUFBSVIsV0FBV3ZCLFNBQVM2RCxNQUFNQyxRQUFRdkMsV0FBV3ZCLEtBQUssS0FBS3VCLFdBQVd2QixNQUFNSyxTQUFTLEdBQUc7QUFDcEYsY0FBTTBELFFBQVN4QyxXQUFXdkIsTUFBaURnRSxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLGFBQWEsQ0FBQztBQUN2RyxjQUFNQyxRQUFTNUMsV0FBV3ZCLE1BQWlEZ0UsT0FBTyxDQUFBQyxNQUFLQSxFQUFFQyxhQUFhLENBQUM7QUFFdkdqQyx3QkFBZ0I4QixNQUFNdEQsSUFBSSxDQUFDd0QsT0FBTztBQUFBLFVBQzlCdEQsUUFBUXNELEVBQUV0RDtBQUFBQSxVQUNWRSxVQUFVb0QsRUFBRXBEO0FBQUFBLFVBQ1pFLE1BQU1rRCxFQUFFbEQ7QUFBQUEsVUFDUkMsUUFBUUMsT0FBT2dELEVBQUVqRCxNQUFNLEtBQUs7QUFBQSxRQUNoQyxFQUFFLENBQUM7QUFFSG1CLDBCQUFrQmdDLE1BQU0xRCxJQUFJLENBQUN3RCxPQUFPO0FBQUEsVUFDaENmLFFBQVFDLE9BQU9DLFdBQVc7QUFBQSxVQUMxQnpDLFFBQVFzRCxFQUFFdEQ7QUFBQUEsVUFDVkUsVUFBVW9ELEVBQUVwRCxZQUFZO0FBQUEsVUFDeEJHLFFBQVFDLE9BQU9nRCxFQUFFakQsTUFBTSxLQUFLO0FBQUEsUUFDaEMsRUFBRSxDQUFDO0FBQUEsTUFDUDtBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsQ0FBQ0ssTUFBTUUsVUFBVSxDQUFDO0FBRXJCaEUsWUFBVSxNQUFNO0FBQ1osUUFBSXFELEdBQUk7QUFDUixRQUFJUixZQUFZQyxXQUFXLEdBQUc7QUFDMUI0QixzQkFBZ0IsRUFBRTtBQUNsQjtBQUFBLElBQ0o7QUFDQSxRQUFJN0IsWUFBWUMsU0FBUyxHQUFHO0FBQ3hCNEIsc0JBQWdCN0IsWUFBWUssSUFBSSxDQUFBd0QsT0FBTTtBQUFBLFFBQ2xDdEQsUUFBUXNELEVBQUVyRDtBQUFBQSxRQUNWQyxVQUFVb0QsRUFBRW5EO0FBQUFBLFFBQ1pDLE1BQU1rRCxFQUFFbEQ7QUFBQUEsUUFDUkMsUUFBUTtBQUFBLE1BQ1osRUFBRSxDQUFDO0FBQUEsSUFDUDtBQUFBLEVBQ0osR0FBRyxDQUFDSixJQUFJUixXQUFXLENBQUM7QUFHcEI3QyxZQUFVLE1BQU07QUFDWlcsV0FBWSxTQUFTLEVBQUVrRyxNQUFNLElBQUksQ0FBQyxFQUM3QlgsS0FBSyxDQUFBWSxRQUFPaEMsbUJBQW1CZ0MsSUFBSUMsUUFBUSxFQUFFLENBQUMsRUFDOUNWLE1BQU0sTUFBTXZCLG1CQUFtQixFQUFFLENBQUM7QUFBQSxFQUMzQyxHQUFHLEVBQUU7QUFFTDlFLFlBQVUsTUFBTTtBQUNaLFFBQUlxRCxNQUFNUixZQUFZQyxXQUFXLEVBQUc7QUFDcEMsVUFBTUYsV0FBV0osTUFBTXdFLE9BQU8sQ0FBQ0MsR0FBR3ZCLE1BQU11QixJQUFJdkQsT0FBT2dDLEVBQUV3QixRQUFRLElBQUl4RCxPQUFPZ0MsRUFBRXlCLFVBQVUsR0FBRyxDQUFDO0FBQ3hGLFVBQU16RSxvQkFBb0IyQixTQUFTM0IscUJBQXFCO0FBQ3hELFVBQU0wRSxhQUFhekUsd0JBQXdCQyxVQUFVRixtQkFBbUJHLFdBQVc7QUFDbkY2QixvQkFBZ0IwQyxVQUFVO0FBQUEsRUFDOUIsR0FBRyxDQUFDL0QsSUFBSWIsT0FBTzZCLFNBQVMzQixtQkFBbUJHLFdBQVcsQ0FBQztBQUV2RCxRQUFNd0UsK0JBQStCQSxDQUFDakUsUUFBZ0JLLFdBQW1CO0FBQ3JFaUIsb0JBQWdCLENBQUE0QyxTQUFRQSxLQUFLcEUsSUFBSSxDQUFBd0QsTUFBS0EsRUFBRXRELFdBQVdBLFNBQVMsRUFBRSxHQUFHc0QsR0FBR2pELE9BQU8sSUFBSWlELENBQUMsQ0FBQztBQUFBLEVBQ3JGO0FBRUEsUUFBTWEsbUJBQW1CdEgsUUFBUSxNQUFNO0FBQ25DLFVBQU0yQyxXQUFXSixNQUFNd0UsT0FBTyxDQUFDQyxHQUFHdkIsTUFBTXVCLElBQUl2RCxPQUFPZ0MsRUFBRXdCLFFBQVEsSUFBSXhELE9BQU9nQyxFQUFFeUIsVUFBVSxHQUFHLENBQUM7QUFDeEYsVUFBTUssYUFBYS9DLGFBQWF1QyxPQUFPLENBQUNDLEdBQUdQLE1BQU1PLEtBQUt2RCxPQUFPZ0QsRUFBRWpELE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDL0UsVUFBTWdFLG9CQUFvQjlDLGVBQWVxQyxPQUFPLENBQUNDLEdBQUdTLE1BQU1ULEtBQUt2RCxPQUFPZ0UsRUFBRWpFLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDeEYsVUFBTWtFLFFBQVEvRSxXQUFXNEUsYUFBYUM7QUFDdEMsV0FBTyxFQUFFN0UsVUFBVTRFLFlBQVlDLG1CQUFtQkUsT0FBT2pGLG1CQUFtQjJCLFNBQVMzQixxQkFBcUIsRUFBRTtBQUFBLEVBQ2hILEdBQUcsQ0FBQ0YsT0FBT2lDLGNBQWNFLGdCQUFnQk4sU0FBUzNCLGlCQUFpQixDQUFDO0FBRXBFLFFBQU1rRixrQkFBa0IzSCxRQUFRLE1BQU07QUFDbEMsVUFBTTJDLFdBQVdKLE1BQU13RSxPQUFPLENBQUNDLEdBQUd2QixNQUFNdUIsSUFBSXZELE9BQU9nQyxFQUFFd0IsUUFBUSxJQUFJeEQsT0FBT2dDLEVBQUV5QixVQUFVLEdBQUcsQ0FBQztBQUN4RixVQUFNekUsb0JBQW9CMkIsU0FBUzNCLHFCQUFxQjtBQUN4RCxRQUFJRyxZQUFZQyxXQUFXLEdBQUc7QUFDMUIsWUFBTStFLFVBQVVsRix3QkFBd0JDLFVBQVVGLG1CQUFtQkcsV0FBVztBQUNoRixhQUFPZ0YsUUFBUTNFLElBQUksQ0FBQXdELE9BQU0sRUFBRXBELFVBQVVvRCxFQUFFcEQsVUFBVUUsTUFBTWtELEVBQUVsRCxNQUFNQyxRQUFRQyxPQUFPZ0QsRUFBRWpELE1BQU0sR0FBR0wsUUFBUXNELEVBQUV0RCxPQUFPLEVBQUU7QUFBQSxJQUNoSDtBQUNBLFdBQU9xQixhQUFhdkIsSUFBSSxDQUFBd0QsT0FBTSxFQUFFcEQsVUFBVW9ELEVBQUVwRCxVQUFVRSxNQUFNa0QsRUFBRWxELE1BQU1DLFFBQVFDLE9BQU9nRCxFQUFFakQsTUFBTSxHQUFHTCxRQUFRc0QsRUFBRXRELE9BQU8sRUFBRTtBQUFBLEVBQ3JILEdBQUcsQ0FBQ1osT0FBTzZCLFNBQVMzQixtQkFBbUJHLGFBQWE0QixZQUFZLENBQUM7QUFFakUsUUFBTXFELFlBQVlBLE1BQU07QUFDcEJ4RCxnQkFBWSxFQUFFLEdBQUdoRCxlQUFlLENBQUM7QUFDakNpRCxhQUFTLEVBQUU7QUFDWEMsbUJBQWUsRUFBRTtBQUNqQkUsb0JBQWdCLEVBQUU7QUFDbEJFLHNCQUFrQixFQUFFO0FBQ3BCWSx5QkFBcUIsRUFBRTtBQUFBLEVBQzNCO0FBRUEsUUFBTXVDLHVCQUF1QixPQUFPQyxXQUFzQjtBQUN0RGhELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNaUQsT0FBTyxNQUFNdkgsUUFBbUJLLHdCQUF3QmtGLFVBQVUrQixPQUFPM0UsRUFBRTtBQUNqRixZQUFNWixRQUFRd0YsS0FBSzdCLGdCQUFnQjtBQUNuQzVCLHFCQUFlL0IsS0FBSztBQUNwQjZCLGtCQUFZLENBQUFnRCxVQUFTO0FBQUEsUUFDakIsR0FBR0E7QUFBQUEsUUFDSDdGLFdBQVd3RyxLQUFLNUU7QUFBQUEsUUFDaEIzQixhQUFhdUcsS0FBSzFFLFFBQVE7QUFBQSxRQUMxQjVCLGFBQWFzRyxLQUFLdEcsZUFBZTtBQUFBLFFBQ2pDSCxhQUFhO0FBQUEsUUFDYnNFLFVBQVVMO0FBQUFBLFFBQ1ZsRSxRQUFRMEcsS0FBS0MsU0FBU1osTUFBTS9GLFVBQVU7QUFBQSxRQUN0Q0ssYUFBYTBGLE1BQU0xRixlQUFlO0FBQUEsUUFDbENNLGVBQWVvRixNQUFNcEYsaUJBQWlCO0FBQUEsTUFDMUMsRUFBRTtBQUNGcUMsZUFBUyxFQUFFO0FBQ1hpQiwyQkFBcUIsRUFBRTtBQUN2QnBGLFlBQU0rSCxRQUFRLDBDQUEwQztBQUFBLElBQzVELFNBQVNDLEtBQUs7QUFDVkMsY0FBUUMsTUFBTUYsR0FBRztBQUNqQmhJLFlBQU1rSSxNQUFNLCtCQUErQjtBQUFBLElBQy9DLFVBQUM7QUFDR3RELGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxRQUFNdUQseUJBQXlCLFlBQVk7QUFDdkMsVUFBTUMsT0FBT25FLFNBQVMxQyxhQUFhOEcsS0FBSztBQUN4QyxRQUFJLENBQUNELE1BQU07QUFDUHBJLFlBQU1zSSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLElBQ0o7QUFDQTFELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNMkQsUUFBUSxNQUFNL0gsY0FBeUJHLHdCQUF3QmtGLFVBQVUsQ0FBQyxFQUFFMkMsV0FBVyxlQUFlQyxPQUFPTCxLQUFLLENBQUMsQ0FBQztBQUMxSCxVQUFJRyxPQUFPO0FBQ1AsY0FBTVoscUJBQXFCWSxLQUFLO0FBQUEsTUFDcEMsT0FBTztBQUNIdkksY0FBTWtJLE1BQU0sd0NBQXdDRSxJQUFJLElBQUk7QUFBQSxNQUNoRTtBQUFBLElBQ0osU0FBU00sR0FBRztBQUNSVCxjQUFRQyxNQUFNUSxDQUFDO0FBQ2YxSSxZQUFNa0ksTUFBTSw0QkFBNEI7QUFBQSxJQUM1QyxVQUFDO0FBQ0d0RCxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTStELHlCQUF5QixPQUFPakQsYUFBdUI7QUFDekQsUUFBSSxDQUFDekIsU0FBUzVDLFdBQVc7QUFDckJyQixZQUFNNEksS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxJQUNKO0FBQ0FoRSxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsWUFBTWlELE9BQU8sTUFBTXZILFFBQWtCSSxvQkFBb0JtRixVQUFVSCxTQUFTekMsRUFBRTtBQUM5RSxVQUFJNEUsS0FBS3hHLGNBQWM0QyxTQUFTNUMsV0FBVztBQUN2Q3JCLGNBQU1rSSxNQUFNLG1EQUFtRDtBQUMvRHRELG1CQUFXLEtBQUs7QUFDaEI7QUFBQSxNQUNKO0FBQ0EsWUFBTWlFLGFBQWFoQixLQUFLRCxRQUFRekUsUUFBUTBFLEtBQUt2RyxlQUFlO0FBQzVENEMsa0JBQVksQ0FBQWdELFVBQVM7QUFBQSxRQUNqQixHQUFHQTtBQUFBQSxRQUNIOUYsYUFBYXlHLEtBQUs1RTtBQUFBQSxRQUNsQnlDLFVBQVUsRUFBRXpDLElBQUk0RSxLQUFLNUUsSUFBSTBDLGtCQUFrQmtDLEtBQUtsQyxvQkFBb0JDLE9BQU9pQyxLQUFLNUUsRUFBRSxHQUFHNkYsZUFBZWpCLEtBQUtpQixjQUFjO0FBQUEsUUFDdkh6SCxXQUFXd0csS0FBS3hHO0FBQUFBLFFBQ2hCQyxhQUFhdUg7QUFBQUEsUUFDYjFILFFBQVEwRyxLQUFLMUcsVUFBVStGLE1BQU0vRixVQUFVO0FBQUEsUUFDdkNLLGFBQWFxRyxLQUFLckcsZUFBZTBGLE1BQU0xRixlQUFlO0FBQUEsUUFDdERNLGVBQWUrRixLQUFLL0YsaUJBQWlCO0FBQUEsUUFDckNLLHNCQUFzQjtBQUFBLE1BQzFCLEVBQUU7QUFFRixZQUFNNEcsV0FBV2xCLEtBQUtrQixZQUFZO0FBQ2xDLFlBQU1DLFdBQXVCRCxTQUFTakcsSUFBSSxDQUFDbUcsR0FBd0JDLFNBQWlCO0FBQUEsUUFDaEZDLFlBQVlGLEVBQUVFO0FBQUFBLFFBQ2RDLGNBQWNILEVBQUVHO0FBQUFBLFFBQ2hCQyxjQUFjSixFQUFFSTtBQUFBQSxRQUNoQkMsYUFBYUosTUFBTTtBQUFBLFFBQ25CcEMsVUFBVW1DLEVBQUVuQztBQUFBQSxRQUNaQyxZQUFZa0MsRUFBRU07QUFBQUEsUUFDZEMsWUFBWVAsRUFBRU07QUFBQUEsUUFDZHhILHFCQUFxQjtBQUFBLFFBQ3JCTSxPQUFPO0FBQUEsUUFDUGtELFFBQVFDLE9BQU9DLFdBQVc7QUFBQSxNQUM5QixFQUFFO0FBQ0Z0QixlQUFTNkUsUUFBUTtBQUNqQjVELDJCQUFxQnlDLEtBQUtsQyxvQkFBb0JDLE9BQU9pQyxLQUFLNUUsRUFBRSxDQUFDO0FBQzdEakQsWUFBTStILFFBQVEsK0NBQStDO0FBQUEsSUFDakUsU0FBU0MsS0FBSztBQUNWQyxjQUFRQyxNQUFNRixHQUFHO0FBQ2pCaEksWUFBTWtJLE1BQU0sNEJBQTRCO0FBQUEsSUFDNUMsVUFBQztBQUNHdEQsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU02RSwyQkFBMkIsWUFBWTtBQUN6QyxRQUFJLENBQUN4RixTQUFTNUMsV0FBVztBQUNyQnJCLFlBQU00SSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLElBQ0o7QUFDQSxVQUFNUixPQUFPakQsa0JBQWtCa0QsS0FBSztBQUNwQyxRQUFJLENBQUNELE1BQU07QUFDUHBJLFlBQU1zSSxLQUFLLGlDQUFpQztBQUM1QztBQUFBLElBQ0o7QUFDQTFELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNMkQsUUFBUSxNQUFNL0gsY0FBd0JFLG9CQUFvQm1GLFVBQVUsQ0FBQyxFQUFFMkMsV0FBVyxvQkFBb0JDLE9BQU9MLEtBQUssQ0FBQyxDQUFDO0FBQzFILFVBQUlHLE9BQU87QUFDUCxjQUFNSSx1QkFBdUJKLEtBQUs7QUFBQSxNQUN0QyxPQUFPO0FBQ0h2SSxjQUFNa0ksTUFBTSwyQ0FBMkM7QUFBQSxNQUMzRDtBQUFBLElBQ0osU0FBU1EsR0FBRztBQUNSVCxjQUFRQyxNQUFNUSxDQUFDO0FBQ2YxSSxZQUFNa0ksTUFBTSw0QkFBNEI7QUFBQSxJQUM1QyxVQUFDO0FBQ0d0RCxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTThFLHdCQUF3QkEsQ0FBQ0MsYUFBa0I7QUFDN0MsUUFBSTFFLGtCQUFrQixVQUFVO0FBQzVCMEMsMkJBQXFCZ0MsUUFBcUI7QUFBQSxJQUM5QyxPQUFPO0FBQ0hoQiw2QkFBdUJnQixRQUFvQjtBQUFBLElBQy9DO0FBQ0F6RSxxQkFBaUIsSUFBSTtBQUNyQkosbUJBQWUsS0FBSztBQUFBLEVBQ3hCO0FBRUEsUUFBTThFLG1CQUFtQkEsQ0FBQ0MsT0FBZUMsT0FBcUNyQixVQUEyQjtBQUNyR3RFLGFBQVMsQ0FBQStDLFNBQVFBLEtBQUtwRSxJQUFJLENBQUNhLE1BQU0yQixNQUFPQSxNQUFNdUUsUUFBUSxFQUFFLEdBQUdsRyxNQUFNLENBQUNtRyxLQUFLLEdBQUdyQixNQUFNLElBQUk5RSxJQUFLLENBQUM7QUFBQSxFQUM5RjtBQUVBLFFBQU1vRyxtQkFBbUJBLENBQUNGLFVBQWtCO0FBQ3hDMUYsYUFBUyxDQUFBK0MsU0FBUUEsS0FBS2IsT0FBTyxDQUFDMkQsR0FBRzFFLE1BQU1BLE1BQU11RSxLQUFLLENBQUM7QUFBQSxFQUN2RDtBQUVBLFFBQU1JLGFBQWEsWUFBWTtBQUMzQixRQUFJLENBQUNoRyxTQUFTNUMsV0FBVztBQUNyQnJCLFlBQU00SSxLQUFLLDBCQUEwQjtBQUNyQztBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUMzRSxTQUFTN0MsYUFBYTtBQUN2QnBCLFlBQU00SSxLQUFLLHdCQUF3QjtBQUNuQztBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUMzRSxTQUFTOUMsUUFBUTtBQUNsQm5CLFlBQU00SSxLQUFLLDBCQUEwQjtBQUNyQztBQUFBLElBQ0o7QUFDQSxRQUFJeEcsTUFBTU0sV0FBVyxHQUFHO0FBQ3BCMUMsWUFBTTRJLEtBQUssOEJBQThCO0FBQ3pDO0FBQUEsSUFDSjtBQUVBLFVBQU1zQixhQUFhN0YsYUFDZGdDLE9BQU8sQ0FBQUMsTUFBS2hELE9BQU9nRCxFQUFFakQsTUFBTSxJQUFJLENBQUMsRUFDaENQLElBQUksQ0FBQXdELE9BQU0sRUFBRSxHQUFHQSxHQUFHQyxVQUFVLEVBQVcsRUFBRTtBQUU5QyxVQUFNNEQsYUFBYTVGLGVBQ2Q4QixPQUFPLENBQUFpQixNQUFLQSxFQUFFdEUsVUFBVSxRQUFRTSxPQUFPZ0UsRUFBRWpFLE1BQU0sSUFBSSxDQUFDLEVBQ3BEUCxJQUFJLENBQUF3RSxPQUFNO0FBQUEsTUFDUHRFLFFBQVFzRSxFQUFFdEU7QUFBQUEsTUFDVkUsVUFBVW9FLEVBQUVwRSxZQUFZbUM7QUFBQUEsTUFDeEJqQyxNQUFNO0FBQUEsTUFDTkMsUUFBUWlFLEVBQUVqRTtBQUFBQSxNQUNWa0QsVUFBVTtBQUFBLElBQ2QsRUFBRTtBQUVOLFVBQU02RCxVQUF1QztBQUFBLE1BQ3pDLEdBQUduRztBQUFBQSxNQUNIOUMsUUFBUThDLFNBQVM5QyxVQUFVO0FBQUEsTUFDM0JDLGFBQWE2QyxTQUFTN0M7QUFBQUEsTUFDdEJDLFdBQVc0QyxTQUFTNUM7QUFBQUEsTUFDcEJFLGFBQWEwQyxTQUFTMUMsZUFBZThEO0FBQUFBLE1BQ3JDN0QsYUFBYXlDLFNBQVN6QyxlQUFlO0FBQUEsTUFDckNDLFlBQVl3QyxTQUFTeEMsZUFBYyxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUN4RUMsY0FBY3NGLGlCQUFpQkk7QUFBQUEsTUFDL0J6RixlQUFlbUMsU0FBU25DLGlCQUFpQjtBQUFBLE1BQ3pDQyxxQkFBcUJrQyxTQUFTbEMsdUJBQXVCO0FBQUEsTUFDckRDLFFBQVFpQyxTQUFTakMsVUFBVTtBQUFBLE1BQzNCQyxrQkFBa0JnQyxTQUFTaEMsb0JBQW9CO0FBQUEsTUFDL0NDLE9BQU8rQixTQUFTL0IsU0FBUztBQUFBLE1BQ3pCQyxzQkFBc0I7QUFBQSxNQUN0QkcsbUJBQW1CMkIsU0FBUzNCLHFCQUFxQjtBQUFBLE1BQ2pERixPQUFPQSxNQUFNVSxJQUFJLENBQUMsRUFBRXlDLFFBQVEsR0FBRzhFLEtBQUssT0FBTyxFQUFFLEdBQUdBLE1BQU1oSSxPQUFPZ0ksS0FBS2hJLFNBQVMsR0FBRyxFQUFFO0FBQUEsTUFDaEZBLE9BQU8sQ0FBQyxHQUFHNkgsWUFBWSxHQUFHQyxVQUFVO0FBQUEsSUFDeEM7QUFFQSxRQUFJO0FBQ0EsWUFBTXBHLFNBQVNxRyxPQUFzQztBQUNyRHBLLFlBQU0rSCxRQUFRLG9DQUFvQztBQUNsRHRFLGVBQVN4QyxrQkFBa0JSLCtCQUErQjZKLFNBQVMsQ0FBQztBQUFBLElBQ3hFLFNBQVM1QixHQUFHO0FBQ1IxSSxZQUFNa0ksTUFBTSxtQkFBbUI7QUFBQSxJQUNuQztBQUFBLEVBQ0o7QUFFQSxNQUFJcEUsWUFBYSxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUV2QyxRQUFNeUcsYUFBYTtBQUVuQixRQUFNQyxzQkFBc0J2RyxTQUFTNUMsWUFDL0IsRUFBRSxHQUFHWCxxQkFBcUIrSixnQkFBZ0IsRUFBRXBKLFdBQVc0QyxTQUFTNUMsVUFBVSxFQUFFLElBQzVFWDtBQUVOLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLCtEQUNUaUU7QUFBQUEsa0JBQWFYLFdBQ1gsdUJBQUMsU0FBSSxXQUFVLDhHQUNYO0FBQUEsNkJBQUMsYUFBVSxXQUFVLCtDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFO0FBQUEsTUFDaEUsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLFNBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0osdUJBQUMsUUFBRyxXQUFVLHVDQUNUTixtQkFBUyxXQUFXLG1DQUFtQyxlQUFlTyxTQUFTeUcsa0JBQWtCekgsRUFBRSxNQUR4RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBV2dCLFNBQVMxQyxlQUFlO0FBQUEsWUFDbkMsV0FBVzBDLFNBQVMzQyxlQUFlO0FBQUEsWUFDbkMsY0FBYyxDQUFDcUosTUFBTXpHLFlBQVksQ0FBQWdELFVBQVMsRUFBRSxHQUFHQSxNQUFNM0YsYUFBYW9KLEtBQUssR0FBRyxFQUFFO0FBQUEsWUFDNUUsY0FBY3hDO0FBQUFBLFlBQ2QsZUFBZSxNQUFNO0FBQUVuRCw2QkFBZXJFLHVCQUE0QztBQUFHdUUsK0JBQWlCLFFBQVE7QUFBR0osNkJBQWUsSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUN2SSxjQUFjNEM7QUFBQUE7QUFBQUEsVUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTRCO0FBQUEsV0FSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLHlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU96RCxTQUFTOUMsVUFBVTtBQUFBLFlBQzFCLFVBQVUsQ0FBQXVILE1BQUt4RSxZQUFZLENBQUFnRCxVQUFTLEVBQUUsR0FBR0EsTUFBTS9GLFFBQVF1SCxFQUFFa0MsT0FBT25DLE1BQU0sRUFBRTtBQUFBLFlBQ3hFLFdBQVc4QjtBQUFBQSxZQUVYO0FBQUEscUNBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUE7QUFBQTtBQUFBLFVBUnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsMkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBV3BGO0FBQUFBLFlBQ1gsV0FBV2xCLFNBQVM3QyxjQUFlNkMsU0FBU3lCLFVBQVVDLG9CQUFvQixXQUFXMUIsU0FBUzdDLFdBQVcsS0FBTTtBQUFBLFlBQy9HLGNBQWMsQ0FBQ3VKLE1BQU12RixxQkFBcUJ1RixLQUFLLEVBQUU7QUFBQSxZQUNqRCxjQUFjbEI7QUFBQUEsWUFDZCxlQUFlLE1BQU07QUFBRXpFLDZCQUFld0YsbUJBQXdDO0FBQUd0RiwrQkFBaUIsVUFBVTtBQUFHSiw2QkFBZSxJQUFJO0FBQUEsWUFBRztBQUFBLFlBQ3JJLGNBQWMsTUFBTTtBQUFFWiwwQkFBWSxDQUFBZ0QsVUFBUyxFQUFFLEdBQUdBLE1BQU05RixhQUFhLEdBQUdzRSxVQUFVTCxPQUFVLEVBQUU7QUFBR2xCLHVCQUFTLEVBQUU7QUFBR2lCLG1DQUFxQixFQUFFO0FBQUEsWUFBRztBQUFBLFlBQ3ZJLFVBQVUsQ0FBQ25CLFNBQVM1QztBQUFBQTtBQUFBQSxVQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPa0M7QUFBQSxXQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsNkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsT0FBTzRDLFNBQVN4QyxjQUFjO0FBQUEsWUFDOUIsVUFBVSxDQUFBaUgsTUFBS3hFLFlBQVksQ0FBQWdELFVBQVMsRUFBRSxHQUFHQSxNQUFNekYsWUFBWWlILEVBQUVrQyxPQUFPbkMsTUFBTSxFQUFFO0FBQUEsWUFDNUUsV0FBVzhCO0FBQUFBLFlBQVksY0FBYTtBQUFBO0FBQUEsVUFKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTZDO0FBQUEsV0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsUUFDekU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLE9BQU90RyxTQUFTaEMsb0JBQW9CO0FBQUEsWUFDcEMsVUFBVSxDQUFBeUcsTUFBS3hFLFlBQVksQ0FBQWdELFVBQVMsRUFBRSxHQUFHQSxNQUFNakYsa0JBQWtCeUcsRUFBRWtDLE9BQU9uQyxTQUFTLEtBQUssRUFBRTtBQUFBLFlBQzFGLFdBQVc4QjtBQUFBQSxZQUNYLGFBQVk7QUFBQSxZQUFXLGNBQWE7QUFBQTtBQUFBLFVBTHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUs2QztBQUFBLFdBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyxxQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFNO0FBQUEsWUFDTixPQUFPdEcsU0FBUy9CLFNBQVM7QUFBQSxZQUN6QixVQUFVLENBQUF3RyxNQUFLeEUsWUFBWSxDQUFBZ0QsVUFBUyxFQUFFLEdBQUdBLE1BQU1oRixPQUFPd0csRUFBRWtDLE9BQU9uQyxTQUFTLEtBQUssRUFBRTtBQUFBLFlBQy9FLFdBQVc4QjtBQUFBQSxZQUFZLGNBQWE7QUFBQTtBQUFBLFVBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2QztBQUFBLFdBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4REE7QUFBQSxJQUVDbkksTUFBTU0sU0FBUyxLQUNaLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSwwQ0FBeUMscUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxtRUFBa0Usd0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSxxQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHdCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUsd0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsUUFBRyxXQUFVLDRFQUEyRSxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQUxuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWk4sZ0JBQU1VLElBQUksQ0FBQ2EsTUFBTWtHLFVBQVU7QUFDeEIsZ0JBQU1nQixVQUFVdkgsT0FBT0ssS0FBS21ELFFBQVEsSUFBSXhELE9BQU9LLEtBQUtvRCxVQUFVO0FBQzlELGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbUNBQ1RwRDtBQUFBQSxtQkFBSzBGO0FBQUFBLGNBQWE7QUFBQSxjQUFDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGdCQUFFMUYsS0FBS3lGO0FBQUFBLGdCQUFhO0FBQUEsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsaUJBRDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx3QkFDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLEtBQUs7QUFBQSxnQkFDTCxPQUFPekYsS0FBS21EO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQWdFLFFBQU9sQixpQkFBaUJDLE9BQU8sWUFBWWlCLEdBQUc7QUFBQSxnQkFDeEQsV0FBVTtBQUFBO0FBQUEsY0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJZ0YsS0FMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLE9BQU9uSCxLQUFLb0Q7QUFBQUEsZ0JBQ1osVUFBVSxDQUFBK0QsUUFBT2xCLGlCQUFpQkMsT0FBTyxjQUFjaUIsR0FBRztBQUFBLGdCQUMxRCxXQUFVO0FBQUE7QUFBQSxjQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlnRixLQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsNENBQTRDOUosc0JBQVk2SixTQUFTLFVBQVUsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkY7QUFBQSxZQUMzRix1QkFBQyxRQUFHLFdBQVUsZ0NBQ1YsaUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNZCxpQkFBaUJGLEtBQUssR0FBRyxXQUFVLHVDQUFzQyx3QkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0gsS0FEMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBdkJLbEcsS0FBSzRCLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxRQUVSLENBQUMsS0E5Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFdBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0EsS0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLFNBOUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQ0E7QUFBQSxJQUdKLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUNyRSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsc0RBQXFELDZDQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLFVBQ25HO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxPQUFPdEIsU0FBUzNCO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQXdJLFFBQU81RyxZQUFZLENBQUFnRCxVQUFTLEVBQUUsR0FBR0EsTUFBTTVFLG1CQUFtQndJLE9BQU8sRUFBRSxFQUFFO0FBQUEsY0FDL0UsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBO0FBQUEsWUFMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS21CO0FBQUEsYUFQdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQ3RELGdCQUFnQjlFLFNBQVMsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLHlFQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLHdCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRjtBQUFBLFlBQy9GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsWUFDbkYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxlQUhwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaOEUsMEJBQWdCMUU7QUFBQUEsWUFBSSxDQUFDQyxLQUFLbUcsUUFDdkIsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSw4Q0FBOENuRyxjQUFJRyxZQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENILGNBQUlLLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckUsdUJBQUMsUUFBRyxXQUFVLGdDQUNUWCxzQkFBWUMsU0FBUyxLQUFLLE9BQU9LLElBQUlDLFdBQVcsV0FDN0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLE9BQU9ELElBQUlNO0FBQUFBLGtCQUNYLFVBQVUsQ0FBQXlILFFBQU83RCw2QkFBNkJsRSxJQUFJQyxRQUFrQjhILE9BQU8sQ0FBQztBQUFBLGtCQUM1RSxXQUFVO0FBQUE7QUFBQSxnQkFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJZ0YsSUFHaEYsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQjlKLHNCQUFZK0IsSUFBSU0sUUFBUSxVQUFVLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFLEtBVDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFkS04sSUFBSUMsVUFBVWtHLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxVQUNILEtBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQSxLQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBLElBRUEsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwyQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBRXpFLHVCQUFDLFNBQUksV0FBVSxzQ0FDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQ0FBeUMsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbEV6RSxnQkFBZ0IvQixXQUFXLElBQ3hCLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsaURBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFLElBRXRFLG1DQUNJO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGFBQ1Y2Qix5QkFBZXpCO0FBQUFBLGNBQUksQ0FBQ2lJLFFBQ2pCLHVCQUFDLFNBQXFCLFdBQVUsdUNBQzVCO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csT0FBT0EsSUFBSS9ILFVBQVU7QUFBQSxvQkFDckIsVUFBVSxDQUFDMEYsTUFBTTtBQUNiLDRCQUFNc0MsTUFBTXRDLEVBQUVrQyxPQUFPbkM7QUFDckIsMEJBQUksQ0FBQ3VDLEtBQUs7QUFDTnhHLDBDQUFrQixDQUFBMEMsU0FBUUEsS0FBS3BFLElBQUksQ0FBQXdFLE1BQUtBLEVBQUUvQixXQUFXd0YsSUFBSXhGLFNBQVMsRUFBRSxHQUFHK0IsR0FBR3RFLFFBQVEsTUFBTUUsVUFBVSxLQUFLLElBQUlvRSxDQUFDLENBQUM7QUFDN0c7QUFBQSxzQkFDSjtBQUNBLDRCQUFNdkUsTUFBTTBCLGdCQUFnQndHLEtBQUssQ0FBQTNFLE1BQUtBLEVBQUVyRCxPQUFPSyxPQUFPMEgsR0FBRyxDQUFDO0FBQzFELDBCQUFJLENBQUNqSSxJQUFLO0FBQ1YsNEJBQU1tSSxjQUFjM0csZUFBZTRHLEtBQUssQ0FBQTdELE1BQUtBLEVBQUUvQixXQUFXd0YsSUFBSXhGLFVBQVUrQixFQUFFdEUsV0FBV0QsSUFBSUUsRUFBRTtBQUMzRiwwQkFBSWlJLGFBQWE7QUFDYmxMLDhCQUFNNEksS0FBSywwREFBMEQ7QUFDckU7QUFBQSxzQkFDSjtBQUNBcEUsd0NBQWtCLENBQUEwQyxTQUFRQSxLQUFLcEU7QUFBQUEsd0JBQUksQ0FBQXdFLE1BQy9CQSxFQUFFL0IsV0FBV3dGLElBQUl4RixTQUFTLEVBQUUsR0FBRytCLEdBQUd0RSxRQUFRRCxJQUFJRSxJQUFJQyxVQUFVSCxJQUFJSSxLQUFLLElBQUltRTtBQUFBQSxzQkFDN0UsQ0FBQztBQUFBLG9CQUNMO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBQ3JDN0MsZ0JBQWdCM0I7QUFBQUEsd0JBQUksQ0FBQ0MsUUFDbEIsdUJBQUMsWUFBb0IsT0FBT0EsSUFBSUUsSUFBSSxVQUFVc0IsZUFBZTRHLEtBQUssQ0FBQTdELE1BQUtBLEVBQUUvQixXQUFXd0YsSUFBSXhGLFVBQVUrQixFQUFFdEUsV0FBV0QsSUFBSUUsRUFBRSxHQUNoSEYsY0FBSUksUUFESUosSUFBSUUsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNIO0FBQUE7QUFBQTtBQUFBLGtCQTFCTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBMkJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csT0FBTzhILElBQUkxSDtBQUFBQSxzQkFDWCxVQUFVLENBQUF5SCxRQUFPdEcsa0JBQWtCLENBQUEwQyxTQUFRQSxLQUFLcEU7QUFBQUEsd0JBQUksQ0FBQXdFLE1BQ2hEQSxFQUFFL0IsV0FBV3dGLElBQUl4RixTQUFTLEVBQUUsR0FBRytCLEdBQUdqRSxRQUFReUgsT0FBTyxFQUFFLElBQUl4RDtBQUFBQSxzQkFDM0QsQ0FBQztBQUFBLHNCQUNELFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUE7QUFBQSxvQkFOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1tQjtBQUFBLGtCQUVuQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNOUMsa0JBQWtCLENBQUEwQyxTQUFRQSxLQUFLYixPQUFPLENBQUFpQixNQUFLQSxFQUFFL0IsV0FBV3dGLElBQUl4RixNQUFNLENBQUM7QUFBQSxzQkFDbEYsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVE7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQTlDTXdGLElBQUl4RixRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0NBO0FBQUEsWUFDSCxLQWxETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1EQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNZixrQkFBa0IsQ0FBQTBDLFNBQVEsQ0FBQyxHQUFHQSxNQUFNLEVBQUUzQixRQUFRQyxPQUFPQyxXQUFXLEdBQUd6QyxRQUFRLE1BQU1FLFVBQVUsTUFBTUcsUUFBUSxFQUFFLENBQUMsQ0FBQztBQUFBLGdCQUM1SCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTREQTtBQUFBLGFBakVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRUE7QUFBQSxXQWxISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUhBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUscURBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJyQyxzQkFBWW1HLGlCQUFpQjNFLFVBQVUsVUFBVSxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLGFBQWxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUw7QUFBQSxRQUN6TCx1QkFBQyxTQUFJLFdBQVUsOENBQTZDO0FBQUEsaUNBQUMsVUFBSyw4Q0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQU8sdUJBQUMsVUFBTXhCLHNCQUFZbUcsaUJBQWlCN0UscUJBQXFCLEdBQUcsVUFBVSxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0w7QUFBQSxRQUN0TCx1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFlBQUd0QixZQUFZbUcsaUJBQWlCQyxZQUFZLFVBQVU7QUFBQSxlQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLGFBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEw7QUFBQSxRQUM5TCx1QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlCQUFnQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFlBQUdwRyxZQUFZbUcsaUJBQWlCRSxtQkFBbUIsVUFBVTtBQUFBLGVBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsYUFBak07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TTtBQUFBLFFBQ3hNLHVCQUFDLFNBQUksV0FBVSwyQ0FBMEM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMkJBQTBCLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQU8sdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnJHLHNCQUFZbUcsaUJBQWlCSSxPQUFPLFVBQVUsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxhQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9OO0FBQUEsV0FMeE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0EzSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRIQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsNkJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNOUQsU0FBU3hDLGtCQUFrQlIsK0JBQStCNkosU0FBUyxDQUFDLEdBQUcsV0FBVSxxSEFBb0gsd0JBQTFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa1A7QUFBQSxNQUNsUCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTTCxZQUFZLFVBQVV0RixhQUFhWCxVQUFVNUIsTUFBTU0sV0FBVyxHQUFHLFdBQVUsMEtBQ3RHO0FBQUEsK0JBQUMsVUFBTyxXQUFVLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUFHO0FBQUEsV0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVDbUMsZUFBZUUsZUFDWix1QkFBQyxlQUFZLFFBQVFGLGFBQWEsU0FBUyxNQUFNO0FBQUVDLHFCQUFlLEtBQUs7QUFBR0ksdUJBQWlCLElBQUk7QUFBQSxJQUFHLEdBQUcsVUFBVXdFLHVCQUF1QixRQUFRM0UsZUFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSjtBQUFBLE9BclFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdVFBO0FBRVI7QUFBRXZCLEdBcmxCV0QsNEJBQTBCO0FBQUEsVUFDcEJ4RCxXQUNFRCxhQUdrQ08sYUFDYkEsV0FBVztBQUFBO0FBQUErSyxLQU54QzdIO0FBQTBCLElBQUE2SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ0b2FzdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhUGx1cyIsIkZhVHJhc2giLCJ1c2VDcnVkSXRlbSIsImdldEJ5SWQiLCJnZXRBbGwiLCJzZWFyY2hCeUZpZWxkIiwibm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnIiwiY29tcHJhc01vZHVsZUNvbmZpZyIsInByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIiwiUmVsYXRpb25hbElucHV0IiwiRGVjaW1hbElucHV0IiwiU2VhcmNoTW9kYWwiLCJMb2FkaW5nU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJkZWZhdWx0SW5pdGlhbCIsInNlcmllcyIsInB1cmNoYXNlX2lkIiwidmVuZG9yX2lkIiwidmVuZG9yX25hbWUiLCJ2ZW5kb3JfY29kZSIsImN1cnJlbmN5X2lkIiwiaXNzdWVfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwidG90YWxfYW1vdW50IiwiZXhjaGFuZ2VfcmF0ZSIsImRpc2NvdW50X3BlcmNlbnRhZ2UiLCJzdGF0dXMiLCJyZWplY3Rpb25fcmVhc29uIiwibm90ZXMiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsIml0ZW1zIiwidGF4ZXMiLCJ3aXRob3V0dGF4X2Ftb3VudCIsImNhbGN1bGF0ZU5vdGVMZXZlbFRheGVzIiwic3VidG90YWwiLCJ2ZW5kb3JUYXhlcyIsImxlbmd0aCIsInRheEJhc2UiLCJNYXRoIiwibWF4IiwibWFwIiwidGF4IiwidGF4X2lkIiwiaWQiLCJ0YXhfbmFtZSIsIm5hbWUiLCJyYXRlIiwiYW1vdW50IiwiTnVtYmVyIiwiTm90YXNDcmVkaXRvQ29tcHJhRm9ybVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwibW9kZSIsIml0ZW0iLCJsb2FkZWREYXRhIiwibG9hZGluZyIsImxvYWRpbmdEYXRhIiwic2F2ZUl0ZW0iLCJzYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0SXRlbXMiLCJzZXRWZW5kb3JUYXhlcyIsImFwcGxpZWRUYXhlcyIsInNldEFwcGxpZWRUYXhlcyIsInBlcmNlcHRpb25Sb3dzIiwic2V0UGVyY2VwdGlvblJvd3MiLCJwZXJjZXB0aW9uVGF4ZXMiLCJzZXRQZXJjZXB0aW9uVGF4ZXMiLCJpc0xvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNNb2RhbE9wZW4iLCJzZXRJc01vZGFsT3BlbiIsIm1vZGFsQ29uZmlnIiwic2V0TW9kYWxDb25maWciLCJlZGl0aW5nVGFyZ2V0Iiwic2V0RWRpdGluZ1RhcmdldCIsInB1cmNoYXNlQ29kZUlucHV0Iiwic2V0UHVyY2hhc2VDb2RlSW5wdXQiLCJ1bmRlZmluZWQiLCJpIiwidGVtcElkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInB1cmNoYXNlIiwiaW50ZXJuYWxfdm91Y2hlciIsIlN0cmluZyIsImVuZHBvaW50IiwidGhlbiIsInYiLCJyZWxhdGVkVGF4ZXMiLCJjYXRjaCIsIkFycmF5IiwiaXNBcnJheSIsInR5cGUxIiwiZmlsdGVyIiwidCIsInRheF90eXBlIiwidHlwZTIiLCJ0eXBlIiwicmVzIiwiZGF0YSIsInJlZHVjZSIsInMiLCJxdWFudGl0eSIsInVuaXRfcHJpY2UiLCJjYWxjdWxhdGVkIiwiaGFuZGxlVXBkYXRlQXBwbGllZFRheEFtb3VudCIsInByZXYiLCJjYWxjdWxhdGVkVG90YWxzIiwidG90YWxUYXhlcyIsInBlcmNlcGNpb25lc1RvdGFsIiwiciIsInRvdGFsIiwiYWdncmVnYXRlZFRheGVzIiwiYXBwbGllZCIsImNsZWFyRm9ybSIsImhhbmRsZVZlbmRvclNlbGVjdGVkIiwidmVuZG9yIiwiZnVsbCIsInNlcmllIiwic3VjY2VzcyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZVZlbmRvckNvZGVTdWJtaXQiLCJjb2RlIiwidHJpbSIsImluZm8iLCJmb3VuZCIsImZpZWxkTmFtZSIsInZhbHVlIiwiZSIsImhhbmRsZVB1cmNoYXNlU2VsZWN0ZWQiLCJ3YXJuIiwidmVuZG9yTmFtZSIsInB1cmNoYXNlX2RhdGUiLCJwcm9kdWN0cyIsIm5ld0l0ZW1zIiwicCIsImlkeCIsInByb2R1Y3RfaWQiLCJwcm9kdWN0X2NvZGUiLCJwcm9kdWN0X25hbWUiLCJsaW5lX251bWJlciIsInByaWNlX2Nvc3QiLCJjb3N0X3ByaWNlIiwiaGFuZGxlUHVyY2hhc2VDb2RlU3VibWl0IiwiaGFuZGxlU2VsZWN0RnJvbU1vZGFsIiwic2VsZWN0ZWQiLCJoYW5kbGVJdGVtQ2hhbmdlIiwiaW5kZXgiLCJmaWVsZCIsImhhbmRsZVJlbW92ZUl0ZW0iLCJfIiwiaGFuZGxlU2F2ZSIsInRheGVzVHlwZTEiLCJ0YXhlc1R5cGUyIiwicGF5bG9hZCIsInJlc3QiLCJiYXNlUm91dGUiLCJpbnB1dFN0eWxlIiwicHVyY2hhc2VNb2RhbENvbmZpZyIsImluaXRpYWxGaWx0ZXJzIiwidm91Y2hlcl9udW1iZXIiLCJjIiwidGFyZ2V0IiwibGluZVN1YiIsIm51bSIsInJvdyIsInZhbCIsImZpbmQiLCJhbHJlYWR5VXNlZCIsInNvbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3Rhc0NyZWRpdG9Db21wcmFGb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgRmFTYXZlLCBGYVNwaW5uZXIsIEZhUGx1cywgRmFUcmFzaCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgZ2V0QnlJZCwgZ2V0QWxsLCBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWcsIHR5cGUgUHVyY2hhc2VDcmVkaXROb3RlLCB0eXBlIFB1cmNoYXNlQ3JlZGl0Tm90ZUl0ZW0gfSBmcm9tICcuLi9ub3Rhc19jcmVkaXRvX2NvbXByYS5jb25maWcnO1xuaW1wb3J0IHsgY29tcHJhc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL2NvbXByYXMvY29tcHJhcy5jb25maWcnO1xuaW1wb3J0IHR5cGUgeyBQdXJjaGFzZSwgUHJvZHVjdFB1cmNoYXNlSXRlbSB9IGZyb20gJy4uLy4uL2NvbXByYXMvY29tcHJhcy5jb25maWcnO1xuaW1wb3J0IHsgcHJvdmVlZG9yZXNNb2R1bGVDb25maWcsIHR5cGUgUHJvdmVlZG9yIH0gZnJvbSAnLi4vLi4vcHJvdmVlZG9yZXMvcHJvdmVlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IFJlbGF0aW9uYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1JlbGF0aW9uYWxJbnB1dCc7XG5pbXBvcnQgeyBEZWNpbWFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9EZWNpbWFsSW5wdXQnO1xuaW1wb3J0IHsgU2VhcmNoTW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9TZWFyY2hNb2RhbCc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB0eXBlIHsgQXBwbGllZFRheCwgUmVsYXRlZFRheCB9IGZyb20gJy4uLy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQgdHlwZSB7IFRheCB9IGZyb20gJy4uLy4uL2ltcHVlc3Rvcy9pbXB1ZXN0b3MuY29uZmlnJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5jb25zdCBkZWZhdWx0SW5pdGlhbDogUGFydGlhbDxQdXJjaGFzZUNyZWRpdE5vdGU+ID0ge1xuICAgIHNlcmllczogJ0InLFxuICAgIHB1cmNoYXNlX2lkOiAwLFxuICAgIHZlbmRvcl9pZDogMCxcbiAgICB2ZW5kb3JfbmFtZTogJycsXG4gICAgdmVuZG9yX2NvZGU6ICcnLFxuICAgIGN1cnJlbmN5X2lkOiAxLFxuICAgIGlzc3VlX2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgIHRvdGFsX2Ftb3VudDogMCxcbiAgICBleGNoYW5nZV9yYXRlOiAxLFxuICAgIGRpc2NvdW50X3BlcmNlbnRhZ2U6IDAsXG4gICAgc3RhdHVzOiAnRFJBRlQnLFxuICAgIHJlamVjdGlvbl9yZWFzb246IG51bGwsXG4gICAgbm90ZXM6IG51bGwsXG4gICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgIGl0ZW1zOiBbXSxcbiAgICB0YXhlczogW10sXG4gICAgd2l0aG91dHRheF9hbW91bnQ6IDAsXG59O1xuXG50eXBlIEZvcm1JdGVtID0gUHVyY2hhc2VDcmVkaXROb3RlSXRlbSAmIHsgdGVtcElkOiBzdHJpbmcgfTtcblxuaW50ZXJmYWNlIFBlcmNlcHRpb25Sb3cge1xuICAgIHRlbXBJZDogc3RyaW5nO1xuICAgIHRheF9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICB0YXhfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBhbW91bnQ6IG51bWJlcjtcbn1cblxuZnVuY3Rpb24gY2FsY3VsYXRlTm90ZUxldmVsVGF4ZXMoc3VidG90YWw6IG51bWJlciwgd2l0aG91dHRheF9hbW91bnQ6IG51bWJlciwgdmVuZG9yVGF4ZXM6IFJlbGF0ZWRUYXhbXSk6IEFwcGxpZWRUYXhbXSB7XG4gICAgaWYgKCF2ZW5kb3JUYXhlcyB8fCB2ZW5kb3JUYXhlcy5sZW5ndGggPT09IDApIHJldHVybiBbXTtcbiAgICBjb25zdCB0YXhCYXNlID0gTWF0aC5tYXgoMCwgc3VidG90YWwgLSB3aXRob3V0dGF4X2Ftb3VudCk7XG4gICAgcmV0dXJuIHZlbmRvclRheGVzLm1hcCh0YXggPT4gKHtcbiAgICAgICAgdGF4X2lkOiB0YXguaWQsXG4gICAgICAgIHRheF9uYW1lOiB0YXgubmFtZSxcbiAgICAgICAgcmF0ZTogdGF4LnJhdGUsXG4gICAgICAgIGFtb3VudDogdGF4QmFzZSAqIChOdW1iZXIodGF4LnJhdGUpIC8gMTAwKSxcbiAgICB9KSk7XG59XG5cbmV4cG9ydCBjb25zdCBOb3Rhc0NyZWRpdG9Db21wcmFGb3JtUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IG1vZGUgPSBpZCA/ICdlZGl0JyA6ICdjcmVhdGUnO1xuXG4gICAgY29uc3QgeyBpdGVtOiBsb2FkZWREYXRhLCBsb2FkaW5nOiBsb2FkaW5nRGF0YSB9ID0gdXNlQ3J1ZEl0ZW08UHVyY2hhc2VDcmVkaXROb3RlPihub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtLCBsb2FkaW5nOiBzYXZpbmcgfSA9IHVzZUNydWRJdGVtPFB1cmNoYXNlQ3JlZGl0Tm90ZT4obm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPFBhcnRpYWw8UHVyY2hhc2VDcmVkaXROb3RlPj4oZGVmYXVsdEluaXRpYWwpO1xuICAgIGNvbnN0IFtpdGVtcywgc2V0SXRlbXNdID0gdXNlU3RhdGU8Rm9ybUl0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFt2ZW5kb3JUYXhlcywgc2V0VmVuZG9yVGF4ZXNdID0gdXNlU3RhdGU8UmVsYXRlZFRheFtdPihbXSk7XG4gICAgY29uc3QgW2FwcGxpZWRUYXhlcywgc2V0QXBwbGllZFRheGVzXSA9IHVzZVN0YXRlPEFwcGxpZWRUYXhbXT4oW10pO1xuICAgIGNvbnN0IFtwZXJjZXB0aW9uUm93cywgc2V0UGVyY2VwdGlvblJvd3NdID0gdXNlU3RhdGU8UGVyY2VwdGlvblJvd1tdPihbXSk7XG4gICAgY29uc3QgW3BlcmNlcHRpb25UYXhlcywgc2V0UGVyY2VwdGlvblRheGVzXSA9IHVzZVN0YXRlPFRheFtdPihbXSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21vZGFsQ29uZmlnLCBzZXRNb2RhbENvbmZpZ10gPSB1c2VTdGF0ZTxNb2R1bGVDb25maWc8YW55PiB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPCd2ZW5kb3InIHwgJ3B1cmNoYXNlJyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtwdXJjaGFzZUNvZGVJbnB1dCwgc2V0UHVyY2hhc2VDb2RlSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1vZGUgPT09ICdlZGl0JyAmJiBsb2FkZWREYXRhKSB7XG4gICAgICAgICAgICBzZXRGb3JtRGF0YSh7XG4gICAgICAgICAgICAgICAgLi4uZGVmYXVsdEluaXRpYWwsXG4gICAgICAgICAgICAgICAgLi4ubG9hZGVkRGF0YSxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfbmFtZTogbG9hZGVkRGF0YS52ZW5kb3JfbmFtZSA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgdmVuZG9yX2NvZGU6IGxvYWRlZERhdGEudmVuZG9yX2NvZGUgPz8gdW5kZWZpbmVkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRJdGVtcygobG9hZGVkRGF0YS5pdGVtcyB8fCBbXSkubWFwKGkgPT4gKHsgLi4uaSwgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpIH0pKSk7XG4gICAgICAgICAgICBzZXRQdXJjaGFzZUNvZGVJbnB1dChsb2FkZWREYXRhLnB1cmNoYXNlPy5pbnRlcm5hbF92b3VjaGVyID8/IFN0cmluZyhsb2FkZWREYXRhLnB1cmNoYXNlX2lkID8/ICcnKSk7XG4gICAgICAgICAgICBpZiAobG9hZGVkRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgICAgICBnZXRCeUlkPFByb3ZlZWRvcj4ocHJvdmVlZG9yZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGxvYWRlZERhdGEudmVuZG9yX2lkKVxuICAgICAgICAgICAgICAgICAgICAudGhlbih2ID0+IHNldFZlbmRvclRheGVzKHYucmVsYXRlZFRheGVzIHx8IFtdKSlcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNldFZlbmRvclRheGVzKFtdKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9hZGVkRGF0YS50YXhlcyAmJiBBcnJheS5pc0FycmF5KGxvYWRlZERhdGEudGF4ZXMpICYmIGxvYWRlZERhdGEudGF4ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUxID0gKGxvYWRlZERhdGEudGF4ZXMgYXMgKEFwcGxpZWRUYXggJiB7IHRheF90eXBlPzogbnVtYmVyIH0pW10pLmZpbHRlcih0ID0+IHQudGF4X3R5cGUgIT09IDIpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUyID0gKGxvYWRlZERhdGEudGF4ZXMgYXMgKEFwcGxpZWRUYXggJiB7IHRheF90eXBlPzogbnVtYmVyIH0pW10pLmZpbHRlcih0ID0+IHQudGF4X3R5cGUgPT09IDIpO1xuXG4gICAgICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKHR5cGUxLm1hcCgodCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgdGF4X2lkOiB0LnRheF9pZCxcbiAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHQudGF4X25hbWUsXG4gICAgICAgICAgICAgICAgICAgIHJhdGU6IHQucmF0ZSxcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpIHx8IDAsXG4gICAgICAgICAgICAgICAgfSkpKTtcblxuICAgICAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHR5cGUyLm1hcCgodCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICB0YXhfaWQ6IHQudGF4X2lkLFxuICAgICAgICAgICAgICAgICAgICB0YXhfbmFtZTogdC50YXhfbmFtZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCkgfHwgMCxcbiAgICAgICAgICAgICAgICB9KSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW21vZGUsIGxvYWRlZERhdGFdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpZCkgcmV0dXJuO1xuICAgICAgICBpZiAodmVuZG9yVGF4ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2ZW5kb3JUYXhlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXModmVuZG9yVGF4ZXMubWFwKHQgPT4gKHtcbiAgICAgICAgICAgICAgICB0YXhfaWQ6IHQuaWQsXG4gICAgICAgICAgICAgICAgdGF4X25hbWU6IHQubmFtZSxcbiAgICAgICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICAgICAgYW1vdW50OiAwLFxuICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgfVxuICAgIH0sIFtpZCwgdmVuZG9yVGF4ZXNdKTtcblxuICAgIC8vIENhcmdhciBpbXB1ZXN0b3MgZGUgdGlwbyBwZXJjZXBjacOzbiAodGF4X3R5cGUgMilcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBnZXRBbGw8VGF4PigndGF4ZXMnLCB7IHR5cGU6ICcyJyB9KVxuICAgICAgICAgICAgLnRoZW4ocmVzID0+IHNldFBlcmNlcHRpb25UYXhlcyhyZXMuZGF0YSB8fCBbXSkpXG4gICAgICAgICAgICAuY2F0Y2goKCkgPT4gc2V0UGVyY2VwdGlvblRheGVzKFtdKSk7XG4gICAgfSwgW10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlkIHx8IHZlbmRvclRheGVzLmxlbmd0aCAhPT0gMSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IGl0ZW1zLnJlZHVjZSgocywgaSkgPT4gcyArIE51bWJlcihpLnF1YW50aXR5KSAqIE51bWJlcihpLnVuaXRfcHJpY2UpLCAwKTtcbiAgICAgICAgY29uc3Qgd2l0aG91dHRheF9hbW91bnQgPSBmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCA/PyAwO1xuICAgICAgICBjb25zdCBjYWxjdWxhdGVkID0gY2FsY3VsYXRlTm90ZUxldmVsVGF4ZXMoc3VidG90YWwsIHdpdGhvdXR0YXhfYW1vdW50LCB2ZW5kb3JUYXhlcyk7XG4gICAgICAgIHNldEFwcGxpZWRUYXhlcyhjYWxjdWxhdGVkKTtcbiAgICB9LCBbaWQsIGl0ZW1zLCBmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCwgdmVuZG9yVGF4ZXNdKTtcblxuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZUFwcGxpZWRUYXhBbW91bnQgPSAodGF4X2lkOiBudW1iZXIsIGFtb3VudDogbnVtYmVyKSA9PiB7XG4gICAgICAgIHNldEFwcGxpZWRUYXhlcyhwcmV2ID0+IHByZXYubWFwKHQgPT4gdC50YXhfaWQgPT09IHRheF9pZCA/IHsgLi4udCwgYW1vdW50IH0gOiB0KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgIGNvbnN0IHRvdGFsVGF4ZXMgPSBhcHBsaWVkVGF4ZXMucmVkdWNlKChzLCB0KSA9PiBzICsgKE51bWJlcih0LmFtb3VudCkgfHwgMCksIDApO1xuICAgICAgICBjb25zdCBwZXJjZXBjaW9uZXNUb3RhbCA9IHBlcmNlcHRpb25Sb3dzLnJlZHVjZSgocywgcikgPT4gcyArIChOdW1iZXIoci5hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3QgdG90YWwgPSBzdWJ0b3RhbCArIHRvdGFsVGF4ZXMgKyBwZXJjZXBjaW9uZXNUb3RhbDtcbiAgICAgICAgcmV0dXJuIHsgc3VidG90YWwsIHRvdGFsVGF4ZXMsIHBlcmNlcGNpb25lc1RvdGFsLCB0b3RhbCwgd2l0aG91dHRheF9hbW91bnQ6IGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50ID8/IDAgfTtcbiAgICB9LCBbaXRlbXMsIGFwcGxpZWRUYXhlcywgcGVyY2VwdGlvblJvd3MsIGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50XSk7XG5cbiAgICBjb25zdCBhZ2dyZWdhdGVkVGF4ZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgIGNvbnN0IHdpdGhvdXR0YXhfYW1vdW50ID0gZm9ybURhdGEud2l0aG91dHRheF9hbW91bnQgPz8gMDtcbiAgICAgICAgaWYgKHZlbmRvclRheGVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgY29uc3QgYXBwbGllZCA9IGNhbGN1bGF0ZU5vdGVMZXZlbFRheGVzKHN1YnRvdGFsLCB3aXRob3V0dGF4X2Ftb3VudCwgdmVuZG9yVGF4ZXMpO1xuICAgICAgICAgICAgcmV0dXJuIGFwcGxpZWQubWFwKHQgPT4gKHsgdGF4X25hbWU6IHQudGF4X25hbWUsIHJhdGU6IHQucmF0ZSwgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpLCB0YXhfaWQ6IHQudGF4X2lkIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXBwbGllZFRheGVzLm1hcCh0ID0+ICh7IHRheF9uYW1lOiB0LnRheF9uYW1lLCByYXRlOiB0LnJhdGUsIGFtb3VudDogTnVtYmVyKHQuYW1vdW50KSwgdGF4X2lkOiB0LnRheF9pZCB9KSk7XG4gICAgfSwgW2l0ZW1zLCBmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCwgdmVuZG9yVGF4ZXMsIGFwcGxpZWRUYXhlc10pO1xuXG4gICAgY29uc3QgY2xlYXJGb3JtID0gKCkgPT4ge1xuICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmRlZmF1bHRJbml0aWFsIH0pO1xuICAgICAgICBzZXRJdGVtcyhbXSk7XG4gICAgICAgIHNldFZlbmRvclRheGVzKFtdKTtcbiAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgc2V0UGVyY2VwdGlvblJvd3MoW10pO1xuICAgICAgICBzZXRQdXJjaGFzZUNvZGVJbnB1dCgnJyk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVZlbmRvclNlbGVjdGVkID0gYXN5bmMgKHZlbmRvcjogUHJvdmVlZG9yKSA9PiB7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmdWxsID0gYXdhaXQgZ2V0QnlJZDxQcm92ZWVkb3I+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCB2ZW5kb3IuaWQpO1xuICAgICAgICAgICAgY29uc3QgdGF4ZXMgPSBmdWxsLnJlbGF0ZWRUYXhlcyB8fCBbXTtcbiAgICAgICAgICAgIHNldFZlbmRvclRheGVzKHRheGVzKTtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIHZlbmRvcl9pZDogZnVsbC5pZCxcbiAgICAgICAgICAgICAgICB2ZW5kb3JfbmFtZTogZnVsbC5uYW1lIHx8ICcnLFxuICAgICAgICAgICAgICAgIHZlbmRvcl9jb2RlOiBmdWxsLnZlbmRvcl9jb2RlIHx8ICcnLFxuICAgICAgICAgICAgICAgIHB1cmNoYXNlX2lkOiAwLFxuICAgICAgICAgICAgICAgIHB1cmNoYXNlOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBmdWxsLnNlcmllID8/IHByZXY/LnNlcmllcyA/PyAnQicsXG4gICAgICAgICAgICAgICAgY3VycmVuY3lfaWQ6IHByZXY/LmN1cnJlbmN5X2lkID8/IDEsXG4gICAgICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogcHJldj8uZXhjaGFuZ2VfcmF0ZSA/PyAxLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgc2V0SXRlbXMoW10pO1xuICAgICAgICAgICAgc2V0UHVyY2hhc2VDb2RlSW5wdXQoJycpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnUHJvdmVlZG9yIHNlbGVjY2lvbmFkby4gRWxpamEgbGEgY29tcHJhLicpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjYXJnYXIgZWwgcHJvdmVlZG9yLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlVmVuZG9yQ29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY29kZSA9IGZvcm1EYXRhLnZlbmRvcl9jb2RlPy50cmltKCk7XG4gICAgICAgIGlmICghY29kZSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbygnSW5ncmVzZSBlbCBjw7NkaWdvIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxQcm92ZWVkb3I+KHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBbeyBmaWVsZE5hbWU6ICd2ZW5kb3JfY29kZScsIHZhbHVlOiBjb2RlIH1dKTtcbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVZlbmRvclNlbGVjdGVkKGZvdW5kKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyBwcm92ZWVkb3IgY29uIGPDs2RpZ28gXCIke2NvZGV9XCIuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIHByb3ZlZWRvci4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVB1cmNoYXNlU2VsZWN0ZWQgPSBhc3luYyAocHVyY2hhc2U6IFB1cmNoYXNlKSA9PiB7XG4gICAgICAgIGlmICghZm9ybURhdGEudmVuZG9yX2lkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdTZWxlY2Npb25lIHByaW1lcm8gdW4gcHJvdmVlZG9yLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmdWxsID0gYXdhaXQgZ2V0QnlJZDxQdXJjaGFzZT4oY29tcHJhc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgcHVyY2hhc2UuaWQpO1xuICAgICAgICAgICAgaWYgKGZ1bGwudmVuZG9yX2lkICE9PSBmb3JtRGF0YS52ZW5kb3JfaWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTGEgY29tcHJhIG5vIHBlcnRlbmVjZSBhbCBwcm92ZWVkb3Igc2VsZWNjaW9uYWRvLicpO1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHZlbmRvck5hbWUgPSBmdWxsLnZlbmRvcj8ubmFtZSB8fCBmdWxsLnZlbmRvcl9uYW1lIHx8ICcnO1xuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgcHVyY2hhc2VfaWQ6IGZ1bGwuaWQsXG4gICAgICAgICAgICAgICAgcHVyY2hhc2U6IHsgaWQ6IGZ1bGwuaWQsIGludGVybmFsX3ZvdWNoZXI6IGZ1bGwuaW50ZXJuYWxfdm91Y2hlciB8fCBTdHJpbmcoZnVsbC5pZCksIHB1cmNoYXNlX2RhdGU6IGZ1bGwucHVyY2hhc2VfZGF0ZSB9LFxuICAgICAgICAgICAgICAgIHZlbmRvcl9pZDogZnVsbC52ZW5kb3JfaWQsXG4gICAgICAgICAgICAgICAgdmVuZG9yX25hbWU6IHZlbmRvck5hbWUsXG4gICAgICAgICAgICAgICAgc2VyaWVzOiBmdWxsLnNlcmllcyB8fCBwcmV2Py5zZXJpZXMgfHwgJ0InLFxuICAgICAgICAgICAgICAgIGN1cnJlbmN5X2lkOiBmdWxsLmN1cnJlbmN5X2lkID8/IHByZXY/LmN1cnJlbmN5X2lkID8/IDEsXG4gICAgICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogZnVsbC5leGNoYW5nZV9yYXRlID8/IDEsXG4gICAgICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICBjb25zdCBwcm9kdWN0cyA9IGZ1bGwucHJvZHVjdHMgfHwgW107XG4gICAgICAgICAgICBjb25zdCBuZXdJdGVtczogRm9ybUl0ZW1bXSA9IHByb2R1Y3RzLm1hcCgocDogUHJvZHVjdFB1cmNoYXNlSXRlbSwgaWR4OiBudW1iZXIpID0+ICh7XG4gICAgICAgICAgICAgICAgcHJvZHVjdF9pZDogcC5wcm9kdWN0X2lkLFxuICAgICAgICAgICAgICAgIHByb2R1Y3RfY29kZTogcC5wcm9kdWN0X2NvZGUsXG4gICAgICAgICAgICAgICAgcHJvZHVjdF9uYW1lOiBwLnByb2R1Y3RfbmFtZSxcbiAgICAgICAgICAgICAgICBsaW5lX251bWJlcjogaWR4ICsgMSxcbiAgICAgICAgICAgICAgICBxdWFudGl0eTogcC5xdWFudGl0eSxcbiAgICAgICAgICAgICAgICB1bml0X3ByaWNlOiBwLnByaWNlX2Nvc3QsXG4gICAgICAgICAgICAgICAgY29zdF9wcmljZTogcC5wcmljZV9jb3N0LFxuICAgICAgICAgICAgICAgIGRpc2NvdW50X3BlcmNlbnRhZ2U6IDAsXG4gICAgICAgICAgICAgICAgdGF4ZXM6IFtdLFxuICAgICAgICAgICAgICAgIHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIHNldEl0ZW1zKG5ld0l0ZW1zKTtcbiAgICAgICAgICAgIHNldFB1cmNoYXNlQ29kZUlucHV0KGZ1bGwuaW50ZXJuYWxfdm91Y2hlciB8fCBTdHJpbmcoZnVsbC5pZCkpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnQ29tcHJhIGNhcmdhZGEuIFJldmlzZSBsb3Mgw610ZW1zIGUgaW1wdWVzdG9zLicpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjYXJnYXIgbGEgY29tcHJhLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUHVyY2hhc2VDb2RlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWZvcm1EYXRhLnZlbmRvcl9pZCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybignU2VsZWNjaW9uZSBwcmltZXJvIHVuIHByb3ZlZWRvci4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjb2RlID0gcHVyY2hhc2VDb2RlSW5wdXQudHJpbSgpO1xuICAgICAgICBpZiAoIWNvZGUpIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oJ0luZ3Jlc2UgZWwgbsO6bWVybyBkZSBsYSBjb21wcmEuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxQdXJjaGFzZT4oY29tcHJhc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgW3sgZmllbGROYW1lOiAnaW50ZXJuYWxfdm91Y2hlcicsIHZhbHVlOiBjb2RlIH1dKTtcbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZVB1cmNoYXNlU2VsZWN0ZWQoZm91bmQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgZW5jb250csOzIHVuYSBjb21wcmEgY29uIGVzZSBuw7ptZXJvLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGJ1c2NhciBsYSBjb21wcmEuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RGcm9tTW9kYWwgPSAoc2VsZWN0ZWQ6IGFueSkgPT4ge1xuICAgICAgICBpZiAoZWRpdGluZ1RhcmdldCA9PT0gJ3ZlbmRvcicpIHtcbiAgICAgICAgICAgIGhhbmRsZVZlbmRvclNlbGVjdGVkKHNlbGVjdGVkIGFzIFByb3ZlZWRvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBoYW5kbGVQdXJjaGFzZVNlbGVjdGVkKHNlbGVjdGVkIGFzIFB1cmNoYXNlKTtcbiAgICAgICAgfVxuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KG51bGwpO1xuICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUl0ZW1DaGFuZ2UgPSAoaW5kZXg6IG51bWJlciwgZmllbGQ6IGtleW9mIFB1cmNoYXNlQ3JlZGl0Tm90ZUl0ZW0sIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2Lm1hcCgoaXRlbSwgaSkgPT4gKGkgPT09IGluZGV4ID8geyAuLi5pdGVtLCBbZmllbGRdOiB2YWx1ZSB9IDogaXRlbSkpKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlSXRlbSA9IChpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybURhdGEudmVuZG9yX2lkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdTZWxlY2Npb25lIHVuIHByb3ZlZWRvci4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWZvcm1EYXRhLnB1cmNoYXNlX2lkKSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdTZWxlY2Npb25lIHVuYSBjb21wcmEuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5zZXJpZXMpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0xhIHNlcmllIGVzIG9ibGlnYXRvcmlhLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0RlYmUgaGFiZXIgYWwgbWVub3MgdW4gw610ZW0uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0YXhlc1R5cGUxID0gYXBwbGllZFRheGVzXG4gICAgICAgICAgICAuZmlsdGVyKHQgPT4gTnVtYmVyKHQuYW1vdW50KSA+IDApXG4gICAgICAgICAgICAubWFwKHQgPT4gKHsgLi4udCwgdGF4X3R5cGU6IDEgYXMgY29uc3QgfSkpO1xuXG4gICAgICAgIGNvbnN0IHRheGVzVHlwZTIgPSBwZXJjZXB0aW9uUm93c1xuICAgICAgICAgICAgLmZpbHRlcihyID0+IHIudGF4X2lkICE9IG51bGwgJiYgTnVtYmVyKHIuYW1vdW50KSA+IDApXG4gICAgICAgICAgICAubWFwKHIgPT4gKHtcbiAgICAgICAgICAgICAgICB0YXhfaWQ6IHIudGF4X2lkISxcbiAgICAgICAgICAgICAgICB0YXhfbmFtZTogci50YXhfbmFtZSA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgcmF0ZTogMCxcbiAgICAgICAgICAgICAgICBhbW91bnQ6IHIuYW1vdW50LFxuICAgICAgICAgICAgICAgIHRheF90eXBlOiAyIGFzIGNvbnN0LFxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IFBhcnRpYWw8UHVyY2hhc2VDcmVkaXROb3RlPiA9IHtcbiAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxuICAgICAgICAgICAgc2VyaWVzOiBmb3JtRGF0YS5zZXJpZXMgfHwgJ0InLFxuICAgICAgICAgICAgcHVyY2hhc2VfaWQ6IGZvcm1EYXRhLnB1cmNoYXNlX2lkLFxuICAgICAgICAgICAgdmVuZG9yX2lkOiBmb3JtRGF0YS52ZW5kb3JfaWQsXG4gICAgICAgICAgICB2ZW5kb3JfY29kZTogZm9ybURhdGEudmVuZG9yX2NvZGUgPz8gdW5kZWZpbmVkLFxuICAgICAgICAgICAgY3VycmVuY3lfaWQ6IGZvcm1EYXRhLmN1cnJlbmN5X2lkID8/IDEsXG4gICAgICAgICAgICBpc3N1ZV9kYXRlOiBmb3JtRGF0YS5pc3N1ZV9kYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiBjYWxjdWxhdGVkVG90YWxzLnRvdGFsLFxuICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogZm9ybURhdGEuZXhjaGFuZ2VfcmF0ZSA/PyAxLFxuICAgICAgICAgICAgZGlzY291bnRfcGVyY2VudGFnZTogZm9ybURhdGEuZGlzY291bnRfcGVyY2VudGFnZSA/PyAwLFxuICAgICAgICAgICAgc3RhdHVzOiBmb3JtRGF0YS5zdGF0dXMgfHwgJ0RSQUZUJyxcbiAgICAgICAgICAgIHJlamVjdGlvbl9yZWFzb246IGZvcm1EYXRhLnJlamVjdGlvbl9yZWFzb24gPz8gbnVsbCxcbiAgICAgICAgICAgIG5vdGVzOiBmb3JtRGF0YS5ub3RlcyA/PyBudWxsLFxuICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgICAgICAgICAgd2l0aG91dHRheF9hbW91bnQ6IGZvcm1EYXRhLndpdGhvdXR0YXhfYW1vdW50ID8/IDAsXG4gICAgICAgICAgICBpdGVtczogaXRlbXMubWFwKCh7IHRlbXBJZCwgLi4ucmVzdCB9KSA9PiAoeyAuLi5yZXN0LCB0YXhlczogcmVzdC50YXhlcyA/PyBbXSB9KSksXG4gICAgICAgICAgICB0YXhlczogWy4uLnRheGVzVHlwZTEsIC4uLnRheGVzVHlwZTJdIGFzIHVua25vd24gYXMgQXBwbGllZFRheFtdLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBzYXZlSXRlbShwYXlsb2FkIGFzIFBhcnRpYWw8UHVyY2hhc2VDcmVkaXROb3RlPik7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKCdOb3RhIGRlIENyw6lkaXRvIChDb21wcmEpIGd1YXJkYWRhLicpO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgZ3VhcmRhci4nKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZ0RhdGEpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG5cbiAgICBjb25zdCBpbnB1dFN0eWxlID0gXCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiO1xuXG4gICAgY29uc3QgcHVyY2hhc2VNb2RhbENvbmZpZyA9IGZvcm1EYXRhLnZlbmRvcl9pZFxuICAgICAgICA/IHsgLi4uY29tcHJhc01vZHVsZUNvbmZpZywgaW5pdGlhbEZpbHRlcnM6IHsgdmVuZG9yX2lkOiBmb3JtRGF0YS52ZW5kb3JfaWQgfSB9XG4gICAgICAgIDogY29tcHJhc01vZHVsZUNvbmZpZztcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LTYgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgIHsoaXNMb2FkaW5nIHx8IHNhdmluZykgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTUwIGJnLXdoaXRlLzgwIHJvdW5kZWQtbGcgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmFja2Ryb3AtYmx1ci1bMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1pbmRpZ28tNjAwIGFuaW1hdGUtc3BpbiBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+UHJvY2VzYW5kby4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgIHttb2RlID09PSAnY3JlYXRlJyA/ICdOdWV2YSBOb3RhIGRlIENyw6lkaXRvIChDb21wcmEpJyA6IGBFZGl0YXIgTm90YSAke2Zvcm1EYXRhLnZvdWNoZXJfbnVtYmVyIHx8IGlkfWB9XG4gICAgICAgICAgICA8L2gxPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlByb3ZlZWRvciAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLnZlbmRvcl9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS52ZW5kb3JfbmFtZSB8fCBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB2ZW5kb3JfY29kZTogYyB8fCAnJyB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZVZlbmRvckNvZGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiB7IHNldE1vZGFsQ29uZmlnKHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIGFzIE1vZHVsZUNvbmZpZzxhbnk+KTsgc2V0RWRpdGluZ1RhcmdldCgndmVuZG9yJyk7IHNldElzTW9kYWxPcGVuKHRydWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXtjbGVhckZvcm19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5TZXJpZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2VyaWVzIHx8ICdCJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgc2VyaWVzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBXCI+QTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJcIj5CPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1wiPkM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJYXCI+WDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZhY3R1cmEgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtwdXJjaGFzZUNvZGVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEucHVyY2hhc2VfaWQgPyAoZm9ybURhdGEucHVyY2hhc2U/LmludGVybmFsX3ZvdWNoZXIgPz8gYENvbXByYSAjJHtmb3JtRGF0YS5wdXJjaGFzZV9pZH1gKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhjKSA9PiBzZXRQdXJjaGFzZUNvZGVJbnB1dChjID8/ICcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17aGFuZGxlUHVyY2hhc2VDb2RlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4geyBzZXRNb2RhbENvbmZpZyhwdXJjaGFzZU1vZGFsQ29uZmlnIGFzIE1vZHVsZUNvbmZpZzxhbnk+KTsgc2V0RWRpdGluZ1RhcmdldCgncHVyY2hhc2UnKTsgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHsgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwdXJjaGFzZV9pZDogMCwgcHVyY2hhc2U6IHVuZGVmaW5lZCB9KSk7IHNldEl0ZW1zKFtdKTsgc2V0UHVyY2hhc2VDb2RlSW5wdXQoJycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFmb3JtRGF0YS52ZW5kb3JfaWR9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GZWNoYSBFbWlzacOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmlzc3VlX2RhdGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGlzc3VlX2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX0gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk1vdGl2byByZWNoYXpvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucmVqZWN0aW9uX3JlYXNvbiB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcmVqZWN0aW9uX3JlYXNvbjogZS50YXJnZXQudmFsdWUgfHwgbnVsbCB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk9wY2lvbmFsXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk5vdGFzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vdGVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBub3RlczogZS50YXJnZXQudmFsdWUgfHwgbnVsbCB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2l0ZW1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTRcIj7DjXRlbXM8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlByb2R1Y3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+Q2FudC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBoaWRkZW5cIj5BY2Npw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWIgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbS50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHJvZHVjdF9uYW1lfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+KHtpdGVtLnByb2R1Y3RfY29kZX0pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0ucXVhbnRpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAncXVhbnRpdHknLCBudW0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjAgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnVuaXRfcHJpY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndW5pdF9wcmljZScsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0yNCBweC0yIHB5LTEgdGV4dC1yaWdodCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LW1lZGl1bVwiPntmb3JtYXRWYWx1ZShsaW5lU3ViLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtY2VudGVyIGhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlSXRlbShpbmRleCl9IGNsYXNzTmFtZT1cInAtMSB0ZXh0LXJlZC02MDAgaG92ZXI6dGV4dC1yZWQtOTAwXCI+RWxpbWluYXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTIgcC00IGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgYXBsaWNhZG9zPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ3JpZC1jb2xzLTMgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGNvbC1zcGFuLTJcIj5WYWxvciBObyBHcmF2YWRvIChubyBncmF2YWRvKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgd2l0aG91dHRheF9hbW91bnQ6IG51bSA/PyAwIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge2FnZ3JlZ2F0ZWRUYXhlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkltcHVlc3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlRhc2EgKCUpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk1vbnRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubWFwKCh0YXgsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3RheC50YXhfaWQgPz8gaWR4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPnt0YXgudGF4X25hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPnt0YXgucmF0ZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZlbmRvclRheGVzLmxlbmd0aCA+IDEgJiYgdHlwZW9mIHRheC50YXhfaWQgPT09ICdudW1iZXInID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGF4LmFtb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVBcHBsaWVkVGF4QW1vdW50KHRheC50YXhfaWQgYXMgbnVtYmVyLCBudW0gPz8gMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjQgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgaW1wdWVzdG9zIGFwbGljYWRvcy48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBtdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBtYi0yXCI+UGVyY2VwY2lvbmVzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uVGF4ZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBwZXJjZXBjaW9uZXMgY29uZmlndXJhZGFzLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uUm93cy5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyb3cudGVtcElkfSBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cm93LnRheF9pZCA/PyAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBlcmNlcHRpb25Sb3dzKHByZXYgPT4gcHJldi5tYXAociA9PiByLnRlbXBJZCA9PT0gcm93LnRlbXBJZCA/IHsgLi4uciwgdGF4X2lkOiBudWxsLCB0YXhfbmFtZTogbnVsbCB9IDogcikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRheCA9IHBlcmNlcHRpb25UYXhlcy5maW5kKHQgPT4gdC5pZCA9PT0gTnVtYmVyKHZhbCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGF4KSByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWxyZWFkeVVzZWQgPSBwZXJjZXB0aW9uUm93cy5zb21lKHIgPT4gci50ZW1wSWQgIT09IHJvdy50ZW1wSWQgJiYgci50YXhfaWQgPT09IHRheC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFscmVhZHlVc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0VzYSBwZXJjZXBjacOzbiB5YSBlc3TDoSBlbiBsYSBsaXN0YS4gTm8gc2UgcHVlZGUgcmVwZXRpci4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYubWFwKHIgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgci50ZW1wSWQgPT09IHJvdy50ZW1wSWQgPyB7IC4uLnIsIHRheF9pZDogdGF4LmlkLCB0YXhfbmFtZTogdGF4Lm5hbWUgfSA6IHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yIHctZnVsbCBweC0yIHB5LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjY2lvbmUgcGVyY2VwY2nDs248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZXB0aW9uVGF4ZXMubWFwKCh0YXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dGF4LmlkfSB2YWx1ZT17dGF4LmlkfSBkaXNhYmxlZD17cGVyY2VwdGlvblJvd3Muc29tZShyID0+IHIudGVtcElkICE9PSByb3cudGVtcElkICYmIHIudGF4X2lkID09PSB0YXguaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RheC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Jvdy5hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYubWFwKHIgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgci50ZW1wSWQgPT09IHJvdy50ZW1wSWQgPyB7IC4uLnIsIGFtb3VudDogbnVtID8/IDAgfSA6IHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQZXJjZXB0aW9uUm93cyhwcmV2ID0+IHByZXYuZmlsdGVyKHIgPT4gci50ZW1wSWQgIT09IHJvdy50ZW1wSWQpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwIHAtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJRdWl0YXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGVyY2VwdGlvblJvd3MocHJldiA9PiBbLi4ucHJldiwgeyB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksIHRheF9pZDogbnVsbCwgdGF4X25hbWU6IG51bGwsIGFtb3VudDogMCB9XSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIG10LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyYXktNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEFncmVnYXIgcGVyY2VwY2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlN1YnRvdGFsOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj48c3Bhbj5WYWxvciBObyBHcmF2YWRvIChubyBncmF2YWRvKTo8L3NwYW4+PHNwYW4+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMud2l0aG91dHRheF9hbW91bnQgPz8gMCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc21cIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+SW1wdWVzdG9zOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5QZXJjZXBjaW9uZXM6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj4rIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnBlcmNlcGNpb25lc1RvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gcHQtMiBib3JkZXItdCBtdC0yXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5Ub3RhbDo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtaW5kaWdvLTYwMFwiPntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgaG92ZXI6YmctZ3JheS01MFwiPkNhbmNlbGFyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlU2F2ZX0gZGlzYWJsZWQ9e2lzTG9hZGluZyB8fCBzYXZpbmcgfHwgaXRlbXMubGVuZ3RoID09PSAwfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYVNhdmUgY2xhc3NOYW1lPVwibXItMlwiIC8+IEd1YXJkYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiB7IHNldElzTW9kYWxPcGVuKGZhbHNlKTsgc2V0RWRpdGluZ1RhcmdldChudWxsKTsgfX0gb25TZWxlY3Q9e2hhbmRsZVNlbGVjdEZyb21Nb2RhbH0gY29uZmlnPXttb2RhbENvbmZpZ30gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9ub3Rhc19jcmVkaXRvX2NvbXByYS9wYWdlcy9Ob3Rhc0NyZWRpdG9Db21wcmFGb3JtUGFnZS50c3gifQ==