import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash, FaPercentage, FaTags, FaWarehouse } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { useSupervisorLowProfitAuth } from "/src/hooks/useSupervisorLowProfitAuth.tsx";
import { salesOrdersModuleConfig } from "/src/features/pedidos_venta/pedidos_venta_config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { articulosModuleConfig, articulosItemSearchFilters } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { AlertModal } from "/src/components/ui/AlertModal.tsx";
import { ToggleSwitch } from "/src/components/ui/ToggleSwitch.tsx";
import { productCostToBaseCostPrice } from "/src/utils/productCostToBase.ts";
import { formatValue } from "/src/utils/formatters.ts";
import {} from "/src/types/appliedTaxes.ts";
import {
  computeExemptDocumentTotal,
  getEffectiveClientTaxes,
  isClientLeyExportacionTdfExempt,
  sanitizeTaxPayloadForExemptClient
} from "/src/utils/clientTaxExemption.ts";
import { computeSalesAppliedTaxes } from "/src/utils/salesRelatedTaxComputation.ts";
import { getById, searchByField } from "/src/services/apiService.ts";
import { ItemTaxModal } from "/src/components/common/ItemTaxModal.tsx";
import { ProductHistoryModal } from "/src/components/common/ProductHistoryModal.tsx";
import { initialHistoryModalState, priceListColumns } from "/src/types/historyModal.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const roundToTwoDecimals = (num) => {
  return Math.round(num * 100) / 100;
};
const EMPTY_ITEM = {
  id: Date.now(),
  line_number: 0,
  product_id: 0,
  product_code: "",
  product_name: "",
  quantity: 1,
  pending_quantity: 0,
  unit_price: 0,
  cost_price: 0,
  // --- MODIFICADO: Usamos discount_amount ---
  discount_amount: 0,
  taxes: [],
  base_sales_price: 0,
  // ✅ NUEVO: Valor base
  base_cost_price: 0,
  // ✅ NUEVO: Valor base
  stock_quantity: 0
};
const defaultInitialData = {
  id: 0,
  order_number: "",
  series: "",
  status: "1",
  purchase_order_number: null,
  order_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  // Default a hoy
  delivery_date: null,
  total_amount: 0,
  notes: null,
  delivery_address: null,
  // --- MODIFICADO: Usamos discount_amount ---
  discount_amount: 0,
  exchange_rate: null,
  is_exchange_rate_fixed: false,
  client_id: null,
  salesperson_id: null,
  buyer_id: null,
  currency_id: null,
  transport_id: null,
  // ✅ NUEVO: Campos de código añadidos al estado inicial
  client_code: null,
  salesperson_code: null,
  buyer_code: null,
  currency_code: null,
  transport_code: null,
  // --- AQUÍ ESTÁ LA CORRECCIÓN ---
  // Objetos relacionales opcionales
  client: void 0,
  salesperson: void 0,
  buyer: void 0,
  currency: void 0,
  transport: void 0,
  // --- FIN CORRECCIÓN ---
  items: [],
  taxes: [],
  appliedTaxes: [],
  has_item_level_taxes: false
  // Default
};
const isLineOverAvailableStock = (item) => {
  if (!item.product_id) return false;
  const q = Number(item.quantity) || 0;
  const s = Number(item.stock_quantity) || 0;
  return q > s;
};
const stockExcessMessage = (item) => {
  const q = Number(item.quantity) || 0;
  const s = Number(item.stock_quantity) || 0;
  const name = item.product_name || "el artículo";
  const code = item.product_code ? ` (${item.product_code})` : "";
  return `Está solicitando ${q} unidad(es) de "${name}"${code} pero el stock disponible es ${s}.`;
};
const costListColumns = [
  { header: "Fecha Compra", accessor: "purchase_date", format: "date" },
  { header: "Factura Compra", accessor: "document_number" },
  { header: "Proveedor", accessor: "vendor_name" },
  { header: "Costo Unit.", accessor: "price_cost", format: "currency" },
  { header: "Cantidad", accessor: "quantity" }
];
export const PedidosVentaFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData, error } = useCrudItem(salesOrdersModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(salesOrdersModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState([]);
  const [clientTaxes, setClientTaxes] = useState([]);
  const [clientTaxCondition, setClientTaxCondition] = useState(null);
  const [isClientTaxExempt, setIsClientTaxExempt] = useState(false);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  const [editingItemIndex, setEditingItemIndex] = useState(null);
  const [isItemTaxModalOpen, setIsItemTaxModalOpen] = useState(false);
  const [currentItemIndexForTax, setCurrentItemIndexForTax] = useState(null);
  const [historyModalState, setHistoryModalState] = useState(initialHistoryModalState);
  const [stockAlert, setStockAlert] = useState({
    open: false,
    title: "",
    message: ""
  });
  const pendingAfterStockAckRef = useRef(null);
  const { gateSave, authModal } = useSupervisorLowProfitAuth();
  const [clientAddresses, setClientAddresses] = useState([]);
  const [isCustomAddress, setIsCustomAddress] = useState(false);
  const [tempDeliveryAddress, setTempDeliveryAddress] = useState("");
  const [simboloMoneda, setSimboloMoneda] = useState("$");
  const effectiveExchangeRate = useMemo(() => {
    const rate = Number(formData.exchange_rate) || 1;
    return formData.currency_code === "01" ? 1 : rate;
  }, [formData.exchange_rate, formData.currency_code]);
  const calculateItemTaxes = (item, taxes = clientTaxes) => {
    if (!taxes || taxes.length === 0) return [];
    const taxBase = Number(item.quantity) * Number(item.unit_price) - (Number(item.discount_amount) || 0);
    return computeSalesAppliedTaxes({
      netBase: taxBase,
      clientTaxCondition,
      taxes
    });
  };
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      const hydratedData = { ...loadedData };
      if (hydratedData.client && clientesModuleConfig.relationalFields) {
        const { codeField, nameField } = clientesModuleConfig.relationalFields;
        hydratedData.client_code = hydratedData.client[codeField];
        hydratedData.client_name = hydratedData.client[nameField];
      }
      if (hydratedData.salesperson && vendedoresModuleConfig.relationalFields) {
        const { codeField, nameField } = vendedoresModuleConfig.relationalFields;
        const rel = hydratedData.salesperson;
        hydratedData.salesperson_code = hydratedData.salesperson_code ?? rel[codeField];
        hydratedData.salesperson_name = hydratedData.salesperson_name ?? rel[nameField];
      }
      if (hydratedData.buyer && compradoresModuleConfig.relationalFields) {
        const { codeField, nameField } = compradoresModuleConfig.relationalFields;
        const rel = hydratedData.buyer;
        hydratedData.buyer_code = hydratedData.buyer_code ?? rel[codeField];
        hydratedData.buyer_name = hydratedData.buyer_name ?? rel[nameField];
      }
      if (hydratedData.currency && monedasModuleConfig.relationalFields) {
        const { codeField, nameField } = monedasModuleConfig.relationalFields;
        const rel = hydratedData.currency;
        hydratedData.currency_code = hydratedData.currency_code ?? rel[codeField];
        hydratedData.currency_name = hydratedData.currency_name ?? rel[nameField];
      }
      if (hydratedData.transport && transportesModuleConfig.relationalFields) {
        const { codeField, nameField } = transportesModuleConfig.relationalFields;
        const rel = hydratedData.transport;
        hydratedData.transport_code = hydratedData.transport_code ?? rel[codeField];
        hydratedData.transport_name = hydratedData.transport_name ?? rel[nameField];
      }
      if (loadedData.client?.shipaddress) {
        setClientAddresses(loadedData.client.shipaddress);
        const isCustom = loadedData.delivery_address && !loadedData.client.shipaddress.includes(loadedData.delivery_address);
        setIsCustomAddress(!!isCustom);
        setTempDeliveryAddress(loadedData.delivery_address || "");
      } else {
        setTempDeliveryAddress(loadedData.delivery_address || "");
      }
      const isExemptOnLoad = isClientLeyExportacionTdfExempt(loadedData.client);
      setIsClientTaxExempt(isExemptOnLoad);
      if (loadedData.client) {
        setClientTaxCondition(loadedData.client.tax ?? null);
      }
      setFormData(isExemptOnLoad ? { ...hydratedData, has_item_level_taxes: false } : hydratedData);
      setItems(isExemptOnLoad ? (loadedData.items || []).map((item) => ({ ...item, taxes: [] })) : loadedData.items || []);
      if (isExemptOnLoad) {
        setAppliedTaxes([]);
      } else if (!loadedData.has_item_level_taxes) {
        setAppliedTaxes(loadedData.appliedTaxes || loadedData.taxes || []);
      }
    } else if (mode === "create") {
      setTempDeliveryAddress(defaultInitialData.delivery_address || "");
    }
  }, [mode, loadedData]);
  useEffect(() => {
    if (formData.client_id) {
      getById(clientesModuleConfig.endpoint, formData.client_id).then((clientData) => {
        const exempt = isClientLeyExportacionTdfExempt(clientData);
        const newClientTaxes = getEffectiveClientTaxes(clientData, clientData.relatedTaxes);
        setIsClientTaxExempt(exempt);
        setClientTaxCondition(clientData.tax ?? null);
        setClientTaxes(newClientTaxes);
        if (exempt) {
          setAppliedTaxes([]);
          setFormData((prev) => ({ ...prev, has_item_level_taxes: false }));
          setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
        } else if (formData.has_item_level_taxes) {
          setItems((prev) => prev.map((item) => ({
            ...item,
            taxes: calculateItemTaxes(item, newClientTaxes)
          })));
        }
      }).catch(() => {
        toast.error("No se pudieron cargar los impuestos del cliente.");
        setIsClientTaxExempt(false);
        setClientTaxCondition(null);
        setClientTaxes([]);
      });
    } else {
      setIsClientTaxExempt(false);
      setClientTaxCondition(null);
      setClientTaxes([]);
      setAppliedTaxes([]);
      if (formData.has_item_level_taxes) {
        setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
      }
    }
  }, [formData.client_id, formData.has_item_level_taxes]);
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((sum, item) => {
      return sum + Number(item.quantity) * Number(item.unit_price);
    }, 0);
    const totalItemDiscounts = items.reduce((sum, item) => {
      return sum + (Number(item.discount_amount) || 0);
    }, 0);
    const globalDiscountAmount = Number(formData.discount_amount) || 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (formData.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => {
          const itemTaxes = item.taxes || [];
          const itemTaxAmount = itemTaxes.reduce((itemSum, tax) => itemSum + Number(tax.amount), 0);
          return sum + itemTaxAmount;
        }, 0);
      } else {
        totalTaxes = appliedTaxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    const total = isClientTaxExempt ? computeExemptDocumentTotal(subtotal, totalItemDiscounts, globalDiscountAmount) : taxBase + totalTaxes;
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes, total };
  }, [items, formData.discount_amount, appliedTaxes, formData.has_item_level_taxes, isClientTaxExempt]);
  useEffect(() => {
    const exchangeRate = effectiveExchangeRate;
    if (isNaN(exchangeRate)) return;
    setItems((prevItems) => prevItems.map((item) => {
      const basePrice = Number(item.base_sales_price);
      const baseCost = Number(item.base_cost_price);
      if (basePrice === 0 && baseCost === 0) return item;
      const newItem = {
        ...item,
        // Convertimos: Precio Base / Tasa de Cambio
        unit_price: roundToTwoDecimals(basePrice / exchangeRate),
        cost_price: roundToTwoDecimals(baseCost / exchangeRate)
      };
      if (formData.has_item_level_taxes && !isClientTaxExempt) {
        newItem.taxes = calculateItemTaxes(newItem, clientTaxes);
      }
      return newItem;
    }));
  }, [effectiveExchangeRate, clientTaxes, formData.has_item_level_taxes, clientTaxCondition, isClientTaxExempt]);
  useEffect(() => {
    if (isClientTaxExempt) {
      setAppliedTaxes([]);
      return;
    }
    if (formData.has_item_level_taxes) {
      setAppliedTaxes([]);
      return;
    }
    if (clientTaxes.length > 0) {
      const { taxBase } = calculatedTotals;
      setAppliedTaxes(computeSalesAppliedTaxes({
        netBase: taxBase,
        clientTaxCondition,
        taxes: clientTaxes
      }));
    } else {
      setAppliedTaxes([]);
    }
  }, [calculatedTotals.taxBase, clientTaxes, formData.has_item_level_taxes, clientTaxCondition, isClientTaxExempt]);
  const applyHeaderSelection = (field, selectedItem) => {
    const moduleConfig = {
      "client": clientesModuleConfig,
      "salesperson": vendedoresModuleConfig,
      "buyer": compradoresModuleConfig,
      "currency": monedasModuleConfig,
      "transport": transportesModuleConfig
    }[field];
    if (!moduleConfig || !moduleConfig.relationalFields) {
      toast.error(`Error: Falta 'relationalFields' en la config de ${field}`);
      return;
    }
    const { codeField, nameField } = moduleConfig.relationalFields;
    setFormData((prev) => {
      const updatedData = { ...prev };
      if (selectedItem) {
        updatedData[`${field}_id`] = selectedItem.id;
        updatedData[`${field}_code`] = selectedItem[codeField];
        updatedData[`${field}_name`] = selectedItem[nameField];
        if (field === "client") {
          setClientTaxCondition(selectedItem.tax ?? null);
          const addresses = selectedItem.shipaddress || [];
          setClientAddresses(addresses);
          setIsCustomAddress(false);
          if (addresses.length > 0) {
            setTempDeliveryAddress(addresses[0]);
            updatedData.delivery_address = addresses[0];
          } else {
            setTempDeliveryAddress("");
            updatedData.delivery_address = null;
          }
          if (selectedItem.salesrep) {
            updatedData.salesperson_id = selectedItem.salesrep;
            updatedData.salesperson_code = selectedItem.salesRepRelation.code || null;
            updatedData.salesperson_name = selectedItem.salesRepRelation.name || null;
          }
          if (selectedItem.transport_id) {
            updatedData.transport_id = selectedItem.transport_id;
            updatedData.transport_code = selectedItem.transport_code || null;
            updatedData.transport_name = selectedItem.transport_name || null;
          }
          if (selectedItem.currency_id) {
            updatedData.currency_id = selectedItem.currency_id;
            updatedData.currency_code = selectedItem.currency_code || null;
            updatedData.currency_name = selectedItem.currency_name || null;
            updatedData.exchange_rate = selectedItem.currency?.exchange_rate || null;
            if (updatedData.currency_code !== "01")
              setSimboloMoneda("USD");
            else
              setSimboloMoneda("$");
          }
          if (selectedItem.buyer_id) {
            updatedData.buyer_id = selectedItem.buyer_id;
            updatedData.buyer_code = selectedItem.buyer_code || null;
            updatedData.buyer_name = selectedItem.buyer_name || null;
          }
        } else if (field === "currency") {
          updatedData.exchange_rate = selectedItem.exchange_rate || null;
          if (updatedData.currency_code !== "01")
            setSimboloMoneda("USD");
          else
            setSimboloMoneda("$");
        }
      }
      return updatedData;
    });
    if (field === "client") {
      setAppliedTaxes([]);
    }
  };
  const handleDeliveryAddressChange = (e) => {
    const value = e.target.value;
    if (value === "CUSTOM_NEW_ADDRESS") {
      setIsCustomAddress(true);
      setTempDeliveryAddress("");
    } else {
      setIsCustomAddress(false);
      setTempDeliveryAddress(value);
    }
  };
  const handleOpenModal = (target, config, itemIndex = null) => {
    setEditingTarget(target);
    setModalConfig(
      target === "item" ? { ...config, initialFilters: articulosItemSearchFilters } : config
    );
    setIsModalOpen(true);
    if (target === "item") {
      setEditingItemIndex(itemIndex);
    }
  };
  const handleSelectModal = async (selectedItem) => {
    if (!editingTarget) return;
    if (editingTarget === "item" && editingItemIndex !== null) {
      const skuValue = selectedItem.sku ? String(selectedItem.sku) : "";
      const product = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: "sku", value: skuValue },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      setItems((prevItems) => {
        const newItems = [...prevItems];
        const item = newItems[editingItemIndex];
        const { codeField, nameField } = articulosModuleConfig.relationalFields;
        const exchangeRate = effectiveExchangeRate;
        const basePrice = product.suggested_price || selectedItem.sale_price || 0;
        const baseCost = productCostToBaseCostPrice(
          product.cost_price ?? selectedItem.cost_price ?? 0,
          product.cost_currency,
          formData.exchange_rate
        );
        item.product_id = selectedItem.id;
        item.product_code = selectedItem[codeField];
        item.product_name = selectedItem[nameField];
        item.stock_quantity = product.stock_quantity ?? 0;
        item.unit_price = basePrice || 0;
        item.cost_price = baseCost || 0;
        item.base_sales_price = basePrice;
        item.base_cost_price = baseCost;
        item.unit_price = roundToTwoDecimals(basePrice / exchangeRate);
        item.cost_price = roundToTwoDecimals(baseCost / exchangeRate);
        if (formData.has_item_level_taxes && !isClientTaxExempt) {
          item.taxes = calculateItemTaxes(item, clientTaxes);
        } else {
          item.taxes = [];
        }
        newItems[editingItemIndex] = item;
        return newItems;
      });
      setEditingItemIndex(null);
    } else if (editingTarget !== "item") {
      applyHeaderSelection(editingTarget, selectedItem);
    }
    setIsModalOpen(false);
  };
  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    let finalValue = value;
    if (type === "checkbox") {
      finalValue = e.target.checked;
    }
    setFormData((prev) => ({ ...prev, [name]: finalValue }));
  };
  const handleItemChange = (index, e) => {
    const { name, value } = e.target;
    const exchangeRate = effectiveExchangeRate;
    const numFields = ["quantity", "unit_price", "discount_amount"];
    const storedValue = numFields.includes(name) ? value === "" ? 0 : Number(value) || 0 : value;
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const item = { ...newItems[index], [name]: storedValue };
      if (name === "unit_price") {
        const newValue = Number(storedValue) || 0;
        item.base_sales_price = newValue * exchangeRate;
        const baseCost = Number(item.base_cost_price) || 0;
        item.cost_price = roundToTwoDecimals(baseCost / exchangeRate);
      }
      if (formData.has_item_level_taxes && !isClientTaxExempt && (name === "quantity" || name === "unit_price" || name === "discount_amount")) {
        item.taxes = calculateItemTaxes(item, clientTaxes);
      } else if (name === "quantity" || name === "unit_price" || name === "discount_amount") {
        item.taxes = [];
      }
      newItems[index] = item;
      return newItems;
    });
  };
  const dispatchItemNumericChange = (index, name, value) => {
    handleItemChange(index, { target: { name, value: String(value) } });
  };
  const handleItemCodeSubmit = async (index) => {
    const item = items[index];
    if (!item.product_code) return;
    const { codeField, nameField } = articulosModuleConfig.relationalFields;
    try {
      const product = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: codeField, value: item.product_code },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      if (product) {
        setItems((prevItems) => {
          const newItems = [...prevItems];
          const exchangeRate = effectiveExchangeRate;
          const basePrice = product.suggested_price || 0;
          const baseCost = productCostToBaseCostPrice(
            product.cost_price || 0,
            product.cost_currency,
            formData.exchange_rate
          );
          const currentPrice = Number(newItems[index].unit_price) || 0;
          const currentCost = Number(newItems[index].cost_price) || 0;
          const calculatedPrice = roundToTwoDecimals(basePrice / exchangeRate);
          const calculatedCost = roundToTwoDecimals(baseCost / exchangeRate);
          const updatedItem = {
            ...newItems[index],
            product_id: product.id,
            product_code: product[codeField],
            product_name: product[nameField],
            base_sales_price: basePrice,
            base_cost_price: baseCost,
            stock_quantity: product.stock_quantity,
            unit_price: currentPrice > 0 ? currentPrice : calculatedPrice,
            cost_price: currentCost > 0 ? currentCost : calculatedCost
          };
          if (formData.has_item_level_taxes && !isClientTaxExempt) {
            updatedItem.taxes = calculateItemTaxes(updatedItem, clientTaxes);
          }
          newItems[index] = updatedItem;
          return newItems;
        });
        toast.success(`'${product[nameField]}' seleccionado.`);
      } else {
        toast.error(`No se encontró ningún artículo con el código "${item.product_code}".`);
      }
    } catch (err) {
      console.error("Error al buscar por código:", err);
      toast.error("Error al buscar artículo por código.");
    }
  };
  const handleItemCodeChange = (index, newCode) => {
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const item = { ...newItems[index] };
      item.product_code = newCode;
      item.product_id = 0;
      item.product_name = "";
      item.unit_price = 0;
      item.stock_quantity = 0;
      item.taxes = [];
      newItems[index] = item;
      return newItems;
    });
  };
  const handleItemAutocompleteSelect = async (index, product) => {
    const { codeField, nameField } = articulosModuleConfig.relationalFields;
    try {
      const skuValue = product.sku ? String(product.sku) : "";
      const fullProduct = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: codeField, value: skuValue },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      if (fullProduct) {
        setItems((prevItems) => {
          const newItems = [...prevItems];
          const exchangeRate = effectiveExchangeRate;
          const basePrice = fullProduct.suggested_price || 0;
          const baseCost = productCostToBaseCostPrice(
            fullProduct.cost_price || 0,
            fullProduct.cost_currency,
            formData.exchange_rate
          );
          const currentPrice = Number(newItems[index].unit_price) || 0;
          const currentCost = Number(newItems[index].cost_price) || 0;
          const calculatedPrice = roundToTwoDecimals(basePrice / exchangeRate);
          const calculatedCost = roundToTwoDecimals(baseCost / exchangeRate);
          const updatedItem = {
            ...newItems[index],
            product_id: fullProduct.id,
            product_code: fullProduct[codeField],
            product_name: fullProduct[nameField],
            base_sales_price: basePrice,
            base_cost_price: baseCost,
            stock_quantity: fullProduct.stock_quantity,
            unit_price: currentPrice > 0 ? currentPrice : calculatedPrice,
            cost_price: currentCost > 0 ? currentCost : calculatedCost
          };
          if (formData.has_item_level_taxes && !isClientTaxExempt) {
            updatedItem.taxes = calculateItemTaxes(updatedItem, clientTaxes);
          }
          newItems[index] = updatedItem;
          return newItems;
        });
      }
    } catch (error2) {
      console.error("Error al cargar producto completo:", error2);
    }
  };
  const handleItemClear = (index) => {
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const item = { ...newItems[index] };
      item.product_id = 0;
      item.product_code = "";
      item.product_name = "";
      item.unit_price = 0;
      item.stock_quantity = 0;
      item.taxes = [];
      newItems[index] = item;
      return newItems;
    });
  };
  const handleAddItem = () => {
    setItems((prev) => [...prev, { ...EMPTY_ITEM, id: 0, line_number: prev.length + 1 }]);
  };
  const handleRemoveItem = (index) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };
  const handleOpenItemTaxModal = (index) => {
    if (isClientTaxExempt) return;
    if (!formData.client_id) {
      toast.warn("Por favor, seleccione un cliente primero.");
      return;
    }
    setCurrentItemIndexForTax(index);
    setIsItemTaxModalOpen(true);
  };
  const handleSaveItemTaxes = (taxes) => {
    if (currentItemIndexForTax === null) return;
    setItems(
      (prevItems) => prevItems.map(
        (item, index) => index === currentItemIndexForTax ? { ...item, taxes } : item
      )
    );
    setCurrentItemIndexForTax(null);
    setIsItemTaxModalOpen(false);
  };
  const handleTaxModeChange = (enabled) => {
    setFormData((prev) => ({
      ...prev,
      has_item_level_taxes: enabled
    }));
    if (enabled && !isClientTaxExempt) {
      setItems((prev) => prev.map((item) => ({
        ...item,
        taxes: calculateItemTaxes(item, clientTaxes)
      })));
    } else {
      setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
    }
  };
  const executeSave = async () => {
    let saveItems = items.map((item) => ({ ...item }));
    let saveHasItemTaxes = formData.has_item_level_taxes;
    let saveTaxes = appliedTaxes;
    let saveAppliedTaxes = [];
    if (isClientTaxExempt) {
      const sanitized = sanitizeTaxPayloadForExemptClient({
        taxes: appliedTaxes,
        items: saveItems,
        has_item_level_taxes: formData.has_item_level_taxes
      });
      saveItems = sanitized.items;
      saveHasItemTaxes = sanitized.has_item_level_taxes;
      saveTaxes = sanitized.taxes;
      saveAppliedTaxes = [];
    } else if (formData.has_item_level_taxes) {
      saveItems = saveItems.map((item) => ({ ...item, taxes: item.taxes || [] }));
      saveTaxes = [];
      saveAppliedTaxes = [];
    } else {
      saveItems = saveItems.map((item) => ({ ...item, taxes: [] }));
      saveAppliedTaxes = [];
    }
    const dataToSend = {
      ...formData,
      items: saveItems,
      has_item_level_taxes: saveHasItemTaxes,
      taxes: saveTaxes,
      appliedTaxes: saveAppliedTaxes,
      total_amount: calculatedTotals.total,
      discount_amount: Number(formData.discount_amount) || 0,
      exchange_rate: formData.exchange_rate || 1,
      is_exchange_rate_fixed: !!formData.is_exchange_rate_fixed,
      delivery_address: tempDeliveryAddress
    };
    try {
      console.log("Datos a enviar:", dataToSend);
      await saveItem(dataToSend);
      toast.success(`Pedido ${mode === "create" ? "creado" : "actualizado"} con éxito.`);
      navigate(getListReturnPath(salesOrdersModuleConfig.baseRoute));
    } catch (apiError) {
      toast.error(`Error al guardar: ${apiError.message || "Error desconocido"}`);
    }
  };
  const handleSave = async () => {
    const itemsWithProduct = items.filter((item) => item.product_id && Number(item.product_id) > 0);
    if (itemsWithProduct.length === 0) {
      toast.error("El pedido debe incluir al menos un producto. Agregue líneas con artículos seleccionados.");
      return;
    }
    if (!formData.currency_id) {
      toast.error("Debe seleccionar una moneda.");
      return;
    }
    const proceedToSave = () => {
      gateSave(items, () => {
        void executeSave();
      });
    };
    const overStockItem = items.find(isLineOverAvailableStock);
    if (overStockItem) {
      pendingAfterStockAckRef.current = proceedToSave;
      setStockAlert({
        open: true,
        title: "Stock insuficiente",
        message: stockExcessMessage(overStockItem)
      });
      return;
    }
    proceedToSave();
  };
  const handleHeaderCodeChange = (field, newCode) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: newCode,
      // Actualiza el código
      [`${field}_name`]: "",
      // Limpia el nombre
      [`${field}`]: void 0
      // Limpia el objeto
    }));
  };
  const handleHeaderCodeSubmit = async (field, config) => {
    const codeValue = formData[`${field}_code`];
    if (!codeValue) return;
    if (!config.relationalFields) {
      toast.error(`Error: Falta 'relationalFields' en la config de ${field}`);
      return;
    }
    const { endpoint } = config;
    const { codeField, nameField } = config.relationalFields;
    try {
      const item = await searchByField(endpoint, [{ fieldName: codeField, value: codeValue }]);
      applyHeaderSelection(field, item);
      toast.success(`'${item[nameField]}' seleccionado.`);
    } catch (err) {
      console.error("Error al buscar por código:", err);
      toast.error("Error al buscar por código.");
    }
  };
  const handleHeaderClear = (field) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: null,
      [`${field}_name`]: null,
      [`${field}`]: void 0
    }));
    if (field === "client") {
      setClientTaxes([]);
      setClientTaxCondition(null);
    }
  };
  const handleOpenHistoryModal = (productId, type, productName) => {
    if (!productId) {
      toast.warn("El ítem no tiene un producto seleccionado.");
      return;
    }
    if (type === "price") {
      setHistoryModalState({
        isOpen: true,
        title: `Historial de Precios de Venta ${productName}`,
        endpoint: "products/sales-history",
        // Endpoint base
        productId,
        clientId: formData.client_id,
        columns: priceListColumns
      });
    } else {
      setHistoryModalState({
        isOpen: true,
        title: "Historial de Costos de Compra",
        endpoint: "products/purchases-history",
        // Endpoint base
        productId,
        clientId: formData.client_id,
        columns: costListColumns
      });
    }
  };
  const handleCloseHistoryModal = () => {
    setHistoryModalState(initialHistoryModalState);
  };
  const handleCloseStockAlert = () => {
    setStockAlert((prev) => ({ ...prev, open: false }));
    const continueSave = pendingAfterStockAckRef.current;
    pendingAfterStockAckRef.current = null;
    continueSave?.();
  };
  const handleQuantityBlur = (index) => {
    const item = items[index];
    if (!item || !isLineOverAvailableStock(item)) return;
    pendingAfterStockAckRef.current = null;
    setStockAlert({
      open: true,
      title: "Stock insuficiente",
      message: stockExcessMessage(item)
    });
  };
  if (loadingData && mode === "edit") return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
    lineNumber: 1048,
    columnNumber: 46
  }, this);
  if (error && mode === "edit") return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar datos: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
    lineNumber: 1049,
    columnNumber: 40
  }, this);
  const totalLabelStyle = "text-sm text-gray-700";
  const totalValueStyle = "text-sm font-semibold text-gray-800 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente (*)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1062,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.client_code || "",
              nameValue: formData.client_name || formData.client?.name || "",
              onCodeChange: (newCode) => handleHeaderCodeChange("client", newCode),
              onCodeSubmit: () => handleHeaderCodeSubmit("client", clientesModuleConfig),
              onSearchClick: () => handleOpenModal("client", clientesModuleConfig),
              onClearClick: () => handleHeaderClear("client")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1063,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1061,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Vendedor" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1073,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.salesperson_code || "",
              nameValue: formData.salesperson_name || formData.salesperson?.name || "",
              onCodeChange: (newCode) => handleHeaderCodeChange("salesperson", newCode),
              onCodeSubmit: () => handleHeaderCodeSubmit("salesperson", vendedoresModuleConfig),
              onSearchClick: () => handleOpenModal("salesperson", vendedoresModuleConfig),
              onClearClick: () => handleHeaderClear("salesperson")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1074,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1072,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Comprador" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1085,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.buyer_code || "",
              nameValue: formData.buyer_name || formData.buyer?.name || "",
              onCodeChange: (newCode) => handleHeaderCodeChange("buyer", newCode),
              onCodeSubmit: () => handleHeaderCodeSubmit("buyer", compradoresModuleConfig),
              onSearchClick: () => handleOpenModal("buyer", compradoresModuleConfig),
              onClearClick: () => handleHeaderClear("buyer")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1086,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1084,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1060,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Pedido (*)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1099,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              name: "order_date",
              value: formData.order_date?.split("T")[0] || "",
              onChange: handleInputChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1100,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1098,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Entrega" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1109,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              name: "delivery_date",
              value: formData.delivery_date?.split("T")[0] || "",
              onChange: handleInputChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1110,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1108,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Transporte" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1120,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.transport_code || "",
              nameValue: formData.transport_name || formData.transport?.name || "",
              onCodeChange: (newCode) => handleHeaderCodeChange("transport", newCode),
              onCodeSubmit: () => handleHeaderCodeSubmit("transport", transportesModuleConfig),
              onSearchClick: () => handleOpenModal("transport", transportesModuleConfig),
              onClearClick: () => handleHeaderClear("transport")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1121,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1119,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1097,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Moneda (*)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1134,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.currency_code || "",
              nameValue: formData.currency_name || formData.currency?.name || "",
              onCodeChange: (newCode) => handleHeaderCodeChange("currency", newCode),
              onCodeSubmit: () => handleHeaderCodeSubmit("currency", monedasModuleConfig),
              onSearchClick: () => handleOpenModal("currency", monedasModuleConfig),
              onClearClick: () => handleHeaderClear("currency")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1135,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1133,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo de cambio" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1145,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              name: "exchange_rate",
              value: formData.exchange_rate ?? 1,
              emptyWhenZero: false,
              onChange: (num) => setFormData((prev) => ({ ...prev, exchange_rate: num || 1 })),
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1146,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1144,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center pt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "is_exchange_rate_fixed",
              name: "is_exchange_rate_fixed",
              type: "checkbox",
              checked: !!formData.is_exchange_rate_fixed,
              onChange: handleInputChange,
              autoComplete: "off",
              className: "h-4 w-4 text-indigo-600 border-gray-300 rounded"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1155,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "is_exchange_rate_fixed", className: "ml-2 block text-sm text-gray-900", children: "Tipo de cambio fijo" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1164,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1154,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1132,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Dirección Entrega" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1173,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "delivery_address_selector",
              value: isCustomAddress ? "CUSTOM_NEW_ADDRESS" : tempDeliveryAddress || (clientAddresses.length > 0 ? clientAddresses[0] : ""),
              onChange: handleDeliveryAddressChange,
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
              disabled: !formData.client_id,
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecciona una dirección" }, void 0, false, {
                  fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                  lineNumber: 1183,
                  columnNumber: 29
                }, this),
                (clientAddresses || []).map(
                  (address, index) => /* @__PURE__ */ jsxDEV("option", { value: address, children: address }, index, false, {
                    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                    lineNumber: 1186,
                    columnNumber: 15
                  }, this)
                ),
                /* @__PURE__ */ jsxDEV("option", { value: "CUSTOM_NEW_ADDRESS", children: "--- Ingresar Otra Dirección ---" }, void 0, false, {
                  fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                  lineNumber: 1191,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1175,
              columnNumber: 25
            },
            this
          ),
          isCustomAddress && /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              name: "delivery_address_input",
              rows: 3,
              value: tempDeliveryAddress,
              onChange: (e) => setTempDeliveryAddress(e.target.value),
              placeholder: "Ingrese la nueva dirección de entrega",
              className: "mt-2 block w-full px-3 py-2 border border-indigo-500 rounded-md shadow-sm sm:text-sm",
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1196,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1172,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Nº Orden Compra" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1206,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "purchase_order_number",
              value: formData.purchase_order_number || "",
              onChange: handleInputChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1207,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1205,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1171,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
      lineNumber: 1058,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Items del Pedido" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1222,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2 hidden", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-medium ${!formData.has_item_level_taxes ? "text-indigo-600" : "text-gray-500"}`, children: "Imp. Global" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1225,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(ToggleSwitch, { enabled: formData.has_item_level_taxes, onChange: handleTaxModeChange, srLabel: "Modo de impuestos" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1226,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-medium ${formData.has_item_level_taxes ? "text-indigo-600" : "text-gray-500"}`, children: "Imp. por Ítem" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1227,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1224,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1221,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-2/5", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1237,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1238,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Stock" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1239,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: [
            "P. Unit. (",
            simboloMoneda,
            ")"
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1240,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden", children: "Desc. (Monto)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1242,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1243,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1246,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Utilidad" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1248,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1249,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Acc." }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1250,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1236,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1235,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
          const subtotal = Number(item.quantity) * Number(item.unit_price);
          const discount = Number(item.discount_amount) || 0;
          const lineSubtotal = subtotal - discount;
          const lineCost = Number(item.quantity) * Number(item.cost_price);
          let profit = (lineSubtotal - lineCost) / lineCost * 100;
          if (isNaN(profit))
            profit = 0;
          const itemTaxTotal = !isClientTaxExempt && formData.has_item_level_taxes ? (item.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0) : 0;
          const lineTotal = lineSubtotal + itemTaxTotal;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.product_code || "",
                nameValue: item.product_name || "",
                onCodeChange: (newCode) => handleItemCodeChange(index, newCode),
                onCodeSubmit: () => handleItemCodeSubmit(index),
                onSearchClick: () => handleOpenModal("item", articulosModuleConfig, index),
                onClearClick: () => handleItemClear(index),
                mask: "sku",
                enableAutocomplete: true,
                autocompleteConfig: {
                  endpoint: articulosModuleConfig.endpoint,
                  codeField: "sku",
                  nameField: "name",
                  searchParams: articulosItemSearchFilters,
                  onSelect: (product) => {
                    handleItemAutocompleteSelect(index, product);
                  }
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1274,
                columnNumber: 45
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1273,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "quantity", value: item.quantity, onChange: (num) => dispatchItemNumericChange(index, "quantity", num), onBlur: () => handleQuantityBlur(index), className: "mt-1 block w-20 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1295,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1294,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: item.stock_quantity }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1298,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "unit_price", value: item.unit_price, onChange: (num) => dispatchItemNumericChange(index, "unit_price", num), className: "mt-1 block w-28 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1302,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1301,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap hidden", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "discount_amount", value: item.discount_amount, onChange: (num) => dispatchItemNumericChange(index, "discount_amount", num), className: "mt-1 block w-24 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1306,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1304,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1308,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm text-gray-500", children: formatValue(itemTaxTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1313,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: `px-3 py-2 whitespace-nowrap text-sm font-medium ${profit >= 0 ? "text-green-600" : "text-red-600"}`, children: formatValue(profit, "percentual") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1317,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-semibold text-gray-700", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1320,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-medium space-x-2", children: [
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenHistoryModal(item.product_id, "price", item.product_name), className: "p-2 text-blue-600 hover:text-blue-900", title: "Ver historial de precios", children: /* @__PURE__ */ jsxDEV(FaTags, {}, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1325,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1324,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenHistoryModal(item.product_id, "cost", item.product_name), className: "p-2 text-gray-600 hover:text-gray-900", title: "Ver historial de costos", children: /* @__PURE__ */ jsxDEV(FaWarehouse, {}, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1328,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1327,
                columnNumber: 45
              }, this),
              !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenItemTaxModal(index), className: "p-2 text-indigo-600 hover:text-indigo-900", title: "Gestionar impuestos del ítem", children: /* @__PURE__ */ jsxDEV(FaPercentage, {}, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1332,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1331,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveItem(index), className: "p-2 text-red-600 hover:text-red-900", title: "Eliminar ítem", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1336,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
                lineNumber: 1335,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1323,
              columnNumber: 41
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1272,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1253,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1234,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1233,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddItem, className: "mt-4 inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1346,
          columnNumber: 21
        }, this),
        "Agregar Ítem"
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1345,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
      lineNumber: 1220,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hidden", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Descuento Global (Monto)" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1356,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              name: "discount_amount",
              value: formData.discount_amount,
              onChange: (num) => setFormData((prev) => ({ ...prev, discount_amount: num })),
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1357,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1355,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Observaciones:" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1366,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              name: "notes",
              rows: 3,
              value: formData.notes || "",
              onChange: handleInputChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1367,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1365,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1353,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1381,
          columnNumber: 29
        }, this),
        appliedTaxes.length > 0 ? appliedTaxes.map(
          (tax) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%):"
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1385,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1386,
              columnNumber: 41
            }, this)
          ] }, tax.tax_id, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1384,
            columnNumber: 13
          }, this)
        ) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No hay impuestos globales aplicados." }, void 0, false, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1390,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1380,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1377,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1400,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1401,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1399,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Items):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1404,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.totalItemDiscounts, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1405,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1403,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Global):" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1408,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.globalDiscountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1409,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1407,
          columnNumber: 25
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1414,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1415,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1413,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: formData.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1418,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1421,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1417,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1412,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1426,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-lg font-bold text-indigo-600`, children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
            fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
            lineNumber: 1427,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1425,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1398,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1397,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
      lineNumber: 1352,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(salesOrdersModuleConfig.baseRoute)), className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1435,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: saving,
          className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700",
          children: [
            saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1442,
              columnNumber: 31
            }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
              lineNumber: 1442,
              columnNumber: 85
            }, this),
            "Guardar Pedido"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
          lineNumber: 1436,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
      lineNumber: 1434,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(SearchModal, { isOpen: isModalOpen, onClose: () => setIsModalOpen(false), onSelect: handleSelectModal, config: modalConfig }, void 0, false, {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
      lineNumber: 1449,
      columnNumber: 7
    }, this),
    isItemTaxModalOpen && currentItemIndexForTax !== null && /* @__PURE__ */ jsxDEV(
      ItemTaxModal,
      {
        isOpen: isItemTaxModalOpen,
        onClose: () => setIsItemTaxModalOpen(false),
        onSave: handleSaveItemTaxes,
        item: items[currentItemIndexForTax],
        clientTaxes,
        clientTaxCondition
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1452,
        columnNumber: 7
      },
      this
    ),
    historyModalState.isOpen && /* @__PURE__ */ jsxDEV(
      ProductHistoryModal,
      {
        isOpen: historyModalState.isOpen,
        onClose: handleCloseHistoryModal,
        title: historyModalState.title,
        endpoint: historyModalState.endpoint,
        productId: historyModalState.productId,
        clientId: historyModalState.clientId,
        columns: historyModalState.columns
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1465,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AlertModal,
      {
        isOpen: stockAlert.open,
        onClose: handleCloseStockAlert,
        title: stockAlert.title,
        message: stockAlert.message
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
        lineNumber: 1475,
        columnNumber: 13
      },
      this
    ),
    authModal
  ] }, void 0, true, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx",
    lineNumber: 1055,
    columnNumber: 5
  }, this);
};
_s(PedidosVentaFormPage, "9S9Z5XAkS4yMDO3rRBJBfFFXE28=", false, function() {
  return [useParams, useNavigate, useCrudItem, useCrudItem, useSupervisorLowProfitAuth];
});
_c = PedidosVentaFormPage;
var _c;
$RefreshReg$(_c, "PedidosVentaFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb2dDK0MsU0E0V25CLFVBNVdtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuZ0MvQyxTQUFTQSxVQUFVQyxXQUFXQyxTQUFTQyxjQUFjO0FBQ3JELFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFFBQVFDLFdBQVdDLFFBQVFDLFNBQVNDLGNBQWNDLFFBQVFDLG1CQUFtQjtBQUN0RixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msa0NBQWtDO0FBQzNDLFNBQVNDLCtCQUFxRTtBQUc5RSxTQUFTQyw0QkFBMEM7QUFDbkQsU0FBU0MsOEJBQThCO0FBRXZDLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHVCQUF1QkMsa0NBQWtDO0FBRWxFLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBRzdCLFNBQVNDLGtDQUFrQztBQUMzQyxTQUFTQyxtQkFBbUI7QUFDNUIsZUFBOEQ7QUFDOUQ7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxTQUFTQyxvQkFBb0I7QUFHN0IsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLDBCQUEwQkMsd0JBQWdEO0FBQ25GLFNBQVNDLHlCQUF5QjtBQUtsQyxNQUFNQyxxQkFBcUJBLENBQUNDLFFBQXdCO0FBQ2hELFNBQU9DLEtBQUtDLE1BQU1GLE1BQU0sR0FBRyxJQUFJO0FBQ25DO0FBRUEsTUFBTUcsYUFBNkI7QUFBQSxFQUMvQkMsSUFBSUMsS0FBS0MsSUFBSTtBQUFBLEVBQ2JDLGFBQWE7QUFBQSxFQUNiQyxZQUFZO0FBQUEsRUFDWkMsY0FBYztBQUFBLEVBQ2RDLGNBQWM7QUFBQSxFQUNkQyxVQUFVO0FBQUEsRUFDVkMsa0JBQWtCO0FBQUEsRUFDbEJDLFlBQVk7QUFBQSxFQUNaQyxZQUFZO0FBQUE7QUFBQSxFQUVaQyxpQkFBaUI7QUFBQSxFQUNqQkMsT0FBTztBQUFBLEVBQ1BDLGtCQUFrQjtBQUFBO0FBQUEsRUFDbEJDLGlCQUFpQjtBQUFBO0FBQUEsRUFDakJDLGdCQUFnQjtBQUNwQjtBQUdBLE1BQU1DLHFCQUFpQztBQUFBLEVBQ25DaEIsSUFBSTtBQUFBLEVBQ0ppQixjQUFjO0FBQUEsRUFDZEMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyx1QkFBdUI7QUFBQSxFQUN2QkMsYUFBWSxvQkFBSXBCLEtBQUssR0FBRXFCLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBO0FBQUEsRUFDakRDLGVBQWU7QUFBQSxFQUNmQyxjQUFjO0FBQUEsRUFDZEMsT0FBTztBQUFBLEVBQ1BDLGtCQUFrQjtBQUFBO0FBQUEsRUFFbEJoQixpQkFBaUI7QUFBQSxFQUNqQmlCLGVBQWU7QUFBQSxFQUNmQyx3QkFBd0I7QUFBQSxFQUN4QkMsV0FBVztBQUFBLEVBQ1hDLGdCQUFnQjtBQUFBLEVBQ2hCQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLGNBQWM7QUFBQTtBQUFBLEVBR2RDLGFBQWE7QUFBQSxFQUNiQyxrQkFBa0I7QUFBQSxFQUNsQkMsWUFBWTtBQUFBLEVBQ1pDLGVBQWU7QUFBQSxFQUNmQyxnQkFBZ0I7QUFBQTtBQUFBO0FBQUEsRUFJaEJDLFFBQVFDO0FBQUFBLEVBQ1JDLGFBQWFEO0FBQUFBLEVBQ2JFLE9BQU9GO0FBQUFBLEVBQ1BHLFVBQVVIO0FBQUFBLEVBQ1ZJLFdBQVdKO0FBQUFBO0FBQUFBLEVBR1hLLE9BQU87QUFBQSxFQUNQbEMsT0FBTztBQUFBLEVBQ1BtQyxjQUFjO0FBQUEsRUFDZEMsc0JBQXNCO0FBQUE7QUFDMUI7QUFFQSxNQUFNQywyQkFBMkJBLENBQUNDLFNBQWtDO0FBQ2hFLE1BQUksQ0FBQ0EsS0FBSzlDLFdBQVksUUFBTztBQUM3QixRQUFNK0MsSUFBSUMsT0FBT0YsS0FBSzNDLFFBQVEsS0FBSztBQUNuQyxRQUFNOEMsSUFBSUQsT0FBT0YsS0FBS25DLGNBQWMsS0FBSztBQUN6QyxTQUFPb0MsSUFBSUU7QUFDZjtBQUVBLE1BQU1DLHFCQUFxQkEsQ0FBQ0osU0FBaUM7QUFDekQsUUFBTUMsSUFBSUMsT0FBT0YsS0FBSzNDLFFBQVEsS0FBSztBQUNuQyxRQUFNOEMsSUFBSUQsT0FBT0YsS0FBS25DLGNBQWMsS0FBSztBQUN6QyxRQUFNd0MsT0FBT0wsS0FBSzVDLGdCQUFnQjtBQUNsQyxRQUFNa0QsT0FBT04sS0FBSzdDLGVBQWUsS0FBSzZDLEtBQUs3QyxZQUFZLE1BQU07QUFDN0QsU0FBTyxvQkFBb0I4QyxDQUFDLG1CQUFtQkksSUFBSSxJQUFJQyxJQUFJLGdDQUFnQ0gsQ0FBQztBQUNoRztBQWVBLE1BQU1JLGtCQUF1RDtBQUFBLEVBQ3pELEVBQUVDLFFBQVEsZ0JBQWdCQyxVQUFVLGlCQUFpQkMsUUFBUSxPQUFPO0FBQUEsRUFDcEUsRUFBRUYsUUFBUSxrQkFBa0JDLFVBQVUsa0JBQWtCO0FBQUEsRUFDeEQsRUFBRUQsUUFBUSxhQUFhQyxVQUFVLGNBQWM7QUFBQSxFQUMvQyxFQUFFRCxRQUFRLGVBQWVDLFVBQVUsY0FBY0MsUUFBUSxXQUFXO0FBQUEsRUFDcEUsRUFBRUYsUUFBUSxZQUFZQyxVQUFVLFdBQVc7QUFBQztBQU96QyxhQUFNRSx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUU5RCxHQUFHLElBQUk1QyxVQUEwQjtBQUN6QyxRQUFNMkcsV0FBVzVHLFlBQVk7QUFDN0IsUUFBTTZHLE9BQU9oRSxLQUFLLFNBQVM7QUFFM0IsUUFBTSxFQUFFa0QsTUFBTWUsWUFBWUMsU0FBU0MsYUFBYUMsTUFBTSxJQUFJdkcsWUFBd0JFLHlCQUF5QmlDLEVBQUU7QUFDN0csUUFBTSxFQUFFcUUsVUFBVUgsU0FBU0ksT0FBTyxJQUFJekcsWUFBd0JFLHlCQUF5QmlDLEVBQUU7QUFFekYsUUFBTSxDQUFDdUUsVUFBVUMsV0FBVyxJQUFJekgsU0FBcUJpRSxrQkFBa0I7QUFDdkUsUUFBTSxDQUFDOEIsT0FBTzJCLFFBQVEsSUFBSTFILFNBQTJCLEVBQUU7QUFFdkQsUUFBTSxDQUFDMkgsYUFBYUMsY0FBYyxJQUFJNUgsU0FBc0IsRUFBRTtBQUM5RCxRQUFNLENBQUM2SCxvQkFBb0JDLHFCQUFxQixJQUFJOUgsU0FBd0IsSUFBSTtBQUNoRixRQUFNLENBQUMrSCxtQkFBbUJDLG9CQUFvQixJQUFJaEksU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2dHLGNBQWNpQyxlQUFlLElBQUlqSSxTQUF1QixFQUFFO0FBRWpFLFFBQU0sQ0FBQ2tJLGFBQWFDLGNBQWMsSUFBSW5JLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNvSSxhQUFhQyxjQUFjLElBQUlySSxTQUFjLElBQUk7QUFDeEQsUUFBTSxDQUFDc0ksZUFBZUMsZ0JBQWdCLElBQUl2SSxTQUErQixJQUFJO0FBQzdFLFFBQU0sQ0FBQ3dJLGtCQUFrQkMsbUJBQW1CLElBQUl6SSxTQUF3QixJQUFJO0FBRTVFLFFBQU0sQ0FBQzBJLG9CQUFvQkMscUJBQXFCLElBQUkzSSxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDNEksd0JBQXdCQyx5QkFBeUIsSUFBSTdJLFNBQXdCLElBQUk7QUFFeEYsUUFBTSxDQUFDOEksbUJBQW1CQyxvQkFBb0IsSUFBSS9JLFNBQTRCeUMsd0JBQXdCO0FBRXRHLFFBQU0sQ0FBQ3VHLFlBQVlDLGFBQWEsSUFBSWpKLFNBQTREO0FBQUEsSUFDNUZrSixNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxFQUNiLENBQUM7QUFDRCxRQUFNQywwQkFBMEJsSixPQUE0QixJQUFJO0FBRWhFLFFBQU0sRUFBRW1KLFVBQVVDLFVBQVUsSUFBSXhJLDJCQUEyQjtBQUUzRCxRQUFNLENBQUN5SSxpQkFBaUJDLGtCQUFrQixJQUFJekosU0FBbUIsRUFBRTtBQUNuRSxRQUFNLENBQUMwSixpQkFBaUJDLGtCQUFrQixJQUFJM0osU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzRKLHFCQUFxQkMsc0JBQXNCLElBQUk3SixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDOEosZUFBZUMsZ0JBQWdCLElBQUkvSixTQUFTLEdBQUc7QUFFdEQsUUFBTWdLLHdCQUF3QjlKLFFBQVEsTUFBTTtBQUN4QyxVQUFNK0osT0FBTzVELE9BQU9tQixTQUFTM0MsYUFBYSxLQUFLO0FBRy9DLFdBQU8yQyxTQUFTakMsa0JBQWtCLE9BQU8sSUFBSTBFO0FBQUFBLEVBQ2pELEdBQUcsQ0FBQ3pDLFNBQVMzQyxlQUFlMkMsU0FBU2pDLGFBQWEsQ0FBQztBQUVuRCxRQUFNMkUscUJBQXFCQSxDQUFDL0QsTUFBc0J0QyxRQUFxQjhELGdCQUE4QjtBQUNqRyxRQUFJLENBQUM5RCxTQUFTQSxNQUFNc0csV0FBVyxFQUFHLFFBQU87QUFDekMsVUFBTUMsVUFBVy9ELE9BQU9GLEtBQUszQyxRQUFRLElBQUk2QyxPQUFPRixLQUFLekMsVUFBVSxLQUFNMkMsT0FBT0YsS0FBS3ZDLGVBQWUsS0FBSztBQUNyRyxXQUFPeEIseUJBQXlCO0FBQUEsTUFDNUJpSSxTQUFTRDtBQUFBQSxNQUNUdkM7QUFBQUEsTUFDQWhFO0FBQUFBLElBQ0osQ0FBQztBQUFBLEVBQ0w7QUFHQTVELFlBQVUsTUFBTTtBQUNaLFFBQUlnSCxTQUFTLFVBQVVDLFlBQVk7QUFFL0IsWUFBTW9ELGVBQWUsRUFBRSxHQUFHcEQsV0FBVztBQUdyQyxVQUFJb0QsYUFBYTdFLFVBQVV4RSxxQkFBcUJzSixrQkFBa0I7QUFDOUQsY0FBTSxFQUFFQyxXQUFXQyxVQUFVLElBQUl4SixxQkFBcUJzSjtBQUN0REQscUJBQWFsRixjQUFja0YsYUFBYTdFLE9BQU8rRSxTQUEwQjtBQUN6RUYscUJBQWFJLGNBQWNKLGFBQWE3RSxPQUFPZ0YsU0FBMEI7QUFBQSxNQUM3RTtBQUVBLFVBQUlILGFBQWEzRSxlQUFlekUsdUJBQXVCcUosa0JBQWtCO0FBQ3JFLGNBQU0sRUFBRUMsV0FBV0MsVUFBVSxJQUFJdkosdUJBQXVCcUo7QUFDeEQsY0FBTUksTUFBTUwsYUFBYTNFO0FBQ3pCMkUscUJBQWFqRixtQkFBb0JpRixhQUFhakYsb0JBQW9Cc0YsSUFBSUgsU0FBNkI7QUFDbkdGLHFCQUFhTSxtQkFBb0JOLGFBQWFNLG9CQUFvQkQsSUFBSUYsU0FBNkI7QUFBQSxNQUN2RztBQUNBLFVBQUlILGFBQWExRSxTQUFTekUsd0JBQXdCb0osa0JBQWtCO0FBQ2hFLGNBQU0sRUFBRUMsV0FBV0MsVUFBVSxJQUFJdEosd0JBQXdCb0o7QUFDekQsY0FBTUksTUFBTUwsYUFBYTFFO0FBQ3pCMEUscUJBQWFoRixhQUFjZ0YsYUFBYWhGLGNBQWNxRixJQUFJSCxTQUE2QjtBQUN2RkYscUJBQWFPLGFBQWNQLGFBQWFPLGNBQWNGLElBQUlGLFNBQTZCO0FBQUEsTUFDM0Y7QUFDQSxVQUFJSCxhQUFhekUsWUFBWXhFLG9CQUFvQmtKLGtCQUFrQjtBQUMvRCxjQUFNLEVBQUVDLFdBQVdDLFVBQVUsSUFBSXBKLG9CQUFvQmtKO0FBQ3JELGNBQU1JLE1BQU1MLGFBQWF6RTtBQUN6QnlFLHFCQUFhL0UsZ0JBQWlCK0UsYUFBYS9FLGlCQUFpQm9GLElBQUlILFNBQTZCO0FBQzdGRixxQkFBYVEsZ0JBQWlCUixhQUFhUSxpQkFBaUJILElBQUlGLFNBQTZCO0FBQUEsTUFDakc7QUFDQSxVQUFJSCxhQUFheEUsYUFBYTFFLHdCQUF3Qm1KLGtCQUFrQjtBQUNwRSxjQUFNLEVBQUVDLFdBQVdDLFVBQVUsSUFBSXJKLHdCQUF3Qm1KO0FBQ3pELGNBQU1JLE1BQU1MLGFBQWF4RTtBQUN6QndFLHFCQUFhOUUsaUJBQWtCOEUsYUFBYTlFLGtCQUFrQm1GLElBQUlILFNBQTZCO0FBQy9GRixxQkFBYVMsaUJBQWtCVCxhQUFhUyxrQkFBa0JKLElBQUlGLFNBQTZCO0FBQUEsTUFDbkc7QUFFQSxVQUFJdkQsV0FBV3pCLFFBQVF1RixhQUFhO0FBQ2hDdkIsMkJBQW1CdkMsV0FBV3pCLE9BQU91RixXQUFXO0FBR2hELGNBQU1DLFdBQVcvRCxXQUFXdEMsb0JBQ3JCLENBQUNzQyxXQUFXekIsT0FBT3VGLFlBQVlFLFNBQVNoRSxXQUFXdEMsZ0JBQWdCO0FBRTFFK0UsMkJBQW1CLENBQUMsQ0FBQ3NCLFFBQVE7QUFHN0JwQiwrQkFBdUIzQyxXQUFXdEMsb0JBQW9CLEVBQUU7QUFBQSxNQUM1RCxPQUFPO0FBQ0hpRiwrQkFBdUIzQyxXQUFXdEMsb0JBQW9CLEVBQUU7QUFBQSxNQUM1RDtBQUNBLFlBQU11RyxpQkFBaUJqSixnQ0FBZ0NnRixXQUFXekIsTUFBTTtBQUN4RXVDLDJCQUFxQm1ELGNBQWM7QUFDbkMsVUFBSWpFLFdBQVd6QixRQUFRO0FBQ25CcUMsOEJBQXNCWixXQUFXekIsT0FBTzJGLE9BQU8sSUFBSTtBQUFBLE1BQ3ZEO0FBRUEzRCxrQkFBWTBELGlCQUNOLEVBQUUsR0FBR2IsY0FBY3JFLHNCQUFzQixNQUFNLElBQy9DcUUsWUFBWTtBQUNsQjVDLGVBQVN5RCxrQkFDRmpFLFdBQVduQixTQUFTLElBQUlzRixJQUFJLENBQUFsRixVQUFTLEVBQUUsR0FBR0EsTUFBTXRDLE9BQU8sR0FBRyxFQUFFLElBQzVEcUQsV0FBV25CLFNBQVMsRUFBRztBQUM5QixVQUFJb0YsZ0JBQWdCO0FBQ2hCbEQsd0JBQWdCLEVBQUU7QUFBQSxNQUN0QixXQUFXLENBQUNmLFdBQVdqQixzQkFBc0I7QUFDekNnQyx3QkFBZ0JmLFdBQVdsQixnQkFBZ0JrQixXQUFXckQsU0FBUyxFQUFFO0FBQUEsTUFDckU7QUFBQSxJQUNKLFdBQVdvRCxTQUFTLFVBQVU7QUFFMUI0Qyw2QkFBdUI1RixtQkFBbUJXLG9CQUFvQixFQUFFO0FBQUEsSUFDcEU7QUFBQSxFQUNKLEdBQUcsQ0FBQ3FDLE1BQU1DLFVBQVUsQ0FBQztBQUdyQmpILFlBQVUsTUFBTTtBQUNaLFFBQUl1SCxTQUFTekMsV0FBVztBQUNwQjFDLGNBQWlCcEIscUJBQXFCcUssVUFBVTlELFNBQVN6QyxTQUFTLEVBQzdEd0csS0FBSyxDQUFBQyxlQUFjO0FBQ2hCLGNBQU1DLFNBQVN2SixnQ0FBZ0NzSixVQUFVO0FBQ3pELGNBQU1FLGlCQUFpQnpKLHdCQUF3QnVKLFlBQVlBLFdBQVdHLFlBQVk7QUFDbEYzRCw2QkFBcUJ5RCxNQUFNO0FBQzNCM0QsOEJBQXNCMEQsV0FBV0osT0FBTyxJQUFJO0FBQzVDeEQsdUJBQWU4RCxjQUFjO0FBRTdCLFlBQUlELFFBQVE7QUFDUnhELDBCQUFnQixFQUFFO0FBQ2xCUixzQkFBWSxDQUFBbUUsVUFBUyxFQUFFLEdBQUdBLE1BQU0zRixzQkFBc0IsTUFBTSxFQUFFO0FBQzlEeUIsbUJBQVMsQ0FBQWtFLFNBQVFBLEtBQUtQLElBQUksQ0FBQWxGLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQy9ELFdBQVcyRCxTQUFTdkIsc0JBQXNCO0FBQ3RDeUIsbUJBQVMsQ0FBQWtFLFNBQVFBLEtBQUtQLElBQUksQ0FBQWxGLFVBQVM7QUFBQSxZQUMvQixHQUFHQTtBQUFBQSxZQUNIdEMsT0FBT3FHLG1CQUFtQi9ELE1BQU11RixjQUFjO0FBQUEsVUFDbEQsRUFBRSxDQUFDO0FBQUEsUUFDUDtBQUFBLE1BQ0osQ0FBQyxFQUNBRyxNQUFNLE1BQU07QUFDVHZMLGNBQU0rRyxNQUFNLGtEQUFrRDtBQUM5RFcsNkJBQXFCLEtBQUs7QUFDMUJGLDhCQUFzQixJQUFJO0FBQzFCRix1QkFBZSxFQUFFO0FBQUEsTUFDckIsQ0FBQztBQUFBLElBQ1QsT0FBTztBQUNISSwyQkFBcUIsS0FBSztBQUMxQkYsNEJBQXNCLElBQUk7QUFDMUJGLHFCQUFlLEVBQUU7QUFDakJLLHNCQUFnQixFQUFFO0FBQ2xCLFVBQUlULFNBQVN2QixzQkFBc0I7QUFDL0J5QixpQkFBUyxDQUFBa0UsU0FBUUEsS0FBS1AsSUFBSSxDQUFBbEYsVUFBUyxFQUFFLEdBQUdBLE1BQU10QyxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDL0Q7QUFBQSxJQUNKO0FBQUEsRUFFSixHQUFHLENBQUMyRCxTQUFTekMsV0FBV3lDLFNBQVN2QixvQkFBb0IsQ0FBQztBQUl0RCxRQUFNNkYsbUJBQW1CNUwsUUFBUSxNQUFNO0FBRW5DLFVBQU02TCxXQUFXaEcsTUFBTWlHLE9BQU8sQ0FBQ0MsS0FBSzlGLFNBQVM7QUFDekMsYUFBTzhGLE1BQU81RixPQUFPRixLQUFLM0MsUUFBUSxJQUFJNkMsT0FBT0YsS0FBS3pDLFVBQVU7QUFBQSxJQUNoRSxHQUFHLENBQUM7QUFHSixVQUFNd0kscUJBQXFCbkcsTUFBTWlHLE9BQU8sQ0FBQ0MsS0FBSzlGLFNBQVM7QUFDbkQsYUFBTzhGLE9BQU81RixPQUFPRixLQUFLdkMsZUFBZSxLQUFLO0FBQUEsSUFDbEQsR0FBRyxDQUFDO0FBR0osVUFBTXVJLHVCQUF1QjlGLE9BQU9tQixTQUFTNUQsZUFBZSxLQUFLO0FBR2pFLFVBQU13RyxVQUFVMkIsV0FBV0cscUJBQXFCQztBQUdoRCxRQUFJQyxhQUFhO0FBRWpCLFFBQUksQ0FBQ3JFLG1CQUFtQjtBQUNwQixVQUFJUCxTQUFTdkIsc0JBQXNCO0FBQy9CbUcscUJBQWFyRyxNQUFNaUcsT0FBTyxDQUFDQyxLQUFLOUYsU0FBUztBQUNyQyxnQkFBTWtHLFlBQVlsRyxLQUFLdEMsU0FBUztBQUNoQyxnQkFBTXlJLGdCQUFnQkQsVUFBVUwsT0FBTyxDQUFDTyxTQUFTbkIsUUFBUW1CLFVBQVVsRyxPQUFPK0UsSUFBSW9CLE1BQU0sR0FBRyxDQUFDO0FBQ3hGLGlCQUFPUCxNQUFNSztBQUFBQSxRQUNqQixHQUFHLENBQUM7QUFBQSxNQUNSLE9BQU87QUFDSEYscUJBQWFwRyxhQUFhZ0csT0FBTyxDQUFDQyxLQUFLYixRQUFRYSxNQUFNNUYsT0FBTytFLElBQUlvQixNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQzlFO0FBQUEsSUFDSjtBQUVBLFVBQU1DLFFBQVExRSxvQkFDUi9GLDJCQUEyQitKLFVBQVVHLG9CQUFvQkMsb0JBQW9CLElBQzdFL0IsVUFBVWdDO0FBRWhCLFdBQU8sRUFBRUwsVUFBVUcsb0JBQW9CQyxzQkFBc0IvQixTQUFTZ0MsWUFBWUssTUFBTTtBQUFBLEVBQzVGLEdBQUcsQ0FBQzFHLE9BQU95QixTQUFTNUQsaUJBQWlCb0MsY0FBY3dCLFNBQVN2QixzQkFBc0I4QixpQkFBaUIsQ0FBQztBQUlwRzlILFlBQVUsTUFBTTtBQUNaLFVBQU15TSxlQUFlMUM7QUFHckIsUUFBSTJDLE1BQU1ELFlBQVksRUFBRztBQUV6QmhGLGFBQVMsQ0FBQWtGLGNBQWFBLFVBQVV2QixJQUFJLENBQUFsRixTQUFRO0FBQ3hDLFlBQU0wRyxZQUFZeEcsT0FBT0YsS0FBS3JDLGdCQUFnQjtBQUM5QyxZQUFNZ0osV0FBV3pHLE9BQU9GLEtBQUtwQyxlQUFlO0FBRzVDLFVBQUk4SSxjQUFjLEtBQUtDLGFBQWEsRUFBRyxRQUFPM0c7QUFFOUMsWUFBTTRHLFVBQVU7QUFBQSxRQUNaLEdBQUc1RztBQUFBQTtBQUFBQSxRQUVIekMsWUFBWWQsbUJBQW1CaUssWUFBWUgsWUFBWTtBQUFBLFFBQ3ZEL0ksWUFBWWYsbUJBQW1Ca0ssV0FBV0osWUFBWTtBQUFBLE1BQzFEO0FBRUEsVUFBSWxGLFNBQVN2Qix3QkFBd0IsQ0FBQzhCLG1CQUFtQjtBQUNyRGdGLGdCQUFRbEosUUFBUXFHLG1CQUFtQjZDLFNBQVNwRixXQUFXO0FBQUEsTUFDM0Q7QUFFQSxhQUFPb0Y7QUFBQUEsSUFDWCxDQUFDLENBQUM7QUFBQSxFQUVOLEdBQUcsQ0FBQy9DLHVCQUF1QnJDLGFBQWFILFNBQVN2QixzQkFBc0I0QixvQkFBb0JFLGlCQUFpQixDQUFDO0FBRzdHOUgsWUFBVSxNQUFNO0FBQ1osUUFBSThILG1CQUFtQjtBQUNuQkUsc0JBQWdCLEVBQUU7QUFDbEI7QUFBQSxJQUNKO0FBRUEsUUFBSVQsU0FBU3ZCLHNCQUFzQjtBQUMvQmdDLHNCQUFnQixFQUFFO0FBQ2xCO0FBQUEsSUFDSjtBQUVBLFFBQUlOLFlBQVl3QyxTQUFTLEdBQUc7QUFFeEIsWUFBTSxFQUFFQyxRQUFRLElBQUkwQjtBQUNwQjdELHNCQUFnQjdGLHlCQUF5QjtBQUFBLFFBQ3JDaUksU0FBU0Q7QUFBQUEsUUFDVHZDO0FBQUFBLFFBQ0FoRSxPQUFPOEQ7QUFBQUEsTUFDWCxDQUFDLENBQUM7QUFBQSxJQUNOLE9BQU87QUFDSE0sc0JBQWdCLEVBQUU7QUFBQSxJQUN0QjtBQUFBLEVBRUosR0FBRyxDQUFDNkQsaUJBQWlCMUIsU0FBU3pDLGFBQWFILFNBQVN2QixzQkFBc0I0QixvQkFBb0JFLGlCQUFpQixDQUFDO0FBT2hILFFBQU1pRix1QkFBdUJBLENBQUNDLE9BQW9CQyxpQkFBc0I7QUFHcEUsVUFBTUMsZUFBZTtBQUFBLE1BQ2pCLFVBQVVsTTtBQUFBQSxNQUNWLGVBQWVDO0FBQUFBLE1BQ2YsU0FBU0M7QUFBQUEsTUFDVCxZQUFZRTtBQUFBQSxNQUNaLGFBQWFEO0FBQUFBLElBQ2pCLEVBQUU2TCxLQUFLO0FBRVAsUUFBSSxDQUFDRSxnQkFBZ0IsQ0FBQ0EsYUFBYTVDLGtCQUFrQjtBQUNqRGpLLFlBQU0rRyxNQUFNLG1EQUFtRDRGLEtBQUssRUFBRTtBQUN0RTtBQUFBLElBQ0o7QUFDQSxVQUFNLEVBQUV6QyxXQUFXQyxVQUFVLElBQUkwQyxhQUFhNUM7QUFFOUM5QyxnQkFBWSxDQUFBbUUsU0FBUTtBQUNoQixZQUFNd0IsY0FBYyxFQUFFLEdBQUd4QixLQUFLO0FBRzlCLFVBQUlzQixjQUFjO0FBRWRFLG9CQUFZLEdBQUdILEtBQUssS0FBSyxJQUFJQyxhQUFhaks7QUFDMUNtSyxvQkFBWSxHQUFHSCxLQUFLLE9BQU8sSUFBSUMsYUFBYTFDLFNBQW1CO0FBQy9ENEMsb0JBQVksR0FBR0gsS0FBSyxPQUFPLElBQUlDLGFBQWF6QyxTQUFtQjtBQUcvRCxZQUFJd0MsVUFBVSxVQUFVO0FBRXBCbkYsZ0NBQXNCb0YsYUFBYTlCLE9BQU8sSUFBSTtBQUc5QyxnQkFBTWlDLFlBQVlILGFBQWFsQyxlQUFlO0FBQzlDdkIsNkJBQW1CNEQsU0FBUztBQUM1QjFELDZCQUFtQixLQUFLO0FBR3hCLGNBQUkwRCxVQUFVbEQsU0FBUyxHQUFHO0FBQ3RCTixtQ0FBdUJ3RCxVQUFVLENBQUMsQ0FBQztBQUNuQ0Qsd0JBQVl4SSxtQkFBbUJ5SSxVQUFVLENBQUM7QUFBQSxVQUM5QyxPQUFPO0FBQ0h4RCxtQ0FBdUIsRUFBRTtBQUN6QnVELHdCQUFZeEksbUJBQW1CO0FBQUEsVUFDbkM7QUFHQSxjQUFJc0ksYUFBYUksVUFBVTtBQUN2QkYsd0JBQVlwSSxpQkFBaUJrSSxhQUFhSTtBQUMxQ0Ysd0JBQVkvSCxtQkFBbUI2SCxhQUFhSyxpQkFBaUI5RyxRQUFRO0FBQ3JFMkcsd0JBQVl4QyxtQkFBbUJzQyxhQUFhSyxpQkFBaUIvRyxRQUFRO0FBQUEsVUFDekU7QUFHQSxjQUFJMEcsYUFBYS9ILGNBQWM7QUFDM0JpSSx3QkFBWWpJLGVBQWUrSCxhQUFhL0g7QUFDeENpSSx3QkFBWTVILGlCQUFpQjBILGFBQWExSCxrQkFBa0I7QUFDNUQ0SCx3QkFBWXJDLGlCQUFpQm1DLGFBQWFuQyxrQkFBa0I7QUFBQSxVQUNoRTtBQUdBLGNBQUltQyxhQUFhaEksYUFBYTtBQUMxQmtJLHdCQUFZbEksY0FBY2dJLGFBQWFoSTtBQUN2Q2tJLHdCQUFZN0gsZ0JBQWdCMkgsYUFBYTNILGlCQUFpQjtBQUMxRDZILHdCQUFZdEMsZ0JBQWdCb0MsYUFBYXBDLGlCQUFpQjtBQUMxRHNDLHdCQUFZdkksZ0JBQWdCcUksYUFBYXJILFVBQVVoQixpQkFBaUI7QUFDcEUsZ0JBQUl1SSxZQUFZN0gsa0JBQWtCO0FBQzlCd0UsK0JBQWlCLEtBQUs7QUFBQTtBQUV0QkEsK0JBQWlCLEdBQUc7QUFBQSxVQUM1QjtBQUVBLGNBQUltRCxhQUFhakksVUFBVTtBQUN2Qm1JLHdCQUFZbkksV0FBV2lJLGFBQWFqSTtBQUNwQ21JLHdCQUFZOUgsYUFBYTRILGFBQWE1SCxjQUFjO0FBQ3BEOEgsd0JBQVl2QyxhQUFhcUMsYUFBYXJDLGNBQWM7QUFBQSxVQUN4RDtBQUFBLFFBQ0osV0FBV29DLFVBQVUsWUFBWTtBQUM3Qkcsc0JBQVl2SSxnQkFBZ0JxSSxhQUFhckksaUJBQWlCO0FBQzFELGNBQUl1SSxZQUFZN0gsa0JBQWtCO0FBQzlCd0UsNkJBQWlCLEtBQUs7QUFBQTtBQUV0QkEsNkJBQWlCLEdBQUc7QUFBQSxRQUM1QjtBQUFBLE1BQ0o7QUFFQSxhQUFPcUQ7QUFBQUEsSUFDWCxDQUFDO0FBR0QsUUFBSUgsVUFBVSxVQUFVO0FBQ3BCaEYsc0JBQWdCLEVBQUU7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFFQSxRQUFNdUYsOEJBQThCQSxDQUFDQyxNQUFrRTtBQUNuRyxVQUFNQyxRQUFRRCxFQUFFRSxPQUFPRDtBQUN2QixRQUFJQSxVQUFVLHNCQUFzQjtBQUNoQy9ELHlCQUFtQixJQUFJO0FBQ3ZCRSw2QkFBdUIsRUFBRTtBQUFBLElBQzdCLE9BQU87QUFDSEYseUJBQW1CLEtBQUs7QUFDeEJFLDZCQUF1QjZELEtBQUs7QUFBQSxJQUNoQztBQUFBLEVBQ0o7QUFFQSxRQUFNRSxrQkFBa0JBLENBQUNELFFBQXVCRSxRQUFhQyxZQUEyQixTQUFTO0FBQzdGdkYscUJBQWlCb0YsTUFBTTtBQUN2QnRGO0FBQUFBLE1BQWVzRixXQUFXLFNBQ3BCLEVBQUUsR0FBR0UsUUFBUUUsZ0JBQWdCeE0sMkJBQTJCLElBQ3hEc007QUFBQUEsSUFDTjtBQUNBMUYsbUJBQWUsSUFBSTtBQUNuQixRQUFJd0YsV0FBVyxRQUFRO0FBQ25CbEYsMEJBQW9CcUYsU0FBUztBQUFBLElBQ2pDO0FBQUEsRUFDSjtBQUVBLFFBQU1FLG9CQUFvQixPQUFPZCxpQkFBc0I7QUFDbkQsUUFBSSxDQUFDNUUsY0FBZTtBQUVwQixRQUFJQSxrQkFBa0IsVUFBVUUscUJBQXFCLE1BQU07QUFFdkQsWUFBTXlGLFdBQVdmLGFBQWFnQixNQUFNQyxPQUFPakIsYUFBYWdCLEdBQUcsSUFBSTtBQUMvRCxZQUFNRSxVQUFVLE1BQU05TDtBQUFBQSxRQUFtQjtBQUFBLFFBQ3JDO0FBQUEsVUFBQyxFQUFFK0wsV0FBVyxPQUFpQlgsT0FBT08sU0FBUztBQUFBLFVBQy9DLEVBQUVJLFdBQVcsYUFBYVgsT0FBT2xHLFNBQVN6QyxXQUFXdUosU0FBUyxLQUFLLEdBQUc7QUFBQSxRQUFDO0FBQUEsTUFDdEU7QUFFTDVHLGVBQVMsQ0FBQWtGLGNBQWE7QUFDbEIsY0FBTTJCLFdBQVcsQ0FBQyxHQUFHM0IsU0FBUztBQUM5QixjQUFNekcsT0FBT29JLFNBQVMvRixnQkFBZ0I7QUFFdEMsY0FBTSxFQUFFZ0MsV0FBV0MsVUFBVSxJQUFJbkosc0JBQXNCaUo7QUFDdkQsY0FBTW1DLGVBQWUxQztBQUNyQixjQUFNNkMsWUFBWXVCLFFBQVFJLG1CQUFtQnRCLGFBQWF1QixjQUFjO0FBQ3hFLGNBQU0zQixXQUFXaEw7QUFBQUEsVUFDYnNNLFFBQVF6SyxjQUFjdUosYUFBYXZKLGNBQWM7QUFBQSxVQUNqRHlLLFFBQVFNO0FBQUFBLFVBQ1JsSCxTQUFTM0M7QUFBQUEsUUFDYjtBQUVBc0IsYUFBSzlDLGFBQWE2SixhQUFhaks7QUFDL0JrRCxhQUFLN0MsZUFBZTRKLGFBQWExQyxTQUFtQjtBQUNwRHJFLGFBQUs1QyxlQUFlMkosYUFBYXpDLFNBQW1CO0FBQ3BEdEUsYUFBS25DLGlCQUFpQm9LLFFBQVFwSyxrQkFBa0I7QUFDaERtQyxhQUFLekMsYUFBYW1KLGFBQWE7QUFDL0IxRyxhQUFLeEMsYUFBYW1KLFlBQVk7QUFDOUIzRyxhQUFLckMsbUJBQW1CK0k7QUFDeEIxRyxhQUFLcEMsa0JBQWtCK0k7QUFFdkIzRyxhQUFLekMsYUFBYWQsbUJBQW1CaUssWUFBWUgsWUFBWTtBQUM3RHZHLGFBQUt4QyxhQUFhZixtQkFBbUJrSyxXQUFXSixZQUFZO0FBRzVELFlBQUlsRixTQUFTdkIsd0JBQXdCLENBQUM4QixtQkFBbUI7QUFDckQ1QixlQUFLdEMsUUFBUXFHLG1CQUFtQi9ELE1BQU13QixXQUFXO0FBQUEsUUFDckQsT0FBTztBQUNIeEIsZUFBS3RDLFFBQVE7QUFBQSxRQUNqQjtBQUVBMEssaUJBQVMvRixnQkFBZ0IsSUFBSXJDO0FBQzdCLGVBQU9vSTtBQUFBQSxNQUNYLENBQUM7QUFDRDlGLDBCQUFvQixJQUFJO0FBQUEsSUFDNUIsV0FDU0gsa0JBQWtCLFFBQVE7QUFFL0IwRSwyQkFBcUIxRSxlQUFlNEUsWUFBWTtBQUFBLElBQ3BEO0FBQ0EvRSxtQkFBZSxLQUFLO0FBQUEsRUFDeEI7QUFFQSxRQUFNd0csb0JBQW9CQSxDQUFDbEIsTUFBcUY7QUFDNUcsVUFBTSxFQUFFakgsTUFBTWtILE9BQU9rQixLQUFLLElBQUluQixFQUFFRTtBQUNoQyxRQUFJa0IsYUFBa0JuQjtBQUd0QixRQUFJa0IsU0FBUyxZQUFZO0FBQ3JCQyxtQkFBY3BCLEVBQUVFLE9BQTRCbUI7QUFBQUEsSUFDaEQ7QUFFQXJILGdCQUFZLENBQUFtRSxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDcEYsSUFBSSxHQUFHcUksV0FBVyxFQUFFO0FBQUEsRUFDekQ7QUFFQSxRQUFNRSxtQkFBbUJBLENBQUNDLE9BQWV2QixNQUEyQztBQUNoRixVQUFNLEVBQUVqSCxNQUFNa0gsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQixVQUFNakIsZUFBZTFDO0FBQ3JCLFVBQU1pRixZQUFZLENBQUMsWUFBWSxjQUFjLGlCQUFpQjtBQUM5RCxVQUFNQyxjQUFjRCxVQUFVL0QsU0FBUzFFLElBQUksSUFBS2tILFVBQVUsS0FBSyxJQUFJckgsT0FBT3FILEtBQUssS0FBSyxJQUFLQTtBQUV6RmhHLGFBQVMsQ0FBQWtGLGNBQWE7QUFDbEIsWUFBTTJCLFdBQVcsQ0FBQyxHQUFHM0IsU0FBUztBQUM5QixZQUFNekcsT0FBTyxFQUFFLEdBQUdvSSxTQUFTUyxLQUFLLEdBQUcsQ0FBQ3hJLElBQUksR0FBRzBJLFlBQVk7QUFFdkQsVUFBSTFJLFNBQVMsY0FBYztBQUN2QixjQUFNMkksV0FBVzlJLE9BQU82SSxXQUFXLEtBQUs7QUFFeEMvSSxhQUFLckMsbUJBQW1CcUwsV0FBV3pDO0FBR25DLGNBQU1JLFdBQVd6RyxPQUFPRixLQUFLcEMsZUFBZSxLQUFLO0FBQ2pEb0MsYUFBS3hDLGFBQWFmLG1CQUFtQmtLLFdBQVdKLFlBQVk7QUFBQSxNQUNoRTtBQUdBLFVBQUlsRixTQUFTdkIsd0JBQXdCLENBQUM4QixzQkFBc0J2QixTQUFTLGNBQWNBLFNBQVMsZ0JBQWdCQSxTQUFTLG9CQUFvQjtBQUNySUwsYUFBS3RDLFFBQVFxRyxtQkFBbUIvRCxNQUFNd0IsV0FBVztBQUFBLE1BQ3JELFdBQVduQixTQUFTLGNBQWNBLFNBQVMsZ0JBQWdCQSxTQUFTLG1CQUFtQjtBQUNuRkwsYUFBS3RDLFFBQVE7QUFBQSxNQUNqQjtBQUVBMEssZUFBU1MsS0FBSyxJQUFJN0k7QUFDbEIsYUFBT29JO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNYSw0QkFBNEJBLENBQUNKLE9BQWV4SSxNQUFja0gsVUFBa0I7QUFDOUVxQixxQkFBaUJDLE9BQU8sRUFBRXJCLFFBQVEsRUFBRW5ILE1BQU1rSCxPQUFPUyxPQUFPVCxLQUFLLEVBQUUsRUFBRSxDQUF3QztBQUFBLEVBQzdHO0FBS0EsUUFBTTJCLHVCQUF1QixPQUFPTCxVQUFrQjtBQUNsRCxVQUFNN0ksT0FBT0osTUFBTWlKLEtBQUs7QUFDeEIsUUFBSSxDQUFDN0ksS0FBSzdDLGFBQWM7QUFJeEIsVUFBTSxFQUFFa0gsV0FBV0MsVUFBVSxJQUFJbkosc0JBQXNCaUo7QUFFdkQsUUFBSTtBQUdBLFlBQU02RCxVQUFVLE1BQU05TDtBQUFBQSxRQUFtQjtBQUFBLFFBQ3JDO0FBQUEsVUFBQyxFQUFFK0wsV0FBVzdELFdBQXFCa0QsT0FBT3ZILEtBQUs3QyxhQUFhO0FBQUEsVUFDNUQsRUFBRStLLFdBQVcsYUFBYVgsT0FBT2xHLFNBQVN6QyxXQUFXdUosU0FBUyxLQUFLLEdBQUc7QUFBQSxRQUFDO0FBQUEsTUFDdEU7QUFFTCxVQUFJRixTQUFTO0FBQ1QxRyxpQkFBUyxDQUFBa0YsY0FBYTtBQUNsQixnQkFBTTJCLFdBQVcsQ0FBQyxHQUFHM0IsU0FBUztBQUM5QixnQkFBTUYsZUFBZTFDO0FBQ3JCLGdCQUFNNkMsWUFBWXVCLFFBQVFJLG1CQUFtQjtBQUM3QyxnQkFBTTFCLFdBQVdoTDtBQUFBQSxZQUNic00sUUFBUXpLLGNBQWM7QUFBQSxZQUN0QnlLLFFBQVFNO0FBQUFBLFlBQ1JsSCxTQUFTM0M7QUFBQUEsVUFDYjtBQUNBLGdCQUFNeUssZUFBZWpKLE9BQU9rSSxTQUFTUyxLQUFLLEVBQUV0TCxVQUFVLEtBQUs7QUFDM0QsZ0JBQU02TCxjQUFjbEosT0FBT2tJLFNBQVNTLEtBQUssRUFBRXJMLFVBQVUsS0FBSztBQUMxRCxnQkFBTTZMLGtCQUFrQjVNLG1CQUFtQmlLLFlBQVlILFlBQVk7QUFDbkUsZ0JBQU0rQyxpQkFBaUI3TSxtQkFBbUJrSyxXQUFXSixZQUFZO0FBRWpFLGdCQUFNZ0QsY0FBYztBQUFBLFlBQ2hCLEdBQUduQixTQUFTUyxLQUFLO0FBQUEsWUFDakIzTCxZQUFZK0ssUUFBUW5MO0FBQUFBLFlBQ3BCSyxjQUFjOEssUUFBUTVELFNBQW1CO0FBQUEsWUFDekNqSCxjQUFjNkssUUFBUTNELFNBQW1CO0FBQUEsWUFDekMzRyxrQkFBa0IrSTtBQUFBQSxZQUNsQjlJLGlCQUFpQitJO0FBQUFBLFlBQ2pCOUksZ0JBQWdCb0ssUUFBUXBLO0FBQUFBLFlBQ3hCTixZQUFZNEwsZUFBZSxJQUFJQSxlQUFlRTtBQUFBQSxZQUM5QzdMLFlBQVk0TCxjQUFjLElBQUlBLGNBQWNFO0FBQUFBLFVBQ2hEO0FBR0EsY0FBSWpJLFNBQVN2Qix3QkFBd0IsQ0FBQzhCLG1CQUFtQjtBQUNyRDJILHdCQUFZN0wsUUFBUXFHLG1CQUFtQndGLGFBQWEvSCxXQUFXO0FBQUEsVUFDbkU7QUFFQTRHLG1CQUFTUyxLQUFLLElBQUlVO0FBQ2xCLGlCQUFPbkI7QUFBQUEsUUFDWCxDQUFDO0FBQ0RqTyxjQUFNcVAsUUFBUSxJQUFJdkIsUUFBUTNELFNBQW1CLENBQUMsaUJBQWlCO0FBQUEsTUFDbkUsT0FBTztBQUNIbkssY0FBTStHLE1BQU0saURBQWlEbEIsS0FBSzdDLFlBQVksSUFBSTtBQUFBLE1BQ3RGO0FBQUEsSUFDSixTQUFTc00sS0FBSztBQUNWQyxjQUFReEksTUFBTSwrQkFBK0J1SSxHQUFHO0FBQ2hEdFAsWUFBTStHLE1BQU0sc0NBQXNDO0FBQUEsSUFDdEQ7QUFBQSxFQUNKO0FBR0EsUUFBTXlJLHVCQUF1QkEsQ0FBQ2QsT0FBZWUsWUFBb0I7QUFDN0RySSxhQUFTLENBQUFrRixjQUFhO0FBQ2xCLFlBQU0yQixXQUFXLENBQUMsR0FBRzNCLFNBQVM7QUFDOUIsWUFBTXpHLE9BQU8sRUFBRSxHQUFHb0ksU0FBU1MsS0FBSyxFQUFFO0FBQ2xDN0ksV0FBSzdDLGVBQWV5TTtBQUVwQjVKLFdBQUs5QyxhQUFhO0FBQ2xCOEMsV0FBSzVDLGVBQWU7QUFDcEI0QyxXQUFLekMsYUFBYTtBQUNsQnlDLFdBQUtuQyxpQkFBaUI7QUFDdEJtQyxXQUFLdEMsUUFBUTtBQUNiMEssZUFBU1MsS0FBSyxJQUFJN0k7QUFDbEIsYUFBT29JO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNeUIsK0JBQStCLE9BQU9oQixPQUFlWixZQUFpQjtBQUN4RSxVQUFNLEVBQUU1RCxXQUFXQyxVQUFVLElBQUluSixzQkFBc0JpSjtBQUV2RCxRQUFJO0FBQ0EsWUFBTTBELFdBQVdHLFFBQVFGLE1BQU1DLE9BQU9DLFFBQVFGLEdBQUcsSUFBSTtBQUNyRCxZQUFNK0IsY0FBYyxNQUFNM047QUFBQUEsUUFBbUI7QUFBQSxRQUN6QztBQUFBLFVBQUMsRUFBRStMLFdBQVc3RCxXQUFxQmtELE9BQU9PLFNBQVM7QUFBQSxVQUNuRCxFQUFFSSxXQUFXLGFBQWFYLE9BQU9sRyxTQUFTekMsV0FBV3VKLFNBQVMsS0FBSyxHQUFHO0FBQUEsUUFBQztBQUFBLE1BQ3RFO0FBRUwsVUFBSTJCLGFBQWE7QUFDYnZJLGlCQUFTLENBQUFrRixjQUFhO0FBQ2xCLGdCQUFNMkIsV0FBVyxDQUFDLEdBQUczQixTQUFTO0FBQzlCLGdCQUFNRixlQUFlMUM7QUFDckIsZ0JBQU02QyxZQUFZb0QsWUFBWXpCLG1CQUFtQjtBQUNqRCxnQkFBTTFCLFdBQVdoTDtBQUFBQSxZQUNibU8sWUFBWXRNLGNBQWM7QUFBQSxZQUMxQnNNLFlBQVl2QjtBQUFBQSxZQUNabEgsU0FBUzNDO0FBQUFBLFVBQ2I7QUFDQSxnQkFBTXlLLGVBQWVqSixPQUFPa0ksU0FBU1MsS0FBSyxFQUFFdEwsVUFBVSxLQUFLO0FBQzNELGdCQUFNNkwsY0FBY2xKLE9BQU9rSSxTQUFTUyxLQUFLLEVBQUVyTCxVQUFVLEtBQUs7QUFDMUQsZ0JBQU02TCxrQkFBa0I1TSxtQkFBbUJpSyxZQUFZSCxZQUFZO0FBQ25FLGdCQUFNK0MsaUJBQWlCN00sbUJBQW1Ca0ssV0FBV0osWUFBWTtBQUVqRSxnQkFBTWdELGNBQWM7QUFBQSxZQUNoQixHQUFHbkIsU0FBU1MsS0FBSztBQUFBLFlBQ2pCM0wsWUFBWTRNLFlBQVloTjtBQUFBQSxZQUN4QkssY0FBYzJNLFlBQVl6RixTQUFtQjtBQUFBLFlBQzdDakgsY0FBYzBNLFlBQVl4RixTQUFtQjtBQUFBLFlBQzdDM0csa0JBQWtCK0k7QUFBQUEsWUFDbEI5SSxpQkFBaUIrSTtBQUFBQSxZQUNqQjlJLGdCQUFnQmlNLFlBQVlqTTtBQUFBQSxZQUM1Qk4sWUFBWTRMLGVBQWUsSUFBSUEsZUFBZUU7QUFBQUEsWUFDOUM3TCxZQUFZNEwsY0FBYyxJQUFJQSxjQUFjRTtBQUFBQSxVQUNoRDtBQUVBLGNBQUlqSSxTQUFTdkIsd0JBQXdCLENBQUM4QixtQkFBbUI7QUFDckQySCx3QkFBWTdMLFFBQVFxRyxtQkFBbUJ3RixhQUFhL0gsV0FBVztBQUFBLFVBQ25FO0FBRUE0RyxtQkFBU1MsS0FBSyxJQUFJVTtBQUNsQixpQkFBT25CO0FBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0w7QUFBQSxJQUNKLFNBQVNsSCxRQUFPO0FBQ1p3SSxjQUFReEksTUFBTSxzQ0FBc0NBLE1BQUs7QUFBQSxJQUM3RDtBQUFBLEVBQ0o7QUFHQSxRQUFNNkksa0JBQWtCQSxDQUFDbEIsVUFBa0I7QUFDdkN0SCxhQUFTLENBQUFrRixjQUFhO0FBQ2xCLFlBQU0yQixXQUFXLENBQUMsR0FBRzNCLFNBQVM7QUFDOUIsWUFBTXpHLE9BQU8sRUFBRSxHQUFHb0ksU0FBU1MsS0FBSyxFQUFFO0FBQ2xDN0ksV0FBSzlDLGFBQWE7QUFDbEI4QyxXQUFLN0MsZUFBZTtBQUNwQjZDLFdBQUs1QyxlQUFlO0FBQ3BCNEMsV0FBS3pDLGFBQWE7QUFDbEJ5QyxXQUFLbkMsaUJBQWlCO0FBQ3RCbUMsV0FBS3RDLFFBQVE7QUFDYjBLLGVBQVNTLEtBQUssSUFBSTdJO0FBQ2xCLGFBQU9vSTtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMO0FBS0EsUUFBTTRCLGdCQUFnQkEsTUFBTTtBQUN4QnpJLGFBQVMsQ0FBQWtFLFNBQVEsQ0FBQyxHQUFHQSxNQUFNLEVBQUUsR0FBRzVJLFlBQVlDLElBQUksR0FBR0csYUFBYXdJLEtBQUt6QixTQUFTLEVBQUUsQ0FBQyxDQUFDO0FBQUEsRUFDdEY7QUFFQSxRQUFNaUcsbUJBQW1CQSxDQUFDcEIsVUFBa0I7QUFDeEN0SCxhQUFTLENBQUFrRSxTQUFRQSxLQUFLeUUsT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNdkIsS0FBSyxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNd0IseUJBQXlCQSxDQUFDeEIsVUFBa0I7QUFDOUMsUUFBSWpILGtCQUFtQjtBQUN2QixRQUFJLENBQUNQLFNBQVN6QyxXQUFXO0FBQ3JCekUsWUFBTW1RLEtBQUssMkNBQTJDO0FBQ3REO0FBQUEsSUFDSjtBQUNBNUgsOEJBQTBCbUcsS0FBSztBQUMvQnJHLDBCQUFzQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNK0gsc0JBQXNCQSxDQUFDN00sVUFBd0I7QUFDakQsUUFBSStFLDJCQUEyQixLQUFNO0FBRXJDbEI7QUFBQUEsTUFBUyxDQUFBa0YsY0FDTEEsVUFBVXZCO0FBQUFBLFFBQUksQ0FBQ2xGLE1BQU02SSxVQUNqQkEsVUFBVXBHLHlCQUF5QixFQUFFLEdBQUd6QyxNQUFNdEMsTUFBYSxJQUFJc0M7QUFBQUEsTUFDbkU7QUFBQSxJQUNKO0FBQ0EwQyw4QkFBMEIsSUFBSTtBQUM5QkYsMEJBQXNCLEtBQUs7QUFBQSxFQUMvQjtBQUVBLFFBQU1nSSxzQkFBc0JBLENBQUNDLFlBQXFCO0FBQzlDbkosZ0JBQVksQ0FBQW1FLFVBQVM7QUFBQSxNQUNqQixHQUFHQTtBQUFBQSxNQUNIM0Ysc0JBQXNCMks7QUFBQUEsSUFDMUIsRUFBRTtBQUVGLFFBQUlBLFdBQVcsQ0FBQzdJLG1CQUFtQjtBQUMvQkwsZUFBUyxDQUFBa0UsU0FBUUEsS0FBS1AsSUFBSSxDQUFBbEYsVUFBUztBQUFBLFFBQy9CLEdBQUdBO0FBQUFBLFFBQ0h0QyxPQUFPcUcsbUJBQW1CL0QsTUFBTXdCLFdBQVc7QUFBQSxNQUMvQyxFQUFFLENBQUM7QUFBQSxJQUNQLE9BQU87QUFFSEQsZUFBUyxDQUFBa0UsU0FBUUEsS0FBS1AsSUFBSSxDQUFBbEYsVUFBUyxFQUFFLEdBQUdBLE1BQU10QyxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNKO0FBRUEsUUFBTWdOLGNBQWMsWUFBWTtBQUM1QixRQUFJQyxZQUFZL0ssTUFBTXNGLElBQUksQ0FBQWxGLFVBQVMsRUFBRSxHQUFHQSxLQUFLLEVBQUU7QUFDL0MsUUFBSTRLLG1CQUFtQnZKLFNBQVN2QjtBQUNoQyxRQUFJK0ssWUFBMEJoTDtBQUM5QixRQUFJaUwsbUJBQWlDO0FBRXJDLFFBQUlsSixtQkFBbUI7QUFDbkIsWUFBTW1KLFlBQVkvTyxrQ0FBa0M7QUFBQSxRQUNoRDBCLE9BQU9tQztBQUFBQSxRQUNQRCxPQUFPK0s7QUFBQUEsUUFDUDdLLHNCQUFzQnVCLFNBQVN2QjtBQUFBQSxNQUNuQyxDQUFDO0FBQ0Q2SyxrQkFBWUksVUFBVW5MO0FBQ3RCZ0wseUJBQW1CRyxVQUFVakw7QUFDN0IrSyxrQkFBWUUsVUFBVXJOO0FBQ3RCb04seUJBQW1CO0FBQUEsSUFDdkIsV0FBV3pKLFNBQVN2QixzQkFBc0I7QUFDdEM2SyxrQkFBWUEsVUFBVXpGLElBQUksQ0FBQWxGLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEMsT0FBT3NDLEtBQUt0QyxTQUFTLEdBQUcsRUFBRTtBQUN4RW1OLGtCQUFZO0FBQ1pDLHlCQUFtQjtBQUFBLElBQ3ZCLE9BQU87QUFDSEgsa0JBQVlBLFVBQVV6RixJQUFJLENBQUFsRixVQUFTLEVBQUUsR0FBR0EsTUFBTXRDLE9BQU8sR0FBRyxFQUFFO0FBQzFEb04seUJBQW1CO0FBQUEsSUFDdkI7QUFFQSxVQUFNRSxhQUFrQztBQUFBLE1BQ3BDLEdBQUczSjtBQUFBQSxNQUNIekIsT0FBTytLO0FBQUFBLE1BQ1A3SyxzQkFBc0I4SztBQUFBQSxNQUN0QmxOLE9BQU9tTjtBQUFBQSxNQUNQaEwsY0FBY2lMO0FBQUFBLE1BQ2R2TSxjQUFjb0gsaUJBQWlCVztBQUFBQSxNQUMvQjdJLGlCQUFpQnlDLE9BQU9tQixTQUFTNUQsZUFBZSxLQUFLO0FBQUEsTUFDckRpQixlQUFlMkMsU0FBUzNDLGlCQUFpQjtBQUFBLE1BQ3pDQyx3QkFBd0IsQ0FBQyxDQUFDMEMsU0FBUzFDO0FBQUFBLE1BQ25DRixrQkFBa0JnRjtBQUFBQSxJQUN0QjtBQUVBLFFBQUk7QUFDQWlHLGNBQVF1QixJQUFJLG1CQUFtQkQsVUFBVTtBQUN6QyxZQUFNN0osU0FBUzZKLFVBQXdCO0FBRXZDN1EsWUFBTXFQLFFBQVEsVUFBVTFJLFNBQVMsV0FBVyxXQUFXLGFBQWEsYUFBYTtBQUNqRkQsZUFBU3JFLGtCQUFrQjNCLHdCQUF3QnFRLFNBQVMsQ0FBQztBQUFBLElBQ2pFLFNBQVNDLFVBQWU7QUFDcEJoUixZQUFNK0csTUFBTSxxQkFBcUJpSyxTQUFTbEksV0FBVyxtQkFBbUIsRUFBRTtBQUFBLElBQzlFO0FBQUEsRUFDSjtBQUVBLFFBQU1tSSxhQUFhLFlBQVk7QUFDM0IsVUFBTUMsbUJBQW1CekwsTUFBTXNLLE9BQU8sQ0FBQWxLLFNBQVFBLEtBQUs5QyxjQUFjZ0QsT0FBT0YsS0FBSzlDLFVBQVUsSUFBSSxDQUFDO0FBQzVGLFFBQUltTyxpQkFBaUJySCxXQUFXLEdBQUc7QUFDL0I3SixZQUFNK0csTUFBTSwwRkFBMEY7QUFDdEc7QUFBQSxJQUNKO0FBRUEsUUFBSSxDQUFDRyxTQUFTdEMsYUFBYTtBQUN2QjVFLFlBQU0rRyxNQUFNLDhCQUE4QjtBQUMxQztBQUFBLElBQ0o7QUFFQSxVQUFNb0ssZ0JBQWdCQSxNQUFNO0FBQ3hCbkksZUFBU3ZELE9BQU8sTUFBTTtBQUNsQixhQUFLOEssWUFBWTtBQUFBLE1BQ3JCLENBQUM7QUFBQSxJQUNMO0FBRUEsVUFBTWEsZ0JBQWdCM0wsTUFBTTRMLEtBQUt6TCx3QkFBd0I7QUFDekQsUUFBSXdMLGVBQWU7QUFDZnJJLDhCQUF3QnVJLFVBQVVIO0FBQ2xDeEksb0JBQWM7QUFBQSxRQUNWQyxNQUFNO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLFNBQVM3QyxtQkFBbUJtTCxhQUFhO0FBQUEsTUFDN0MsQ0FBQztBQUNEO0FBQUEsSUFDSjtBQUVBRCxrQkFBYztBQUFBLEVBQ2xCO0FBSUEsUUFBTUkseUJBQXlCQSxDQUFDNUUsT0FBb0I4QyxZQUFvQjtBQUNwRXRJLGdCQUFZLENBQUFtRSxVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDLEdBQUdxQixLQUFLLEtBQUssR0FBRztBQUFBLE1BQ2pCLENBQUMsR0FBR0EsS0FBSyxPQUFPLEdBQUc4QztBQUFBQTtBQUFBQSxNQUNuQixDQUFDLEdBQUc5QyxLQUFLLE9BQU8sR0FBRztBQUFBO0FBQUEsTUFDbkIsQ0FBQyxHQUFHQSxLQUFLLEVBQUUsR0FBR3ZIO0FBQUFBO0FBQUFBLElBQ2xCLEVBQUU7QUFBQSxFQUNOO0FBRUEsUUFBTW9NLHlCQUF5QixPQUFPN0UsT0FBb0JZLFdBQThCO0FBQ3BGLFVBQU1rRSxZQUFZdkssU0FBUyxHQUFHeUYsS0FBSyxPQUEyQjtBQUM5RCxRQUFJLENBQUM4RSxVQUFXO0FBRWhCLFFBQUksQ0FBQ2xFLE9BQU90RCxrQkFBa0I7QUFDMUJqSyxZQUFNK0csTUFBTSxtREFBbUQ0RixLQUFLLEVBQUU7QUFDdEU7QUFBQSxJQUNKO0FBRUEsVUFBTSxFQUFFM0IsU0FBUyxJQUFJdUM7QUFDckIsVUFBTSxFQUFFckQsV0FBV0MsVUFBVSxJQUFJb0QsT0FBT3REO0FBRXhDLFFBQUk7QUFDQSxZQUFNcEUsT0FBTyxNQUFNN0QsY0FBbUJnSixVQUFVLENBQUMsRUFBRStDLFdBQVc3RCxXQUFxQmtELE9BQU9xRSxVQUFVLENBQUMsQ0FBQztBQUV0Ry9FLDJCQUFxQkMsT0FBTzlHLElBQUk7QUFDaEM3RixZQUFNcVAsUUFBUSxJQUFJeEosS0FBS3NFLFNBQW1CLENBQUMsaUJBQWlCO0FBQUEsSUFDaEUsU0FBU21GLEtBQUs7QUFDVkMsY0FBUXhJLE1BQU0sK0JBQStCdUksR0FBRztBQUNoRHRQLFlBQU0rRyxNQUFNLDZCQUE2QjtBQUFBLElBQzdDO0FBQUEsRUFDSjtBQUVBLFFBQU0ySyxvQkFBb0JBLENBQUMvRSxVQUF1QjtBQUM5Q3hGLGdCQUFZLENBQUFtRSxVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDLEdBQUdxQixLQUFLLEtBQUssR0FBRztBQUFBLE1BQ2pCLENBQUMsR0FBR0EsS0FBSyxPQUFPLEdBQUc7QUFBQSxNQUNuQixDQUFDLEdBQUdBLEtBQUssT0FBTyxHQUFHO0FBQUEsTUFDbkIsQ0FBQyxHQUFHQSxLQUFLLEVBQUUsR0FBR3ZIO0FBQUFBLElBQ2xCLEVBQUU7QUFDRixRQUFJdUgsVUFBVSxVQUFVO0FBQ3BCckYscUJBQWUsRUFBRTtBQUNqQkUsNEJBQXNCLElBQUk7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFHQSxRQUFNbUsseUJBQXlCQSxDQUFDQyxXQUFtQnRELE1BQXdCdUQsZ0JBQXdCO0FBQy9GLFFBQUksQ0FBQ0QsV0FBVztBQUNaNVIsWUFBTW1RLEtBQUssNENBQTRDO0FBQ3ZEO0FBQUEsSUFDSjtBQUVBLFFBQUk3QixTQUFTLFNBQVM7QUFDbEI3RiwyQkFBcUI7QUFBQSxRQUNqQnFKLFFBQVE7QUFBQSxRQUNSakosT0FBTyxpQ0FBaUNnSixXQUFXO0FBQUEsUUFDbkQ3RyxVQUFVO0FBQUE7QUFBQSxRQUNWNEc7QUFBQUEsUUFDQUcsVUFBVTdLLFNBQVN6QztBQUFBQSxRQUNuQnVOLFNBQVM1UDtBQUFBQSxNQUNiLENBQUM7QUFBQSxJQUNMLE9BQU87QUFDSHFHLDJCQUFxQjtBQUFBLFFBQ2pCcUosUUFBUTtBQUFBLFFBQ1JqSixPQUFPO0FBQUEsUUFDUG1DLFVBQVU7QUFBQTtBQUFBLFFBQ1Y0RztBQUFBQSxRQUNBRyxVQUFVN0ssU0FBU3pDO0FBQUFBLFFBQ25CdU4sU0FBUzVMO0FBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKO0FBRUEsUUFBTTZMLDBCQUEwQkEsTUFBTTtBQUNsQ3hKLHlCQUFxQnRHLHdCQUF3QjtBQUFBLEVBQ2pEO0FBRUEsUUFBTStQLHdCQUF3QkEsTUFBTTtBQUNoQ3ZKLGtCQUFjLENBQUEyQyxVQUFTLEVBQUUsR0FBR0EsTUFBTTFDLE1BQU0sTUFBTSxFQUFFO0FBQ2hELFVBQU11SixlQUFlcEosd0JBQXdCdUk7QUFDN0N2SSw0QkFBd0J1SSxVQUFVO0FBQ2xDYSxtQkFBZTtBQUFBLEVBQ25CO0FBRUEsUUFBTUMscUJBQXFCQSxDQUFDMUQsVUFBa0I7QUFDMUMsVUFBTTdJLE9BQU9KLE1BQU1pSixLQUFLO0FBQ3hCLFFBQUksQ0FBQzdJLFFBQVEsQ0FBQ0QseUJBQXlCQyxJQUFJLEVBQUc7QUFDOUNrRCw0QkFBd0J1SSxVQUFVO0FBQ2xDM0ksa0JBQWM7QUFBQSxNQUNWQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLFNBQVM3QyxtQkFBbUJKLElBQUk7QUFBQSxJQUNwQyxDQUFDO0FBQUEsRUFDTDtBQUdBLE1BQUlpQixlQUFlSCxTQUFTLE9BQVEsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDMUQsTUFBSUksU0FBU0osU0FBUyxPQUFRLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUF3Qkk7QUFBQUEsT0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0RDtBQUVqRyxRQUFNc0wsa0JBQWtCO0FBQ3hCLFFBQU1DLGtCQUFrQjtBQUV4QixTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFHWDtBQUFBLDJCQUFDLFNBQUksV0FBVSx5Q0FFWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDJCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXcEwsU0FBU3BDLGVBQWU7QUFBQSxjQUNuQyxXQUFXb0MsU0FBU2tELGVBQWVsRCxTQUFTL0IsUUFBUWUsUUFBUTtBQUFBLGNBQzVELGNBQWMsQ0FBQ3VKLFlBQVk4Qix1QkFBdUIsVUFBVTlCLE9BQU87QUFBQSxjQUNuRSxjQUFjLE1BQU0rQix1QkFBdUIsVUFBVTdRLG9CQUFvQjtBQUFBLGNBQ3pFLGVBQWUsTUFBTTJNLGdCQUFnQixVQUFVM00sb0JBQW9CO0FBQUEsY0FDbkUsY0FBYyxNQUFNK1Esa0JBQWtCLFFBQVE7QUFBQTtBQUFBLFlBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1vRDtBQUFBLGFBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVd4SyxTQUFTbkMsb0JBQW9CO0FBQUEsY0FDeEMsV0FBV21DLFNBQVNvRCxvQkFBb0JwRCxTQUFTN0IsYUFBYWEsUUFBUTtBQUFBLGNBQ3RFLGNBQWMsQ0FBQ3VKLFlBQVk4Qix1QkFBdUIsZUFBZTlCLE9BQU87QUFBQSxjQUN4RSxjQUFjLE1BQU0rQix1QkFBdUIsZUFBZTVRLHNCQUFzQjtBQUFBLGNBQ2hGLGVBQWUsTUFBTTBNLGdCQUFnQixlQUFlMU0sc0JBQXNCO0FBQUEsY0FDMUUsY0FBYyxNQUFNOFEsa0JBQWtCLGFBQWE7QUFBQTtBQUFBLFlBTnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU15RDtBQUFBLGFBUjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMseUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVd4SyxTQUFTbEMsY0FBYztBQUFBLGNBQ2xDLFdBQVdrQyxTQUFTcUQsY0FBY3JELFNBQVM1QixPQUFPWSxRQUFRO0FBQUEsY0FDMUQsY0FBYyxDQUFDdUosWUFBWThCLHVCQUF1QixTQUFTOUIsT0FBTztBQUFBLGNBQ2xFLGNBQWMsTUFBTStCLHVCQUF1QixTQUFTM1EsdUJBQXVCO0FBQUEsY0FDM0UsZUFBZSxNQUFNeU0sZ0JBQWdCLFNBQVN6TSx1QkFBdUI7QUFBQSxjQUNyRSxjQUFjLE1BQU02USxrQkFBa0IsT0FBTztBQUFBO0FBQUEsWUFOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTW1EO0FBQUEsYUFSdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsZ0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU94SyxTQUFTbEQsWUFBWUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsY0FDN0MsVUFBVW1LO0FBQUFBLGNBQ1YsY0FBYTtBQUFBLGNBQU0sV0FBVTtBQUFBO0FBQUEsWUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FIO0FBQUEsYUFQekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT25ILFNBQVMvQyxlQUFlRCxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxjQUNoRCxVQUFVbUs7QUFBQUEsY0FDVixjQUFhO0FBQUEsY0FBTSxXQUFVO0FBQUE7QUFBQSxZQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLcUg7QUFBQSxhQVB6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDBCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXbkgsU0FBU2hDLGtCQUFrQjtBQUFBLGNBQ3RDLFdBQVdnQyxTQUFTdUQsa0JBQWtCdkQsU0FBUzFCLFdBQVdVLFFBQVE7QUFBQSxjQUNsRSxjQUFjLENBQUN1SixZQUFZOEIsdUJBQXVCLGFBQWE5QixPQUFPO0FBQUEsY0FDdEUsY0FBYyxNQUFNK0IsdUJBQXVCLGFBQWExUSx1QkFBdUI7QUFBQSxjQUMvRSxlQUFlLE1BQU13TSxnQkFBZ0IsYUFBYXhNLHVCQUF1QjtBQUFBLGNBQ3pFLGNBQWMsTUFBTTRRLGtCQUFrQixXQUFXO0FBQUE7QUFBQSxZQU5yRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNdUQ7QUFBQSxhQVIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwrQkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQywwQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBV3hLLFNBQVNqQyxpQkFBaUI7QUFBQSxjQUNyQyxXQUFXaUMsU0FBU3NELGlCQUFpQnRELFNBQVMzQixVQUFVVyxRQUFRO0FBQUEsY0FDaEUsY0FBYyxDQUFDdUosWUFBWThCLHVCQUF1QixZQUFZOUIsT0FBTztBQUFBLGNBQ3JFLGNBQWMsTUFBTStCLHVCQUF1QixZQUFZelEsbUJBQW1CO0FBQUEsY0FDMUUsZUFBZSxNQUFNdU0sZ0JBQWdCLFlBQVl2TSxtQkFBbUI7QUFBQSxjQUNwRSxjQUFjLE1BQU0yUSxrQkFBa0IsVUFBVTtBQUFBO0FBQUEsWUFOcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXNEO0FBQUEsYUFSMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw4QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsT0FBT3hLLFNBQVMzQyxpQkFBaUI7QUFBQSxjQUNqQyxlQUFlO0FBQUEsY0FDZixVQUFVLENBQUFoQyxRQUFPNEUsWUFBWSxDQUFBbUUsVUFBUyxFQUFFLEdBQUdBLE1BQU0vRyxlQUFlaEMsT0FBTyxFQUFFLEVBQUU7QUFBQSxjQUMzRSxXQUFVO0FBQUE7QUFBQSxZQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtrRztBQUFBLGFBUHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLFNBQVMsQ0FBQyxDQUFDMkUsU0FBUzFDO0FBQUFBLGNBRXBCLFVBQVU2SjtBQUFBQSxjQUNWLGNBQWE7QUFBQSxjQUFNLFdBQVU7QUFBQTtBQUFBLFlBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9rRjtBQUFBLFVBRWxGLHVCQUFDLFdBQU0sU0FBUSwwQkFBeUIsV0FBVSxvQ0FBa0MsbUNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLGlDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBRTVFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FFTCxPQUFPakYsa0JBQWtCLHVCQUF3QkUsd0JBQXdCSixnQkFBZ0JXLFNBQVMsSUFBSVgsZ0JBQWdCLENBQUMsSUFBSTtBQUFBLGNBQzNILFVBQVVnRTtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLFVBQVUsQ0FBQ2hHLFNBQVN6QztBQUFBQSxjQUVwQjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxJQUFHLHdDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLGlCQUV2Q3lFLG1CQUFtQixJQUFJNkI7QUFBQUEsa0JBQUksQ0FBQ3dILFNBQVM3RCxVQUNuQyx1QkFBQyxZQUFtQixPQUFPNkQsU0FDdEJBLHFCQURRN0QsT0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0g7QUFBQSxnQkFFRCx1QkFBQyxZQUFPLE9BQU0sc0JBQXFCLCtDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRTtBQUFBO0FBQUE7QUFBQSxZQWhCdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsVUFHQ3RGLG1CQUNHO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxNQUFNO0FBQUEsY0FDTixPQUFPRTtBQUFBQSxjQUNQLFVBQVUsQ0FBQTZELE1BQUs1RCx1QkFBdUI0RCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsY0FDcEQsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBLGNBQXVGLGNBQWE7QUFBQTtBQUFBLFlBTmxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU11SDtBQUFBLGFBOUIvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQywrQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT2xHLFNBQVNuRCx5QkFBeUI7QUFBQSxjQUN6QyxVQUFVc0s7QUFBQUEsY0FDVixjQUFhO0FBQUEsY0FBTSxXQUFVO0FBQUE7QUFBQSxZQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLcUg7QUFBQSxhQVB6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBO0FBQUEsU0E3Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThKQTtBQUFBLElBSUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLCtDQUE4QyxnQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzNFLENBQUM1RyxxQkFDRSx1QkFBQyxTQUFJLFdBQVUsc0NBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVcsdUJBQXVCLENBQUNQLFNBQVN2Qix1QkFBdUIsb0JBQW9CLGVBQWUsSUFBSSwyQkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQSxVQUMzSCx1QkFBQyxnQkFBYSxTQUFTdUIsU0FBU3ZCLHNCQUFzQixVQUFVMEsscUJBQXFCLFNBQVEsdUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdIO0FBQUEsVUFDaEgsdUJBQUMsVUFBSyxXQUFXLHVCQUF1Qm5KLFNBQVN2Qix1QkFBdUIsb0JBQW9CLGVBQWUsSUFBSSw2QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEg7QUFBQSxhQUhoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0ZBQXVGLHdCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYscUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsVUFDcEcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixxQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxVQUNwRyx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGO0FBQUE7QUFBQSxZQUFXNkQ7QUFBQUEsWUFBYztBQUFBLGVBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlIO0FBQUEsVUFFekgsdUJBQUMsUUFBRyxXQUFVLHlGQUF3Riw2QkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUg7QUFBQSxVQUNuSCx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHdCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RztBQUFBLFVBRXRHLENBQUMvQixxQkFBcUJQLFNBQVN2Qix3QkFDNUIsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRix5QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0c7QUFBQSxVQUU1Ryx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHdCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RztBQUFBLFVBQ3ZHLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsMkJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBHO0FBQUEsVUFDMUcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixvQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQWR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaRixnQkFBTXNGLElBQUksQ0FBQ2xGLE1BQU02SSxVQUFVO0FBQ3hCLGdCQUFNakQsV0FBWTFGLE9BQU9GLEtBQUszQyxRQUFRLElBQUk2QyxPQUFPRixLQUFLekMsVUFBVTtBQUNoRSxnQkFBTW9QLFdBQVd6TSxPQUFPRixLQUFLdkMsZUFBZSxLQUFLO0FBQ2pELGdCQUFNbVAsZUFBZWhILFdBQVcrRztBQUVoQyxnQkFBTUUsV0FBWTNNLE9BQU9GLEtBQUszQyxRQUFRLElBQUk2QyxPQUFPRixLQUFLeEMsVUFBVTtBQUNoRSxjQUFJc1AsVUFBVUYsZUFBZUMsWUFBWUEsV0FBVztBQUVwRCxjQUFJckcsTUFBTXNHLE1BQU07QUFDWkEscUJBQVM7QUFFYixnQkFBTUMsZUFBZSxDQUFDbkwscUJBQXFCUCxTQUFTdkIsd0JBQzdDRSxLQUFLdEMsU0FBUyxJQUFJbUksT0FBTyxDQUFDQyxLQUFLYixRQUFRYSxNQUFNNUYsT0FBTytFLElBQUlvQixNQUFNLEdBQUcsQ0FBQyxJQUNuRTtBQUVOLGdCQUFNMkcsWUFBWUosZUFBZUc7QUFFakMsaUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSwrQkFDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVcvTSxLQUFLN0MsZ0JBQWdCO0FBQUEsZ0JBQ2hDLFdBQVc2QyxLQUFLNUMsZ0JBQWdCO0FBQUEsZ0JBQ2hDLGNBQWMsQ0FBQ3dNLFlBQVlELHFCQUFxQmQsT0FBT2UsT0FBTztBQUFBLGdCQUM5RCxjQUFjLE1BQU1WLHFCQUFxQkwsS0FBSztBQUFBLGdCQUM5QyxlQUFlLE1BQU1wQixnQkFBZ0IsUUFBUXRNLHVCQUF1QjBOLEtBQUs7QUFBQSxnQkFDekUsY0FBYyxNQUFNa0IsZ0JBQWdCbEIsS0FBSztBQUFBLGdCQUN6QyxNQUFLO0FBQUEsZ0JBQ0wsb0JBQW9CO0FBQUEsZ0JBQ3BCLG9CQUFvQjtBQUFBLGtCQUNoQjFELFVBQVVoSyxzQkFBc0JnSztBQUFBQSxrQkFDaENkLFdBQVc7QUFBQSxrQkFDWEMsV0FBVztBQUFBLGtCQUNYMkksY0FBYzdSO0FBQUFBLGtCQUNkOFIsVUFBVUEsQ0FBQ2pGLFlBQVk7QUFDbkI0QixpREFBNkJoQixPQUFPWixPQUFPO0FBQUEsa0JBQy9DO0FBQUEsZ0JBQ0o7QUFBQTtBQUFBLGNBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCTSxLQWxCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNWLGlDQUFDLGdCQUFhLE1BQUssWUFBVyxPQUFPakksS0FBSzNDLFVBQVUsVUFBVSxDQUFBWCxRQUFPdU0sMEJBQTBCSixPQUFPLFlBQVluTSxHQUFHLEdBQUcsUUFBUSxNQUFNNlAsbUJBQW1CMUQsS0FBSyxHQUFHLFdBQVUsc0ZBQTNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZQLEtBRGpRO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFDVDdJLGVBQUtuQyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsK0JBQ1YsaUNBQUMsZ0JBQWEsTUFBSyxjQUFhLE9BQU9tQyxLQUFLekMsWUFBWSxVQUFVLENBQUFiLFFBQU91TSwwQkFBMEJKLE9BQU8sY0FBY25NLEdBQUcsR0FBRyxXQUFVLHNGQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwTixLQUQ5TjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsc0NBRVYsaUNBQUMsZ0JBQWEsTUFBSyxtQkFBa0IsT0FBT3NELEtBQUt2QyxpQkFBaUIsVUFBVSxDQUFBZixRQUFPdU0sMEJBQTBCSixPQUFPLG1CQUFtQm5NLEdBQUcsR0FBRyxXQUFVLHNGQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5TyxLQUY3TztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUscURBQ1RkLHNCQUFZZ1IsY0FBYyxVQUFVLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVDLENBQUNoTCxxQkFBcUJQLFNBQVN2Qix3QkFDNUIsdUJBQUMsUUFBRyxXQUFVLHFEQUNUbEUsc0JBQVltUixjQUFjLFVBQVUsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUosdUJBQUMsUUFBRyxXQUFXLG1EQUFtREQsVUFBVSxJQUFJLG1CQUFtQixjQUFjLElBQzVHbFIsc0JBQVlrUixRQUFRLFlBQVksS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLG1FQUNUbFIsc0JBQVlvUixXQUFXLFVBQVUsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDZEQUNWO0FBQUEscUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNbEIsdUJBQXVCOUwsS0FBSzlDLFlBQVksU0FBUzhDLEtBQUs1QyxZQUFZLEdBQUcsV0FBVSx5Q0FBd0MsT0FBTSw0QkFDOUosaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNME8sdUJBQXVCOUwsS0FBSzlDLFlBQVksUUFBUThDLEtBQUs1QyxZQUFZLEdBQUcsV0FBVSx5Q0FBd0MsT0FBTSwyQkFDN0osaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWSxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQyxDQUFDd0UscUJBQXFCUCxTQUFTdkIsd0JBQzVCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTXVLLHVCQUF1QnhCLEtBQUssR0FBRyxXQUFVLDZDQUE0QyxPQUFNLGdDQUM1SCxpQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVKLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTW9CLGlCQUFpQnBCLEtBQUssR0FBRyxXQUFVLHVDQUFzQyxPQUFNLGlCQUNoSCxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVEsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBbEVLN0ksS0FBS2xELE1BQU0rTCxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1FQTtBQUFBLFFBRVIsQ0FBQyxLQXhGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUZBO0FBQUEsV0E1R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZHQSxLQTlHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0dBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTbUIsZUFBZSxXQUFVLDJKQUNwRDtBQUFBLCtCQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBO0FBQUEsV0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FoSUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlJQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHVEQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUVYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFVBQ1g7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLHdDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxPQUFPM0ksU0FBUzVEO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQWYsUUFBTzRFLFlBQVksQ0FBQW1FLFVBQVMsRUFBRSxHQUFHQSxNQUFNaEksaUJBQWlCZixJQUFJLEVBQUU7QUFBQSxjQUN4RSxXQUFVO0FBQUE7QUFBQSxZQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlrRztBQUFBLGFBTnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE1BQU07QUFBQSxjQUNOLE9BQU8yRSxTQUFTN0MsU0FBUztBQUFBLGNBQ3pCLFVBQVVnSztBQUFBQSxjQUNWLGNBQWE7QUFBQSxjQUFNLFdBQVU7QUFBQTtBQUFBLFlBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtxSDtBQUFBLGFBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFFVixXQUFDNUcscUJBQXFCLENBQUNQLFNBQVN2Qix3QkFDN0IsdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLDRDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDN0VELGFBQWFtRSxTQUFTLElBQ25CbkUsYUFBYXFGO0FBQUFBLFVBQUksQ0FBQUQsUUFDYix1QkFBQyxTQUFxQixXQUFVLHFDQUM1QjtBQUFBLG1DQUFDLFVBQUssV0FBV3VILGlCQUFrQnZIO0FBQUFBLGtCQUFJa0k7QUFBQUEsY0FBUztBQUFBLGNBQUdsSSxJQUFJbkI7QUFBQUEsY0FBSztBQUFBLGlCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLFlBQy9ELHVCQUFDLFVBQUssV0FBVzJJLGlCQUFrQjdRLHNCQUFZcUosSUFBSW9CLFFBQVEsVUFBVSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmpFcEIsSUFBSW1JLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0gsSUFFRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLG9EQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsV0FWakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBLEtBZlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNYLGlDQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXWixpQkFBaUIsaUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBa0I3USxzQkFBWStKLGlCQUFpQkMsVUFBVSxVQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsYUFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVc0RyxpQkFBaUIsOEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDaEQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUc3USxZQUFZK0osaUJBQWlCSSxvQkFBb0IsVUFBVTtBQUFBLGVBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsYUFGdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVd5RyxpQkFBaUIsK0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUc3USxZQUFZK0osaUJBQWlCSyxzQkFBc0IsVUFBVTtBQUFBLGVBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsYUFGeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQyxDQUFDcEUscUJBQ0UsbUNBQ0k7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0RBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsR0FBRzRLLGVBQWUsa0JBQWtCLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLFVBQUssV0FBVyxHQUFHQyxlQUFlLGtCQUFtQjdRLHNCQUFZK0osaUJBQWlCMUIsU0FBUyxVQUFVLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsZUFGNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXdUksaUJBQ1puTCxtQkFBU3ZCLHVCQUF1Qix1QkFBdUIseUJBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVzJNLGlCQUFpQjtBQUFBO0FBQUEsY0FBRzdRLFlBQVkrSixpQkFBaUJNLFlBQVksVUFBVTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBSjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUosdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUd1RyxlQUFlLDBCQUEwQiw0QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxVQUFLLFdBQVcsR0FBR0MsZUFBZSxzQ0FBdUM3USxzQkFBWStKLGlCQUFpQlcsT0FBTyxVQUFVLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsYUFGOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0E5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQSxLQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsU0E5RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNekYsU0FBU3JFLGtCQUFrQjNCLHdCQUF3QnFRLFNBQVMsQ0FBQyxHQUFHLFdBQVUsOElBQTZJLHdCQUE1UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9RO0FBQUEsTUFDcFE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVNFO0FBQUFBLFVBQ1QsVUFBVWhLO0FBQUFBLFVBQ1YsV0FBVTtBQUFBLFVBRVRBO0FBQUFBLHFCQUFTLHVCQUFDLGFBQVUsV0FBVSwrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0QsSUFBTSx1QkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQU52RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHQ1csZUFBZUUsZUFDWix1QkFBQyxlQUFZLFFBQVFGLGFBQWEsU0FBUyxNQUFNQyxlQUFlLEtBQUssR0FBRyxVQUFVNkYsbUJBQW1CLFFBQVE1RixlQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlIO0FBQUEsSUFFNUhNLHNCQUFzQkUsMkJBQTJCLFFBQzlDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRRjtBQUFBQSxRQUNSLFNBQVMsTUFBTUMsc0JBQXNCLEtBQUs7QUFBQSxRQUUxQyxRQUFRK0g7QUFBQUEsUUFDUixNQUFNM0ssTUFBTTZDLHNCQUFzQjtBQUFBLFFBQ2xDO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPMkM7QUFBQSxJQUs5Q0Usa0JBQWtCc0osVUFDZjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUXRKLGtCQUFrQnNKO0FBQUFBLFFBQzFCLFNBQVNHO0FBQUFBLFFBQ1QsT0FBT3pKLGtCQUFrQks7QUFBQUEsUUFDekIsVUFBVUwsa0JBQWtCd0M7QUFBQUEsUUFDNUIsV0FBV3hDLGtCQUFrQm9KO0FBQUFBLFFBQzdCLFVBQVVwSixrQkFBa0J1SjtBQUFBQSxRQUM1QixTQUFTdkosa0JBQWtCd0o7QUFBQUE7QUFBQUEsTUFQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT3VDO0FBQUEsSUFHM0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVF0SixXQUFXRTtBQUFBQSxRQUNuQixTQUFTc0o7QUFBQUEsUUFDVCxPQUFPeEosV0FBV0c7QUFBQUEsUUFDbEIsU0FBU0gsV0FBV0k7QUFBQUE7QUFBQUEsTUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWdDO0FBQUEsSUFHL0JHO0FBQUFBLE9BM2FMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0YUE7QUFFUjtBQUFFeEMsR0FoeUNXRCxzQkFBb0I7QUFBQSxVQUNkekcsV0FDRUQsYUFHeUNVLGFBQ3BCQSxhQTJCTkMsMEJBQTBCO0FBQUE7QUFBQXlTLEtBakNqRDFNO0FBQW9CLElBQUEwTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ0b2FzdCIsIkZhU2F2ZSIsIkZhU3Bpbm5lciIsIkZhUGx1cyIsIkZhVHJhc2giLCJGYVBlcmNlbnRhZ2UiLCJGYVRhZ3MiLCJGYVdhcmVob3VzZSIsInVzZUNydWRJdGVtIiwidXNlU3VwZXJ2aXNvckxvd1Byb2ZpdEF1dGgiLCJzYWxlc09yZGVyc01vZHVsZUNvbmZpZyIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwidmVuZGVkb3Jlc01vZHVsZUNvbmZpZyIsImNvbXByYWRvcmVzTW9kdWxlQ29uZmlnIiwidHJhbnNwb3J0ZXNNb2R1bGVDb25maWciLCJtb25lZGFzTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMiLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsIkxvYWRpbmdTcGlubmVyIiwiQWxlcnRNb2RhbCIsIlRvZ2dsZVN3aXRjaCIsInByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlIiwiZm9ybWF0VmFsdWUiLCJjb21wdXRlRXhlbXB0RG9jdW1lbnRUb3RhbCIsImdldEVmZmVjdGl2ZUNsaWVudFRheGVzIiwiaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdCIsInNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCIsImNvbXB1dGVTYWxlc0FwcGxpZWRUYXhlcyIsImdldEJ5SWQiLCJzZWFyY2hCeUZpZWxkIiwiSXRlbVRheE1vZGFsIiwiUHJvZHVjdEhpc3RvcnlNb2RhbCIsImluaXRpYWxIaXN0b3J5TW9kYWxTdGF0ZSIsInByaWNlTGlzdENvbHVtbnMiLCJnZXRMaXN0UmV0dXJuUGF0aCIsInJvdW5kVG9Ud29EZWNpbWFscyIsIm51bSIsIk1hdGgiLCJyb3VuZCIsIkVNUFRZX0lURU0iLCJpZCIsIkRhdGUiLCJub3ciLCJsaW5lX251bWJlciIsInByb2R1Y3RfaWQiLCJwcm9kdWN0X2NvZGUiLCJwcm9kdWN0X25hbWUiLCJxdWFudGl0eSIsInBlbmRpbmdfcXVhbnRpdHkiLCJ1bml0X3ByaWNlIiwiY29zdF9wcmljZSIsImRpc2NvdW50X2Ftb3VudCIsInRheGVzIiwiYmFzZV9zYWxlc19wcmljZSIsImJhc2VfY29zdF9wcmljZSIsInN0b2NrX3F1YW50aXR5IiwiZGVmYXVsdEluaXRpYWxEYXRhIiwib3JkZXJfbnVtYmVyIiwic2VyaWVzIiwic3RhdHVzIiwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyIiwib3JkZXJfZGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJkZWxpdmVyeV9kYXRlIiwidG90YWxfYW1vdW50Iiwibm90ZXMiLCJkZWxpdmVyeV9hZGRyZXNzIiwiZXhjaGFuZ2VfcmF0ZSIsImlzX2V4Y2hhbmdlX3JhdGVfZml4ZWQiLCJjbGllbnRfaWQiLCJzYWxlc3BlcnNvbl9pZCIsImJ1eWVyX2lkIiwiY3VycmVuY3lfaWQiLCJ0cmFuc3BvcnRfaWQiLCJjbGllbnRfY29kZSIsInNhbGVzcGVyc29uX2NvZGUiLCJidXllcl9jb2RlIiwiY3VycmVuY3lfY29kZSIsInRyYW5zcG9ydF9jb2RlIiwiY2xpZW50IiwidW5kZWZpbmVkIiwic2FsZXNwZXJzb24iLCJidXllciIsImN1cnJlbmN5IiwidHJhbnNwb3J0IiwiaXRlbXMiLCJhcHBsaWVkVGF4ZXMiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsImlzTGluZU92ZXJBdmFpbGFibGVTdG9jayIsIml0ZW0iLCJxIiwiTnVtYmVyIiwicyIsInN0b2NrRXhjZXNzTWVzc2FnZSIsIm5hbWUiLCJjb2RlIiwiY29zdExpc3RDb2x1bW5zIiwiaGVhZGVyIiwiYWNjZXNzb3IiLCJmb3JtYXQiLCJQZWRpZG9zVmVudGFGb3JtUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJtb2RlIiwibG9hZGVkRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nRGF0YSIsImVycm9yIiwic2F2ZUl0ZW0iLCJzYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0SXRlbXMiLCJjbGllbnRUYXhlcyIsInNldENsaWVudFRheGVzIiwiY2xpZW50VGF4Q29uZGl0aW9uIiwic2V0Q2xpZW50VGF4Q29uZGl0aW9uIiwiaXNDbGllbnRUYXhFeGVtcHQiLCJzZXRJc0NsaWVudFRheEV4ZW1wdCIsInNldEFwcGxpZWRUYXhlcyIsImlzTW9kYWxPcGVuIiwic2V0SXNNb2RhbE9wZW4iLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJlZGl0aW5nSXRlbUluZGV4Iiwic2V0RWRpdGluZ0l0ZW1JbmRleCIsImlzSXRlbVRheE1vZGFsT3BlbiIsInNldElzSXRlbVRheE1vZGFsT3BlbiIsImN1cnJlbnRJdGVtSW5kZXhGb3JUYXgiLCJzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4IiwiaGlzdG9yeU1vZGFsU3RhdGUiLCJzZXRIaXN0b3J5TW9kYWxTdGF0ZSIsInN0b2NrQWxlcnQiLCJzZXRTdG9ja0FsZXJ0Iiwib3BlbiIsInRpdGxlIiwibWVzc2FnZSIsInBlbmRpbmdBZnRlclN0b2NrQWNrUmVmIiwiZ2F0ZVNhdmUiLCJhdXRoTW9kYWwiLCJjbGllbnRBZGRyZXNzZXMiLCJzZXRDbGllbnRBZGRyZXNzZXMiLCJpc0N1c3RvbUFkZHJlc3MiLCJzZXRJc0N1c3RvbUFkZHJlc3MiLCJ0ZW1wRGVsaXZlcnlBZGRyZXNzIiwic2V0VGVtcERlbGl2ZXJ5QWRkcmVzcyIsInNpbWJvbG9Nb25lZGEiLCJzZXRTaW1ib2xvTW9uZWRhIiwiZWZmZWN0aXZlRXhjaGFuZ2VSYXRlIiwicmF0ZSIsImNhbGN1bGF0ZUl0ZW1UYXhlcyIsImxlbmd0aCIsInRheEJhc2UiLCJuZXRCYXNlIiwiaHlkcmF0ZWREYXRhIiwicmVsYXRpb25hbEZpZWxkcyIsImNvZGVGaWVsZCIsIm5hbWVGaWVsZCIsImNsaWVudF9uYW1lIiwicmVsIiwic2FsZXNwZXJzb25fbmFtZSIsImJ1eWVyX25hbWUiLCJjdXJyZW5jeV9uYW1lIiwidHJhbnNwb3J0X25hbWUiLCJzaGlwYWRkcmVzcyIsImlzQ3VzdG9tIiwiaW5jbHVkZXMiLCJpc0V4ZW1wdE9uTG9hZCIsInRheCIsIm1hcCIsImVuZHBvaW50IiwidGhlbiIsImNsaWVudERhdGEiLCJleGVtcHQiLCJuZXdDbGllbnRUYXhlcyIsInJlbGF0ZWRUYXhlcyIsInByZXYiLCJjYXRjaCIsImNhbGN1bGF0ZWRUb3RhbHMiLCJzdWJ0b3RhbCIsInJlZHVjZSIsInN1bSIsInRvdGFsSXRlbURpc2NvdW50cyIsImdsb2JhbERpc2NvdW50QW1vdW50IiwidG90YWxUYXhlcyIsIml0ZW1UYXhlcyIsIml0ZW1UYXhBbW91bnQiLCJpdGVtU3VtIiwiYW1vdW50IiwidG90YWwiLCJleGNoYW5nZVJhdGUiLCJpc05hTiIsInByZXZJdGVtcyIsImJhc2VQcmljZSIsImJhc2VDb3N0IiwibmV3SXRlbSIsImFwcGx5SGVhZGVyU2VsZWN0aW9uIiwiZmllbGQiLCJzZWxlY3RlZEl0ZW0iLCJtb2R1bGVDb25maWciLCJ1cGRhdGVkRGF0YSIsImFkZHJlc3NlcyIsInNhbGVzcmVwIiwic2FsZXNSZXBSZWxhdGlvbiIsImhhbmRsZURlbGl2ZXJ5QWRkcmVzc0NoYW5nZSIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImhhbmRsZU9wZW5Nb2RhbCIsImNvbmZpZyIsIml0ZW1JbmRleCIsImluaXRpYWxGaWx0ZXJzIiwiaGFuZGxlU2VsZWN0TW9kYWwiLCJza3VWYWx1ZSIsInNrdSIsIlN0cmluZyIsInByb2R1Y3QiLCJmaWVsZE5hbWUiLCJ0b1N0cmluZyIsIm5ld0l0ZW1zIiwic3VnZ2VzdGVkX3ByaWNlIiwic2FsZV9wcmljZSIsImNvc3RfY3VycmVuY3kiLCJoYW5kbGVJbnB1dENoYW5nZSIsInR5cGUiLCJmaW5hbFZhbHVlIiwiY2hlY2tlZCIsImhhbmRsZUl0ZW1DaGFuZ2UiLCJpbmRleCIsIm51bUZpZWxkcyIsInN0b3JlZFZhbHVlIiwibmV3VmFsdWUiLCJkaXNwYXRjaEl0ZW1OdW1lcmljQ2hhbmdlIiwiaGFuZGxlSXRlbUNvZGVTdWJtaXQiLCJjdXJyZW50UHJpY2UiLCJjdXJyZW50Q29zdCIsImNhbGN1bGF0ZWRQcmljZSIsImNhbGN1bGF0ZWRDb3N0IiwidXBkYXRlZEl0ZW0iLCJzdWNjZXNzIiwiZXJyIiwiY29uc29sZSIsImhhbmRsZUl0ZW1Db2RlQ2hhbmdlIiwibmV3Q29kZSIsImhhbmRsZUl0ZW1BdXRvY29tcGxldGVTZWxlY3QiLCJmdWxsUHJvZHVjdCIsImhhbmRsZUl0ZW1DbGVhciIsImhhbmRsZUFkZEl0ZW0iLCJoYW5kbGVSZW1vdmVJdGVtIiwiZmlsdGVyIiwiXyIsImkiLCJoYW5kbGVPcGVuSXRlbVRheE1vZGFsIiwid2FybiIsImhhbmRsZVNhdmVJdGVtVGF4ZXMiLCJoYW5kbGVUYXhNb2RlQ2hhbmdlIiwiZW5hYmxlZCIsImV4ZWN1dGVTYXZlIiwic2F2ZUl0ZW1zIiwic2F2ZUhhc0l0ZW1UYXhlcyIsInNhdmVUYXhlcyIsInNhdmVBcHBsaWVkVGF4ZXMiLCJzYW5pdGl6ZWQiLCJkYXRhVG9TZW5kIiwibG9nIiwiYmFzZVJvdXRlIiwiYXBpRXJyb3IiLCJoYW5kbGVTYXZlIiwiaXRlbXNXaXRoUHJvZHVjdCIsInByb2NlZWRUb1NhdmUiLCJvdmVyU3RvY2tJdGVtIiwiZmluZCIsImN1cnJlbnQiLCJoYW5kbGVIZWFkZXJDb2RlQ2hhbmdlIiwiaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCIsImNvZGVWYWx1ZSIsImhhbmRsZUhlYWRlckNsZWFyIiwiaGFuZGxlT3Blbkhpc3RvcnlNb2RhbCIsInByb2R1Y3RJZCIsInByb2R1Y3ROYW1lIiwiaXNPcGVuIiwiY2xpZW50SWQiLCJjb2x1bW5zIiwiaGFuZGxlQ2xvc2VIaXN0b3J5TW9kYWwiLCJoYW5kbGVDbG9zZVN0b2NrQWxlcnQiLCJjb250aW51ZVNhdmUiLCJoYW5kbGVRdWFudGl0eUJsdXIiLCJ0b3RhbExhYmVsU3R5bGUiLCJ0b3RhbFZhbHVlU3R5bGUiLCJhZGRyZXNzIiwiZGlzY291bnQiLCJsaW5lU3VidG90YWwiLCJsaW5lQ29zdCIsInByb2ZpdCIsIml0ZW1UYXhUb3RhbCIsImxpbmVUb3RhbCIsInNlYXJjaFBhcmFtcyIsIm9uU2VsZWN0IiwidGF4X25hbWUiLCJ0YXhfaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZWRpZG9zVmVudGFGb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNhdmUsIEZhU3Bpbm5lciwgRmFQbHVzLCBGYVRyYXNoLCBGYVBlcmNlbnRhZ2UsIEZhVGFncywgRmFXYXJlaG91c2UgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHVzZVN1cGVydmlzb3JMb3dQcm9maXRBdXRoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlU3VwZXJ2aXNvckxvd1Byb2ZpdEF1dGgnO1xuaW1wb3J0IHsgc2FsZXNPcmRlcnNNb2R1bGVDb25maWcsIHR5cGUgU2FsZXNPcmRlciwgdHlwZSBTYWxlc09yZGVySXRlbSB9IGZyb20gJy4uL3BlZGlkb3NfdmVudGFfY29uZmlnJztcblxuLy8gSW1wb3J0YW1vcyB0b2RhcyBsYXMgY29uZmlnc1xuaW1wb3J0IHsgY2xpZW50ZXNNb2R1bGVDb25maWcsIHR5cGUgQ2xpZW50ZSB9IGZyb20gJy4uLy4uL2NsaWVudGVzL2NsaWVudGVzLmNvbmZpZyc7XG5pbXBvcnQgeyB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vdmVuZGVkb3Jlcy92ZW5kZWRvcmVzLmNvbmZpZyc7XG4vLyAtLS0gTU9ESUZJQ0FETzogSW1wb3J0YW1vcyBDb21wcmFkb3IgeSBUcmFuc3BvcnRlIC0tLVxuaW1wb3J0IHsgY29tcHJhZG9yZXNNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9jb21wcmFkb3Jlcy9jb21wcmFkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi90cmFuc3BvcnRlcy90cmFuc3BvcnRlcy5jb25maWcnO1xuaW1wb3J0IHsgbW9uZWRhc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL21vbmVkYXMvbW9uZWRhcy5jb25maWcnO1xuaW1wb3J0IHsgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCBhcnRpY3Vsb3NJdGVtU2VhcmNoRmlsdGVycyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJztcblxuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBBbGVydE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9BbGVydE1vZGFsJztcbmltcG9ydCB7IFRvZ2dsZVN3aXRjaCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvVG9nZ2xlU3dpdGNoJztcblxuXG5pbXBvcnQgeyBwcm9kdWN0Q29zdFRvQmFzZUNvc3RQcmljZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Byb2R1Y3RDb3N0VG9CYXNlJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyB0eXBlIEFwcGxpZWRUYXgsIHR5cGUgUmVsYXRlZFRheCBhcyBDbGllbnRUYXggfSBmcm9tICcuLi8uLi8uLi90eXBlcy9hcHBsaWVkVGF4ZXMnO1xuaW1wb3J0IHtcbiAgICBjb21wdXRlRXhlbXB0RG9jdW1lbnRUb3RhbCxcbiAgICBnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyxcbiAgICBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0LFxuICAgIHNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCxcbn0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvY2xpZW50VGF4RXhlbXB0aW9uJztcbmltcG9ydCB7IGNvbXB1dGVTYWxlc0FwcGxpZWRUYXhlcyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3NhbGVzUmVsYXRlZFRheENvbXB1dGF0aW9uJztcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaEJ5RmllbGQgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IEl0ZW1UYXhNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0l0ZW1UYXhNb2RhbCc7XG5cbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnLCBDb2x1bW5EZWZpbml0aW9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJzsgLy8g4pyFIDIuIEltcG9ydGFyIENvbHVtbkRlZmluaXRpb25cbmltcG9ydCB7IFByb2R1Y3RIaXN0b3J5TW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SGlzdG9yeU1vZGFsJzsgLy8g4pyFIDMuIEltcG9ydGFyIG51ZXZvIE1vZGFsXG5pbXBvcnQgeyBpbml0aWFsSGlzdG9yeU1vZGFsU3RhdGUsIHByaWNlTGlzdENvbHVtbnMsIHR5cGUgSGlzdG9yeU1vZGFsU3RhdGUgfSBmcm9tICcuLi8uLi8uLi90eXBlcy9oaXN0b3J5TW9kYWwnO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbnR5cGUgRWRpdGluZ1RhcmdldCA9ICdjbGllbnQnIHwgJ3NhbGVzcGVyc29uJyB8ICdidXllcicgfCAnY3VycmVuY3knIHwgJ3RyYW5zcG9ydCcgfCAnaXRlbSc7XG50eXBlIEhlYWRlckZpZWxkID0gJ2NsaWVudCcgfCAnc2FsZXNwZXJzb24nIHwgJ2J1eWVyJyB8ICdjdXJyZW5jeScgfCAndHJhbnNwb3J0JztcblxuY29uc3Qgcm91bmRUb1R3b0RlY2ltYWxzID0gKG51bTogbnVtYmVyKTogbnVtYmVyID0+IHtcbiAgICByZXR1cm4gTWF0aC5yb3VuZChudW0gKiAxMDApIC8gMTAwO1xufTtcblxuY29uc3QgRU1QVFlfSVRFTTogU2FsZXNPcmRlckl0ZW0gPSB7XG4gICAgaWQ6IERhdGUubm93KCksXG4gICAgbGluZV9udW1iZXI6IDAsXG4gICAgcHJvZHVjdF9pZDogMCxcbiAgICBwcm9kdWN0X2NvZGU6ICcnLFxuICAgIHByb2R1Y3RfbmFtZTogJycsXG4gICAgcXVhbnRpdHk6IDEsXG4gICAgcGVuZGluZ19xdWFudGl0eTogMCxcbiAgICB1bml0X3ByaWNlOiAwLFxuICAgIGNvc3RfcHJpY2U6IDAsXG4gICAgLy8gLS0tIE1PRElGSUNBRE86IFVzYW1vcyBkaXNjb3VudF9hbW91bnQgLS0tXG4gICAgZGlzY291bnRfYW1vdW50OiAwLFxuICAgIHRheGVzOiBbXSxcbiAgICBiYXNlX3NhbGVzX3ByaWNlOiAwLCAvLyDinIUgTlVFVk86IFZhbG9yIGJhc2VcbiAgICBiYXNlX2Nvc3RfcHJpY2U6IDAsIC8vIOKchSBOVUVWTzogVmFsb3IgYmFzZVxuICAgIHN0b2NrX3F1YW50aXR5OiAwLFxufTtcblxuLy8gLS0tIENPUlJFQ0NJw5NOIERFIEVSUk9SRVMgREUgVElQTyAtLS1cbmNvbnN0IGRlZmF1bHRJbml0aWFsRGF0YTogU2FsZXNPcmRlciA9IHtcbiAgICBpZDogMCxcbiAgICBvcmRlcl9udW1iZXI6ICcnLFxuICAgIHNlcmllczogJycsXG4gICAgc3RhdHVzOiAnMScsXG4gICAgcHVyY2hhc2Vfb3JkZXJfbnVtYmVyOiBudWxsLFxuICAgIG9yZGVyX2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLCAvLyBEZWZhdWx0IGEgaG95XG4gICAgZGVsaXZlcnlfZGF0ZTogbnVsbCxcbiAgICB0b3RhbF9hbW91bnQ6IDAsXG4gICAgbm90ZXM6IG51bGwsXG4gICAgZGVsaXZlcnlfYWRkcmVzczogbnVsbCxcbiAgICAvLyAtLS0gTU9ESUZJQ0FETzogVXNhbW9zIGRpc2NvdW50X2Ftb3VudCAtLS1cbiAgICBkaXNjb3VudF9hbW91bnQ6IDAsXG4gICAgZXhjaGFuZ2VfcmF0ZTogbnVsbCxcbiAgICBpc19leGNoYW5nZV9yYXRlX2ZpeGVkOiBmYWxzZSxcbiAgICBjbGllbnRfaWQ6IG51bGwsXG4gICAgc2FsZXNwZXJzb25faWQ6IG51bGwsXG4gICAgYnV5ZXJfaWQ6IG51bGwsXG4gICAgY3VycmVuY3lfaWQ6IG51bGwsXG4gICAgdHJhbnNwb3J0X2lkOiBudWxsLFxuXG4gICAgLy8g4pyFIE5VRVZPOiBDYW1wb3MgZGUgY8OzZGlnbyBhw7FhZGlkb3MgYWwgZXN0YWRvIGluaWNpYWxcbiAgICBjbGllbnRfY29kZTogbnVsbCxcbiAgICBzYWxlc3BlcnNvbl9jb2RlOiBudWxsLFxuICAgIGJ1eWVyX2NvZGU6IG51bGwsXG4gICAgY3VycmVuY3lfY29kZTogbnVsbCxcbiAgICB0cmFuc3BvcnRfY29kZTogbnVsbCxcblxuICAgIC8vIC0tLSBBUVXDjSBFU1TDgSBMQSBDT1JSRUNDScOTTiAtLS1cbiAgICAvLyBPYmpldG9zIHJlbGFjaW9uYWxlcyBvcGNpb25hbGVzXG4gICAgY2xpZW50OiB1bmRlZmluZWQsXG4gICAgc2FsZXNwZXJzb246IHVuZGVmaW5lZCxcbiAgICBidXllcjogdW5kZWZpbmVkLFxuICAgIGN1cnJlbmN5OiB1bmRlZmluZWQsXG4gICAgdHJhbnNwb3J0OiB1bmRlZmluZWQsXG4gICAgLy8gLS0tIEZJTiBDT1JSRUNDScOTTiAtLS1cblxuICAgIGl0ZW1zOiBbXSxcbiAgICB0YXhlczogW10sXG4gICAgYXBwbGllZFRheGVzOiBbXSxcbiAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsIC8vIERlZmF1bHRcbn07XG5cbmNvbnN0IGlzTGluZU92ZXJBdmFpbGFibGVTdG9jayA9IChpdGVtOiBTYWxlc09yZGVySXRlbSk6IGJvb2xlYW4gPT4ge1xuICAgIGlmICghaXRlbS5wcm9kdWN0X2lkKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgcSA9IE51bWJlcihpdGVtLnF1YW50aXR5KSB8fCAwO1xuICAgIGNvbnN0IHMgPSBOdW1iZXIoaXRlbS5zdG9ja19xdWFudGl0eSkgfHwgMDtcbiAgICByZXR1cm4gcSA+IHM7XG59O1xuXG5jb25zdCBzdG9ja0V4Y2Vzc01lc3NhZ2UgPSAoaXRlbTogU2FsZXNPcmRlckl0ZW0pOiBzdHJpbmcgPT4ge1xuICAgIGNvbnN0IHEgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgfHwgMDtcbiAgICBjb25zdCBzID0gTnVtYmVyKGl0ZW0uc3RvY2tfcXVhbnRpdHkpIHx8IDA7XG4gICAgY29uc3QgbmFtZSA9IGl0ZW0ucHJvZHVjdF9uYW1lIHx8ICdlbCBhcnTDrWN1bG8nO1xuICAgIGNvbnN0IGNvZGUgPSBpdGVtLnByb2R1Y3RfY29kZSA/IGAgKCR7aXRlbS5wcm9kdWN0X2NvZGV9KWAgOiAnJztcbiAgICByZXR1cm4gYEVzdMOhIHNvbGljaXRhbmRvICR7cX0gdW5pZGFkKGVzKSBkZSBcIiR7bmFtZX1cIiR7Y29kZX0gcGVybyBlbCBzdG9jayBkaXNwb25pYmxlIGVzICR7c30uYDtcbn07XG5cblxuaW50ZXJmYWNlIENvc3RIaXN0b3J5SXRlbSB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBwdXJjaGFzZV9kYXRlOiBzdHJpbmc7XG4gICAgcHJpY2VfY29zdDogbnVtYmVyO1xuICAgIGRvY3VtZW50X251bWJlcjogc3RyaW5nO1xuICAgIHZlbmRvcl9uYW1lOiBzdHJpbmc7XG4gICAgcXVhbnRpdHk6IG51bWJlcjtcblxufVxuXG4vLyBEZWZpbmljacOzbiBkZSBjb2x1bW5hcyBwYXJhIGVsIG1vZGFsXG5cbmNvbnN0IGNvc3RMaXN0Q29sdW1uczogQ29sdW1uRGVmaW5pdGlvbjxDb3N0SGlzdG9yeUl0ZW0+W10gPSBbXG4gICAgeyBoZWFkZXI6ICdGZWNoYSBDb21wcmEnLCBhY2Nlc3NvcjogJ3B1cmNoYXNlX2RhdGUnLCBmb3JtYXQ6ICdkYXRlJyB9LFxuICAgIHsgaGVhZGVyOiAnRmFjdHVyYSBDb21wcmEnLCBhY2Nlc3NvcjogJ2RvY3VtZW50X251bWJlcicgfSxcbiAgICB7IGhlYWRlcjogJ1Byb3ZlZWRvcicsIGFjY2Vzc29yOiAndmVuZG9yX25hbWUnIH0sXG4gICAgeyBoZWFkZXI6ICdDb3N0byBVbml0LicsIGFjY2Vzc29yOiAncHJpY2VfY29zdCcsIGZvcm1hdDogJ2N1cnJlbmN5JyB9LFxuICAgIHsgaGVhZGVyOiAnQ2FudGlkYWQnLCBhY2Nlc3NvcjogJ3F1YW50aXR5JyB9LFxuXTtcblxuLy8gRXN0YWRvIHBhcmEgZWwgbW9kYWwgZGUgaGlzdG9yaWFsXG5cblxuXG5leHBvcnQgY29uc3QgUGVkaWRvc1ZlbnRhRm9ybVBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCBtb2RlID0gaWQgPyAnZWRpdCcgOiAnY3JlYXRlJztcblxuICAgIGNvbnN0IHsgaXRlbTogbG9hZGVkRGF0YSwgbG9hZGluZzogbG9hZGluZ0RhdGEsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxTYWxlc09yZGVyPihzYWxlc09yZGVyc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IHsgc2F2ZUl0ZW0sIGxvYWRpbmc6IHNhdmluZyB9ID0gdXNlQ3J1ZEl0ZW08U2FsZXNPcmRlcj4oc2FsZXNPcmRlcnNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8U2FsZXNPcmRlcj4oZGVmYXVsdEluaXRpYWxEYXRhKTtcbiAgICBjb25zdCBbaXRlbXMsIHNldEl0ZW1zXSA9IHVzZVN0YXRlPFNhbGVzT3JkZXJJdGVtW10+KFtdKTtcblxuICAgIGNvbnN0IFtjbGllbnRUYXhlcywgc2V0Q2xpZW50VGF4ZXNdID0gdXNlU3RhdGU8Q2xpZW50VGF4W10+KFtdKTtcbiAgICBjb25zdCBbY2xpZW50VGF4Q29uZGl0aW9uLCBzZXRDbGllbnRUYXhDb25kaXRpb25dID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2lzQ2xpZW50VGF4RXhlbXB0LCBzZXRJc0NsaWVudFRheEV4ZW1wdF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2FwcGxpZWRUYXhlcywgc2V0QXBwbGllZFRheGVzXSA9IHVzZVN0YXRlPEFwcGxpZWRUYXhbXT4oW10pO1xuXG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21vZGFsQ29uZmlnLCBzZXRNb2RhbENvbmZpZ10gPSB1c2VTdGF0ZTxhbnk+KG51bGwpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPEVkaXRpbmdUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZWRpdGluZ0l0ZW1JbmRleCwgc2V0RWRpdGluZ0l0ZW1JbmRleF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcblxuICAgIGNvbnN0IFtpc0l0ZW1UYXhNb2RhbE9wZW4sIHNldElzSXRlbVRheE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2N1cnJlbnRJdGVtSW5kZXhGb3JUYXgsIHNldEN1cnJlbnRJdGVtSW5kZXhGb3JUYXhdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBbaGlzdG9yeU1vZGFsU3RhdGUsIHNldEhpc3RvcnlNb2RhbFN0YXRlXSA9IHVzZVN0YXRlPEhpc3RvcnlNb2RhbFN0YXRlPihpbml0aWFsSGlzdG9yeU1vZGFsU3RhdGUpO1xuXG4gICAgY29uc3QgW3N0b2NrQWxlcnQsIHNldFN0b2NrQWxlcnRdID0gdXNlU3RhdGU8eyBvcGVuOiBib29sZWFuOyB0aXRsZTogc3RyaW5nOyBtZXNzYWdlOiBzdHJpbmcgfT4oe1xuICAgICAgICBvcGVuOiBmYWxzZSxcbiAgICAgICAgdGl0bGU6ICcnLFxuICAgICAgICBtZXNzYWdlOiAnJyxcbiAgICB9KTtcbiAgICBjb25zdCBwZW5kaW5nQWZ0ZXJTdG9ja0Fja1JlZiA9IHVzZVJlZjwoKCkgPT4gdm9pZCkgfCBudWxsPihudWxsKTtcblxuICAgIGNvbnN0IHsgZ2F0ZVNhdmUsIGF1dGhNb2RhbCB9ID0gdXNlU3VwZXJ2aXNvckxvd1Byb2ZpdEF1dGgoKTtcblxuICAgIGNvbnN0IFtjbGllbnRBZGRyZXNzZXMsIHNldENsaWVudEFkZHJlc3Nlc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xuICAgIGNvbnN0IFtpc0N1c3RvbUFkZHJlc3MsIHNldElzQ3VzdG9tQWRkcmVzc10gPSB1c2VTdGF0ZShmYWxzZSk7IC8vIEJhbmRlcmEgcGFyYSBpbnB1dCBtYW51YWxcbiAgICBjb25zdCBbdGVtcERlbGl2ZXJ5QWRkcmVzcywgc2V0VGVtcERlbGl2ZXJ5QWRkcmVzc10gPSB1c2VTdGF0ZSgnJyk7IC8vIFZhbG9yIHNlbGVjY2lvbmFkby9pbmdyZXNhZG9cbiAgICBjb25zdCBbc2ltYm9sb01vbmVkYSwgc2V0U2ltYm9sb01vbmVkYV0gPSB1c2VTdGF0ZSgnJCcpO1xuXG4gICAgY29uc3QgZWZmZWN0aXZlRXhjaGFuZ2VSYXRlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJhdGUgPSBOdW1iZXIoZm9ybURhdGEuZXhjaGFuZ2VfcmF0ZSkgfHwgMTtcbiAgICAgICAgLy8gU2kgZWwgY8OzZGlnbyBkZSBtb25lZGEgZXMgJzAxJyAoTW9uZWRhIExvY2FsL0Jhc2UpLCBsYSB0YXNhIGVmZWN0aXZhIGVzIDEuXG4gICAgICAgIC8vIFNpIG5vLCB1c2Ftb3MgbGEgdGFzYSBpbmdyZXNhZGEuXG4gICAgICAgIHJldHVybiBmb3JtRGF0YS5jdXJyZW5jeV9jb2RlID09PSAnMDEnID8gMSA6IHJhdGU7XG4gICAgfSwgW2Zvcm1EYXRhLmV4Y2hhbmdlX3JhdGUsIGZvcm1EYXRhLmN1cnJlbmN5X2NvZGVdKTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZUl0ZW1UYXhlcyA9IChpdGVtOiBTYWxlc09yZGVySXRlbSwgdGF4ZXM6IENsaWVudFRheFtdID0gY2xpZW50VGF4ZXMpOiBBcHBsaWVkVGF4W10gPT4ge1xuICAgICAgICBpZiAoIXRheGVzIHx8IHRheGVzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCB0YXhCYXNlID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKSAtIChOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDApO1xuICAgICAgICByZXR1cm4gY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgICAgIG5ldEJhc2U6IHRheEJhc2UsXG4gICAgICAgICAgICBjbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICB0YXhlcyxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIEVmZWN0byBwYXJhIGNhcmdhciBkYXRvcyAoZW4gbW9kbyAnZWRpdCcpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKG1vZGUgPT09ICdlZGl0JyAmJiBsb2FkZWREYXRhKSB7XG4gICAgICAgICAgICAvLyDinIUgMS4gTk8gU0VURUFNT1MgRElSRUNUQU1FTlRFLiBQUkVQQVJBTU9TIExPUyBEQVRPUy5cbiAgICAgICAgICAgIGNvbnN0IGh5ZHJhdGVkRGF0YSA9IHsgLi4ubG9hZGVkRGF0YSB9O1xuXG4gICAgICAgICAgICAvLyBDbGllbnRlXG4gICAgICAgICAgICBpZiAoaHlkcmF0ZWREYXRhLmNsaWVudCAmJiBjbGllbnRlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBjb2RlRmllbGQsIG5hbWVGaWVsZCB9ID0gY2xpZW50ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcztcbiAgICAgICAgICAgICAgICBoeWRyYXRlZERhdGEuY2xpZW50X2NvZGUgPSBoeWRyYXRlZERhdGEuY2xpZW50W2NvZGVGaWVsZCBhcyBrZXlvZiBDbGllbnRlXSBhcyBzdHJpbmc7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWREYXRhLmNsaWVudF9uYW1lID0gaHlkcmF0ZWREYXRhLmNsaWVudFtuYW1lRmllbGQgYXMga2V5b2YgQ2xpZW50ZV0gYXMgc3RyaW5nO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoaHlkcmF0ZWREYXRhLnNhbGVzcGVyc29uICYmIHZlbmRlZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IHZlbmRlZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcztcbiAgICAgICAgICAgICAgICBjb25zdCByZWwgPSBoeWRyYXRlZERhdGEuc2FsZXNwZXJzb247XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWREYXRhLnNhbGVzcGVyc29uX2NvZGUgPSAoaHlkcmF0ZWREYXRhLnNhbGVzcGVyc29uX2NvZGUgPz8gcmVsW2NvZGVGaWVsZCBhcyBrZXlvZiB0eXBlb2YgcmVsXSkgYXMgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZERhdGEuc2FsZXNwZXJzb25fbmFtZSA9IChoeWRyYXRlZERhdGEuc2FsZXNwZXJzb25fbmFtZSA/PyByZWxbbmFtZUZpZWxkIGFzIGtleW9mIHR5cGVvZiByZWxdKSBhcyBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaHlkcmF0ZWREYXRhLmJ1eWVyICYmIGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlbCA9IGh5ZHJhdGVkRGF0YS5idXllcjtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZERhdGEuYnV5ZXJfY29kZSA9IChoeWRyYXRlZERhdGEuYnV5ZXJfY29kZSA/PyByZWxbY29kZUZpZWxkIGFzIGtleW9mIHR5cGVvZiByZWxdKSBhcyBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGh5ZHJhdGVkRGF0YS5idXllcl9uYW1lID0gKGh5ZHJhdGVkRGF0YS5idXllcl9uYW1lID8/IHJlbFtuYW1lRmllbGQgYXMga2V5b2YgdHlwZW9mIHJlbF0pIGFzIHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChoeWRyYXRlZERhdGEuY3VycmVuY3kgJiYgbW9uZWRhc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBjb2RlRmllbGQsIG5hbWVGaWVsZCB9ID0gbW9uZWRhc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlbCA9IGh5ZHJhdGVkRGF0YS5jdXJyZW5jeTtcbiAgICAgICAgICAgICAgICBoeWRyYXRlZERhdGEuY3VycmVuY3lfY29kZSA9IChoeWRyYXRlZERhdGEuY3VycmVuY3lfY29kZSA/PyByZWxbY29kZUZpZWxkIGFzIGtleW9mIHR5cGVvZiByZWxdKSBhcyBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGh5ZHJhdGVkRGF0YS5jdXJyZW5jeV9uYW1lID0gKGh5ZHJhdGVkRGF0YS5jdXJyZW5jeV9uYW1lID8/IHJlbFtuYW1lRmllbGQgYXMga2V5b2YgdHlwZW9mIHJlbF0pIGFzIHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChoeWRyYXRlZERhdGEudHJhbnNwb3J0ICYmIHRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlbCA9IGh5ZHJhdGVkRGF0YS50cmFuc3BvcnQ7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWREYXRhLnRyYW5zcG9ydF9jb2RlID0gKGh5ZHJhdGVkRGF0YS50cmFuc3BvcnRfY29kZSA/PyByZWxbY29kZUZpZWxkIGFzIGtleW9mIHR5cGVvZiByZWxdKSBhcyBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGh5ZHJhdGVkRGF0YS50cmFuc3BvcnRfbmFtZSA9IChoeWRyYXRlZERhdGEudHJhbnNwb3J0X25hbWUgPz8gcmVsW25hbWVGaWVsZCBhcyBrZXlvZiB0eXBlb2YgcmVsXSkgYXMgc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAobG9hZGVkRGF0YS5jbGllbnQ/LnNoaXBhZGRyZXNzKSB7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50QWRkcmVzc2VzKGxvYWRlZERhdGEuY2xpZW50LnNoaXBhZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgIC8vIERldGVybWluYW1vcyBzaSBsYSBkaXJlY2Npw7NuIGd1YXJkYWRhIGVzIHVuYSBkaXJlY2Npw7NuIG51ZXZhXG4gICAgICAgICAgICAgICAgY29uc3QgaXNDdXN0b20gPSBsb2FkZWREYXRhLmRlbGl2ZXJ5X2FkZHJlc3NcbiAgICAgICAgICAgICAgICAgICAgJiYgIWxvYWRlZERhdGEuY2xpZW50LnNoaXBhZGRyZXNzLmluY2x1ZGVzKGxvYWRlZERhdGEuZGVsaXZlcnlfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3MoISFpc0N1c3RvbSk7IC8vIEZvcnphciBib29sZWFub1xuXG4gICAgICAgICAgICAgICAgLy8gU2V0ZWFtb3MgZWwgdmFsb3IgdGVtcG9yYWwgY29uIGVsIGd1YXJkYWRvXG4gICAgICAgICAgICAgICAgc2V0VGVtcERlbGl2ZXJ5QWRkcmVzcyhsb2FkZWREYXRhLmRlbGl2ZXJ5X2FkZHJlc3MgfHwgJycpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGxvYWRlZERhdGEuZGVsaXZlcnlfYWRkcmVzcyB8fCAnJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBpc0V4ZW1wdE9uTG9hZCA9IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQobG9hZGVkRGF0YS5jbGllbnQpO1xuICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoaXNFeGVtcHRPbkxvYWQpO1xuICAgICAgICAgICAgaWYgKGxvYWRlZERhdGEuY2xpZW50KSB7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGxvYWRlZERhdGEuY2xpZW50LnRheCA/PyBudWxsKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2V0Rm9ybURhdGEoaXNFeGVtcHRPbkxvYWRcbiAgICAgICAgICAgICAgICA/IHsgLi4uaHlkcmF0ZWREYXRhLCBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UgfVxuICAgICAgICAgICAgICAgIDogaHlkcmF0ZWREYXRhKTtcbiAgICAgICAgICAgIHNldEl0ZW1zKGlzRXhlbXB0T25Mb2FkXG4gICAgICAgICAgICAgICAgPyAobG9hZGVkRGF0YS5pdGVtcyB8fCBbXSkubWFwKGl0ZW0gPT4gKHsgLi4uaXRlbSwgdGF4ZXM6IFtdIH0pKVxuICAgICAgICAgICAgICAgIDogKGxvYWRlZERhdGEuaXRlbXMgfHwgW10pKTtcbiAgICAgICAgICAgIGlmIChpc0V4ZW1wdE9uTG9hZCkge1xuICAgICAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCFsb2FkZWREYXRhLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKGxvYWRlZERhdGEuYXBwbGllZFRheGVzIHx8IGxvYWRlZERhdGEudGF4ZXMgfHwgW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKG1vZGUgPT09ICdjcmVhdGUnKSB7XG4gICAgICAgICAgICAvLyDinIUgRklYOiBBbCBjcmVhciwgc2V0ZWFyIGVsIHZhbG9yIHRlbXBvcmFsIGRlbCBmb3JtRGF0YSAocXVlIGVzIG51bGwpXG4gICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGRlZmF1bHRJbml0aWFsRGF0YS5kZWxpdmVyeV9hZGRyZXNzIHx8ICcnKTtcbiAgICAgICAgfVxuICAgIH0sIFttb2RlLCBsb2FkZWREYXRhXSk7XG5cbiAgICAvLyBFZmVjdG8gcGFyYSBjYXJnYXIgaW1wdWVzdG9zIGRlbCBjbGllbnRlXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGZvcm1EYXRhLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgZ2V0QnlJZDxDbGllbnRlPihjbGllbnRlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgZm9ybURhdGEuY2xpZW50X2lkKVxuICAgICAgICAgICAgICAgIC50aGVuKGNsaWVudERhdGEgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGVtcHQgPSBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0KGNsaWVudERhdGEpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdDbGllbnRUYXhlcyA9IGdldEVmZmVjdGl2ZUNsaWVudFRheGVzKGNsaWVudERhdGEsIGNsaWVudERhdGEucmVsYXRlZFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoZXhlbXB0KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGNsaWVudERhdGEudGF4ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhuZXdDbGllbnRUYXhlcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiAoeyAuLi5pdGVtLCB0YXhlczogW10gfSkpKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2Lm1hcChpdGVtID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXhlczogY2FsY3VsYXRlSXRlbVRheGVzKGl0ZW0sIG5ld0NsaWVudFRheGVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZGllcm9uIGNhcmdhciBsb3MgaW1wdWVzdG9zIGRlbCBjbGllbnRlLicpO1xuICAgICAgICAgICAgICAgICAgICBzZXRJc0NsaWVudFRheEV4ZW1wdChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoZmFsc2UpO1xuICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKG51bGwpO1xuICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMoW10pO1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiAoeyAuLi5pdGVtLCB0YXhlczogW10gfSkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgfSwgW2Zvcm1EYXRhLmNsaWVudF9pZCwgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXNdKTsgLy8gRGVwZW5kZW1vcyBkZSBoYXNfaXRlbV9sZXZlbF90YXhlc1xuXG5cbiAgICAvLyAtLS0gTMOTR0lDQSBERSBDw4FMQ1VMTyAoVVNFIE1FTU8pIC0tLVxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgLy8gMS4gU3VidG90YWwgZGUgw610ZW1zIChhbnRlcyBkZSBkZXNjdWVudG9zKVxuICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gc3VtICsgKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKTtcbiAgICAgICAgfSwgMCk7XG5cbiAgICAgICAgLy8gMi4gVG90YWwgZGUgZGVzY3VlbnRvcyBkZSDDrXRlbXNcbiAgICAgICAgY29uc3QgdG90YWxJdGVtRGlzY291bnRzID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHtcbiAgICAgICAgICAgIHJldHVybiBzdW0gKyAoTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwKTtcbiAgICAgICAgfSwgMCk7XG5cbiAgICAgICAgLy8gMy4gRGVzY3VlbnRvIGdsb2JhbCAobm9taW5hbClcbiAgICAgICAgY29uc3QgZ2xvYmFsRGlzY291bnRBbW91bnQgPSBOdW1iZXIoZm9ybURhdGEuZGlzY291bnRfYW1vdW50KSB8fCAwO1xuXG4gICAgICAgIC8vIDQuIEJhc2UgSW1wb25pYmxlOiBTdWJ0b3RhbCAtIChzdW1hIGRlIGRlc2N1ZW50b3MgZGUgaXRlbSkgLSAoZGVzY3VlbnRvIGdsb2JhbClcbiAgICAgICAgY29uc3QgdGF4QmFzZSA9IHN1YnRvdGFsIC0gdG90YWxJdGVtRGlzY291bnRzIC0gZ2xvYmFsRGlzY291bnRBbW91bnQ7XG5cbiAgICAgICAgLy8gNS4gQ8OhbGN1bG8gZGUgJ3RvdGFsVGF4ZXMnIGRlcGVuZGUgZGVsIG1vZG9cbiAgICAgICAgbGV0IHRvdGFsVGF4ZXMgPSAwO1xuXG4gICAgICAgIGlmICghaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtVGF4ZXMgPSBpdGVtLnRheGVzIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtVGF4QW1vdW50ID0gaXRlbVRheGVzLnJlZHVjZSgoaXRlbVN1bSwgdGF4KSA9PiBpdGVtU3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN1bSArIGl0ZW1UYXhBbW91bnQ7XG4gICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBhcHBsaWVkVGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHRvdGFsID0gaXNDbGllbnRUYXhFeGVtcHRcbiAgICAgICAgICAgID8gY29tcHV0ZUV4ZW1wdERvY3VtZW50VG90YWwoc3VidG90YWwsIHRvdGFsSXRlbURpc2NvdW50cywgZ2xvYmFsRGlzY291bnRBbW91bnQpXG4gICAgICAgICAgICA6IHRheEJhc2UgKyB0b3RhbFRheGVzO1xuXG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbEl0ZW1EaXNjb3VudHMsIGdsb2JhbERpc2NvdW50QW1vdW50LCB0YXhCYXNlLCB0b3RhbFRheGVzLCB0b3RhbCB9O1xuICAgIH0sIFtpdGVtcywgZm9ybURhdGEuZGlzY291bnRfYW1vdW50LCBhcHBsaWVkVGF4ZXMsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG5cbiAgICAvLyDinIUgTlVFVk8gRUZFQ1RPOiBDT05WRVJTScOTTiBERSBNT05FREFcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBleGNoYW5nZVJhdGUgPSBlZmZlY3RpdmVFeGNoYW5nZVJhdGU7XG5cbiAgICAgICAgLy8gTm8gaGFjZW1vcyBuYWRhIHNpIGxhIHRhc2EgZXMgMSwgbyBzaSBlcyBsYSBwcmltZXJhIGNhcmdhIHkgbm8gaGF5IHRhc2FcbiAgICAgICAgaWYgKGlzTmFOKGV4Y2hhbmdlUmF0ZSkpIHJldHVybjtcblxuICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT4gcHJldkl0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJhc2VQcmljZSA9IE51bWJlcihpdGVtLmJhc2Vfc2FsZXNfcHJpY2UpO1xuICAgICAgICAgICAgY29uc3QgYmFzZUNvc3QgPSBOdW1iZXIoaXRlbS5iYXNlX2Nvc3RfcHJpY2UpO1xuXG4gICAgICAgICAgICAvLyBTaSBsb3MgdmFsb3JlcyBiYXNlIGVzdMOhbiB2YWPDrW9zIG8gc29uIDAsIG5vIGhheSBuYWRhIHF1ZSBjb252ZXJ0aXJcbiAgICAgICAgICAgIGlmIChiYXNlUHJpY2UgPT09IDAgJiYgYmFzZUNvc3QgPT09IDApIHJldHVybiBpdGVtO1xuXG4gICAgICAgICAgICBjb25zdCBuZXdJdGVtID0ge1xuICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgLy8gQ29udmVydGltb3M6IFByZWNpbyBCYXNlIC8gVGFzYSBkZSBDYW1iaW9cbiAgICAgICAgICAgICAgICB1bml0X3ByaWNlOiByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZVByaWNlIC8gZXhjaGFuZ2VSYXRlKSxcbiAgICAgICAgICAgICAgICBjb3N0X3ByaWNlOiByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpLFxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgICAgIG5ld0l0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXMobmV3SXRlbSwgY2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gbmV3SXRlbTtcbiAgICAgICAgfSkpO1xuICAgICAgICAvLyBEZXBlbmRlIGRlIGxhIHRhc2EgZGUgY2FtYmlvIHkgZGUgbG9zIGltcHVlc3RvcyBkZSBjbGllbnRlIHBhcmEgcmVjYWxjdWxhciBsYSB1dGlsaWRhZC9pbXB1ZXN0b3NcbiAgICB9LCBbZWZmZWN0aXZlRXhjaGFuZ2VSYXRlLCBjbGllbnRUYXhlcywgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMsIGNsaWVudFRheENvbmRpdGlvbiwgaXNDbGllbnRUYXhFeGVtcHRdKTtcblxuICAgIC8vIEVmZWN0byBwYXJhIGNhbGN1bGFyIElNUFVFU1RPUyBHTE9CQUxFU1xuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjbGllbnRUYXhlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAvLyBVc2Ftb3MgbGEgJ3RheEJhc2UnIGRlIG51ZXN0cm9zIGPDoWxjdWxvc1xuICAgICAgICAgICAgY29uc3QgeyB0YXhCYXNlIH0gPSBjYWxjdWxhdGVkVG90YWxzO1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKGNvbXB1dGVTYWxlc0FwcGxpZWRUYXhlcyh7XG4gICAgICAgICAgICAgICAgbmV0QmFzZTogdGF4QmFzZSxcbiAgICAgICAgICAgICAgICBjbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICAgICAgdGF4ZXM6IGNsaWVudFRheGVzLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW2NhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgY2xpZW50VGF4ZXMsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBjbGllbnRUYXhDb25kaXRpb24sIGlzQ2xpZW50VGF4RXhlbXB0XSk7XG5cblxuICAgIC8vIC0tLSBIQU5ETEVSUyAoTW9kYWwgUmVsYWNpb25hbCwgSXRlbXMsIEd1YXJkYWRvKSAtLS1cblxuICAgIC8vIOKchSAxLiBOVUVWTyBIQU5ETEVSIENFTlRSQUxJWkFET1xuICAgIC8vIEVzdGEgZnVuY2nDs24gY29udGllbmUgVE9EQSBsYSBsw7NnaWNhIGRlIHNldGVvIHkgYXV0by1yZWxsZW5hZG9cbiAgICBjb25zdCBhcHBseUhlYWRlclNlbGVjdGlvbiA9IChmaWVsZDogSGVhZGVyRmllbGQsIHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG5cbiAgICAgICAgLy8gT2J0ZW5lbW9zIGxhIGNvbmZpZyBkZWwgbcOzZHVsbyBjb3JyZXNwb25kaWVudGVcbiAgICAgICAgY29uc3QgbW9kdWxlQ29uZmlnID0ge1xuICAgICAgICAgICAgJ2NsaWVudCc6IGNsaWVudGVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ3NhbGVzcGVyc29uJzogdmVuZGVkb3Jlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICdidXllcic6IGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ2N1cnJlbmN5JzogbW9uZWRhc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICd0cmFuc3BvcnQnOiB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgfVtmaWVsZF07XG5cbiAgICAgICAgaWYgKCFtb2R1bGVDb25maWcgfHwgIW1vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihgRXJyb3I6IEZhbHRhICdyZWxhdGlvbmFsRmllbGRzJyBlbiBsYSBjb25maWcgZGUgJHtmaWVsZH1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBtb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcztcblxuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWREYXRhID0geyAuLi5wcmV2IH07XG5cbiAgICAgICAgICAgIC8vIEEuIFNldGVhbW9zIGVsIGNhbXBvIHByaW5jaXBhbCAoZWouIENsaWVudGUpXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRJdGVtKSB7XG5cbiAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YVtgJHtmaWVsZH1faWRgXSA9IHNlbGVjdGVkSXRlbS5pZDtcbiAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YVtgJHtmaWVsZH1fY29kZWBdID0gc2VsZWN0ZWRJdGVtW2NvZGVGaWVsZCBhcyBzdHJpbmddO1xuICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW2Ake2ZpZWxkfV9uYW1lYF0gPSBzZWxlY3RlZEl0ZW1bbmFtZUZpZWxkIGFzIHN0cmluZ107XG5cbiAgICAgICAgICAgICAgICAvLyBCLiDinKggTMOTR0lDQSBERSBBVVRPLVJFTExFTk86IFNpIGZ1ZSBlbCBDTElFTlRFXG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSAnY2xpZW50Jykge1xuXG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihzZWxlY3RlZEl0ZW0udGF4ID8/IG51bGwpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIC0tLSBOVUVWTzogTMOzZ2ljYSBwYXJhIGVsIHNlbGVjdG9yIGRlIGRpcmVjY2nDs24gLS0tXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFkZHJlc3NlcyA9IHNlbGVjdGVkSXRlbS5zaGlwYWRkcmVzcyB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWRkcmVzc2VzKGFkZHJlc3Nlcyk7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ3VzdG9tQWRkcmVzcyhmYWxzZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gU2VsZWNjaW9uYW1vcyBsYSBwcmltZXJhIGRpcmVjY2nDs24gY29tbyB2YWxvciBwb3IgZGVmZWN0byBzaSBleGlzdGVcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFkZHJlc3Nlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGFkZHJlc3Nlc1swXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5kZWxpdmVyeV9hZGRyZXNzID0gYWRkcmVzc2VzWzBdOyAvLyBTZXRlYXIgZW4gZm9ybURhdGEgcGFyYSB2YWxpZGFjacOzblxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGVtcERlbGl2ZXJ5QWRkcmVzcygnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5kZWxpdmVyeV9hZGRyZXNzID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8vIEF1dG8tcmVsbGVuYXIgVmVuZGVkb3JcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkSXRlbS5zYWxlc3JlcCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuc2FsZXNwZXJzb25faWQgPSBzZWxlY3RlZEl0ZW0uc2FsZXNyZXA7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5zYWxlc3BlcnNvbl9jb2RlID0gc2VsZWN0ZWRJdGVtLnNhbGVzUmVwUmVsYXRpb24uY29kZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuc2FsZXNwZXJzb25fbmFtZSA9IHNlbGVjdGVkSXRlbS5zYWxlc1JlcFJlbGF0aW9uLm5hbWUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8vIEF1dG8tcmVsbGVuYXIgVHJhbnNwb3J0ZVxuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRJdGVtLnRyYW5zcG9ydF9pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEudHJhbnNwb3J0X2lkID0gc2VsZWN0ZWRJdGVtLnRyYW5zcG9ydF9pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLnRyYW5zcG9ydF9jb2RlID0gc2VsZWN0ZWRJdGVtLnRyYW5zcG9ydF9jb2RlIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS50cmFuc3BvcnRfbmFtZSA9IHNlbGVjdGVkSXRlbS50cmFuc3BvcnRfbmFtZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gQXV0by1yZWxsZW5hciBNb25lZGFcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkSXRlbS5jdXJyZW5jeV9pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuY3VycmVuY3lfaWQgPSBzZWxlY3RlZEl0ZW0uY3VycmVuY3lfaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5jdXJyZW5jeV9jb2RlID0gc2VsZWN0ZWRJdGVtLmN1cnJlbmN5X2NvZGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmN1cnJlbmN5X25hbWUgPSBzZWxlY3RlZEl0ZW0uY3VycmVuY3lfbmFtZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuZXhjaGFuZ2VfcmF0ZSA9IHNlbGVjdGVkSXRlbS5jdXJyZW5jeT8uZXhjaGFuZ2VfcmF0ZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVwZGF0ZWREYXRhLmN1cnJlbmN5X2NvZGUgIT09ICcwMScpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltYm9sb01vbmVkYSgnVVNEJylcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaW1ib2xvTW9uZWRhKCckJylcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEl0ZW0uYnV5ZXJfaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmJ1eWVyX2lkID0gc2VsZWN0ZWRJdGVtLmJ1eWVyX2lkO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuYnV5ZXJfY29kZSA9IHNlbGVjdGVkSXRlbS5idXllcl9jb2RlIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5idXllcl9uYW1lID0gc2VsZWN0ZWRJdGVtLmJ1eWVyX25hbWUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZmllbGQgPT09ICdjdXJyZW5jeScpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuZXhjaGFuZ2VfcmF0ZSA9IHNlbGVjdGVkSXRlbS5leGNoYW5nZV9yYXRlIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIGlmICh1cGRhdGVkRGF0YS5jdXJyZW5jeV9jb2RlICE9PSAnMDEnKVxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltYm9sb01vbmVkYSgnVVNEJylcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltYm9sb01vbmVkYSgnJCcpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIEMuIEVmZWN0b3Mgc2VjdW5kYXJpb3MgKGZ1ZXJhIGRlbCAnc2V0Rm9ybURhdGEnKVxuICAgICAgICBpZiAoZmllbGQgPT09ICdjbGllbnQnKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pOyAvLyBSZXNldGVhciBpbXB1ZXN0b3NcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVEZWxpdmVyeUFkZHJlc3NDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTFNlbGVjdEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICBpZiAodmFsdWUgPT09ICdDVVNUT01fTkVXX0FERFJFU1MnKSB7XG4gICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3ModHJ1ZSk7XG4gICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKCcnKTsgLy8gTGltcGlhbW9zIGVsIHZhbG9yIHBhcmEgcXVlIGVsIHVzdWFyaW8gaW5ncmVzZVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0SXNDdXN0b21BZGRyZXNzKGZhbHNlKTtcbiAgICAgICAgICAgIHNldFRlbXBEZWxpdmVyeUFkZHJlc3ModmFsdWUpOyAvLyBTZXRlYW1vcyBlbCB2YWxvciBzZWxlY2Npb25hZG9cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAodGFyZ2V0OiBFZGl0aW5nVGFyZ2V0LCBjb25maWc6IGFueSwgaXRlbUluZGV4OiBudW1iZXIgfCBudWxsID0gbnVsbCkgPT4ge1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KHRhcmdldCk7XG4gICAgICAgIHNldE1vZGFsQ29uZmlnKHRhcmdldCA9PT0gJ2l0ZW0nXG4gICAgICAgICAgICA/IHsgLi4uY29uZmlnLCBpbml0aWFsRmlsdGVyczogYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMgfVxuICAgICAgICAgICAgOiBjb25maWdcbiAgICAgICAgKTtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgIGlmICh0YXJnZXQgPT09ICdpdGVtJykge1xuICAgICAgICAgICAgc2V0RWRpdGluZ0l0ZW1JbmRleChpdGVtSW5kZXgpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdE1vZGFsID0gYXN5bmMgKHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG4gICAgICAgIGlmICghZWRpdGluZ1RhcmdldCkgcmV0dXJuO1xuXG4gICAgICAgIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAnaXRlbScgJiYgZWRpdGluZ0l0ZW1JbmRleCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgLy8g4pyFIEJ1c2NhciBjb24gZWwgZm9ybWF0byBkZSBtw6FzY2FyYSAoaW5jbHV5ZSBwdW50b3MpXG4gICAgICAgICAgICBjb25zdCBza3VWYWx1ZSA9IHNlbGVjdGVkSXRlbS5za3UgPyBTdHJpbmcoc2VsZWN0ZWRJdGVtLnNrdSkgOiAnJztcbiAgICAgICAgICAgIGNvbnN0IHByb2R1Y3QgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oJ3Byb2R1Y3RzL2ZpbmQtYnktc2t1JyxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6ICdza3UnIGFzIHN0cmluZywgdmFsdWU6IHNrdVZhbHVlIH0sXG4gICAgICAgICAgICAgICAgeyBmaWVsZE5hbWU6ICdjbGllbnRfaWQnLCB2YWx1ZTogZm9ybURhdGEuY2xpZW50X2lkPy50b1N0cmluZygpID8/ICcnIH1cbiAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdJdGVtcyA9IFsuLi5wcmV2SXRlbXNdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBuZXdJdGVtc1tlZGl0aW5nSXRlbUluZGV4XTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IGFydGljdWxvc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzITtcbiAgICAgICAgICAgICAgICBjb25zdCBleGNoYW5nZVJhdGUgPSBlZmZlY3RpdmVFeGNoYW5nZVJhdGU7XG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZVByaWNlID0gcHJvZHVjdC5zdWdnZXN0ZWRfcHJpY2UgfHwgc2VsZWN0ZWRJdGVtLnNhbGVfcHJpY2UgfHwgMDtcbiAgICAgICAgICAgICAgICBjb25zdCBiYXNlQ29zdCA9IHByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlKFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0LmNvc3RfcHJpY2UgPz8gc2VsZWN0ZWRJdGVtLmNvc3RfcHJpY2UgPz8gMCxcbiAgICAgICAgICAgICAgICAgICAgcHJvZHVjdC5jb3N0X2N1cnJlbmN5LFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5leGNoYW5nZV9yYXRlXG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9pZCA9IHNlbGVjdGVkSXRlbS5pZDtcbiAgICAgICAgICAgICAgICBpdGVtLnByb2R1Y3RfY29kZSA9IHNlbGVjdGVkSXRlbVtjb2RlRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICBpdGVtLnByb2R1Y3RfbmFtZSA9IHNlbGVjdGVkSXRlbVtuYW1lRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICBpdGVtLnN0b2NrX3F1YW50aXR5ID0gcHJvZHVjdC5zdG9ja19xdWFudGl0eSA/PyAwO1xuICAgICAgICAgICAgICAgIGl0ZW0udW5pdF9wcmljZSA9IGJhc2VQcmljZSB8fCAwO1xuICAgICAgICAgICAgICAgIGl0ZW0uY29zdF9wcmljZSA9IGJhc2VDb3N0IHx8IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5iYXNlX3NhbGVzX3ByaWNlID0gYmFzZVByaWNlO1xuICAgICAgICAgICAgICAgIGl0ZW0uYmFzZV9jb3N0X3ByaWNlID0gYmFzZUNvc3Q7XG5cbiAgICAgICAgICAgICAgICBpdGVtLnVuaXRfcHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZVByaWNlIC8gZXhjaGFuZ2VSYXRlKTtcbiAgICAgICAgICAgICAgICBpdGVtLmNvc3RfcHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpO1xuXG4gICAgICAgICAgICAgICAgLy8gLS0tIE1PRElGSUNBRE86IEPDoWxjdWxvIGF1dG9tw6F0aWNvIGRlIGltcHVlc3RvcyAtLS1cbiAgICAgICAgICAgICAgICBpZiAoZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXMoaXRlbSwgY2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udGF4ZXMgPSBbXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBuZXdJdGVtc1tlZGl0aW5nSXRlbUluZGV4XSA9IGl0ZW07XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ld0l0ZW1zO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRFZGl0aW5nSXRlbUluZGV4KG51bGwpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGVkaXRpbmdUYXJnZXQgIT09ICdpdGVtJykge1xuICAgICAgICAgICAgLy8g4pyFIDIuIFNJTVBMSUZJQ0FETzogTGxhbWFtb3MgYSBsYSBudWV2YSBmdW5jacOzblxuICAgICAgICAgICAgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZWRpdGluZ1RhcmdldCwgc2VsZWN0ZWRJdGVtKTtcbiAgICAgICAgfVxuICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50IHwgSFRNTFNlbGVjdEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUsIHR5cGUgfSA9IGUudGFyZ2V0O1xuICAgICAgICBsZXQgZmluYWxWYWx1ZTogYW55ID0gdmFsdWU7XG5cbiAgICAgICAgLy8g4pyFIE1PRElGSUNBQ0nDk046IE1hbmVqYXIgZWwgdGlwbyBjaGVja2JveFxuICAgICAgICBpZiAodHlwZSA9PT0gJ2NoZWNrYm94Jykge1xuICAgICAgICAgICAgZmluYWxWYWx1ZSA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IGZpbmFsVmFsdWUgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVJdGVtQ2hhbmdlID0gKGluZGV4OiBudW1iZXIsIGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xuICAgICAgICBjb25zdCBleGNoYW5nZVJhdGUgPSBlZmZlY3RpdmVFeGNoYW5nZVJhdGU7XG4gICAgICAgIGNvbnN0IG51bUZpZWxkcyA9IFsncXVhbnRpdHknLCAndW5pdF9wcmljZScsICdkaXNjb3VudF9hbW91bnQnXTtcbiAgICAgICAgY29uc3Qgc3RvcmVkVmFsdWUgPSBudW1GaWVsZHMuaW5jbHVkZXMobmFtZSkgPyAodmFsdWUgPT09ICcnID8gMCA6IE51bWJlcih2YWx1ZSkgfHwgMCkgOiB2YWx1ZTtcblxuICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBbLi4ucHJldkl0ZW1zXTtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSB7IC4uLm5ld0l0ZW1zW2luZGV4XSwgW25hbWVdOiBzdG9yZWRWYWx1ZSB9O1xuXG4gICAgICAgICAgICBpZiAobmFtZSA9PT0gJ3VuaXRfcHJpY2UnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBOdW1iZXIoc3RvcmVkVmFsdWUpIHx8IDA7XG4gICAgICAgICAgICAgICAgLy8gRWwgbnVldm8gcHJlY2lvIGJhc2UgZXMgZWwgcHJlY2lvIGRlIHBhbnRhbGxhICogdGFzYSBkZSBjYW1iaW9cbiAgICAgICAgICAgICAgICBpdGVtLmJhc2Vfc2FsZXNfcHJpY2UgPSBuZXdWYWx1ZSAqIGV4Y2hhbmdlUmF0ZTtcblxuICAgICAgICAgICAgICAgIC8vIE1hbnRlbmVtb3MgZWwgY29zdF9wcmljZSBzaW5jcm9uaXphZG8gY29uIGxhIHRhc2EgYWN0dWFsICh5YSBxdWUgbm8gZXMgZWRpdGFibGUpXG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZUNvc3QgPSBOdW1iZXIoaXRlbS5iYXNlX2Nvc3RfcHJpY2UpIHx8IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5jb3N0X3ByaWNlID0gcm91bmRUb1R3b0RlY2ltYWxzKGJhc2VDb3N0IC8gZXhjaGFuZ2VSYXRlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gLS0tIE1PRElGSUNBRE86IFJlY2FsY3VsbyBhdXRvbcOhdGljbyBhbCBjYW1iaWFyIC0tLVxuICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCAmJiAobmFtZSA9PT0gJ3F1YW50aXR5JyB8fCBuYW1lID09PSAndW5pdF9wcmljZScgfHwgbmFtZSA9PT0gJ2Rpc2NvdW50X2Ftb3VudCcpKSB7XG4gICAgICAgICAgICAgICAgaXRlbS50YXhlcyA9IGNhbGN1bGF0ZUl0ZW1UYXhlcyhpdGVtLCBjbGllbnRUYXhlcyk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdxdWFudGl0eScgfHwgbmFtZSA9PT0gJ3VuaXRfcHJpY2UnIHx8IG5hbWUgPT09ICdkaXNjb3VudF9hbW91bnQnKSB7XG4gICAgICAgICAgICAgICAgaXRlbS50YXhlcyA9IFtdOyAvLyBMaW1waWFyIHNpIG5vIGVzIG1vZG8gcG9yIGl0ZW1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gaXRlbTtcbiAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGRpc3BhdGNoSXRlbU51bWVyaWNDaGFuZ2UgPSAoaW5kZXg6IG51bWJlciwgbmFtZTogc3RyaW5nLCB2YWx1ZTogbnVtYmVyKSA9PiB7XG4gICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsIHsgdGFyZ2V0OiB7IG5hbWUsIHZhbHVlOiBTdHJpbmcodmFsdWUpIH0gfSBhcyBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50Pik7XG4gICAgfTtcblxuICAgIC8vIOKchSA0LiBOVUVWT1MgSEFORExFUlMgUEFSQSBMQSBCw5pTUVVFREEgUE9SIEPDk0RJR08gRU4gSVRFTVNcblxuICAgIC8qKiBTZSBlamVjdXRhIGFsIHByZXNpb25hciAnRW50ZXInIGVuIGVsIGPDs2RpZ28gZGVsIMOtdGVtICovXG4gICAgY29uc3QgaGFuZGxlSXRlbUNvZGVTdWJtaXQgPSBhc3luYyAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0gaXRlbXNbaW5kZXhdO1xuICAgICAgICBpZiAoIWl0ZW0ucHJvZHVjdF9jb2RlKSByZXR1cm47IC8vIE5vIGJ1c2NhciBzaSBlc3TDoSB2YWPDrW9cblxuICAgICAgICAvLyBMZWVtb3MgbGEgY29uZmlnIGRlIGFydMOtY3Vsb3NcblxuICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBhcnRpY3Vsb3NNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyE7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIOKchSBCdXNjYXIgY29uIGVsIGZvcm1hdG8gZGUgbcOhc2NhcmEgKGluY2x1eWUgcHVudG9zKVxuICAgICAgICAgICAgLy8gQnVzY2Ftb3MgcG9yIGVsICdjb2RlRmllbGQnIChlajogJ3NrdScpXG4gICAgICAgICAgICBjb25zdCBwcm9kdWN0ID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxhbnk+KCdwcm9kdWN0cy9maW5kLWJ5LXNrdScsXG4gICAgICAgICAgICAgICAgW3sgZmllbGROYW1lOiBjb2RlRmllbGQgYXMgc3RyaW5nLCB2YWx1ZTogaXRlbS5wcm9kdWN0X2NvZGUgfSxcbiAgICAgICAgICAgICAgICB7IGZpZWxkTmFtZTogJ2NsaWVudF9pZCcsIHZhbHVlOiBmb3JtRGF0YS5jbGllbnRfaWQ/LnRvU3RyaW5nKCkgPz8gJycgfVxuICAgICAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICBpZiAocHJvZHVjdCkge1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0l0ZW1zID0gWy4uLnByZXZJdGVtc107XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4Y2hhbmdlUmF0ZSA9IGVmZmVjdGl2ZUV4Y2hhbmdlUmF0ZTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZVByaWNlID0gcHJvZHVjdC5zdWdnZXN0ZWRfcHJpY2UgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZUNvc3QgPSBwcm9kdWN0Q29zdFRvQmFzZUNvc3RQcmljZShcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3QuY29zdF9wcmljZSB8fCAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdC5jb3N0X2N1cnJlbmN5LFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZXhjaGFuZ2VfcmF0ZVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50UHJpY2UgPSBOdW1iZXIobmV3SXRlbXNbaW5kZXhdLnVuaXRfcHJpY2UpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRDb3N0ID0gTnVtYmVyKG5ld0l0ZW1zW2luZGV4XS5jb3N0X3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjYWxjdWxhdGVkUHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZVByaWNlIC8gZXhjaGFuZ2VSYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FsY3VsYXRlZENvc3QgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRJdGVtID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ubmV3SXRlbXNbaW5kZXhdLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfY29kZTogcHJvZHVjdFtjb2RlRmllbGQgYXMgc3RyaW5nXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogcHJvZHVjdFtuYW1lRmllbGQgYXMgc3RyaW5nXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhc2Vfc2FsZXNfcHJpY2U6IGJhc2VQcmljZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhc2VfY29zdF9wcmljZTogYmFzZUNvc3QsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdG9ja19xdWFudGl0eTogcHJvZHVjdC5zdG9ja19xdWFudGl0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuaXRfcHJpY2U6IGN1cnJlbnRQcmljZSA+IDAgPyBjdXJyZW50UHJpY2UgOiBjYWxjdWxhdGVkUHJpY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3N0X3ByaWNlOiBjdXJyZW50Q29zdCA+IDAgPyBjdXJyZW50Q29zdCA6IGNhbGN1bGF0ZWRDb3N0LFxuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIFJlY2FsY3VsYXIgaW1wdWVzdG9zIHNpIGVzIG5lY2VzYXJpb1xuICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS50YXhlcyA9IGNhbGN1bGF0ZUl0ZW1UYXhlcyh1cGRhdGVkSXRlbSwgY2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gdXBkYXRlZEl0ZW07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGAnJHtwcm9kdWN0W25hbWVGaWVsZCBhcyBzdHJpbmddfScgc2VsZWNjaW9uYWRvLmApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihgTm8gc2UgZW5jb250csOzIG5pbmfDum4gYXJ0w61jdWxvIGNvbiBlbCBjw7NkaWdvIFwiJHtpdGVtLnByb2R1Y3RfY29kZX1cIi5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgYnVzY2FyIHBvciBjw7NkaWdvOlwiLCBlcnIpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgYXJ0w61jdWxvIHBvciBjw7NkaWdvLlwiKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvKiogU2UgZWplY3V0YSBhbCB0ZWNsZWFyIGVuIGVsIGlucHV0IGRlIGPDs2RpZ28gZGVsIMOtdGVtICovXG4gICAgY29uc3QgaGFuZGxlSXRlbUNvZGVDaGFuZ2UgPSAoaW5kZXg6IG51bWJlciwgbmV3Q29kZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdJdGVtcyA9IFsuLi5wcmV2SXRlbXNdO1xuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHsgLi4ubmV3SXRlbXNbaW5kZXhdIH07XG4gICAgICAgICAgICBpdGVtLnByb2R1Y3RfY29kZSA9IG5ld0NvZGU7XG4gICAgICAgICAgICAvLyBMaW1waWFtb3MgbG9zIG90cm9zIGNhbXBvcyBtaWVudHJhcyB0ZWNsZWFcbiAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9pZCA9IDA7XG4gICAgICAgICAgICBpdGVtLnByb2R1Y3RfbmFtZSA9ICcnO1xuICAgICAgICAgICAgaXRlbS51bml0X3ByaWNlID0gMDtcbiAgICAgICAgICAgIGl0ZW0uc3RvY2tfcXVhbnRpdHkgPSAwO1xuICAgICAgICAgICAgaXRlbS50YXhlcyA9IFtdO1xuICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gaXRlbTtcbiAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIOKchSBGdW5jacOzbiBwYXJhIG1hbmVqYXIgc2VsZWNjacOzbiBkZXNkZSBhdXRvY29tcGxldGFkb1xuICAgIGNvbnN0IGhhbmRsZUl0ZW1BdXRvY29tcGxldGVTZWxlY3QgPSBhc3luYyAoaW5kZXg6IG51bWJlciwgcHJvZHVjdDogYW55KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IGFydGljdWxvc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzITtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2t1VmFsdWUgPSBwcm9kdWN0LnNrdSA/IFN0cmluZyhwcm9kdWN0LnNrdSkgOiAnJztcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxQcm9kdWN0ID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxhbnk+KCdwcm9kdWN0cy9maW5kLWJ5LXNrdScsXG4gICAgICAgICAgICAgICAgW3sgZmllbGROYW1lOiBjb2RlRmllbGQgYXMgc3RyaW5nLCB2YWx1ZTogc2t1VmFsdWUgfSxcbiAgICAgICAgICAgICAgICB7IGZpZWxkTmFtZTogJ2NsaWVudF9pZCcsIHZhbHVlOiBmb3JtRGF0YS5jbGllbnRfaWQ/LnRvU3RyaW5nKCkgPz8gJycgfVxuICAgICAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICBpZiAoZnVsbFByb2R1Y3QpIHtcbiAgICAgICAgICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdJdGVtcyA9IFsuLi5wcmV2SXRlbXNdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBleGNoYW5nZVJhdGUgPSBlZmZlY3RpdmVFeGNoYW5nZVJhdGU7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhc2VQcmljZSA9IGZ1bGxQcm9kdWN0LnN1Z2dlc3RlZF9wcmljZSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBiYXNlQ29zdCA9IHByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlKFxuICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFByb2R1Y3QuY29zdF9wcmljZSB8fCAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFByb2R1Y3QuY29zdF9jdXJyZW5jeSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmV4Y2hhbmdlX3JhdGVcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFByaWNlID0gTnVtYmVyKG5ld0l0ZW1zW2luZGV4XS51bml0X3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50Q29zdCA9IE51bWJlcihuZXdJdGVtc1tpbmRleF0uY29zdF9wcmljZSkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FsY3VsYXRlZFByaWNlID0gcm91bmRUb1R3b0RlY2ltYWxzKGJhc2VQcmljZSAvIGV4Y2hhbmdlUmF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhbGN1bGF0ZWRDb3N0ID0gcm91bmRUb1R3b0RlY2ltYWxzKGJhc2VDb3N0IC8gZXhjaGFuZ2VSYXRlKTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkSXRlbSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm5ld0l0ZW1zW2luZGV4XSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGZ1bGxQcm9kdWN0LmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9jb2RlOiBmdWxsUHJvZHVjdFtjb2RlRmllbGQgYXMgc3RyaW5nXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogZnVsbFByb2R1Y3RbbmFtZUZpZWxkIGFzIHN0cmluZ10sXG4gICAgICAgICAgICAgICAgICAgICAgICBiYXNlX3NhbGVzX3ByaWNlOiBiYXNlUHJpY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYXNlX2Nvc3RfcHJpY2U6IGJhc2VDb3N0LFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RvY2tfcXVhbnRpdHk6IGZ1bGxQcm9kdWN0LnN0b2NrX3F1YW50aXR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgdW5pdF9wcmljZTogY3VycmVudFByaWNlID4gMCA/IGN1cnJlbnRQcmljZSA6IGNhbGN1bGF0ZWRQcmljZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvc3RfcHJpY2U6IGN1cnJlbnRDb3N0ID4gMCA/IGN1cnJlbnRDb3N0IDogY2FsY3VsYXRlZENvc3QsXG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXModXBkYXRlZEl0ZW0sIGNsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIG5ld0l0ZW1zW2luZGV4XSA9IHVwZGF0ZWRJdGVtO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3SXRlbXM7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgcHJvZHVjdG8gY29tcGxldG86JywgZXJyb3IpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8qKiBTZSBlamVjdXRhIGFsIGxpbXBpYXIgZWwgaW5wdXQgcmVsYWNpb25hbCBkZWwgw610ZW0gKi9cbiAgICBjb25zdCBoYW5kbGVJdGVtQ2xlYXIgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBbLi4ucHJldkl0ZW1zXTtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSB7IC4uLm5ld0l0ZW1zW2luZGV4XSB9O1xuICAgICAgICAgICAgaXRlbS5wcm9kdWN0X2lkID0gMDtcbiAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9jb2RlID0gJyc7XG4gICAgICAgICAgICBpdGVtLnByb2R1Y3RfbmFtZSA9ICcnO1xuICAgICAgICAgICAgaXRlbS51bml0X3ByaWNlID0gMDtcbiAgICAgICAgICAgIGl0ZW0uc3RvY2tfcXVhbnRpdHkgPSAwO1xuICAgICAgICAgICAgaXRlbS50YXhlcyA9IFtdO1xuICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gaXRlbTtcbiAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgfSk7XG4gICAgfTtcblxuXG5cbiAgICAvLyAuLi4gKGhhbmRsZUFkZEl0ZW0sIGhhbmRsZVJlbW92ZUl0ZW0sIGhhbmRsZU9wZW5JdGVtVGF4TW9kYWwsIGhhbmRsZVNhdmVJdGVtVGF4ZXMsIGhhbmRsZVRheE1vZGVDaGFuZ2Ugc2luIGNhbWJpb3MpIC4uLlxuICAgIGNvbnN0IGhhbmRsZUFkZEl0ZW0gPSAoKSA9PiB7XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gWy4uLnByZXYsIHsgLi4uRU1QVFlfSVRFTSwgaWQ6IDAsIGxpbmVfbnVtYmVyOiBwcmV2Lmxlbmd0aCArIDEgfV0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZW1vdmVJdGVtID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlT3Blbkl0ZW1UYXhNb2RhbCA9IChpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgIGlmIChpc0NsaWVudFRheEV4ZW1wdCkgcmV0dXJuO1xuICAgICAgICBpZiAoIWZvcm1EYXRhLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybignUG9yIGZhdm9yLCBzZWxlY2Npb25lIHVuIGNsaWVudGUgcHJpbWVyby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4KGluZGV4KTtcbiAgICAgICAgc2V0SXNJdGVtVGF4TW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlSXRlbVRheGVzID0gKHRheGVzOiBBcHBsaWVkVGF4W10pID0+IHtcbiAgICAgICAgaWYgKGN1cnJlbnRJdGVtSW5kZXhGb3JUYXggPT09IG51bGwpIHJldHVybjtcblxuICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT5cbiAgICAgICAgICAgIHByZXZJdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PlxuICAgICAgICAgICAgICAgIGluZGV4ID09PSBjdXJyZW50SXRlbUluZGV4Rm9yVGF4ID8geyAuLi5pdGVtLCB0YXhlczogdGF4ZXMgfSA6IGl0ZW1cbiAgICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgc2V0Q3VycmVudEl0ZW1JbmRleEZvclRheChudWxsKTtcbiAgICAgICAgc2V0SXNJdGVtVGF4TW9kYWxPcGVuKGZhbHNlKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlVGF4TW9kZUNoYW5nZSA9IChlbmFibGVkOiBib29sZWFuKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZW5hYmxlZFxuICAgICAgICB9KSk7XG5cbiAgICAgICAgaWYgKGVuYWJsZWQgJiYgIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYubWFwKGl0ZW0gPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgIHRheGVzOiBjYWxjdWxhdGVJdGVtVGF4ZXMoaXRlbSwgY2xpZW50VGF4ZXMpXG4gICAgICAgICAgICB9KSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gTU9ETyBHTE9CQUw6IExpbXBpYXIgdG9kb3NcbiAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiAoeyAuLi5pdGVtLCB0YXhlczogW10gfSkpKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBleGVjdXRlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgbGV0IHNhdmVJdGVtcyA9IGl0ZW1zLm1hcChpdGVtID0+ICh7IC4uLml0ZW0gfSkpO1xuICAgICAgICBsZXQgc2F2ZUhhc0l0ZW1UYXhlcyA9IGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzO1xuICAgICAgICBsZXQgc2F2ZVRheGVzOiBBcHBsaWVkVGF4W10gPSBhcHBsaWVkVGF4ZXM7XG4gICAgICAgIGxldCBzYXZlQXBwbGllZFRheGVzOiBBcHBsaWVkVGF4W10gPSBbXTtcblxuICAgICAgICBpZiAoaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGNvbnN0IHNhbml0aXplZCA9IHNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCh7XG4gICAgICAgICAgICAgICAgdGF4ZXM6IGFwcGxpZWRUYXhlcyxcbiAgICAgICAgICAgICAgICBpdGVtczogc2F2ZUl0ZW1zLFxuICAgICAgICAgICAgICAgIGhhc19pdGVtX2xldmVsX3RheGVzOiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgc2F2ZUl0ZW1zID0gc2FuaXRpemVkLml0ZW1zO1xuICAgICAgICAgICAgc2F2ZUhhc0l0ZW1UYXhlcyA9IHNhbml0aXplZC5oYXNfaXRlbV9sZXZlbF90YXhlcztcbiAgICAgICAgICAgIHNhdmVUYXhlcyA9IHNhbml0aXplZC50YXhlcztcbiAgICAgICAgICAgIHNhdmVBcHBsaWVkVGF4ZXMgPSBbXTtcbiAgICAgICAgfSBlbHNlIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgc2F2ZUl0ZW1zID0gc2F2ZUl0ZW1zLm1hcChpdGVtID0+ICh7IC4uLml0ZW0sIHRheGVzOiBpdGVtLnRheGVzIHx8IFtdIH0pKTtcbiAgICAgICAgICAgIHNhdmVUYXhlcyA9IFtdO1xuICAgICAgICAgICAgc2F2ZUFwcGxpZWRUYXhlcyA9IFtdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2F2ZUl0ZW1zID0gc2F2ZUl0ZW1zLm1hcChpdGVtID0+ICh7IC4uLml0ZW0sIHRheGVzOiBbXSB9KSk7XG4gICAgICAgICAgICBzYXZlQXBwbGllZFRheGVzID0gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhVG9TZW5kOiBQYXJ0aWFsPFNhbGVzT3JkZXI+ID0ge1xuICAgICAgICAgICAgLi4uZm9ybURhdGEsXG4gICAgICAgICAgICBpdGVtczogc2F2ZUl0ZW1zLFxuICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IHNhdmVIYXNJdGVtVGF4ZXMsXG4gICAgICAgICAgICB0YXhlczogc2F2ZVRheGVzLFxuICAgICAgICAgICAgYXBwbGllZFRheGVzOiBzYXZlQXBwbGllZFRheGVzLFxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiBjYWxjdWxhdGVkVG90YWxzLnRvdGFsLFxuICAgICAgICAgICAgZGlzY291bnRfYW1vdW50OiBOdW1iZXIoZm9ybURhdGEuZGlzY291bnRfYW1vdW50KSB8fCAwLFxuICAgICAgICAgICAgZXhjaGFuZ2VfcmF0ZTogZm9ybURhdGEuZXhjaGFuZ2VfcmF0ZSB8fCAxLFxuICAgICAgICAgICAgaXNfZXhjaGFuZ2VfcmF0ZV9maXhlZDogISFmb3JtRGF0YS5pc19leGNoYW5nZV9yYXRlX2ZpeGVkLFxuICAgICAgICAgICAgZGVsaXZlcnlfYWRkcmVzczogdGVtcERlbGl2ZXJ5QWRkcmVzcyxcbiAgICAgICAgfTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJEYXRvcyBhIGVudmlhcjpcIiwgZGF0YVRvU2VuZCk7XG4gICAgICAgICAgICBhd2FpdCBzYXZlSXRlbShkYXRhVG9TZW5kIGFzIFNhbGVzT3JkZXIpO1xuXG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBQZWRpZG8gJHttb2RlID09PSAnY3JlYXRlJyA/ICdjcmVhZG8nIDogJ2FjdHVhbGl6YWRvJ30gY29uIMOpeGl0by5gKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9IGNhdGNoIChhcGlFcnJvcjogYW55KSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihgRXJyb3IgYWwgZ3VhcmRhcjogJHthcGlFcnJvci5tZXNzYWdlIHx8ICdFcnJvciBkZXNjb25vY2lkbyd9YCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgaXRlbXNXaXRoUHJvZHVjdCA9IGl0ZW1zLmZpbHRlcihpdGVtID0+IGl0ZW0ucHJvZHVjdF9pZCAmJiBOdW1iZXIoaXRlbS5wcm9kdWN0X2lkKSA+IDApO1xuICAgICAgICBpZiAoaXRlbXNXaXRoUHJvZHVjdC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBwZWRpZG8gZGViZSBpbmNsdWlyIGFsIG1lbm9zIHVuIHByb2R1Y3RvLiBBZ3JlZ3VlIGzDrW5lYXMgY29uIGFydMOtY3Vsb3Mgc2VsZWNjaW9uYWRvcy4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghZm9ybURhdGEuY3VycmVuY3lfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdEZWJlIHNlbGVjY2lvbmFyIHVuYSBtb25lZGEuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBwcm9jZWVkVG9TYXZlID0gKCkgPT4ge1xuICAgICAgICAgICAgZ2F0ZVNhdmUoaXRlbXMsICgpID0+IHtcbiAgICAgICAgICAgICAgICB2b2lkIGV4ZWN1dGVTYXZlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBvdmVyU3RvY2tJdGVtID0gaXRlbXMuZmluZChpc0xpbmVPdmVyQXZhaWxhYmxlU3RvY2spO1xuICAgICAgICBpZiAob3ZlclN0b2NrSXRlbSkge1xuICAgICAgICAgICAgcGVuZGluZ0FmdGVyU3RvY2tBY2tSZWYuY3VycmVudCA9IHByb2NlZWRUb1NhdmU7XG4gICAgICAgICAgICBzZXRTdG9ja0FsZXJ0KHtcbiAgICAgICAgICAgICAgICBvcGVuOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRpdGxlOiAnU3RvY2sgaW5zdWZpY2llbnRlJyxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBzdG9ja0V4Y2Vzc01lc3NhZ2Uob3ZlclN0b2NrSXRlbSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHByb2NlZWRUb1NhdmUoKTtcbiAgICB9O1xuXG4gICAgLy8g4pyFIE5VRVZPOiBIQU5ETEVSUyBHRU7DiVJJQ09TIFBBUkEgTEEgQ0FCRUNFUkFcblxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UgPSAoZmllbGQ6IEhlYWRlckZpZWxkLCBuZXdDb2RlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtgJHtmaWVsZH1faWRgXTogbnVsbCxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1fY29kZWBdOiBuZXdDb2RlLCAvLyBBY3R1YWxpemEgZWwgY8OzZGlnb1xuICAgICAgICAgICAgW2Ake2ZpZWxkfV9uYW1lYF06ICcnLCAvLyBMaW1waWEgZWwgbm9tYnJlXG4gICAgICAgICAgICBbYCR7ZmllbGR9YF06IHVuZGVmaW5lZCwgLy8gTGltcGlhIGVsIG9iamV0b1xuICAgICAgICB9KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQgPSBhc3luYyAoZmllbGQ6IEhlYWRlckZpZWxkLCBjb25maWc6IE1vZHVsZUNvbmZpZzxhbnk+KSA9PiB7XG4gICAgICAgIGNvbnN0IGNvZGVWYWx1ZSA9IGZvcm1EYXRhW2Ake2ZpZWxkfV9jb2RlYCBhcyBrZXlvZiBTYWxlc09yZGVyXSBhcyBzdHJpbmc7XG4gICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG5cbiAgICAgICAgaWYgKCFjb25maWcucmVsYXRpb25hbEZpZWxkcykge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoYEVycm9yOiBGYWx0YSAncmVsYXRpb25hbEZpZWxkcycgZW4gbGEgY29uZmlnIGRlICR7ZmllbGR9YCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGVuZHBvaW50IH0gPSBjb25maWc7XG4gICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IGNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBpdGVtID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxhbnk+KGVuZHBvaW50LCBbeyBmaWVsZE5hbWU6IGNvZGVGaWVsZCBhcyBzdHJpbmcsIHZhbHVlOiBjb2RlVmFsdWUgfV0pO1xuICAgICAgICAgICAgLy8g4pyFIDQuIFNJTVBMSUZJQ0FETzogTGxhbWFtb3MgYSBsYSBudWV2YSBmdW5jacOzblxuICAgICAgICAgICAgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZmllbGQsIGl0ZW0pO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgJyR7aXRlbVtuYW1lRmllbGQgYXMgc3RyaW5nXX0nIHNlbGVjY2lvbmFkby5gKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgYnVzY2FyIHBvciBjw7NkaWdvOlwiLCBlcnIpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgcG9yIGPDs2RpZ28uXCIpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNsZWFyID0gKGZpZWxkOiBIZWFkZXJGaWVsZCkgPT4ge1xuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgW2Ake2ZpZWxkfV9pZGBdOiBudWxsLFxuICAgICAgICAgICAgW2Ake2ZpZWxkfV9jb2RlYF06IG51bGwsXG4gICAgICAgICAgICBbYCR7ZmllbGR9X25hbWVgXTogbnVsbCxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1gXTogdW5kZWZpbmVkLFxuICAgICAgICB9KSk7XG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ2NsaWVudCcpIHtcbiAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDinIUgNi4gTnVldm8gaGFuZGxlciBwYXJhIGFicmlyIGVsIG1vZGFsIGRlIGhpc3RvcmlhbFxuICAgIGNvbnN0IGhhbmRsZU9wZW5IaXN0b3J5TW9kYWwgPSAocHJvZHVjdElkOiBudW1iZXIsIHR5cGU6ICdwcmljZScgfCAnY29zdCcsIHByb2R1Y3ROYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKCFwcm9kdWN0SWQpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0VsIMOtdGVtIG5vIHRpZW5lIHVuIHByb2R1Y3RvIHNlbGVjY2lvbmFkby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlID09PSAncHJpY2UnKSB7XG4gICAgICAgICAgICBzZXRIaXN0b3J5TW9kYWxTdGF0ZSh7XG4gICAgICAgICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRpdGxlOiBgSGlzdG9yaWFsIGRlIFByZWNpb3MgZGUgVmVudGEgJHtwcm9kdWN0TmFtZX1gLFxuICAgICAgICAgICAgICAgIGVuZHBvaW50OiAncHJvZHVjdHMvc2FsZXMtaGlzdG9yeScsIC8vIEVuZHBvaW50IGJhc2VcbiAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgICAgICAgICBjbGllbnRJZDogZm9ybURhdGEuY2xpZW50X2lkLFxuICAgICAgICAgICAgICAgIGNvbHVtbnM6IHByaWNlTGlzdENvbHVtbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEhpc3RvcnlNb2RhbFN0YXRlKHtcbiAgICAgICAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgICAgICAgdGl0bGU6ICdIaXN0b3JpYWwgZGUgQ29zdG9zIGRlIENvbXByYScsXG4gICAgICAgICAgICAgICAgZW5kcG9pbnQ6ICdwcm9kdWN0cy9wdXJjaGFzZXMtaGlzdG9yeScsIC8vIEVuZHBvaW50IGJhc2VcbiAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgICAgICAgICBjbGllbnRJZDogZm9ybURhdGEuY2xpZW50X2lkLFxuICAgICAgICAgICAgICAgIGNvbHVtbnM6IGNvc3RMaXN0Q29sdW1ucyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNsb3NlSGlzdG9yeU1vZGFsID0gKCkgPT4ge1xuICAgICAgICBzZXRIaXN0b3J5TW9kYWxTdGF0ZShpbml0aWFsSGlzdG9yeU1vZGFsU3RhdGUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDbG9zZVN0b2NrQWxlcnQgPSAoKSA9PiB7XG4gICAgICAgIHNldFN0b2NrQWxlcnQocHJldiA9PiAoeyAuLi5wcmV2LCBvcGVuOiBmYWxzZSB9KSk7XG4gICAgICAgIGNvbnN0IGNvbnRpbnVlU2F2ZSA9IHBlbmRpbmdBZnRlclN0b2NrQWNrUmVmLmN1cnJlbnQ7XG4gICAgICAgIHBlbmRpbmdBZnRlclN0b2NrQWNrUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBjb250aW51ZVNhdmU/LigpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVRdWFudGl0eUJsdXIgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0gaXRlbXNbaW5kZXhdO1xuICAgICAgICBpZiAoIWl0ZW0gfHwgIWlzTGluZU92ZXJBdmFpbGFibGVTdG9jayhpdGVtKSkgcmV0dXJuO1xuICAgICAgICBwZW5kaW5nQWZ0ZXJTdG9ja0Fja1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgc2V0U3RvY2tBbGVydCh7XG4gICAgICAgICAgICBvcGVuOiB0cnVlLFxuICAgICAgICAgICAgdGl0bGU6ICdTdG9jayBpbnN1ZmljaWVudGUnLFxuICAgICAgICAgICAgbWVzc2FnZTogc3RvY2tFeGNlc3NNZXNzYWdlKGl0ZW0pLFxuICAgICAgICB9KTtcbiAgICB9O1xuXG5cbiAgICBpZiAobG9hZGluZ0RhdGEgJiYgbW9kZSA9PT0gJ2VkaXQnKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvciAmJiBtb2RlID09PSAnZWRpdCcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBkYXRvczoge2Vycm9yfTwvZGl2PjtcblxuICAgIGNvbnN0IHRvdGFsTGFiZWxTdHlsZSA9IFwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0XCI7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02XCI+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgQ0FCRUNFUkEgKFJFU1RBVVJBREEpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNlwiPlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIDEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkNsaWVudGUgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLmNsaWVudF9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEuY2xpZW50X25hbWUgfHwgZm9ybURhdGEuY2xpZW50Py5uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UoJ2NsaWVudCcsIG5ld0NvZGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCgnY2xpZW50JywgY2xpZW50ZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnY2xpZW50JywgY2xpZW50ZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSGVhZGVyQ2xlYXIoJ2NsaWVudCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VmVuZGVkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuc2FsZXNwZXJzb25fY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnNhbGVzcGVyc29uX25hbWUgfHwgZm9ybURhdGEuc2FsZXNwZXJzb24/Lm5hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnc2FsZXNwZXJzb24nLCBuZXdDb2RlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ3NhbGVzcGVyc29uJywgdmVuZGVkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdzYWxlc3BlcnNvbicsIHZlbmRlZG9yZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSGVhZGVyQ2xlYXIoJ3NhbGVzcGVyc29uJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgey8qIC0tLSBNT0RJRklDQURPOiBDYW1wbyAnQ29tcHJhZG9yJyByZXN0YXVyYWRvIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Db21wcmFkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuYnV5ZXJfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLmJ1eWVyX25hbWUgfHwgZm9ybURhdGEuYnV5ZXI/Lm5hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnYnV5ZXInLCBuZXdDb2RlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ2J1eWVyJywgY29tcHJhZG9yZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnYnV5ZXInLCBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVIZWFkZXJDbGVhcignYnV5ZXInKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIDIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIFBlZGlkbyAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJvcmRlcl9kYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEub3JkZXJfZGF0ZT8uc3BsaXQoJ1QnKVswXSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GZWNoYSBFbnRyZWdhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVsaXZlcnlfZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRlbGl2ZXJ5X2RhdGU/LnNwbGl0KCdUJylbMF0gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gTU9ESUZJQ0FETzogQ2FtcG8gJ1RyYW5zcG9ydGUnIHJlc3RhdXJhZG8gLS0tICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlRyYW5zcG9ydGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEudHJhbnNwb3J0X2NvZGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS50cmFuc3BvcnRfbmFtZSB8fCBmb3JtRGF0YS50cmFuc3BvcnQ/Lm5hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgndHJhbnNwb3J0JywgbmV3Q29kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVIZWFkZXJDb2RlU3VibWl0KCd0cmFuc3BvcnQnLCB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCd0cmFuc3BvcnQnLCB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVIZWFkZXJDbGVhcigndHJhbnNwb3J0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogQ29sdW1uYSAzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Nb25lZGEgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLmN1cnJlbmN5X2NvZGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5jdXJyZW5jeV9uYW1lIHx8IGZvcm1EYXRhLmN1cnJlbmN5Py5uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UoJ2N1cnJlbmN5JywgbmV3Q29kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVIZWFkZXJDb2RlU3VibWl0KCdjdXJyZW5jeScsIG1vbmVkYXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnY3VycmVuY3knLCBtb25lZGFzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IGhhbmRsZUhlYWRlckNsZWFyKCdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VGlwbyBkZSBjYW1iaW88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJleGNoYW5nZV9yYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZXhjaGFuZ2VfcmF0ZSA/PyAxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtcHR5V2hlblplcm89e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBleGNoYW5nZV9yYXRlOiBudW0gfHwgMSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlzX2V4Y2hhbmdlX3JhdGVfZml4ZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpc19leGNoYW5nZV9yYXRlX2ZpeGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9eyEhZm9ybURhdGEuaXNfZXhjaGFuZ2VfcmF0ZV9maXhlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBVc2Ftb3MgaGFuZGxlSW5wdXRDaGFuZ2UgcGFyYSBndWFyZGFyIGVsIHZhbG9yIGVuIGZvcm1EYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1pbmRpZ28tNjAwIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImlzX2V4Y2hhbmdlX3JhdGVfZml4ZWRcIiBjbGFzc05hbWU9XCJtbC0yIGJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpcG8gZGUgY2FtYmlvIGZpam9cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgey8qIENvbHVtbmEgNCAoVGV4dGFyZWFzKSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RGlyZWNjacOzbiBFbnRyZWdhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDinIUgNi4gUkVFTVBMQVpPIERFIFRFWFRBUkVBIFBPUiBTRUxFQ1QgRElOw4FNSUNPICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkZWxpdmVyeV9hZGRyZXNzX3NlbGVjdG9yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFbCB2YWxvciBzZWxlY2Npb25hZG8gZW4gZWwgc2VsZWN0b3IgZGViZSBzZXIgJ0NVU1RPTV9ORVdfQUREUkVTUycgbyBsYSBkaXJlY2Npw7NuIGFjdHVhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpc0N1c3RvbUFkZHJlc3MgPyAnQ1VTVE9NX05FV19BRERSRVNTJyA6ICh0ZW1wRGVsaXZlcnlBZGRyZXNzIHx8IChjbGllbnRBZGRyZXNzZXMubGVuZ3RoID4gMCA/IGNsaWVudEFkZHJlc3Nlc1swXSA6ICcnKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURlbGl2ZXJ5QWRkcmVzc0NoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZvcm1EYXRhLmNsaWVudF9pZH0gLy8gRGVzaGFiaWxpdGFkbyBzaSBubyBoYXkgY2xpZW50ZVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25hIHVuYSBkaXJlY2Npw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9wY2lvbmVzIGRlbCBjbGllbnRlIChzaGlwYWRkcmVzcyBhcnJheSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjbGllbnRBZGRyZXNzZXMgfHwgW10pLm1hcCgoYWRkcmVzcywgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2luZGV4fSB2YWx1ZT17YWRkcmVzc30+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9wY2nDs24gJ090cmEgRGlyZWNjacOzbicgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNVU1RPTV9ORVdfQUREUkVTU1wiPi0tLSBJbmdyZXNhciBPdHJhIERpcmVjY2nDs24gLS0tPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSA3LiBJTlBVVCBWSVNJQkxFIHNpIHNlIHNlbGVjY2lvbmEgJ090cmEgRGlyZWNjacOzbicgbyBzaSBsYSBkaXJlY2Npw7NuIGNhcmdhZGEgZXJhIGN1c3RvbSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0N1c3RvbUFkZHJlc3MgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVsaXZlcnlfYWRkcmVzc19pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wRGVsaXZlcnlBZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbmdyZXNlIGxhIG51ZXZhIGRpcmVjY2nDs24gZGUgZW50cmVnYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWluZGlnby01MDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5OwrogT3JkZW4gQ29tcHJhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucHVyY2hhc2Vfb3JkZXJfbnVtYmVyIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cblxuICAgICAgICAgICAgey8qIC0tLSBTRUNDScOTTiBERSBJVEVNUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+SXRlbXMgZGVsIFBlZGlkbzwvaDM+XG4gICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1lZGl1bSAkeyFmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/ICd0ZXh0LWluZGlnby02MDAnIDogJ3RleHQtZ3JheS01MDAnfWB9PkltcC4gR2xvYmFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb2dnbGVTd2l0Y2ggZW5hYmxlZD17Zm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXN9IG9uQ2hhbmdlPXtoYW5kbGVUYXhNb2RlQ2hhbmdlfSBzckxhYmVsPVwiTW9kbyBkZSBpbXB1ZXN0b3NcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/ICd0ZXh0LWluZGlnby02MDAnIDogJ3RleHQtZ3JheS01MDAnfWB9PkltcC4gcG9yIMONdGVtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogVGFibGEgZGUgSXRlbXMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB3LTIvNVwiPkFydMOtY3VsbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5DYW50LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5TdG9jazwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5QLiBVbml0LiAoe3NpbWJvbG9Nb25lZGF9KTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gTU9ESUZJQ0FETzogRXRpcXVldGEgZGUgZGVzY3VlbnRvIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBoaWRkZW5cIj5EZXNjLiAoTW9udG8pPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIC0tLSBNT0RJRklDQURPOiBDb2x1bW5hIGRlIEltcHVlc3RvcyAoQ29uZGljaW9uYWwpIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+SW1wdWVzdG9zPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlV0aWxpZGFkPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRvdGFsIEzDrW5lYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5BY2MuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IChOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRpc2NvdW50ID0gTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsaW5lU3VidG90YWwgPSBzdWJ0b3RhbCAtIGRpc2NvdW50OyAvLyBTdWJ0b3RhbCBkZSBsw61uZWEgKEJhc2UgaW1wb25pYmxlIGRlbCBpdGVtKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVDb3N0ID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLmNvc3RfcHJpY2UpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb2ZpdCA9IChsaW5lU3VidG90YWwgLSBsaW5lQ29zdCkgLyBsaW5lQ29zdCAqIDEwMDsgLy8gVXRpbGlkYWRcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNOYU4ocHJvZml0KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2ZpdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENhbGN1bGFtb3MgdG90YWwgZGUgaW1wdWVzdG9zIGRlbCBpdGVtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXhUb3RhbCA9ICFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoaXRlbS50YXhlcyB8fCBbXSkucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXhUb3RhbDsgLy8gVG90YWwgZmluYWwgZGUgbGEgbMOtbmVhXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWQgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtpdGVtLnByb2R1Y3RfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5wcm9kdWN0X25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhuZXdDb2RlKSA9PiBoYW5kbGVJdGVtQ29kZUNoYW5nZShpbmRleCwgbmV3Q29kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUl0ZW1Db2RlU3VibWl0KGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnaXRlbScsIGFydGljdWxvc01vZHVsZUNvbmZpZywgaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVJdGVtQ2xlYXIoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFzaz1cInNrdVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmFibGVBdXRvY29tcGxldGU9e3RydWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvY29tcGxldGVDb25maWc9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRwb2ludDogYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVGaWVsZDogJ3NrdScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZUZpZWxkOiAnbmFtZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUGFyYW1zOiBhcnRpY3Vsb3NJdGVtU2VhcmNoRmlsdGVycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdDogKHByb2R1Y3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUF1dG9jb21wbGV0ZVNlbGVjdChpbmRleCwgcHJvZHVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCBuYW1lPVwicXVhbnRpdHlcIiB2YWx1ZT17aXRlbS5xdWFudGl0eX0gb25DaGFuZ2U9e251bSA9PiBkaXNwYXRjaEl0ZW1OdW1lcmljQ2hhbmdlKGluZGV4LCAncXVhbnRpdHknLCBudW0pfSBvbkJsdXI9eygpID0+IGhhbmRsZVF1YW50aXR5Qmx1cihpbmRleCl9IGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy0yMCBweC0yIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdG9ja19xdWFudGl0eX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCBuYW1lPVwidW5pdF9wcmljZVwiIHZhbHVlPXtpdGVtLnVuaXRfcHJpY2V9IG9uQ2hhbmdlPXtudW0gPT4gZGlzcGF0Y2hJdGVtTnVtZXJpY0NoYW5nZShpbmRleCwgJ3VuaXRfcHJpY2UnLCBudW0pfSBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctMjggcHgtMiBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwIGhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE1PRElGSUNBRE86IElucHV0IGRlIGRlc2N1ZW50byAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXQgbmFtZT1cImRpc2NvdW50X2Ftb3VudFwiIHZhbHVlPXtpdGVtLmRpc2NvdW50X2Ftb3VudH0gb25DaGFuZ2U9e251bSA9PiBkaXNwYXRjaEl0ZW1OdW1lcmljQ2hhbmdlKGluZGV4LCAnZGlzY291bnRfYW1vdW50JywgbnVtKX0gY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LTI0IHB4LTIgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGxpbmVTdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE1PRElGSUNBRE86IENlbGRhIGRlIEltcHVlc3RvcyAoQ29uZGljaW9uYWwpIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtVGF4VG90YWwsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtICR7cHJvZml0ID49IDAgPyAndGV4dC1ncmVlbi02MDAnIDogJ3RleHQtcmVkLTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShwcm9maXQsICdwZXJjZW50dWFsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShsaW5lVG90YWwsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNwYWNlLXgtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuSGlzdG9yeU1vZGFsKGl0ZW0ucHJvZHVjdF9pZCwgJ3ByaWNlJywgaXRlbS5wcm9kdWN0X25hbWUpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1ibHVlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtOTAwXCIgdGl0bGU9XCJWZXIgaGlzdG9yaWFsIGRlIHByZWNpb3NcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRhZ3MgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5IaXN0b3J5TW9kYWwoaXRlbS5wcm9kdWN0X2lkLCAnY29zdCcsIGl0ZW0ucHJvZHVjdF9uYW1lKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtZ3JheS02MDAgaG92ZXI6dGV4dC1ncmF5LTkwMFwiIHRpdGxlPVwiVmVyIGhpc3RvcmlhbCBkZSBjb3N0b3NcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVdhcmVob3VzZSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuSXRlbVRheE1vZGFsKGluZGV4KX0gY2xhc3NOYW1lPVwicC0yIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby05MDBcIiB0aXRsZT1cIkdlc3Rpb25hciBpbXB1ZXN0b3MgZGVsIMOtdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGVyY2VudGFnZSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZUl0ZW0oaW5kZXgpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1yZWQtNjAwIGhvdmVyOnRleHQtcmVkLTkwMFwiIHRpdGxlPVwiRWxpbWluYXIgw610ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVBZGRJdGVtfSBjbGFzc05hbWU9XCJtdC00IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYVBsdXMgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgQWdyZWdhciDDjXRlbVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgVE9UQUxFUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTYgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogLS0tIE1PRElGSUNBRE86IElucHV0IGRlIERlc2N1ZW50byBHbG9iYWwgKE1vbnRvKSAtLS0gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RGVzY3VlbnRvIEdsb2JhbCAoTW9udG8pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzY291bnRfYW1vdW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGlzY291bnRfYW1vdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBkaXNjb3VudF9hbW91bnQ6IG51bSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk9ic2VydmFjaW9uZXM6PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3Rlc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M30gLy8gRGFtb3MgbcOhcyBlc3BhY2lvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vdGVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBTZWNjacOzbiBJbXB1ZXN0b3MgR2xvYmFsZXMgKENvbmRpY2lvbmFsKSAqL31cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiAhZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIEdsb2JhbGVzIEFwbGljYWRvczwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FwcGxpZWRUYXhlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBsaWVkVGF4ZXMubWFwKHRheCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dGF4LnRheF9pZH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9Pnt0YXgudGF4X25hbWV9ICh7dGF4LnJhdGV9JSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+Tm8gaGF5IGltcHVlc3RvcyBnbG9iYWxlcyBhcGxpY2Fkb3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIGRlIFJlc3VtZW4gRmluYWwgKE1PRElGSUNBREEpICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TdWJ0b3RhbCAoSXRlbXMpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RGVzYy4gKEl0ZW1zKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxJdGVtRGlzY291bnRzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIChHbG9iYWwpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+LSB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy5nbG9iYWxEaXNjb3VudEFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSBmb250LXNlbWlib2xkYH0+QmFzZSBJbXBvbmlibGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbFZhbHVlU3R5bGV9IGZvbnQtc2VtaWJvbGRgfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50YXhCYXNlLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IFwiSW1wdWVzdG9zIChJdGVtcyk6XCIgOiBcIkltcHVlc3RvcyAoR2xvYmFsKTpcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT4rIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRvdGFsVGF4ZXMsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtbGcgZm9udC1zZW1pYm9sZGB9PlRvdGFsIEZpbmFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZX0gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIEJvdG9uZXMgZGUgR3VhcmRhci9DYW5jZWxhciAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIj5DYW5jZWxhcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgbWwtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctZ3JlZW4tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JlZW4tNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgUGVkaWRvXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1vZGFsZXMgKi99XG4gICAgICAgICAgICB7aXNNb2RhbE9wZW4gJiYgbW9kYWxDb25maWcgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbCBpc09wZW49e2lzTW9kYWxPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9IG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RNb2RhbH0gY29uZmlnPXttb2RhbENvbmZpZ30gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7aXNJdGVtVGF4TW9kYWxPcGVuICYmIGN1cnJlbnRJdGVtSW5kZXhGb3JUYXggIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgIDxJdGVtVGF4TW9kYWxcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXtpc0l0ZW1UYXhNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzSXRlbVRheE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIC8vIEVsIG1vZGFsIFwiZ3VhcmRhXCIgKGNvbmZpcm1hKSBsb3MgaW1wdWVzdG9zIHF1ZSB5YSBzZSBjYWxjdWxhcm9uXG4gICAgICAgICAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZUl0ZW1UYXhlc31cbiAgICAgICAgICAgICAgICAgICAgaXRlbT17aXRlbXNbY3VycmVudEl0ZW1JbmRleEZvclRheF19XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudFRheGVzPXtjbGllbnRUYXhlc31cbiAgICAgICAgICAgICAgICAgICAgY2xpZW50VGF4Q29uZGl0aW9uPXtjbGllbnRUYXhDb25kaXRpb259XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiDinIUgOC4gUmVuZGVyaXphciBlbCBudWV2byBtb2RhbCBkZSBoaXN0b3JpYWwgKi99XG4gICAgICAgICAgICB7aGlzdG9yeU1vZGFsU3RhdGUuaXNPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8UHJvZHVjdEhpc3RvcnlNb2RhbFxuICAgICAgICAgICAgICAgICAgICBpc09wZW49e2hpc3RvcnlNb2RhbFN0YXRlLmlzT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VIaXN0b3J5TW9kYWx9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXtoaXN0b3J5TW9kYWxTdGF0ZS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ9e2hpc3RvcnlNb2RhbFN0YXRlLmVuZHBvaW50fVxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWQ9e2hpc3RvcnlNb2RhbFN0YXRlLnByb2R1Y3RJZCF9XG4gICAgICAgICAgICAgICAgICAgIGNsaWVudElkPXtoaXN0b3J5TW9kYWxTdGF0ZS5jbGllbnRJZCF9XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2hpc3RvcnlNb2RhbFN0YXRlLmNvbHVtbnN9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8QWxlcnRNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17c3RvY2tBbGVydC5vcGVufVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlU3RvY2tBbGVydH1cbiAgICAgICAgICAgICAgICB0aXRsZT17c3RvY2tBbGVydC50aXRsZX1cbiAgICAgICAgICAgICAgICBtZXNzYWdlPXtzdG9ja0FsZXJ0Lm1lc3NhZ2V9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICB7YXV0aE1vZGFsfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3BlZGlkb3NfdmVudGEvcGFnZXMvUGVkaWRvc1ZlbnRhRm9ybVBhZ2UudHN4In0=