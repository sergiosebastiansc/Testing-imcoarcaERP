import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito/pages/NotasCreditoListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito/pages/NotasCreditoListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { notasCreditoModuleConfig } from "/src/features/notas_credito/notas_credito.config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getModuleBasePermission, getRequiredPermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const NotasCreditoListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(notasCreditoModuleConfig, getDefaultListDateRange());
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(notasCreditoModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const hasEditPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const hasDeletePermission = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEditNote = (note) => {
    return hasEditPermission && !note.cae_number;
  };
  const canDeleteNote = (note) => {
    return hasDeletePermission && !note.cae_number;
  };
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoListPage.tsx",
    lineNumber: 51,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: notasCreditoModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit: canEditNote,
      canDelete: canDeleteNote
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoListPage.tsx",
      lineNumber: 54,
      columnNumber: 5
    },
    this
  );
};
_s(NotasCreditoListPage, "yjB/rutd0ICjbFA72BDSbAuQTHI=", false, function() {
  return [useCrud, usePermissions];
});
_c = NotasCreditoListPage;
var _c;
$RefreshReg$(_c, "NotasCreditoListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito/pages/NotasCreditoListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito/pages/NotasCreditoListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdDQUFpRDtBQUMxRCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCQyw2QkFBNkI7QUFDL0QsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLHVCQUF1QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJbkIsUUFBb0JDLDBCQUEwQkksd0JBQXdCLENBQUM7QUFHM0UsUUFBTSxFQUFFZSxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTW1CLG1CQUFtQmpCLHNCQUFzQkgseUJBQXlCcUIsU0FBUztBQUNqRixRQUFNQyxhQUFhRixtQkFBbUJsQix3QkFBd0JrQixnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxvQkFBb0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFDakYsUUFBTUUsc0JBQXNCRixhQUFhSCxvQkFBb0JHLFlBQVksUUFBUSxJQUFJO0FBR3JGLFFBQU1HLGNBQWNBLENBQUNDLFNBQThCO0FBRS9DLFdBQU9ILHFCQUFxQixDQUFDRyxLQUFLQztBQUFBQSxFQUN0QztBQUVBLFFBQU1DLGdCQUFnQkEsQ0FBQ0YsU0FBOEI7QUFFakQsV0FBT0YsdUJBQXVCLENBQUNFLEtBQUtDO0FBQUFBLEVBQ3hDO0FBRUEsTUFBSWpCLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRVjtBQUFBQSxNQUNSLG9CQUFvQk87QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhVyxRQUFRO0FBQUEsTUFDakMsaUJBQWlCWCxhQUFhWSxhQUFhO0FBQUEsTUFDM0MsZUFBZVosYUFBYWEsV0FBVztBQUFBLE1BQ3ZDLHVCQUF1QjtBQUFBLE1BQ3ZCLFNBQVNOO0FBQUFBLE1BQ1QsV0FBV0c7QUFBQUE7QUFBQUEsSUFqQmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUI2QjtBQUdyQztBQUFFdEIsR0EvQ1dELHNCQUFvQjtBQUFBLFVBSXpCTixTQUc0QkUsY0FBYztBQUFBO0FBQUErQixLQVByQzNCO0FBQW9CLElBQUEyQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsIm5vdGFzQ3JlZGl0b01vZHVsZUNvbmZpZyIsInVzZVBlcm1pc3Npb25zIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXREZWZhdWx0TGlzdERhdGVSYW5nZSIsIk5vdGFzQ3JlZGl0b0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiaGFzRWRpdFBlcm1pc3Npb24iLCJoYXNEZWxldGVQZXJtaXNzaW9uIiwiY2FuRWRpdE5vdGUiLCJub3RlIiwiY2FlX251bWJlciIsImNhbkRlbGV0ZU5vdGUiLCJ0ZXJtIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzQ3JlZGl0b0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgbm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLCB0eXBlIENyZWRpdE5vdGUgfSBmcm9tICcuLi9ub3Rhc19jcmVkaXRvLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uLCBnZXRSZXF1aXJlZFBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuXG5leHBvcnQgY29uc3QgTm90YXNDcmVkaXRvTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxDcmVkaXROb3RlPihub3Rhc0NyZWRpdG9Nb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgLy8g4pyFIFBlcm1pc29zIGRlbCBtw7NkdWxvXG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IG1vZHVsZVBlcm1pc3Npb24gPSBnZXRSZXF1aXJlZFBlcm1pc3Npb24obm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSk7XG4gICAgY29uc3QgbW9kdWxlQmFzZSA9IG1vZHVsZVBlcm1pc3Npb24gPyBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbihtb2R1bGVQZXJtaXNzaW9uKSA6IG51bGw7XG4gICAgY29uc3QgaGFzRWRpdFBlcm1pc3Npb24gPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnZWRpdCcpIDogdHJ1ZTtcbiAgICBjb25zdCBoYXNEZWxldGVQZXJtaXNzaW9uID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2RlbGV0ZScpIDogdHJ1ZTtcblxuICAgIC8vIOKchSBSZWdsYXMgY29tYmluYWRhczogcGVybWlzbyArIENBRVxuICAgIGNvbnN0IGNhbkVkaXROb3RlID0gKG5vdGU6IENyZWRpdE5vdGUpOiBib29sZWFuID0+IHtcbiAgICAgICAgLy8gU29sbyBlZGl0YWJsZSBzaSB0aWVuZSBwZXJtaXNvIHkgTk8gdGllbmUgQ0FFXG4gICAgICAgIHJldHVybiBoYXNFZGl0UGVybWlzc2lvbiAmJiAhbm90ZS5jYWVfbnVtYmVyO1xuICAgIH07XG5cbiAgICBjb25zdCBjYW5EZWxldGVOb3RlID0gKG5vdGU6IENyZWRpdE5vdGUpOiBib29sZWFuID0+IHtcbiAgICAgICAgLy8gU29sbyBib3JyYWJsZSBzaSB0aWVuZSBwZXJtaXNvIHkgTk8gdGllbmUgQ0FFXG4gICAgICAgIHJldHVybiBoYXNEZWxldGVQZXJtaXNzaW9uICYmICFub3RlLmNhZV9udW1iZXI7XG4gICAgfTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8Q3JlZGl0Tm90ZT5cbiAgICAgICAgICAgIGNvbmZpZz17bm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgICAgICBjYW5FZGl0PXtjYW5FZGl0Tm90ZX1cbiAgICAgICAgICAgIGNhbkRlbGV0ZT17Y2FuRGVsZXRlTm90ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG8vcGFnZXMvTm90YXNDcmVkaXRvTGlzdFBhZ2UudHN4In0=