import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cheques/pages/ChequesListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cheques/pages/ChequesListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { chequesModuleConfig } from "/src/features/cheques/cheques.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const ChequesListPage = () => {
  _s();
  const navigate = useNavigate();
  const {
    response,
    loading,
    isAppending,
    error,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(chequesModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/cheques/pages/ChequesListPage.tsx",
    lineNumber: 34,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: chequesModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      onRowClick: (item) => navigate(`${chequesModuleConfig.baseRoute}/${item.id}`)
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/cheques/pages/ChequesListPage.tsx",
      lineNumber: 37,
      columnNumber: 5
    },
    this
  );
};
_s(ChequesListPage, "HZL5Y2i4Rt72HBCy4JuYZ2VZOd0=", false, function() {
  return [useNavigate, useCrud];
});
_c = ChequesListPage;
var _c;
$RefreshReg$(_c, "ChequesListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cheques/pages/ChequesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cheques/pages/ChequesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY3NCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWR0QixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDJCQUErQztBQUN4RCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUVqQyxhQUFNQyxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNQyxXQUFXUCxZQUFZO0FBRTdCLFFBQU07QUFBQSxJQUNGUTtBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUNuREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJZixRQUF1QkQscUJBQXFCRSx3QkFBd0IsQ0FBQztBQUV6RSxNQUFJTyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFdkQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVQ7QUFBQUEsTUFDUixvQkFBb0JNO0FBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsUUFBUUk7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFDLFFBQVE7QUFBQSxNQUNqQyxpQkFBaUJELGFBQWFFLGFBQWE7QUFBQSxNQUMzQyxlQUFlRixhQUFhRyxXQUFXO0FBQUEsTUFDdkMsdUJBQXVCO0FBQUEsTUFDdkIsWUFBWSxDQUFDQyxTQUFTZixTQUFTLEdBQUdMLG9CQUFvQnFCLFNBQVMsSUFBSUQsS0FBS0UsRUFBRSxFQUFFO0FBQUE7QUFBQSxJQWZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFla0Y7QUFHMUY7QUFBRWxCLEdBN0JXRCxpQkFBZTtBQUFBLFVBQ1BMLGFBS2JHLE9BQU87QUFBQTtBQUFBc0IsS0FORnBCO0FBQWUsSUFBQW9CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNMaXN0UGFnZSIsImNoZXF1ZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJDaGVxdWVzTGlzdFBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiaXNBcHBlbmRpbmciLCJlcnJvciIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJpdGVtIiwiYmFzZVJvdXRlIiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDaGVxdWVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgY2hlcXVlc01vZHVsZUNvbmZpZywgdHlwZSBSZWNlaXZlZENoZWNrIH0gZnJvbSAnLi4vY2hlcXVlcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0RGF0ZVJhbmdlJztcblxuZXhwb3J0IGNvbnN0IENoZXF1ZXNMaXN0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICBjb25zdCB7XG4gICAgICAgIHJlc3BvbnNlLCBsb2FkaW5nLCBpc0FwcGVuZGluZywgZXJyb3IsIGhhbmRsZVNvcnQsIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbiwgaGFuZGxlUGFnZUNoYW5nZSwgaGFuZGxlTG9hZE1vcmUsIGhhbmRsZVNlYXJjaCwgc2VhcmNoUGFyYW1zLFxuICAgIH0gPSB1c2VDcnVkPFJlY2VpdmVkQ2hlY2s+KGNoZXF1ZXNNb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxSZWNlaXZlZENoZWNrPlxuICAgICAgICAgICAgY29uZmlnPXtjaGVxdWVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJTdGFydD17c2VhcmNoUGFyYW1zLnN0YXJ0RGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJFbmQ9e3NlYXJjaFBhcmFtcy5lbmREYXRlID8/ICcnfVxuICAgICAgICAgICAgZW5hYmxlRGF0ZVJhbmdlRmlsdGVyPXt0cnVlfVxuICAgICAgICAgICAgb25Sb3dDbGljaz17KGl0ZW0pID0+IG5hdmlnYXRlKGAke2NoZXF1ZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlfS8ke2l0ZW0uaWR9YCl9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NoZXF1ZXMvcGFnZXMvQ2hlcXVlc0xpc3RQYWdlLnRzeCJ9