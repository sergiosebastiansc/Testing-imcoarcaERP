import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/pages/LoginPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/auth/pages/LoginPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useAuth } from "/src/hooks/useAuth.ts";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { AuthLayout } from "/src/features/auth/components/AuthLayout.tsx";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { useOrganization } from "/src/hooks/useOrganization.ts";
export const LoginPage = () => {
  _s();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const { refreshBranding } = useOrganization();
  const navigate = useNavigate();
  useEffect(() => {
    void refreshBranding();
  }, [refreshBranding]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login({ email, password });
      navigate("/dashboard");
    } catch (error) {
      const apiData = error && typeof error === "object" && "response" in error ? error.response?.data : void 0;
      let errorMessage = apiData?.message;
      if (!errorMessage && apiData?.errors) {
        const firstFieldErrors = Object.values(apiData.errors)[0];
        errorMessage = Array.isArray(firstFieldErrors) ? firstFieldErrors[0] : void 0;
      }
      toast.error(errorMessage || "Error al iniciar sesión.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(AuthLayout, { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", autoComplete: "off", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "email", className: "block text-sm font-medium text-gray-700", children: "Email" }, void 0, false, {
        fileName: "/app/src/features/auth/pages/LoginPage.tsx",
        lineNumber: 70,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: "email",
          type: "email",
          value: email,
          onChange: (e) => setEmail(e.target.value),
          required: true,
          autoComplete: "off",
          className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/auth/pages/LoginPage.tsx",
          lineNumber: 73,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/auth/pages/LoginPage.tsx",
      lineNumber: 69,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "password", className: "block text-sm font-medium text-gray-700", children: "Contraseña" }, void 0, false, {
        fileName: "/app/src/features/auth/pages/LoginPage.tsx",
        lineNumber: 84,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: "password",
          type: "password",
          value: password,
          onChange: (e) => setPassword(e.target.value),
          required: true,
          autoComplete: "off",
          className: "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/auth/pages/LoginPage.tsx",
          lineNumber: 87,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/auth/pages/LoginPage.tsx",
      lineNumber: 83,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-right", children: /* @__PURE__ */ jsxDEV(Link, { to: "/recuperar-password", className: "font-medium text-indigo-600 hover:text-indigo-500", children: "¿Olvidaste tu contraseña?" }, void 0, false, {
      fileName: "/app/src/features/auth/pages/LoginPage.tsx",
      lineNumber: 99,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/auth/pages/LoginPage.tsx",
      lineNumber: 98,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        disabled: loading,
        type: "submit",
        className: "w-full px-4 py-2 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
        children: loading ? "Ingresando..." : "Ingresar"
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/auth/pages/LoginPage.tsx",
        lineNumber: 104,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/features/auth/pages/LoginPage.tsx",
      lineNumber: 103,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/auth/pages/LoginPage.tsx",
    lineNumber: 68,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/features/auth/pages/LoginPage.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
};
_s(LoginPage, "+RAdNtgBh3gdWcpkjvvrjjcqDHw=", false, function() {
  return [useAuth, useOrganization, useNavigate];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/auth/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/auth/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsRHBCLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGFBQWFDLFlBQVk7QUFDbEMsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsdUJBQXVCO0FBRXpCLGFBQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVYsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ1csVUFBVUMsV0FBVyxJQUFJWixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDYSxTQUFTQyxVQUFVLElBQUlkLFNBQVMsS0FBSztBQUM1QyxRQUFNLEVBQUVlLE1BQU0sSUFBSWQsUUFBUTtBQUMxQixRQUFNLEVBQUVlLGdCQUFnQixJQUFJVixnQkFBZ0I7QUFDNUMsUUFBTVcsV0FBV2YsWUFBWTtBQUU3QkgsWUFBVSxNQUFNO0FBQ1osU0FBS2lCLGdCQUFnQjtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ0EsZUFBZSxDQUFDO0FBRXBCLFFBQU1FLGVBQWUsT0FBT0MsTUFBdUI7QUFDL0NBLE1BQUVDLGVBQWU7QUFDakJOLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxZQUFNQyxNQUFNLEVBQUVOLE9BQU9FLFNBQVMsQ0FBQztBQUMvQk0sZUFBUyxZQUFZO0FBQUEsSUFDekIsU0FBU0ksT0FBZ0I7QUFFckIsWUFBTUMsVUFDRkQsU0FDQSxPQUFPQSxVQUFVLFlBQ2pCLGNBQWNBLFFBQ1BBLE1BQ0lFLFVBQVVDLE9BQ2ZDO0FBRVYsVUFBSUMsZUFBZUosU0FBU0s7QUFDNUIsVUFBSSxDQUFDRCxnQkFBZ0JKLFNBQVNNLFFBQVE7QUFDbEMsY0FBTUMsbUJBQW1CQyxPQUFPQyxPQUFPVCxRQUFRTSxNQUFNLEVBQUUsQ0FBQztBQUN4REYsdUJBQWVNLE1BQU1DLFFBQVFKLGdCQUFnQixJQUFJQSxpQkFBaUIsQ0FBQyxJQUFJSjtBQUFBQSxNQUMzRTtBQUNBcEIsWUFBTWdCLE1BQU1LLGdCQUFnQiwwQkFBMEI7QUFBQSxJQUMxRCxVQUFDO0FBQ0daLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxTQUNJLHVCQUFDLGNBQ0csaUNBQUMsVUFBSyxVQUFVSSxjQUFjLFdBQVUsYUFBWSxjQUFhLE9BQzdEO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFdBQU0sU0FBUSxTQUFRLFdBQVUsMkNBQXlDLHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxJQUFHO0FBQUEsVUFDSCxNQUFLO0FBQUEsVUFDTCxPQUFPVDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ1UsTUFBTVQsU0FBU1MsRUFBRWUsT0FBT0MsS0FBSztBQUFBLFVBQ3hDO0FBQUEsVUFDQSxjQUFhO0FBQUEsVUFDYixXQUFVO0FBQUE7QUFBQSxRQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9rSjtBQUFBLFNBWHRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFdBQU0sU0FBUSxZQUFXLFdBQVUsMkNBQXlDLDBCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxJQUFHO0FBQUEsVUFDSCxNQUFLO0FBQUEsVUFDTCxPQUFPeEI7QUFBQUEsVUFDUCxVQUFVLENBQUNRLE1BQU1QLFlBQVlPLEVBQUVlLE9BQU9DLEtBQUs7QUFBQSxVQUMzQztBQUFBLFVBQ0EsY0FBYTtBQUFBLFVBQ2IsV0FBVTtBQUFBO0FBQUEsUUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPa0o7QUFBQSxTQVh0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDWCxpQ0FBQyxRQUFLLElBQUcsdUJBQXNCLFdBQVUscURBQW1ELHlDQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFNBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFVBQVV0QjtBQUFBQSxRQUNWLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUVUQSxvQkFBVSxrQkFBa0I7QUFBQTtBQUFBLE1BTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQSxLQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBO0FBRVI7QUFBRUwsR0F4RldELFdBQVM7QUFBQSxVQUlBTixTQUNVSyxpQkFDWEosV0FBVztBQUFBO0FBQUFrQyxLQU5uQjdCO0FBQVMsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlQXV0aCIsInVzZU5hdmlnYXRlIiwiTGluayIsIkF1dGhMYXlvdXQiLCJ0b2FzdCIsInVzZU9yZ2FuaXphdGlvbiIsIkxvZ2luUGFnZSIsIl9zIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImxvZ2luIiwicmVmcmVzaEJyYW5kaW5nIiwibmF2aWdhdGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJlcnJvciIsImFwaURhdGEiLCJyZXNwb25zZSIsImRhdGEiLCJ1bmRlZmluZWQiLCJlcnJvck1lc3NhZ2UiLCJtZXNzYWdlIiwiZXJyb3JzIiwiZmlyc3RGaWVsZEVycm9ycyIsIk9iamVjdCIsInZhbHVlcyIsIkFycmF5IiwiaXNBcnJheSIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9naW5QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VBdXRoJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7IC8vIEltcG9ydGFtb3MgTGlua1xuaW1wb3J0IHsgQXV0aExheW91dCB9IGZyb20gJy4uL2NvbXBvbmVudHMvQXV0aExheW91dCc7IC8vIEltcG9ydGFtb3MgbnVlc3RybyBudWV2byBMYXlvdXRcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgdXNlT3JnYW5pemF0aW9uIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlT3JnYW5pemF0aW9uJztcblxuZXhwb3J0IGNvbnN0IExvZ2luUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgeyBsb2dpbiB9ID0gdXNlQXV0aCgpO1xuICAgIGNvbnN0IHsgcmVmcmVzaEJyYW5kaW5nIH0gPSB1c2VPcmdhbml6YXRpb24oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB2b2lkIHJlZnJlc2hCcmFuZGluZygpO1xuICAgIH0sIFtyZWZyZXNoQnJhbmRpbmddKTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgbG9naW4oeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgICAgICAgICAgLy8gU2kgbGEgQVBJIGRldnVlbHZlIHVuIGVycm9yLCBsbyBtb3N0cmFtb3MgY29uIHVuIHRvYXN0XG4gICAgICAgICAgICBjb25zdCBhcGlEYXRhID1cbiAgICAgICAgICAgICAgICBlcnJvciAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBlcnJvciA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICAgICAgICAncmVzcG9uc2UnIGluIGVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gKGVycm9yIGFzIHsgcmVzcG9uc2U/OiB7IGRhdGE/OiB7IG1lc3NhZ2U/OiBzdHJpbmc7IGVycm9ycz86IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiB9IH0gfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlc3BvbnNlPy5kYXRhXG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuXG4gICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlID0gYXBpRGF0YT8ubWVzc2FnZTtcbiAgICAgICAgICAgIGlmICghZXJyb3JNZXNzYWdlICYmIGFwaURhdGE/LmVycm9ycykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpcnN0RmllbGRFcnJvcnMgPSBPYmplY3QudmFsdWVzKGFwaURhdGEuZXJyb3JzKVswXTtcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBBcnJheS5pc0FycmF5KGZpcnN0RmllbGRFcnJvcnMpID8gZmlyc3RGaWVsZEVycm9yc1swXSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRvYXN0LmVycm9yKGVycm9yTWVzc2FnZSB8fCAnRXJyb3IgYWwgaW5pY2lhciBzZXNpw7NuLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEF1dGhMYXlvdXQ+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBhdXRvQ29tcGxldGU9XCJvZmZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDb250cmFzZcOxYVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogRW5sYWNlIHBhcmEgcmVjdXBlcmFyIGNvbnRyYXNlw7FhICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlY3VwZXJhci1wYXNzd29yZFwiIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIMK/T2x2aWRhc3RlIHR1IGNvbnRyYXNlw7FhP1xuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgcm91bmRlZC1tZCBob3ZlcjpiZy1pbmRpZ28tNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/ICdJbmdyZXNhbmRvLi4uJyA6ICdJbmdyZXNhcid9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L0F1dGhMYXlvdXQgPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYXV0aC9wYWdlcy9Mb2dpblBhZ2UudHN4In0=