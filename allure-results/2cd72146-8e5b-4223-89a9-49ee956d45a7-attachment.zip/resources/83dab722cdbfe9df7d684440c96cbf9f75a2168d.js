import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { priceListsModuleConfig } from "/src/features/lista_precios/listas_precios.config.tsx";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
export const ListasDePreciosDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: priceList, loading, error } = useCrudItem(priceListsModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la lista: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 21
  }, this);
  if (!priceList) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró la lista de precios." }, void 0, false, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 26
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: priceListsModuleConfig, item: priceList }, void 0, false, {
      fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
      lineNumber: 39,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Items de la Lista de Precios" }, void 0, false, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
        lineNumber: 43,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Código Producto" }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
            lineNumber: 50,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nombre" }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
            lineNumber: 51,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Precio" }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
            lineNumber: 52,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
          lineNumber: 49,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
          lineNumber: 48,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
          (priceList.items || []).map(
            (item, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6", children: item.priceable_code }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
                lineNumber: 58,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: [
                item.priceable_name,
                " "
              ] }, void 0, true, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
                lineNumber: 61,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(item.price, "currency") }, void 0, false, {
                fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
                lineNumber: 64,
                columnNumber: 37
              }, this)
            ] }, item.id || item.priceable_id || index, true, {
              fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
              lineNumber: 57,
              columnNumber: 15
            }, this)
          ),
          (!priceList.items || priceList.items.length === 0) && /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 3, className: "px-6 py-4 text-center text-sm text-gray-500", children: "No hay ítems en esta lista." }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
            lineNumber: 71,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
            lineNumber: 70,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
          lineNumber: 55,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
        lineNumber: 47,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
        lineNumber: 46,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
      lineNumber: 42,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
};
_s(ListasDePreciosDetailPage, "cthh6W2rnlVueABYTf027BYjxk0=", false, function() {
  return [useParams, useCrudItem];
});
_c = ListasDePreciosDetailPage;
var _c;
$RefreshReg$(_c, "ListasDePreciosDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVh4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDhCQUE4QztBQUN2RCxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUVyQixhQUFNQyw0QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVIsVUFBMEI7QUFDekMsUUFBTSxFQUFFUyxNQUFNQyxXQUFXQyxTQUFTQyxNQUFNLElBQUlYLFlBQXVCQyx3QkFBd0JNLEVBQUU7QUFFN0YsTUFBSUcsUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUEyQkE7QUFBQUEsT0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErRDtBQUNqRixNQUFJLENBQUNGLFVBQVcsUUFBTyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLG1EQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThFO0FBRXJHLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGFBRVg7QUFBQSwyQkFBQyxxQkFBa0IsUUFBUVIsd0JBQXdCLE1BQU1RLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUduRSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0RBQWtELDRDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSwrQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxVQUN0Ryx1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHNCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSwyRUFBMEUsc0JBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsYUFIbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1hBO0FBQUFBLHFCQUFVRyxTQUFTLElBQUlDO0FBQUFBLFlBQUksQ0FBQ0wsTUFBTU0sVUFDaEMsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSw0REFDVE4sZUFBS08sa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNUUDtBQUFBQSxxQkFBS1E7QUFBQUEsZ0JBQWU7QUFBQSxtQkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLHVFQUNUWixzQkFBWUksS0FBS1MsT0FBTyxVQUFVLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFUS1QsS0FBS0QsTUFBTUMsS0FBS1UsZ0JBQWdCSixPQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsVUFDSDtBQUFBLFdBQ0MsQ0FBQ0wsVUFBVUcsU0FBU0gsVUFBVUcsTUFBTU8sV0FBVyxNQUM3Qyx1QkFBQyxRQUNHLGlDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsK0NBQThDLDJDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRyxLQUR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFqQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQTtBQUFBLFNBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ0E7QUFBQSxPQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUNBO0FBRVI7QUFBRWIsR0FwRFdELDJCQUF5QjtBQUFBLFVBQ25CTixXQUM2QkMsV0FBVztBQUFBO0FBQUFvQixLQUY5Q2Y7QUFBeUIsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZUNydWRJdGVtIiwicHJpY2VMaXN0c01vZHVsZUNvbmZpZyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiTG9hZGluZ1NwaW5uZXIiLCJmb3JtYXRWYWx1ZSIsIkxpc3Rhc0RlUHJlY2lvc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwiaXRlbSIsInByaWNlTGlzdCIsImxvYWRpbmciLCJlcnJvciIsIml0ZW1zIiwibWFwIiwiaW5kZXgiLCJwcmljZWFibGVfY29kZSIsInByaWNlYWJsZV9uYW1lIiwicHJpY2UiLCJwcmljZWFibGVfaWQiLCJsZW5ndGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMaXN0YXNQcmVjaW9zRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL21vZHVsZXMvbGlzdGFzX2RlX3ByZWNpb3MvcGFnZXMvTGlzdGFzRGVQcmVjaW9zRGV0YWlsUGFnZS50c3hcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBwcmljZUxpc3RzTW9kdWxlQ29uZmlnLCB0eXBlIFByaWNlTGlzdCB9IGZyb20gJy4uL2xpc3Rhc19wcmVjaW9zLmNvbmZpZyc7XG5pbXBvcnQgeyBHZW5lcmljRGV0YWlsUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNEZXRhaWxQYWdlJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuXG5leHBvcnQgY29uc3QgTGlzdGFzRGVQcmVjaW9zRGV0YWlsUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgeyBpdGVtOiBwcmljZUxpc3QsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxQcmljZUxpc3Q+KHByaWNlTGlzdHNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+RXJyb3IgYWwgY2FyZ2FyIGxhIGxpc3RhOiB7ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghcHJpY2VMaXN0KSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+Tm8gc2UgZW5jb250csOzIGxhIGxpc3RhIGRlIHByZWNpb3MuPC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIHsvKiBEZXRhbGxlcyBkZSBsYSBDYWJlY2VyYSAodXNhbmRvIEdlbmVyaWNEZXRhaWxQYWdlKSAqL31cbiAgICAgICAgICAgIDxHZW5lcmljRGV0YWlsUGFnZSBjb25maWc9e3ByaWNlTGlzdHNNb2R1bGVDb25maWd9IGl0ZW09e3ByaWNlTGlzdH0gLz5cblxuICAgICAgICAgICAgey8qIFNlY2Npw7NuIGRlIEl0ZW1zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02XCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDAgbWItNFwiPlxuICAgICAgICAgICAgICAgICAgICBJdGVtcyBkZSBsYSBMaXN0YSBkZSBQcmVjaW9zXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkPDs2RpZ28gUHJvZHVjdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Tm9tYnJlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC0zIHByLTQgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwci02XCI+UHJlY2lvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KHByaWNlTGlzdC5pdGVtcyB8fCBbXSkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkIHx8IGl0ZW0ucHJpY2VhYmxlX2lkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByaWNlYWJsZV9jb2RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHJpY2VhYmxlX25hbWV9IHsvKiBQb2Ryw61hbW9zIG1vc3RyYXIgYWxnbyBtw6FzIGFtaWdhYmxlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBzbTpwci02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGl0ZW0ucHJpY2UsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KCFwcmljZUxpc3QuaXRlbXMgfHwgcHJpY2VMaXN0Lml0ZW1zLmxlbmd0aCA9PT0gMCkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17M30gY2xhc3NOYW1lPVwicHgtNiBweS00IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSDDrXRlbXMgZW4gZXN0YSBsaXN0YS48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGlzdGFfcHJlY2lvcy9wYWdlcy9MaXN0YXNQcmVjaW9zRGV0YWlsUGFnZS50c3gifQ==