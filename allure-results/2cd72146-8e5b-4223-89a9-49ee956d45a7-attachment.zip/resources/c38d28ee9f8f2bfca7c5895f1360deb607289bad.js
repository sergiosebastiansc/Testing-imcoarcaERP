import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/LoadingSpinner.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/LoadingSpinner.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export const LoadingSpinner = ({ className }) => {
  const baseClasses = "border-4 border-dashed rounded-full animate-spin border-indigo-600";
  const combinedClasses = className ? `${baseClasses} ${className}` : `${baseClasses} w-8 h-8`;
  return /* @__PURE__ */ jsxDEV("div", { className: combinedClasses }, void 0, false, {
    fileName: "/app/src/components/ui/LoadingSpinner.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_c = LoadingSpinner;
var _c;
$RefreshReg$(_c, "LoadingSpinner");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/LoadingSpinner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/LoadingSpinner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWRCxhQUFNQSxpQkFBaUJBLENBQUMsRUFBRUMsVUFBaUIsTUFBTTtBQUVwRCxRQUFNQyxjQUFjO0FBSXBCLFFBQU1DLGtCQUFrQkYsWUFBWSxHQUFHQyxXQUFXLElBQUlELFNBQVMsS0FBSyxHQUFHQyxXQUFXO0FBR2xGLFNBQ0ksdUJBQUMsU0FBSSxXQUFXQyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpQztBQUV6QztBQUFFQyxLQVpXSjtBQUFjLElBQUFJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMb2FkaW5nU3Bpbm5lciIsImNsYXNzTmFtZSIsImJhc2VDbGFzc2VzIiwiY29tYmluZWRDbGFzc2VzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9hZGluZ1NwaW5uZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBQcm9wcyB7XG4gICAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgTG9hZGluZ1NwaW5uZXIgPSAoeyBjbGFzc05hbWUgfTogUHJvcHMpID0+IHtcbiAgICAvLyAyLiBEZWZpbmltb3MgbGFzIGNsYXNlcyBiYXNlIGRlbCBzcGlubmVyLlxuICAgIGNvbnN0IGJhc2VDbGFzc2VzID0gXCJib3JkZXItNCBib3JkZXItZGFzaGVkIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gYm9yZGVyLWluZGlnby02MDBcIjtcblxuICAgIC8vIDMuIENvbWJpbmFtb3MgbGFzIGNsYXNlcyBiYXNlIGNvbiBlbCBjbGFzc05hbWUgcXVlIHNlIGxlIHBhc2EuXG4gICAgLy8gICAgU2kgbm8gc2UgcGFzYSB1biBjbGFzc05hbWUsIHVzYW1vcyB1biB0YW1hw7FvIHBvciBkZWZlY3RvICh3LTggaC04KS5cbiAgICBjb25zdCBjb21iaW5lZENsYXNzZXMgPSBjbGFzc05hbWUgPyBgJHtiYXNlQ2xhc3Nlc30gJHtjbGFzc05hbWV9YCA6IGAke2Jhc2VDbGFzc2VzfSB3LTggaC04YDtcblxuICAgIC8vIDQuIEVsaW1pbmFtb3MgZWwgZGl2IGV4dGVyaW9yIHkgZGV2b2x2ZW1vcyBzb2xvIGVsIHNwaW5uZXIuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NvbWJpbmVkQ2xhc3Nlc30+PC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyLnRzeCJ9