import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { notasFinancierasCompraModuleConfig } from "/src/features/notas_financieras_compra/notas_financieras_compra.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { formatTaxRateCell, getAppliedTaxDisplayName } from "/src/utils/taxDisplay.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) return 0;
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const NotasFinancierasCompraDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: note, loading, error } = useCrudItem(notasFinancierasCompraModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const calculatedTotals = useMemo(() => {
    if (!note || !note.items?.length) return { subtotal: 0, totalTaxes: 0 };
    let subtotal = 0;
    for (const item of note.items) {
      subtotal += Number(item.quantity) * Number(item.unit_price);
    }
    let totalTaxes = 0;
    if (note.has_item_level_taxes) {
      totalTaxes = note.items.reduce((sum, item) => sum + getItemTaxTotal(item), 0);
    } else {
      totalTaxes = (note.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
    }
    return { subtotal, totalTaxes };
  }, [note]);
  const aggregatedTaxes = useMemo(() => {
    if (!note) return [];
    const items = note.items || [];
    if (note.has_item_level_taxes && items.length > 0) {
      const map = /* @__PURE__ */ new Map();
      for (const item of items) {
        for (const t of item.taxes || []) {
          const key = t.tax_id;
          if (!map.has(key)) {
            map.set(key, {
              tax_id: t.tax_id,
              tax_name: t.tax_name,
              tax_type: t.tax_type,
              tax_type_label: t.tax_type_label,
              tax: t.tax,
              rate: t.rate,
              amount: 0
            });
          }
          const row = map.get(key);
          row.amount += Number(t.amount);
        }
      }
      return Array.from(map.values());
    }
    return (note.taxes || []).map((t) => ({
      tax_id: t.tax_id,
      tax_name: t.tax_name,
      tax_type: t.tax_type,
      tax_type_label: t.tax_type_label,
      tax: t.tax,
      rate: t.rate,
      amount: Number(t.amount)
    }));
  }, [note]);
  const handlePrint = async () => {
    if (!note) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/purchase-financial-notes/${note.id}/pdf`);
    } catch (err) {
      if (!session.window.closed) session.window.close();
      console.error(err);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
    lineNumber: 117,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la nota financiera: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
    lineNumber: 118,
    columnNumber: 21
  }, this);
  if (!note) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el documento." }, void 0, false, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
    lineNumber: 119,
    columnNumber: 21
  }, this);
  const isDebit = note.type === "DEBIT";
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(notasFinancierasCompraModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 130,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 129,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "NF Compra: ",
            note.series ? `${note.series}-` : "",
            note.voucher_number
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 133,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${isDebit ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`, children: isDebit ? "Débito" : "Crédito" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 134,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 132,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 128,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handlePrint,
          disabled: isPrinting,
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
          children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 146,
            columnNumber: 39
          }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 146,
            columnNumber: 88
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 140,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 139,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
      lineNumber: 127,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Proveedor" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 153,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: /* @__PURE__ */ jsxDEV(Link, { to: `/proveedores/${note.vendor_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: note.vendor?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 155,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 154,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 152,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Nº de Factura" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.purchase_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/compras/${note.purchase_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: note.purchase?.document_number || `ID: ${note.purchase_id}` }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 164,
          columnNumber: 13
        }, this) : "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 162,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 160,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Serie" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 171,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.series || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 172,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 170,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 175,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatValue(note.issue_date, "date") }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 176,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 174,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 179,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.currency?.name ?? note.currency?.currency_name ?? "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 180,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 178,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Concepto" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 183,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: note.concept || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 184,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 182,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
      lineNumber: 151,
      columnNumber: 13
    }, this),
    note.items && note.items.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Ítems" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 190,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Descripción" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 195,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Código" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 196,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 197,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 198,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 199,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 200,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 194,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 193,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: note.items.map((item, index) => {
          const lineSub = Number(item.quantity) * Number(item.unit_price);
          const itemTax = note.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSub + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6 font-medium text-gray-900", children: item.description }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 210,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.concept_code }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 211,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 212,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 213,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSub, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 214,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 215,
              columnNumber: 45
            }, this)
          ] }, item.id ?? index, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 209,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 203,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 192,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 191,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
      lineNumber: 189,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 p-4 border rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Impuestos aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 227,
          columnNumber: 21
        }, this),
        aggregatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 233,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 234,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 235,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 232,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 231,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: aggregatedTaxes.map(
            (tax, idx) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: getAppliedTaxDisplayName(tax) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
                lineNumber: 241,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatTaxRateCell(tax) }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
                lineNumber: 242,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
                lineNumber: 243,
                columnNumber: 45
              }, this)
            ] }, tax.tax_id ?? idx, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 240,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 238,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 230,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 229,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-gray-500", children: "No hay impuestos aplicados en esta nota." }, void 0, false, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 250,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 226,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 rounded-lg space-y-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 255,
              columnNumber: 76
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 255,
              columnNumber: 126
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 255,
            columnNumber: 25
          }, this),
          (note.withouttax_amount ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center text-red-600", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Valor No Gravado:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 257,
              columnNumber: 77
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "- ",
              formatValue(note.withouttax_amount, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 257,
              columnNumber: 135
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 257,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Impuestos:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 259,
              columnNumber: 76
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 259,
              columnNumber: 127
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 259,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 260,
              columnNumber: 95
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-lg font-bold text-indigo-600`, children: formatValue(note.total_amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
              lineNumber: 260,
              columnNumber: 169
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 260,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 254,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 263,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900 whitespace-pre-wrap", children: note.notes || "-" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
            lineNumber: 264,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
          lineNumber: 262,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
        lineNumber: 253,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
      lineNumber: 225,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx",
    lineNumber: 126,
    columnNumber: 5
  }, this);
};
_s(NotasFinancierasCompraDetailPage, "69cmju0yomXyJadVjPaMAOahG2Q=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = NotasFinancierasCompraDetailPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasCompraDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUd3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqR3hCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywwQ0FBc0c7QUFDL0csU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLGVBQWU7QUFDckMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxtQkFBbUJDLGdDQUFnQztBQUU1RCxTQUFTQyxpQkFBaUJDLHdCQUF3QjtBQUNsRCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHlCQUF5QjtBQUVsQyxNQUFNQyxrQkFBa0JBLENBQUNDLFNBQW9DO0FBQ3pELE1BQUksQ0FBQ0EsS0FBS0MsU0FBU0QsS0FBS0MsTUFBTUMsV0FBVyxFQUFHLFFBQU87QUFDbkQsU0FBT0YsS0FBS0MsTUFBTUUsT0FBTyxDQUFDQyxLQUFLQyxRQUFRRCxNQUFNRSxPQUFPRCxJQUFJRSxNQUFNLEdBQUcsQ0FBQztBQUN0RTtBQUVPLGFBQU1DLG1DQUFtQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2xELFFBQU0sRUFBRUMsR0FBRyxJQUFJN0IsVUFBMEI7QUFDekMsUUFBTThCLFdBQVc3QixZQUFZO0FBQzdCLFFBQU0sRUFBRWtCLE1BQU1ZLE1BQU1DLFNBQVNDLE1BQU0sSUFBSTVCLFlBQW1DQyxvQ0FBb0N1QixFQUFFO0FBQ2hILFFBQU0sQ0FBQ0ssWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxLQUFLO0FBRWxELFFBQU1nQyxtQkFBbUJqQyxRQUFRLE1BQU07QUFDbkMsUUFBSSxDQUFDNEIsUUFBUSxDQUFDQSxLQUFLTSxPQUFPaEIsT0FBUSxRQUFPLEVBQUVpQixVQUFVLEdBQUdDLFlBQVksRUFBRTtBQUN0RSxRQUFJRCxXQUFXO0FBQ2YsZUFBV25CLFFBQVFZLEtBQUtNLE9BQU87QUFDM0JDLGtCQUFZYixPQUFPTixLQUFLcUIsUUFBUSxJQUFJZixPQUFPTixLQUFLc0IsVUFBVTtBQUFBLElBQzlEO0FBQ0EsUUFBSUYsYUFBYTtBQUNqQixRQUFJUixLQUFLVyxzQkFBc0I7QUFDM0JILG1CQUFhUixLQUFLTSxNQUFNZixPQUFPLENBQUNDLEtBQUtKLFNBQVNJLE1BQU1MLGdCQUFnQkMsSUFBSSxHQUFHLENBQUM7QUFBQSxJQUNoRixPQUFPO0FBQ0hvQixvQkFBY1IsS0FBS1gsU0FBUyxJQUFJRSxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU1FLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQUEsSUFDcEY7QUFDQSxXQUFPLEVBQUVZLFVBQVVDLFdBQVc7QUFBQSxFQUNsQyxHQUFHLENBQUNSLElBQUksQ0FBQztBQUVULFFBQU1ZLGtCQUFrQnhDLFFBQVEsTUFBb0I7QUFDaEQsUUFBSSxDQUFDNEIsS0FBTSxRQUFPO0FBQ2xCLFVBQU1NLFFBQVFOLEtBQUtNLFNBQVM7QUFDNUIsUUFBSU4sS0FBS1csd0JBQXdCTCxNQUFNaEIsU0FBUyxHQUFHO0FBQy9DLFlBQU11QixNQUFNLG9CQUFJQyxJQUF3QjtBQUN4QyxpQkFBVzFCLFFBQVFrQixPQUFPO0FBQ3RCLG1CQUFXUyxLQUFLM0IsS0FBS0MsU0FBUyxJQUFJO0FBQzlCLGdCQUFNMkIsTUFBTUQsRUFBRUU7QUFDZCxjQUFJLENBQUNKLElBQUlLLElBQUlGLEdBQUcsR0FBRztBQUNmSCxnQkFBSU0sSUFBSUgsS0FBSztBQUFBLGNBQ1RDLFFBQVFGLEVBQUVFO0FBQUFBLGNBQ1ZHLFVBQVVMLEVBQUVLO0FBQUFBLGNBQ1pDLFVBQVVOLEVBQUVNO0FBQUFBLGNBQ1pDLGdCQUFnQlAsRUFBRU87QUFBQUEsY0FDbEI3QixLQUFLc0IsRUFBRXRCO0FBQUFBLGNBQ1A4QixNQUFNUixFQUFFUTtBQUFBQSxjQUNSNUIsUUFBUTtBQUFBLFlBQ1osQ0FBQztBQUFBLFVBQ0w7QUFDQSxnQkFBTTZCLE1BQU1YLElBQUlZLElBQUlULEdBQUc7QUFDdkJRLGNBQUk3QixVQUFVRCxPQUFPcUIsRUFBRXBCLE1BQU07QUFBQSxRQUNqQztBQUFBLE1BQ0o7QUFDQSxhQUFPK0IsTUFBTUMsS0FBS2QsSUFBSWUsT0FBTyxDQUFDO0FBQUEsSUFDbEM7QUFDQSxZQUFRNUIsS0FBS1gsU0FBUyxJQUFJd0IsSUFBSSxDQUFBRSxPQUFNO0FBQUEsTUFDaENFLFFBQVFGLEVBQUVFO0FBQUFBLE1BQ1ZHLFVBQVVMLEVBQUVLO0FBQUFBLE1BQ1pDLFVBQVVOLEVBQUVNO0FBQUFBLE1BQ1pDLGdCQUFnQlAsRUFBRU87QUFBQUEsTUFDbEI3QixLQUFLc0IsRUFBRXRCO0FBQUFBLE1BQ1A4QixNQUFNUixFQUFFUTtBQUFBQSxNQUNSNUIsUUFBUUQsT0FBT3FCLEVBQUVwQixNQUFNO0FBQUEsSUFDM0IsRUFBRTtBQUFBLEVBQ04sR0FBRyxDQUFDSyxJQUFJLENBQUM7QUFFVCxRQUFNNkIsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQzdCLEtBQU07QUFFWCxVQUFNOEIsVUFBVS9DLGdCQUFnQjtBQUNoQyxRQUFJLENBQUMrQyxTQUFTO0FBQ1Y3QyxZQUFNaUIsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFFLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNBLFlBQU1wQixpQkFBaUI4QyxTQUFTLDZCQUE2QjlCLEtBQUtGLEVBQUUsTUFBTTtBQUFBLElBQzlFLFNBQVNpQyxLQUFLO0FBQ1YsVUFBSSxDQUFDRCxRQUFRRSxPQUFPQyxPQUFRSCxTQUFRRSxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFRakMsTUFBTTZCLEdBQUc7QUFDakI5QyxZQUFNaUIsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dFLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFFQSxNQUFJSCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLElBQXFDQTtBQUFBQSxPQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1GO0FBQ3JHLE1BQUksQ0FBQ0YsS0FBTSxRQUFPLHVCQUFDLFNBQUksV0FBVSw2QkFBNEIsNENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUU7QUFFekYsUUFBTW9DLFVBQVVwQyxLQUFLcUMsU0FBUztBQUM5QixRQUFNQyxrQkFBa0I7QUFDeEIsUUFBTUMsa0JBQWtCO0FBRXhCLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHNEQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlFQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtCQUNYO0FBQUEsK0JBQUMsWUFBTyxTQUFTLE1BQU14QyxTQUFTYixrQkFBa0JYLG1DQUFtQ2lFLFNBQVMsQ0FBQyxHQUFHLFdBQVUsb0RBQ3hHLGlDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxpREFBZ0Q7QUFBQTtBQUFBLFlBQVl4QyxLQUFLeUMsU0FBUyxHQUFHekMsS0FBS3lDLE1BQU0sTUFBTTtBQUFBLFlBQUl6QyxLQUFLMEM7QUFBQUEsZUFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0k7QUFBQSxVQUNwSSx1QkFBQyxVQUFLLFdBQVcsdURBQXVETixVQUFVLDRCQUE0Qiw2QkFBNkIsSUFDdElBLG9CQUFVLFdBQVcsYUFEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDWDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBU1A7QUFBQUEsVUFDVCxVQUFVMUI7QUFBQUEsVUFDVixXQUFVO0FBQUEsVUFFVEEsdUJBQWEsdUJBQUMsYUFBVSxXQUFVLDBCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxJQUFNLHVCQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBO0FBQUEsUUFOL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsa0VBQ1Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdtQyxpQkFBaUIseUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1YsaUNBQUMsUUFBSyxJQUFJLGdCQUFnQnRDLEtBQUsyQyxTQUFTLElBQUksV0FBVSx5REFDakQzQyxlQUFLNEMsUUFBUUMsUUFBUSxTQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXUCxpQkFBaUIsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1R0QyxlQUFLOEMsY0FDRix1QkFBQyxRQUFLLElBQUksWUFBWTlDLEtBQUs4QyxXQUFXLElBQUksV0FBVSx5REFDL0M5QyxlQUFLK0MsVUFBVUMsbUJBQW1CLE9BQU9oRCxLQUFLOEMsV0FBVyxNQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDQSxPQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdSLGlCQUFpQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0N0QyxlQUFLeUMsVUFBVSxPQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsV0FGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdILGlCQUFpQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQzdDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0MxRCxzQkFBWW9CLEtBQUtpRCxZQUFZLE1BQU0sS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFdBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXWCxpQkFBaUIsc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDdEMsZUFBS2tELFVBQVVMLFFBQVE3QyxLQUFLa0QsVUFBVUMsaUJBQWlCLE9BQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxXQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2IsaUJBQWlCLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ3RDLGVBQUtvRCxXQUFXLE9BQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxXQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsSUFFQ3BELEtBQUtNLFNBQVNOLEtBQUtNLE1BQU1oQixTQUFTLEtBQy9CLHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUsK0NBQThDLHFCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsU0FBSSxXQUFVLDJFQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLDJCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRztBQUFBLFVBQ2xHLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsc0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsUUFBRyxXQUFVLDJFQUEwRSwyQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQU52RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWlUsZUFBS00sTUFBTU8sSUFBSSxDQUFDekIsTUFBTWlFLFVBQVU7QUFDN0IsZ0JBQU1DLFVBQVU1RCxPQUFPTixLQUFLcUIsUUFBUSxJQUFJZixPQUFPTixLQUFLc0IsVUFBVTtBQUM5RCxnQkFBTTZDLFVBQVV2RCxLQUFLVyx1QkFBdUJ4QixnQkFBZ0JDLElBQUksSUFBSTtBQUNwRSxnQkFBTW9FLFlBQVlGLFVBQVVDO0FBQzVCLGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNERBQTREbkUsZUFBS3FFLGVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJGO0FBQUEsWUFDM0YsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ3JFLGVBQUtzRSxnQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRSx1QkFBQyxRQUFHLFdBQVUsOENBQThDaEUsaUJBQU9OLEtBQUtxQixRQUFRLEVBQUVrRCxRQUFRLENBQUMsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxZQUM3Rix1QkFBQyxRQUFHLFdBQVUsOENBQThDL0Usc0JBQVlRLEtBQUtzQixZQUFZLFVBQVUsS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUc7QUFBQSxZQUNyRyx1QkFBQyxRQUFHLFdBQVUsOENBQThDOUIsc0JBQVkwRSxTQUFTLFVBQVUsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxZQUM3Rix1QkFBQyxRQUFHLFdBQVUsdUVBQXVFMUUsc0JBQVk0RSxXQUFXLFVBQVUsS0FBdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxlQU5uSHBFLEtBQUtVLE1BQU11RCxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsUUFFUixDQUFDLEtBZkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFdBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkEsS0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQTtBQUFBLFNBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0E7QUFBQSxJQUdKLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUNwRXpDLGdCQUFnQnRCLFNBQVMsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLHlFQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLHdCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRjtBQUFBLFlBQy9GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsWUFDbkYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxlQUhwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNac0IsMEJBQWdCQztBQUFBQSxZQUFJLENBQUNwQixLQUFLbUUsUUFDdkIsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSw4Q0FBOEM5RSxtQ0FBeUJXLEdBQUcsS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEY7QUFBQSxjQUMxRix1QkFBQyxRQUFHLFdBQVUsOENBQThDWiw0QkFBa0JZLEdBQUcsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxjQUNuRix1QkFBQyxRQUFHLFdBQVUsOENBQThDYixzQkFBWWEsSUFBSUUsUUFBUSxVQUFVLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdHO0FBQUEsaUJBSDNGRixJQUFJd0IsVUFBVTJDLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxVQUNILEtBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkEsS0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsd0RBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxXQXhCMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLG1DQUFDLFVBQUssV0FBV3RCLGlCQUFpQix5QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBV0MsaUJBQWtCM0Qsc0JBQVl5QixpQkFBaUJFLFVBQVUsVUFBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBQTNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtNO0FBQUEsV0FDaE1QLEtBQUs2RCxxQkFBcUIsS0FBSyxLQUM3Qix1QkFBQyxTQUFJLFdBQVUsa0RBQWlEO0FBQUEsbUNBQUMsVUFBSyxXQUFXdkIsaUJBQWlCLGlDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLGNBQUczRCxZQUFZb0IsS0FBSzZELG1CQUFvQixVQUFVO0FBQUEsaUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsZUFBaE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdU47QUFBQSxVQUUzTix1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUEsbUNBQUMsVUFBSyxXQUFXdkIsaUJBQWlCLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLGNBQUczRCxZQUFZeUIsaUJBQWlCRyxZQUFZLFVBQVU7QUFBQSxpQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxlQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1TTtBQUFBLFVBQ3ZNLHVCQUFDLFNBQUksV0FBVSx3REFBdUQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsR0FBRzhCLGVBQWUsMEJBQTBCLHNCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGVBQWUsc0NBQXVDM0Qsc0JBQVlvQixLQUFLOEQsY0FBYyxVQUFVLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFIO0FBQUEsZUFBclE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNFE7QUFBQSxhQU5oUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVd4QixpQkFBaUIscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFDckMsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRHRDLGVBQUsrRCxTQUFTLE9BQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsYUFGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsT0E3SUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThJQTtBQUVSO0FBQUVsRSxHQXZPV0Qsa0NBQWdDO0FBQUEsVUFDMUIzQixXQUNFQyxhQUNzQkksV0FBVztBQUFBO0FBQUEwRixLQUh6Q3BFO0FBQWdDLElBQUFvRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlQ3J1ZEl0ZW0iLCJub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJJb0Fycm93QmFjayIsIklvUHJpbnQiLCJGYVNwaW5uZXIiLCJmb3JtYXRWYWx1ZSIsImZvcm1hdFRheFJhdGVDZWxsIiwiZ2V0QXBwbGllZFRheERpc3BsYXlOYW1lIiwiYmVnaW5QZGZQcmV2aWV3IiwiZmluaXNoUGRmUHJldmlldyIsInRvYXN0IiwiZ2V0TGlzdFJldHVyblBhdGgiLCJnZXRJdGVtVGF4VG90YWwiLCJpdGVtIiwidGF4ZXMiLCJsZW5ndGgiLCJyZWR1Y2UiLCJzdW0iLCJ0YXgiLCJOdW1iZXIiLCJhbW91bnQiLCJOb3Rhc0ZpbmFuY2llcmFzQ29tcHJhRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIm5vdGUiLCJsb2FkaW5nIiwiZXJyb3IiLCJpc1ByaW50aW5nIiwic2V0SXNQcmludGluZyIsImNhbGN1bGF0ZWRUb3RhbHMiLCJpdGVtcyIsInN1YnRvdGFsIiwidG90YWxUYXhlcyIsInF1YW50aXR5IiwidW5pdF9wcmljZSIsImhhc19pdGVtX2xldmVsX3RheGVzIiwiYWdncmVnYXRlZFRheGVzIiwibWFwIiwiTWFwIiwidCIsImtleSIsInRheF9pZCIsImhhcyIsInNldCIsInRheF9uYW1lIiwidGF4X3R5cGUiLCJ0YXhfdHlwZV9sYWJlbCIsInJhdGUiLCJyb3ciLCJnZXQiLCJBcnJheSIsImZyb20iLCJ2YWx1ZXMiLCJoYW5kbGVQcmludCIsInNlc3Npb24iLCJlcnIiLCJ3aW5kb3ciLCJjbG9zZWQiLCJjbG9zZSIsImNvbnNvbGUiLCJpc0RlYml0IiwidHlwZSIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsImJhc2VSb3V0ZSIsInNlcmllcyIsInZvdWNoZXJfbnVtYmVyIiwidmVuZG9yX2lkIiwidmVuZG9yIiwibmFtZSIsInB1cmNoYXNlX2lkIiwicHVyY2hhc2UiLCJkb2N1bWVudF9udW1iZXIiLCJpc3N1ZV9kYXRlIiwiY3VycmVuY3kiLCJjdXJyZW5jeV9uYW1lIiwiY29uY2VwdCIsImluZGV4IiwibGluZVN1YiIsIml0ZW1UYXgiLCJsaW5lVG90YWwiLCJkZXNjcmlwdGlvbiIsImNvbmNlcHRfY29kZSIsInRvRml4ZWQiLCJpZHgiLCJ3aXRob3V0dGF4X2Ftb3VudCIsInRvdGFsX2Ftb3VudCIsIm5vdGVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90YXNGaW5hbmNpZXJhc0NvbXByYURldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnLCB0eXBlIFB1cmNoYXNlRmluYW5jaWFsTm90ZSwgdHlwZSBQdXJjaGFzZUZpbmFuY2lhbE5vdGVJdGVtIH0gZnJvbSAnLi4vbm90YXNfZmluYW5jaWVyYXNfY29tcHJhLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2ssIElvUHJpbnQgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgRmFTcGlubmVyIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IGZvcm1hdFRheFJhdGVDZWxsLCBnZXRBcHBsaWVkVGF4RGlzcGxheU5hbWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy90YXhEaXNwbGF5JztcbmltcG9ydCB0eXBlIHsgQXBwbGllZFRheCB9IGZyb20gJy4uLy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQgeyBiZWdpblBkZlByZXZpZXcsIGZpbmlzaFBkZlByZXZpZXcgfSBmcm9tICcuLi8uLi8uLi91dGlscy9ibG9iSGVscGVyJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmNvbnN0IGdldEl0ZW1UYXhUb3RhbCA9IChpdGVtOiBQdXJjaGFzZUZpbmFuY2lhbE5vdGVJdGVtKSA9PiB7XG4gICAgaWYgKCFpdGVtLnRheGVzIHx8IGl0ZW0udGF4ZXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgICByZXR1cm4gaXRlbS50YXhlcy5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xufTtcblxuZXhwb3J0IGNvbnN0IE5vdGFzRmluYW5jaWVyYXNDb21wcmFEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBpdGVtOiBub3RlLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08UHVyY2hhc2VGaW5hbmNpYWxOb3RlPihub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgW2lzUHJpbnRpbmcsIHNldElzUHJpbnRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgY2FsY3VsYXRlZFRvdGFscyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIW5vdGUgfHwgIW5vdGUuaXRlbXM/Lmxlbmd0aCkgcmV0dXJuIHsgc3VidG90YWw6IDAsIHRvdGFsVGF4ZXM6IDAgfTtcbiAgICAgICAgbGV0IHN1YnRvdGFsID0gMDtcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIG5vdGUuaXRlbXMpIHtcbiAgICAgICAgICAgIHN1YnRvdGFsICs9IE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpO1xuICAgICAgICB9XG4gICAgICAgIGxldCB0b3RhbFRheGVzID0gMDtcbiAgICAgICAgaWYgKG5vdGUuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMpIHtcbiAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBub3RlLml0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyBnZXRJdGVtVGF4VG90YWwoaXRlbSksIDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdG90YWxUYXhlcyA9IChub3RlLnRheGVzIHx8IFtdKS5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbFRheGVzIH07XG4gICAgfSwgW25vdGVdKTtcblxuICAgIGNvbnN0IGFnZ3JlZ2F0ZWRUYXhlcyA9IHVzZU1lbW8oKCk6IEFwcGxpZWRUYXhbXSA9PiB7XG4gICAgICAgIGlmICghbm90ZSkgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBpdGVtcyA9IG5vdGUuaXRlbXMgfHwgW107XG4gICAgICAgIGlmIChub3RlLmhhc19pdGVtX2xldmVsX3RheGVzICYmIGl0ZW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8bnVtYmVyLCBBcHBsaWVkVGF4PigpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB0IG9mIGl0ZW0udGF4ZXMgfHwgW10pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5ID0gdC50YXhfaWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghbWFwLmhhcyhrZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXAuc2V0KGtleSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRheF9pZDogdC50YXhfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X25hbWU6IHQudGF4X25hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X3R5cGU6IHQudGF4X3R5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4X3R5cGVfbGFiZWw6IHQudGF4X3R5cGVfbGFiZWwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4OiB0LnRheCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93ID0gbWFwLmdldChrZXkpITtcbiAgICAgICAgICAgICAgICAgICAgcm93LmFtb3VudCArPSBOdW1iZXIodC5hbW91bnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKG1hcC52YWx1ZXMoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIChub3RlLnRheGVzIHx8IFtdKS5tYXAodCA9PiAoe1xuICAgICAgICAgICAgdGF4X2lkOiB0LnRheF9pZCxcbiAgICAgICAgICAgIHRheF9uYW1lOiB0LnRheF9uYW1lLFxuICAgICAgICAgICAgdGF4X3R5cGU6IHQudGF4X3R5cGUsXG4gICAgICAgICAgICB0YXhfdHlwZV9sYWJlbDogdC50YXhfdHlwZV9sYWJlbCxcbiAgICAgICAgICAgIHRheDogdC50YXgsXG4gICAgICAgICAgICByYXRlOiB0LnJhdGUsXG4gICAgICAgICAgICBhbW91bnQ6IE51bWJlcih0LmFtb3VudCksXG4gICAgICAgIH0pKTtcbiAgICB9LCBbbm90ZV0pO1xuXG4gICAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghbm90ZSkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBiZWdpblBkZlByZXZpZXcoKTtcbiAgICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGVybWl0w60gdmVudGFuYXMgZW1lcmdlbnRlcyBwYXJhIHZlciBlbCBQREYuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc1ByaW50aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZmluaXNoUGRmUHJldmlldyhzZXNzaW9uLCBgL3B1cmNoYXNlLWZpbmFuY2lhbC1ub3Rlcy8ke25vdGUuaWR9L3BkZmApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCBjb21wcm9iYW50ZSBQREYuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1ByaW50aW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBsYSBub3RhIGZpbmFuY2llcmE6IHtlcnJvciBhcyBzdHJpbmd9PC9kaXY+O1xuICAgIGlmICghbm90ZSkgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPk5vIHNlIGVuY29udHLDsyBlbCBkb2N1bWVudG8uPC9kaXY+O1xuXG4gICAgY29uc3QgaXNEZWJpdCA9IG5vdGUudHlwZSA9PT0gJ0RFQklUJztcbiAgICBjb25zdCB0b3RhbExhYmVsU3R5bGUgPSBcInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiO1xuICAgIGNvbnN0IHRvdGFsVmFsdWVTdHlsZSA9IFwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdGV4dC1yaWdodFwiO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktOFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IG1iLTQgYm9yZGVyLWIgc206ZmxleCBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1ncmF5LTUwMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+TkYgQ29tcHJhOiB7bm90ZS5zZXJpZXMgPyBgJHtub3RlLnNlcmllc30tYCA6ICcnfXtub3RlLnZvdWNoZXJfbnVtYmVyfTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BtdC0xIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtpc0RlYml0ID8gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJyA6ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0RlYml0ID8gJ0TDqWJpdG8nIDogJ0Nyw6lkaXRvJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNtOm10LTAgc206bWwtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByaW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJpbnRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itd2FpdFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ByaW50aW5nID8gPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+IDogPElvUHJpbnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAteC00IGdhcC15LTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Qcm92ZWVkb3I8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2AvcHJvdmVlZG9yZXMvJHtub3RlLnZlbmRvcl9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlLnZlbmRvcj8ubmFtZSB8fCAnTi9BJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5OwrogZGUgRmFjdHVyYTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5wdXJjaGFzZV9pZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9jb21wcmFzLyR7bm90ZS5wdXJjaGFzZV9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS5wdXJjaGFzZT8uZG9jdW1lbnRfbnVtYmVyIHx8IGBJRDogJHtub3RlLnB1cmNoYXNlX2lkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6ICctJ31cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TZXJpZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e25vdGUuc2VyaWVzIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIEVtaXNpw7NuPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+TW9uZWRhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57bm90ZS5jdXJyZW5jeT8ubmFtZSA/PyBub3RlLmN1cnJlbmN5Py5jdXJyZW5jeV9uYW1lID8/ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkNvbmNlcHRvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57bm90ZS5jb25jZXB0IHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kbD5cblxuICAgICAgICAgICAge25vdGUuaXRlbXMgJiYgbm90ZS5pdGVtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPsONdGVtczwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+RGVzY3JpcGNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Dw7NkaWdvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q2FudC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtMyBwci00IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cHItNlwiPlRvdGFsIEzDrW5lYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlLml0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWIgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXggPSBub3RlLmhhc19pdGVtX2xldmVsX3RheGVzID8gZ2V0SXRlbVRheFRvdGFsKGl0ZW0pIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWIgKyBpdGVtVGF4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkID8/IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gc206cGwtNiBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e2l0ZW0uZGVzY3JpcHRpb259PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57aXRlbS5jb25jZXB0X2NvZGV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntOdW1iZXIoaXRlbS5xdWFudGl0eSkudG9GaXhlZCgyKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGl0ZW0udW5pdF9wcmljZSwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShsaW5lU3ViLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC0zIHByLTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgc206cHItNlwiPntmb3JtYXRWYWx1ZShsaW5lVG90YWwsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIHAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIGFwbGljYWRvczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIHthZ2dyZWdhdGVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5JbXB1ZXN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5UYXNhICglKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdncmVnYXRlZFRheGVzLm1hcCgodGF4LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0YXgudGF4X2lkID8/IGlkeH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNtOnBsLTZcIj57Z2V0QXBwbGllZFRheERpc3BsYXlOYW1lKHRheCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRUYXhSYXRlQ2VsbCh0YXgpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBoYXkgaW1wdWVzdG9zIGFwbGljYWRvcyBlbiBlc3RhIG5vdGEuPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCByb3VuZGVkLWxnIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+U3VidG90YWw6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy5zdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgeyhub3RlLndpdGhvdXR0YXhfYW1vdW50ID8/IDApID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC1yZWQtNjAwXCI+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlZhbG9yIE5vIEdyYXZhZG86PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT4tIHtmb3JtYXRWYWx1ZShub3RlLndpdGhvdXR0YXhfYW1vdW50ISwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkltcHVlc3Rvczo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pisge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxUYXhlcywgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+PHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtbGcgZm9udC1zZW1pYm9sZGB9PlRvdGFsOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZX0gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+e2Zvcm1hdFZhbHVlKG5vdGUudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Ob3RhczwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+e25vdGUubm90ZXMgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9ub3Rhc19maW5hbmNpZXJhc19jb21wcmEvcGFnZXMvTm90YXNGaW5hbmNpZXJhc0NvbXByYURldGFpbFBhZ2UudHN4In0=