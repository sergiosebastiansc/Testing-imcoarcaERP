import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/organization_details/pages/OrganizationDetailsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { FaEye, FaEyeSlash, FaSave, FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { getById, searchByField } from "/src/services/apiService.ts";
import {
  buildOrganizationDetailsPayload,
  fetchOrganizationDetails,
  organizationDetailsToFormState,
  updateOrganizationDetails
} from "/src/services/organizationDetailsService.ts";
import { isValidSingleEmail } from "/src/utils/emailValidation.ts";
import { useOrganization } from "/src/hooks/useOrganization.ts";
import {
  MAIL_ENCRYPTION_OPTIONS,
  emptyOrganizationDetailsForm
} from "/src/features/organization_details/organizationDetails.types.ts";
import {
  DEFAULT_PRIMARY_COLOR,
  DEFAULT_SECONDARY_COLOR,
  isValidBrandHexColor
} from "/src/context/organizationBranding.ts";
function parseApiFieldErrors(error) {
  if (!error || typeof error !== "object" || !("response" in error)) return {};
  const data = error.response?.data;
  if (!data?.errors || typeof data.errors !== "object") return {};
  const mapped = {};
  for (const [field, messages] of Object.entries(data.errors)) {
    if (Array.isArray(messages) && messages[0]) {
      mapped[field] = messages[0];
    }
  }
  return mapped;
}
function parseApiMessage(error) {
  if (error && typeof error === "object" && "response" in error) {
    const data = error.response?.data;
    if (typeof data?.message === "string" && data.message.trim()) {
      return data.message.trim();
    }
  }
  if (error instanceof Error && error.message) return error.message;
  return "No se pudo guardar la configuración.";
}
const inputClass = "mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500";
const inputErrorClass = "mt-1 block w-full rounded-md border border-red-500 px-3 py-2 text-sm shadow-sm focus:border-red-500 focus:ring-red-500";
function FieldError({ message }) {
  if (!message) return null;
  return /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: message }, void 0, false, {
    fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
    lineNumber: 83,
    columnNumber: 10
  }, this);
}
_c = FieldError;
function BrandColorField({
  id,
  label,
  value,
  disabled,
  hasError,
  errorMessage,
  fallback,
  onChange
}) {
  const pickerValue = isValidBrandHexColor(value) ? value : fallback;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-sm font-medium text-gray-700", children: label }, void 0, false, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 109,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id: `${id}-picker`,
          type: "color",
          value: pickerValue,
          disabled,
          onChange: (e) => onChange(e.target.value.toUpperCase()),
          className: "h-10 w-12 cursor-pointer rounded border border-gray-300 bg-white p-1 disabled:cursor-not-allowed disabled:opacity-60",
          "aria-label": `${label} (selector)`
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 113,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id,
          type: "text",
          value,
          disabled,
          placeholder: fallback,
          maxLength: 7,
          autoComplete: "off",
          onChange: (e) => onChange(e.target.value),
          className: hasError ? inputErrorClass : inputClass
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 122,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 112,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: [
      "Formato #RRGGBB. Vacío usa el default (",
      fallback,
      ")."
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 134,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FieldError, { message: errorMessage }, void 0, false, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 135,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
    lineNumber: 108,
    columnNumber: 5
  }, this);
}
_c2 = BrandColorField;
function PasswordField({
  id,
  label,
  value,
  disabled,
  hasError,
  errorMessage,
  onChange
}) {
  _s();
  const [visible, setVisible] = useState(false);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-sm font-medium text-gray-700", children: label }, void 0, false, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 161,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative mt-1", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id,
          type: visible ? "text" : "password",
          value,
          disabled,
          autoComplete: "off",
          onChange: (e) => onChange(e.target.value),
          className: `${hasError ? inputErrorClass : inputClass} pr-10`
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 165,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          tabIndex: -1,
          disabled,
          onClick: () => setVisible((v) => !v),
          className: "absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-gray-600",
          "aria-label": visible ? "Ocultar" : "Mostrar",
          children: visible ? /* @__PURE__ */ jsxDEV(FaEyeSlash, {}, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 182,
            columnNumber: 32
          }, this) : /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 182,
            columnNumber: 49
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 174,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 164,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(FieldError, { message: errorMessage }, void 0, false, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 185,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
    lineNumber: 160,
    columnNumber: 5
  }, this);
}
_s(PasswordField, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c3 = PasswordField;
export const OrganizationDetailsPage = () => {
  _s2();
  const { setBranding } = useOrganization();
  const [form, setForm] = useState(emptyOrganizationDetailsForm);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreviewUrl, setLogoPreviewUrl] = useState(null);
  const [afipCertFile, setAfipCertFile] = useState(null);
  const [afipKeyFile, setAfipKeyFile] = useState(null);
  const fileInputRef = useRef(null);
  const afipCertInputRef = useRef(null);
  const afipKeyInputRef = useRef(null);
  const patchForm = useCallback((patch) => {
    setForm((prev) => ({ ...prev, ...patch }));
    setFieldErrors((prev) => {
      const next = { ...prev };
      for (const key of Object.keys(patch)) {
        delete next[key];
      }
      return next;
    });
  }, []);
  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const details = await fetchOrganizationDetails();
      const nextForm = organizationDetailsToFormState(details);
      if (details.meli_shipping_product_id) {
        try {
          const product = await getById(
            articulosModuleConfig.endpoint,
            details.meli_shipping_product_id
          );
          nextForm.meli_shipping_product_sku = product.sku ?? "";
          nextForm.meli_shipping_product_name = product.name ?? "";
        } catch (e) {
          console.error(e);
          toast.warn("No se pudo cargar el Producto Flete MELI asociado.");
        }
      }
      setForm(nextForm);
      setLogoFile(null);
      setLogoPreviewUrl(null);
      setAfipCertFile(null);
      setAfipKeyFile(null);
      setFieldErrors({});
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      if (afipCertInputRef.current) {
        afipCertInputRef.current.value = "";
      }
      if (afipKeyInputRef.current) {
        afipKeyInputRef.current.value = "";
      }
    } catch (e) {
      console.error(e);
      setLoadError("No se pudo cargar la configuración del sistema.");
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    return () => {
      if (logoPreviewUrl) {
        URL.revokeObjectURL(logoPreviewUrl);
      }
    };
  }, [logoPreviewUrl]);
  const clearLogoSelection = useCallback(() => {
    setLogoFile(null);
    setLogoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.logo;
      return next;
    });
  }, []);
  const clearAfipCertSelection = useCallback(() => {
    setAfipCertFile(null);
    if (afipCertInputRef.current) {
      afipCertInputRef.current.value = "";
    }
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.afip_cert;
      return next;
    });
  }, []);
  const clearAfipKeySelection = useCallback(() => {
    setAfipKeyFile(null);
    if (afipKeyInputRef.current) {
      afipKeyInputRef.current.value = "";
    }
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.afip_key;
      return next;
    });
  }, []);
  const fileExtension = (filename) => {
    const parts = filename.toLowerCase().split(".");
    return parts.length > 1 ? parts.pop() ?? "" : "";
  };
  const handleAfipCertChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) {
      clearAfipCertSelection();
      return;
    }
    const ext = fileExtension(file.name);
    const maxSize = 1024 * 1024;
    if (ext !== "crt" && ext !== "pem") {
      toast.error("Tipo de archivo no permitido. Solo .crt o .pem.");
      clearAfipCertSelection();
      setFieldErrors((prev) => ({
        ...prev,
        afip_cert: "Solo se permiten archivos .crt o .pem."
      }));
      return;
    }
    if (file.size > maxSize) {
      toast.error("El certificado excede el tamaño máximo de 1MB.");
      clearAfipCertSelection();
      setFieldErrors((prev) => ({
        ...prev,
        afip_cert: "El certificado no puede superar 1 MB."
      }));
      return;
    }
    setAfipCertFile(file);
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.afip_cert;
      return next;
    });
  };
  const handleAfipKeyChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) {
      clearAfipKeySelection();
      return;
    }
    const ext = fileExtension(file.name);
    const maxSize = 1024 * 1024;
    if (ext !== "key") {
      toast.error("Tipo de archivo no permitido. Solo .key.");
      clearAfipKeySelection();
      setFieldErrors((prev) => ({
        ...prev,
        afip_key: "Solo se permiten archivos .key."
      }));
      return;
    }
    if (file.size > maxSize) {
      toast.error("La clave excede el tamaño máximo de 1MB.");
      clearAfipKeySelection();
      setFieldErrors((prev) => ({
        ...prev,
        afip_key: "La clave no puede superar 1 MB."
      }));
      return;
    }
    setAfipKeyFile(file);
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.afip_key;
      return next;
    });
  };
  const handleLogoChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) {
      clearLogoSelection();
      return;
    }
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
    const maxSize = 2048 * 1024;
    if (!allowedTypes.includes(file.type)) {
      toast.error("Tipo de archivo no permitido. Solo JPG, PNG o WEBP.");
      clearLogoSelection();
      setFieldErrors((prev) => ({
        ...prev,
        logo: "Solo se permiten imágenes JPG, PNG o WEBP."
      }));
      return;
    }
    if (file.size > maxSize) {
      toast.error("El archivo excede el tamaño máximo de 2MB.");
      clearLogoSelection();
      setFieldErrors((prev) => ({
        ...prev,
        logo: "El logo no puede superar los 2 MB."
      }));
      return;
    }
    setLogoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    setLogoFile(file);
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.logo;
      return next;
    });
  };
  const handleProductCodeChange = (code) => {
    patchForm({
      meli_shipping_product_sku: code,
      meli_shipping_product_id: null,
      meli_shipping_product_name: ""
    });
  };
  const handleProductSelect = (product) => {
    patchForm({
      meli_shipping_product_id: product.id,
      meli_shipping_product_sku: product.sku ?? "",
      meli_shipping_product_name: product.name ?? ""
    });
    setIsProductModalOpen(false);
  };
  const handleProductCodeSubmit = async () => {
    const codeValue = form.meli_shipping_product_sku.trim();
    if (!codeValue) return;
    try {
      const result = await searchByField(
        articulosModuleConfig.endpoint,
        [
          { fieldName: "sku", value: codeValue }
        ]
      );
      if (result && result.is_active !== false) {
        handleProductSelect(result);
        toast.success("Producto encontrado.");
      } else if (result && result.is_active === false) {
        toast.error("El producto encontrado no está activo.");
        patchForm({
          meli_shipping_product_id: null,
          meli_shipping_product_name: ""
        });
      } else {
        toast.error(`No se encontró ningún artículo con el código "${codeValue}".`);
        patchForm({
          meli_shipping_product_id: null,
          meli_shipping_product_name: ""
        });
      }
    } catch (e) {
      console.error(e);
      toast.error("Error al buscar el artículo.");
    }
  };
  const validateClient = () => {
    const errors = {};
    if (!form.name.trim()) {
      errors.name = "El nombre es obligatorio.";
    }
    if (form.mail_from_address.trim() && !isValidSingleEmail(form.mail_from_address)) {
      errors.mail_from_address = "El email no tiene un formato válido.";
    }
    if (form.contact_email.trim() && !isValidSingleEmail(form.contact_email)) {
      errors.contact_email = "El email no tiene un formato válido.";
    }
    if (form.mail_port.trim()) {
      const port = Number(form.mail_port.trim());
      if (!Number.isInteger(port) || port <= 0) {
        errors.mail_port = "El puerto debe ser un número entero positivo.";
      }
    }
    if (form.fce_minimum_amount != null && form.fce_minimum_amount < 0) {
      errors.fce_minimum_amount = "El valor mínimo no puede ser negativo.";
    }
    if (form.meli_shipping_product_sku.trim() && !form.meli_shipping_product_id) {
      errors.meli_shipping_product_id = "Seleccioná un producto válido (Enter o lupa) antes de guardar.";
    }
    if (form.primary_color.trim() && !isValidBrandHexColor(form.primary_color.trim())) {
      errors.primary_color = "Usá un color hex válido (#RRGGBB).";
    }
    if (form.secondary_color.trim() && !isValidBrandHexColor(form.secondary_color.trim())) {
      errors.secondary_color = "Usá un color hex válido (#RRGGBB).";
    }
    return errors;
  };
  const handleSave = async () => {
    const clientErrors = validateClient();
    if (Object.keys(clientErrors).length > 0) {
      setFieldErrors(clientErrors);
      toast.warn("Revisá los campos marcados.");
      return;
    }
    setSaving(true);
    setFieldErrors({});
    try {
      const payload = buildOrganizationDetailsPayload(form);
      const updated = await updateOrganizationDetails(payload, {
        logoFile,
        afipCertFile,
        afipKeyFile
      });
      const nextForm = organizationDetailsToFormState(updated);
      nextForm.meli_shipping_product_sku = form.meli_shipping_product_sku;
      nextForm.meli_shipping_product_name = form.meli_shipping_product_name;
      setForm(nextForm);
      clearLogoSelection();
      clearAfipCertSelection();
      clearAfipKeySelection();
      setBranding({
        name: updated.name,
        logo_url: updated.logo_url ?? null,
        primary_color: updated.primary_color ?? null,
        secondary_color: updated.secondary_color ?? null
      });
      toast.success("Configuración guardada.");
    } catch (e) {
      console.error(e);
      const apiErrors = parseApiFieldErrors(e);
      if (Object.keys(apiErrors).length > 0) {
        setFieldErrors(apiErrors);
        toast.error("Hay errores de validación. Revisá los campos marcados.");
      } else {
        toast.error(parseApiMessage(e));
      }
    } finally {
      setSaving(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
    lineNumber: 571,
    columnNumber: 23
  }, this);
  if (loadError) {
    return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg bg-white p-6 shadow-sm", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-red-600", children: loadError }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 576,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => void load(),
          className: "mt-4 rounded-md bg-yellow-600 px-4 py-2 text-sm font-medium text-white hover:bg-yellow-700",
          children: "Reintentar"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 577,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 575,
      columnNumber: 7
    }, this);
  }
  const disabled = saving;
  const displayedLogoUrl = logoPreviewUrl || form.logo_url;
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 rounded-lg bg-white p-4 shadow-sm sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b pb-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: "Configuración del sistema" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 594,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => void handleSave(),
          disabled,
          className: "inline-flex items-center rounded-md border border-transparent bg-yellow-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-yellow-700 disabled:opacity-60",
          children: [
            saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "mr-2 h-4 w-4 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 602,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2 h-4 w-4" }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 604,
              columnNumber: 11
            }, this),
            "Guardar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 595,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 593,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "General" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 612,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-name", className: "block text-sm font-medium text-gray-700", children: "Nombre *" }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 616,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "org-name",
            type: "text",
            value: form.name,
            disabled,
            onChange: (e) => patchForm({ name: e.target.value }),
            className: fieldErrors.name ? inputErrorClass : inputClass,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 619,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.name }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 626,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 615,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-logo", className: "block text-sm font-medium text-gray-700", children: "Logo" }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 629,
          columnNumber: 21
        }, this),
        displayedLogoUrl && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: displayedLogoUrl,
              alt: "Logo de la organización",
              className: "max-h-20 max-w-[200px] rounded border border-gray-200 bg-white object-contain p-1"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 634,
              columnNumber: 29
            },
            this
          ),
          logoFile && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-blue-600", children: "Vista previa del nuevo logo (aún no guardado)." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 640,
            columnNumber: 13
          }, this),
          !logoFile && form.logo_url && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Logo actual." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 645,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 633,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: fileInputRef,
            id: "org-logo",
            type: "file",
            accept: ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp",
            disabled,
            onChange: handleLogoChange,
            autoComplete: "off",
            className: "mt-1 block w-full cursor-pointer rounded-md border border-gray-300 text-sm text-gray-900 shadow-sm focus:outline-none file:mr-4 file:rounded-l-md file:border-0 file:bg-indigo-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-indigo-700 hover:file:bg-indigo-100"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 649,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: form.logo_url ? "Seleccioná un nuevo archivo para reemplazar el actual. Opcional. Tipos: JPG, PNG, WEBP. Máx: 2MB." : "Opcional. Tipos: JPG, PNG, WEBP. Máx: 2MB." }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 658,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.logo }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 663,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 628,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(
          BrandColorField,
          {
            id: "org-primary-color",
            label: "Color principal",
            value: form.primary_color,
            disabled,
            hasError: Boolean(fieldErrors.primary_color),
            errorMessage: fieldErrors.primary_color,
            fallback: DEFAULT_PRIMARY_COLOR,
            onChange: (value) => patchForm({ primary_color: value })
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 666,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          BrandColorField,
          {
            id: "org-secondary-color",
            label: "Color secundario",
            value: form.secondary_color,
            disabled,
            hasError: Boolean(fieldErrors.secondary_color),
            errorMessage: fieldErrors.secondary_color,
            fallback: DEFAULT_SECONDARY_COLOR,
            onChange: (value) => patchForm({ secondary_color: value })
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 676,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 665,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 611,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 border-t pt-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "Datos de la empresa" }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 692,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Datos impresos en PDF / remitos." }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 695,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 691,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-activity", className: "block text-sm font-medium text-gray-700", children: "Actividad / marca" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 701,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-activity",
              type: "text",
              value: form.activity,
              disabled,
              placeholder: "CINTAS AUTOADHESIVAS",
              onChange: (e) => patchForm({ activity: e.target.value }),
              className: fieldErrors.activity ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 704,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.activity }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 714,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 700,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-address", className: "block text-sm font-medium text-gray-700", children: "Dirección" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 717,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-address",
              type: "text",
              value: form.address,
              disabled,
              placeholder: "ARGERICH 5756/60",
              onChange: (e) => patchForm({ address: e.target.value }),
              className: fieldErrors.address ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 720,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.address }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 730,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 716,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-city", className: "block text-sm font-medium text-gray-700", children: "Ciudad / CP" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 733,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-city",
              type: "text",
              value: form.city,
              disabled,
              placeholder: "(C1419DCF) BUENOS AIRES",
              onChange: (e) => patchForm({ city: e.target.value }),
              className: fieldErrors.city ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 736,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.city }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 746,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 732,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-iva-condition", className: "block text-sm font-medium text-gray-700", children: "Condición IVA" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 749,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-iva-condition",
              type: "text",
              value: form.iva_condition,
              disabled,
              placeholder: "I.V.A.: RESPONSABLE INSCRIPTO",
              onChange: (e) => patchForm({ iva_condition: e.target.value }),
              className: fieldErrors.iva_condition ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 752,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.iva_condition }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 762,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 748,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-website", className: "block text-sm font-medium text-gray-700", children: "Sitio web" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 765,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-website",
              type: "text",
              value: form.website,
              disabled,
              placeholder: "www.selgom.com.ar",
              onChange: (e) => patchForm({ website: e.target.value }),
              className: fieldErrors.website ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 768,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.website }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 778,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 764,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-contact-email", className: "block text-sm font-medium text-gray-700", children: "E-mail de contacto" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 781,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-contact-email",
              type: "email",
              value: form.contact_email,
              disabled,
              placeholder: "info@selgom.com.ar",
              onChange: (e) => patchForm({ contact_email: e.target.value }),
              className: fieldErrors.contact_email ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 784,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Distinto del email SMTP (mail from address)." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 794,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.contact_email }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 797,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 780,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-mobile", className: "block text-sm font-medium text-gray-700", children: "Celular" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 800,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-mobile",
              type: "text",
              value: form.mobile,
              disabled,
              placeholder: "11-5114-5355",
              onChange: (e) => patchForm({ mobile: e.target.value }),
              className: fieldErrors.mobile ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 803,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Sin prefijo “Cel.”; el PDF lo agrega." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 813,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mobile }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 814,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 799,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-phone", className: "block text-sm font-medium text-gray-700", children: "Tel/Fax" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 817,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-phone",
              type: "text",
              value: form.phone,
              disabled,
              placeholder: "4572-6067 L. Rot.",
              onChange: (e) => patchForm({ phone: e.target.value }),
              className: fieldErrors.phone ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 820,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Sin “TEL/FAX:”; el PDF lo agrega en remito." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 830,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.phone }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 831,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 816,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-cuit", className: "block text-sm font-medium text-gray-700", children: "CUIT (impresión)" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 834,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-cuit",
              type: "text",
              value: form.cuit,
              disabled,
              placeholder: "30-54673757-4",
              onChange: (e) => patchForm({ cuit: e.target.value }),
              className: fieldErrors.cuit ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 837,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.cuit }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 847,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 833,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-ing-brutos", className: "block text-sm font-medium text-gray-700", children: "Ingresos Brutos" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 850,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-ing-brutos",
              type: "text",
              value: form.ing_brutos,
              disabled,
              placeholder: "901-917434-3",
              onChange: (e) => patchForm({ ing_brutos: e.target.value }),
              className: fieldErrors.ing_brutos ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 853,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.ing_brutos }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 863,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 849,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-fiscal-start-date", className: "block text-sm font-medium text-gray-700", children: "Inicio de actividades" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 866,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-fiscal-start-date",
              type: "text",
              value: form.fiscal_start_date,
              disabled,
              placeholder: "30/07/1986",
              onChange: (e) => patchForm({ fiscal_start_date: e.target.value }),
              className: fieldErrors.fiscal_start_date ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 869,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.fiscal_start_date }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 879,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 865,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-remito-cai-number", className: "block text-sm font-medium text-gray-700", children: "CAI remito" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 882,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-remito-cai-number",
              type: "text",
              value: form.remito_cai_number,
              disabled,
              placeholder: "52134217905443",
              onChange: (e) => patchForm({ remito_cai_number: e.target.value }),
              className: fieldErrors.remito_cai_number ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 885,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.remito_cai_number }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 895,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 881,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "org-remito-cai-due-date", className: "block text-sm font-medium text-gray-700", children: "Vencimiento CAI" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 898,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "org-remito-cai-due-date",
              type: "text",
              value: form.remito_cai_due_date,
              disabled,
              placeholder: "01/04/2027",
              onChange: (e) => patchForm({ remito_cai_due_date: e.target.value }),
              className: fieldErrors.remito_cai_due_date ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 901,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.remito_cai_due_date }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 911,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 897,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "org-payment-legal-legend",
              className: "block text-sm font-medium text-gray-700",
              children: "Leyenda legal de pago"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 914,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              id: "org-payment-legal-legend",
              rows: 6,
              value: form.payment_legal_legend,
              disabled,
              onChange: (e) => patchForm({ payment_legal_legend: e.target.value }),
              className: fieldErrors.payment_legal_legend ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 920,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Texto impreso al pie de factura / NC / NF (omitido en ventas MELI en PDF)." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 931,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.payment_legal_legend }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 935,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 913,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 699,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 690,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 border-t pt-6", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "Mercado Libre" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 942,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "meli-client-id",
              className: "block text-sm font-medium text-gray-700",
              children: "Client ID - MELI"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 947,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "meli-client-id",
              type: "text",
              value: form.meli_client_id,
              disabled,
              onChange: (e) => patchForm({ meli_client_id: e.target.value }),
              className: fieldErrors.meli_client_id ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 953,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.meli_client_id }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 960,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 946,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          PasswordField,
          {
            id: "meli-client-secret",
            label: "Client Secret - MELI",
            value: form.meli_client_secret,
            disabled,
            hasError: Boolean(fieldErrors.meli_client_secret),
            errorMessage: fieldErrors.meli_client_secret,
            onChange: (value) => patchForm({ meli_client_secret: value })
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 962,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Producto Flete MELI" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 972,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: form.meli_shipping_product_sku,
              nameValue: form.meli_shipping_product_name,
              onCodeChange: handleProductCodeChange,
              onCodeSubmit: () => void handleProductCodeSubmit(),
              onSearchClick: () => setIsProductModalOpen(true),
              onClearClick: () => patchForm({
                meli_shipping_product_id: null,
                meli_shipping_product_sku: "",
                meli_shipping_product_name: ""
              }),
              mask: "sku",
              disabled,
              hasError: Boolean(fieldErrors.meli_shipping_product_id),
              enableAutocomplete: true,
              autocompleteConfig: {
                endpoint: articulosModuleConfig.endpoint,
                codeField: "sku",
                nameField: "name",
                searchParams: { is_active: true },
                onSelect: (item) => handleProductSelect(item)
              }
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 975,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Escribí el SKU y presioná Enter, o usá la lupa. Solo productos activos." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1e3,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.meli_shipping_product_id }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1003,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 971,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 945,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 941,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 border-t pt-6", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "Email" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1010,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-medium text-gray-700", children: "Servidor de email" }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1014,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1 grid grid-cols-1 gap-3 sm:grid-cols-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "mail-host", className: "sr-only", children: "Host" }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1019,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "mail-host",
                type: "text",
                placeholder: "Host",
                value: form.mail_host,
                disabled,
                onChange: (e) => patchForm({ mail_host: e.target.value }),
                className: fieldErrors.mail_host ? inputErrorClass : inputClass,
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
                lineNumber: 1022,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_host }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1030,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1018,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "mail-port", className: "sr-only", children: "Puerto" }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1033,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "mail-port",
                type: "text",
                inputMode: "numeric",
                placeholder: "Puerto",
                value: form.mail_port,
                disabled,
                onChange: (e) => patchForm({ mail_port: e.target.value }),
                className: fieldErrors.mail_port ? inputErrorClass : inputClass,
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
                lineNumber: 1036,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_port }, void 0, false, {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1045,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1032,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1017,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1013,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "mail-encryption",
              className: "block text-sm font-medium text-gray-700",
              children: "Cifrado de email"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1052,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              id: "mail-encryption",
              value: form.mail_encryption,
              disabled,
              onChange: (e) => patchForm({
                mail_encryption: e.target.value
              }),
              className: fieldErrors.mail_encryption ? inputErrorClass : inputClass,
              children: MAIL_ENCRYPTION_OPTIONS.map(
                (opt) => /* @__PURE__ */ jsxDEV("option", { value: opt.value, children: opt.label }, opt.value || "none", false, {
                  fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
                  lineNumber: 1070,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1058,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_encryption }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1075,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1051,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "mail-from-address",
              className: "block text-sm font-medium text-gray-700",
              children: "Cuenta de email"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1078,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "mail-from-address",
              type: "email",
              value: form.mail_from_address,
              disabled,
              onChange: (e) => patchForm({ mail_from_address: e.target.value }),
              className: fieldErrors.mail_from_address ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1084,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_from_address }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1093,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1077,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "mail-from-name",
              className: "block text-sm font-medium text-gray-700",
              children: "Nombre público del email"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1096,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "mail-from-name",
              type: "text",
              value: form.mail_from_name,
              disabled,
              onChange: (e) => patchForm({ mail_from_name: e.target.value }),
              className: fieldErrors.mail_from_name ? inputErrorClass : inputClass,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1102,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_from_name }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1109,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1095,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "mail-username",
              className: "block text-sm font-medium text-gray-700",
              children: "Usuario de email"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1112,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "mail-username",
              type: "text",
              value: form.mail_username,
              disabled,
              autoComplete: "off",
              onChange: (e) => patchForm({ mail_username: e.target.value }),
              className: fieldErrors.mail_username ? inputErrorClass : inputClass
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1118,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.mail_username }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1127,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1111,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          PasswordField,
          {
            id: "mail-password",
            label: "Clave de email",
            value: form.mail_password,
            disabled,
            hasError: Boolean(fieldErrors.mail_password),
            errorMessage: fieldErrors.mail_password,
            onChange: (value) => patchForm({ mail_password: value })
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1129,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1050,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 1009,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 border-t pt-6", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "Facturación" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1143,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-md", children: [
        /* @__PURE__ */ jsxDEV(
          "label",
          {
            htmlFor: "fce-minimum-amount",
            className: "block text-sm font-medium text-gray-700",
            children: "Valor mínimo de Factura de Crédito Electrónica MiPyME"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1147,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DecimalInput,
          {
            id: "fce-minimum-amount",
            nullable: true,
            value: form.fce_minimum_amount,
            whenEmpty: null,
            emptyWhenZero: false,
            disabled,
            min: 0,
            step: "0.01",
            onChange: (num) => patchForm({ fce_minimum_amount: num }),
            className: fieldErrors.fce_minimum_amount ? inputErrorClass : inputClass
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1153,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.fce_minimum_amount }, void 0, false, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1167,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1146,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 1142,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-4 border-t pt-6", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-wide text-gray-500", children: "AFIP / ARCA" }, void 0, false, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1173,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "org-afip-cert",
              className: "block text-sm font-medium text-gray-700",
              children: "Certificado AFIP"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1178,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: afipCertFile ? `Nuevo archivo seleccionado: ${afipCertFile.name} (aún no guardado).` : form.has_afip_cert ? "Certificado cargado." : "Sin certificado." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1184,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: afipCertInputRef,
              id: "org-afip-cert",
              type: "file",
              accept: ".crt,.pem",
              disabled,
              onChange: handleAfipCertChange,
              autoComplete: "off",
              className: "mt-2 block w-full cursor-pointer rounded-md border border-gray-300 text-sm text-gray-900 shadow-sm focus:outline-none file:mr-4 file:rounded-l-md file:border-0 file:bg-indigo-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-indigo-700 hover:file:bg-indigo-100"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1191,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: form.has_afip_cert ? "Seleccioná un nuevo archivo para reemplazar el actual. Opcional. Tipos: .crt, .pem. Máx: 1MB." : "Opcional. Tipos: .crt, .pem. Máx: 1MB." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1200,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.afip_cert }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1205,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1177,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "org-afip-key",
              className: "block text-sm font-medium text-gray-700",
              children: "Clave privada AFIP"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1208,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: afipKeyFile ? `Nuevo archivo seleccionado: ${afipKeyFile.name} (aún no guardado).` : form.has_afip_key ? "Clave cargada." : "Sin clave." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1214,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: afipKeyInputRef,
              id: "org-afip-key",
              type: "file",
              accept: ".key",
              disabled,
              onChange: handleAfipKeyChange,
              autoComplete: "off",
              className: "mt-2 block w-full cursor-pointer rounded-md border border-gray-300 text-sm text-gray-900 shadow-sm focus:outline-none file:mr-4 file:rounded-l-md file:border-0 file:bg-indigo-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-indigo-700 hover:file:bg-indigo-100"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
              lineNumber: 1221,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: form.has_afip_key ? "Seleccioná un nuevo archivo para reemplazar el actual. Opcional. Tipo: .key. Máx: 1MB." : "Opcional. Tipo: .key. Máx: 1MB." }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1230,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(FieldError, { message: fieldErrors.afip_key }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1235,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
          lineNumber: 1207,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1176,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 1172,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end border-t pt-6", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => void handleSave(),
        disabled,
        className: "inline-flex items-center rounded-md border border-transparent bg-yellow-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-yellow-700 disabled:opacity-60",
        children: [
          saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "mr-2 h-4 w-4 animate-spin" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1248,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
            lineNumber: 1250,
            columnNumber: 11
          }, this),
          "Guardar"
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1241,
        columnNumber: 17
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
      lineNumber: 1240,
      columnNumber: 13
    }, this),
    isProductModalOpen && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isProductModalOpen,
        onClose: () => setIsProductModalOpen(false),
        onSelect: (item) => handleProductSelect(item),
        config: {
          ...articulosModuleConfig,
          initialFilters: { is_active: true }
        }
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
        lineNumber: 1257,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx",
    lineNumber: 592,
    columnNumber: 5
  }, this);
};
_s2(OrganizationDetailsPage, "iBEGP6bATXglKfVVDA6eZTJfze0=", false, function() {
  return [useOrganization];
});
_c4 = OrganizationDetailsPage;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "FieldError");
$RefreshReg$(_c2, "BrandColorField");
$RefreshReg$(_c3, "PasswordField");
$RefreshReg$(_c4, "OrganizationDetailsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/organization_details/pages/OrganizationDetailsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0RXOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9EWCxTQUFTQSxhQUFhQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDekQsU0FBU0MsT0FBT0MsWUFBWUMsUUFBUUMsaUJBQWlCO0FBQ3JELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLDZCQUE0QztBQUNyRCxTQUFTQyxTQUFTQyxxQkFBcUI7QUFDdkM7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLHVCQUF1QjtBQUNoQztBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BR0c7QUFDUDtBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0c7QUFJUCxTQUFTQyxvQkFBb0JDLE9BQTZCO0FBQ3RELE1BQUksQ0FBQ0EsU0FBUyxPQUFPQSxVQUFVLFlBQVksRUFBRSxjQUFjQSxPQUFRLFFBQU8sQ0FBQztBQUMzRSxRQUFNQyxPQUFRRCxNQUEwRUUsVUFDbEZEO0FBQ04sTUFBSSxDQUFDQSxNQUFNRSxVQUFVLE9BQU9GLEtBQUtFLFdBQVcsU0FBVSxRQUFPLENBQUM7QUFDOUQsUUFBTUMsU0FBc0IsQ0FBQztBQUM3QixhQUFXLENBQUNDLE9BQU9DLFFBQVEsS0FBS0MsT0FBT0MsUUFBUVAsS0FBS0UsTUFBTSxHQUFHO0FBQ3pELFFBQUlNLE1BQU1DLFFBQVFKLFFBQVEsS0FBS0EsU0FBUyxDQUFDLEdBQUc7QUFDeENGLGFBQU9DLEtBQUssSUFBSUMsU0FBUyxDQUFDO0FBQUEsSUFDOUI7QUFBQSxFQUNKO0FBQ0EsU0FBT0Y7QUFDWDtBQUVBLFNBQVNPLGdCQUFnQlgsT0FBd0I7QUFDN0MsTUFBSUEsU0FBUyxPQUFPQSxVQUFVLFlBQVksY0FBY0EsT0FBTztBQUMzRCxVQUFNQyxPQUFRRCxNQUF5REUsVUFBVUQ7QUFDakYsUUFBSSxPQUFPQSxNQUFNVyxZQUFZLFlBQVlYLEtBQUtXLFFBQVFDLEtBQUssR0FBRztBQUMxRCxhQUFPWixLQUFLVyxRQUFRQyxLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNKO0FBQ0EsTUFBSWIsaUJBQWlCYyxTQUFTZCxNQUFNWSxRQUFTLFFBQU9aLE1BQU1ZO0FBQzFELFNBQU87QUFDWDtBQUVBLE1BQU1HLGFBQ0Y7QUFDSixNQUFNQyxrQkFDRjtBQUVKLFNBQVNDLFdBQVcsRUFBRUwsUUFBOEIsR0FBRztBQUNuRCxNQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixTQUFPLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLHFCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWtEO0FBQzdEO0FBQUNNLEtBSFFEO0FBS1QsU0FBU0UsZ0JBQWdCO0FBQUEsRUFDckJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBVUosR0FBRztBQUNDLFFBQU1DLGNBQWM5QixxQkFBcUJ3QixLQUFLLElBQUlBLFFBQVFJO0FBRTFELFNBQ0ksdUJBQUMsU0FDRztBQUFBLDJCQUFDLFdBQU0sU0FBU04sSUFBSSxXQUFVLDJDQUN6QkMsbUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1g7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csSUFBSSxHQUFHRCxFQUFFO0FBQUEsVUFDVCxNQUFLO0FBQUEsVUFDTCxPQUFPUTtBQUFBQSxVQUNQO0FBQUEsVUFDQSxVQUFVLENBQUFDLE1BQUtGLFNBQVNFLEVBQUVDLE9BQU9SLE1BQU1TLFlBQVksQ0FBQztBQUFBLFVBQ3BELFdBQVU7QUFBQSxVQUNWLGNBQVksR0FBR1YsS0FBSztBQUFBO0FBQUEsUUFQeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT3NDO0FBQUEsTUFFdEM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHO0FBQUEsVUFDQSxNQUFLO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBLGFBQWFLO0FBQUFBLFVBQ2IsV0FBVztBQUFBLFVBQ1gsY0FBYTtBQUFBLFVBQ2IsVUFBVSxDQUFBRyxNQUFLRixTQUFTRSxFQUFFQyxPQUFPUixLQUFLO0FBQUEsVUFDdEMsV0FBV0UsV0FBV1Isa0JBQWtCRDtBQUFBQTtBQUFBQSxRQVQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTdUQ7QUFBQSxTQW5CM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsTUFBd0NXO0FBQUFBLE1BQVM7QUFBQSxTQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZGO0FBQUEsSUFDN0YsdUJBQUMsY0FBVyxTQUFTRCxnQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQztBQUFBLE9BM0J0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBRVI7QUFBQ08sTUFwRFFiO0FBc0RULFNBQVNjLGNBQWM7QUFBQSxFQUNuQmI7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUU7QUFTSixHQUFHO0FBQUFPLEtBQUE7QUFDQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTdELFNBQVMsS0FBSztBQUU1QyxTQUNJLHVCQUFDLFNBQ0c7QUFBQSwyQkFBQyxXQUFNLFNBQVM2QyxJQUFJLFdBQVUsMkNBQ3pCQyxtQkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRztBQUFBLFVBQ0EsTUFBTWMsVUFBVSxTQUFTO0FBQUEsVUFDekI7QUFBQSxVQUNBO0FBQUEsVUFDQSxjQUFhO0FBQUEsVUFDYixVQUFVLENBQUFOLE1BQUtGLFNBQVNFLEVBQUVDLE9BQU9SLEtBQUs7QUFBQSxVQUN0QyxXQUFXLEdBQUdFLFdBQVdSLGtCQUFrQkQsVUFBVTtBQUFBO0FBQUEsUUFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT2tFO0FBQUEsTUFFbEU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFVBQVU7QUFBQSxVQUNWO0FBQUEsVUFDQSxTQUFTLE1BQU1xQixXQUFXLENBQUFDLE1BQUssQ0FBQ0EsQ0FBQztBQUFBLFVBQ2pDLFdBQVU7QUFBQSxVQUNWLGNBQVlGLFVBQVUsWUFBWTtBQUFBLFVBRWpDQSxvQkFBVSx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXLElBQU0sdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFNO0FBQUE7QUFBQSxRQVJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLFNBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsU0FBU1YsZ0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxPQXpCdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQTtBQUVSO0FBQUNTLEdBaERRRCxlQUFhO0FBQUFLLE1BQWJMO0FBa0RGLGFBQU1NLDBCQUEwQkEsTUFBTTtBQUFBQyxNQUFBO0FBQ3pDLFFBQU0sRUFBRUMsWUFBWSxJQUFJaEQsZ0JBQWdCO0FBQ3hDLFFBQU0sQ0FBQ2lELE1BQU1DLE9BQU8sSUFBSXBFLFNBQXVDb0IsNEJBQTRCO0FBQzNGLFFBQU0sQ0FBQ2lELFNBQVNDLFVBQVUsSUFBSXRFLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUN1RSxXQUFXQyxZQUFZLElBQUl4RSxTQUF3QixJQUFJO0FBQzlELFFBQU0sQ0FBQ3lFLFFBQVFDLFNBQVMsSUFBSTFFLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUMyRSxhQUFhQyxjQUFjLElBQUk1RSxTQUFzQixDQUFDLENBQUM7QUFDOUQsUUFBTSxDQUFDNkUsb0JBQW9CQyxxQkFBcUIsSUFBSTlFLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUMrRSxVQUFVQyxXQUFXLElBQUloRixTQUFzQixJQUFJO0FBQzFELFFBQU0sQ0FBQ2lGLGdCQUFnQkMsaUJBQWlCLElBQUlsRixTQUF3QixJQUFJO0FBQ3hFLFFBQU0sQ0FBQ21GLGNBQWNDLGVBQWUsSUFBSXBGLFNBQXNCLElBQUk7QUFDbEUsUUFBTSxDQUFDcUYsYUFBYUMsY0FBYyxJQUFJdEYsU0FBc0IsSUFBSTtBQUNoRSxRQUFNdUYsZUFBZXhGLE9BQXlCLElBQUk7QUFDbEQsUUFBTXlGLG1CQUFtQnpGLE9BQXlCLElBQUk7QUFDdEQsUUFBTTBGLGtCQUFrQjFGLE9BQXlCLElBQUk7QUFFckQsUUFBTTJGLFlBQVk3RixZQUFZLENBQUM4RixVQUFpRDtBQUM1RXZCLFlBQVEsQ0FBQXdCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLEdBQUdELE1BQU0sRUFBRTtBQUN2Q2YsbUJBQWUsQ0FBQWdCLFNBQVE7QUFDbkIsWUFBTUMsT0FBTyxFQUFFLEdBQUdELEtBQUs7QUFDdkIsaUJBQVdFLE9BQU85RCxPQUFPK0QsS0FBS0osS0FBSyxHQUFHO0FBQ2xDLGVBQU9FLEtBQUtDLEdBQUc7QUFBQSxNQUNuQjtBQUNBLGFBQU9EO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBRUwsUUFBTUcsT0FBT25HLFlBQVksWUFBWTtBQUNqQ3lFLGVBQVcsSUFBSTtBQUNmRSxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDQSxZQUFNeUIsVUFBVSxNQUFNbkYseUJBQXlCO0FBQy9DLFlBQU1vRixXQUFXbkYsK0JBQStCa0YsT0FBTztBQUV2RCxVQUFJQSxRQUFRRSwwQkFBMEI7QUFDbEMsWUFBSTtBQUNBLGdCQUFNQyxVQUFVLE1BQU16RjtBQUFBQSxZQUNsQkQsc0JBQXNCMkY7QUFBQUEsWUFDdEJKLFFBQVFFO0FBQUFBLFVBQ1o7QUFDQUQsbUJBQVNJLDRCQUE0QkYsUUFBUUcsT0FBTztBQUNwREwsbUJBQVNNLDZCQUE2QkosUUFBUUssUUFBUTtBQUFBLFFBQzFELFNBQVNuRCxHQUFHO0FBQ1JvRCxrQkFBUWpGLE1BQU02QixDQUFDO0FBQ2ZqRCxnQkFBTXNHLEtBQUssb0RBQW9EO0FBQUEsUUFDbkU7QUFBQSxNQUNKO0FBRUF2QyxjQUFROEIsUUFBUTtBQUNoQmxCLGtCQUFZLElBQUk7QUFDaEJFLHdCQUFrQixJQUFJO0FBQ3RCRSxzQkFBZ0IsSUFBSTtBQUNwQkUscUJBQWUsSUFBSTtBQUNuQlYscUJBQWUsQ0FBQyxDQUFDO0FBQ2pCLFVBQUlXLGFBQWFxQixTQUFTO0FBQ3RCckIscUJBQWFxQixRQUFRN0QsUUFBUTtBQUFBLE1BQ2pDO0FBQ0EsVUFBSXlDLGlCQUFpQm9CLFNBQVM7QUFDMUJwQix5QkFBaUJvQixRQUFRN0QsUUFBUTtBQUFBLE1BQ3JDO0FBQ0EsVUFBSTBDLGdCQUFnQm1CLFNBQVM7QUFDekJuQix3QkFBZ0JtQixRQUFRN0QsUUFBUTtBQUFBLE1BQ3BDO0FBQUEsSUFDSixTQUFTTyxHQUFHO0FBQ1JvRCxjQUFRakYsTUFBTTZCLENBQUM7QUFDZmtCLG1CQUFhLGlEQUFpRDtBQUFBLElBQ2xFLFVBQUM7QUFDR0YsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFFTHhFLFlBQVUsTUFBTTtBQUNaLFNBQUtrRyxLQUFLO0FBQUEsRUFDZCxHQUFHLENBQUNBLElBQUksQ0FBQztBQUVUbEcsWUFBVSxNQUFNO0FBQ1osV0FBTyxNQUFNO0FBQ1QsVUFBSW1GLGdCQUFnQjtBQUNoQjRCLFlBQUlDLGdCQUFnQjdCLGNBQWM7QUFBQSxNQUN0QztBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsQ0FBQ0EsY0FBYyxDQUFDO0FBRW5CLFFBQU04QixxQkFBcUJsSCxZQUFZLE1BQU07QUFDekNtRixnQkFBWSxJQUFJO0FBQ2hCRSxzQkFBa0IsQ0FBQVUsU0FBUTtBQUN0QixVQUFJQSxLQUFNaUIsS0FBSUMsZ0JBQWdCbEIsSUFBSTtBQUNsQyxhQUFPO0FBQUEsSUFDWCxDQUFDO0FBQ0QsUUFBSUwsYUFBYXFCLFNBQVM7QUFDdEJyQixtQkFBYXFCLFFBQVE3RCxRQUFRO0FBQUEsSUFDakM7QUFDQTZCLG1CQUFlLENBQUFnQixTQUFRO0FBQ25CLFlBQU1DLE9BQU8sRUFBRSxHQUFHRCxLQUFLO0FBQ3ZCLGFBQU9DLEtBQUttQjtBQUNaLGFBQU9uQjtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUVMLFFBQU1vQix5QkFBeUJwSCxZQUFZLE1BQU07QUFDN0N1RixvQkFBZ0IsSUFBSTtBQUNwQixRQUFJSSxpQkFBaUJvQixTQUFTO0FBQzFCcEIsdUJBQWlCb0IsUUFBUTdELFFBQVE7QUFBQSxJQUNyQztBQUNBNkIsbUJBQWUsQ0FBQWdCLFNBQVE7QUFDbkIsWUFBTUMsT0FBTyxFQUFFLEdBQUdELEtBQUs7QUFDdkIsYUFBT0MsS0FBS3FCO0FBQ1osYUFBT3JCO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBRUwsUUFBTXNCLHdCQUF3QnRILFlBQVksTUFBTTtBQUM1Q3lGLG1CQUFlLElBQUk7QUFDbkIsUUFBSUcsZ0JBQWdCbUIsU0FBUztBQUN6Qm5CLHNCQUFnQm1CLFFBQVE3RCxRQUFRO0FBQUEsSUFDcEM7QUFDQTZCLG1CQUFlLENBQUFnQixTQUFRO0FBQ25CLFlBQU1DLE9BQU8sRUFBRSxHQUFHRCxLQUFLO0FBQ3ZCLGFBQU9DLEtBQUt1QjtBQUNaLGFBQU92QjtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUVMLFFBQU13QixnQkFBZ0JBLENBQUNDLGFBQTZCO0FBQ2hELFVBQU1DLFFBQVFELFNBQVNFLFlBQVksRUFBRUMsTUFBTSxHQUFHO0FBQzlDLFdBQU9GLE1BQU1HLFNBQVMsSUFBS0gsTUFBTUksSUFBSSxLQUFLLEtBQU07QUFBQSxFQUNwRDtBQUVBLFFBQU1DLHVCQUF1QkEsQ0FBQ3RFLE1BQTJDO0FBQ3JFLFVBQU11RSxPQUFPdkUsRUFBRUMsT0FBT3VFLFFBQVEsQ0FBQztBQUMvQixRQUFJLENBQUNELE1BQU07QUFDUFosNkJBQXVCO0FBQ3ZCO0FBQUEsSUFDSjtBQUVBLFVBQU1jLE1BQU1WLGNBQWNRLEtBQUtwQixJQUFJO0FBQ25DLFVBQU11QixVQUFVLE9BQU87QUFFdkIsUUFBSUQsUUFBUSxTQUFTQSxRQUFRLE9BQU87QUFDaEMxSCxZQUFNb0IsTUFBTSxpREFBaUQ7QUFDN0R3Riw2QkFBdUI7QUFDdkJyQyxxQkFBZSxDQUFBZ0IsVUFBUztBQUFBLFFBQ3BCLEdBQUdBO0FBQUFBLFFBQ0hzQixXQUFXO0FBQUEsTUFDZixFQUFFO0FBQ0Y7QUFBQSxJQUNKO0FBRUEsUUFBSVcsS0FBS0ksT0FBT0QsU0FBUztBQUNyQjNILFlBQU1vQixNQUFNLGdEQUFnRDtBQUM1RHdGLDZCQUF1QjtBQUN2QnJDLHFCQUFlLENBQUFnQixVQUFTO0FBQUEsUUFDcEIsR0FBR0E7QUFBQUEsUUFDSHNCLFdBQVc7QUFBQSxNQUNmLEVBQUU7QUFDRjtBQUFBLElBQ0o7QUFFQTlCLG9CQUFnQnlDLElBQUk7QUFDcEJqRCxtQkFBZSxDQUFBZ0IsU0FBUTtBQUNuQixZQUFNQyxPQUFPLEVBQUUsR0FBR0QsS0FBSztBQUN2QixhQUFPQyxLQUFLcUI7QUFDWixhQUFPckI7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1xQyxzQkFBc0JBLENBQUM1RSxNQUEyQztBQUNwRSxVQUFNdUUsT0FBT3ZFLEVBQUVDLE9BQU91RSxRQUFRLENBQUM7QUFDL0IsUUFBSSxDQUFDRCxNQUFNO0FBQ1BWLDRCQUFzQjtBQUN0QjtBQUFBLElBQ0o7QUFFQSxVQUFNWSxNQUFNVixjQUFjUSxLQUFLcEIsSUFBSTtBQUNuQyxVQUFNdUIsVUFBVSxPQUFPO0FBRXZCLFFBQUlELFFBQVEsT0FBTztBQUNmMUgsWUFBTW9CLE1BQU0sMENBQTBDO0FBQ3REMEYsNEJBQXNCO0FBQ3RCdkMscUJBQWUsQ0FBQWdCLFVBQVM7QUFBQSxRQUNwQixHQUFHQTtBQUFBQSxRQUNId0IsVUFBVTtBQUFBLE1BQ2QsRUFBRTtBQUNGO0FBQUEsSUFDSjtBQUVBLFFBQUlTLEtBQUtJLE9BQU9ELFNBQVM7QUFDckIzSCxZQUFNb0IsTUFBTSwwQ0FBMEM7QUFDdEQwRiw0QkFBc0I7QUFDdEJ2QyxxQkFBZSxDQUFBZ0IsVUFBUztBQUFBLFFBQ3BCLEdBQUdBO0FBQUFBLFFBQ0h3QixVQUFVO0FBQUEsTUFDZCxFQUFFO0FBQ0Y7QUFBQSxJQUNKO0FBRUE5QixtQkFBZXVDLElBQUk7QUFDbkJqRCxtQkFBZSxDQUFBZ0IsU0FBUTtBQUNuQixZQUFNQyxPQUFPLEVBQUUsR0FBR0QsS0FBSztBQUN2QixhQUFPQyxLQUFLdUI7QUFDWixhQUFPdkI7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1zQyxtQkFBbUJBLENBQUM3RSxNQUEyQztBQUNqRSxVQUFNdUUsT0FBT3ZFLEVBQUVDLE9BQU91RSxRQUFRLENBQUM7QUFDL0IsUUFBSSxDQUFDRCxNQUFNO0FBQ1BkLHlCQUFtQjtBQUNuQjtBQUFBLElBQ0o7QUFFQSxVQUFNcUIsZUFBZSxDQUFDLGNBQWMsYUFBYSxhQUFhLFlBQVk7QUFDMUUsVUFBTUosVUFBVSxPQUFPO0FBRXZCLFFBQUksQ0FBQ0ksYUFBYUMsU0FBU1IsS0FBS1MsSUFBSSxHQUFHO0FBQ25DakksWUFBTW9CLE1BQU0scURBQXFEO0FBQ2pFc0YseUJBQW1CO0FBQ25CbkMscUJBQWUsQ0FBQWdCLFVBQVM7QUFBQSxRQUNwQixHQUFHQTtBQUFBQSxRQUNIb0IsTUFBTTtBQUFBLE1BQ1YsRUFBRTtBQUNGO0FBQUEsSUFDSjtBQUVBLFFBQUlhLEtBQUtJLE9BQU9ELFNBQVM7QUFDckIzSCxZQUFNb0IsTUFBTSw0Q0FBNEM7QUFDeERzRix5QkFBbUI7QUFDbkJuQyxxQkFBZSxDQUFBZ0IsVUFBUztBQUFBLFFBQ3BCLEdBQUdBO0FBQUFBLFFBQ0hvQixNQUFNO0FBQUEsTUFDVixFQUFFO0FBQ0Y7QUFBQSxJQUNKO0FBRUE5QixzQkFBa0IsQ0FBQVUsU0FBUTtBQUN0QixVQUFJQSxLQUFNaUIsS0FBSUMsZ0JBQWdCbEIsSUFBSTtBQUNsQyxhQUFPaUIsSUFBSTBCLGdCQUFnQlYsSUFBSTtBQUFBLElBQ25DLENBQUM7QUFDRDdDLGdCQUFZNkMsSUFBSTtBQUNoQmpELG1CQUFlLENBQUFnQixTQUFRO0FBQ25CLFlBQU1DLE9BQU8sRUFBRSxHQUFHRCxLQUFLO0FBQ3ZCLGFBQU9DLEtBQUttQjtBQUNaLGFBQU9uQjtBQUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTTJDLDBCQUEwQkEsQ0FBQ0MsU0FBaUI7QUFDOUMvQyxjQUFVO0FBQUEsTUFDTlksMkJBQTJCbUM7QUFBQUEsTUFDM0J0QywwQkFBMEI7QUFBQSxNQUMxQkssNEJBQTRCO0FBQUEsSUFDaEMsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNa0Msc0JBQXNCQSxDQUFDdEMsWUFBc0I7QUFDL0NWLGNBQVU7QUFBQSxNQUNOUywwQkFBMEJDLFFBQVF2RDtBQUFBQSxNQUNsQ3lELDJCQUEyQkYsUUFBUUcsT0FBTztBQUFBLE1BQzFDQyw0QkFBNEJKLFFBQVFLLFFBQVE7QUFBQSxJQUNoRCxDQUFDO0FBQ0QzQiwwQkFBc0IsS0FBSztBQUFBLEVBQy9CO0FBRUEsUUFBTTZELDBCQUEwQixZQUFZO0FBQ3hDLFVBQU1DLFlBQVl6RSxLQUFLbUMsMEJBQTBCaEUsS0FBSztBQUN0RCxRQUFJLENBQUNzRyxVQUFXO0FBRWhCLFFBQUk7QUFDQSxZQUFNQyxTQUFTLE1BQU1qSTtBQUFBQSxRQUF3QkYsc0JBQXNCMkY7QUFBQUEsUUFBVTtBQUFBLFVBQ3pFLEVBQUV5QyxXQUFXLE9BQU8vRixPQUFPNkYsVUFBVTtBQUFBLFFBQUM7QUFBQSxNQUN6QztBQUVELFVBQUlDLFVBQVVBLE9BQU9FLGNBQWMsT0FBTztBQUN0Q0wsNEJBQW9CRyxNQUFNO0FBQzFCeEksY0FBTTJJLFFBQVEsc0JBQXNCO0FBQUEsTUFDeEMsV0FBV0gsVUFBVUEsT0FBT0UsY0FBYyxPQUFPO0FBQzdDMUksY0FBTW9CLE1BQU0sd0NBQXdDO0FBQ3BEaUUsa0JBQVU7QUFBQSxVQUNOUywwQkFBMEI7QUFBQSxVQUMxQkssNEJBQTRCO0FBQUEsUUFDaEMsQ0FBQztBQUFBLE1BQ0wsT0FBTztBQUNIbkcsY0FBTW9CLE1BQU0saURBQWlEbUgsU0FBUyxJQUFJO0FBQzFFbEQsa0JBQVU7QUFBQSxVQUNOUywwQkFBMEI7QUFBQSxVQUMxQkssNEJBQTRCO0FBQUEsUUFDaEMsQ0FBQztBQUFBLE1BQ0w7QUFBQSxJQUNKLFNBQVNsRCxHQUFHO0FBQ1JvRCxjQUFRakYsTUFBTTZCLENBQUM7QUFDZmpELFlBQU1vQixNQUFNLDhCQUE4QjtBQUFBLElBQzlDO0FBQUEsRUFDSjtBQUVBLFFBQU13SCxpQkFBaUJBLE1BQW1CO0FBQ3RDLFVBQU1ySCxTQUFzQixDQUFDO0FBRTdCLFFBQUksQ0FBQ3VDLEtBQUtzQyxLQUFLbkUsS0FBSyxHQUFHO0FBQ25CVixhQUFPNkUsT0FBTztBQUFBLElBQ2xCO0FBRUEsUUFBSXRDLEtBQUsrRSxrQkFBa0I1RyxLQUFLLEtBQUssQ0FBQ3JCLG1CQUFtQmtELEtBQUsrRSxpQkFBaUIsR0FBRztBQUM5RXRILGFBQU9zSCxvQkFBb0I7QUFBQSxJQUMvQjtBQUVBLFFBQUkvRSxLQUFLZ0YsY0FBYzdHLEtBQUssS0FBSyxDQUFDckIsbUJBQW1Ca0QsS0FBS2dGLGFBQWEsR0FBRztBQUN0RXZILGFBQU91SCxnQkFBZ0I7QUFBQSxJQUMzQjtBQUVBLFFBQUloRixLQUFLaUYsVUFBVTlHLEtBQUssR0FBRztBQUN2QixZQUFNK0csT0FBT0MsT0FBT25GLEtBQUtpRixVQUFVOUcsS0FBSyxDQUFDO0FBQ3pDLFVBQUksQ0FBQ2dILE9BQU9DLFVBQVVGLElBQUksS0FBS0EsUUFBUSxHQUFHO0FBQ3RDekgsZUFBT3dILFlBQVk7QUFBQSxNQUN2QjtBQUFBLElBQ0o7QUFFQSxRQUFJakYsS0FBS3FGLHNCQUFzQixRQUFRckYsS0FBS3FGLHFCQUFxQixHQUFHO0FBQ2hFNUgsYUFBTzRILHFCQUFxQjtBQUFBLElBQ2hDO0FBRUEsUUFBSXJGLEtBQUttQywwQkFBMEJoRSxLQUFLLEtBQUssQ0FBQzZCLEtBQUtnQywwQkFBMEI7QUFDekV2RSxhQUFPdUUsMkJBQ0g7QUFBQSxJQUNSO0FBRUEsUUFBSWhDLEtBQUtzRixjQUFjbkgsS0FBSyxLQUFLLENBQUNmLHFCQUFxQjRDLEtBQUtzRixjQUFjbkgsS0FBSyxDQUFDLEdBQUc7QUFDL0VWLGFBQU82SCxnQkFBZ0I7QUFBQSxJQUMzQjtBQUVBLFFBQUl0RixLQUFLdUYsZ0JBQWdCcEgsS0FBSyxLQUFLLENBQUNmLHFCQUFxQjRDLEtBQUt1RixnQkFBZ0JwSCxLQUFLLENBQUMsR0FBRztBQUNuRlYsYUFBTzhILGtCQUFrQjtBQUFBLElBQzdCO0FBRUEsV0FBTzlIO0FBQUFBLEVBQ1g7QUFFQSxRQUFNK0gsYUFBYSxZQUFZO0FBQzNCLFVBQU1DLGVBQWVYLGVBQWU7QUFDcEMsUUFBSWpILE9BQU8rRCxLQUFLNkQsWUFBWSxFQUFFbEMsU0FBUyxHQUFHO0FBQ3RDOUMscUJBQWVnRixZQUFZO0FBQzNCdkosWUFBTXNHLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsSUFDSjtBQUVBakMsY0FBVSxJQUFJO0FBQ2RFLG1CQUFlLENBQUMsQ0FBQztBQUNqQixRQUFJO0FBQ0EsWUFBTWlGLFVBQVVoSixnQ0FBZ0NzRCxJQUFJO0FBQ3BELFlBQU0yRixVQUFVLE1BQU05SSwwQkFBMEI2SSxTQUFTO0FBQUEsUUFDckQ5RTtBQUFBQSxRQUNBSTtBQUFBQSxRQUNBRTtBQUFBQSxNQUNKLENBQUM7QUFDRCxZQUFNYSxXQUFXbkYsK0JBQStCK0ksT0FBTztBQUN2RDVELGVBQVNJLDRCQUE0Qm5DLEtBQUttQztBQUMxQ0osZUFBU00sNkJBQTZCckMsS0FBS3FDO0FBQzNDcEMsY0FBUThCLFFBQVE7QUFDaEJhLHlCQUFtQjtBQUNuQkUsNkJBQXVCO0FBQ3ZCRSw0QkFBc0I7QUFDdEJqRCxrQkFBWTtBQUFBLFFBQ1J1QyxNQUFNcUQsUUFBUXJEO0FBQUFBLFFBQ2RzRCxVQUFVRCxRQUFRQyxZQUFZO0FBQUEsUUFDOUJOLGVBQWVLLFFBQVFMLGlCQUFpQjtBQUFBLFFBQ3hDQyxpQkFBaUJJLFFBQVFKLG1CQUFtQjtBQUFBLE1BQ2hELENBQUM7QUFDRHJKLFlBQU0ySSxRQUFRLHlCQUF5QjtBQUFBLElBQzNDLFNBQVMxRixHQUFHO0FBQ1JvRCxjQUFRakYsTUFBTTZCLENBQUM7QUFDZixZQUFNMEcsWUFBWXhJLG9CQUFvQjhCLENBQUM7QUFDdkMsVUFBSXRCLE9BQU8rRCxLQUFLaUUsU0FBUyxFQUFFdEMsU0FBUyxHQUFHO0FBQ25DOUMsdUJBQWVvRixTQUFTO0FBQ3hCM0osY0FBTW9CLE1BQU0sd0RBQXdEO0FBQUEsTUFDeEUsT0FBTztBQUNIcEIsY0FBTW9CLE1BQU1XLGdCQUFnQmtCLENBQUMsQ0FBQztBQUFBLE1BQ2xDO0FBQUEsSUFDSixVQUFDO0FBQ0dvQixnQkFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxFQUNKO0FBRUEsTUFBSUwsUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUVuQyxNQUFJRSxXQUFXO0FBQ1gsV0FDSSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSw2QkFBQyxPQUFFLFdBQVUsZ0JBQWdCQSx1QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU0sS0FBS3lCLEtBQUs7QUFBQSxVQUN6QixXQUFVO0FBQUEsVUFBNEY7QUFBQTtBQUFBLFFBSDFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxFQUVSO0FBRUEsUUFBTWhELFdBQVd5QjtBQUNqQixRQUFNd0YsbUJBQW1CaEYsa0JBQWtCZCxLQUFLNEY7QUFFaEQsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsTUFDN0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTSxLQUFLSixXQUFXO0FBQUEsVUFDL0I7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUVUbEY7QUFBQUEscUJBQ0csdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRCxJQUVoRCx1QkFBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFDbkM7QUFBQTtBQUFBO0FBQUEsUUFWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLFNBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLFdBQVUsYUFDZjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrREFBNkQsdUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxZQUFXLFdBQVUsMkNBQXlDLHdCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxPQUFPTixLQUFLc0M7QUFBQUEsWUFDWjtBQUFBLFlBQ0EsVUFBVSxDQUFBbkQsTUFBS29DLFVBQVUsRUFBRWUsTUFBTW5ELEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLFlBQ2pELFdBQVc0QixZQUFZOEIsT0FBT2hFLGtCQUFrQkQ7QUFBQUEsWUFBWSxjQUFhO0FBQUE7QUFBQSxVQU43RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNa0Y7QUFBQSxRQUNsRix1QkFBQyxjQUFXLFNBQVNtQyxZQUFZOEIsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFdBWDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxZQUFXLFdBQVUsMkNBQXlDLG9CQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDd0Qsb0JBQ0csdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csS0FBS0E7QUFBQUEsY0FDTCxLQUFJO0FBQUEsY0FDSixXQUFVO0FBQUE7QUFBQSxZQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdpRztBQUFBLFVBRWhHbEYsWUFDRyx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCLDhEQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFSCxDQUFDQSxZQUFZWixLQUFLNEYsWUFDZix1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDRCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBWjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBRUo7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLEtBQUt4RTtBQUFBQSxZQUNMLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQO0FBQUEsWUFDQSxVQUFVNEM7QUFBQUEsWUFDVixjQUFhO0FBQUEsWUFBTSxXQUFVO0FBQUE7QUFBQSxVQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPc1Q7QUFBQSxRQUV0VCx1QkFBQyxPQUFFLFdBQVUsOEJBQ1JoRSxlQUFLNEYsV0FDQSxzR0FDQSxnREFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLGNBQVcsU0FBU3BGLFlBQVlxQyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsV0FuQzFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxPQUFNO0FBQUEsWUFDTixPQUFPN0MsS0FBS3NGO0FBQUFBLFlBQ1o7QUFBQSxZQUNBLFVBQVVTLFFBQVF2RixZQUFZOEUsYUFBYTtBQUFBLFlBQzNDLGNBQWM5RSxZQUFZOEU7QUFBQUEsWUFDMUIsVUFBVXBJO0FBQUFBLFlBQ1YsVUFBVSxDQUFBMEIsVUFBUzJDLFVBQVUsRUFBRStELGVBQWUxRyxNQUFNLENBQUM7QUFBQTtBQUFBLFVBUnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVEyRDtBQUFBLFFBRTNEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxPQUFNO0FBQUEsWUFDTixPQUFPb0IsS0FBS3VGO0FBQUFBLFlBQ1o7QUFBQSxZQUNBLFVBQVVRLFFBQVF2RixZQUFZK0UsZUFBZTtBQUFBLFlBQzdDLGNBQWMvRSxZQUFZK0U7QUFBQUEsWUFDMUIsVUFBVXBJO0FBQUFBLFlBQ1YsVUFBVSxDQUFBeUIsVUFBUzJDLFVBQVUsRUFBRWdFLGlCQUFpQjNHLE1BQU0sQ0FBQztBQUFBO0FBQUEsVUFSM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUTZEO0FBQUEsV0FuQmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTNFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEVBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLFdBQVUsMkJBQ2Y7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLCtEQUE2RCxtQ0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCLGdEQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsaUNBQUMsV0FBTSxTQUFRLGdCQUFlLFdBQVUsMkNBQXlDLGlDQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT29CLEtBQUtnRztBQUFBQSxjQUNaO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUE3RyxNQUFLb0MsVUFBVSxFQUFFeUUsVUFBVTdHLEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGNBQ3JELFdBQVc0QixZQUFZd0YsV0FBVzFILGtCQUFrQkQ7QUFBQUEsY0FDcEQsY0FBYTtBQUFBO0FBQUEsWUFSakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXNCO0FBQUEsVUFFdEIsdUJBQUMsY0FBVyxTQUFTbUMsWUFBWXdGLFlBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsYUFkOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsZUFBYyxXQUFVLDJDQUF5Qyx5QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU9oRyxLQUFLaUc7QUFBQUEsY0FDWjtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osVUFBVSxDQUFBOUcsTUFBS29DLFVBQVUsRUFBRTBFLFNBQVM5RyxFQUFFQyxPQUFPUixNQUFNLENBQUM7QUFBQSxjQUNwRCxXQUFXNEIsWUFBWXlGLFVBQVUzSCxrQkFBa0JEO0FBQUFBLGNBQ25ELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVl5RixXQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBZDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsaUNBQUMsV0FBTSxTQUFRLFlBQVcsV0FBVSwyQ0FBeUMsMkJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPakcsS0FBS2tHO0FBQUFBLGNBQ1o7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFVBQVUsQ0FBQS9HLE1BQUtvQyxVQUFVLEVBQUUyRSxNQUFNL0csRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDakQsV0FBVzRCLFlBQVkwRixPQUFPNUgsa0JBQWtCRDtBQUFBQSxjQUNoRCxjQUFhO0FBQUE7QUFBQSxZQVJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRc0I7QUFBQSxVQUV0Qix1QkFBQyxjQUFXLFNBQVNtQyxZQUFZMEYsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxhQWQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLGlDQUFDLFdBQU0sU0FBUSxxQkFBb0IsV0FBVSwyQ0FBeUMsNkJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPbEcsS0FBS21HO0FBQUFBLGNBQ1o7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFVBQVUsQ0FBQWhILE1BQUtvQyxVQUFVLEVBQUU0RSxlQUFlaEgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDMUQsV0FBVzRCLFlBQVkyRixnQkFBZ0I3SCxrQkFBa0JEO0FBQUFBLGNBQ3pELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVkyRixpQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxhQWRuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsZUFBYyxXQUFVLDJDQUF5Qyx5QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU9uRyxLQUFLb0c7QUFBQUEsY0FDWjtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osVUFBVSxDQUFBakgsTUFBS29DLFVBQVUsRUFBRTZFLFNBQVNqSCxFQUFFQyxPQUFPUixNQUFNLENBQUM7QUFBQSxjQUNwRCxXQUFXNEIsWUFBWTRGLFVBQVU5SCxrQkFBa0JEO0FBQUFBLGNBQ25ELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVk0RixXQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBZDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sU0FBUSxxQkFBb0IsV0FBVSwyQ0FBeUMsa0NBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPcEcsS0FBS2dGO0FBQUFBLGNBQ1o7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFVBQVUsQ0FBQTdGLE1BQUtvQyxVQUFVLEVBQUV5RCxlQUFlN0YsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDMUQsV0FBVzRCLFlBQVl3RSxnQkFBZ0IxRyxrQkFBa0JEO0FBQUFBLGNBQ3pELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEIsNERBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGNBQVcsU0FBU21DLFlBQVl3RSxpQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxhQWpCbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sU0FBUSxjQUFhLFdBQVUsMkNBQXlDLHVCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT2hGLEtBQUtxRztBQUFBQSxjQUNaO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUFsSCxNQUFLb0MsVUFBVSxFQUFFOEUsUUFBUWxILEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGNBQ25ELFdBQVc0QixZQUFZNkYsU0FBUy9ILGtCQUFrQkQ7QUFBQUEsY0FDbEQsY0FBYTtBQUFBO0FBQUEsWUFSakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXNCO0FBQUEsVUFFdEIsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixxREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUMvRSx1QkFBQyxjQUFXLFNBQVNtQyxZQUFZNkYsVUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0M7QUFBQSxhQWY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxTQUFRLGFBQVksV0FBVSwyQ0FBeUMsdUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPckcsS0FBS3NHO0FBQUFBLGNBQ1o7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFVBQVUsQ0FBQW5ILE1BQUtvQyxVQUFVLEVBQUUrRSxPQUFPbkgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDbEQsV0FBVzRCLFlBQVk4RixRQUFRaEksa0JBQWtCRDtBQUFBQSxjQUNqRCxjQUFhO0FBQUE7QUFBQSxZQVJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRc0I7QUFBQSxVQUV0Qix1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDJEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLGNBQVcsU0FBU21DLFlBQVk4RixTQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBZjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsWUFBVyxXQUFVLDJDQUF5QyxnQ0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU90RyxLQUFLdUc7QUFBQUEsY0FDWjtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osVUFBVSxDQUFBcEgsTUFBS29DLFVBQVUsRUFBRWdGLE1BQU1wSCxFQUFFQyxPQUFPUixNQUFNLENBQUM7QUFBQSxjQUNqRCxXQUFXNEIsWUFBWStGLE9BQU9qSSxrQkFBa0JEO0FBQUFBLGNBQ2hELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVkrRixRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLGFBZDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sU0FBUSxrQkFBaUIsV0FBVSwyQ0FBeUMsK0JBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPdkcsS0FBS3dHO0FBQUFBLGNBQ1o7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFVBQVUsQ0FBQXJILE1BQUtvQyxVQUFVLEVBQUVpRixZQUFZckgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDdkQsV0FBVzRCLFlBQVlnRyxhQUFhbEksa0JBQWtCRDtBQUFBQSxjQUN0RCxjQUFhO0FBQUE7QUFBQSxZQVJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRc0I7QUFBQSxVQUV0Qix1QkFBQyxjQUFXLFNBQVNtQyxZQUFZZ0csY0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxhQWRoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEseUJBQXdCLFdBQVUsMkNBQXlDLHFDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3hHLEtBQUt5RztBQUFBQSxjQUNaO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUF0SCxNQUFLb0MsVUFBVSxFQUFFa0YsbUJBQW1CdEgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDOUQsV0FBVzRCLFlBQVlpRyxvQkFBb0JuSSxrQkFBa0JEO0FBQUFBLGNBQzdELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVlpRyxxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxhQWR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEseUJBQXdCLFdBQVUsMkNBQXlDLDBCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3pHLEtBQUswRztBQUFBQSxjQUNaO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUF2SCxNQUFLb0MsVUFBVSxFQUFFbUYsbUJBQW1CdkgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDOUQsV0FBVzRCLFlBQVlrRyxvQkFBb0JwSSxrQkFBa0JEO0FBQUFBLGNBQzdELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVlrRyxxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxhQWR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsMkJBQTBCLFdBQVUsMkNBQXlDLCtCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBTzFHLEtBQUsyRztBQUFBQSxjQUNaO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixVQUFVLENBQUF4SCxNQUFLb0MsVUFBVSxFQUFFb0YscUJBQXFCeEgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDaEUsV0FBVzRCLFlBQVltRyxzQkFBc0JySSxrQkFBa0JEO0FBQUFBLGNBQy9ELGNBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFzQjtBQUFBLFVBRXRCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVltRyx1QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQWR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBTTtBQUFBLGNBQ04sT0FBTzNHLEtBQUs0RztBQUFBQSxjQUNaO0FBQUEsY0FDQSxVQUFVLENBQUF6SCxNQUFLb0MsVUFBVSxFQUFFcUYsc0JBQXNCekgsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDakUsV0FDSTRCLFlBQVlvRyx1QkFBdUJ0SSxrQkFBa0JEO0FBQUFBLGNBRXpELGNBQWE7QUFBQTtBQUFBLFlBVGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNzQjtBQUFBLFVBRXRCLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEIsMEZBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLGNBQVcsU0FBU21DLFlBQVlvRyx3QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxhQXRCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFdBN09KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4T0E7QUFBQSxTQXZQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd1BBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLFdBQVUsMkJBQ2Y7QUFBQSw2QkFBQyxRQUFHLFdBQVUsK0RBQTZELDZCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLCtCQUFDLFNBQ0c7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUTtBQUFBLGNBQ1IsV0FBVTtBQUFBLGNBQXlDO0FBQUE7QUFBQSxZQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU81RyxLQUFLNkc7QUFBQUEsY0FDWjtBQUFBLGNBQ0EsVUFBVSxDQUFBMUgsTUFBS29DLFVBQVUsRUFBRXNGLGdCQUFnQjFILEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGNBQzNELFdBQVc0QixZQUFZcUcsaUJBQWlCdkksa0JBQWtCRDtBQUFBQSxjQUFZLGNBQWE7QUFBQTtBQUFBLFlBTnZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU00RjtBQUFBLFVBQzVGLHVCQUFDLGNBQVcsU0FBU21DLFlBQVlxRyxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxhQWRwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxPQUFNO0FBQUEsWUFDTixPQUFPN0csS0FBSzhHO0FBQUFBLFlBQ1o7QUFBQSxZQUNBLFVBQVVmLFFBQVF2RixZQUFZc0csa0JBQWtCO0FBQUEsWUFDaEQsY0FBY3RHLFlBQVlzRztBQUFBQSxZQUMxQixVQUFVLENBQUFsSSxVQUFTMkMsVUFBVSxFQUFFdUYsb0JBQW9CbEksTUFBTSxDQUFDO0FBQUE7QUFBQSxVQVA5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPZ0U7QUFBQSxRQUVoRSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQXlDLG1DQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBV29CLEtBQUttQztBQUFBQSxjQUNoQixXQUFXbkMsS0FBS3FDO0FBQUFBLGNBQ2hCLGNBQWNnQztBQUFBQSxjQUNkLGNBQWMsTUFBTSxLQUFLRyx3QkFBd0I7QUFBQSxjQUNqRCxlQUFlLE1BQU03RCxzQkFBc0IsSUFBSTtBQUFBLGNBQy9DLGNBQWMsTUFDVlksVUFBVTtBQUFBLGdCQUNOUywwQkFBMEI7QUFBQSxnQkFDMUJHLDJCQUEyQjtBQUFBLGdCQUMzQkUsNEJBQTRCO0FBQUEsY0FDaEMsQ0FBQztBQUFBLGNBRUwsTUFBSztBQUFBLGNBQ0w7QUFBQSxjQUNBLFVBQVUwRCxRQUFRdkYsWUFBWXdCLHdCQUF3QjtBQUFBLGNBQ3REO0FBQUEsY0FDQSxvQkFBb0I7QUFBQSxnQkFDaEJFLFVBQVUzRixzQkFBc0IyRjtBQUFBQSxnQkFDaEM2RSxXQUFXO0FBQUEsZ0JBQ1hDLFdBQVc7QUFBQSxnQkFDWEMsY0FBYyxFQUFFckMsV0FBVyxLQUFLO0FBQUEsZ0JBQ2hDc0MsVUFBVUEsQ0FBQUMsU0FBUTVDLG9CQUFvQjRDLElBQWdCO0FBQUEsY0FDMUQ7QUFBQTtBQUFBLFlBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCTTtBQUFBLFVBRU4sdUJBQUMsT0FBRSxXQUFVLDhCQUE0Qix1RkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsY0FBVyxTQUFTM0csWUFBWXdCLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBaEM5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsV0EzREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQTtBQUFBLFNBaEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRUE7QUFBQSxJQUdBLHVCQUFDLGFBQVEsV0FBVSwyQkFDZjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrREFBNkQscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDRztBQUFBLCtCQUFDLFVBQUssV0FBVSwyQ0FBeUMsaUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsbUNBQUMsV0FBTSxTQUFRLGFBQVksV0FBVSxXQUFTLG9CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU9oQyxLQUFLb0g7QUFBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxVQUFVLENBQUFqSSxNQUFLb0MsVUFBVSxFQUFFNkYsV0FBV2pJLEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGdCQUN0RCxXQUFXNEIsWUFBWTRHLFlBQVk5SSxrQkFBa0JEO0FBQUFBLGdCQUFZLGNBQWE7QUFBQTtBQUFBLGNBUGxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU91RjtBQUFBLFlBQ3ZGLHVCQUFDLGNBQVcsU0FBU21DLFlBQVk0RyxhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLGVBWi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFNBQVEsYUFBWSxXQUFVLFdBQVMsc0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLE9BQU9wSCxLQUFLaUY7QUFBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxVQUFVLENBQUE5RixNQUFLb0MsVUFBVSxFQUFFMEQsV0FBVzlGLEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGdCQUN0RCxXQUFXNEIsWUFBWXlFLFlBQVkzRyxrQkFBa0JEO0FBQUFBLGdCQUFZLGNBQWE7QUFBQTtBQUFBLGNBUmxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVF1RjtBQUFBLFlBQ3ZGLHVCQUFDLGNBQVcsU0FBU21DLFlBQVl5RSxhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLGVBYi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsV0FsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsT0FBT2pGLEtBQUtxSDtBQUFBQSxjQUNaO0FBQUEsY0FDQSxVQUFVLENBQUFsSSxNQUNOb0MsVUFBVTtBQUFBLGdCQUNOOEYsaUJBQWlCbEksRUFBRUMsT0FBT1I7QUFBQUEsY0FDOUIsQ0FBQztBQUFBLGNBRUwsV0FBVzRCLFlBQVk2RyxrQkFBa0IvSSxrQkFBa0JEO0FBQUFBLGNBRTFEckIsa0NBQXdCc0s7QUFBQUEsZ0JBQUksQ0FBQUMsUUFDekIsdUJBQUMsWUFBaUMsT0FBT0EsSUFBSTNJLE9BQ3hDMkksY0FBSTVJLFNBREk0SSxJQUFJM0ksU0FBUyxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDSDtBQUFBO0FBQUEsWUFmTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQkE7QUFBQSxVQUNBLHVCQUFDLGNBQVcsU0FBUzRCLFlBQVk2RyxtQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxhQXhCckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3JILEtBQUsrRTtBQUFBQSxjQUNaO0FBQUEsY0FDQSxVQUFVLENBQUE1RixNQUFLb0MsVUFBVSxFQUFFd0QsbUJBQW1CNUYsRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDOUQsV0FDSTRCLFlBQVl1RSxvQkFBb0J6RyxrQkFBa0JEO0FBQUFBLGNBQ3BELGNBQWE7QUFBQTtBQUFBLFlBUm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVF3QjtBQUFBLFVBQ3hCLHVCQUFDLGNBQVcsU0FBU21DLFlBQVl1RSxxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxhQWhCdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBTy9FLEtBQUt3SDtBQUFBQSxjQUNaO0FBQUEsY0FDQSxVQUFVLENBQUFySSxNQUFLb0MsVUFBVSxFQUFFaUcsZ0JBQWdCckksRUFBRUMsT0FBT1IsTUFBTSxDQUFDO0FBQUEsY0FDM0QsV0FBVzRCLFlBQVlnSCxpQkFBaUJsSixrQkFBa0JEO0FBQUFBLGNBQVksY0FBYTtBQUFBO0FBQUEsWUFOdkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTRGO0FBQUEsVUFDNUYsdUJBQUMsY0FBVyxTQUFTbUMsWUFBWWdILGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLGFBZHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3hILEtBQUt5SDtBQUFBQSxjQUNaO0FBQUEsY0FDQSxjQUFhO0FBQUEsY0FDYixVQUFVLENBQUF0SSxNQUFLb0MsVUFBVSxFQUFFa0csZUFBZXRJLEVBQUVDLE9BQU9SLE1BQU0sQ0FBQztBQUFBLGNBQzFELFdBQVc0QixZQUFZaUgsZ0JBQWdCbkosa0JBQWtCRDtBQUFBQTtBQUFBQSxZQVA3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPd0U7QUFBQSxVQUV4RSx1QkFBQyxjQUFXLFNBQVNtQyxZQUFZaUgsaUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsYUFoQm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFHO0FBQUEsWUFDSCxPQUFNO0FBQUEsWUFDTixPQUFPekgsS0FBSzBIO0FBQUFBLFlBQ1o7QUFBQSxZQUNBLFVBQVUzQixRQUFRdkYsWUFBWWtILGFBQWE7QUFBQSxZQUMzQyxjQUFjbEgsWUFBWWtIO0FBQUFBLFlBQzFCLFVBQVUsQ0FBQTlJLFVBQVMyQyxVQUFVLEVBQUVtRyxlQUFlOUksTUFBTSxDQUFDO0FBQUE7QUFBQSxVQVB6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPMkQ7QUFBQSxXQXRGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdGQTtBQUFBLFNBaklKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrSUE7QUFBQSxJQUdBLHVCQUFDLGFBQVEsV0FBVSwyQkFDZjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrREFBNkQsMkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBLFlBQXlDO0FBQUE7QUFBQSxVQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLElBQUc7QUFBQSxZQUNIO0FBQUEsWUFDQSxPQUFPb0IsS0FBS3FGO0FBQUFBLFlBQ1osV0FBVztBQUFBLFlBQ1gsZUFBZTtBQUFBLFlBQ2Y7QUFBQSxZQUNBLEtBQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLFVBQVUsQ0FBQXNDLFFBQU9wRyxVQUFVLEVBQUU4RCxvQkFBb0JzQyxJQUFJLENBQUM7QUFBQSxZQUN0RCxXQUNJbkgsWUFBWTZFLHFCQUFxQi9HLGtCQUFrQkQ7QUFBQUE7QUFBQUEsVUFYM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUs7QUFBQSxRQUVMLHVCQUFDLGNBQVcsU0FBU21DLFlBQVk2RSxzQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFdBckJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsU0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLElBR0EsdUJBQUMsYUFBUSxXQUFVLDJCQUNmO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtEQUE2RCwyQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSwrQkFBQyxTQUNHO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVE7QUFBQSxjQUNSLFdBQVU7QUFBQSxjQUF5QztBQUFBO0FBQUEsWUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDUnJFLHlCQUNLLCtCQUErQkEsYUFBYXNCLElBQUksd0JBQ2hEdEMsS0FBSzRILGdCQUNILHlCQUNBLHNCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxLQUFLdkc7QUFBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUDtBQUFBLGNBQ0EsVUFBVW9DO0FBQUFBLGNBQ1YsY0FBYTtBQUFBLGNBQU0sV0FBVTtBQUFBO0FBQUEsWUFQakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT3NUO0FBQUEsVUFFdFQsdUJBQUMsT0FBRSxXQUFVLDhCQUNSekQsZUFBSzRILGdCQUNBLGtHQUNBLDRDQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLGNBQVcsU0FBU3BILFlBQVl1QyxhQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLGFBNUIvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVE7QUFBQSxjQUNSLFdBQVU7QUFBQSxjQUF5QztBQUFBO0FBQUEsWUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDUjdCLHdCQUNLLCtCQUErQkEsWUFBWW9CLElBQUksd0JBQy9DdEMsS0FBSzZILGVBQ0gsbUJBQ0EsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLEtBQUt2RztBQUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQO0FBQUEsY0FDQSxVQUFVeUM7QUFBQUEsY0FDVixjQUFhO0FBQUEsY0FBTSxXQUFVO0FBQUE7QUFBQSxZQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPc1Q7QUFBQSxVQUV0VCx1QkFBQyxPQUFFLFdBQVUsOEJBQ1IvRCxlQUFLNkgsZUFDQSwyRkFDQSxxQ0FIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxjQUFXLFNBQVNySCxZQUFZeUMsWUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQTVCOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQTtBQUFBLFdBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2REE7QUFBQSxTQWpFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0VBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFNBQVMsTUFBTSxLQUFLdUMsV0FBVztBQUFBLFFBQy9CO0FBQUEsUUFDQSxXQUFVO0FBQUEsUUFFVGxGO0FBQUFBLG1CQUNHLHVCQUFDLGFBQVUsV0FBVSwrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0QsSUFFaEQsdUJBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQ25DO0FBQUE7QUFBQTtBQUFBLE1BVkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUEsS0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUVDSSxzQkFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUUE7QUFBQUEsUUFDUixTQUFTLE1BQU1DLHNCQUFzQixLQUFLO0FBQUEsUUFDMUMsVUFBVSxDQUFBd0csU0FBUTVDLG9CQUFvQjRDLElBQWdCO0FBQUEsUUFDdEQsUUFBUTtBQUFBLFVBQ0osR0FBRzVLO0FBQUFBLFVBQ0h1TCxnQkFBZ0IsRUFBRWxELFdBQVcsS0FBSztBQUFBLFFBQ3RDO0FBQUE7QUFBQSxNQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9NO0FBQUEsT0FocUJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtcUJBO0FBRVI7QUFBRTlFLElBdmpDV0QseUJBQXVCO0FBQUEsVUFDUjlDLGVBQWU7QUFBQTtBQUFBZ0wsTUFEOUJsSTtBQUF1QixJQUFBckIsSUFBQWMsS0FBQU0sS0FBQW1JO0FBQUFDLGFBQUF4SixJQUFBO0FBQUF3SixhQUFBMUksS0FBQTtBQUFBMEksYUFBQXBJLEtBQUE7QUFBQW9JLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiRmFFeWUiLCJGYUV5ZVNsYXNoIiwiRmFTYXZlIiwiRmFTcGlubmVyIiwidG9hc3QiLCJEZWNpbWFsSW5wdXQiLCJSZWxhdGlvbmFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsIkxvYWRpbmdTcGlubmVyIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiZ2V0QnlJZCIsInNlYXJjaEJ5RmllbGQiLCJidWlsZE9yZ2FuaXphdGlvbkRldGFpbHNQYXlsb2FkIiwiZmV0Y2hPcmdhbml6YXRpb25EZXRhaWxzIiwib3JnYW5pemF0aW9uRGV0YWlsc1RvRm9ybVN0YXRlIiwidXBkYXRlT3JnYW5pemF0aW9uRGV0YWlscyIsImlzVmFsaWRTaW5nbGVFbWFpbCIsInVzZU9yZ2FuaXphdGlvbiIsIk1BSUxfRU5DUllQVElPTl9PUFRJT05TIiwiZW1wdHlPcmdhbml6YXRpb25EZXRhaWxzRm9ybSIsIkRFRkFVTFRfUFJJTUFSWV9DT0xPUiIsIkRFRkFVTFRfU0VDT05EQVJZX0NPTE9SIiwiaXNWYWxpZEJyYW5kSGV4Q29sb3IiLCJwYXJzZUFwaUZpZWxkRXJyb3JzIiwiZXJyb3IiLCJkYXRhIiwicmVzcG9uc2UiLCJlcnJvcnMiLCJtYXBwZWQiLCJmaWVsZCIsIm1lc3NhZ2VzIiwiT2JqZWN0IiwiZW50cmllcyIsIkFycmF5IiwiaXNBcnJheSIsInBhcnNlQXBpTWVzc2FnZSIsIm1lc3NhZ2UiLCJ0cmltIiwiRXJyb3IiLCJpbnB1dENsYXNzIiwiaW5wdXRFcnJvckNsYXNzIiwiRmllbGRFcnJvciIsIl9jIiwiQnJhbmRDb2xvckZpZWxkIiwiaWQiLCJsYWJlbCIsInZhbHVlIiwiZGlzYWJsZWQiLCJoYXNFcnJvciIsImVycm9yTWVzc2FnZSIsImZhbGxiYWNrIiwib25DaGFuZ2UiLCJwaWNrZXJWYWx1ZSIsImUiLCJ0YXJnZXQiLCJ0b1VwcGVyQ2FzZSIsIl9jMiIsIlBhc3N3b3JkRmllbGQiLCJfcyIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidiIsIl9jMyIsIk9yZ2FuaXphdGlvbkRldGFpbHNQYWdlIiwiX3MyIiwic2V0QnJhbmRpbmciLCJmb3JtIiwic2V0Rm9ybSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibG9hZEVycm9yIiwic2V0TG9hZEVycm9yIiwic2F2aW5nIiwic2V0U2F2aW5nIiwiZmllbGRFcnJvcnMiLCJzZXRGaWVsZEVycm9ycyIsImlzUHJvZHVjdE1vZGFsT3BlbiIsInNldElzUHJvZHVjdE1vZGFsT3BlbiIsImxvZ29GaWxlIiwic2V0TG9nb0ZpbGUiLCJsb2dvUHJldmlld1VybCIsInNldExvZ29QcmV2aWV3VXJsIiwiYWZpcENlcnRGaWxlIiwic2V0QWZpcENlcnRGaWxlIiwiYWZpcEtleUZpbGUiLCJzZXRBZmlwS2V5RmlsZSIsImZpbGVJbnB1dFJlZiIsImFmaXBDZXJ0SW5wdXRSZWYiLCJhZmlwS2V5SW5wdXRSZWYiLCJwYXRjaEZvcm0iLCJwYXRjaCIsInByZXYiLCJuZXh0Iiwia2V5Iiwia2V5cyIsImxvYWQiLCJkZXRhaWxzIiwibmV4dEZvcm0iLCJtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQiLCJwcm9kdWN0IiwiZW5kcG9pbnQiLCJtZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1Iiwic2t1IiwibWVsaV9zaGlwcGluZ19wcm9kdWN0X25hbWUiLCJuYW1lIiwiY29uc29sZSIsIndhcm4iLCJjdXJyZW50IiwiVVJMIiwicmV2b2tlT2JqZWN0VVJMIiwiY2xlYXJMb2dvU2VsZWN0aW9uIiwibG9nbyIsImNsZWFyQWZpcENlcnRTZWxlY3Rpb24iLCJhZmlwX2NlcnQiLCJjbGVhckFmaXBLZXlTZWxlY3Rpb24iLCJhZmlwX2tleSIsImZpbGVFeHRlbnNpb24iLCJmaWxlbmFtZSIsInBhcnRzIiwidG9Mb3dlckNhc2UiLCJzcGxpdCIsImxlbmd0aCIsInBvcCIsImhhbmRsZUFmaXBDZXJ0Q2hhbmdlIiwiZmlsZSIsImZpbGVzIiwiZXh0IiwibWF4U2l6ZSIsInNpemUiLCJoYW5kbGVBZmlwS2V5Q2hhbmdlIiwiaGFuZGxlTG9nb0NoYW5nZSIsImFsbG93ZWRUeXBlcyIsImluY2x1ZGVzIiwidHlwZSIsImNyZWF0ZU9iamVjdFVSTCIsImhhbmRsZVByb2R1Y3RDb2RlQ2hhbmdlIiwiY29kZSIsImhhbmRsZVByb2R1Y3RTZWxlY3QiLCJoYW5kbGVQcm9kdWN0Q29kZVN1Ym1pdCIsImNvZGVWYWx1ZSIsInJlc3VsdCIsImZpZWxkTmFtZSIsImlzX2FjdGl2ZSIsInN1Y2Nlc3MiLCJ2YWxpZGF0ZUNsaWVudCIsIm1haWxfZnJvbV9hZGRyZXNzIiwiY29udGFjdF9lbWFpbCIsIm1haWxfcG9ydCIsInBvcnQiLCJOdW1iZXIiLCJpc0ludGVnZXIiLCJmY2VfbWluaW11bV9hbW91bnQiLCJwcmltYXJ5X2NvbG9yIiwic2Vjb25kYXJ5X2NvbG9yIiwiaGFuZGxlU2F2ZSIsImNsaWVudEVycm9ycyIsInBheWxvYWQiLCJ1cGRhdGVkIiwibG9nb191cmwiLCJhcGlFcnJvcnMiLCJkaXNwbGF5ZWRMb2dvVXJsIiwiQm9vbGVhbiIsImFjdGl2aXR5IiwiYWRkcmVzcyIsImNpdHkiLCJpdmFfY29uZGl0aW9uIiwid2Vic2l0ZSIsIm1vYmlsZSIsInBob25lIiwiY3VpdCIsImluZ19icnV0b3MiLCJmaXNjYWxfc3RhcnRfZGF0ZSIsInJlbWl0b19jYWlfbnVtYmVyIiwicmVtaXRvX2NhaV9kdWVfZGF0ZSIsInBheW1lbnRfbGVnYWxfbGVnZW5kIiwibWVsaV9jbGllbnRfaWQiLCJtZWxpX2NsaWVudF9zZWNyZXQiLCJjb2RlRmllbGQiLCJuYW1lRmllbGQiLCJzZWFyY2hQYXJhbXMiLCJvblNlbGVjdCIsIml0ZW0iLCJtYWlsX2hvc3QiLCJtYWlsX2VuY3J5cHRpb24iLCJtYXAiLCJvcHQiLCJtYWlsX2Zyb21fbmFtZSIsIm1haWxfdXNlcm5hbWUiLCJtYWlsX3Bhc3N3b3JkIiwibnVtIiwiaGFzX2FmaXBfY2VydCIsImhhc19hZmlwX2tleSIsImluaXRpYWxGaWx0ZXJzIiwiX2M0IiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk9yZ2FuaXphdGlvbkRldGFpbHNQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRmFFeWUsIEZhRXllU2xhc2gsIEZhU2F2ZSwgRmFTcGlubmVyIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBEZWNpbWFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9EZWNpbWFsSW5wdXQnO1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IFNlYXJjaE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZywgdHlwZSBBcnRpY3VsbyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJztcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaEJ5RmllbGQgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7XG4gICAgYnVpbGRPcmdhbml6YXRpb25EZXRhaWxzUGF5bG9hZCxcbiAgICBmZXRjaE9yZ2FuaXphdGlvbkRldGFpbHMsXG4gICAgb3JnYW5pemF0aW9uRGV0YWlsc1RvRm9ybVN0YXRlLFxuICAgIHVwZGF0ZU9yZ2FuaXphdGlvbkRldGFpbHMsXG59IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL29yZ2FuaXphdGlvbkRldGFpbHNTZXJ2aWNlJztcbmltcG9ydCB7IGlzVmFsaWRTaW5nbGVFbWFpbCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2VtYWlsVmFsaWRhdGlvbic7XG5pbXBvcnQgeyB1c2VPcmdhbml6YXRpb24gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VPcmdhbml6YXRpb24nO1xuaW1wb3J0IHtcbiAgICBNQUlMX0VOQ1JZUFRJT05fT1BUSU9OUyxcbiAgICBlbXB0eU9yZ2FuaXphdGlvbkRldGFpbHNGb3JtLFxuICAgIHR5cGUgTWFpbEVuY3J5cHRpb24sXG4gICAgdHlwZSBPcmdhbml6YXRpb25EZXRhaWxzRm9ybVN0YXRlLFxufSBmcm9tICcuLi9vcmdhbml6YXRpb25EZXRhaWxzLnR5cGVzJztcbmltcG9ydCB7XG4gICAgREVGQVVMVF9QUklNQVJZX0NPTE9SLFxuICAgIERFRkFVTFRfU0VDT05EQVJZX0NPTE9SLFxuICAgIGlzVmFsaWRCcmFuZEhleENvbG9yLFxufSBmcm9tICcuLi8uLi8uLi9jb250ZXh0L29yZ2FuaXphdGlvbkJyYW5kaW5nJztcblxudHlwZSBGaWVsZEVycm9ycyA9IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG5cbmZ1bmN0aW9uIHBhcnNlQXBpRmllbGRFcnJvcnMoZXJyb3I6IHVua25vd24pOiBGaWVsZEVycm9ycyB7XG4gICAgaWYgKCFlcnJvciB8fCB0eXBlb2YgZXJyb3IgIT09ICdvYmplY3QnIHx8ICEoJ3Jlc3BvbnNlJyBpbiBlcnJvcikpIHJldHVybiB7fTtcbiAgICBjb25zdCBkYXRhID0gKGVycm9yIGFzIHsgcmVzcG9uc2U/OiB7IGRhdGE/OiB7IGVycm9ycz86IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiB9IH0gfSkucmVzcG9uc2VcbiAgICAgICAgPy5kYXRhO1xuICAgIGlmICghZGF0YT8uZXJyb3JzIHx8IHR5cGVvZiBkYXRhLmVycm9ycyAhPT0gJ29iamVjdCcpIHJldHVybiB7fTtcbiAgICBjb25zdCBtYXBwZWQ6IEZpZWxkRXJyb3JzID0ge307XG4gICAgZm9yIChjb25zdCBbZmllbGQsIG1lc3NhZ2VzXSBvZiBPYmplY3QuZW50cmllcyhkYXRhLmVycm9ycykpIHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobWVzc2FnZXMpICYmIG1lc3NhZ2VzWzBdKSB7XG4gICAgICAgICAgICBtYXBwZWRbZmllbGRdID0gbWVzc2FnZXNbMF07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG1hcHBlZDtcbn1cblxuZnVuY3Rpb24gcGFyc2VBcGlNZXNzYWdlKGVycm9yOiB1bmtub3duKTogc3RyaW5nIHtcbiAgICBpZiAoZXJyb3IgJiYgdHlwZW9mIGVycm9yID09PSAnb2JqZWN0JyAmJiAncmVzcG9uc2UnIGluIGVycm9yKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSAoZXJyb3IgYXMgeyByZXNwb25zZT86IHsgZGF0YT86IHsgbWVzc2FnZT86IHN0cmluZyB9IH0gfSkucmVzcG9uc2U/LmRhdGE7XG4gICAgICAgIGlmICh0eXBlb2YgZGF0YT8ubWVzc2FnZSA9PT0gJ3N0cmluZycgJiYgZGF0YS5tZXNzYWdlLnRyaW0oKSkge1xuICAgICAgICAgICAgcmV0dXJuIGRhdGEubWVzc2FnZS50cmltKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubWVzc2FnZSkgcmV0dXJuIGVycm9yLm1lc3NhZ2U7XG4gICAgcmV0dXJuICdObyBzZSBwdWRvIGd1YXJkYXIgbGEgY29uZmlndXJhY2nDs24uJztcbn1cblxuY29uc3QgaW5wdXRDbGFzcyA9XG4gICAgJ210LTEgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBweC0zIHB5LTIgdGV4dC1zbSBzaGFkb3ctc20gZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgZm9jdXM6cmluZy1pbmRpZ28tNTAwJztcbmNvbnN0IGlucHV0RXJyb3JDbGFzcyA9XG4gICAgJ210LTEgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHB4LTMgcHktMiB0ZXh0LXNtIHNoYWRvdy1zbSBmb2N1czpib3JkZXItcmVkLTUwMCBmb2N1czpyaW5nLXJlZC01MDAnO1xuXG5mdW5jdGlvbiBGaWVsZEVycm9yKHsgbWVzc2FnZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSkge1xuICAgIGlmICghbWVzc2FnZSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC02MDBcIj57bWVzc2FnZX08L3A+O1xufVxuXG5mdW5jdGlvbiBCcmFuZENvbG9yRmllbGQoe1xuICAgIGlkLFxuICAgIGxhYmVsLFxuICAgIHZhbHVlLFxuICAgIGRpc2FibGVkLFxuICAgIGhhc0Vycm9yLFxuICAgIGVycm9yTWVzc2FnZSxcbiAgICBmYWxsYmFjayxcbiAgICBvbkNoYW5nZSxcbn06IHtcbiAgICBpZDogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgdmFsdWU6IHN0cmluZztcbiAgICBkaXNhYmxlZD86IGJvb2xlYW47XG4gICAgaGFzRXJyb3I/OiBib29sZWFuO1xuICAgIGVycm9yTWVzc2FnZT86IHN0cmluZztcbiAgICBmYWxsYmFjazogc3RyaW5nO1xuICAgIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgICBjb25zdCBwaWNrZXJWYWx1ZSA9IGlzVmFsaWRCcmFuZEhleENvbG9yKHZhbHVlKSA/IHZhbHVlIDogZmFsbGJhY2s7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2lkfSBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPXtgJHtpZH0tcGlja2VyYH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNvbG9yXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BpY2tlclZhbHVlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IG9uQ2hhbmdlKGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHctMTIgY3Vyc29yLXBvaW50ZXIgcm91bmRlZCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHAtMSBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2Ake2xhYmVsfSAoc2VsZWN0b3IpYH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICBpZD17aWR9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmYWxsYmFja31cbiAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs3fVxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBvbkNoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aGFzRXJyb3IgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Rm9ybWF0byAjUlJHR0JCLiBWYWPDrW8gdXNhIGVsIGRlZmF1bHQgKHtmYWxsYmFja30pLjwvcD5cbiAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxuZnVuY3Rpb24gUGFzc3dvcmRGaWVsZCh7XG4gICAgaWQsXG4gICAgbGFiZWwsXG4gICAgdmFsdWUsXG4gICAgZGlzYWJsZWQsXG4gICAgaGFzRXJyb3IsXG4gICAgZXJyb3JNZXNzYWdlLFxuICAgIG9uQ2hhbmdlLFxufToge1xuICAgIGlkOiBzdHJpbmc7XG4gICAgbGFiZWw6IHN0cmluZztcbiAgICB2YWx1ZTogc3RyaW5nO1xuICAgIGRpc2FibGVkPzogYm9vbGVhbjtcbiAgICBoYXNFcnJvcj86IGJvb2xlYW47XG4gICAgZXJyb3JNZXNzYWdlPzogc3RyaW5nO1xuICAgIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2lkfSBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPXtpZH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT17dmlzaWJsZSA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBvbkNoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aGFzRXJyb3IgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfSBwci0xMGB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlzaWJsZSh2ID0+ICF2KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt2aXNpYmxlID8gJ09jdWx0YXInIDogJ01vc3RyYXInfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGUgPyA8RmFFeWVTbGFzaCAvPiA6IDxGYUV5ZSAvPn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZXJyb3JNZXNzYWdlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuXG5leHBvcnQgY29uc3QgT3JnYW5pemF0aW9uRGV0YWlsc1BhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBzZXRCcmFuZGluZyB9ID0gdXNlT3JnYW5pemF0aW9uKCk7XG4gICAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGU8T3JnYW5pemF0aW9uRGV0YWlsc0Zvcm1TdGF0ZT4oZW1wdHlPcmdhbml6YXRpb25EZXRhaWxzRm9ybSk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2xvYWRFcnJvciwgc2V0TG9hZEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2ZpZWxkRXJyb3JzLCBzZXRGaWVsZEVycm9yc10gPSB1c2VTdGF0ZTxGaWVsZEVycm9ycz4oe30pO1xuICAgIGNvbnN0IFtpc1Byb2R1Y3RNb2RhbE9wZW4sIHNldElzUHJvZHVjdE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2xvZ29GaWxlLCBzZXRMb2dvRmlsZV0gPSB1c2VTdGF0ZTxGaWxlIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2xvZ29QcmV2aWV3VXJsLCBzZXRMb2dvUHJldmlld1VybF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbYWZpcENlcnRGaWxlLCBzZXRBZmlwQ2VydEZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFthZmlwS2V5RmlsZSwgc2V0QWZpcEtleUZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IGZpbGVJbnB1dFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgICBjb25zdCBhZmlwQ2VydElucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IGFmaXBLZXlJbnB1dFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcblxuICAgIGNvbnN0IHBhdGNoRm9ybSA9IHVzZUNhbGxiYWNrKChwYXRjaDogUGFydGlhbDxPcmdhbml6YXRpb25EZXRhaWxzRm9ybVN0YXRlPikgPT4ge1xuICAgICAgICBzZXRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgLi4ucGF0Y2ggfSkpO1xuICAgICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSB7IC4uLnByZXYgfTtcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHBhdGNoKSkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBuZXh0W2tleV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgbG9hZCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgc2V0TG9hZEVycm9yKG51bGwpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZGV0YWlscyA9IGF3YWl0IGZldGNoT3JnYW5pemF0aW9uRGV0YWlscygpO1xuICAgICAgICAgICAgY29uc3QgbmV4dEZvcm0gPSBvcmdhbml6YXRpb25EZXRhaWxzVG9Gb3JtU3RhdGUoZGV0YWlscyk7XG5cbiAgICAgICAgICAgIGlmIChkZXRhaWxzLm1lbGlfc2hpcHBpbmdfcHJvZHVjdF9pZCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHByb2R1Y3QgPSBhd2FpdCBnZXRCeUlkPEFydGljdWxvPihcbiAgICAgICAgICAgICAgICAgICAgICAgIGFydGljdWxvc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRldGFpbHMubWVsaV9zaGlwcGluZ19wcm9kdWN0X2lkXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIG5leHRGb3JtLm1lbGlfc2hpcHBpbmdfcHJvZHVjdF9za3UgPSBwcm9kdWN0LnNrdSA/PyAnJztcbiAgICAgICAgICAgICAgICAgICAgbmV4dEZvcm0ubWVsaV9zaGlwcGluZ19wcm9kdWN0X25hbWUgPSBwcm9kdWN0Lm5hbWUgPz8gJyc7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC53YXJuKCdObyBzZSBwdWRvIGNhcmdhciBlbCBQcm9kdWN0byBGbGV0ZSBNRUxJIGFzb2NpYWRvLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2V0Rm9ybShuZXh0Rm9ybSk7XG4gICAgICAgICAgICBzZXRMb2dvRmlsZShudWxsKTtcbiAgICAgICAgICAgIHNldExvZ29QcmV2aWV3VXJsKG51bGwpO1xuICAgICAgICAgICAgc2V0QWZpcENlcnRGaWxlKG51bGwpO1xuICAgICAgICAgICAgc2V0QWZpcEtleUZpbGUobnVsbCk7XG4gICAgICAgICAgICBzZXRGaWVsZEVycm9ycyh7fSk7XG4gICAgICAgICAgICBpZiAoZmlsZUlucHV0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgICAgICBmaWxlSW5wdXRSZWYuY3VycmVudC52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGFmaXBDZXJ0SW5wdXRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGFmaXBDZXJ0SW5wdXRSZWYuY3VycmVudC52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGFmaXBLZXlJbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgYWZpcEtleUlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSAnJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIHNldExvYWRFcnJvcignTm8gc2UgcHVkbyBjYXJnYXIgbGEgY29uZmlndXJhY2nDs24gZGVsIHNpc3RlbWEuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH0sIFtdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHZvaWQgbG9hZCgpO1xuICAgIH0sIFtsb2FkXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGxvZ29QcmV2aWV3VXJsKSB7XG4gICAgICAgICAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChsb2dvUHJldmlld1VybCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSwgW2xvZ29QcmV2aWV3VXJsXSk7XG5cbiAgICBjb25zdCBjbGVhckxvZ29TZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIHNldExvZ29GaWxlKG51bGwpO1xuICAgICAgICBzZXRMb2dvUHJldmlld1VybChwcmV2ID0+IHtcbiAgICAgICAgICAgIGlmIChwcmV2KSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXYpO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoZmlsZUlucHV0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGZpbGVJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gJyc7XG4gICAgICAgIH1cbiAgICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgbmV4dC5sb2dvO1xuICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgIH0pO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGNsZWFyQWZpcENlcnRTZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIHNldEFmaXBDZXJ0RmlsZShudWxsKTtcbiAgICAgICAgaWYgKGFmaXBDZXJ0SW5wdXRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgYWZpcENlcnRJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gJyc7XG4gICAgICAgIH1cbiAgICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgbmV4dC5hZmlwX2NlcnQ7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgY2xlYXJBZmlwS2V5U2VsZWN0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBzZXRBZmlwS2V5RmlsZShudWxsKTtcbiAgICAgICAgaWYgKGFmaXBLZXlJbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBhZmlwS2V5SW5wdXRSZWYuY3VycmVudC52YWx1ZSA9ICcnO1xuICAgICAgICB9XG4gICAgICAgIHNldEZpZWxkRXJyb3JzKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHsgLi4ucHJldiB9O1xuICAgICAgICAgICAgZGVsZXRlIG5leHQuYWZpcF9rZXk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgZmlsZUV4dGVuc2lvbiA9IChmaWxlbmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgICAgY29uc3QgcGFydHMgPSBmaWxlbmFtZS50b0xvd2VyQ2FzZSgpLnNwbGl0KCcuJyk7XG4gICAgICAgIHJldHVybiBwYXJ0cy5sZW5ndGggPiAxID8gKHBhcnRzLnBvcCgpID8/ICcnKSA6ICcnO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBZmlwQ2VydENoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICAgICAgaWYgKCFmaWxlKSB7XG4gICAgICAgICAgICBjbGVhckFmaXBDZXJ0U2VsZWN0aW9uKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBleHQgPSBmaWxlRXh0ZW5zaW9uKGZpbGUubmFtZSk7XG4gICAgICAgIGNvbnN0IG1heFNpemUgPSAxMDI0ICogMTAyNDsgLy8gMSBNQlxuXG4gICAgICAgIGlmIChleHQgIT09ICdjcnQnICYmIGV4dCAhPT0gJ3BlbScpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdUaXBvIGRlIGFyY2hpdm8gbm8gcGVybWl0aWRvLiBTb2xvIC5jcnQgbyAucGVtLicpO1xuICAgICAgICAgICAgY2xlYXJBZmlwQ2VydFNlbGVjdGlvbigpO1xuICAgICAgICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgYWZpcF9jZXJ0OiAnU29sbyBzZSBwZXJtaXRlbiBhcmNoaXZvcyAuY3J0IG8gLnBlbS4nLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZpbGUuc2l6ZSA+IG1heFNpemUpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBjZXJ0aWZpY2FkbyBleGNlZGUgZWwgdGFtYcOxbyBtw6F4aW1vIGRlIDFNQi4nKTtcbiAgICAgICAgICAgIGNsZWFyQWZpcENlcnRTZWxlY3Rpb24oKTtcbiAgICAgICAgICAgIHNldEZpZWxkRXJyb3JzKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIGFmaXBfY2VydDogJ0VsIGNlcnRpZmljYWRvIG5vIHB1ZWRlIHN1cGVyYXIgMSBNQi4nLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0QWZpcENlcnRGaWxlKGZpbGUpO1xuICAgICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSB7IC4uLnByZXYgfTtcbiAgICAgICAgICAgIGRlbGV0ZSBuZXh0LmFmaXBfY2VydDtcbiAgICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQWZpcEtleUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICAgICAgaWYgKCFmaWxlKSB7XG4gICAgICAgICAgICBjbGVhckFmaXBLZXlTZWxlY3Rpb24oKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGV4dCA9IGZpbGVFeHRlbnNpb24oZmlsZS5uYW1lKTtcbiAgICAgICAgY29uc3QgbWF4U2l6ZSA9IDEwMjQgKiAxMDI0OyAvLyAxIE1CXG5cbiAgICAgICAgaWYgKGV4dCAhPT0gJ2tleScpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdUaXBvIGRlIGFyY2hpdm8gbm8gcGVybWl0aWRvLiBTb2xvIC5rZXkuJyk7XG4gICAgICAgICAgICBjbGVhckFmaXBLZXlTZWxlY3Rpb24oKTtcbiAgICAgICAgICAgIHNldEZpZWxkRXJyb3JzKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgIGFmaXBfa2V5OiAnU29sbyBzZSBwZXJtaXRlbiBhcmNoaXZvcyAua2V5LicsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmlsZS5zaXplID4gbWF4U2l6ZSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0xhIGNsYXZlIGV4Y2VkZSBlbCB0YW1hw7FvIG3DoXhpbW8gZGUgMU1CLicpO1xuICAgICAgICAgICAgY2xlYXJBZmlwS2V5U2VsZWN0aW9uKCk7XG4gICAgICAgICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICBhZmlwX2tleTogJ0xhIGNsYXZlIG5vIHB1ZWRlIHN1cGVyYXIgMSBNQi4nLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0QWZpcEtleUZpbGUoZmlsZSk7XG4gICAgICAgIHNldEZpZWxkRXJyb3JzKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHsgLi4ucHJldiB9O1xuICAgICAgICAgICAgZGVsZXRlIG5leHQuYWZpcF9rZXk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUxvZ29DaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgICAgIGlmICghZmlsZSkge1xuICAgICAgICAgICAgY2xlYXJMb2dvU2VsZWN0aW9uKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhbGxvd2VkVHlwZXMgPSBbJ2ltYWdlL2pwZWcnLCAnaW1hZ2UvcG5nJywgJ2ltYWdlL2pwZycsICdpbWFnZS93ZWJwJ107XG4gICAgICAgIGNvbnN0IG1heFNpemUgPSAyMDQ4ICogMTAyNDsgLy8gMiBNQlxuXG4gICAgICAgIGlmICghYWxsb3dlZFR5cGVzLmluY2x1ZGVzKGZpbGUudHlwZSkpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdUaXBvIGRlIGFyY2hpdm8gbm8gcGVybWl0aWRvLiBTb2xvIEpQRywgUE5HIG8gV0VCUC4nKTtcbiAgICAgICAgICAgIGNsZWFyTG9nb1NlbGVjdGlvbigpO1xuICAgICAgICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgbG9nbzogJ1NvbG8gc2UgcGVybWl0ZW4gaW3DoWdlbmVzIEpQRywgUE5HIG8gV0VCUC4nLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZpbGUuc2l6ZSA+IG1heFNpemUpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBhcmNoaXZvIGV4Y2VkZSBlbCB0YW1hw7FvIG3DoXhpbW8gZGUgMk1CLicpO1xuICAgICAgICAgICAgY2xlYXJMb2dvU2VsZWN0aW9uKCk7XG4gICAgICAgICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+ICh7XG4gICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICBsb2dvOiAnRWwgbG9nbyBubyBwdWVkZSBzdXBlcmFyIGxvcyAyIE1CLicsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRMb2dvUHJldmlld1VybChwcmV2ID0+IHtcbiAgICAgICAgICAgIGlmIChwcmV2KSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXYpO1xuICAgICAgICAgICAgcmV0dXJuIFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XG4gICAgICAgIH0pO1xuICAgICAgICBzZXRMb2dvRmlsZShmaWxlKTtcbiAgICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgbmV4dC5sb2dvO1xuICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0Q29kZUNoYW5nZSA9IChjb2RlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgcGF0Y2hGb3JtKHtcbiAgICAgICAgICAgIG1lbGlfc2hpcHBpbmdfcHJvZHVjdF9za3U6IGNvZGUsXG4gICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQ6IG51bGwsXG4gICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfbmFtZTogJycsXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0U2VsZWN0ID0gKHByb2R1Y3Q6IEFydGljdWxvKSA9PiB7XG4gICAgICAgIHBhdGNoRm9ybSh7XG4gICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQ6IHByb2R1Y3QuaWQsXG4gICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1OiBwcm9kdWN0LnNrdSA/PyAnJyxcbiAgICAgICAgICAgIG1lbGlfc2hpcHBpbmdfcHJvZHVjdF9uYW1lOiBwcm9kdWN0Lm5hbWUgPz8gJycsXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRJc1Byb2R1Y3RNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0Q29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY29kZVZhbHVlID0gZm9ybS5tZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1LnRyaW0oKTtcbiAgICAgICAgaWYgKCFjb2RlVmFsdWUpIHJldHVybjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxBcnRpY3Vsbz4oYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBbXG4gICAgICAgICAgICAgICAgeyBmaWVsZE5hbWU6ICdza3UnLCB2YWx1ZTogY29kZVZhbHVlIH0sXG4gICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgaWYgKHJlc3VsdCAmJiByZXN1bHQuaXNfYWN0aXZlICE9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgIGhhbmRsZVByb2R1Y3RTZWxlY3QocmVzdWx0KTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKCdQcm9kdWN0byBlbmNvbnRyYWRvLicpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChyZXN1bHQgJiYgcmVzdWx0LmlzX2FjdGl2ZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignRWwgcHJvZHVjdG8gZW5jb250cmFkbyBubyBlc3TDoSBhY3Rpdm8uJyk7XG4gICAgICAgICAgICAgICAgcGF0Y2hGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgbWVsaV9zaGlwcGluZ19wcm9kdWN0X2lkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfbmFtZTogJycsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKGBObyBzZSBlbmNvbnRyw7MgbmluZ8O6biBhcnTDrWN1bG8gY29uIGVsIGPDs2RpZ28gXCIke2NvZGVWYWx1ZX1cIi5gKTtcbiAgICAgICAgICAgICAgICBwYXRjaEZvcm0oe1xuICAgICAgICAgICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIG1lbGlfc2hpcHBpbmdfcHJvZHVjdF9uYW1lOiAnJyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgZWwgYXJ0w61jdWxvLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHZhbGlkYXRlQ2xpZW50ID0gKCk6IEZpZWxkRXJyb3JzID0+IHtcbiAgICAgICAgY29uc3QgZXJyb3JzOiBGaWVsZEVycm9ycyA9IHt9O1xuXG4gICAgICAgIGlmICghZm9ybS5uYW1lLnRyaW0oKSkge1xuICAgICAgICAgICAgZXJyb3JzLm5hbWUgPSAnRWwgbm9tYnJlIGVzIG9ibGlnYXRvcmlvLic7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZm9ybS5tYWlsX2Zyb21fYWRkcmVzcy50cmltKCkgJiYgIWlzVmFsaWRTaW5nbGVFbWFpbChmb3JtLm1haWxfZnJvbV9hZGRyZXNzKSkge1xuICAgICAgICAgICAgZXJyb3JzLm1haWxfZnJvbV9hZGRyZXNzID0gJ0VsIGVtYWlsIG5vIHRpZW5lIHVuIGZvcm1hdG8gdsOhbGlkby4nO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZvcm0uY29udGFjdF9lbWFpbC50cmltKCkgJiYgIWlzVmFsaWRTaW5nbGVFbWFpbChmb3JtLmNvbnRhY3RfZW1haWwpKSB7XG4gICAgICAgICAgICBlcnJvcnMuY29udGFjdF9lbWFpbCA9ICdFbCBlbWFpbCBubyB0aWVuZSB1biBmb3JtYXRvIHbDoWxpZG8uJztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmb3JtLm1haWxfcG9ydC50cmltKCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHBvcnQgPSBOdW1iZXIoZm9ybS5tYWlsX3BvcnQudHJpbSgpKTtcbiAgICAgICAgICAgIGlmICghTnVtYmVyLmlzSW50ZWdlcihwb3J0KSB8fCBwb3J0IDw9IDApIHtcbiAgICAgICAgICAgICAgICBlcnJvcnMubWFpbF9wb3J0ID0gJ0VsIHB1ZXJ0byBkZWJlIHNlciB1biBuw7ptZXJvIGVudGVybyBwb3NpdGl2by4nO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZvcm0uZmNlX21pbmltdW1fYW1vdW50ICE9IG51bGwgJiYgZm9ybS5mY2VfbWluaW11bV9hbW91bnQgPCAwKSB7XG4gICAgICAgICAgICBlcnJvcnMuZmNlX21pbmltdW1fYW1vdW50ID0gJ0VsIHZhbG9yIG3DrW5pbW8gbm8gcHVlZGUgc2VyIG5lZ2F0aXZvLic7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZm9ybS5tZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1LnRyaW0oKSAmJiAhZm9ybS5tZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQpIHtcbiAgICAgICAgICAgIGVycm9ycy5tZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQgPVxuICAgICAgICAgICAgICAgICdTZWxlY2Npb27DoSB1biBwcm9kdWN0byB2w6FsaWRvIChFbnRlciBvIGx1cGEpIGFudGVzIGRlIGd1YXJkYXIuJztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmb3JtLnByaW1hcnlfY29sb3IudHJpbSgpICYmICFpc1ZhbGlkQnJhbmRIZXhDb2xvcihmb3JtLnByaW1hcnlfY29sb3IudHJpbSgpKSkge1xuICAgICAgICAgICAgZXJyb3JzLnByaW1hcnlfY29sb3IgPSAnVXPDoSB1biBjb2xvciBoZXggdsOhbGlkbyAoI1JSR0dCQikuJztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmb3JtLnNlY29uZGFyeV9jb2xvci50cmltKCkgJiYgIWlzVmFsaWRCcmFuZEhleENvbG9yKGZvcm0uc2Vjb25kYXJ5X2NvbG9yLnRyaW0oKSkpIHtcbiAgICAgICAgICAgIGVycm9ycy5zZWNvbmRhcnlfY29sb3IgPSAnVXPDoSB1biBjb2xvciBoZXggdsOhbGlkbyAoI1JSR0dCQikuJztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBlcnJvcnM7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNsaWVudEVycm9ycyA9IHZhbGlkYXRlQ2xpZW50KCk7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhjbGllbnRFcnJvcnMpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHNldEZpZWxkRXJyb3JzKGNsaWVudEVycm9ycyk7XG4gICAgICAgICAgICB0b2FzdC53YXJuKCdSZXZpc8OhIGxvcyBjYW1wb3MgbWFyY2Fkb3MuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgICAgIHNldEZpZWxkRXJyb3JzKHt9KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBidWlsZE9yZ2FuaXphdGlvbkRldGFpbHNQYXlsb2FkKGZvcm0pO1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IHVwZGF0ZU9yZ2FuaXphdGlvbkRldGFpbHMocGF5bG9hZCwge1xuICAgICAgICAgICAgICAgIGxvZ29GaWxlLFxuICAgICAgICAgICAgICAgIGFmaXBDZXJ0RmlsZSxcbiAgICAgICAgICAgICAgICBhZmlwS2V5RmlsZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3QgbmV4dEZvcm0gPSBvcmdhbml6YXRpb25EZXRhaWxzVG9Gb3JtU3RhdGUodXBkYXRlZCk7XG4gICAgICAgICAgICBuZXh0Rm9ybS5tZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1ID0gZm9ybS5tZWxpX3NoaXBwaW5nX3Byb2R1Y3Rfc2t1O1xuICAgICAgICAgICAgbmV4dEZvcm0ubWVsaV9zaGlwcGluZ19wcm9kdWN0X25hbWUgPSBmb3JtLm1lbGlfc2hpcHBpbmdfcHJvZHVjdF9uYW1lO1xuICAgICAgICAgICAgc2V0Rm9ybShuZXh0Rm9ybSk7XG4gICAgICAgICAgICBjbGVhckxvZ29TZWxlY3Rpb24oKTtcbiAgICAgICAgICAgIGNsZWFyQWZpcENlcnRTZWxlY3Rpb24oKTtcbiAgICAgICAgICAgIGNsZWFyQWZpcEtleVNlbGVjdGlvbigpO1xuICAgICAgICAgICAgc2V0QnJhbmRpbmcoe1xuICAgICAgICAgICAgICAgIG5hbWU6IHVwZGF0ZWQubmFtZSxcbiAgICAgICAgICAgICAgICBsb2dvX3VybDogdXBkYXRlZC5sb2dvX3VybCA/PyBudWxsLFxuICAgICAgICAgICAgICAgIHByaW1hcnlfY29sb3I6IHVwZGF0ZWQucHJpbWFyeV9jb2xvciA/PyBudWxsLFxuICAgICAgICAgICAgICAgIHNlY29uZGFyeV9jb2xvcjogdXBkYXRlZC5zZWNvbmRhcnlfY29sb3IgPz8gbnVsbCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnQ29uZmlndXJhY2nDs24gZ3VhcmRhZGEuJyk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICBjb25zdCBhcGlFcnJvcnMgPSBwYXJzZUFwaUZpZWxkRXJyb3JzKGUpO1xuICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKGFwaUVycm9ycykubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkRXJyb3JzKGFwaUVycm9ycyk7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0hheSBlcnJvcmVzIGRlIHZhbGlkYWNpw7NuLiBSZXZpc8OhIGxvcyBjYW1wb3MgbWFyY2Fkb3MuJyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKHBhcnNlQXBpTWVzc2FnZShlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRTYXZpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuXG4gICAgaWYgKGxvYWRFcnJvcikge1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJnLXdoaXRlIHAtNiBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIj57bG9hZEVycm9yfTwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGxvYWQoKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLW1kIGJnLXllbGxvdy02MDAgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBob3ZlcjpiZy15ZWxsb3ctNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFJlaW50ZW50YXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGRpc2FibGVkID0gc2F2aW5nO1xuICAgIGNvbnN0IGRpc3BsYXllZExvZ29VcmwgPSBsb2dvUHJldmlld1VybCB8fCBmb3JtLmxvZ29fdXJsO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgcm91bmRlZC1sZyBiZy13aGl0ZSBwLTQgc2hhZG93LXNtIHNtOnAtNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgcGItNFwiPlxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNvbmZpZ3VyYWNpw7NuIGRlbCBzaXN0ZW1hPC9oMT5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVNhdmUoKX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLXllbGxvdy02MDAgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmcteWVsbG93LTcwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhU2F2ZSBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICBHdWFyZGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEdlbmVyYWwgKi99XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgR2VuZXJhbFxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJvcmctbmFtZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTm9tYnJlICpcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZy1uYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMubmFtZSA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLm5hbWV9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJvcmctbG9nb1wiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTG9nb1xuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICB7ZGlzcGxheWVkTG9nb1VybCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtkaXNwbGF5ZWRMb2dvVXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJMb2dvIGRlIGxhIG9yZ2FuaXphY2nDs25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC0yMCBtYXgtdy1bMjAwcHhdIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBvYmplY3QtY29udGFpbiBwLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvZ29GaWxlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtYmx1ZS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpc3RhIHByZXZpYSBkZWwgbnVldm8gbG9nbyAoYcO6biBubyBndWFyZGFkbykuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshbG9nb0ZpbGUgJiYgZm9ybS5sb2dvX3VybCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+TG9nbyBhY3R1YWwuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWxvZ29cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmpwZywuanBlZywucG5nLC53ZWJwLGltYWdlL2pwZWcsaW1hZ2UvcG5nLGltYWdlL3dlYnBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUxvZ29DaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZmlsZTptci00IGZpbGU6cm91bmRlZC1sLW1kIGZpbGU6Ym9yZGVyLTAgZmlsZTpiZy1pbmRpZ28tNTAgZmlsZTpweC00IGZpbGU6cHktMiBmaWxlOnRleHQtc20gZmlsZTpmb250LXNlbWlib2xkIGZpbGU6dGV4dC1pbmRpZ28tNzAwIGhvdmVyOmZpbGU6YmctaW5kaWdvLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybS5sb2dvX3VybFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1NlbGVjY2lvbsOhIHVuIG51ZXZvIGFyY2hpdm8gcGFyYSByZWVtcGxhemFyIGVsIGFjdHVhbC4gT3BjaW9uYWwuIFRpcG9zOiBKUEcsIFBORywgV0VCUC4gTcOheDogMk1CLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdPcGNpb25hbC4gVGlwb3M6IEpQRywgUE5HLCBXRUJQLiBNw6F4OiAyTUIuJ31cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5sb2dvfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8QnJhbmRDb2xvckZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZy1wcmltYXJ5LWNvbG9yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ29sb3IgcHJpbmNpcGFsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnByaW1hcnlfY29sb3J9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNFcnJvcj17Qm9vbGVhbihmaWVsZEVycm9ycy5wcmltYXJ5X2NvbG9yKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZT17ZmllbGRFcnJvcnMucHJpbWFyeV9jb2xvcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGZhbGxiYWNrPXtERUZBVUxUX1BSSU1BUllfQ09MT1J9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dmFsdWUgPT4gcGF0Y2hGb3JtKHsgcHJpbWFyeV9jb2xvcjogdmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxCcmFuZENvbG9yRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLXNlY29uZGFyeS1jb2xvclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkNvbG9yIHNlY3VuZGFyaW9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uc2Vjb25kYXJ5X2NvbG9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgaGFzRXJyb3I9e0Jvb2xlYW4oZmllbGRFcnJvcnMuc2Vjb25kYXJ5X2NvbG9yKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZT17ZmllbGRFcnJvcnMuc2Vjb25kYXJ5X2NvbG9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgZmFsbGJhY2s9e0RFRkFVTFRfU0VDT05EQVJZX0NPTE9SfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3ZhbHVlID0+IHBhdGNoRm9ybSh7IHNlY29uZGFyeV9jb2xvcjogdmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgIHsvKiBEYXRvcyBkZSBsYSBlbXByZXNhIChlbWlzb3IgUERGKSAqL31cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNwYWNlLXktNCBib3JkZXItdCBwdC02XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEYXRvcyBkZSBsYSBlbXByZXNhXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEYXRvcyBpbXByZXNvcyBlbiBQREYgLyByZW1pdG9zLlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJvcmctYWN0aXZpdHlcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY3RpdmlkYWQgLyBtYXJjYVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWFjdGl2aXR5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uYWN0aXZpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ0lOVEFTIEFVVE9BREhFU0lWQVNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IGFjdGl2aXR5OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLmFjdGl2aXR5ID8gaW5wdXRFcnJvckNsYXNzIDogaW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLmFjdGl2aXR5fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1hZGRyZXNzXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGlyZWNjacOzblxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWFkZHJlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5hZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFSR0VSSUNIIDU3NTYvNjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IGFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMuYWRkcmVzcyA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5hZGRyZXNzfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1jaXR5XCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2l1ZGFkIC8gQ1BcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZy1jaXR5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY2l0eX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIoQzE0MTlEQ0YpIEJVRU5PUyBBSVJFU1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgY2l0eTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtmaWVsZEVycm9ycy5jaXR5ID8gaW5wdXRFcnJvckNsYXNzIDogaW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLmNpdHl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwib3JnLWl2YS1jb25kaXRpb25cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb25kaWNpw7NuIElWQVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWl2YS1jb25kaXRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5pdmFfY29uZGl0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkkuVi5BLjogUkVTUE9OU0FCTEUgSU5TQ1JJUFRPXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBpdmFfY29uZGl0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLml2YV9jb25kaXRpb24gPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuaXZhX2NvbmRpdGlvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy13ZWJzaXRlXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2l0aW8gd2ViXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvcmctd2Vic2l0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLndlYnNpdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwid3d3LnNlbGdvbS5jb20uYXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IHdlYnNpdGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMud2Vic2l0ZSA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy53ZWJzaXRlfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwib3JnLWNvbnRhY3QtZW1haWxcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFLW1haWwgZGUgY29udGFjdG9cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZy1jb250YWN0LWVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmNvbnRhY3RfZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiaW5mb0BzZWxnb20uY29tLmFyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBjb250YWN0X2VtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLmNvbnRhY3RfZW1haWwgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEaXN0aW50byBkZWwgZW1haWwgU01UUCAobWFpbCBmcm9tIGFkZHJlc3MpLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuY29udGFjdF9lbWFpbH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1tb2JpbGVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDZWx1bGFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvcmctbW9iaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubW9iaWxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjExLTUxMTQtNTM1NVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgbW9iaWxlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLm1vYmlsZSA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlNpbiBwcmVmaWpvIOKAnENlbC7igJ07IGVsIFBERiBsbyBhZ3JlZ2EuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubW9iaWxlfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwib3JnLXBob25lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVsL0ZheFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLXBob25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ucGhvbmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNDU3Mi02MDY3IEwuIFJvdC5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IHBob25lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLnBob25lID8gaW5wdXRFcnJvckNsYXNzIDogaW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+U2luIOKAnFRFTC9GQVg64oCdOyBlbCBQREYgbG8gYWdyZWdhIGVuIHJlbWl0by48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5waG9uZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1jdWl0XCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ1VJVCAoaW1wcmVzacOzbilcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm9yZy1jdWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uY3VpdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIzMC01NDY3Mzc1Ny00XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBjdWl0OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLmN1aXQgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuY3VpdH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1pbmctYnJ1dG9zXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5ncmVzb3MgQnJ1dG9zXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvcmctaW5nLWJydXRvc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmluZ19icnV0b3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiOTAxLTkxNzQzNC0zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBpbmdfYnJ1dG9zOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLmluZ19icnV0b3MgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuaW5nX2JydXRvc30gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm9yZy1maXNjYWwtc3RhcnQtZGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluaWNpbyBkZSBhY3RpdmlkYWRlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWZpc2NhbC1zdGFydC1kYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uZmlzY2FsX3N0YXJ0X2RhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMzAvMDcvMTk4NlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgZmlzY2FsX3N0YXJ0X2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMuZmlzY2FsX3N0YXJ0X2RhdGUgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuZmlzY2FsX3N0YXJ0X2RhdGV9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJvcmctcmVtaXRvLWNhaS1udW1iZXJcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDQUkgcmVtaXRvXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvcmctcmVtaXRvLWNhaS1udW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5yZW1pdG9fY2FpX251bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI1MjEzNDIxNzkwNTQ0M1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgcmVtaXRvX2NhaV9udW1iZXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMucmVtaXRvX2NhaV9udW1iZXIgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMucmVtaXRvX2NhaV9udW1iZXJ9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJvcmctcmVtaXRvLWNhaS1kdWUtZGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZlbmNpbWllbnRvIENBSVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLXJlbWl0by1jYWktZHVlLWRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5yZW1pdG9fY2FpX2R1ZV9kYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAxLzA0LzIwMjdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IHJlbWl0b19jYWlfZHVlX2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMucmVtaXRvX2NhaV9kdWVfZGF0ZSA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5yZW1pdG9fY2FpX2R1ZV9kYXRlfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwib3JnLXBheW1lbnQtbGVnYWwtbGVnZW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIExleWVuZGEgbGVnYWwgZGUgcGFnb1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLXBheW1lbnQtbGVnYWwtbGVnZW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs2fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnBheW1lbnRfbGVnYWxfbGVnZW5kfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBwYXltZW50X2xlZ2FsX2xlZ2VuZDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRFcnJvcnMucGF5bWVudF9sZWdhbF9sZWdlbmQgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUZXh0byBpbXByZXNvIGFsIHBpZSBkZSBmYWN0dXJhIC8gTkMgLyBORiAob21pdGlkbyBlbiB2ZW50YXMgTUVMSSBlblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBERikuXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5wYXltZW50X2xlZ2FsX2xlZ2VuZH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgIHsvKiBNZXJjYWRvIExpYnJlICovfVxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS00IGJvcmRlci10IHB0LTZcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgTWVyY2FkbyBMaWJyZVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibWVsaS1jbGllbnQtaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpZW50IElEIC0gTUVMSVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWVsaS1jbGllbnQtaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tZWxpX2NsaWVudF9pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgbWVsaV9jbGllbnRfaWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMubWVsaV9jbGllbnRfaWQgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubWVsaV9jbGllbnRfaWR9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8UGFzc3dvcmRGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJtZWxpLWNsaWVudC1zZWNyZXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDbGllbnQgU2VjcmV0IC0gTUVMSVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tZWxpX2NsaWVudF9zZWNyZXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNFcnJvcj17Qm9vbGVhbihmaWVsZEVycm9ycy5tZWxpX2NsaWVudF9zZWNyZXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlPXtmaWVsZEVycm9ycy5tZWxpX2NsaWVudF9zZWNyZXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dmFsdWUgPT4gcGF0Y2hGb3JtKHsgbWVsaV9jbGllbnRfc2VjcmV0OiB2YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvZHVjdG8gRmxldGUgTUVMSVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm0ubWVsaV9zaGlwcGluZ19wcm9kdWN0X3NrdX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm0ubWVsaV9zaGlwcGluZ19wcm9kdWN0X25hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXtoYW5kbGVQcm9kdWN0Q29kZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IHZvaWQgaGFuZGxlUHJvZHVjdENvZGVTdWJtaXQoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBzZXRJc1Byb2R1Y3RNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRjaEZvcm0oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVsaV9zaGlwcGluZ19wcm9kdWN0X2lkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVsaV9zaGlwcGluZ19wcm9kdWN0X3NrdTogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZWxpX3NoaXBwaW5nX3Byb2R1Y3RfbmFtZTogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hc2s9XCJza3VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYXNFcnJvcj17Qm9vbGVhbihmaWVsZEVycm9ycy5tZWxpX3NoaXBwaW5nX3Byb2R1Y3RfaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuYWJsZUF1dG9jb21wbGV0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZUNvbmZpZz17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRwb2ludDogYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlRmllbGQ6ICdza3UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICduYW1lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoUGFyYW1zOiB7IGlzX2FjdGl2ZTogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdDogaXRlbSA9PiBoYW5kbGVQcm9kdWN0U2VsZWN0KGl0ZW0gYXMgQXJ0aWN1bG8pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFc2NyaWLDrSBlbCBTS1UgeSBwcmVzaW9uw6EgRW50ZXIsIG8gdXPDoSBsYSBsdXBhLiBTb2xvIHByb2R1Y3RvcyBhY3Rpdm9zLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubWVsaV9zaGlwcGluZ19wcm9kdWN0X2lkfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIEVtYWlsICovfVxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS00IGJvcmRlci10IHB0LTZcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgRW1haWxcbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgU2Vydmlkb3IgZGUgZW1haWxcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZ3JpZCBncmlkLWNvbHMtMSBnYXAtMyBzbTpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtYWlsLWhvc3RcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEhvc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1haWwtaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJIb3N0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubWFpbF9ob3N0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IG1haWxfaG9zdDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMubWFpbF9ob3N0ID8gaW5wdXRFcnJvckNsYXNzIDogaW5wdXRDbGFzc30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmllbGRFcnJvciBtZXNzYWdlPXtmaWVsZEVycm9ycy5tYWlsX2hvc3R9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtYWlsLXBvcnRcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFB1ZXJ0b1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWFpbC1wb3J0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQdWVydG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tYWlsX3BvcnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gcGF0Y2hGb3JtKHsgbWFpbF9wb3J0OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtmaWVsZEVycm9ycy5tYWlsX3BvcnQgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLm1haWxfcG9ydH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm1haWwtZW5jcnlwdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaWZyYWRvIGRlIGVtYWlsXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWFpbC1lbmNyeXB0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tYWlsX2VuY3J5cHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdGNoRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYWlsX2VuY3J5cHRpb246IGUudGFyZ2V0LnZhbHVlIGFzIE1haWxFbmNyeXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLm1haWxfZW5jcnlwdGlvbiA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge01BSUxfRU5DUllQVElPTl9PUFRJT05TLm1hcChvcHQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17b3B0LnZhbHVlIHx8ICdub25lJ30gdmFsdWU9e29wdC52YWx1ZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubWFpbF9lbmNyeXB0aW9ufSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJtYWlsLWZyb20tYWRkcmVzc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdWVudGEgZGUgZW1haWxcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1haWwtZnJvbS1hZGRyZXNzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLm1haWxfZnJvbV9hZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBwYXRjaEZvcm0oeyBtYWlsX2Zyb21fYWRkcmVzczogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRFcnJvcnMubWFpbF9mcm9tX2FkZHJlc3MgPyBpbnB1dEVycm9yQ2xhc3MgOiBpbnB1dENsYXNzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubWFpbF9mcm9tX2FkZHJlc3N9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm1haWwtZnJvbS1uYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWJyZSBww7pibGljbyBkZWwgZW1haWxcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1haWwtZnJvbS1uYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubWFpbF9mcm9tX25hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IG1haWxfZnJvbV9uYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ZpZWxkRXJyb3JzLm1haWxfZnJvbV9uYW1lID8gaW5wdXRFcnJvckNsYXNzIDogaW5wdXRDbGFzc30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLm1haWxfZnJvbV9uYW1lfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJtYWlsLXVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzdWFyaW8gZGUgZW1haWxcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1haWwtdXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tYWlsX3VzZXJuYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHBhdGNoRm9ybSh7IG1haWxfdXNlcm5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17ZmllbGRFcnJvcnMubWFpbF91c2VybmFtZSA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMubWFpbF91c2VybmFtZX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxQYXNzd29yZEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm1haWwtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDbGF2ZSBkZSBlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5tYWlsX3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgaGFzRXJyb3I9e0Jvb2xlYW4oZmllbGRFcnJvcnMubWFpbF9wYXNzd29yZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2U9e2ZpZWxkRXJyb3JzLm1haWxfcGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dmFsdWUgPT4gcGF0Y2hGb3JtKHsgbWFpbF9wYXNzd29yZDogdmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgIHsvKiBGYWN0dXJhY2nDs24gKi99XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTQgYm9yZGVyLXQgcHQtNlwiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICBGYWN0dXJhY2nDs25cbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZmNlLW1pbmltdW0tYW1vdW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZhbG9yIG3DrW5pbW8gZGUgRmFjdHVyYSBkZSBDcsOpZGl0byBFbGVjdHLDs25pY2EgTWlQeU1FXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZmNlLW1pbmltdW0tYW1vdW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG51bGxhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5mY2VfbWluaW11bV9hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGVuRW1wdHk9e251bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbXB0eVdoZW5aZXJvPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gcGF0Y2hGb3JtKHsgZmNlX21pbmltdW1fYW1vdW50OiBudW0gfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkRXJyb3JzLmZjZV9taW5pbXVtX2Ftb3VudCA/IGlucHV0RXJyb3JDbGFzcyA6IGlucHV0Q2xhc3NcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuZmNlX21pbmltdW1fYW1vdW50fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgICB7LyogQUZJUCAvIEFSQ0EgKi99XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTQgYm9yZGVyLXQgcHQtNlwiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICBBRklQIC8gQVJDQVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwib3JnLWFmaXAtY2VydFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDZXJ0aWZpY2FkbyBBRklQXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWZpcENlcnRGaWxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYE51ZXZvIGFyY2hpdm8gc2VsZWNjaW9uYWRvOiAke2FmaXBDZXJ0RmlsZS5uYW1lfSAoYcO6biBubyBndWFyZGFkbykuYFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGZvcm0uaGFzX2FmaXBfY2VydFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0NlcnRpZmljYWRvIGNhcmdhZG8uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1NpbiBjZXJ0aWZpY2Fkby4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXthZmlwQ2VydElucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3JnLWFmaXAtY2VydFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cIi5jcnQsLnBlbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVBZmlwQ2VydENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0yIGJsb2NrIHctZnVsbCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZmlsZTptci00IGZpbGU6cm91bmRlZC1sLW1kIGZpbGU6Ym9yZGVyLTAgZmlsZTpiZy1pbmRpZ28tNTAgZmlsZTpweC00IGZpbGU6cHktMiBmaWxlOnRleHQtc20gZmlsZTpmb250LXNlbWlib2xkIGZpbGU6dGV4dC1pbmRpZ28tNzAwIGhvdmVyOmZpbGU6YmctaW5kaWdvLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybS5oYXNfYWZpcF9jZXJ0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1NlbGVjY2lvbsOhIHVuIG51ZXZvIGFyY2hpdm8gcGFyYSByZWVtcGxhemFyIGVsIGFjdHVhbC4gT3BjaW9uYWwuIFRpcG9zOiAuY3J0LCAucGVtLiBNw6F4OiAxTUIuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdPcGNpb25hbC4gVGlwb3M6IC5jcnQsIC5wZW0uIE3DoXg6IDFNQi4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpZWxkRXJyb3IgbWVzc2FnZT17ZmllbGRFcnJvcnMuYWZpcF9jZXJ0fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJvcmctYWZpcC1rZXlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xhdmUgcHJpdmFkYSBBRklQXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWZpcEtleUZpbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgTnVldm8gYXJjaGl2byBzZWxlY2Npb25hZG86ICR7YWZpcEtleUZpbGUubmFtZX0gKGHDum4gbm8gZ3VhcmRhZG8pLmBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtLmhhc19hZmlwX2tleVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0NsYXZlIGNhcmdhZGEuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1NpbiBjbGF2ZS4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXthZmlwS2V5SW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvcmctYWZpcC1rZXlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCIua2V5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUFmaXBLZXlDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPVwibXQtMiBibG9jayB3LWZ1bGwgY3Vyc29yLXBvaW50ZXIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtc20gdGV4dC1ncmF5LTkwMCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZpbGU6bXItNCBmaWxlOnJvdW5kZWQtbC1tZCBmaWxlOmJvcmRlci0wIGZpbGU6YmctaW5kaWdvLTUwIGZpbGU6cHgtNCBmaWxlOnB5LTIgZmlsZTp0ZXh0LXNtIGZpbGU6Zm9udC1zZW1pYm9sZCBmaWxlOnRleHQtaW5kaWdvLTcwMCBob3ZlcjpmaWxlOmJnLWluZGlnby0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm0uaGFzX2FmaXBfa2V5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1NlbGVjY2lvbsOhIHVuIG51ZXZvIGFyY2hpdm8gcGFyYSByZWVtcGxhemFyIGVsIGFjdHVhbC4gT3BjaW9uYWwuIFRpcG86IC5rZXkuIE3DoXg6IDFNQi4nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ09wY2lvbmFsLiBUaXBvOiAua2V5LiBNw6F4OiAxTUIuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGaWVsZEVycm9yIG1lc3NhZ2U9e2ZpZWxkRXJyb3JzLmFmaXBfa2V5fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGJvcmRlci10IHB0LTZcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVNhdmUoKX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLXllbGxvdy02MDAgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmcteWVsbG93LTcwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhU2F2ZSBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICBHdWFyZGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2lzUHJvZHVjdE1vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNQcm9kdWN0TW9kYWxPcGVufVxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc1Byb2R1Y3RNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17aXRlbSA9PiBoYW5kbGVQcm9kdWN0U2VsZWN0KGl0ZW0gYXMgQXJ0aWN1bG8pfVxuICAgICAgICAgICAgICAgICAgICBjb25maWc9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmFydGljdWxvc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluaXRpYWxGaWx0ZXJzOiB7IGlzX2FjdGl2ZTogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvb3JnYW5pemF0aW9uX2RldGFpbHMvcGFnZXMvT3JnYW5pemF0aW9uRGV0YWlsc1BhZ2UudHN4In0=