import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cajas/pages/CajasListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cajas/pages/CajasListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { cajasModuleConfig } from "/src/features/cajas/cajas.config.tsx";
export const CajasListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(cajasModuleConfig, getDefaultListDateRange());
  const isOriginatedFromBank = (item) => !!item.source_type && item.source_id != null && item.source_type.includes("BankMovement");
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasListPage.tsx",
    lineNumber: 47,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: cajasModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit: (item) => !isOriginatedFromBank(item),
      canDelete: (item) => !isOriginatedFromBank(item)
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/cajas/pages/CajasListPage.tsx",
      lineNumber: 50,
      columnNumber: 5
    },
    this
  );
};
_s(CajasListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = CajasListPage;
var _c;
$RefreshReg$(_c, "CajasListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cajas/pages/CajasListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cajas/pages/CajasListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyx5QkFBb0M7QUFFdEMsYUFBTUMsZ0JBQWdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDL0IsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSWhCLFFBQWNFLG1CQUFtQkQsd0JBQXdCLENBQUM7QUFFOUQsUUFBTWdCLHVCQUF1QkEsQ0FBQ0MsU0FDMUIsQ0FBQyxDQUFDQSxLQUFLQyxlQUNQRCxLQUFLRSxhQUFhLFFBQ2xCRixLQUFLQyxZQUFZRSxTQUFTLGNBQWM7QUFFNUMsTUFBSWIsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRXZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFOO0FBQUFBLE1BQ1Isb0JBQW9CRztBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFNLFFBQVE7QUFBQSxNQUNqQyxpQkFBaUJOLGFBQWFPLGFBQWE7QUFBQSxNQUMzQyxlQUFlUCxhQUFhUSxXQUFXO0FBQUEsTUFDdkMsdUJBQXVCO0FBQUEsTUFDdkIsU0FBUyxDQUFDTixTQUFTLENBQUNELHFCQUFxQkMsSUFBSTtBQUFBLE1BQzdDLFdBQVcsQ0FBQ0EsU0FBUyxDQUFDRCxxQkFBcUJDLElBQUk7QUFBQTtBQUFBLElBakJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQnFEO0FBRzdEO0FBQUVkLEdBNUNXRCxlQUFhO0FBQUEsVUFjbEJILE9BQU87QUFBQTtBQUFBeUIsS0FkRnRCO0FBQWEsSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJjYWphc01vZHVsZUNvbmZpZyIsIkNhamFzTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJpc09yaWdpbmF0ZWRGcm9tQmFuayIsIml0ZW0iLCJzb3VyY2VfdHlwZSIsInNvdXJjZV9pZCIsImluY2x1ZGVzIiwidGVybSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYWphc0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvZmVhdHVyZXMvY2FqYXMvcGFnZXMvQ2FqYXNMaXN0UGFnZS50c3hcbmltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuaW1wb3J0IHsgY2FqYXNNb2R1bGVDb25maWcsIHR5cGUgQ2FqYSB9IGZyb20gJy4uL2NhamFzLmNvbmZpZyc7XG5cbmV4cG9ydCBjb25zdCBDYWphc0xpc3RQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGlzQXBwZW5kaW5nLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgZGVsZXRlSXRlbSxcbiAgICAgICAgaGFuZGxlU29ydCxcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVMb2FkTW9yZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8Q2FqYT4oY2FqYXNNb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgY29uc3QgaXNPcmlnaW5hdGVkRnJvbUJhbmsgPSAoaXRlbTogQ2FqYSkgPT5cbiAgICAgICAgISFpdGVtLnNvdXJjZV90eXBlICYmXG4gICAgICAgIGl0ZW0uc291cmNlX2lkICE9IG51bGwgJiZcbiAgICAgICAgaXRlbS5zb3VyY2VfdHlwZS5pbmNsdWRlcygnQmFua01vdmVtZW50Jyk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPENhamE+XG4gICAgICAgICAgICBjb25maWc9e2NhamFzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgICAgICBjYW5FZGl0PXsoaXRlbSkgPT4gIWlzT3JpZ2luYXRlZEZyb21CYW5rKGl0ZW0pfVxuICAgICAgICAgICAgY2FuRGVsZXRlPXsoaXRlbSkgPT4gIWlzT3JpZ2luYXRlZEZyb21CYW5rKGl0ZW0pfVxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jYWphcy9wYWdlcy9DYWphc0xpc3RQYWdlLnRzeCJ9