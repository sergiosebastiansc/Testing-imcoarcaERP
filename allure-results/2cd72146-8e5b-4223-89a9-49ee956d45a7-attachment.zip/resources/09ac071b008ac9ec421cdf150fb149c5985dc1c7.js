import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/fractionings/pages/FractioningDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/fractionings/pages/FractioningDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { fractioningsModuleConfig } from "/src/features/fractionings/fractionings.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { FaArrowDown, FaArrowUp, FaUndoAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const MovementsTable = ({
  title,
  movements,
  icon,
  emptyMessage,
  showExtraColumns = false
}) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
  /* @__PURE__ */ jsxDEV("h2", { className: "flex items-center text-lg font-medium text-gray-800", children: [
    icon,
    /* @__PURE__ */ jsxDEV("span", { className: "ml-2", children: title }, void 0, false, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 47,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 45,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
    /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
      /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Producto" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 53,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cantidad" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 54,
        columnNumber: 25
      }, this),
      showExtraColumns && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Costo Adicional" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 57,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Observación" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 58,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 56,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 52,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 51,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: movements.length > 0 ? movements.map(
      (m) => /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6", children: m.product_name || `ID: ${m.product_id}` }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 67,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: Math.abs(parseFloat(m.quantity)) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 68,
          columnNumber: 33
        }, this),
        showExtraColumns && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: formatValue(m.additional_cost, "currency") }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
            lineNumber: 71,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: m.observation || "-" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
            lineNumber: 72,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 70,
          columnNumber: 11
        }, this)
      ] }, m.id, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    ) : /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: showExtraColumns ? 4 : 2, className: "px-6 py-4 text-sm text-center text-gray-500", children: emptyMessage }, void 0, false, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 79,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 78,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 63,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 50,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 49,
    columnNumber: 9
  }, this)
] }, void 0, true, {
  fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
  lineNumber: 44,
  columnNumber: 1
}, this);
_c = MovementsTable;
export const FractioningDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: fractioning, loading, error } = useCrudItem(fractioningsModuleConfig, id);
  const { sourceMovements, newResultingMovements, remnantMovements } = useMemo(() => {
    if (!fractioning?.movements) {
      return { sourceMovements: [], newResultingMovements: [], remnantMovements: [] };
    }
    const source = fractioning.movements.filter((m) => parseFloat(m.quantity) < 0);
    const allResulting = fractioning.movements.filter((m) => parseFloat(m.quantity) > 0);
    const remnants = allResulting.filter((m) => m.is_remanente === true);
    const newProducts = allResulting.filter((m) => m.is_remanente === false);
    return {
      sourceMovements: source,
      newResultingMovements: newProducts,
      remnantMovements: remnants
    };
  }, [fractioning]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 116,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 117,
    columnNumber: 21
  }, this);
  if (!fractioning) return /* @__PURE__ */ jsxDEV("div", { children: "No se encontró el registro de fraccionamiento." }, void 0, false, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 118,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: [
          "Detalle del Fraccionamiento #",
          fractioning.id
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 124,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: [
          "Realizado el: ",
          formatValue(fractioning.fractioning_date, "date")
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 127,
          columnNumber: 21
        }, this),
        fractioning.description && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-600", children: [
          "Descripción: ",
          fractioning.description
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 130,
          columnNumber: 49
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 123,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-3 sm:mt-0", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => navigate(getListReturnPath(fractioningsModuleConfig.baseRoute)),
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
          children: [
            /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
              lineNumber: 138,
              columnNumber: 25
            }, this),
            "Volver al Listado"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 133,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 132,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
      lineNumber: 122,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      MovementsTable,
      {
        title: "Productos de Origen (Consumidos)",
        movements: sourceMovements,
        icon: /* @__PURE__ */ jsxDEV(FaArrowDown, { className: "text-red-500" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 147,
          columnNumber: 15
        }, this),
        emptyMessage: "No hay productos de origen."
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 144,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      MovementsTable,
      {
        title: "Productos Resultantes (Generados)",
        movements: newResultingMovements,
        icon: /* @__PURE__ */ jsxDEV(FaArrowUp, { className: "text-green-500" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 154,
          columnNumber: 15
        }, this),
        emptyMessage: "No se generaron nuevos productos.",
        showExtraColumns: true
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 151,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      MovementsTable,
      {
        title: "Remanentes (Devueltos al Stock)",
        movements: remnantMovements,
        icon: /* @__PURE__ */ jsxDEV(FaUndoAlt, { className: "text-blue-500" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
          lineNumber: 161,
          columnNumber: 15
        }, this),
        emptyMessage: "No hubo productos remanentes."
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
        lineNumber: 158,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/fractionings/pages/FractioningDetailPage.tsx",
    lineNumber: 121,
    columnNumber: 5
  }, this);
};
_s(FractioningDetailPage, "GxpUdvXzM1IRG6xTjGt8rM/b/nE=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c2 = FractioningDetailPage;
var _c, _c2;
$RefreshReg$(_c, "MovementsTable");
$RefreshReg$(_c2, "FractioningDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/fractionings/pages/FractioningDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/fractionings/pages/FractioningDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJZLFNBU2dCLFVBVGhCOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCWixPQUFPQSxTQUFTQyxlQUFlO0FBQy9CLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0NBQTRFO0FBQ3JGLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWFDLFdBQVdDLGlCQUFpQjtBQUNsRCxTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsaUJBQWlCQSxDQUFDO0FBQUEsRUFDcEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLG1CQUFtQjtBQU92QixNQUNJLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLHlCQUFDLFFBQUcsV0FBVSx1REFDVEY7QUFBQUE7QUFBQUEsSUFDRCx1QkFBQyxVQUFLLFdBQVUsUUFBUUYsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxPQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFBQSxFQUNBLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwyQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRjtBQUFBLE1BQy9GLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsd0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUNqRkksb0JBQ0csbUNBQ0k7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkRBQTRELCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFDekYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCwyQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFdBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pILG9CQUFVSSxTQUFTLElBQ2hCSixVQUFVSztBQUFBQSxNQUFJLENBQUFDLE1BQ1YsdUJBQUMsUUFDRztBQUFBLCtCQUFDLFFBQUcsV0FBVSw0REFBNERBLFlBQUVDLGdCQUFnQixPQUFPRCxFQUFFRSxVQUFVLE1BQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0g7QUFBQSxRQUNsSCx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DQyxlQUFLQyxJQUFJQyxXQUFXTCxFQUFFTSxRQUFRLENBQUMsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFFBQ2pGVCxvQkFDRyxtQ0FDSTtBQUFBLGlDQUFDLFFBQUcsV0FBVSxtQ0FBbUNWLHNCQUFZYSxFQUFFTyxpQkFBaUIsVUFBVSxLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RjtBQUFBLFVBQzVGLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNQLFlBQUVRLGVBQWUsT0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxhQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBDUixFQUFFUyxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLElBQ0gsSUFFRCx1QkFBQyxRQUNHLGlDQUFDLFFBQUcsU0FBU1osbUJBQW1CLElBQUksR0FBRyxXQUFVLCtDQUErQ0QsMEJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkcsS0FEakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBakJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxPQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBLEtBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFBQSxLQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BeUNBO0FBQ0ZjLEtBdkRJbEI7QUF5REMsYUFBTW1CLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUgsR0FBRyxJQUFJNUIsVUFBMEI7QUFDekMsUUFBTWdDLFdBQVcvQixZQUFZO0FBQzdCLFFBQU0sRUFBRWdDLE1BQU1DLGFBQWFDLFNBQVNDLE1BQU0sSUFBSWxDLFlBQXlCQywwQkFBMEJ5QixFQUFFO0FBR25HLFFBQU0sRUFBRVMsaUJBQWlCQyx1QkFBdUJDLGlCQUFpQixJQUFJeEMsUUFBUSxNQUFNO0FBQy9FLFFBQUksQ0FBQ21DLGFBQWFyQixXQUFXO0FBQ3pCLGFBQU8sRUFBRXdCLGlCQUFpQixJQUFJQyx1QkFBdUIsSUFBSUMsa0JBQWtCLEdBQUc7QUFBQSxJQUNsRjtBQUdBLFVBQU1DLFNBQVNOLFlBQVlyQixVQUFVNEIsT0FBTyxDQUFBdEIsTUFBS0ssV0FBV0wsRUFBRU0sUUFBUSxJQUFJLENBQUM7QUFHM0UsVUFBTWlCLGVBQWVSLFlBQVlyQixVQUFVNEIsT0FBTyxDQUFBdEIsTUFBS0ssV0FBV0wsRUFBRU0sUUFBUSxJQUFJLENBQUM7QUFHakYsVUFBTWtCLFdBQVdELGFBQWFELE9BQU8sQ0FBQXRCLE1BQUtBLEVBQUV5QixpQkFBaUIsSUFBSTtBQUNqRSxVQUFNQyxjQUFjSCxhQUFhRCxPQUFPLENBQUF0QixNQUFLQSxFQUFFeUIsaUJBQWlCLEtBQUs7QUFFckUsV0FBTztBQUFBLE1BQ0hQLGlCQUFpQkc7QUFBQUEsTUFDakJGLHVCQUF1Qk87QUFBQUEsTUFDdkJOLGtCQUFrQkk7QUFBQUEsSUFDdEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ1QsV0FBVyxDQUFDO0FBRWhCLE1BQUlDLFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsWUFBYSxRQUFPLHVCQUFDLFNBQUksOERBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRDtBQUU1RSxTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSw0REFDWDtBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUNBQXFDO0FBQUE7QUFBQSxVQUNqQkEsWUFBWU47QUFBQUEsYUFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCO0FBQUE7QUFBQSxVQUN0QnRCLFlBQVk0QixZQUFZWSxrQkFBa0IsTUFBTTtBQUFBLGFBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0NaLFlBQVlhLGVBQWUsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsVUFBY2IsWUFBWWE7QUFBQUEsYUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFdBUGhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNYO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1mLFNBQVN0QixrQkFBa0JQLHlCQUF5QjZDLFNBQVMsQ0FBQztBQUFBLFVBQzdFLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsZUFBWSxXQUFVLHdCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE9BQU07QUFBQSxRQUNOLFdBQVdYO0FBQUFBLFFBQ1gsTUFBTSx1QkFBQyxlQUFZLFdBQVUsa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUMzQyxjQUFhO0FBQUE7QUFBQSxNQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJOEM7QUFBQSxJQUc5QztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csT0FBTTtBQUFBLFFBQ04sV0FBV0M7QUFBQUEsUUFDWCxNQUFNLHVCQUFDLGFBQVUsV0FBVSxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQzNDLGNBQWE7QUFBQSxRQUNiLGtCQUFrQjtBQUFBO0FBQUEsTUFMdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSzJCO0FBQUEsSUFFM0I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE9BQU07QUFBQSxRQUNOLFdBQVdDO0FBQUFBLFFBQ1gsTUFBTSx1QkFBQyxhQUFVLFdBQVUsbUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUMxQyxjQUFhO0FBQUE7QUFBQSxNQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJZ0Q7QUFBQSxPQXpDcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQTtBQUVSO0FBQUVSLEdBL0VXRCx1QkFBcUI7QUFBQSxVQUNmOUIsV0FDRUMsYUFDNkJDLFdBQVc7QUFBQTtBQUFBK0MsTUFIaERuQjtBQUFxQixJQUFBRCxJQUFBb0I7QUFBQUMsYUFBQXJCLElBQUE7QUFBQXFCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZU1lbW8iLCJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsInVzZUNydWRJdGVtIiwiZnJhY3Rpb25pbmdzTW9kdWxlQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJJb0Fycm93QmFjayIsImZvcm1hdFZhbHVlIiwiRmFBcnJvd0Rvd24iLCJGYUFycm93VXAiLCJGYVVuZG9BbHQiLCJnZXRMaXN0UmV0dXJuUGF0aCIsIk1vdmVtZW50c1RhYmxlIiwidGl0bGUiLCJtb3ZlbWVudHMiLCJpY29uIiwiZW1wdHlNZXNzYWdlIiwic2hvd0V4dHJhQ29sdW1ucyIsImxlbmd0aCIsIm1hcCIsIm0iLCJwcm9kdWN0X25hbWUiLCJwcm9kdWN0X2lkIiwiTWF0aCIsImFicyIsInBhcnNlRmxvYXQiLCJxdWFudGl0eSIsImFkZGl0aW9uYWxfY29zdCIsIm9ic2VydmF0aW9uIiwiaWQiLCJfYyIsIkZyYWN0aW9uaW5nRGV0YWlsUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJpdGVtIiwiZnJhY3Rpb25pbmciLCJsb2FkaW5nIiwiZXJyb3IiLCJzb3VyY2VNb3ZlbWVudHMiLCJuZXdSZXN1bHRpbmdNb3ZlbWVudHMiLCJyZW1uYW50TW92ZW1lbnRzIiwic291cmNlIiwiZmlsdGVyIiwiYWxsUmVzdWx0aW5nIiwicmVtbmFudHMiLCJpc19yZW1hbmVudGUiLCJuZXdQcm9kdWN0cyIsImZyYWN0aW9uaW5nX2RhdGUiLCJkZXNjcmlwdGlvbiIsImJhc2VSb3V0ZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGcmFjdGlvbmluZ0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBmcmFjdGlvbmluZ3NNb2R1bGVDb25maWcsIHR5cGUgRnJhY3Rpb25pbmcsIHR5cGUgRnJhY3Rpb25pbmdNb3ZlbWVudCB9IGZyb20gJy4uL2ZyYWN0aW9uaW5ncy5jb25maWcudHN4JztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjayB9IGZyb20gJ3JlYWN0LWljb25zL2lvNSc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgRmFBcnJvd0Rvd24sIEZhQXJyb3dVcCwgRmFVbmRvQWx0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbi8vIENvbXBvbmVudGUgcmV1dGlsaXphYmxlIHBhcmEgbGFzIHRhYmxhcyBkZSBtb3ZpbWllbnRvcyAoc2luIGNhbWJpb3MpXG5jb25zdCBNb3ZlbWVudHNUYWJsZSA9ICh7XG4gICAgdGl0bGUsXG4gICAgbW92ZW1lbnRzLFxuICAgIGljb24sXG4gICAgZW1wdHlNZXNzYWdlLFxuICAgIHNob3dFeHRyYUNvbHVtbnMgPSBmYWxzZVxufToge1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgbW92ZW1lbnRzOiBGcmFjdGlvbmluZ01vdmVtZW50W10sXG4gICAgaWNvbjogUmVhY3QuUmVhY3ROb2RlLFxuICAgIGVtcHR5TWVzc2FnZTogc3RyaW5nLFxuICAgIHNob3dFeHRyYUNvbHVtbnM/OiBib29sZWFuXG59KSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxuICAgICAgICAgICAge2ljb259XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yXCI+e3RpdGxlfTwvc3Bhbj5cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+UHJvZHVjdG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnRpZGFkPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93RXh0cmFDb2x1bW5zICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q29zdG8gQWRpY2lvbmFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk9ic2VydmFjacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bW92ZW1lbnRzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICBtb3ZlbWVudHMubWFwKG0gPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e20uaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj57bS5wcm9kdWN0X25hbWUgfHwgYElEOiAke20ucHJvZHVjdF9pZH1gfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e01hdGguYWJzKHBhcnNlRmxvYXQobS5xdWFudGl0eSkpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93RXh0cmFDb2x1bW5zICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUobS5hZGRpdGlvbmFsX2Nvc3QsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57bS5vYnNlcnZhdGlvbiB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXtzaG93RXh0cmFDb2x1bW5zID8gNCA6IDJ9IGNsYXNzTmFtZT1cInB4LTYgcHktNCB0ZXh0LXNtIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj57ZW1wdHlNZXNzYWdlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbik7XG5cbmV4cG9ydCBjb25zdCBGcmFjdGlvbmluZ0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IGZyYWN0aW9uaW5nLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08RnJhY3Rpb25pbmc+KGZyYWN0aW9uaW5nc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgLy8g4pyFIEzDk0dJQ0EgQ09SUkVHSURBOiBVc2Ftb3MgJ2lzX3JlbW5hbnQnIHBhcmEgbGEgc2VwYXJhY2nDs25cbiAgICBjb25zdCB7IHNvdXJjZU1vdmVtZW50cywgbmV3UmVzdWx0aW5nTW92ZW1lbnRzLCByZW1uYW50TW92ZW1lbnRzIH0gPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFmcmFjdGlvbmluZz8ubW92ZW1lbnRzKSB7XG4gICAgICAgICAgICByZXR1cm4geyBzb3VyY2VNb3ZlbWVudHM6IFtdLCBuZXdSZXN1bHRpbmdNb3ZlbWVudHM6IFtdLCByZW1uYW50TW92ZW1lbnRzOiBbXSB9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gMS4gUHJvZHVjdG9zIGRlIE9yaWdlbiAoY2FudGlkYWQgbmVnYXRpdmEpXG4gICAgICAgIGNvbnN0IHNvdXJjZSA9IGZyYWN0aW9uaW5nLm1vdmVtZW50cy5maWx0ZXIobSA9PiBwYXJzZUZsb2F0KG0ucXVhbnRpdHkpIDwgMCk7XG5cbiAgICAgICAgLy8gMi4gVG9kb3MgbG9zIHByb2R1Y3RvcyBnZW5lcmFkb3MgKGNhbnRpZGFkIHBvc2l0aXZhKVxuICAgICAgICBjb25zdCBhbGxSZXN1bHRpbmcgPSBmcmFjdGlvbmluZy5tb3ZlbWVudHMuZmlsdGVyKG0gPT4gcGFyc2VGbG9hdChtLnF1YW50aXR5KSA+IDApO1xuXG4gICAgICAgIC8vIDMuIFNlcGFyYW1vcyBsb3MgZ2VuZXJhZG9zIHVzYW5kbyBsYSBiYW5kZXJhICdpc19yZW1uYW50J1xuICAgICAgICBjb25zdCByZW1uYW50cyA9IGFsbFJlc3VsdGluZy5maWx0ZXIobSA9PiBtLmlzX3JlbWFuZW50ZSA9PT0gdHJ1ZSk7XG4gICAgICAgIGNvbnN0IG5ld1Byb2R1Y3RzID0gYWxsUmVzdWx0aW5nLmZpbHRlcihtID0+IG0uaXNfcmVtYW5lbnRlID09PSBmYWxzZSk7XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNvdXJjZU1vdmVtZW50czogc291cmNlLFxuICAgICAgICAgICAgbmV3UmVzdWx0aW5nTW92ZW1lbnRzOiBuZXdQcm9kdWN0cyxcbiAgICAgICAgICAgIHJlbW5hbnRNb3ZlbWVudHM6IHJlbW5hbnRzXG4gICAgICAgIH07XG4gICAgfSwgW2ZyYWN0aW9uaW5nXSk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFmcmFjdGlvbmluZykgcmV0dXJuIDxkaXY+Tm8gc2UgZW5jb250csOzIGVsIHJlZ2lzdHJvIGRlIGZyYWNjaW9uYW1pZW50by48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgYm9yZGVyLWIgc206ZmxleCBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEZXRhbGxlIGRlbCBGcmFjY2lvbmFtaWVudG8gI3tmcmFjdGlvbmluZy5pZH1cbiAgICAgICAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWxpemFkbyBlbDoge2Zvcm1hdFZhbHVlKGZyYWN0aW9uaW5nLmZyYWN0aW9uaW5nX2RhdGUsICdkYXRlJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAge2ZyYWN0aW9uaW5nLmRlc2NyaXB0aW9uICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+RGVzY3JpcGNpw7NuOiB7ZnJhY3Rpb25pbmcuZGVzY3JpcHRpb259PC9wPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgc206bXQtMFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGZyYWN0aW9uaW5nc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgVm9sdmVyIGFsIExpc3RhZG9cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPE1vdmVtZW50c1RhYmxlXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJQcm9kdWN0b3MgZGUgT3JpZ2VuIChDb25zdW1pZG9zKVwiXG4gICAgICAgICAgICAgICAgbW92ZW1lbnRzPXtzb3VyY2VNb3ZlbWVudHN9XG4gICAgICAgICAgICAgICAgaWNvbj17PEZhQXJyb3dEb3duIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiIC8+fVxuICAgICAgICAgICAgICAgIGVtcHR5TWVzc2FnZT1cIk5vIGhheSBwcm9kdWN0b3MgZGUgb3JpZ2VuLlwiXG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8TW92ZW1lbnRzVGFibGVcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlByb2R1Y3RvcyBSZXN1bHRhbnRlcyAoR2VuZXJhZG9zKVwiXG4gICAgICAgICAgICAgICAgbW92ZW1lbnRzPXtuZXdSZXN1bHRpbmdNb3ZlbWVudHN9XG4gICAgICAgICAgICAgICAgaWNvbj17PEZhQXJyb3dVcCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMFwiIC8+fVxuICAgICAgICAgICAgICAgIGVtcHR5TWVzc2FnZT1cIk5vIHNlIGdlbmVyYXJvbiBudWV2b3MgcHJvZHVjdG9zLlwiXG4gICAgICAgICAgICAgICAgc2hvd0V4dHJhQ29sdW1ucz17dHJ1ZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8TW92ZW1lbnRzVGFibGVcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbWFuZW50ZXMgKERldnVlbHRvcyBhbCBTdG9jaylcIlxuICAgICAgICAgICAgICAgIG1vdmVtZW50cz17cmVtbmFudE1vdmVtZW50c31cbiAgICAgICAgICAgICAgICBpY29uPXs8RmFVbmRvQWx0IGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPn1cbiAgICAgICAgICAgICAgICBlbXB0eU1lc3NhZ2U9XCJObyBodWJvIHByb2R1Y3RvcyByZW1hbmVudGVzLlwiXG5cbiAgICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvZnJhY3Rpb25pbmdzL3BhZ2VzL0ZyYWN0aW9uaW5nRGV0YWlsUGFnZS50c3gifQ==