import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/usuarios/pages/UsuariosCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/usuarios/pages/UsuariosCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { usuariosModuleConfig } from "/src/features/usuarios/usuarios.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import __vite__cjsImport8_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport8_react["useEffect"]; const useState = __vite__cjsImport8_react["useState"]; const useMemo = __vite__cjsImport8_react["useMemo"];
import { getAll } from "/src/services/apiService.ts";
const initialUserValues = {
  name: "",
  email: "",
  phone: "",
  password: "",
  password_confirmation: "",
  role_id: void 0
};
export const UsuarioCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(usuariosModuleConfig);
  const [profiles, setProfiles] = useState([]);
  useEffect(() => {
    getAll("profiles").then((response) => setProfiles(response.data));
  }, []);
  const handleSave = async (data) => {
    if (data.password !== data.password_confirmation) {
      toast.error("Las contraseñas no coinciden.");
      return;
    }
    if (!data.password) {
      toast.error("El campo de contraseña es obligatorio.");
      return;
    }
    if (data.password.length < 8) {
      toast.error("La clave debe tener al menos 8 caracteres.");
      return;
    }
    const payload = { ...data };
    delete payload.password_confirmation;
    if (payload.role_id) {
      payload.role_id = Number(payload.role_id);
    }
    const newUser = await saveItem(payload);
    if (newUser) {
      toast.info(`Usuario "${payload.name}" creado con éxito!`);
      navigate("/configuracion/usuarios");
    }
  };
  const formConfigWithProfiles = useMemo(() => {
    const newConfig = JSON.parse(JSON.stringify(usuariosModuleConfig));
    newConfig.form.block = newConfig.form.block.map((block) => {
      const updatedFields = block.fields.map((field) => {
        if (field.name === "role_id") {
          return {
            ...field,
            options: profiles.map((p) => ({ value: p.id, label: p.name }))
          };
        }
        return field;
      });
      return { ...block, fields: updatedFields };
    });
    return newConfig;
  }, [profiles]);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: formConfigWithProfiles,
      initialData: initialUserValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/usuarios/pages/UsuariosCreatePage.tsx",
      lineNumber: 109,
      columnNumber: 5
    },
    this
  );
};
_s(UsuarioCreatePage, "b76oQ+CcV6Erzy1eU1K0b2hCDJM=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = UsuarioCreatePage;
var _c;
$RefreshReg$(_c, "UsuarioCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/usuarios/pages/UsuariosCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/usuarios/pages/UsuariosCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhGUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDRCQUEwQztBQUNuRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUV0QixTQUFTQyxXQUFXQyxVQUFVQyxlQUFlO0FBQzdDLFNBQVNDLGNBQWM7QUFHdkIsTUFBTUMsb0JBQXNDO0FBQUEsRUFDeENDLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyx1QkFBdUI7QUFBQSxFQUN2QkMsU0FBU0M7QUFDYjtBQUVPLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLFdBQVduQixZQUFZO0FBQzdCLFFBQU0sRUFBRW9CLFNBQVMsSUFBSWpCLFlBQXFCRCxvQkFBb0I7QUFDOUQsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJaEIsU0FBb0IsRUFBRTtBQUV0REQsWUFBVSxNQUFNO0FBQ1pHLFdBQWdCLFVBQVUsRUFBRWUsS0FBSyxDQUFBQyxhQUFZRixZQUFZRSxTQUFTQyxJQUFJLENBQUM7QUFBQSxFQUMzRSxHQUFHLEVBQUU7QUFFTCxRQUFNQyxhQUFhLE9BQU9ELFNBQWtCO0FBQ3hDLFFBQUlBLEtBQUtaLGFBQWFZLEtBQUtYLHVCQUF1QjtBQUM5Q1YsWUFBTXVCLE1BQU0sK0JBQStCO0FBQzNDO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ0YsS0FBS1osVUFBVTtBQUNoQlQsWUFBTXVCLE1BQU0sd0NBQXdDO0FBQ3BEO0FBQUEsSUFDSjtBQUVBLFFBQUlGLEtBQUtaLFNBQVNlLFNBQVMsR0FBRztBQUMxQnhCLFlBQU11QixNQUFNLDRDQUE0QztBQUN4RDtBQUFBLElBQ0o7QUFHQSxVQUFNRSxVQUFVLEVBQUUsR0FBR0osS0FBSztBQUUxQixXQUFPSSxRQUFRZjtBQUdmLFFBQUllLFFBQVFkLFNBQVM7QUFDakJjLGNBQVFkLFVBQVVlLE9BQU9ELFFBQVFkLE9BQU87QUFBQSxJQUM1QztBQUVBLFVBQU1nQixVQUFVLE1BQU1YLFNBQVNTLE9BQU87QUFDdEMsUUFBSUUsU0FBUztBQUNUM0IsWUFBTTRCLEtBQUssWUFBWUgsUUFBUW5CLElBQUkscUJBQXFCO0FBQ3hEUyxlQUFTLHlCQUF5QjtBQUFBLElBQ3RDO0FBQUEsRUFDSjtBQUlBLFFBQU1jLHlCQUF5QjFCLFFBQVEsTUFBTTtBQUV6QyxVQUFNMkIsWUFBWUMsS0FBS0MsTUFBTUQsS0FBS0UsVUFBVW5DLG9CQUFvQixDQUFDO0FBR2pFZ0MsY0FBVUksS0FBS0MsUUFBUUwsVUFBVUksS0FBS0MsTUFBTUMsSUFBSSxDQUFDRCxVQUFrRDtBQUUvRixZQUFNRSxnQkFBZ0JGLE1BQU1HLE9BQU9GLElBQUksQ0FBQ0csVUFBb0M7QUFFeEUsWUFBSUEsTUFBTWpDLFNBQVMsV0FBVztBQUMxQixpQkFBTztBQUFBLFlBQ0gsR0FBR2lDO0FBQUFBLFlBQ0hDLFNBQVN2QixTQUFTbUIsSUFBSSxDQUFBSyxPQUFNLEVBQUVDLE9BQU9ELEVBQUVFLElBQUlDLE9BQU9ILEVBQUVuQyxLQUFLLEVBQUU7QUFBQSxVQUMvRDtBQUFBLFFBQ0o7QUFDQSxlQUFPaUM7QUFBQUEsTUFDWCxDQUFDO0FBRUQsYUFBTyxFQUFFLEdBQUdKLE9BQU9HLFFBQVFELGNBQWM7QUFBQSxJQUM3QyxDQUFDO0FBRUQsV0FBT1A7QUFBQUEsRUFDWCxHQUFHLENBQUNiLFFBQVEsQ0FBQztBQUViLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFZO0FBQUFBLE1BQ1IsYUFBYXhCO0FBQUFBLE1BQ2IsUUFBUWlCO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUI7QUFHekI7QUFBRVIsR0E1RVdELG1CQUFpQjtBQUFBLFVBQ1RqQixhQUNJRyxXQUFXO0FBQUE7QUFBQThDLEtBRnZCaEM7QUFBaUIsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VOYXZpZ2F0ZSIsIkdlbmVyaWNGb3JtUGFnZSIsInVzdWFyaW9zTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJ0b2FzdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImdldEFsbCIsImluaXRpYWxVc2VyVmFsdWVzIiwibmFtZSIsImVtYWlsIiwicGhvbmUiLCJwYXNzd29yZCIsInBhc3N3b3JkX2NvbmZpcm1hdGlvbiIsInJvbGVfaWQiLCJ1bmRlZmluZWQiLCJVc3VhcmlvQ3JlYXRlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJzYXZlSXRlbSIsInByb2ZpbGVzIiwic2V0UHJvZmlsZXMiLCJ0aGVuIiwicmVzcG9uc2UiLCJkYXRhIiwiaGFuZGxlU2F2ZSIsImVycm9yIiwibGVuZ3RoIiwicGF5bG9hZCIsIk51bWJlciIsIm5ld1VzZXIiLCJpbmZvIiwiZm9ybUNvbmZpZ1dpdGhQcm9maWxlcyIsIm5ld0NvbmZpZyIsIkpTT04iLCJwYXJzZSIsInN0cmluZ2lmeSIsImZvcm0iLCJibG9jayIsIm1hcCIsInVwZGF0ZWRGaWVsZHMiLCJmaWVsZHMiLCJmaWVsZCIsIm9wdGlvbnMiLCJwIiwidmFsdWUiLCJpZCIsImxhYmVsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVXN1YXJpb3NDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvZmVhdHVyZXMvdXN1YXJpb3MvcGFnZXMvVXN1YXJpb0NyZWF0ZVBhZ2UudHN4XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHVzdWFyaW9zTW9kdWxlQ29uZmlnLCB0eXBlIFVzdWFyaW8gfSBmcm9tICcuLi91c3Vhcmlvcy5jb25maWcudHN4JztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgdHlwZSB7IFByb2ZpbGUgfSBmcm9tICcuLi8uLi9wcm9maWxlcy9wcm9maWxlcy5jb25maWcudHN4JztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRBbGwgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlLnRzJztcbmltcG9ydCB0eXBlIHsgRm9ybUZpZWxkQ29uZmlnIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlLnRzJztcblxuY29uc3QgaW5pdGlhbFVzZXJWYWx1ZXM6IFBhcnRpYWw8VXN1YXJpbz4gPSB7XG4gICAgbmFtZTogJycsXG4gICAgZW1haWw6ICcnLFxuICAgIHBob25lOiAnJyxcbiAgICBwYXNzd29yZDogJycsXG4gICAgcGFzc3dvcmRfY29uZmlybWF0aW9uOiAnJyxcbiAgICByb2xlX2lkOiB1bmRlZmluZWQsXG59O1xuXG5leHBvcnQgY29uc3QgVXN1YXJpb0NyZWF0ZVBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgc2F2ZUl0ZW0gfSA9IHVzZUNydWRJdGVtPFVzdWFyaW8+KHVzdWFyaW9zTW9kdWxlQ29uZmlnKTtcbiAgICBjb25zdCBbcHJvZmlsZXMsIHNldFByb2ZpbGVzXSA9IHVzZVN0YXRlPFByb2ZpbGVbXT4oW10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZ2V0QWxsPFByb2ZpbGU+KCdwcm9maWxlcycpLnRoZW4ocmVzcG9uc2UgPT4gc2V0UHJvZmlsZXMocmVzcG9uc2UuZGF0YSkpO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogVXN1YXJpbykgPT4ge1xuICAgICAgICBpZiAoZGF0YS5wYXNzd29yZCAhPT0gZGF0YS5wYXNzd29yZF9jb25maXJtYXRpb24pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdMYXMgY29udHJhc2XDsWFzIG5vIGNvaW5jaWRlbi4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghZGF0YS5wYXNzd29yZCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIGNhbXBvIGRlIGNvbnRyYXNlw7FhIGVzIG9ibGlnYXRvcmlvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRhdGEucGFzc3dvcmQubGVuZ3RoIDwgOCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0xhIGNsYXZlIGRlYmUgdGVuZXIgYWwgbWVub3MgOCBjYXJhY3RlcmVzLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ3JlYW1vcyB1bmEgY29waWEgZGVsIHBheWxvYWQgcGFyYSBubyBtb2RpZmljYXIgZWwgZXN0YWRvIG9yaWdpbmFsXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7IC4uLmRhdGEgfTtcbiAgICAgICAgLy8gRWxpbWluYW1vcyBlbCBjYW1wbyBkZSBjb25maXJtYWNpw7NuIGFudGVzIGRlIGVudmlhcmxvIGEgbGEgQVBJXG4gICAgICAgIGRlbGV0ZSBwYXlsb2FkLnBhc3N3b3JkX2NvbmZpcm1hdGlvbjtcblxuICAgICAgICAvLyBBc2VndXJhbW9zIHF1ZSByb2xlX2lkIGVzIHVuIG7Dum1lcm9cbiAgICAgICAgaWYgKHBheWxvYWQucm9sZV9pZCkge1xuICAgICAgICAgICAgcGF5bG9hZC5yb2xlX2lkID0gTnVtYmVyKHBheWxvYWQucm9sZV9pZCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdVc2VyID0gYXdhaXQgc2F2ZUl0ZW0ocGF5bG9hZCk7XG4gICAgICAgIGlmIChuZXdVc2VyKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKGBVc3VhcmlvIFwiJHtwYXlsb2FkLm5hbWV9XCIgY3JlYWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2NvbmZpZ3VyYWNpb24vdXN1YXJpb3MnKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyAtLS0g4pyFIENPUlJFQ0NJw5NOIFBSSU5DSVBBTCAtLS1cbiAgICAvLyBVc2Ftb3MgdXNlTWVtbyBwYXJhIGV2aXRhciByZWNhbGN1bGFyIGxhIGNvbmZpZ3VyYWNpw7NuIGVuIGNhZGEgcmVuZGVyaXphZG8uXG4gICAgY29uc3QgZm9ybUNvbmZpZ1dpdGhQcm9maWxlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICAvLyBIYWNlbW9zIHVuYSBjb3BpYSBwcm9mdW5kYSBwYXJhIG5vIG11dGFyIGxhIGNvbmZpZ3VyYWNpw7NuIG9yaWdpbmFsIGltcG9ydGFkYVxuICAgICAgICBjb25zdCBuZXdDb25maWcgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHVzdWFyaW9zTW9kdWxlQ29uZmlnKSk7XG5cbiAgICAgICAgLy8gTWFwZWFtb3MgYSB0cmF2w6lzIGRlIGNhZGEgYmxvcXVlXG4gICAgICAgIG5ld0NvbmZpZy5mb3JtLmJsb2NrID0gbmV3Q29uZmlnLmZvcm0uYmxvY2subWFwKChibG9jazogeyBmaWVsZHM6IEZvcm1GaWVsZENvbmZpZzxVc3VhcmlvPltdIH0pID0+IHtcbiAgICAgICAgICAgIC8vIERlbnRybyBkZSBjYWRhIGJsb3F1ZSwgbWFwZWFtb3MgYSB0cmF2w6lzIGRlIGxvcyBjYW1wb3NcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZHMgPSBibG9jay5maWVsZHMubWFwKChmaWVsZDogRm9ybUZpZWxkQ29uZmlnPFVzdWFyaW8+KSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gU2kgZW5jb250cmFtb3MgZWwgY2FtcG8gJ3JvbGVfaWQnLCBsZSBpbnllY3RhbW9zIGxhcyBvcGNpb25lc1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZC5uYW1lID09PSAncm9sZV9pZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZpZWxkLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogcHJvZmlsZXMubWFwKHAgPT4gKHsgdmFsdWU6IHAuaWQsIGxhYmVsOiBwLm5hbWUgfSkpXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBmaWVsZDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLy8gRGV2b2x2ZW1vcyBlbCBibG9xdWUgY29uIGxvcyBjYW1wb3MgYWN0dWFsaXphZG9zXG4gICAgICAgICAgICByZXR1cm4geyAuLi5ibG9jaywgZmllbGRzOiB1cGRhdGVkRmllbGRzIH07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBuZXdDb25maWc7XG4gICAgfSwgW3Byb2ZpbGVzXSk7IC8vIEVzdGEgZnVuY2nDs24gc29sbyBzZSB2b2x2ZXLDoSBhIGVqZWN1dGFyIHNpICdwcm9maWxlcycgY2FtYmlhXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICBjb25maWc9e2Zvcm1Db25maWdXaXRoUHJvZmlsZXN9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFVzZXJWYWx1ZXMgYXMgVXN1YXJpb31cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJjcmVhdGVcIlxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3Vhcmlvc0NyZWF0ZVBhZ2UudHN4In0=