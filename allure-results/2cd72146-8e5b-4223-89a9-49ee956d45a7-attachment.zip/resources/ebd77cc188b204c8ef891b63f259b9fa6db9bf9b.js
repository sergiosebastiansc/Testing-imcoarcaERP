import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/AlertModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/AlertModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export const AlertModal = ({ isOpen, onClose, title, message, confirmLabel = "Aceptar" }) => {
  if (!isOpen) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50", "aria-modal": "true", role: "alertdialog", "aria-labelledby": "alert-modal-title", "aria-describedby": "alert-modal-message", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md p-6 mx-4 bg-white rounded-lg shadow-xl", children: [
    /* @__PURE__ */ jsxDEV("h3", { id: "alert-modal-title", className: "text-lg font-bold text-gray-900", children: title }, void 0, false, {
      fileName: "/app/src/components/ui/AlertModal.tsx",
      lineNumber: 37,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("p", { id: "alert-modal-message", className: "mt-2 text-sm text-gray-600", children: message }, void 0, false, {
      fileName: "/app/src/components/ui/AlertModal.tsx",
      lineNumber: 40,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-6", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onClose,
        className: "px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
        children: confirmLabel
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/ui/AlertModal.tsx",
        lineNumber: 44,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/ui/AlertModal.tsx",
      lineNumber: 43,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/ui/AlertModal.tsx",
    lineNumber: 36,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/ui/AlertModal.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
};
_c = AlertModal;
var _c;
$RefreshReg$(_c, "AlertModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/AlertModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/AlertModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJnQjs7Ozs7Ozs7Ozs7Ozs7OztBQVJULGFBQU1BLGFBQWFBLENBQUMsRUFBRUMsUUFBUUMsU0FBU0MsT0FBT0MsU0FBU0MsZUFBZSxVQUEyQixNQUFNO0FBQzFHLE1BQUksQ0FBQ0osUUFBUTtBQUNULFdBQU87QUFBQSxFQUNYO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsbUVBQWtFLGNBQVcsUUFBTyxNQUFLLGVBQWMsbUJBQWdCLHFCQUFvQixvQkFBaUIsdUJBQ3ZLLGlDQUFDLFNBQUksV0FBVSwwREFDWDtBQUFBLDJCQUFDLFFBQUcsSUFBRyxxQkFBb0IsV0FBVSxtQ0FDaENFLG1CQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxJQUFHLHVCQUFzQixXQUFVLDhCQUNqQ0MscUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFNBQVNGO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVRHO0FBQUFBO0FBQUFBLE1BTEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVSO0FBQUVDLEtBMUJXTjtBQUFVLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJBbGVydE1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsInRpdGxlIiwibWVzc2FnZSIsImNvbmZpcm1MYWJlbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFsZXJ0TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBBbGVydE1vZGFsUHJvcHMge1xuICAgIGlzT3BlbjogYm9vbGVhbjtcbiAgICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIC8qKiBUZXh0byBkZWwgYm90w7NuIGRlIGNpZXJyZTsgcG9yIGRlZmVjdG8gXCJBY2VwdGFyXCIgKi9cbiAgICBjb25maXJtTGFiZWw/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBBbGVydE1vZGFsID0gKHsgaXNPcGVuLCBvbkNsb3NlLCB0aXRsZSwgbWVzc2FnZSwgY29uZmlybUxhYmVsID0gJ0FjZXB0YXInIH06IEFsZXJ0TW9kYWxQcm9wcykgPT4ge1xuICAgIGlmICghaXNPcGVuKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzUwXCIgYXJpYS1tb2RhbD1cInRydWVcIiByb2xlPVwiYWxlcnRkaWFsb2dcIiBhcmlhLWxhYmVsbGVkYnk9XCJhbGVydC1tb2RhbC10aXRsZVwiIGFyaWEtZGVzY3JpYmVkYnk9XCJhbGVydC1tb2RhbC1tZXNzYWdlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCBwLTYgbXgtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgICAgIDxoMyBpZD1cImFsZXJ0LW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBpZD1cImFsZXJ0LW1vZGFsLW1lc3NhZ2VcIiBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctb2Zmc2V0LTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NvbmZpcm1MYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvdWkvQWxlcnRNb2RhbC50c3gifQ==