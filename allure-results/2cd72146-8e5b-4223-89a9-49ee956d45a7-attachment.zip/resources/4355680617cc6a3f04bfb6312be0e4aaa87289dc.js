import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/dashboards/components/UpcomingPaymentsWidget.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaFileInvoiceDollar, FaSpinner, FaExclamationTriangle, FaArrowLeft } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { getAll } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
export const UpcomingPaymentsWidget = () => {
  _s();
  const [showList, setShowList] = useState(false);
  const [vendorBalances, setVendorBalances] = useState([]);
  const [total, setTotal] = useState(void 0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchVendorBalances = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await getAll("purchases/vendor-balances");
        const list = response?.balances ?? (Array.isArray(response) ? response : []);
        setVendorBalances(Array.isArray(list) ? list : []);
        if (response?.total != null) {
          setTotal(response.total);
        }
      } catch (err) {
        console.error("Error fetching vendor balances:", err);
        setError("No se pudo cargar el resumen de saldos.");
        setVendorBalances([]);
      } finally {
        setLoading(false);
      }
    };
    fetchVendorBalances();
  }, []);
  const handleVendorClick = (vendorId) => {
    navigate(`/proveedores/${vendorId}?tab=movements`);
  };
  const renderCardView = () => /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "button",
      tabIndex: 0,
      onClick: () => setShowList(true),
      onKeyDown: (e) => e.key === "Enter" && setShowList(true),
      className: "p-6 bg-white rounded-lg shadow-md h-full cursor-pointer hover:bg-gray-50 transition-colors",
      children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-700", children: "Total Saldo Proveedores" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 80,
          columnNumber: 13
        }, this),
        loading && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500", children: "Cargando..." }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 82,
          columnNumber: 25
        }, this),
        error && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 font-semibold text-red-500 flex items-center", children: [
          /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "mr-2" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
            lineNumber: 86,
            columnNumber: 21
          }, this),
          " ",
          error
        ] }, void 0, true, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 85,
          columnNumber: 5
        }, this),
        !loading && !error && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold text-red-600", children: total != null ? formatValue(String(total), "currency") : "Sin datos" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
            lineNumber: 92,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Clic para ver detalle por proveedor" }, void 0, false, {
            fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
            lineNumber: 95,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 91,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 73,
      columnNumber: 3
    },
    this
  );
  const renderListView = () => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md flex flex-col", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-gray-200 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 flex items-center", children: [
        /* @__PURE__ */ jsxDEV(FaFileInvoiceDollar, { className: "mr-3 text-indigo-500" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 105,
          columnNumber: 21
        }, this),
        "Saldos Totales por Proveedor"
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
        lineNumber: 104,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setShowList(false),
          className: "text-sm text-indigo-600 hover:text-indigo-800 flex items-center",
          children: [
            /* @__PURE__ */ jsxDEV(FaArrowLeft, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
              lineNumber: 113,
              columnNumber: 21
            }, this),
            " Volver"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 108,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 103,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center p-10", children: /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin text-4xl text-indigo-500" }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 118,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 117,
      columnNumber: 5
    }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "p-4 text-center text-red-500 flex flex-col items-center", children: [
      /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "mb-2" }, void 0, false, {
        fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
        lineNumber: 122,
        columnNumber: 21
      }, this),
      " ",
      error
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 121,
      columnNumber: 5
    }, this) : !vendorBalances || vendorBalances.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "p-4 text-sm text-center text-gray-500", children: "No hay proveedores con saldo pendiente." }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 125,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-y-auto max-h-80", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Proveedor" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 131,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Saldo Total" }, void 0, false, {
          fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
          lineNumber: 132,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
        lineNumber: 130,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
        lineNumber: 129,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: vendorBalances.map(
        (vendor) => /* @__PURE__ */ jsxDEV(
          "tr",
          {
            onClick: () => handleVendorClick(vendor.vendor_id),
            className: "hover:bg-gray-50 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900", children: vendor.vendor_name }, void 0, false, {
                fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
                lineNumber: 142,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 whitespace-nowrap text-sm text-right font-semibold text-red-600", children: formatValue(vendor.total_balance, "currency") }, void 0, false, {
                fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
                lineNumber: 143,
                columnNumber: 37
              }, this)
            ]
          },
          vendor.vendor_id,
          true,
          {
            fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
            lineNumber: 137,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
        lineNumber: 135,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 128,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
      lineNumber: 127,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx",
    lineNumber: 102,
    columnNumber: 3
  }, this);
  return showList ? renderListView() : renderCardView();
};
_s(UpcomingPaymentsWidget, "3LHM/o4KL7NgKFOejRjvHx4sjFI=", false, function() {
  return [useNavigate];
});
_c = UpcomingPaymentsWidget;
var _c;
$RefreshReg$(_c, "UpcomingPaymentsWidget");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/dashboards/components/UpcomingPaymentsWidget.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVEWixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHFCQUFxQkMsV0FBV0MsdUJBQXVCQyxtQkFBbUI7QUFDbkYsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxtQkFBbUI7QUFhckIsYUFBTUMseUJBQXlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlYLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNZLGdCQUFnQkMsaUJBQWlCLElBQUliLFNBQTBCLEVBQUU7QUFDeEUsUUFBTSxDQUFDYyxPQUFPQyxRQUFRLElBQUlmLFNBQXNDZ0IsTUFBUztBQUN6RSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWxCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNtQixPQUFPQyxRQUFRLElBQUlwQixTQUF3QixJQUFJO0FBQ3RELFFBQU1xQixXQUFXcEIsWUFBWTtBQUU3QkYsWUFBVSxNQUFNO0FBQ1osVUFBTXVCLHNCQUFzQixZQUFZO0FBQ3BDSixpQkFBVyxJQUFJO0FBQ2ZFLGVBQVMsSUFBSTtBQUNiLFVBQUk7QUFDQSxjQUFNRyxXQUFXLE1BQU1qQixPQUFPLDJCQUEyQjtBQUN6RCxjQUFNa0IsT0FBT0QsVUFBVUUsYUFBYUMsTUFBTUMsUUFBUUosUUFBUSxJQUFJQSxXQUFXO0FBQ3pFViwwQkFBa0JhLE1BQU1DLFFBQVFILElBQUksSUFBSUEsT0FBTyxFQUFFO0FBQ2pELFlBQUlELFVBQVVULFNBQVMsTUFBTTtBQUN6QkMsbUJBQVNRLFNBQVNULEtBQUs7QUFBQSxRQUMzQjtBQUFBLE1BQ0osU0FBU2MsS0FBSztBQUNWQyxnQkFBUVYsTUFBTSxtQ0FBbUNTLEdBQUc7QUFDcERSLGlCQUFTLHlDQUF5QztBQUNsRFAsMEJBQWtCLEVBQUU7QUFBQSxNQUN4QixVQUFDO0FBQ0dLLG1CQUFXLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFFQUksd0JBQW9CO0FBQUEsRUFDeEIsR0FBRyxFQUFFO0FBRUwsUUFBTVEsb0JBQW9CQSxDQUFDQyxhQUFxQjtBQUM1Q1YsYUFBUyxnQkFBZ0JVLFFBQVEsZ0JBQWdCO0FBQUEsRUFDckQ7QUFFQSxRQUFNQyxpQkFBaUJBLE1BQ25CO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTCxVQUFVO0FBQUEsTUFDVixTQUFTLE1BQU1yQixZQUFZLElBQUk7QUFBQSxNQUMvQixXQUFXLENBQUNzQixNQUFNQSxFQUFFQyxRQUFRLFdBQVd2QixZQUFZLElBQUk7QUFBQSxNQUN2RCxXQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsdUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUUxRU0sV0FBVyx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLDJCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFFeERFLFNBQ0csdUJBQUMsT0FBRSxXQUFVLHFEQUNUO0FBQUEsaUNBQUMseUJBQXNCLFdBQVUsVUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUFHO0FBQUEsVUFBRUE7QUFBQUEsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHSCxDQUFDRixXQUFXLENBQUNFLFNBQ1YsdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsbUNBQ1JMLG1CQUFTLE9BQU9QLFlBQVk0QixPQUFPckIsS0FBSyxHQUFHLFVBQVUsSUFBSSxlQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG1EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLGFBSmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBO0FBQUE7QUFBQSxJQXZCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF5QkE7QUFHSixRQUFNc0IsaUJBQWlCQSxNQUNuQix1QkFBQyxTQUFJLFdBQVUsK0NBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0VBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQ1Y7QUFBQSwrQkFBQyx1QkFBb0IsV0FBVSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBO0FBQUEsV0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNekIsWUFBWSxLQUFLO0FBQUEsVUFDaEMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsVUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUE7QUFBQTtBQUFBLFFBTHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUNDTSxVQUNHLHVCQUFDLFNBQUksV0FBVSx5Q0FDWCxpQ0FBQyxhQUFVLFdBQVUsMkNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQsS0FEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBQ0FFLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNYO0FBQUEsNkJBQUMseUJBQXNCLFdBQVUsVUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQUc7QUFBQSxNQUFFQTtBQUFBQSxTQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFDQSxDQUFDUCxrQkFBa0JBLGVBQWV5QixXQUFXLElBQzdDLHVCQUFDLE9BQUUsV0FBVSx5Q0FBd0MsdURBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEYsSUFFNUYsdUJBQUMsU0FBSSxXQUFVLDRCQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSwyQkFDYixpQ0FBQyxRQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtGQUFpRix5QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RztBQUFBLFFBQ3hHLHVCQUFDLFFBQUcsV0FBVSxtRkFBa0YsMkJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkc7QUFBQSxXQUYvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnpCLHlCQUFlMEI7QUFBQUEsUUFBSSxDQUFDQyxXQUNqQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUcsU0FBUyxNQUFNVCxrQkFBa0JTLE9BQU9DLFNBQVM7QUFBQSxZQUNqRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxpRUFBaUVELGlCQUFPRSxlQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRztBQUFBLGNBQ2xHLHVCQUFDLFFBQUcsV0FBVSw2RUFBNkVsQyxzQkFBWWdDLE9BQU9HLGVBQWUsVUFBVSxLQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5STtBQUFBO0FBQUE7QUFBQSxVQUxwSUgsT0FBT0M7QUFBQUEsVUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsTUFDSCxLQVZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLE9BOUNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFHSixTQUFPOUIsV0FBVzBCLGVBQWUsSUFBSUosZUFBZTtBQUN4RDtBQUFFdkIsR0FySFdELHdCQUFzQjtBQUFBLFVBTWRQLFdBQVc7QUFBQTtBQUFBMEMsS0FObkJuQztBQUFzQixJQUFBbUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJGYUZpbGVJbnZvaWNlRG9sbGFyIiwiRmFTcGlubmVyIiwiRmFFeGNsYW1hdGlvblRyaWFuZ2xlIiwiRmFBcnJvd0xlZnQiLCJnZXRBbGwiLCJmb3JtYXRWYWx1ZSIsIlVwY29taW5nUGF5bWVudHNXaWRnZXQiLCJfcyIsInNob3dMaXN0Iiwic2V0U2hvd0xpc3QiLCJ2ZW5kb3JCYWxhbmNlcyIsInNldFZlbmRvckJhbGFuY2VzIiwidG90YWwiLCJzZXRUb3RhbCIsInVuZGVmaW5lZCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsIm5hdmlnYXRlIiwiZmV0Y2hWZW5kb3JCYWxhbmNlcyIsInJlc3BvbnNlIiwibGlzdCIsImJhbGFuY2VzIiwiQXJyYXkiLCJpc0FycmF5IiwiZXJyIiwiY29uc29sZSIsImhhbmRsZVZlbmRvckNsaWNrIiwidmVuZG9ySWQiLCJyZW5kZXJDYXJkVmlldyIsImUiLCJrZXkiLCJTdHJpbmciLCJyZW5kZXJMaXN0VmlldyIsImxlbmd0aCIsIm1hcCIsInZlbmRvciIsInZlbmRvcl9pZCIsInZlbmRvcl9uYW1lIiwidG90YWxfYmFsYW5jZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVwY29taW5nUGF5bWVudHNXaWRnZXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgRmFGaWxlSW52b2ljZURvbGxhciwgRmFTcGlubmVyLCBGYUV4Y2xhbWF0aW9uVHJpYW5nbGUsIEZhQXJyb3dMZWZ0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgZ2V0QWxsIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuXG5pbnRlcmZhY2UgVmVuZG9yQmFsYW5jZSB7XG4gICAgdmVuZG9yX2lkOiBudW1iZXI7XG4gICAgdmVuZG9yX25hbWU6IHN0cmluZztcbiAgICB0b3RhbF9iYWxhbmNlOiBzdHJpbmc7XG59XG5cbnR5cGUgVmVuZG9yQmFsYW5jZXNSZXNwb25zZSA9IHtcbiAgICB0b3RhbD86IG51bWJlciB8IHN0cmluZztcbiAgICBiYWxhbmNlcz86IFZlbmRvckJhbGFuY2VbXTtcbn07XG5cbmV4cG9ydCBjb25zdCBVcGNvbWluZ1BheW1lbnRzV2lkZ2V0ID0gKCkgPT4ge1xuICAgIGNvbnN0IFtzaG93TGlzdCwgc2V0U2hvd0xpc3RdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt2ZW5kb3JCYWxhbmNlcywgc2V0VmVuZG9yQmFsYW5jZXNdID0gdXNlU3RhdGU8VmVuZG9yQmFsYW5jZVtdPihbXSk7XG4gICAgY29uc3QgW3RvdGFsLCBzZXRUb3RhbF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBzdHJpbmcgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBmZXRjaFZlbmRvckJhbGFuY2VzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldEFsbCgncHVyY2hhc2VzL3ZlbmRvci1iYWxhbmNlcycpIGFzIHVua25vd24gYXMgVmVuZG9yQmFsYW5jZXNSZXNwb25zZTtcbiAgICAgICAgICAgICAgICBjb25zdCBsaXN0ID0gcmVzcG9uc2U/LmJhbGFuY2VzID8/IChBcnJheS5pc0FycmF5KHJlc3BvbnNlKSA/IHJlc3BvbnNlIDogW10pO1xuICAgICAgICAgICAgICAgIHNldFZlbmRvckJhbGFuY2VzKEFycmF5LmlzQXJyYXkobGlzdCkgPyBsaXN0IDogW10pO1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZT8udG90YWwgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBzZXRUb3RhbChyZXNwb25zZS50b3RhbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHZlbmRvciBiYWxhbmNlczpcIiwgZXJyKTtcbiAgICAgICAgICAgICAgICBzZXRFcnJvcignTm8gc2UgcHVkbyBjYXJnYXIgZWwgcmVzdW1lbiBkZSBzYWxkb3MuJyk7XG4gICAgICAgICAgICAgICAgc2V0VmVuZG9yQmFsYW5jZXMoW10pO1xuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBmZXRjaFZlbmRvckJhbGFuY2VzKCk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgaGFuZGxlVmVuZG9yQ2xpY2sgPSAodmVuZG9ySWQ6IG51bWJlcikgPT4ge1xuICAgICAgICBuYXZpZ2F0ZShgL3Byb3ZlZWRvcmVzLyR7dmVuZG9ySWR9P3RhYj1tb3ZlbWVudHNgKTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVuZGVyQ2FyZFZpZXcgPSAoKSA9PiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICAgIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgICAgdGFiSW5kZXg9ezB9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TGlzdCh0cnVlKX1cbiAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSAnRW50ZXInICYmIHNldFNob3dMaXN0KHRydWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC02IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LW1kIGgtZnVsbCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgU2FsZG8gUHJvdmVlZG9yZXM8L2gyPlxuXG4gICAgICAgICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtZ3JheS01MDBcIj5DYXJnYW5kby4uLjwvcD59XG5cbiAgICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCBmb250LXNlbWlib2xkIHRleHQtcmVkLTUwMCBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFFeGNsYW1hdGlvblRyaWFuZ2xlIGNsYXNzTmFtZT1cIm1yLTJcIiAvPiB7ZXJyb3J9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgeyFsb2FkaW5nICYmICFlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbCAhPSBudWxsID8gZm9ybWF0VmFsdWUoU3RyaW5nKHRvdGFsKSwgJ2N1cnJlbmN5JykgOiAnU2luIGRhdG9zJ31cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMlwiPkNsaWMgcGFyYSB2ZXIgZGV0YWxsZSBwb3IgcHJvdmVlZG9yPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcblxuICAgIGNvbnN0IHJlbmRlckxpc3RWaWV3ID0gKCkgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LW1kIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZhRmlsZUludm9pY2VEb2xsYXIgY2xhc3NOYW1lPVwibXItMyB0ZXh0LWluZGlnby01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICBTYWxkb3MgVG90YWxlcyBwb3IgUHJvdmVlZG9yXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TGlzdChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8RmFBcnJvd0xlZnQgY2xhc3NOYW1lPVwibXItMlwiIC8+IFZvbHZlclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdGV4dC00eGwgdGV4dC1pbmRpZ28tNTAwXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBlcnJvciA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCB0ZXh0LWNlbnRlciB0ZXh0LXJlZC01MDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZhRXhjbGFtYXRpb25UcmlhbmdsZSBjbGFzc05hbWU9XCJtYi0yXCIgLz4ge2Vycm9yfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6ICF2ZW5kb3JCYWxhbmNlcyB8fCB2ZW5kb3JCYWxhbmNlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicC00IHRleHQtc20gdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBwcm92ZWVkb3JlcyBjb24gc2FsZG8gcGVuZGllbnRlLjwvcD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy15LWF1dG8gbWF4LWgtODBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBzdGlja3kgdG9wLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Qcm92ZWVkb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlNhbGRvIFRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmVuZG9yQmFsYW5jZXMubWFwKCh2ZW5kb3IpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZlbmRvci52ZW5kb3JfaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVWZW5kb3JDbGljayh2ZW5kb3IudmVuZG9yX2lkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPnt2ZW5kb3IudmVuZG9yX25hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwXCI+e2Zvcm1hdFZhbHVlKHZlbmRvci50b3RhbF9iYWxhbmNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG5cbiAgICByZXR1cm4gc2hvd0xpc3QgPyByZW5kZXJMaXN0VmlldygpIDogcmVuZGVyQ2FyZFZpZXcoKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2Rhc2hib2FyZHMvY29tcG9uZW50cy9VcGNvbWluZ1BheW1lbnRzV2lkZ2V0LnRzeCJ9