import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/pages/ArticulosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/pages/ArticulosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { BulkAdjustSalePriceModal } from "/src/features/articulos/components/BulkAdjustSalePriceModal.tsx";
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { postRaw } from "/src/services/apiService.ts";
import { MultiSelectDropdown } from "/src/components/common/MultiSelectDropdown.tsx";
import { articulosModuleConfig, loadCategories, loadLines } from "/src/features/articulos/articulos.config.tsx";
import {
  buildBulkAdjustSalePriceBodyByIds
} from "/src/features/articulos/utils/bulkAdjustSalePricePayload.ts";
function parseBulkAdjustError(e) {
  if (e && typeof e === "object" && "response" in e) {
    const resp = e.response;
    const data = resp?.data;
    if (data?.errors && typeof data.errors === "object") {
      const msgs = Object.values(data.errors).flat().filter(Boolean);
      if (msgs.length) return msgs.join(" ");
    }
    if (typeof data?.message === "string" && data.message.trim()) return data.message.trim();
  }
  if (e instanceof Error && e.message) return e.message;
  return "No se pudo aplicar el ajuste de precios.";
}
function formatSelectionSummary(items, selectedIds) {
  const selected = items.filter((item) => selectedIds.has(item.id));
  const count = selectedIds.size;
  if (count === 0) return "";
  const labels = selected.map((item) => item.sku || item.name).filter(Boolean);
  if (labels.length <= 5 && labels.length === count) {
    return `${count} producto${count === 1 ? "" : "s"} seleccionado${count === 1 ? "" : "s"}: ${labels.join(", ")}`;
  }
  if (labels.length > 0 && labels.length <= 5) {
    return `${count} producto${count === 1 ? "" : "s"} seleccionado${count === 1 ? "" : "s"} (página visible: ${labels.join(", ")})`;
  }
  return `${count} producto${count === 1 ? "" : "s"} seleccionado${count === 1 ? "" : "s"}`;
}
function normalizeIdFilterFromParams(raw) {
  if (raw === void 0 || raw === null || raw === "") {
    return [];
  }
  if (Array.isArray(raw)) {
    return raw.filter((v) => v !== "" && v !== null && v !== void 0).map((v) => String(v));
  }
  return [String(raw)];
}
function toIdFilterPayload(values) {
  if (values.length === 0) {
    return void 0;
  }
  const ids = values.map(Number).filter((n) => Number.isFinite(n));
  return ids.length > 0 ? ids : void 0;
}
export const ArticulosListPage = () => {
  _s();
  const { hasModulePermission } = usePermissions();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(articulosModuleConfig);
  const modulePermission = getRequiredPermission(articulosModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canBulkAdjustPrice = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const [lineFilter, setLineFilter] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState([]);
  const [lineOptions, setLineOptions] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [selectedIds, setSelectedIds] = useState(/* @__PURE__ */ new Set());
  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [bulkLoading, setBulkLoading] = useState(false);
  const refreshOptions = useCallback(async () => {
    try {
      const [lines, categories] = await Promise.all([loadLines(), loadCategories()]);
      setLineOptions(lines);
      setCategoryOptions(categories);
    } catch {
      setLineOptions([]);
      setCategoryOptions([]);
    }
  }, []);
  useEffect(() => {
    void refreshOptions();
  }, [refreshOptions]);
  useEffect(() => {
    setLineFilter(normalizeIdFilterFromParams(searchParams.line));
  }, [searchParams.line]);
  useEffect(() => {
    setCategoryFilter(normalizeIdFilterFromParams(searchParams.category));
  }, [searchParams.category]);
  const additionalSearchMerge = useMemo(() => ({
    line: toIdFilterPayload(lineFilter),
    category: toIdFilterPayload(categoryFilter)
  }), [lineFilter, categoryFilter]);
  const pageItems = response?.data ?? [];
  const selectionSummary = useMemo(
    () => formatSelectionSummary(pageItems, selectedIds),
    [pageItems, selectedIds]
  );
  const hasSelection = selectedIds.size > 0;
  const handleToggleRow = useCallback((id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else
        next.add(id);
      return next;
    });
  }, []);
  const handleTogglePage = useCallback((ids, checked) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => {
        if (checked) next.add(id);
        else
          next.delete(id);
      });
      return next;
    });
  }, []);
  const handleSearchWithClearSelection = useCallback(
    (params) => {
      setSelectedIds(/* @__PURE__ */ new Set());
      handleSearch(params);
    },
    [handleSearch]
  );
  const handleBulkApply = async (percent) => {
    if (selectedIds.size === 0) return;
    setBulkLoading(true);
    try {
      const body = buildBulkAdjustSalePriceBodyByIds([...selectedIds], percent);
      const res = await postRaw("products/bulk-adjust-sale-price", body);
      toast.success(
        `Ajuste aplicado: ${res.updated} productos actualizados (${res.matched} coincidencias).`
      );
      setBulkModalOpen(false);
      setSelectedIds(/* @__PURE__ */ new Set());
      handleSearch({ ...searchParams });
    } catch (e) {
      toast.error(parseBulkAdjustError(e));
    } finally {
      setBulkLoading(false);
    }
  };
  const lineDropdownOptions = useMemo(
    () => lineOptions.map((o) => ({ value: String(o.value), label: o.label })),
    [lineOptions]
  );
  const categoryDropdownOptions = useMemo(
    () => categoryOptions.map((o) => ({ value: String(o.value), label: o.label })),
    [categoryOptions]
  );
  const extraFilters = /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Línea" }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
        lineNumber: 210,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        MultiSelectDropdown,
        {
          options: lineDropdownOptions,
          selected: lineFilter,
          onChange: setLineFilter,
          placeholder: "Todas"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
          lineNumber: 213,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
      lineNumber: 209,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Categoría" }, void 0, false, {
        fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
        lineNumber: 221,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        MultiSelectDropdown,
        {
          options: categoryDropdownOptions,
          selected: categoryFilter,
          onChange: setCategoryFilter,
          placeholder: "Todas"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
          lineNumber: 224,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
      lineNumber: 220,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
    lineNumber: 208,
    columnNumber: 3
  }, this);
  const additionalHeaderButtons = canBulkAdjustPrice ? /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick: () => setBulkModalOpen(true),
      disabled: !hasSelection,
      className: "inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed sm:w-auto",
      children: [
        "Ajustar Precio",
        hasSelection ? ` (${selectedIds.size})` : ""
      ]
    },
    void 0,
    true,
    {
      fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
      lineNumber: 236,
      columnNumber: 3
    },
    this
  ) : null;
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
    lineNumber: 246,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      BulkAdjustSalePriceModal,
      {
        isOpen: bulkModalOpen,
        loading: bulkLoading,
        selectionSummary,
        selectionCount: selectedIds.size,
        onClose: () => {
          if (!bulkLoading) setBulkModalOpen(false);
        },
        onApply: handleBulkApply
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
        lineNumber: 250,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      GenericListPage,
      {
        config: articulosModuleConfig,
        paginationResponse: response,
        loading,
        isAppending,
        onDelete: deleteItem,
        onSort: handleSort,
        sortBy,
        sortDirection,
        onPageChange: handlePageChange,
        onLoadMore: handleLoadMore,
        onSearch: handleSearchWithClearSelection,
        searchTerm: searchParams.term ?? "",
        persistedSearchParams: searchParams,
        additionalSearchMerge,
        renderExtraSearchFields: extraFilters,
        additionalHeaderButtons,
        enableRowSelection: canBulkAdjustPrice,
        selectedIds,
        onToggleRow: handleToggleRow,
        onTogglePage: handleTogglePage
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
        lineNumber: 260,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/articulos/pages/ArticulosListPage.tsx",
    lineNumber: 249,
    columnNumber: 5
  }, this);
};
_s(ArticulosListPage, "QK7GULlWHbQKUQLEMKhs6Q9YGQs=", false, function() {
  return [usePermissions, useCrud];
});
_c = ArticulosListPage;
var _c;
$RefreshReg$(_c, "ArticulosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/pages/ArticulosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/pages/ArticulosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNExRLG1CQUVRLGNBRlI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNUxSLFNBQVNBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUMxRCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGdDQUFnQztBQUN6QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCQywrQkFBK0I7QUFDL0QsU0FBU0MsZUFBZTtBQUN4QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsdUJBQXVCQyxnQkFBZ0JDLGlCQUFnQztBQUNoRjtBQUFBLEVBQ0lDO0FBQUFBLE9BRUc7QUFFUCxTQUFTQyxxQkFBcUJDLEdBQW9CO0FBQzlDLE1BQUlBLEtBQUssT0FBT0EsTUFBTSxZQUFZLGNBQWNBLEdBQUc7QUFDL0MsVUFBTUMsT0FBUUQsRUFBd0NFO0FBQ3RELFVBQU1DLE9BQU9GLE1BQU1FO0FBQ25CLFFBQUlBLE1BQU1DLFVBQVUsT0FBT0QsS0FBS0MsV0FBVyxVQUFVO0FBQ2pELFlBQU1DLE9BQU9DLE9BQU9DLE9BQU9KLEtBQUtDLE1BQU0sRUFBRUksS0FBSyxFQUFFQyxPQUFPQyxPQUFPO0FBQzdELFVBQUlMLEtBQUtNLE9BQVEsUUFBT04sS0FBS08sS0FBSyxHQUFHO0FBQUEsSUFDekM7QUFDQSxRQUFJLE9BQU9ULE1BQU1VLFlBQVksWUFBWVYsS0FBS1UsUUFBUUMsS0FBSyxFQUFHLFFBQU9YLEtBQUtVLFFBQVFDLEtBQUs7QUFBQSxFQUMzRjtBQUNBLE1BQUlkLGFBQWFlLFNBQVNmLEVBQUVhLFFBQVMsUUFBT2IsRUFBRWE7QUFDOUMsU0FBTztBQUNYO0FBRUEsU0FBU0csdUJBQXVCQyxPQUFtQkMsYUFBa0M7QUFDakYsUUFBTUMsV0FBV0YsTUFBTVIsT0FBTyxDQUFBVyxTQUFRRixZQUFZRyxJQUFJRCxLQUFLRSxFQUFFLENBQUM7QUFDOUQsUUFBTUMsUUFBUUwsWUFBWU07QUFDMUIsTUFBSUQsVUFBVSxFQUFHLFFBQU87QUFFeEIsUUFBTUUsU0FBU04sU0FBU08sSUFBSSxDQUFBTixTQUFRQSxLQUFLTyxPQUFPUCxLQUFLUSxJQUFJLEVBQUVuQixPQUFPQyxPQUFPO0FBQ3pFLE1BQUllLE9BQU9kLFVBQVUsS0FBS2MsT0FBT2QsV0FBV1ksT0FBTztBQUMvQyxXQUFPLEdBQUdBLEtBQUssWUFBWUEsVUFBVSxJQUFJLEtBQUssR0FBRyxnQkFBZ0JBLFVBQVUsSUFBSSxLQUFLLEdBQUcsS0FBS0UsT0FBT2IsS0FBSyxJQUFJLENBQUM7QUFBQSxFQUNqSDtBQUNBLE1BQUlhLE9BQU9kLFNBQVMsS0FBS2MsT0FBT2QsVUFBVSxHQUFHO0FBQ3pDLFdBQU8sR0FBR1ksS0FBSyxZQUFZQSxVQUFVLElBQUksS0FBSyxHQUFHLGdCQUFnQkEsVUFBVSxJQUFJLEtBQUssR0FBRyxxQkFBcUJFLE9BQU9iLEtBQUssSUFBSSxDQUFDO0FBQUEsRUFDakk7QUFDQSxTQUFPLEdBQUdXLEtBQUssWUFBWUEsVUFBVSxJQUFJLEtBQUssR0FBRyxnQkFBZ0JBLFVBQVUsSUFBSSxLQUFLLEdBQUc7QUFDM0Y7QUFFQSxTQUFTTSw0QkFBNEJDLEtBQXdCO0FBQ3pELE1BQUlBLFFBQVFDLFVBQWFELFFBQVEsUUFBUUEsUUFBUSxJQUFJO0FBQ2pELFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBSUUsTUFBTUMsUUFBUUgsR0FBRyxHQUFHO0FBQ3BCLFdBQU9BLElBQ0ZyQixPQUFPLENBQUF5QixNQUFLQSxNQUFNLE1BQU1BLE1BQU0sUUFBUUEsTUFBTUgsTUFBUyxFQUNyREwsSUFBSSxDQUFBUSxNQUFLQyxPQUFPRCxDQUFDLENBQUM7QUFBQSxFQUMzQjtBQUNBLFNBQU8sQ0FBQ0MsT0FBT0wsR0FBRyxDQUFDO0FBQ3ZCO0FBRUEsU0FBU00sa0JBQWtCN0IsUUFBd0M7QUFDL0QsTUFBSUEsT0FBT0ksV0FBVyxHQUFHO0FBQ3JCLFdBQU9vQjtBQUFBQSxFQUNYO0FBQ0EsUUFBTU0sTUFBTTlCLE9BQU9tQixJQUFJWSxNQUFNLEVBQUU3QixPQUFPLENBQUE4QixNQUFLRCxPQUFPRSxTQUFTRCxDQUFDLENBQUM7QUFDN0QsU0FBT0YsSUFBSTFCLFNBQVMsSUFBSTBCLE1BQU1OO0FBQ2xDO0FBRU8sYUFBTVUsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxFQUFFQyxvQkFBb0IsSUFBSXJELGVBQWU7QUFDL0MsUUFBTTtBQUFBLElBQ0ZZO0FBQUFBLElBQ0EwQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNKLElBQUlqRSxRQUFrQk0scUJBQXFCO0FBRTNDLFFBQU00RCxtQkFBbUJoRSxzQkFBc0JJLHNCQUFzQjZELFNBQVM7QUFDOUUsUUFBTUMsYUFBYUYsbUJBQW1CL0Qsd0JBQXdCK0QsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcscUJBQXFCRCxhQUFhZCxvQkFBb0JjLFlBQVksTUFBTSxJQUFJO0FBRWxGLFFBQU0sQ0FBQ0UsWUFBWUMsYUFBYSxJQUFJM0UsU0FBbUIsRUFBRTtBQUN6RCxRQUFNLENBQUM0RSxnQkFBZ0JDLGlCQUFpQixJQUFJN0UsU0FBbUIsRUFBRTtBQUNqRSxRQUFNLENBQUM4RSxhQUFhQyxjQUFjLElBQUkvRSxTQUFzRCxFQUFFO0FBQzlGLFFBQU0sQ0FBQ2dGLGlCQUFpQkMsa0JBQWtCLElBQUlqRixTQUFzRCxFQUFFO0FBRXRHLFFBQU0sQ0FBQ2lDLGFBQWFpRCxjQUFjLElBQUlsRixTQUFzQixvQkFBSW1GLElBQUksQ0FBQztBQUNyRSxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJckYsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3NGLGFBQWFDLGNBQWMsSUFBSXZGLFNBQVMsS0FBSztBQUVwRCxRQUFNd0YsaUJBQWlCM0YsWUFBWSxZQUFZO0FBQzNDLFFBQUk7QUFDQSxZQUFNLENBQUM0RixPQUFPQyxVQUFVLElBQUksTUFBTUMsUUFBUUMsSUFBSSxDQUFDaEYsVUFBVSxHQUFHRCxlQUFlLENBQUMsQ0FBQztBQUM3RW9FLHFCQUFlVSxLQUFLO0FBQ3BCUix5QkFBbUJTLFVBQVU7QUFBQSxJQUNqQyxRQUFRO0FBQ0pYLHFCQUFlLEVBQUU7QUFDakJFLHlCQUFtQixFQUFFO0FBQUEsSUFDekI7QUFBQSxFQUNKLEdBQUcsRUFBRTtBQUVMbkYsWUFBVSxNQUFNO0FBQ1osU0FBSzBGLGVBQWU7QUFBQSxFQUN4QixHQUFHLENBQUNBLGNBQWMsQ0FBQztBQUVuQjFGLFlBQVUsTUFBTTtBQUNaNkUsa0JBQWMvQiw0QkFBNEJ5QixhQUFhd0IsSUFBSSxDQUFDO0FBQUEsRUFDaEUsR0FBRyxDQUFDeEIsYUFBYXdCLElBQUksQ0FBQztBQUV0Qi9GLFlBQVUsTUFBTTtBQUNaK0Usc0JBQWtCakMsNEJBQTRCeUIsYUFBYXlCLFFBQVEsQ0FBQztBQUFBLEVBQ3hFLEdBQUcsQ0FBQ3pCLGFBQWF5QixRQUFRLENBQUM7QUFFMUIsUUFBTUMsd0JBQXdCaEcsUUFBUSxPQUFxQztBQUFBLElBQ3ZFOEYsTUFBTTFDLGtCQUFrQnVCLFVBQVU7QUFBQSxJQUNsQ29CLFVBQVUzQyxrQkFBa0J5QixjQUFjO0FBQUEsRUFDOUMsSUFBSSxDQUFDRixZQUFZRSxjQUFjLENBQUM7QUFFaEMsUUFBTW9CLFlBQVkvRSxVQUFVQyxRQUFRO0FBRXBDLFFBQU0rRSxtQkFBbUJsRztBQUFBQSxJQUNyQixNQUFNZ0MsdUJBQXVCaUUsV0FBVy9ELFdBQVc7QUFBQSxJQUNuRCxDQUFDK0QsV0FBVy9ELFdBQVc7QUFBQSxFQUMzQjtBQUVBLFFBQU1pRSxlQUFlakUsWUFBWU0sT0FBTztBQUV4QyxRQUFNNEQsa0JBQWtCdEcsWUFBWSxDQUFDd0MsT0FBZTtBQUNoRDZDLG1CQUFlLENBQUFrQixTQUFRO0FBQ25CLFlBQU1DLE9BQU8sSUFBSWxCLElBQUlpQixJQUFJO0FBQ3pCLFVBQUlDLEtBQUtqRSxJQUFJQyxFQUFFLEVBQUdnRSxNQUFLQyxPQUFPakUsRUFBRTtBQUFBO0FBQzNCZ0UsYUFBS0UsSUFBSWxFLEVBQUU7QUFDaEIsYUFBT2dFO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBRUwsUUFBTUcsbUJBQW1CM0csWUFBWSxDQUFDdUQsS0FBZXFELFlBQXFCO0FBQ3RFdkIsbUJBQWUsQ0FBQWtCLFNBQVE7QUFDbkIsWUFBTUMsT0FBTyxJQUFJbEIsSUFBSWlCLElBQUk7QUFDekJoRCxVQUFJc0QsUUFBUSxDQUFBckUsT0FBTTtBQUNkLFlBQUlvRSxRQUFTSixNQUFLRSxJQUFJbEUsRUFBRTtBQUFBO0FBQ25CZ0UsZUFBS0MsT0FBT2pFLEVBQUU7QUFBQSxNQUN2QixDQUFDO0FBQ0QsYUFBT2dFO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0wsR0FBRyxFQUFFO0FBRUwsUUFBTU0saUNBQWlDOUc7QUFBQUEsSUFDbkMsQ0FBQytHLFdBQWdDO0FBQzdCMUIscUJBQWUsb0JBQUlDLElBQUksQ0FBQztBQUN4QmYsbUJBQWF3QyxNQUFNO0FBQUEsSUFDdkI7QUFBQSxJQUNBLENBQUN4QyxZQUFZO0FBQUEsRUFDakI7QUFFQSxRQUFNeUMsa0JBQWtCLE9BQU9DLFlBQW9CO0FBQy9DLFFBQUk3RSxZQUFZTSxTQUFTLEVBQUc7QUFDNUJnRCxtQkFBZSxJQUFJO0FBQ25CLFFBQUk7QUFDQSxZQUFNd0IsT0FBT2xHLGtDQUFrQyxDQUFDLEdBQUdvQixXQUFXLEdBQUc2RSxPQUFPO0FBQ3hFLFlBQU1FLE1BQU0sTUFBTXhHLFFBQXFDLG1DQUFtQ3VHLElBQUk7QUFDOUY5RyxZQUFNZ0g7QUFBQUEsUUFDRixvQkFBb0JELElBQUlFLE9BQU8sNEJBQTRCRixJQUFJRyxPQUFPO0FBQUEsTUFDMUU7QUFDQTlCLHVCQUFpQixLQUFLO0FBQ3RCSCxxQkFBZSxvQkFBSUMsSUFBSSxDQUFDO0FBQ3hCZixtQkFBYSxFQUFFLEdBQUdDLGFBQWEsQ0FBQztBQUFBLElBQ3BDLFNBQVN0RCxHQUFHO0FBQ1JkLFlBQU00RCxNQUFNL0MscUJBQXFCQyxDQUFDLENBQUM7QUFBQSxJQUN2QyxVQUFDO0FBQ0d3RSxxQkFBZSxLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNKO0FBRUEsUUFBTTZCLHNCQUFzQnJIO0FBQUFBLElBQ3hCLE1BQU0rRSxZQUFZckMsSUFBSSxDQUFBNEUsT0FBTSxFQUFFQyxPQUFPcEUsT0FBT21FLEVBQUVDLEtBQUssR0FBR0MsT0FBT0YsRUFBRUUsTUFBTSxFQUFFO0FBQUEsSUFDdkUsQ0FBQ3pDLFdBQVc7QUFBQSxFQUNoQjtBQUNBLFFBQU0wQywwQkFBMEJ6SDtBQUFBQSxJQUM1QixNQUFNaUYsZ0JBQWdCdkMsSUFBSSxDQUFBNEUsT0FBTSxFQUFFQyxPQUFPcEUsT0FBT21FLEVBQUVDLEtBQUssR0FBR0MsT0FBT0YsRUFBRUUsTUFBTSxFQUFFO0FBQUEsSUFDM0UsQ0FBQ3ZDLGVBQWU7QUFBQSxFQUNwQjtBQUVBLFFBQU15QyxlQUNGLG1DQUNJO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFdBQU0sV0FBVSwyQ0FBeUMscUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFNBQVNMO0FBQUFBLFVBQ1QsVUFBVTFDO0FBQUFBLFVBQ1YsVUFBVUM7QUFBQUEsVUFDVixhQUFZO0FBQUE7QUFBQSxRQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJdUI7QUFBQSxTQVIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxXQUFNLFdBQVUsMkNBQXlDLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxTQUFTNkM7QUFBQUEsVUFDVCxVQUFVNUM7QUFBQUEsVUFDVixVQUFVQztBQUFBQSxVQUNWLGFBQVk7QUFBQTtBQUFBLFFBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUl1QjtBQUFBLFNBUjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFHSixRQUFNNkMsMEJBQ0ZqRCxxQkFDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csTUFBSztBQUFBLE1BQ0wsU0FBUyxNQUFNWSxpQkFBaUIsSUFBSTtBQUFBLE1BQ3BDLFVBQVUsQ0FBQ2E7QUFBQUEsTUFDWCxXQUFVO0FBQUEsTUFBK1I7QUFBQTtBQUFBLFFBRTFSQSxlQUFlLEtBQUtqRSxZQUFZTSxJQUFJLE1BQU07QUFBQTtBQUFBO0FBQUEsSUFON0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsSUFDQTtBQUVSLE1BQUlzQixNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFdkQsU0FDSSxtQ0FDSTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRdUI7QUFBQUEsUUFDUixTQUFTRTtBQUFBQSxRQUNUO0FBQUEsUUFDQSxnQkFBZ0JyRCxZQUFZTTtBQUFBQSxRQUM1QixTQUFTLE1BQU07QUFDWCxjQUFJLENBQUMrQyxZQUFhRCxrQkFBaUIsS0FBSztBQUFBLFFBQzVDO0FBQUEsUUFDQSxTQUFTd0I7QUFBQUE7QUFBQUEsTUFSYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRNkI7QUFBQSxJQUU3QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUW5HO0FBQUFBLFFBQ1Isb0JBQW9CTztBQUFBQSxRQUNwQjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVU2QztBQUFBQSxRQUNWLFFBQVFDO0FBQUFBLFFBQ1I7QUFBQSxRQUNBO0FBQUEsUUFDQSxjQUFjRztBQUFBQSxRQUNkLFlBQVlDO0FBQUFBLFFBQ1osVUFBVXdDO0FBQUFBLFFBQ1YsWUFBWXRDLGFBQWFzRCxRQUFRO0FBQUEsUUFDakMsdUJBQXVCdEQ7QUFBQUEsUUFDdkI7QUFBQSxRQUNBLHlCQUF5Qm9EO0FBQUFBLFFBQ3pCO0FBQUEsUUFDQSxvQkFBb0JoRDtBQUFBQSxRQUNwQjtBQUFBLFFBQ0EsYUFBYTBCO0FBQUFBLFFBQ2IsY0FBY0s7QUFBQUE7QUFBQUEsTUFwQmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9CbUM7QUFBQSxPQS9CdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVSO0FBQUUvQyxHQXhNV0QsbUJBQWlCO0FBQUEsVUFDTW5ELGdCQWM1QkQsT0FBTztBQUFBO0FBQUF3SCxLQWZGcEU7QUFBaUIsSUFBQW9FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInRvYXN0IiwiQnVsa0FkanVzdFNhbGVQcmljZU1vZGFsIiwiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsInVzZVBlcm1pc3Npb25zIiwiZ2V0UmVxdWlyZWRQZXJtaXNzaW9uIiwiZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24iLCJwb3N0UmF3IiwiTXVsdGlTZWxlY3REcm9wZG93biIsImFydGljdWxvc01vZHVsZUNvbmZpZyIsImxvYWRDYXRlZ29yaWVzIiwibG9hZExpbmVzIiwiYnVpbGRCdWxrQWRqdXN0U2FsZVByaWNlQm9keUJ5SWRzIiwicGFyc2VCdWxrQWRqdXN0RXJyb3IiLCJlIiwicmVzcCIsInJlc3BvbnNlIiwiZGF0YSIsImVycm9ycyIsIm1zZ3MiLCJPYmplY3QiLCJ2YWx1ZXMiLCJmbGF0IiwiZmlsdGVyIiwiQm9vbGVhbiIsImxlbmd0aCIsImpvaW4iLCJtZXNzYWdlIiwidHJpbSIsIkVycm9yIiwiZm9ybWF0U2VsZWN0aW9uU3VtbWFyeSIsIml0ZW1zIiwic2VsZWN0ZWRJZHMiLCJzZWxlY3RlZCIsIml0ZW0iLCJoYXMiLCJpZCIsImNvdW50Iiwic2l6ZSIsImxhYmVscyIsIm1hcCIsInNrdSIsIm5hbWUiLCJub3JtYWxpemVJZEZpbHRlckZyb21QYXJhbXMiLCJyYXciLCJ1bmRlZmluZWQiLCJBcnJheSIsImlzQXJyYXkiLCJ2IiwiU3RyaW5nIiwidG9JZEZpbHRlclBheWxvYWQiLCJpZHMiLCJOdW1iZXIiLCJuIiwiaXNGaW5pdGUiLCJBcnRpY3Vsb3NMaXN0UGFnZSIsIl9zIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJjYW5CdWxrQWRqdXN0UHJpY2UiLCJsaW5lRmlsdGVyIiwic2V0TGluZUZpbHRlciIsImNhdGVnb3J5RmlsdGVyIiwic2V0Q2F0ZWdvcnlGaWx0ZXIiLCJsaW5lT3B0aW9ucyIsInNldExpbmVPcHRpb25zIiwiY2F0ZWdvcnlPcHRpb25zIiwic2V0Q2F0ZWdvcnlPcHRpb25zIiwic2V0U2VsZWN0ZWRJZHMiLCJTZXQiLCJidWxrTW9kYWxPcGVuIiwic2V0QnVsa01vZGFsT3BlbiIsImJ1bGtMb2FkaW5nIiwic2V0QnVsa0xvYWRpbmciLCJyZWZyZXNoT3B0aW9ucyIsImxpbmVzIiwiY2F0ZWdvcmllcyIsIlByb21pc2UiLCJhbGwiLCJsaW5lIiwiY2F0ZWdvcnkiLCJhZGRpdGlvbmFsU2VhcmNoTWVyZ2UiLCJwYWdlSXRlbXMiLCJzZWxlY3Rpb25TdW1tYXJ5IiwiaGFzU2VsZWN0aW9uIiwiaGFuZGxlVG9nZ2xlUm93IiwicHJldiIsIm5leHQiLCJkZWxldGUiLCJhZGQiLCJoYW5kbGVUb2dnbGVQYWdlIiwiY2hlY2tlZCIsImZvckVhY2giLCJoYW5kbGVTZWFyY2hXaXRoQ2xlYXJTZWxlY3Rpb24iLCJwYXJhbXMiLCJoYW5kbGVCdWxrQXBwbHkiLCJwZXJjZW50IiwiYm9keSIsInJlcyIsInN1Y2Nlc3MiLCJ1cGRhdGVkIiwibWF0Y2hlZCIsImxpbmVEcm9wZG93bk9wdGlvbnMiLCJvIiwidmFsdWUiLCJsYWJlbCIsImNhdGVnb3J5RHJvcGRvd25PcHRpb25zIiwiZXh0cmFGaWx0ZXJzIiwiYWRkaXRpb25hbEhlYWRlckJ1dHRvbnMiLCJ0ZXJtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXJ0aWN1bG9zTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBCdWxrQWRqdXN0U2FsZVByaWNlTW9kYWwgfSBmcm9tICcuLi9jb21wb25lbnRzL0J1bGtBZGp1c3RTYWxlUHJpY2VNb2RhbCc7XG5pbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VQZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXRSZXF1aXJlZFBlcm1pc3Npb24sIGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgcG9zdFJhdyB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgTXVsdGlTZWxlY3REcm9wZG93biB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL011bHRpU2VsZWN0RHJvcGRvd24nO1xuaW1wb3J0IHsgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCBsb2FkQ2F0ZWdvcmllcywgbG9hZExpbmVzLCB0eXBlIEFydGljdWxvIH0gZnJvbSAnLi4vYXJ0aWN1bG9zLmNvbmZpZy50c3gnO1xuaW1wb3J0IHtcbiAgICBidWlsZEJ1bGtBZGp1c3RTYWxlUHJpY2VCb2R5QnlJZHMsXG4gICAgdHlwZSBCdWxrQWRqdXN0U2FsZVByaWNlUmVzcG9uc2UsXG59IGZyb20gJy4uL3V0aWxzL2J1bGtBZGp1c3RTYWxlUHJpY2VQYXlsb2FkJztcblxuZnVuY3Rpb24gcGFyc2VCdWxrQWRqdXN0RXJyb3IoZTogdW5rbm93bik6IHN0cmluZyB7XG4gICAgaWYgKGUgJiYgdHlwZW9mIGUgPT09ICdvYmplY3QnICYmICdyZXNwb25zZScgaW4gZSkge1xuICAgICAgICBjb25zdCByZXNwID0gKGUgYXMgeyByZXNwb25zZT86IHsgZGF0YT86IHVua25vd24gfSB9KS5yZXNwb25zZTtcbiAgICAgICAgY29uc3QgZGF0YSA9IHJlc3A/LmRhdGEgYXMgeyBtZXNzYWdlPzogc3RyaW5nOyBlcnJvcnM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gfSB8IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKGRhdGE/LmVycm9ycyAmJiB0eXBlb2YgZGF0YS5lcnJvcnMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBjb25zdCBtc2dzID0gT2JqZWN0LnZhbHVlcyhkYXRhLmVycm9ycykuZmxhdCgpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgICAgIGlmIChtc2dzLmxlbmd0aCkgcmV0dXJuIG1zZ3Muam9pbignICcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgZGF0YT8ubWVzc2FnZSA9PT0gJ3N0cmluZycgJiYgZGF0YS5tZXNzYWdlLnRyaW0oKSkgcmV0dXJuIGRhdGEubWVzc2FnZS50cmltKCk7XG4gICAgfVxuICAgIGlmIChlIGluc3RhbmNlb2YgRXJyb3IgJiYgZS5tZXNzYWdlKSByZXR1cm4gZS5tZXNzYWdlO1xuICAgIHJldHVybiAnTm8gc2UgcHVkbyBhcGxpY2FyIGVsIGFqdXN0ZSBkZSBwcmVjaW9zLic7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFNlbGVjdGlvblN1bW1hcnkoaXRlbXM6IEFydGljdWxvW10sIHNlbGVjdGVkSWRzOiBTZXQ8bnVtYmVyPik6IHN0cmluZyB7XG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBpdGVtcy5maWx0ZXIoaXRlbSA9PiBzZWxlY3RlZElkcy5oYXMoaXRlbS5pZCkpO1xuICAgIGNvbnN0IGNvdW50ID0gc2VsZWN0ZWRJZHMuc2l6ZTtcbiAgICBpZiAoY291bnQgPT09IDApIHJldHVybiAnJztcblxuICAgIGNvbnN0IGxhYmVscyA9IHNlbGVjdGVkLm1hcChpdGVtID0+IGl0ZW0uc2t1IHx8IGl0ZW0ubmFtZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgIGlmIChsYWJlbHMubGVuZ3RoIDw9IDUgJiYgbGFiZWxzLmxlbmd0aCA9PT0gY291bnQpIHtcbiAgICAgICAgcmV0dXJuIGAke2NvdW50fSBwcm9kdWN0byR7Y291bnQgPT09IDEgPyAnJyA6ICdzJ30gc2VsZWNjaW9uYWRvJHtjb3VudCA9PT0gMSA/ICcnIDogJ3MnfTogJHtsYWJlbHMuam9pbignLCAnKX1gO1xuICAgIH1cbiAgICBpZiAobGFiZWxzLmxlbmd0aCA+IDAgJiYgbGFiZWxzLmxlbmd0aCA8PSA1KSB7XG4gICAgICAgIHJldHVybiBgJHtjb3VudH0gcHJvZHVjdG8ke2NvdW50ID09PSAxID8gJycgOiAncyd9IHNlbGVjY2lvbmFkbyR7Y291bnQgPT09IDEgPyAnJyA6ICdzJ30gKHDDoWdpbmEgdmlzaWJsZTogJHtsYWJlbHMuam9pbignLCAnKX0pYDtcbiAgICB9XG4gICAgcmV0dXJuIGAke2NvdW50fSBwcm9kdWN0byR7Y291bnQgPT09IDEgPyAnJyA6ICdzJ30gc2VsZWNjaW9uYWRvJHtjb3VudCA9PT0gMSA/ICcnIDogJ3MnfWA7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUlkRmlsdGVyRnJvbVBhcmFtcyhyYXc6IHVua25vd24pOiBzdHJpbmdbXSB7XG4gICAgaWYgKHJhdyA9PT0gdW5kZWZpbmVkIHx8IHJhdyA9PT0gbnVsbCB8fCByYXcgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocmF3KSkge1xuICAgICAgICByZXR1cm4gcmF3XG4gICAgICAgICAgICAuZmlsdGVyKHYgPT4gdiAhPT0gJycgJiYgdiAhPT0gbnVsbCAmJiB2ICE9PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAubWFwKHYgPT4gU3RyaW5nKHYpKTtcbiAgICB9XG4gICAgcmV0dXJuIFtTdHJpbmcocmF3KV07XG59XG5cbmZ1bmN0aW9uIHRvSWRGaWx0ZXJQYXlsb2FkKHZhbHVlczogc3RyaW5nW10pOiBudW1iZXJbXSB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKHZhbHVlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgaWRzID0gdmFsdWVzLm1hcChOdW1iZXIpLmZpbHRlcihuID0+IE51bWJlci5pc0Zpbml0ZShuKSk7XG4gICAgcmV0dXJuIGlkcy5sZW5ndGggPiAwID8gaWRzIDogdW5kZWZpbmVkO1xufVxuXG5leHBvcnQgY29uc3QgQXJ0aWN1bG9zTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGlzQXBwZW5kaW5nLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgZGVsZXRlSXRlbSxcbiAgICAgICAgaGFuZGxlU29ydCxcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVMb2FkTW9yZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8QXJ0aWN1bG8+KGFydGljdWxvc01vZHVsZUNvbmZpZyk7XG5cbiAgICBjb25zdCBtb2R1bGVQZXJtaXNzaW9uID0gZ2V0UmVxdWlyZWRQZXJtaXNzaW9uKGFydGljdWxvc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkJ1bGtBZGp1c3RQcmljZSA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuXG4gICAgY29uc3QgW2xpbmVGaWx0ZXIsIHNldExpbmVGaWx0ZXJdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgICBjb25zdCBbY2F0ZWdvcnlGaWx0ZXIsIHNldENhdGVnb3J5RmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gICAgY29uc3QgW2xpbmVPcHRpb25zLCBzZXRMaW5lT3B0aW9uc10gPSB1c2VTdGF0ZTx7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfVtdPihbXSk7XG4gICAgY29uc3QgW2NhdGVnb3J5T3B0aW9ucywgc2V0Q2F0ZWdvcnlPcHRpb25zXSA9IHVzZVN0YXRlPHsgdmFsdWU6IHN0cmluZyB8IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9W10+KFtdKTtcblxuICAgIGNvbnN0IFtzZWxlY3RlZElkcywgc2V0U2VsZWN0ZWRJZHNdID0gdXNlU3RhdGU8U2V0PG51bWJlcj4+KG5ldyBTZXQoKSk7XG4gICAgY29uc3QgW2J1bGtNb2RhbE9wZW4sIHNldEJ1bGtNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtidWxrTG9hZGluZywgc2V0QnVsa0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgcmVmcmVzaE9wdGlvbnMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBbbGluZXMsIGNhdGVnb3JpZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRMaW5lcygpLCBsb2FkQ2F0ZWdvcmllcygpXSk7XG4gICAgICAgICAgICBzZXRMaW5lT3B0aW9ucyhsaW5lcyk7XG4gICAgICAgICAgICBzZXRDYXRlZ29yeU9wdGlvbnMoY2F0ZWdvcmllcyk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgc2V0TGluZU9wdGlvbnMoW10pO1xuICAgICAgICAgICAgc2V0Q2F0ZWdvcnlPcHRpb25zKFtdKTtcbiAgICAgICAgfVxuICAgIH0sIFtdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHZvaWQgcmVmcmVzaE9wdGlvbnMoKTtcbiAgICB9LCBbcmVmcmVzaE9wdGlvbnNdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldExpbmVGaWx0ZXIobm9ybWFsaXplSWRGaWx0ZXJGcm9tUGFyYW1zKHNlYXJjaFBhcmFtcy5saW5lKSk7XG4gICAgfSwgW3NlYXJjaFBhcmFtcy5saW5lXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRDYXRlZ29yeUZpbHRlcihub3JtYWxpemVJZEZpbHRlckZyb21QYXJhbXMoc2VhcmNoUGFyYW1zLmNhdGVnb3J5KSk7XG4gICAgfSwgW3NlYXJjaFBhcmFtcy5jYXRlZ29yeV0pO1xuXG4gICAgY29uc3QgYWRkaXRpb25hbFNlYXJjaE1lcmdlID0gdXNlTWVtbygoKTogUGFydGlhbDx0eXBlb2Ygc2VhcmNoUGFyYW1zPiA9PiAoe1xuICAgICAgICBsaW5lOiB0b0lkRmlsdGVyUGF5bG9hZChsaW5lRmlsdGVyKSxcbiAgICAgICAgY2F0ZWdvcnk6IHRvSWRGaWx0ZXJQYXlsb2FkKGNhdGVnb3J5RmlsdGVyKSxcbiAgICB9KSwgW2xpbmVGaWx0ZXIsIGNhdGVnb3J5RmlsdGVyXSk7XG5cbiAgICBjb25zdCBwYWdlSXRlbXMgPSByZXNwb25zZT8uZGF0YSA/PyBbXTtcblxuICAgIGNvbnN0IHNlbGVjdGlvblN1bW1hcnkgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBmb3JtYXRTZWxlY3Rpb25TdW1tYXJ5KHBhZ2VJdGVtcywgc2VsZWN0ZWRJZHMpLFxuICAgICAgICBbcGFnZUl0ZW1zLCBzZWxlY3RlZElkc11cbiAgICApO1xuXG4gICAgY29uc3QgaGFzU2VsZWN0aW9uID0gc2VsZWN0ZWRJZHMuc2l6ZSA+IDA7XG5cbiAgICBjb25zdCBoYW5kbGVUb2dnbGVSb3cgPSB1c2VDYWxsYmFjaygoaWQ6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRTZWxlY3RlZElkcyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXcgU2V0KHByZXYpO1xuICAgICAgICAgICAgaWYgKG5leHQuaGFzKGlkKSkgbmV4dC5kZWxldGUoaWQpO1xuICAgICAgICAgICAgZWxzZSBuZXh0LmFkZChpZCk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgaGFuZGxlVG9nZ2xlUGFnZSA9IHVzZUNhbGxiYWNrKChpZHM6IG51bWJlcltdLCBjaGVja2VkOiBib29sZWFuKSA9PiB7XG4gICAgICAgIHNldFNlbGVjdGVkSWRzKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBTZXQocHJldik7XG4gICAgICAgICAgICBpZHMuZm9yRWFjaChpZCA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGNoZWNrZWQpIG5leHQuYWRkKGlkKTtcbiAgICAgICAgICAgICAgICBlbHNlIG5leHQuZGVsZXRlKGlkKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgIH0pO1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IGhhbmRsZVNlYXJjaFdpdGhDbGVhclNlbGVjdGlvbiA9IHVzZUNhbGxiYWNrKFxuICAgICAgICAocGFyYW1zOiB0eXBlb2Ygc2VhcmNoUGFyYW1zKSA9PiB7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgICAgICAgICAgaGFuZGxlU2VhcmNoKHBhcmFtcyk7XG4gICAgICAgIH0sXG4gICAgICAgIFtoYW5kbGVTZWFyY2hdXG4gICAgKTtcblxuICAgIGNvbnN0IGhhbmRsZUJ1bGtBcHBseSA9IGFzeW5jIChwZXJjZW50OiBudW1iZXIpID0+IHtcbiAgICAgICAgaWYgKHNlbGVjdGVkSWRzLnNpemUgPT09IDApIHJldHVybjtcbiAgICAgICAgc2V0QnVsa0xvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBib2R5ID0gYnVpbGRCdWxrQWRqdXN0U2FsZVByaWNlQm9keUJ5SWRzKFsuLi5zZWxlY3RlZElkc10sIHBlcmNlbnQpO1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcG9zdFJhdzxCdWxrQWRqdXN0U2FsZVByaWNlUmVzcG9uc2U+KCdwcm9kdWN0cy9idWxrLWFkanVzdC1zYWxlLXByaWNlJywgYm9keSk7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFxuICAgICAgICAgICAgICAgIGBBanVzdGUgYXBsaWNhZG86ICR7cmVzLnVwZGF0ZWR9IHByb2R1Y3RvcyBhY3R1YWxpemFkb3MgKCR7cmVzLm1hdGNoZWR9IGNvaW5jaWRlbmNpYXMpLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBzZXRCdWxrTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gICAgICAgICAgICBoYW5kbGVTZWFyY2goeyAuLi5zZWFyY2hQYXJhbXMgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKHBhcnNlQnVsa0FkanVzdEVycm9yKGUpKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldEJ1bGtMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBsaW5lRHJvcGRvd25PcHRpb25zID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gbGluZU9wdGlvbnMubWFwKG8gPT4gKHsgdmFsdWU6IFN0cmluZyhvLnZhbHVlKSwgbGFiZWw6IG8ubGFiZWwgfSkpLFxuICAgICAgICBbbGluZU9wdGlvbnNdXG4gICAgKTtcbiAgICBjb25zdCBjYXRlZ29yeURyb3Bkb3duT3B0aW9ucyA9IHVzZU1lbW8oXG4gICAgICAgICgpID0+IGNhdGVnb3J5T3B0aW9ucy5tYXAobyA9PiAoeyB2YWx1ZTogU3RyaW5nKG8udmFsdWUpLCBsYWJlbDogby5sYWJlbCB9KSksXG4gICAgICAgIFtjYXRlZ29yeU9wdGlvbnNdXG4gICAgKTtcblxuICAgIGNvbnN0IGV4dHJhRmlsdGVycyA9IChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICBMw61uZWFcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxNdWx0aVNlbGVjdERyb3Bkb3duXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2xpbmVEcm9wZG93bk9wdGlvbnN9XG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkPXtsaW5lRmlsdGVyfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0TGluZUZpbHRlcn1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUb2Rhc1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIENhdGVnb3LDrWFcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxNdWx0aVNlbGVjdERyb3Bkb3duXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2NhdGVnb3J5RHJvcGRvd25PcHRpb25zfVxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZD17Y2F0ZWdvcnlGaWx0ZXJ9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRDYXRlZ29yeUZpbHRlcn1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUb2Rhc1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICApO1xuXG4gICAgY29uc3QgYWRkaXRpb25hbEhlYWRlckJ1dHRvbnMgPVxuICAgICAgICBjYW5CdWxrQWRqdXN0UHJpY2UgPyAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnVsa01vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWhhc1NlbGVjdGlvbn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBzbTp3LWF1dG9cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEFqdXN0YXIgUHJlY2lve2hhc1NlbGVjdGlvbiA/IGAgKCR7c2VsZWN0ZWRJZHMuc2l6ZX0pYCA6ICcnfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkgOiBudWxsO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxCdWxrQWRqdXN0U2FsZVByaWNlTW9kYWxcbiAgICAgICAgICAgICAgICBpc09wZW49e2J1bGtNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgbG9hZGluZz17YnVsa0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgc2VsZWN0aW9uU3VtbWFyeT17c2VsZWN0aW9uU3VtbWFyeX1cbiAgICAgICAgICAgICAgICBzZWxlY3Rpb25Db3VudD17c2VsZWN0ZWRJZHMuc2l6ZX1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghYnVsa0xvYWRpbmcpIHNldEJ1bGtNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgb25BcHBseT17aGFuZGxlQnVsa0FwcGx5fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8QXJ0aWN1bG8+XG4gICAgICAgICAgICAgICAgY29uZmlnPXthcnRpY3Vsb3NNb2R1bGVDb25maWd9XG4gICAgICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaFdpdGhDbGVhclNlbGVjdGlvbn1cbiAgICAgICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgICAgICAgICBwZXJzaXN0ZWRTZWFyY2hQYXJhbXM9e3NlYXJjaFBhcmFtc31cbiAgICAgICAgICAgICAgICBhZGRpdGlvbmFsU2VhcmNoTWVyZ2U9e2FkZGl0aW9uYWxTZWFyY2hNZXJnZX1cbiAgICAgICAgICAgICAgICByZW5kZXJFeHRyYVNlYXJjaEZpZWxkcz17ZXh0cmFGaWx0ZXJzfVxuICAgICAgICAgICAgICAgIGFkZGl0aW9uYWxIZWFkZXJCdXR0b25zPXthZGRpdGlvbmFsSGVhZGVyQnV0dG9uc31cbiAgICAgICAgICAgICAgICBlbmFibGVSb3dTZWxlY3Rpb249e2NhbkJ1bGtBZGp1c3RQcmljZX1cbiAgICAgICAgICAgICAgICBzZWxlY3RlZElkcz17c2VsZWN0ZWRJZHN9XG4gICAgICAgICAgICAgICAgb25Ub2dnbGVSb3c9e2hhbmRsZVRvZ2dsZVJvd31cbiAgICAgICAgICAgICAgICBvblRvZ2dsZVBhZ2U9e2hhbmRsZVRvZ2dsZVBhZ2V9XG4gICAgICAgICAgICAvPlxuICAgICAgICA8Lz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYXJ0aWN1bG9zL3BhZ2VzL0FydGljdWxvc0xpc3RQYWdlLnRzeCJ9