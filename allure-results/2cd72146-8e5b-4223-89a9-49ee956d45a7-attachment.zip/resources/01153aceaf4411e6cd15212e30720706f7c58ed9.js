import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cajas/pages/CajasCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cajas/pages/CajasCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { cajasModuleConfig } from "/src/features/cajas/cajas.config.tsx";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
const initialCajaValues = {
  date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  // Fecha de hoy por defecto
  internal_number: 0,
  client_id: null,
  vendor_id: null,
  sign: "E",
  // Entrada por defecto
  amount: 0,
  value_type: "E",
  // Efectivo por defecto
  receipt_number: "",
  check_number: "",
  observations_1: "",
  is_annulled: false
};
export const CajasCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(cajasModuleConfig);
  const handleSave = async (data) => {
    const total = Number(data.amount);
    if (!Number.isFinite(total) || total <= 0) {
      toast.error("El importe debe ser mayor que 0.");
      return;
    }
    const dataToSave = { ...data };
    if (dataToSave.value_type === "H") {
      dataToSave.check_amount = dataToSave.amount;
    } else {
      dataToSave.check_amount = 0;
    }
    if (data.sign === "E" && data.name) {
      dataToSave.client_name = data.name;
    } else if (data.sign === "S" && data.name) {
      dataToSave.vendor_name = data.name;
    }
    delete dataToSave.name;
    delete dataToSave.code;
    const newItem = await saveItem(dataToSave);
    if (newItem) {
      toast.info(`Movimiento creado con éxito!`);
      navigate("/cajas");
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: cajasModuleConfig,
      initialData: initialCajaValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/cajas/pages/CajasCreatePage.tsx",
      lineNumber: 81,
      columnNumber: 5
    },
    this
  );
};
_s(CajasCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = CajasCreatePage;
var _c;
$RefreshReg$(_c, "CajasCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cajas/pages/CajasCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cajas/pages/CajasCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVEUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx5QkFBb0M7QUFDN0MsU0FBU0MsYUFBYTtBQUd0QixNQUFNQyxvQkFBbUM7QUFBQSxFQUNyQ0MsT0FBTSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQTtBQUFBLEVBQzNDQyxpQkFBaUI7QUFBQSxFQUNqQkMsV0FBVztBQUFBLEVBQ1hDLFdBQVc7QUFBQSxFQUNYQyxNQUFNO0FBQUE7QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsWUFBWTtBQUFBO0FBQUEsRUFDWkMsZ0JBQWdCO0FBQUEsRUFDaEJDLGNBQWM7QUFBQSxFQUNkQyxnQkFBZ0I7QUFBQSxFQUNoQkMsYUFBYTtBQUNqQjtBQUVPLGFBQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2pDLFFBQU1DLFdBQVd0QixZQUFZO0FBQzdCLFFBQU0sRUFBRXVCLFNBQVMsSUFBSXJCLFlBQWtCQyxpQkFBaUI7QUFFeEQsUUFBTXFCLGFBQWEsT0FBT0MsU0FBZTtBQUNyQyxVQUFNQyxRQUFRQyxPQUFPRixLQUFLWCxNQUFNO0FBQ2hDLFFBQUksQ0FBQ2EsT0FBT0MsU0FBU0YsS0FBSyxLQUFLQSxTQUFTLEdBQUc7QUFDdkN0QixZQUFNeUIsTUFBTSxrQ0FBa0M7QUFDOUM7QUFBQSxJQUNKO0FBR0EsVUFBTUMsYUFBbUIsRUFBRSxHQUFHTCxLQUFLO0FBQ25DLFFBQUlLLFdBQVdmLGVBQWUsS0FBSztBQUMvQmUsaUJBQVdDLGVBQWVELFdBQVdoQjtBQUFBQSxJQUN6QyxPQUFPO0FBQ0hnQixpQkFBV0MsZUFBZTtBQUFBLElBQzlCO0FBRUEsUUFBSU4sS0FBS1osU0FBUyxPQUFPWSxLQUFLTyxNQUFNO0FBRWhDRixpQkFBV0csY0FBY1IsS0FBS087QUFBQUEsSUFDbEMsV0FBV1AsS0FBS1osU0FBUyxPQUFPWSxLQUFLTyxNQUFNO0FBRXZDRixpQkFBV0ksY0FBY1QsS0FBS087QUFBQUEsSUFDbEM7QUFHQSxXQUFRRixXQUFtQkU7QUFDM0IsV0FBUUYsV0FBbUJLO0FBRTNCLFVBQU1DLFVBQVUsTUFBTWIsU0FBU08sVUFBVTtBQUN6QyxRQUFJTSxTQUFTO0FBQ1RoQyxZQUFNaUMsS0FBSyw4QkFBOEI7QUFDekNmLGVBQVMsUUFBUTtBQUFBLElBQ3JCO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFuQjtBQUFBQSxNQUNSLGFBQWFFO0FBQUFBLE1BQ2IsUUFBUW1CO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJaUI7QUFHekI7QUFBRUgsR0E5Q1dELGlCQUFlO0FBQUEsVUFDUHBCLGFBQ0lFLFdBQVc7QUFBQTtBQUFBb0MsS0FGdkJsQjtBQUFlLElBQUFrQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJ1c2VDcnVkSXRlbSIsImNhamFzTW9kdWxlQ29uZmlnIiwidG9hc3QiLCJpbml0aWFsQ2FqYVZhbHVlcyIsImRhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImludGVybmFsX251bWJlciIsImNsaWVudF9pZCIsInZlbmRvcl9pZCIsInNpZ24iLCJhbW91bnQiLCJ2YWx1ZV90eXBlIiwicmVjZWlwdF9udW1iZXIiLCJjaGVja19udW1iZXIiLCJvYnNlcnZhdGlvbnNfMSIsImlzX2FubnVsbGVkIiwiQ2FqYXNDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJ0b3RhbCIsIk51bWJlciIsImlzRmluaXRlIiwiZXJyb3IiLCJkYXRhVG9TYXZlIiwiY2hlY2tfYW1vdW50IiwibmFtZSIsImNsaWVudF9uYW1lIiwidmVuZG9yX25hbWUiLCJjb2RlIiwibmV3SXRlbSIsImluZm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYWphc0NyZWF0ZVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9jYWphcy9wYWdlcy9DYWphc0NyZWF0ZVBhZ2UudHN4XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgY2FqYXNNb2R1bGVDb25maWcsIHR5cGUgQ2FqYSB9IGZyb20gJy4uL2NhamFzLmNvbmZpZyc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcblxuLy8gVmFsb3JlcyBpbmljaWFsZXMgcGFyYSB1biBudWV2byBtb3ZpbWllbnRvIGRlIGNhamFcbmNvbnN0IGluaXRpYWxDYWphVmFsdWVzOiBQYXJ0aWFsPENhamE+ID0ge1xuICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLCAvLyBGZWNoYSBkZSBob3kgcG9yIGRlZmVjdG9cbiAgICBpbnRlcm5hbF9udW1iZXI6IDAsXG4gICAgY2xpZW50X2lkOiBudWxsLFxuICAgIHZlbmRvcl9pZDogbnVsbCxcbiAgICBzaWduOiAnRScsIC8vIEVudHJhZGEgcG9yIGRlZmVjdG9cbiAgICBhbW91bnQ6IDAsXG4gICAgdmFsdWVfdHlwZTogJ0UnLCAvLyBFZmVjdGl2byBwb3IgZGVmZWN0b1xuICAgIHJlY2VpcHRfbnVtYmVyOiAnJyxcbiAgICBjaGVja19udW1iZXI6ICcnLFxuICAgIG9ic2VydmF0aW9uc18xOiAnJyxcbiAgICBpc19hbm51bGxlZDogZmFsc2UsXG59O1xuXG5leHBvcnQgY29uc3QgQ2FqYXNDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxDYWphPihjYWphc01vZHVsZUNvbmZpZyk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IENhamEpID0+IHtcbiAgICAgICAgY29uc3QgdG90YWwgPSBOdW1iZXIoZGF0YS5hbW91bnQpO1xuICAgICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh0b3RhbCkgfHwgdG90YWwgPD0gMCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIGltcG9ydGUgZGViZSBzZXIgbWF5b3IgcXVlIDAuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyDinIUgTWFwZWFyICduYW1lJyBhICdjbGllbnRfbmFtZScgbyAndmVuZG9yX25hbWUnIHNlZ8O6biBlbCBzaWduXG4gICAgICAgIGNvbnN0IGRhdGFUb1NhdmU6IENhamEgPSB7IC4uLmRhdGEgfTtcbiAgICAgICAgaWYgKGRhdGFUb1NhdmUudmFsdWVfdHlwZSA9PT0gJ0gnKSB7XG4gICAgICAgICAgICBkYXRhVG9TYXZlLmNoZWNrX2Ftb3VudCA9IGRhdGFUb1NhdmUuYW1vdW50O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZGF0YVRvU2F2ZS5jaGVja19hbW91bnQgPSAwO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRhdGEuc2lnbiA9PT0gJ0UnICYmIGRhdGEubmFtZSkge1xuICAgICAgICAgICAgLy8gU2kgZXMgRW50cmFkYSB5IGhheSB1biBuYW1lLCBtYXBlYXIgYSBjbGllbnRfbmFtZVxuICAgICAgICAgICAgZGF0YVRvU2F2ZS5jbGllbnRfbmFtZSA9IGRhdGEubmFtZTtcbiAgICAgICAgfSBlbHNlIGlmIChkYXRhLnNpZ24gPT09ICdTJyAmJiBkYXRhLm5hbWUpIHtcbiAgICAgICAgICAgIC8vIFNpIGVzIFNhbGlkYSB5IGhheSB1biBuYW1lLCBtYXBlYXIgYSB2ZW5kb3JfbmFtZVxuICAgICAgICAgICAgZGF0YVRvU2F2ZS52ZW5kb3JfbmFtZSA9IGRhdGEubmFtZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIExpbXBpYXIgZWwgY2FtcG8gdGVtcG9yYWwgJ25hbWUnIGFudGVzIGRlIGVudmlhclxuICAgICAgICBkZWxldGUgKGRhdGFUb1NhdmUgYXMgYW55KS5uYW1lO1xuICAgICAgICBkZWxldGUgKGRhdGFUb1NhdmUgYXMgYW55KS5jb2RlO1xuXG4gICAgICAgIGNvbnN0IG5ld0l0ZW0gPSBhd2FpdCBzYXZlSXRlbShkYXRhVG9TYXZlKTtcbiAgICAgICAgaWYgKG5ld0l0ZW0pIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oYE1vdmltaWVudG8gY3JlYWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2NhamFzJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZVxuICAgICAgICAgICAgY29uZmlnPXtjYWphc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpbml0aWFsQ2FqYVZhbHVlcyBhcyBDYWphfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzQ3JlYXRlUGFnZS50c3gifQ==