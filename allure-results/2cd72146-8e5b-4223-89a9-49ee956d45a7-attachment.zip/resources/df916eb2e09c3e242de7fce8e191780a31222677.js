import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaPencilAlt, FaChevronDown, FaChevronUp } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { IoArrowBack } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const GenericDetailPage = ({
  config,
  item,
  hideHeader = false,
  renderExtraContent,
  canEditOverride,
  renderHeaderActions
}) => {
  _s();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const [blockVisibility, setBlockVisibility] = useState(
    config.form.block.reduce((acc, block) => ({ ...acc, [block.name]: { isCollapsed: false } }), {})
  );
  const modulePermission = getRequiredPermission(config.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEditByPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const canEdit = typeof canEditOverride === "boolean" ? canEditOverride && canEditByPermission : canEditByPermission;
  const toggleBlockVisibility = (blockName) => {
    setBlockVisibility((prevState) => ({
      ...prevState,
      [`${blockName}`]: { isCollapsed: !prevState[`${blockName}`].isCollapsed }
    }));
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
    !hideHeader && /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
        config.moduleName,
        ":",
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-indigo-600", children: item[config.detail.displayNameKey] }, void 0, false, {
          fileName: "/app/src/components/common/GenericDetailPage.tsx",
          lineNumber: 82,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericDetailPage.tsx",
        lineNumber: 80,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericDetailPage.tsx",
        lineNumber: 79,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-3 space-x-3 sm:mt-0", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(getListReturnPath(config.baseRoute)),
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: [
              /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/components/common/GenericDetailPage.tsx",
                lineNumber: 91,
                columnNumber: 29
              }, this),
              "Volver"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/components/common/GenericDetailPage.tsx",
            lineNumber: 86,
            columnNumber: 25
          },
          this
        ),
        canEdit && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(`${config.baseRoute}/${item.id}/editar`),
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
            children: [
              /* @__PURE__ */ jsxDEV(FaPencilAlt, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/components/common/GenericDetailPage.tsx",
                lineNumber: 100,
                columnNumber: 33
              }, this),
              "Editar"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/components/common/GenericDetailPage.tsx",
            lineNumber: 95,
            columnNumber: 11
          },
          this
        ),
        renderHeaderActions?.(item)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/GenericDetailPage.tsx",
        lineNumber: 85,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericDetailPage.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      config.form.block.map(
        (block) => /* @__PURE__ */ jsxDEV("div", { className: "border rounded-md", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center justify-between px-4 py-2 cursor-pointer bg-gray-50 hover:bg-gray-100 rounded-t-md",
              onClick: () => toggleBlockVisibility(block.name),
              children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: block.name }, void 0, false, {
                  fileName: "/app/src/components/common/GenericDetailPage.tsx",
                  lineNumber: 116,
                  columnNumber: 29
                }, this),
                blockVisibility[`${block.name}`]?.isCollapsed ? /* @__PURE__ */ jsxDEV(FaChevronDown, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
                  fileName: "/app/src/components/common/GenericDetailPage.tsx",
                  lineNumber: 118,
                  columnNumber: 13
                }, this) : /* @__PURE__ */ jsxDEV(FaChevronUp, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
                  fileName: "/app/src/components/common/GenericDetailPage.tsx",
                  lineNumber: 120,
                  columnNumber: 13
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/components/common/GenericDetailPage.tsx",
              lineNumber: 112,
              columnNumber: 25
            },
            this
          ),
          !blockVisibility[`${block.name}`]?.isCollapsed && /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-8 p-4 sm:grid-cols-2 lg:grid-cols-3", children: block.fields.filter((field) => {
            if (!field.visibleWhen) {
              return true;
            }
            return field.visibleWhen(item);
          }).map(
            (field) => /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
              /* @__PURE__ */ jsxDEV("dt", { className: "text-sm font-medium text-gray-500", children: field.label }, void 0, false, {
                fileName: "/app/src/components/common/GenericDetailPage.tsx",
                lineNumber: 137,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: (() => {
                if (field.render) return field.render(item);
                if (field.type === "array-string") {
                  const value = item[field.name];
                  const arrayValues = Array.isArray(value) ? value : [];
                  if (arrayValues.length === 0) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericDetailPage.tsx",
                    lineNumber: 149,
                    columnNumber: 58
                  }, this);
                  return /* @__PURE__ */ jsxDEV("ul", { className: "pl-4 list-disc list-inside", children: arrayValues.map(
                    (val, idx) => /* @__PURE__ */ jsxDEV("li", { className: "text-gray-800", children: val }, idx, false, {
                      fileName: "/app/src/components/common/GenericDetailPage.tsx",
                      lineNumber: 154,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "/app/src/components/common/GenericDetailPage.tsx",
                    lineNumber: 152,
                    columnNumber: 23
                  }, this);
                }
                if (field.type === "password") {
                  const val = item[field.name];
                  return val != null && String(val).length > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: "••••••••" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericDetailPage.tsx",
                    lineNumber: 164,
                    columnNumber: 21
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
                    fileName: "/app/src/components/common/GenericDetailPage.tsx",
                    lineNumber: 165,
                    columnNumber: 21
                  }, this);
                }
                return formatValue(item[field.name], field.format);
              })() }, void 0, false, {
                fileName: "/app/src/components/common/GenericDetailPage.tsx",
                lineNumber: 138,
                columnNumber: 45
              }, this)
            ] }, String(field.name), true, {
              fileName: "/app/src/components/common/GenericDetailPage.tsx",
              lineNumber: 136,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/components/common/GenericDetailPage.tsx",
            lineNumber: 125,
            columnNumber: 11
          }, this)
        ] }, block.name, true, {
          fileName: "/app/src/components/common/GenericDetailPage.tsx",
          lineNumber: 111,
          columnNumber: 9
        }, this)
      ),
      renderExtraContent?.(item)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericDetailPage.tsx",
      lineNumber: 109,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/GenericDetailPage.tsx",
    lineNumber: 76,
    columnNumber: 5
  }, this);
};
_s(GenericDetailPage, "4CxJQeTuXY3rTck10r3/Rl44yYY=", false, function() {
  return [useNavigate, usePermissions];
});
_c = GenericDetailPage;
var _c;
$RefreshReg$(_c, "GenericDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEQ0Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1RDVCLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYUMsZUFBZUMsbUJBQW1CO0FBQ3hELFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLHlCQUF5QjtBQWtCM0IsYUFBTUMsb0JBQW9CLENBQTBEO0FBQUEsRUFDdkZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGFBQWE7QUFBQSxFQUNiQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUN1QixNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTUMsV0FBV2xCLFlBQVk7QUFDN0IsUUFBTSxFQUFFbUIsb0JBQW9CLElBQUliLGVBQWU7QUFDL0MsUUFBTSxDQUFDYyxpQkFBaUJDLGtCQUFrQixJQUFJdEI7QUFBQUEsSUFDMUNZLE9BQU9XLEtBQUtDLE1BQU1DLE9BQU8sQ0FBQ0MsS0FBS0YsV0FBVyxFQUFFLEdBQUdFLEtBQUssQ0FBQ0YsTUFBTUcsSUFBSSxHQUFHLEVBQUVDLGFBQWEsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQUEsRUFDbkc7QUFHQSxRQUFNQyxtQkFBbUJyQixzQkFBc0JJLE9BQU9rQixTQUFTO0FBQy9ELFFBQU1DLGFBQWFGLG1CQUFtQnBCLHdCQUF3Qm9CLGdCQUFnQixJQUFJO0FBQ2xGLFFBQU1HLHNCQUFzQkQsYUFBYVgsb0JBQW9CVyxZQUFZLE1BQU0sSUFBSTtBQUNuRixRQUFNRSxVQUFVLE9BQU9qQixvQkFBb0IsWUFBWUEsbUJBQW1CZ0Isc0JBQXNCQTtBQUVoRyxRQUFNRSx3QkFBd0JBLENBQUNDLGNBQXNCO0FBQ2pEYix1QkFBbUIsQ0FBQWMsZUFBYztBQUFBLE1BQzdCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQyxHQUFHRCxTQUFTLEVBQUUsR0FBRyxFQUFFUCxhQUFhLENBQUNRLFVBQVUsR0FBR0QsU0FBUyxFQUFFLEVBQUVQLFlBQVk7QUFBQSxJQUM1RSxFQUFFO0FBQUEsRUFDTjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLDRDQUNWO0FBQUEsS0FBQ2QsY0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBQ1g7QUFBQSw2QkFBQyxTQUNHLGlDQUFDLFFBQUcsV0FBVSxpREFDVEY7QUFBQUEsZUFBT3lCO0FBQUFBLFFBQVc7QUFBQSxRQUFFO0FBQUEsUUFDckIsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnhCLGVBQUtELE9BQU8wQixPQUFPQyxjQUFjLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUc7QUFBQSxXQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1wQixTQUFTVCxrQkFBa0JFLE9BQU9rQixTQUFTLENBQUM7QUFBQSxZQUMzRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLGVBQVksV0FBVSx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUwvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBQ0NHLFdBQ0c7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTWQsU0FBUyxHQUFHUCxPQUFPa0IsU0FBUyxJQUFJakIsS0FBSzJCLEVBQUUsU0FBUztBQUFBLFlBQy9ELFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsZUFBWSxXQUFVLHdCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFFSHZCLHNCQUFzQkosSUFBSTtBQUFBLFdBbkIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLElBR0osdUJBQUMsU0FBSSxXQUFVLGFBQ1ZEO0FBQUFBLGFBQU9XLEtBQUtDLE1BQU1pQjtBQUFBQSxRQUFJLENBQUNqQixVQUNwQix1QkFBQyxTQUFxQixXQUFVLHFCQUM1QjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU1VLHNCQUFzQlYsTUFBTUcsSUFBSTtBQUFBLGNBRS9DO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHFDQUFxQ0gsZ0JBQU1HLFFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsZ0JBQzdETixnQkFBZ0IsR0FBR0csTUFBTUcsSUFBSSxFQUFFLEdBQUdDLGNBQy9CLHVCQUFDLGlCQUFjLFdBQVUsMkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdELElBRWhELHVCQUFDLGVBQVksV0FBVSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQTtBQUFBO0FBQUEsWUFSdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxVQUVDLENBQUNQLGdCQUFnQixHQUFHRyxNQUFNRyxJQUFJLEVBQUUsR0FBR0MsZUFDaEMsdUJBQUMsUUFBRyxXQUFVLHNFQUNUSixnQkFBTWtCLE9BQ0ZDLE9BQU8sQ0FBQUMsVUFBUztBQUViLGdCQUFJLENBQUNBLE1BQU1DLGFBQWE7QUFDcEIscUJBQU87QUFBQSxZQUNYO0FBRUEsbUJBQU9ELE1BQU1DLFlBQVloQyxJQUFJO0FBQUEsVUFDakMsQ0FBQyxFQUNBNEI7QUFBQUEsWUFBSSxDQUFDRyxVQUNGLHVCQUFDLFNBQTZCLFdBQVUsaUJBQ3BDO0FBQUEscUNBQUMsUUFBRyxXQUFVLHFDQUFxQ0EsZ0JBQU1FLFNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0QsdUJBQUMsUUFBRyxXQUFVLGdDQUVSLGlCQUFNO0FBRUosb0JBQUlGLE1BQU1HLE9BQVEsUUFBT0gsTUFBTUcsT0FBT2xDLElBQUk7QUFHMUMsb0JBQUkrQixNQUFNSSxTQUFTLGdCQUFnQjtBQUMvQix3QkFBTUMsUUFBUXBDLEtBQUsrQixNQUFNakIsSUFBSTtBQUM3Qix3QkFBTXVCLGNBQWVDLE1BQU1DLFFBQVFILEtBQUssSUFBSUEsUUFBUTtBQUVwRCxzQkFBSUMsWUFBWUcsV0FBVyxFQUFHLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFFdEUseUJBQ0ksdUJBQUMsUUFBRyxXQUFVLDhCQUNUSCxzQkFBWVQ7QUFBQUEsb0JBQUksQ0FBQ2EsS0FBYUMsUUFDM0IsdUJBQUMsUUFBYSxXQUFVLGlCQUFpQkQsaUJBQWhDQyxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsa0JBQ2hELEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGdCQUVSO0FBR0Esb0JBQUlYLE1BQU1JLFNBQVMsWUFBWTtBQUMzQix3QkFBTU0sTUFBTXpDLEtBQUsrQixNQUFNakIsSUFBSTtBQUMzQix5QkFBTzJCLE9BQU8sUUFBUUUsT0FBT0YsR0FBRyxFQUFFRCxTQUFTLElBQ3JDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0Isd0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDLElBQ3hDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsZ0JBQzNDO0FBR0EsdUJBQU8vQyxZQUFZTyxLQUFLK0IsTUFBTWpCLElBQUksR0FBR2lCLE1BQU1hLE1BQU07QUFBQSxjQUNyRCxHQUFHLEtBaENQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsaUJBbkNNRCxPQUFPWixNQUFNakIsSUFBSSxHQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQTtBQUFBLFVBQ0gsS0FoRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpREE7QUFBQSxhQS9ERUgsTUFBTUcsTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlFQTtBQUFBLE1BQ0g7QUFBQSxNQUNBWixxQkFBcUJGLElBQUk7QUFBQSxTQXJFOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNFQTtBQUFBLE9BdkdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3R0E7QUFFUjtBQUFFSyxHQXRJV1AsbUJBQWlCO0FBQUEsVUFRVFYsYUFDZU0sY0FBYztBQUFBO0FBQUFtRCxLQVRyQy9DO0FBQWlCLElBQUErQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiRmFQZW5jaWxBbHQiLCJGYUNoZXZyb25Eb3duIiwiRmFDaGV2cm9uVXAiLCJJb0Fycm93QmFjayIsImZvcm1hdFZhbHVlIiwidXNlUGVybWlzc2lvbnMiLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImdldExpc3RSZXR1cm5QYXRoIiwiR2VuZXJpY0RldGFpbFBhZ2UiLCJjb25maWciLCJpdGVtIiwiaGlkZUhlYWRlciIsInJlbmRlckV4dHJhQ29udGVudCIsImNhbkVkaXRPdmVycmlkZSIsInJlbmRlckhlYWRlckFjdGlvbnMiLCJfcyIsIm5hdmlnYXRlIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsImJsb2NrVmlzaWJpbGl0eSIsInNldEJsb2NrVmlzaWJpbGl0eSIsImZvcm0iLCJibG9jayIsInJlZHVjZSIsImFjYyIsIm5hbWUiLCJpc0NvbGxhcHNlZCIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdEJ5UGVybWlzc2lvbiIsImNhbkVkaXQiLCJ0b2dnbGVCbG9ja1Zpc2liaWxpdHkiLCJibG9ja05hbWUiLCJwcmV2U3RhdGUiLCJtb2R1bGVOYW1lIiwiZGV0YWlsIiwiZGlzcGxheU5hbWVLZXkiLCJpZCIsIm1hcCIsImZpZWxkcyIsImZpbHRlciIsImZpZWxkIiwidmlzaWJsZVdoZW4iLCJsYWJlbCIsInJlbmRlciIsInR5cGUiLCJ2YWx1ZSIsImFycmF5VmFsdWVzIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwidmFsIiwiaWR4IiwiU3RyaW5nIiwiZm9ybWF0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2VuZXJpY0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbi8vIHNyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZS50c3hcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBGYVBlbmNpbEFsdCwgRmFDaGV2cm9uRG93biwgRmFDaGV2cm9uVXAgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyBJb0Fycm93QmFjayB9IGZyb20gXCJyZWFjdC1pY29ucy9pbzVcIjtcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5pbnRlcmZhY2UgR2VuZXJpY0RldGFpbFBhZ2VQcm9wczxUPiB7XG4gICAgY29uZmlnOiBNb2R1bGVDb25maWc8VD47XG4gICAgaXRlbTogVDtcbiAgICBoaWRlSGVhZGVyPzogYm9vbGVhbjtcbiAgICAvKiogQ29udGVuaWRvIGV4dHJhIHF1ZSBwdWVkZSBkZXBlbmRlciBkZWwgw610ZW0uIFNlIHJlbmRlcml6YSBkZXNwdcOpcyBkZSBsb3MgYmxvcXVlcyBkZWwgZm9ybXVsYXJpby4gKi9cbiAgICByZW5kZXJFeHRyYUNvbnRlbnQ/OiAoaXRlbTogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xuICAgIC8qKiBQZXJtaXRlIGZvcnphciBzaSBzZSBtdWVzdHJhIG8gbm8gZWwgYm90w7NuIEVkaXRhciwgcG9yIGVuY2ltYSBkZSBwZXJtaXNvcyBwb3IgbcOzZHVsby4gKi9cbiAgICBjYW5FZGl0T3ZlcnJpZGU/OiBib29sZWFuO1xuICAgIC8qKiBBY2Npb25lcyBleHRyYSBlbiBlbCBlbmNhYmV6YWRvIChwLiBlai4gY29udmVyc2nDs24gYSBjbGllbnRlKSwganVudG8gYSBWb2x2ZXIvRWRpdGFyLiAqL1xuICAgIHJlbmRlckhlYWRlckFjdGlvbnM/OiAoaXRlbTogVCkgPT4gUmVhY3QuUmVhY3ROb2RlO1xufVxuXG5pbnRlcmZhY2UgQmxvY2tTdGF0ZSB7XG4gICAgaXNDb2xsYXBzZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBHZW5lcmljRGV0YWlsUGFnZSA9IDxUIGV4dGVuZHMgeyBpZDogc3RyaW5nIHwgbnVtYmVyIH0gJiBSZWNvcmQ8c3RyaW5nLCBhbnk+Pih7XG4gICAgY29uZmlnLFxuICAgIGl0ZW0sXG4gICAgaGlkZUhlYWRlciA9IGZhbHNlLFxuICAgIHJlbmRlckV4dHJhQ29udGVudCxcbiAgICBjYW5FZGl0T3ZlcnJpZGUsXG4gICAgcmVuZGVySGVhZGVyQWN0aW9ucyxcbn06IEdlbmVyaWNEZXRhaWxQYWdlUHJvcHM8VD4pID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IFtibG9ja1Zpc2liaWxpdHksIHNldEJsb2NrVmlzaWJpbGl0eV0gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBCbG9ja1N0YXRlPj4oXG4gICAgICAgIGNvbmZpZy5mb3JtLmJsb2NrLnJlZHVjZSgoYWNjLCBibG9jaykgPT4gKHsgLi4uYWNjLCBbYmxvY2submFtZV06IHsgaXNDb2xsYXBzZWQ6IGZhbHNlIH0gfSksIHt9KVxuICAgICk7XG5cbiAgICAvLyDinIUgVmFsaWRhciBwZXJtaXNvcyBwYXJhIGVkaXRhclxuICAgIGNvbnN0IG1vZHVsZVBlcm1pc3Npb24gPSBnZXRSZXF1aXJlZFBlcm1pc3Npb24oY29uZmlnLmJhc2VSb3V0ZSk7XG4gICAgY29uc3QgbW9kdWxlQmFzZSA9IG1vZHVsZVBlcm1pc3Npb24gPyBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbihtb2R1bGVQZXJtaXNzaW9uKSA6IG51bGw7XG4gICAgY29uc3QgY2FuRWRpdEJ5UGVybWlzc2lvbiA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuICAgIGNvbnN0IGNhbkVkaXQgPSB0eXBlb2YgY2FuRWRpdE92ZXJyaWRlID09PSAnYm9vbGVhbicgPyBjYW5FZGl0T3ZlcnJpZGUgJiYgY2FuRWRpdEJ5UGVybWlzc2lvbiA6IGNhbkVkaXRCeVBlcm1pc3Npb247XG5cbiAgICBjb25zdCB0b2dnbGVCbG9ja1Zpc2liaWxpdHkgPSAoYmxvY2tOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0QmxvY2tWaXNpYmlsaXR5KHByZXZTdGF0ZSA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldlN0YXRlLFxuICAgICAgICAgICAgW2Ake2Jsb2NrTmFtZX1gXTogeyBpc0NvbGxhcHNlZDogIXByZXZTdGF0ZVtgJHtibG9ja05hbWV9YF0uaXNDb2xsYXBzZWQgfVxuICAgICAgICB9KSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNlwiPlxuICAgICAgICAgICAgeyFoaWRlSGVhZGVyICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgbWItNCBib3JkZXItYiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbGVhZGluZy02IHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29uZmlnLm1vZHVsZU5hbWV9OnsnICd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtaW5kaWdvLTYwMFwiPntpdGVtW2NvbmZpZy5kZXRhaWwuZGlzcGxheU5hbWVLZXldIGFzIFJlYWN0LlJlYWN0Tm9kZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC0zIHNwYWNlLXgtMyBzbTptdC0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgoY29uZmlnLmJhc2VSb3V0ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvQXJyb3dCYWNrIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVm9sdmVyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5FZGl0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgJHtjb25maWcuYmFzZVJvdXRlfS8ke2l0ZW0uaWR9L2VkaXRhcmApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFQZW5jaWxBbHQgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yIC1tbC0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdGFyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckhlYWRlckFjdGlvbnM/LihpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgIHtjb25maWcuZm9ybS5ibG9jay5tYXAoKGJsb2NrKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtibG9jay5uYW1lfSBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC00IHB5LTIgY3Vyc29yLXBvaW50ZXIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCByb3VuZGVkLXQtbWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUJsb2NrVmlzaWJpbGl0eShibG9jay5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+e2Jsb2NrLm5hbWV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmxvY2tWaXNpYmlsaXR5W2Ake2Jsb2NrLm5hbWV9YF0/LmlzQ29sbGFwc2VkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUNoZXZyb25VcCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgeyFibG9ja1Zpc2liaWxpdHlbYCR7YmxvY2submFtZX1gXT8uaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC14LTQgZ2FwLXktOCBwLTQgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Jsb2NrLmZpZWxkc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihmaWVsZCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2kgbm8gaGF5IGNvbmRpY2nDs24gJ3Zpc2libGVXaGVuJywgZWwgY2FtcG8gc2llbXByZSBlcyB2aXNpYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFmaWVsZC52aXNpYmxlV2hlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2kgaGF5IGNvbmRpY2nDs24sIGxhIGV2YWx1YW1vcyBjb24gbG9zIGRhdG9zIGRlbCBpdGVtIGFjdHVhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmaWVsZC52aXNpYmxlV2hlbihpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKChmaWVsZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtTdHJpbmcoZmllbGQubmFtZSl9IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPntmaWVsZC5sYWJlbH08L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSBMT0dJQ0EgREUgUkVOREVSSVpBRE8gTUVKT1JBREEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAxLiBTaSB0aWVuZSByZW5kZXIgcGVyc29uYWxpemFkbywgbG8gdXNhbW9zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkLnJlbmRlcikgcmV0dXJuIGZpZWxkLnJlbmRlcihpdGVtKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDIuIFNpIGVzIHVuIGFycmF5IGRlIHN0cmluZ3MsIHJlbmRlcml6YW1vcyB1bmEgbGlzdGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQudHlwZSA9PT0gJ2FycmF5LXN0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBpdGVtW2ZpZWxkLm5hbWVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhcnJheVZhbHVlcyA9IChBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogW10pIGFzIHN0cmluZ1tdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhcnJheVZhbHVlcy5sZW5ndGggPT09IDApIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+LTwvc3Bhbj47XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJwbC00IGxpc3QtZGlzYyBsaXN0LWluc2lkZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcnJheVZhbHVlcy5tYXAoKHZhbDogc3RyaW5nLCBpZHg6IG51bWJlcikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpZHh9IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57dmFsfTwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDMuIFBhc3N3b3JkOiBubyBtb3N0cmFyIHZhbG9yIGVuIGNsYXJvIGVuIGRldGFsbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQudHlwZSA9PT0gJ3Bhc3N3b3JkJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBpdGVtW2ZpZWxkLm5hbWVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsICE9IG51bGwgJiYgU3RyaW5nKHZhbCkubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+LTwvc3Bhbj47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gNC4gRmFsbGJhY2sgZXN0w6FuZGFyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZvcm1hdFZhbHVlKGl0ZW1bZmllbGQubmFtZV0sIGZpZWxkLmZvcm1hdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIHtyZW5kZXJFeHRyYUNvbnRlbnQ/LihpdGVtKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UudHN4In0=