import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { createValueMapperRenderer } from "/src/utils/renders.tsx";
import { renderSignedStockQuantity } from "/src/utils/stockMovementQuantity.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
const movStockOptions = [
  { value: "A", label: "A - Compra a Proveedor" },
  { value: "B", label: "B - Baja de Stock" },
  { value: "C", label: "C - Corrección de Stock" },
  { value: "D", label: "D - Devolución" },
  { value: "F", label: "F - Venta a Cliente" },
  { value: "S", label: "S - Salida de Stock" }
];
const renderMovStockOptions = createValueMapperRenderer(
  movStockOptions,
  "movement_code"
);
const renderRelatedDocument = (item) => {
  const doc = item.related_document;
  const remito = item.delivery_note?.trim() ?? "";
  if (!doc && item.movement_code === "A" && remito) {
    return /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: [
      "Remito - ",
      remito
    ] }, void 0, true, {
      fileName: "/app/src/features/mov_stock/movStock.config.tsx",
      lineNumber: 72,
      columnNumber: 12
    }, this);
  }
  if (!doc) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
    fileName: "/app/src/features/mov_stock/movStock.config.tsx",
    lineNumber: 74,
    columnNumber: 20
  }, this);
  let label = "Doc";
  let colorClass = "bg-gray-100 text-gray-800";
  let route = "#";
  const docNumber = doc.document_number || doc.invoice_number || doc.internal_voucher || `ID: ${doc.id}`;
  switch (doc.type) {
    case "Purchase":
      label = "Compra";
      colorClass = "bg-blue-100 text-blue-800";
      route = `/compras/${doc.id}`;
      break;
    case "SalesInvoice":
      label = "Factura";
      colorClass = "bg-green-100 text-green-800";
      route = `/facturas-de-venta/${doc.id}`;
      break;
    case "credit_note":
      label = "Nota Crédito";
      colorClass = "bg-orange-100 text-orange-800";
      route = `/notas-credito/${doc.id}`;
      break;
    case "debit_note":
      label = "Nota Débito";
      colorClass = "bg-purple-100 text-purple-800";
      route = `/notas-debito/${doc.id}`;
      break;
    default:
      label = doc.type;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-start", children: route !== "#" ? /* @__PURE__ */ jsxDEV(Link, { to: route, className: "text-sm text-indigo-600 hover:text-indigo-900 hover:underline", children: [
    /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colorClass} mb-1`, children: label }, void 0, false, {
      fileName: "/app/src/features/mov_stock/movStock.config.tsx",
      lineNumber: 113,
      columnNumber: 21
    }, this),
    " - ",
    docNumber
  ] }, void 0, true, {
    fileName: "/app/src/features/mov_stock/movStock.config.tsx",
    lineNumber: 112,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: docNumber }, void 0, false, {
    fileName: "/app/src/features/mov_stock/movStock.config.tsx",
    lineNumber: 118,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/features/mov_stock/movStock.config.tsx",
    lineNumber: 110,
    columnNumber: 5
  }, this);
};
export const stockMovementsModuleConfig = {
  endpoint: "stock-movements",
  moduleName: "Movimiento de Stock",
  moduleNamePlural: "Movimientos de Stock",
  baseRoute: "/stock/movimientos",
  detail: {
    // Usamos un render para el título porque no hay un solo campo que lo identifique
    displayNameKey: "id"
    // Placeholder, el render es lo importante
  },
  list: {
    columns: [
      { header: "Fecha", accessor: "movement_date", format: "date" },
      { header: "Producto", accessor: "product_id", sortField: "product_name", render: (item) => item.product_name || "N/A" },
      { header: "Tipo", accessor: "movement_code", render: renderMovStockOptions },
      {
        header: "Documento Relacionado",
        // Header actualizado
        accessor: "related_document",
        // Accessor actualizado
        sortField: "related_document",
        render: renderRelatedDocument
        // Render actualizado
      },
      {
        header: "Cantidad",
        accessor: "quantity",
        render: (item) => /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: renderSignedStockQuantity(item.movement_code, item.quantity) }, void 0, false, {
          fileName: "/app/src/features/mov_stock/movStock.config.tsx",
          lineNumber: 151,
          columnNumber: 7
        }, this)
      },
      { header: "Cliente", accessor: "client_id", sortField: "client_name", render: (item) => item.client_name || "-" },
      { header: "Proveedor", accessor: "vendor_id", sortField: "vendor_name", render: (item) => item.vendor_name || "-" }
    ]
  },
  form: {
    block: [
      {
        name: "Detalle del Movimiento",
        fields: [
          { name: "movement_date", label: "Fecha del Movimiento", type: "date", mandatory: true },
          {
            name: "movement_code",
            label: "Tipo de Movimiento",
            type: "select",
            mandatory: true,
            options: movStockOptions,
            render: renderMovStockOptions
          },
          { name: "chart_account_id", label: "Comprobante Stock", type: "number" },
          {
            name: "product_id",
            label: "Producto",
            type: "relational",
            mandatory: true,
            relationalConfig: {
              moduleConfig: articulosModuleConfig,
              nameField: "product_name",
              codeField: "sku"
              // Campo en MovStock para guardar el nombre
            },
            render: (item) => {
              return /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: `/articulos/${item.product_id}`,
                  className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                  children: item.product_name || "N/A"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/mov_stock/movStock.config.tsx",
                  lineNumber: 181,
                  columnNumber: 13
                },
                this
              );
            }
          },
          {
            name: "quantity",
            label: "Cantidad",
            type: "number",
            mandatory: true,
            render: (item) => renderSignedStockQuantity(item.movement_code, item.quantity)
          }
        ]
      },
      {
        name: "Referencias y Documentación",
        fields: [
          {
            name: "related_document",
            // Accessor en el objeto item
            label: "Documento Relacionado",
            type: "text",
            // Tipo 'dummy', el render hace el trabajo real
            render: renderRelatedDocument
            // ¡Reutilizamos la misma lógica de la lista!
          },
          {
            name: "client_id",
            label: "Cliente Asociado",
            type: "relational",
            relationalConfig: {
              moduleConfig: clientesModuleConfig,
              nameField: "client_name",
              codeField: "customer_code"
            },
            render: (item) => item.client_name || "N/A",
            visibleWhen: (formData) => formData.movement_code !== "A"
          },
          {
            name: "vendor_id",
            label: "Proveedor Asociado",
            type: "relational",
            relationalConfig: {
              moduleConfig: proveedoresModuleConfig,
              nameField: "vendor_name",
              codeField: "vendor_code"
            },
            render: (item) => item.vendor_name || "N/A",
            visibleWhen: (formData) => formData.movement_code !== "F"
          },
          //{ name: 'voucher', label: 'Comprobante', type: 'text', placeholder: 'Ej: FAC-A-0001-12345' },
          { name: "delivery_note", label: "Remito", type: "text" },
          { name: "reference", label: "Referencia", type: "textarea", placeholder: "Cualquier observación adicional..." }
        ]
      }
    ]
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUVlO0FBcEVmLFNBQVNBLDRCQUE0QjtBQUNyQyxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLGlDQUFrQztBQUMzQyxTQUFTQyxpQ0FBaUM7QUFDMUMsU0FBU0MsWUFBWTtBQTRDckIsTUFBTUMsa0JBQWtCO0FBQUEsRUFDcEIsRUFBRUMsT0FBTyxLQUFLQyxPQUFPLHlCQUF5QjtBQUFBLEVBQzlDLEVBQUVELE9BQU8sS0FBS0MsT0FBTyxvQkFBb0I7QUFBQSxFQUN6QyxFQUFFRCxPQUFPLEtBQUtDLE9BQU8sMEJBQTBCO0FBQUEsRUFDL0MsRUFBRUQsT0FBTyxLQUFLQyxPQUFPLGlCQUFpQjtBQUFBLEVBQ3RDLEVBQUVELE9BQU8sS0FBS0MsT0FBTyxzQkFBc0I7QUFBQSxFQUMzQyxFQUFFRCxPQUFPLEtBQUtDLE9BQU8sc0JBQXNCO0FBQUM7QUFHaEQsTUFBTUMsd0JBQXdCTjtBQUFBQSxFQUMxQkc7QUFBQUEsRUFDQTtBQUNKO0FBR0EsTUFBTUksd0JBQXdCQSxDQUFDQyxTQUFtQjtBQUM5QyxRQUFNQyxNQUFNRCxLQUFLRTtBQUNqQixRQUFNQyxTQUFTSCxLQUFLSSxlQUFlQyxLQUFLLEtBQUs7QUFDN0MsTUFBSSxDQUFDSixPQUFPRCxLQUFLTSxrQkFBa0IsT0FBT0gsUUFBUTtBQUM5QyxXQUFPLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLE1BQVVBO0FBQUFBLFNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxFQUNwRTtBQUNBLE1BQUksQ0FBQ0YsSUFBSyxRQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUM7QUFHbEQsTUFBSUosUUFBUTtBQUNaLE1BQUlVLGFBQWE7QUFDakIsTUFBSUMsUUFBUTtBQUdaLFFBQU1DLFlBQVlSLElBQUlTLG1CQUFtQlQsSUFBSVUsa0JBQWtCVixJQUFJVyxvQkFBb0IsT0FBT1gsSUFBSVksRUFBRTtBQUVwRyxVQUFRWixJQUFJYSxNQUFJO0FBQUEsSUFDWixLQUFLO0FBQ0RqQixjQUFRO0FBQ1JVLG1CQUFhO0FBQ2JDLGNBQVEsWUFBWVAsSUFBSVksRUFBRTtBQUMxQjtBQUFBLElBQ0osS0FBSztBQUNEaEIsY0FBUTtBQUNSVSxtQkFBYTtBQUNiQyxjQUFRLHNCQUFzQlAsSUFBSVksRUFBRTtBQUNwQztBQUFBLElBQ0osS0FBSztBQUNEaEIsY0FBUTtBQUNSVSxtQkFBYTtBQUNiQyxjQUFRLGtCQUFrQlAsSUFBSVksRUFBRTtBQUNoQztBQUFBLElBQ0osS0FBSztBQUNEaEIsY0FBUTtBQUNSVSxtQkFBYTtBQUNiQyxjQUFRLGlCQUFpQlAsSUFBSVksRUFBRTtBQUMvQjtBQUFBLElBQ0o7QUFDSWhCLGNBQVFJLElBQUlhO0FBQUFBLEVBQ3BCO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1ZOLG9CQUFVLE1BQ1AsdUJBQUMsUUFBSyxJQUFJQSxPQUFPLFdBQVUsaUVBQ3ZCO0FBQUEsMkJBQUMsVUFBSyxXQUFXLG9FQUFvRUQsVUFBVSxTQUMxRlYsbUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFBTztBQUFBLElBQUlZO0FBQUFBLE9BSGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLElBRUEsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QkEsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUQsS0FSM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRVI7QUFHTyxhQUFNTSw2QkFBcUQ7QUFBQSxFQUM5REMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaQyxrQkFBa0I7QUFBQSxFQUNsQkMsV0FBVztBQUFBLEVBRVhDLFFBQVE7QUFBQTtBQUFBLElBRUpDLGdCQUFnQjtBQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsU0FBUztBQUFBLE1BQ0wsRUFBRUMsUUFBUSxTQUFTQyxVQUFVLGlCQUFpQkMsUUFBUSxPQUFPO0FBQUEsTUFDN0QsRUFBRUYsUUFBUSxZQUFZQyxVQUFVLGNBQWNFLFdBQVcsZ0JBQWdCQyxRQUFRQSxDQUFDNUIsU0FBU0EsS0FBSzZCLGdCQUFnQixNQUFNO0FBQUEsTUFDdEgsRUFBRUwsUUFBUSxRQUFRQyxVQUFVLGlCQUFpQkcsUUFBUTlCLHNCQUFzQjtBQUFBLE1BQzNFO0FBQUEsUUFDSTBCLFFBQVE7QUFBQTtBQUFBLFFBQ1JDLFVBQVU7QUFBQTtBQUFBLFFBQ1ZFLFdBQVc7QUFBQSxRQUNYQyxRQUFRN0I7QUFBQUE7QUFBQUEsTUFDWjtBQUFBLE1BQ0E7QUFBQSxRQUNJeUIsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWRyxRQUFRQSxDQUFDNUIsU0FDTCx1QkFBQyxTQUFJLFdBQVUsY0FBY1Asb0NBQTBCTyxLQUFLTSxlQUFlTixLQUFLOEIsUUFBUSxLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsTUFFbEc7QUFBQSxNQUNBLEVBQUVOLFFBQVEsV0FBV0MsVUFBVSxhQUFhRSxXQUFXLGVBQWVDLFFBQVFBLENBQUM1QixTQUFTQSxLQUFLK0IsZUFBZSxJQUFJO0FBQUEsTUFDaEgsRUFBRVAsUUFBUSxhQUFhQyxVQUFVLGFBQWFFLFdBQVcsZUFBZUMsUUFBUUEsQ0FBQzVCLFNBQVNBLEtBQUtnQyxlQUFlLElBQUk7QUFBQSxJQUFDO0FBQUEsRUFFM0g7QUFBQSxFQUVBQyxNQUFNO0FBQUEsSUFDRkMsT0FBTztBQUFBLE1BQ0g7QUFBQSxRQUNJQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFVBQ0osRUFBRUQsTUFBTSxpQkFBaUJ0QyxPQUFPLHdCQUF3QmlCLE1BQU0sUUFBUXVCLFdBQVcsS0FBSztBQUFBLFVBQ3RGO0FBQUEsWUFDSUYsTUFBTTtBQUFBLFlBQWlCdEMsT0FBTztBQUFBLFlBQXNCaUIsTUFBTTtBQUFBLFlBQVV1QixXQUFXO0FBQUEsWUFDL0VDLFNBQVMzQztBQUFBQSxZQUNUaUMsUUFBUTlCO0FBQUFBLFVBQ1o7QUFBQSxVQUNBLEVBQUVxQyxNQUFNLG9CQUFvQnRDLE9BQU8scUJBQXFCaUIsTUFBTSxTQUFTO0FBQUEsVUFFdkU7QUFBQSxZQUNJcUIsTUFBTTtBQUFBLFlBQWN0QyxPQUFPO0FBQUEsWUFBWWlCLE1BQU07QUFBQSxZQUFjdUIsV0FBVztBQUFBLFlBQ3RFRSxrQkFBa0I7QUFBQSxjQUNkQyxjQUFjbEQ7QUFBQUEsY0FDZG1ELFdBQVc7QUFBQSxjQUNYQyxXQUFXO0FBQUE7QUFBQSxZQUNmO0FBQUEsWUFDQWQsUUFBUUEsQ0FBQzVCLFNBQVM7QUFDZCxxQkFDSTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxJQUFJLGNBQWNBLEtBQUsyQyxVQUFVO0FBQUEsa0JBQ2pDLFdBQVU7QUFBQSxrQkFFVDNDLGVBQUs2QixnQkFBZ0I7QUFBQTtBQUFBLGdCQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLFlBRVI7QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFlBQ0lNLE1BQU07QUFBQSxZQUNOdEMsT0FBTztBQUFBLFlBQ1BpQixNQUFNO0FBQUEsWUFDTnVCLFdBQVc7QUFBQSxZQUNYVCxRQUFRQSxDQUFDNUIsU0FBU1AsMEJBQTBCTyxLQUFLTSxlQUFlTixLQUFLOEIsUUFBUTtBQUFBLFVBQ2pGO0FBQUEsUUFBQztBQUFBLE1BRVQ7QUFBQSxNQUNBO0FBQUEsUUFDSUssTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxVQUNKO0FBQUEsWUFDSUQsTUFBTTtBQUFBO0FBQUEsWUFDTnRDLE9BQU87QUFBQSxZQUNQaUIsTUFBTTtBQUFBO0FBQUEsWUFDTmMsUUFBUTdCO0FBQUFBO0FBQUFBLFVBQ1o7QUFBQSxVQUNBO0FBQUEsWUFDSW9DLE1BQU07QUFBQSxZQUFhdEMsT0FBTztBQUFBLFlBQW9CaUIsTUFBTTtBQUFBLFlBQ3BEeUIsa0JBQWtCO0FBQUEsY0FDZEMsY0FBY25EO0FBQUFBLGNBQ2RvRCxXQUFXO0FBQUEsY0FDWEMsV0FBVztBQUFBLFlBQ2Y7QUFBQSxZQUNBZCxRQUFRQSxDQUFDNUIsU0FBU0EsS0FBSytCLGVBQWU7QUFBQSxZQUN0Q2EsYUFBYUEsQ0FBQ0MsYUFBYUEsU0FBU3ZDLGtCQUFrQjtBQUFBLFVBQzFEO0FBQUEsVUFDQTtBQUFBLFlBQ0k2QixNQUFNO0FBQUEsWUFBYXRDLE9BQU87QUFBQSxZQUFzQmlCLE1BQU07QUFBQSxZQUN0RHlCLGtCQUFrQjtBQUFBLGNBQ2RDLGNBQWNqRDtBQUFBQSxjQUNka0QsV0FBVztBQUFBLGNBQ1hDLFdBQVc7QUFBQSxZQUNmO0FBQUEsWUFDQWQsUUFBUUEsQ0FBQzVCLFNBQVNBLEtBQUtnQyxlQUFlO0FBQUEsWUFDdENZLGFBQWFBLENBQUNDLGFBQWFBLFNBQVN2QyxrQkFBa0I7QUFBQSxVQUMxRDtBQUFBO0FBQUEsVUFFQSxFQUFFNkIsTUFBTSxpQkFBaUJ0QyxPQUFPLFVBQVVpQixNQUFNLE9BQU87QUFBQSxVQUN2RCxFQUFFcUIsTUFBTSxhQUFhdEMsT0FBTyxjQUFjaUIsTUFBTSxZQUFZZ0MsYUFBYSxxQ0FBcUM7QUFBQSxRQUFDO0FBQUEsTUFFdkg7QUFBQSxJQUFDO0FBQUEsRUFFVDtBQUNKIiwibmFtZXMiOlsiY2xpZW50ZXNNb2R1bGVDb25maWciLCJhcnRpY3Vsb3NNb2R1bGVDb25maWciLCJwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZyIsImNyZWF0ZVZhbHVlTWFwcGVyUmVuZGVyZXIiLCJyZW5kZXJTaWduZWRTdG9ja1F1YW50aXR5IiwiTGluayIsIm1vdlN0b2NrT3B0aW9ucyIsInZhbHVlIiwibGFiZWwiLCJyZW5kZXJNb3ZTdG9ja09wdGlvbnMiLCJyZW5kZXJSZWxhdGVkRG9jdW1lbnQiLCJpdGVtIiwiZG9jIiwicmVsYXRlZF9kb2N1bWVudCIsInJlbWl0byIsImRlbGl2ZXJ5X25vdGUiLCJ0cmltIiwibW92ZW1lbnRfY29kZSIsImNvbG9yQ2xhc3MiLCJyb3V0ZSIsImRvY051bWJlciIsImRvY3VtZW50X251bWJlciIsImludm9pY2VfbnVtYmVyIiwiaW50ZXJuYWxfdm91Y2hlciIsImlkIiwidHlwZSIsInN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnIiwiZW5kcG9pbnQiLCJtb2R1bGVOYW1lIiwibW9kdWxlTmFtZVBsdXJhbCIsImJhc2VSb3V0ZSIsImRldGFpbCIsImRpc3BsYXlOYW1lS2V5IiwibGlzdCIsImNvbHVtbnMiLCJoZWFkZXIiLCJhY2Nlc3NvciIsImZvcm1hdCIsInNvcnRGaWVsZCIsInJlbmRlciIsInByb2R1Y3RfbmFtZSIsInF1YW50aXR5IiwiY2xpZW50X25hbWUiLCJ2ZW5kb3JfbmFtZSIsImZvcm0iLCJibG9jayIsIm5hbWUiLCJmaWVsZHMiLCJtYW5kYXRvcnkiLCJvcHRpb25zIiwicmVsYXRpb25hbENvbmZpZyIsIm1vZHVsZUNvbmZpZyIsIm5hbWVGaWVsZCIsImNvZGVGaWVsZCIsInByb2R1Y3RfaWQiLCJ2aXNpYmxlV2hlbiIsImZvcm1EYXRhIiwicGxhY2Vob2xkZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibW92U3RvY2suY29uZmlnLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvZmVhdHVyZXMvc3RvY2stbW92ZW1lbnRzL3N0b2NrTW92ZW1lbnRzLmNvbmZpZy50c3hcblxuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlXCI7XG5pbXBvcnQgeyBjbGllbnRlc01vZHVsZUNvbmZpZyB9IGZyb20gXCIuLi9jbGllbnRlcy9jbGllbnRlcy5jb25maWdcIjtcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZyB9IGZyb20gXCIuLi9hcnRpY3Vsb3MvYXJ0aWN1bG9zLmNvbmZpZ1wiO1xuaW1wb3J0IHsgcHJvdmVlZG9yZXNNb2R1bGVDb25maWcgfSBmcm9tIFwiLi4vcHJvdmVlZG9yZXMvcHJvdmVlZG9yZXMuY29uZmlnXCI7XG5pbXBvcnQgeyBjcmVhdGVWYWx1ZU1hcHBlclJlbmRlcmVyLCB9IGZyb20gXCIuLi8uLi91dGlscy9yZW5kZXJzXCI7XG5pbXBvcnQgeyByZW5kZXJTaWduZWRTdG9ja1F1YW50aXR5IH0gZnJvbSBcIi4uLy4uL3V0aWxzL3N0b2NrTW92ZW1lbnRRdWFudGl0eVwiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmVsYXRlZERvY3VtZW50IHtcbiAgICBpZDogbnVtYmVyO1xuICAgIC8vIEFqdXN0YSBlc3RvcyBzdHJpbmdzIHNlZ8O6biBsbyBxdWUgZGV2dWVsdmEgdHUgYmFja2VuZCAobW9ycGggbWFwKVxuICAgIHR5cGU6ICdwdXJjaGFzZScgfCAnc2FsZXNfaW52b2ljZScgfCAnY3JlZGl0X25vdGUnIHwgJ2RlYml0X25vdGUnIHwgc3RyaW5nO1xuXG4gICAgLy8gRWwgYmFja2VuZCBkZWJlcsOtYSBub3JtYWxpemFyIGVzdG8gbyBlbnZpYXJsbyBzZWfDum4gZWwgbW9kZWxvXG4gICAgZG9jdW1lbnRfbnVtYmVyPzogc3RyaW5nOyAgIC8vIEdlbsOpcmljb1xuICAgIGludm9pY2VfbnVtYmVyPzogc3RyaW5nOyAgICAvLyBUw61waWNvIGRlIEZhY3R1cmFzIFZlbnRhXG4gICAgaW50ZXJuYWxfdm91Y2hlcj86IHN0cmluZzsgIC8vIFTDrXBpY28gZGUgQ29tcHJhc1xuICAgIGRpc3BsYXlfbmFtZT86IHN0cmluZzsgICAgICAvLyBTaSBlbCBiYWNrZW5kIHlhIG1hbmRhIGFsZ28gZm9ybWF0ZWFkb1xufVxuXG5cbi8vIC0tLSBJbnRlcmZheiBQcmluY2lwYWwgcGFyYSBNb3ZpbWllbnRvIGRlIFN0b2NrIC0tLVxuZXhwb3J0IGludGVyZmFjZSBNb3ZTdG9jayB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBtb3ZlbWVudF9kYXRlOiBzdHJpbmc7XG4gICAgbW92ZW1lbnRfY29kZTogJ0EnIHwgJ0InIHwgJ0MnIHwgJ0QnIHwgJ0YnIHwgJ1MnIHwgc3RyaW5nO1xuICAgIHF1YW50aXR5OiBudW1iZXI7XG4gICAgcmVsYXRlZF9kb2N1bWVudDogUmVsYXRlZERvY3VtZW50IHwgbnVsbDtcbiAgICB2b3VjaGVyOiBzdHJpbmcgfCBudWxsO1xuICAgIHJlZmVyZW5jZTogc3RyaW5nIHwgbnVsbDtcbiAgICBkZWxpdmVyeV9ub3RlOiBzdHJpbmcgfCBudWxsO1xuXG4gICAgLy8gSURzIGRlIHJlbGFjaW9uZXNcbiAgICBwcm9kdWN0X2lkOiBudW1iZXI7XG4gICAgY2xpZW50X2lkOiBudW1iZXIgfCBudWxsO1xuICAgIHZlbmRvcl9pZDogbnVtYmVyIHwgbnVsbDtcbiAgICBjaGFydF9hY2NvdW50X2lkOiBudW1iZXIgfCBudWxsO1xuXG4gICAgLy8gQ2FtcG9zIHBhcmEgbW9zdHJhciBub21icmVzIGVuIGlucHV0cyByZWxhY2lvbmFsZXNcbiAgICBwcm9kdWN0X25hbWU/OiBzdHJpbmc7XG4gICAgc2t1Pzogc3RyaW5nO1xuICAgIGNsaWVudF9uYW1lPzogc3RyaW5nO1xuICAgIHZlbmRvcl9uYW1lPzogc3RyaW5nO1xuICAgIGN1c3RvbWVyX2NvZGU/OiBzdHJpbmc7XG4gICAgdmVuZG9yX2NvZGU/OiBzdHJpbmc7XG4gICAgY2hhcnRfYWNjb3VudF9uYW1lPzogc3RyaW5nO1xuXG4gICAgY3JlYXRlZF9hdD86IHN0cmluZztcbn1cblxuY29uc3QgbW92U3RvY2tPcHRpb25zID0gW1xuICAgIHsgdmFsdWU6ICdBJywgbGFiZWw6ICdBIC0gQ29tcHJhIGEgUHJvdmVlZG9yJyB9LFxuICAgIHsgdmFsdWU6ICdCJywgbGFiZWw6ICdCIC0gQmFqYSBkZSBTdG9jaycgfSxcbiAgICB7IHZhbHVlOiAnQycsIGxhYmVsOiAnQyAtIENvcnJlY2Npw7NuIGRlIFN0b2NrJyB9LFxuICAgIHsgdmFsdWU6ICdEJywgbGFiZWw6ICdEIC0gRGV2b2x1Y2nDs24nIH0sXG4gICAgeyB2YWx1ZTogJ0YnLCBsYWJlbDogJ0YgLSBWZW50YSBhIENsaWVudGUnIH0sXG4gICAgeyB2YWx1ZTogJ1MnLCBsYWJlbDogJ1MgLSBTYWxpZGEgZGUgU3RvY2snIH0sXG5dO1xuXG5jb25zdCByZW5kZXJNb3ZTdG9ja09wdGlvbnMgPSBjcmVhdGVWYWx1ZU1hcHBlclJlbmRlcmVyPE1vdlN0b2NrPihcbiAgICBtb3ZTdG9ja09wdGlvbnMsXG4gICAgJ21vdmVtZW50X2NvZGUnXG4pO1xuXG4vLyDinIUgTUFHSUMgRlVOQ1RJT046IFJlbmRlcml6YWRvIFBvbGltw7NyZmljb1xuY29uc3QgcmVuZGVyUmVsYXRlZERvY3VtZW50ID0gKGl0ZW06IE1vdlN0b2NrKSA9PiB7XG4gICAgY29uc3QgZG9jID0gaXRlbS5yZWxhdGVkX2RvY3VtZW50O1xuICAgIGNvbnN0IHJlbWl0byA9IGl0ZW0uZGVsaXZlcnlfbm90ZT8udHJpbSgpID8/ICcnO1xuICAgIGlmICghZG9jICYmIGl0ZW0ubW92ZW1lbnRfY29kZSA9PT0gJ0EnICYmIHJlbWl0bykge1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+UmVtaXRvIC0ge3JlbWl0b308L3NwYW4+O1xuICAgIH1cbiAgICBpZiAoIWRvYykgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4tPC9zcGFuPjtcblxuICAgIC8vIDEuIERldGVybWluYXIgZXRpcXVldGEgeSBjb2xvciBzZWfDum4gZWwgdGlwb1xuICAgIGxldCBsYWJlbCA9ICdEb2MnO1xuICAgIGxldCBjb2xvckNsYXNzID0gJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnO1xuICAgIGxldCByb3V0ZSA9ICcjJztcblxuICAgIC8vIE5vcm1hbGl6YW1vcyBlbCBuw7ptZXJvIGRlIGRvY3VtZW50byBidXNjYW5kbyBlbiBsb3MgY2FtcG9zIHBvc2libGVzXG4gICAgY29uc3QgZG9jTnVtYmVyID0gZG9jLmRvY3VtZW50X251bWJlciB8fCBkb2MuaW52b2ljZV9udW1iZXIgfHwgZG9jLmludGVybmFsX3ZvdWNoZXIgfHwgYElEOiAke2RvYy5pZH1gO1xuXG4gICAgc3dpdGNoIChkb2MudHlwZSkge1xuICAgICAgICBjYXNlICdQdXJjaGFzZSc6XG4gICAgICAgICAgICBsYWJlbCA9ICdDb21wcmEnO1xuICAgICAgICAgICAgY29sb3JDbGFzcyA9ICdiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwJztcbiAgICAgICAgICAgIHJvdXRlID0gYC9jb21wcmFzLyR7ZG9jLmlkfWA7IC8vIEFzdW1lIHJ1dGEgZGUgY29tcHJhc1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ1NhbGVzSW52b2ljZSc6XG4gICAgICAgICAgICBsYWJlbCA9ICdGYWN0dXJhJztcbiAgICAgICAgICAgIGNvbG9yQ2xhc3MgPSAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgICAgICAgIHJvdXRlID0gYC9mYWN0dXJhcy1kZS12ZW50YS8ke2RvYy5pZH1gOyAvLyBBc3VtZSBydXRhIGRlIHZlbnRhc1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2NyZWRpdF9ub3RlJzpcbiAgICAgICAgICAgIGxhYmVsID0gJ05vdGEgQ3LDqWRpdG8nO1xuICAgICAgICAgICAgY29sb3JDbGFzcyA9ICdiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTgwMCc7XG4gICAgICAgICAgICByb3V0ZSA9IGAvbm90YXMtY3JlZGl0by8ke2RvYy5pZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2RlYml0X25vdGUnOlxuICAgICAgICAgICAgbGFiZWwgPSAnTm90YSBEw6liaXRvJztcbiAgICAgICAgICAgIGNvbG9yQ2xhc3MgPSAnYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAnO1xuICAgICAgICAgICAgcm91dGUgPSBgL25vdGFzLWRlYml0by8ke2RvYy5pZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBsYWJlbCA9IGRvYy50eXBlOyAvLyBGYWxsYmFja1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAge3JvdXRlICE9PSAnIycgPyAoXG4gICAgICAgICAgICAgICAgPExpbmsgdG89e3JvdXRlfSBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby05MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQteHMgZm9udC1tZWRpdW0gJHtjb2xvckNsYXNzfSBtYi0xYH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj4gLSB7ZG9jTnVtYmVyfVxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+e2RvY051bWJlcn08L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuLy8gLS0tIENvbmZpZ3VyYWNpw7NuIGRlbCBNw7NkdWxvIGRlIE1vdmltaWVudG9zIGRlIFN0b2NrIC0tLVxuZXhwb3J0IGNvbnN0IHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnOiBNb2R1bGVDb25maWc8TW92U3RvY2s+ID0ge1xuICAgIGVuZHBvaW50OiAnc3RvY2stbW92ZW1lbnRzJyxcbiAgICBtb2R1bGVOYW1lOiAnTW92aW1pZW50byBkZSBTdG9jaycsXG4gICAgbW9kdWxlTmFtZVBsdXJhbDogJ01vdmltaWVudG9zIGRlIFN0b2NrJyxcbiAgICBiYXNlUm91dGU6ICcvc3RvY2svbW92aW1pZW50b3MnLFxuXG4gICAgZGV0YWlsOiB7XG4gICAgICAgIC8vIFVzYW1vcyB1biByZW5kZXIgcGFyYSBlbCB0w610dWxvIHBvcnF1ZSBubyBoYXkgdW4gc29sbyBjYW1wbyBxdWUgbG8gaWRlbnRpZmlxdWVcbiAgICAgICAgZGlzcGxheU5hbWVLZXk6ICdpZCcsIC8vIFBsYWNlaG9sZGVyLCBlbCByZW5kZXIgZXMgbG8gaW1wb3J0YW50ZVxuICAgIH0sXG5cbiAgICBsaXN0OiB7XG4gICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnRmVjaGEnLCBhY2Nlc3NvcjogJ21vdmVtZW50X2RhdGUnLCBmb3JtYXQ6ICdkYXRlJyB9LFxuICAgICAgICAgICAgeyBoZWFkZXI6ICdQcm9kdWN0bycsIGFjY2Vzc29yOiAncHJvZHVjdF9pZCcsIHNvcnRGaWVsZDogJ3Byb2R1Y3RfbmFtZScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0ucHJvZHVjdF9uYW1lIHx8ICdOL0EnIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ1RpcG8nLCBhY2Nlc3NvcjogJ21vdmVtZW50X2NvZGUnLCByZW5kZXI6IHJlbmRlck1vdlN0b2NrT3B0aW9ucyB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ0RvY3VtZW50byBSZWxhY2lvbmFkbycsIC8vIEhlYWRlciBhY3R1YWxpemFkb1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAncmVsYXRlZF9kb2N1bWVudCcsICAgIC8vIEFjY2Vzc29yIGFjdHVhbGl6YWRvXG4gICAgICAgICAgICAgICAgc29ydEZpZWxkOiAncmVsYXRlZF9kb2N1bWVudCcsXG4gICAgICAgICAgICAgICAgcmVuZGVyOiByZW5kZXJSZWxhdGVkRG9jdW1lbnQsICAgLy8gUmVuZGVyIGFjdHVhbGl6YWRvXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcjogJ0NhbnRpZGFkJyxcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogJ3F1YW50aXR5JyxcbiAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPntyZW5kZXJTaWduZWRTdG9ja1F1YW50aXR5KGl0ZW0ubW92ZW1lbnRfY29kZSwgaXRlbS5xdWFudGl0eSl9PC9kaXY+XG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7IGhlYWRlcjogJ0NsaWVudGUnLCBhY2Nlc3NvcjogJ2NsaWVudF9pZCcsIHNvcnRGaWVsZDogJ2NsaWVudF9uYW1lJywgcmVuZGVyOiAoaXRlbSkgPT4gaXRlbS5jbGllbnRfbmFtZSB8fCAnLScgfSxcbiAgICAgICAgICAgIHsgaGVhZGVyOiAnUHJvdmVlZG9yJywgYWNjZXNzb3I6ICd2ZW5kb3JfaWQnLCBzb3J0RmllbGQ6ICd2ZW5kb3JfbmFtZScsIHJlbmRlcjogKGl0ZW0pID0+IGl0ZW0udmVuZG9yX25hbWUgfHwgJy0nIH0sXG4gICAgICAgIF0sXG4gICAgfSxcblxuICAgIGZvcm06IHtcbiAgICAgICAgYmxvY2s6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIkRldGFsbGUgZGVsIE1vdmltaWVudG9cIixcbiAgICAgICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnbW92ZW1lbnRfZGF0ZScsIGxhYmVsOiAnRmVjaGEgZGVsIE1vdmltaWVudG8nLCB0eXBlOiAnZGF0ZScsIG1hbmRhdG9yeTogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnbW92ZW1lbnRfY29kZScsIGxhYmVsOiAnVGlwbyBkZSBNb3ZpbWllbnRvJywgdHlwZTogJ3NlbGVjdCcsIG1hbmRhdG9yeTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM6IG1vdlN0b2NrT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogcmVuZGVyTW92U3RvY2tPcHRpb25zXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2NoYXJ0X2FjY291bnRfaWQnLCBsYWJlbDogJ0NvbXByb2JhbnRlIFN0b2NrJywgdHlwZTogJ251bWJlcicgfSxcblxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAncHJvZHVjdF9pZCcsIGxhYmVsOiAnUHJvZHVjdG8nLCB0eXBlOiAncmVsYXRpb25hbCcsIG1hbmRhdG9yeTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uYWxDb25maWc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVDb25maWc6IGFydGljdWxvc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICdwcm9kdWN0X25hbWUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVGaWVsZDogJ3NrdScgLy8gQ2FtcG8gZW4gTW92U3RvY2sgcGFyYSBndWFyZGFyIGVsIG5vbWJyZVxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvYXJ0aWN1bG9zLyR7aXRlbS5wcm9kdWN0X2lkfWB9IC8vIEFzdW1vIHJ1dGEgL3Byb3ZlZWRvcmVzLzppZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9kdWN0X25hbWUgfHwgJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdxdWFudGl0eScsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0NhbnRpZGFkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdudW1iZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWFuZGF0b3J5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoaXRlbSkgPT4gcmVuZGVyU2lnbmVkU3RvY2tRdWFudGl0eShpdGVtLm1vdmVtZW50X2NvZGUsIGl0ZW0ucXVhbnRpdHkpLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJSZWZlcmVuY2lhcyB5IERvY3VtZW50YWNpw7NuXCIsXG4gICAgICAgICAgICAgICAgZmllbGRzOiBbXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdyZWxhdGVkX2RvY3VtZW50JywgLy8gQWNjZXNzb3IgZW4gZWwgb2JqZXRvIGl0ZW1cbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnRG9jdW1lbnRvIFJlbGFjaW9uYWRvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0ZXh0JywgLy8gVGlwbyAnZHVtbXknLCBlbCByZW5kZXIgaGFjZSBlbCB0cmFiYWpvIHJlYWxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcjogcmVuZGVyUmVsYXRlZERvY3VtZW50IC8vIMKhUmV1dGlsaXphbW9zIGxhIG1pc21hIGzDs2dpY2EgZGUgbGEgbGlzdGEhXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdjbGllbnRfaWQnLCBsYWJlbDogJ0NsaWVudGUgQXNvY2lhZG8nLCB0eXBlOiAncmVsYXRpb25hbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICByZWxhdGlvbmFsQ29uZmlnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kdWxlQ29uZmlnOiBjbGllbnRlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICdjbGllbnRfbmFtZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnY3VzdG9tZXJfY29kZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLmNsaWVudF9uYW1lIHx8ICdOL0EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZVdoZW46IChmb3JtRGF0YSkgPT4gZm9ybURhdGEubW92ZW1lbnRfY29kZSAhPT0gJ0EnXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICd2ZW5kb3JfaWQnLCBsYWJlbDogJ1Byb3ZlZWRvciBBc29jaWFkbycsIHR5cGU6ICdyZWxhdGlvbmFsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGF0aW9uYWxDb25maWc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVDb25maWc6IHByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ3ZlbmRvcl9uYW1lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlRmllbGQ6ICd2ZW5kb3JfY29kZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChpdGVtKSA9PiBpdGVtLnZlbmRvcl9uYW1lIHx8ICdOL0EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZVdoZW46IChmb3JtRGF0YSkgPT4gZm9ybURhdGEubW92ZW1lbnRfY29kZSAhPT0gJ0YnXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIC8veyBuYW1lOiAndm91Y2hlcicsIGxhYmVsOiAnQ29tcHJvYmFudGUnLCB0eXBlOiAndGV4dCcsIHBsYWNlaG9sZGVyOiAnRWo6IEZBQy1BLTAwMDEtMTIzNDUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2RlbGl2ZXJ5X25vdGUnLCBsYWJlbDogJ1JlbWl0bycsIHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdyZWZlcmVuY2UnLCBsYWJlbDogJ1JlZmVyZW5jaWEnLCB0eXBlOiAndGV4dGFyZWEnLCBwbGFjZWhvbGRlcjogJ0N1YWxxdWllciBvYnNlcnZhY2nDs24gYWRpY2lvbmFsLi4uJyB9LFxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL21vdl9zdG9jay9tb3ZTdG9jay5jb25maWcudHN4In0=