import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { AccountMovementsTab } from "/src/components/common/AccountMovementsTab.tsx";
export function ClienteCuentaCorrienteModal({ isOpen, onClose, clientId }) {
  _s();
  const resolvedClientId = useMemo(
    () => clientId != null && clientId > 0 ? clientId : null,
    [clientId]
  );
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black bg-opacity-50",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "cliente-cuenta-corriente-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-6 py-4 border-b border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { id: "cliente-cuenta-corriente-modal-title", className: "text-lg font-medium text-gray-900", children: "Cuenta Corriente" }, void 0, false, {
                fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
                lineNumber: 49,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  className: "px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50",
                  children: "Cerrar"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
                  lineNumber: 52,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
              lineNumber: 48,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-y-auto flex-1", children: resolvedClientId ? /* @__PURE__ */ jsxDEV(
              AccountMovementsTab,
              {
                entityId: resolvedClientId,
                endpoint: "customer-accounts",
                dateInputIdPrefix: "aut-ped-cta-cte"
              },
              resolvedClientId,
              false,
              {
                fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
                lineNumber: 62,
                columnNumber: 11
              },
              this
            ) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Este pedido no tiene un cliente asociado." }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
              lineNumber: 69,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
              lineNumber: 60,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
          lineNumber: 44,
          columnNumber: 13
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx",
      lineNumber: 38,
      columnNumber: 5
    },
    this
  );
}
_s(ClienteCuentaCorrienteModal, "FKs8jMlfE26hWM04TJ2ACLhxAMc=");
_c = ClienteCuentaCorrienteModal;
var _c;
$RefreshReg$(_c, "ClienteCuentaCorrienteModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3QnBCLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsMkJBQTJCO0FBUTdCLGdCQUFTQyw0QkFBNEIsRUFBRUMsUUFBUUMsU0FBU0MsU0FBMkMsR0FBRztBQUFBQyxLQUFBO0FBQ3pHLFFBQU1DLG1CQUFtQlA7QUFBQUEsSUFDckIsTUFBT0ssWUFBWSxRQUFRQSxXQUFXLElBQUlBLFdBQVc7QUFBQSxJQUNyRCxDQUFDQSxRQUFRO0FBQUEsRUFDYjtBQUVBLE1BQUksQ0FBQ0YsT0FBUSxRQUFPO0FBRXBCLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFdBQVU7QUFBQSxNQUNWLE1BQUs7QUFBQSxNQUNMLGNBQVc7QUFBQSxNQUNYLG1CQUFnQjtBQUFBLE1BRWhCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxXQUFVO0FBQUEsVUFDVixTQUFTLENBQUFLLE1BQUtBLEVBQUVDLGdCQUFnQjtBQUFBLFVBRWhDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdFQUNYO0FBQUEscUNBQUMsUUFBRyxJQUFHLHdDQUF1QyxXQUFVLHFDQUFtQyxnQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVNMO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFBMkc7QUFBQTtBQUFBLGdCQUh6SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDVkcsNkJBQ0c7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFRyxVQUFVQTtBQUFBQSxnQkFDVixVQUFTO0FBQUEsZ0JBQ1QsbUJBQWtCO0FBQUE7QUFBQSxjQUhiQTtBQUFBQSxjQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJdUMsSUFHdkMsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix5REFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEUsS0FUdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBO0FBQUE7QUFBQSxRQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE0QkE7QUFBQTtBQUFBLElBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DQTtBQUVSO0FBQUNELEdBOUNlSiw2QkFBMkI7QUFBQVEsS0FBM0JSO0FBQTJCLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwiQWNjb3VudE1vdmVtZW50c1RhYiIsIkNsaWVudGVDdWVudGFDb3JyaWVudGVNb2RhbCIsImlzT3BlbiIsIm9uQ2xvc2UiLCJjbGllbnRJZCIsIl9zIiwicmVzb2x2ZWRDbGllbnRJZCIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDbGllbnRlQ3VlbnRhQ29ycmllbnRlTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBY2NvdW50TW92ZW1lbnRzVGFiIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vQWNjb3VudE1vdmVtZW50c1RhYic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2xpZW50ZUN1ZW50YUNvcnJpZW50ZU1vZGFsUHJvcHMge1xuICAgIGlzT3BlbjogYm9vbGVhbjtcbiAgICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAgIGNsaWVudElkOiBudW1iZXIgfCBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2xpZW50ZUN1ZW50YUNvcnJpZW50ZU1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCBjbGllbnRJZCB9OiBDbGllbnRlQ3VlbnRhQ29ycmllbnRlTW9kYWxQcm9wcykge1xuICAgIGNvbnN0IHJlc29sdmVkQ2xpZW50SWQgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiAoY2xpZW50SWQgIT0gbnVsbCAmJiBjbGllbnRJZCA+IDAgPyBjbGllbnRJZCA6IG51bGwpLFxuICAgICAgICBbY2xpZW50SWRdXG4gICAgKTtcblxuICAgIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2sgYmctb3BhY2l0eS01MFwiXG4gICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cImNsaWVudGUtY3VlbnRhLWNvcnJpZW50ZS1tb2RhbC10aXRsZVwiXG4gICAgICAgID5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy14bCB3LWZ1bGwgbWF4LXctNXhsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbFwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17ZSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTYgcHktNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGlkPVwiY2xpZW50ZS1jdWVudGEtY29ycmllbnRlLW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDdWVudGEgQ29ycmllbnRlXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBvdmVyZmxvdy15LWF1dG8gZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXNvbHZlZENsaWVudElkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEFjY291bnRNb3ZlbWVudHNUYWJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3Jlc29sdmVkQ2xpZW50SWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5SWQ9e3Jlc29sdmVkQ2xpZW50SWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ9XCJjdXN0b21lci1hY2NvdW50c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZUlucHV0SWRQcmVmaXg9XCJhdXQtcGVkLWN0YS1jdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkVzdGUgcGVkaWRvIG5vIHRpZW5lIHVuIGNsaWVudGUgYXNvY2lhZG8uPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2F1dG9yaXphY2lvbl9wZWRpZG9zL2NvbXBvbmVudHMvQ2xpZW50ZUN1ZW50YUNvcnJpZW50ZU1vZGFsLnRzeCJ9