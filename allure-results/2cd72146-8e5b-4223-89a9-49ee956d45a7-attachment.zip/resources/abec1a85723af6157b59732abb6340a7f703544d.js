import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/lista_precios/pages/ListasPreciosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/lista_precios/pages/ListasPreciosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { priceListsModuleConfig } from "/src/features/lista_precios/listas_precios.config.tsx";
export const ListasDePreciosListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    // <-- Nombre devuelto por el hook
    handleSort,
    // <-- Nombre devuelto por el hook
    sortBy,
    sortDirection,
    handlePageChange,
    // <-- Nombre devuelto por el hook
    handleLoadMore,
    // <-- Nombre devuelto por el hook
    handleSearch,
    // <-- Nombre devuelto por el hook
    searchParams
    // <-- Objeto devuelto por el hook
  } = useCrud(priceListsModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/lista_precios/pages/ListasPreciosListPage.tsx",
    lineNumber: 43,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: priceListsModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/lista_precios/pages/ListasPreciosListPage.tsx",
      lineNumber: 47,
      columnNumber: 5
    },
    this
  );
};
_s(ListasDePreciosListPage, "U8S05Ww1by7fDJyEIURrRuVrACU=", false, function() {
  return [useCrud];
});
_c = ListasDePreciosListPage;
var _c;
$RefreshReg$(_c, "ListasDePreciosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/lista_precios/pages/ListasPreciosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/lista_precios/pages/ListasPreciosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyw4QkFBOEM7QUFFaEQsYUFBTUMsMEJBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFFekMsUUFBTTtBQUFBLElBQ0ZDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLElBQ0FDO0FBQUFBO0FBQUFBLEVBQ0osSUFBSWhCLFFBQW1CRSx3QkFBd0JELHdCQUF3QixDQUFDO0FBRXhFLE1BQUlPLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUd2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRTjtBQUFBQSxNQUNSLG9CQUFvQkc7QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhQyxRQUFRO0FBQUEsTUFDakMsaUJBQWlCRCxhQUFhRSxhQUFhO0FBQUEsTUFDM0MsZUFBZUYsYUFBYUcsV0FBVztBQUFBLE1BRXZDLHVCQUF1QjtBQUFBO0FBQUEsSUFoQjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdCZ0M7QUFHeEM7QUFBRWYsR0F4Q1dELHlCQUF1QjtBQUFBLFVBZTVCSCxPQUFPO0FBQUE7QUFBQW9CLEtBZkZqQjtBQUF1QixJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkdlbmVyaWNMaXN0UGFnZSIsInVzZUNydWQiLCJnZXREZWZhdWx0TGlzdERhdGVSYW5nZSIsInByaWNlTGlzdHNNb2R1bGVDb25maWciLCJMaXN0YXNEZVByZWNpb3NMaXN0UGFnZSIsIl9zIiwicmVzcG9uc2UiLCJsb2FkaW5nIiwiaXNBcHBlbmRpbmciLCJlcnJvciIsImRlbGV0ZUl0ZW0iLCJoYW5kbGVTb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVMb2FkTW9yZSIsImhhbmRsZVNlYXJjaCIsInNlYXJjaFBhcmFtcyIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGlzdGFzUHJlY2lvc0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvbW9kdWxlcy9saXN0YXNfZGVfcHJlY2lvcy9wYWdlcy9MaXN0YXNEZVByZWNpb3NMaXN0UGFnZS50c3hcbmltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuaW1wb3J0IHsgcHJpY2VMaXN0c01vZHVsZUNvbmZpZywgdHlwZSBQcmljZUxpc3QgfSBmcm9tICcuLi9saXN0YXNfcHJlY2lvcy5jb25maWcnO1xuXG5leHBvcnQgY29uc3QgTGlzdGFzRGVQcmVjaW9zTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgLy8gRXh0cmFlbW9zIHRvZGFzIGxhcyBwcm9waWVkYWRlcyBkZWwgaG9vayB1c2VDcnVkXG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLCAvLyA8LS0gTm9tYnJlIGRldnVlbHRvIHBvciBlbCBob29rXG4gICAgICAgIGhhbmRsZVNvcnQsIC8vIDwtLSBOb21icmUgZGV2dWVsdG8gcG9yIGVsIGhvb2tcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLCAvLyA8LS0gTm9tYnJlIGRldnVlbHRvIHBvciBlbCBob29rXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLCAvLyA8LS0gTm9tYnJlIGRldnVlbHRvIHBvciBlbCBob29rXG4gICAgICAgIGhhbmRsZVNlYXJjaCwgLy8gPC0tIE5vbWJyZSBkZXZ1ZWx0byBwb3IgZWwgaG9va1xuICAgICAgICBzZWFyY2hQYXJhbXMsIC8vIDwtLSBPYmpldG8gZGV2dWVsdG8gcG9yIGVsIGhvb2tcbiAgICB9ID0gdXNlQ3J1ZDxQcmljZUxpc3Q+KHByaWNlTGlzdHNNb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgLy8gTWFwZWFtb3MgZXhwbMOtY2l0YW1lbnRlIGxhcyBwcm9waWVkYWRlcyBhIGxhcyBwcm9wcyBkZSBHZW5lcmljTGlzdFBhZ2VcbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPFByaWNlTGlzdD5cbiAgICAgICAgICAgIGNvbmZpZz17cHJpY2VMaXN0c01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9IC8vIHJlc3BvbnNlIC0+IHBhZ2luYXRpb25SZXNwb25zZVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfSAvLyBkZWxldGVJdGVtIC0+IG9uRGVsZXRlXG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9IC8vIGhhbmRsZVNvcnQgLT4gb25Tb3J0XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9IC8vIGhhbmRsZVBhZ2VDaGFuZ2UgLT4gb25QYWdlQ2hhbmdlXG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX0gLy8gaGFuZGxlTG9hZE1vcmUgLT4gb25Mb2FkTW9yZVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH0gLy8gaGFuZGxlU2VhcmNoIC0+IG9uU2VhcmNoXG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJTdGFydD17c2VhcmNoUGFyYW1zLnN0YXJ0RGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGRhdGVGaWx0ZXJFbmQ9e3NlYXJjaFBhcmFtcy5lbmREYXRlID8/ICcnfVxuICAgICAgICAgICAgLy8gT3BjaW9uYWw6IEhhYmlsaXRhciBmaWx0cm8gZGUgZmVjaGEgc2kgbG8gbmVjZXNpdGFzIHBhcmEgbGlzdGFzIGRlIHByZWNpb3NcbiAgICAgICAgICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlcj17dHJ1ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2xpc3RhX3ByZWNpb3MvcGFnZXMvTGlzdGFzUHJlY2lvc0xpc3RQYWdlLnRzeCJ9