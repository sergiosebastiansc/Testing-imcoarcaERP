import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/clientes/pages/ClientesCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/clientes/pages/ClientesCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ClientesFormPage } from "/src/features/clientes/pages/ClientesFormPage.tsx";
import {} from "/src/features/clientes/clientes.config.tsx";
const getTodayDate = () => (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
const initialClientValues = {
  name: "",
  cuit: "",
  email: "",
  phone: "",
  whatsapp: "",
  estado: "Activo",
  startdate: getTodayDate(),
  relatedTaxes: [],
  taxes: [],
  collection_contact: "",
  collection_email: "",
  collection_phone: "",
  collection_portal_url: "",
  collection_portal_username: "",
  collection_portal_password: "",
  cbu: null,
  zone: null,
  zone_name: null
};
export const ClienteCreatePage = () => {
  return /* @__PURE__ */ jsxDEV(
    ClientesFormPage,
    {
      mode: "create",
      initialData: initialClientValues
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/clientes/pages/ClientesCreatePage.tsx",
      lineNumber: 48,
      columnNumber: 5
    },
    this
  );
};
_c = ClienteCreatePage;
var _c;
$RefreshReg$(_c, "ClienteCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/clientes/pages/ClientesCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/clientes/pages/ClientesCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJROzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJSLFNBQVNBLHdCQUF3QjtBQUNqQyxlQUE2QjtBQUU3QixNQUFNQyxlQUFlQSxPQUFNLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUVoRSxNQUFNQyxzQkFBd0M7QUFBQSxFQUMxQ0MsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxRQUFRO0FBQUEsRUFDUkMsV0FBV1gsYUFBYTtBQUFBLEVBQ3hCWSxjQUFjO0FBQUEsRUFDZEMsT0FBTztBQUFBLEVBQ1BDLG9CQUFvQjtBQUFBLEVBQ3BCQyxrQkFBa0I7QUFBQSxFQUNsQkMsa0JBQWtCO0FBQUEsRUFDbEJDLHVCQUF1QjtBQUFBLEVBQ3ZCQyw0QkFBNEI7QUFBQSxFQUM1QkMsNEJBQTRCO0FBQUEsRUFDNUJDLEtBQUs7QUFBQSxFQUNMQyxNQUFNO0FBQUEsRUFDTkMsV0FBVztBQUNmO0FBRU8sYUFBTUMsb0JBQW9CQSxNQUFNO0FBQ25DLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLE1BQUs7QUFBQSxNQUNMLGFBQWFuQjtBQUFBQTtBQUFBQSxJQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFFZ0Q7QUFHeEQ7QUFBRW9CLEtBUFdEO0FBQWlCLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDbGllbnRlc0Zvcm1QYWdlIiwiZ2V0VG9kYXlEYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJpbml0aWFsQ2xpZW50VmFsdWVzIiwibmFtZSIsImN1aXQiLCJlbWFpbCIsInBob25lIiwid2hhdHNhcHAiLCJlc3RhZG8iLCJzdGFydGRhdGUiLCJyZWxhdGVkVGF4ZXMiLCJ0YXhlcyIsImNvbGxlY3Rpb25fY29udGFjdCIsImNvbGxlY3Rpb25fZW1haWwiLCJjb2xsZWN0aW9uX3Bob25lIiwiY29sbGVjdGlvbl9wb3J0YWxfdXJsIiwiY29sbGVjdGlvbl9wb3J0YWxfdXNlcm5hbWUiLCJjb2xsZWN0aW9uX3BvcnRhbF9wYXNzd29yZCIsImNidSIsInpvbmUiLCJ6b25lX25hbWUiLCJDbGllbnRlQ3JlYXRlUGFnZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudGVzQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xpZW50ZXNGb3JtUGFnZSB9IGZyb20gJy4vQ2xpZW50ZXNGb3JtUGFnZS50c3gnO1xuaW1wb3J0IHsgdHlwZSBDbGllbnRlIH0gZnJvbSAnLi4vY2xpZW50ZXMuY29uZmlnJztcblxuY29uc3QgZ2V0VG9kYXlEYXRlID0gKCkgPT4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF07XG4vLyBWYWxvcmVzIGluaWNpYWxlcyBwYXJhIHVuIGNsaWVudGUgbnVldm8geSB2YWPDrW8uXG5jb25zdCBpbml0aWFsQ2xpZW50VmFsdWVzOiBQYXJ0aWFsPENsaWVudGU+ID0ge1xuICAgIG5hbWU6ICcnLFxuICAgIGN1aXQ6ICcnLFxuICAgIGVtYWlsOiAnJyxcbiAgICBwaG9uZTogJycsXG4gICAgd2hhdHNhcHA6ICcnLFxuICAgIGVzdGFkbzogJ0FjdGl2bycsXG4gICAgc3RhcnRkYXRlOiBnZXRUb2RheURhdGUoKSxcbiAgICByZWxhdGVkVGF4ZXM6IFtdLFxuICAgIHRheGVzOiBbXSxcbiAgICBjb2xsZWN0aW9uX2NvbnRhY3Q6ICcnLFxuICAgIGNvbGxlY3Rpb25fZW1haWw6ICcnLFxuICAgIGNvbGxlY3Rpb25fcGhvbmU6ICcnLFxuICAgIGNvbGxlY3Rpb25fcG9ydGFsX3VybDogJycsXG4gICAgY29sbGVjdGlvbl9wb3J0YWxfdXNlcm5hbWU6ICcnLFxuICAgIGNvbGxlY3Rpb25fcG9ydGFsX3Bhc3N3b3JkOiAnJyxcbiAgICBjYnU6IG51bGwsXG4gICAgem9uZTogbnVsbCxcbiAgICB6b25lX25hbWU6IG51bGwsXG59O1xuXG5leHBvcnQgY29uc3QgQ2xpZW50ZUNyZWF0ZVBhZ2UgPSAoKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPENsaWVudGVzRm9ybVBhZ2VcbiAgICAgICAgICAgIG1vZGU9XCJjcmVhdGVcIlxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2luaXRpYWxDbGllbnRWYWx1ZXMgYXMgQ2xpZW50ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NsaWVudGVzL3BhZ2VzL0NsaWVudGVzQ3JlYXRlUGFnZS50c3gifQ==