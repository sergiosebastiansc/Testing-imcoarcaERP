import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/CashStatementTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/CashStatementTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { search, getFileBlobWithMeta } from "/src/services/apiService.ts";
import { downloadBlob } from "/src/utils/blobHelper.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { FaFilter } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
const ENDPOINT = "cashes/statement";
function getMotivoLabel(sourceType, sign) {
  if (!sourceType) return "Movimiento Caja";
  if (sourceType.includes("Collection")) return "Recibo";
  if (sourceType.includes("PaymentOrder")) return "Orden de Pago";
  if (sourceType.includes("BankMovement")) return sign === "S" ? "Retiro" : "Depósito";
  return sourceType;
}
function getValueTypeLabel(valueType, sourceType) {
  if (!valueType) return "";
  switch (valueType) {
    case "E":
      return "Efectivo";
    case "H":
      if (sourceType?.includes("Collection")) return "Cheque recibido";
      if (sourceType?.includes("PaymentOrder")) return "Cheque entregado";
      return "Cheque";
    case "T":
      return "Transferencia";
    default:
      return valueType;
  }
}
function getMotivoLink(sourceType, sourceId) {
  if (sourceId == null || !sourceType) return null;
  if (sourceType.includes("Collection")) return `/cobranzas/${sourceId}`;
  if (sourceType.includes("PaymentOrder")) return `/ordenes-de-pago/${sourceId}`;
  if (sourceType.includes("BankMovement")) return `/movimientos-bancos/${sourceId}`;
  return null;
}
function getMotivoText(mov) {
  if (mov.source_type?.includes("BankMovement")) {
    const tipo = getMotivoLabel(mov.source_type, mov.sign);
    const valueTypeLabel = getValueTypeLabel(mov.value_type, mov.source_type);
    const tipoConValor = valueTypeLabel ? `${tipo} (${valueTypeLabel})` : tipo;
    const part2 = mov.bank_name ? `${tipoConValor} - ${mov.bank_name}` : tipoConValor;
    return part2.trim() || "—";
  }
  const label = getMotivoLabel(mov.source_type, mov.sign);
  const name = mov.source_type?.includes("Collection") ? mov.client_name : mov.source_type?.includes("PaymentOrder") ? mov.vendor_name : null;
  const part = [label, name].filter(Boolean).join(" ");
  return part.trim() || "—";
}
function createDefaultDateRange() {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
  return { from: oneMonthAgo, to: today };
}
export const CashStatementTab = () => {
  _s();
  const [movements, setMovements] = useState([]);
  const [initialBalance, setInitialBalance] = useState(null);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [draftRange, setDraftRange] = useState(() => createDefaultDateRange());
  const [appliedRange, setAppliedRange] = useState(() => createDefaultDateRange());
  const appliedRangeRef = useRef(appliedRange);
  appliedRangeRef.current = appliedRange;
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const fetchMovements = useCallback(async (pageUrl, range) => {
    setLoading(true);
    try {
      let url;
      if (pageUrl) {
        if (pageUrl.startsWith("http")) {
          const urlObj = new URL(pageUrl);
          url = urlObj.pathname.replace(/^\/api\//, "") + urlObj.search;
        } else {
          url = pageUrl;
        }
      } else {
        const r = range ?? appliedRangeRef.current;
        const params = new URLSearchParams();
        params.set("start_date", r.from);
        params.set("end_date", r.to);
        url = `${ENDPOINT}?${params.toString()}`;
      }
      const response = await search(url);
      setInitialBalance(response.initial_balance);
      setMovements(response.statement.data);
      setPaginationMeta(response.statement);
    } catch (error) {
      toast.error("Error al cargar el estado de cuenta de caja.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void fetchMovements(void 0, appliedRangeRef.current);
  }, [fetchMovements]);
  const applyFilters = () => {
    if (draftRange.from === appliedRange.from && draftRange.to === appliedRange.to) {
      return;
    }
    setAppliedRange(draftRange);
    void fetchMovements(void 0, draftRange);
  };
  const handleDateBlur = (e) => {
    const next = e.relatedTarget;
    if (next && next.type === "submit") {
      return;
    }
    applyFilters();
  };
  const handlePageChange = (url) => {
    fetchMovements(url);
  };
  const handleFilterSubmit = (e) => {
    e.preventDefault();
    applyFilters();
  };
  const handleGenerateReport = async () => {
    setIsGeneratingReport(true);
    try {
      const endpoint = `cashes/consolidated-report/pdf?startDate=${appliedRange.from}&endDate=${appliedRange.to}`;
      const { blob, filename } = await getFileBlobWithMeta(endpoint);
      const fallbackName = `reporte-caja-consolidado-${appliedRange.from}-${appliedRange.to}.pdf`;
      downloadBlob(blob, filename === "documento.pdf" ? fallbackName : filename);
      toast.success("Reporte generado.");
    } catch (error) {
      console.error("Error al generar reporte:", error);
      toast.error("Error al generar el reporte.");
    } finally {
      setIsGeneratingReport(false);
    }
  };
  const columns = [
    { key: "id", label: "ID" },
    { key: "transaction_date", label: "Fecha" },
    { key: "value_type", label: "Tipo Valor" },
    { key: "document_number", label: "Nº Documento" },
    { key: "motivo", label: "Motivo" },
    { key: "debit", label: "Debe" },
    { key: "credit", label: "Haber" },
    { key: "balance", label: "Saldo" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleFilterSubmit, autoComplete: "off", className: "flex items-end gap-4 mb-4 p-4 bg-gray-50 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_from", className: "block text-sm font-medium text-gray-700", children: "Desde" }, void 0, false, {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 239,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_from",
            value: draftRange.from,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, from: e.target.value })),
            onBlur: handleDateBlur,
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/CashStatementTab.tsx",
            lineNumber: 240,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/CashStatementTab.tsx",
        lineNumber: 238,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_to", className: "block text-sm font-medium text-gray-700", children: "Hasta" }, void 0, false, {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 249,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_to",
            value: draftRange.to,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, to: e.target.value })),
            onBlur: handleDateBlur,
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/CashStatementTab.tsx",
            lineNumber: 250,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/CashStatementTab.tsx",
        lineNumber: 248,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(FaFilter, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/components/common/CashStatementTab.tsx",
              lineNumber: 262,
              columnNumber: 21
            }, this),
            " Filtrar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 258,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleGenerateReport,
          disabled: isGeneratingReport,
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed",
          children: isGeneratingReport ? "Generando…" : "Generar Reporte"
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 264,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/CashStatementTab.tsx",
      lineNumber: 237,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/CashStatementTab.tsx",
      lineNumber: 275,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: columns.map(
          (col) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: `py-3.5 px-3 text-left text-sm font-semibold text-gray-900 ${["debit", "credit", "balance"].includes(col.key) ? "text-right" : ""}`, children: col.label }, col.key, false, {
            fileName: "/app/src/components/common/CashStatementTab.tsx",
            lineNumber: 283,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 281,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 280,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
          initialBalance !== null && /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-50 font-medium", children: [
            /* @__PURE__ */ jsxDEV("td", { colSpan: columns.length - 1, className: "py-3 pl-4 pr-3 text-sm font-semibold text-gray-900 sm:pl-6", children: [
              "SALDO ANTERIOR (al ",
              formatValue(appliedRange.from, "date"),
              ")"
            ] }, void 0, true, {
              fileName: "/app/src/components/common/CashStatementTab.tsx",
              lineNumber: 292,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm text-right font-semibold text-gray-900", children: formatValue(initialBalance, "currency") }, void 0, false, {
              fileName: "/app/src/components/common/CashStatementTab.tsx",
              lineNumber: 295,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/CashStatementTab.tsx",
            lineNumber: 291,
            columnNumber: 15
          }, this),
          movements.map((mov, index) => {
            const motivoPath = getMotivoLink(mov.source_type, mov.source_id);
            const motivoText = getMotivoText(mov);
            return /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(Link, { to: `/cajas/${mov.id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: mov.id }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 307,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 306,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: formatValue(mov.transaction_date, "date") }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 311,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: getValueTypeLabel(mov.value_type, mov.source_type) }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 312,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: mov.document_number ?? (mov.internal_number != null ? String(mov.internal_number) : "—") }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 313,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: motivoPath ? /* @__PURE__ */ jsxDEV(Link, { to: motivoPath, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: motivoText }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 318,
                columnNumber: 23
              }, this) : motivoText }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 316,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.debit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 325,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.credit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 326,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-semibold", children: formatValue(mov.balance, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/CashStatementTab.tsx",
                lineNumber: 327,
                columnNumber: 45
              }, this)
            ] }, `${mov.id}-${mov.document_type}-${index}`, true, {
              fileName: "/app/src/components/common/CashStatementTab.tsx",
              lineNumber: 305,
              columnNumber: 19
            }, this);
          })
        ] }, void 0, true, {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 289,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/CashStatementTab.tsx",
        lineNumber: 279,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/CashStatementTab.tsx",
        lineNumber: 278,
        columnNumber: 21
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          meta: paginationMeta,
          onPageChange: handlePageChange
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/CashStatementTab.tsx",
          lineNumber: 335,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/CashStatementTab.tsx",
      lineNumber: 277,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/CashStatementTab.tsx",
    lineNumber: 236,
    columnNumber: 5
  }, this);
};
_s(CashStatementTab, "BcDTrTfuH1OhiREGo2uubAdJ7yc=");
_c = CashStatementTab;
var _c;
$RefreshReg$(_c, "CashStatementTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/CashStatementTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/CashStatementTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMk5vQixTQXNDSixVQXRDSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExTnBCLFNBQVNBLFVBQVVDLFdBQVdDLGFBQWFDLGNBQWM7QUFDekQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFFBQVFDLDJCQUEyQjtBQUM1QyxTQUFTQyxvQkFBb0I7QUFFN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBZ0R6QixNQUFNQyxXQUFXO0FBRWpCLFNBQVNDLGVBQWVDLFlBQXVDQyxNQUEwQjtBQUNyRixNQUFJLENBQUNELFdBQVksUUFBTztBQUN4QixNQUFJQSxXQUFXRSxTQUFTLFlBQVksRUFBRyxRQUFPO0FBQzlDLE1BQUlGLFdBQVdFLFNBQVMsY0FBYyxFQUFHLFFBQU87QUFDaEQsTUFBSUYsV0FBV0UsU0FBUyxjQUFjLEVBQUcsUUFBT0QsU0FBUyxNQUFNLFdBQVc7QUFDMUUsU0FBT0Q7QUFDWDtBQUVBLFNBQVNHLGtCQUFrQkMsV0FBc0NKLFlBQWdEO0FBQzdHLE1BQUksQ0FBQ0ksVUFBVyxRQUFPO0FBQ3ZCLFVBQVFBLFdBQVM7QUFBQSxJQUNiLEtBQUs7QUFBSyxhQUFPO0FBQUEsSUFDakIsS0FBSztBQUNELFVBQUlKLFlBQVlFLFNBQVMsWUFBWSxFQUFHLFFBQU87QUFDL0MsVUFBSUYsWUFBWUUsU0FBUyxjQUFjLEVBQUcsUUFBTztBQUNqRCxhQUFPO0FBQUEsSUFDWCxLQUFLO0FBQUssYUFBTztBQUFBLElBQ2pCO0FBQVMsYUFBT0U7QUFBQUEsRUFDcEI7QUFDSjtBQUVBLFNBQVNDLGNBQWNMLFlBQXVDTSxVQUFvRDtBQUM5RyxNQUFJQSxZQUFZLFFBQVEsQ0FBQ04sV0FBWSxRQUFPO0FBQzVDLE1BQUlBLFdBQVdFLFNBQVMsWUFBWSxFQUFHLFFBQU8sY0FBY0ksUUFBUTtBQUNwRSxNQUFJTixXQUFXRSxTQUFTLGNBQWMsRUFBRyxRQUFPLG9CQUFvQkksUUFBUTtBQUM1RSxNQUFJTixXQUFXRSxTQUFTLGNBQWMsRUFBRyxRQUFPLHVCQUF1QkksUUFBUTtBQUMvRSxTQUFPO0FBQ1g7QUFFQSxTQUFTQyxjQUFjQyxLQUF1QztBQUMxRCxNQUFJQSxJQUFJQyxhQUFhUCxTQUFTLGNBQWMsR0FBRztBQUMzQyxVQUFNUSxPQUFPWCxlQUFlUyxJQUFJQyxhQUFhRCxJQUFJUCxJQUFJO0FBQ3JELFVBQU1VLGlCQUFpQlIsa0JBQWtCSyxJQUFJSSxZQUFZSixJQUFJQyxXQUFXO0FBQ3hFLFVBQU1JLGVBQWVGLGlCQUFpQixHQUFHRCxJQUFJLEtBQUtDLGNBQWMsTUFBTUQ7QUFDdEUsVUFBTUksUUFBT04sSUFBSU8sWUFBWSxHQUFHRixZQUFZLE1BQU1MLElBQUlPLFNBQVMsS0FBS0Y7QUFDcEUsV0FBT0MsTUFBS0UsS0FBSyxLQUFLO0FBQUEsRUFDMUI7QUFDQSxRQUFNQyxRQUFRbEIsZUFBZVMsSUFBSUMsYUFBYUQsSUFBSVAsSUFBSTtBQUN0RCxRQUFNaUIsT0FBT1YsSUFBSUMsYUFBYVAsU0FBUyxZQUFZLElBQzdDTSxJQUFJVyxjQUNKWCxJQUFJQyxhQUFhUCxTQUFTLGNBQWMsSUFDcENNLElBQUlZLGNBQ0o7QUFDVixRQUFNTixPQUFPLENBQUNHLE9BQU9DLElBQUksRUFBRUcsT0FBT0MsT0FBTyxFQUFFQyxLQUFLLEdBQUc7QUFDbkQsU0FBT1QsS0FBS0UsS0FBSyxLQUFLO0FBQzFCO0FBRUEsU0FBU1EseUJBQXVEO0FBQzVELFFBQU1DLFNBQVEsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25ELFFBQU1DLGNBQWMsSUFBSUgsS0FBS0EsS0FBS0ksSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSSxFQUFFSCxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDOUYsU0FBTyxFQUFFRyxNQUFNRixhQUFhRyxJQUFJUCxNQUFNO0FBQzFDO0FBRU8sYUFBTVEsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUluRCxTQUFxQyxFQUFFO0FBQ3pFLFFBQU0sQ0FBQ29ELGdCQUFnQkMsaUJBQWlCLElBQUlyRCxTQUF3QixJQUFJO0FBQ3hFLFFBQU0sQ0FBQ3NELGdCQUFnQkMsaUJBQWlCLElBQUl2RCxTQUF3QyxJQUFJO0FBQ3hGLFFBQU0sQ0FBQ3dELFNBQVNDLFVBQVUsSUFBSXpELFNBQVMsS0FBSztBQUU1QyxRQUFNLENBQUMwRCxZQUFZQyxhQUFhLElBQUkzRCxTQUFTLE1BQU11Qyx1QkFBdUIsQ0FBQztBQUMzRSxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUk3RCxTQUFTLE1BQU11Qyx1QkFBdUIsQ0FBQztBQUMvRSxRQUFNdUIsa0JBQWtCM0QsT0FBT3lELFlBQVk7QUFDM0NFLGtCQUFnQkMsVUFBVUg7QUFFMUIsUUFBTSxDQUFDSSxvQkFBb0JDLHFCQUFxQixJQUFJakUsU0FBUyxLQUFLO0FBRWxFLFFBQU1rRSxpQkFBaUJoRSxZQUFZLE9BQU9pRSxTQUFrQkMsVUFBeUM7QUFDakdYLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDQSxVQUFJWTtBQUVKLFVBQUlGLFNBQVM7QUFDVCxZQUFJQSxRQUFRRyxXQUFXLE1BQU0sR0FBRztBQUM1QixnQkFBTUMsU0FBUyxJQUFJQyxJQUFJTCxPQUFPO0FBQzlCRSxnQkFBTUUsT0FBT0UsU0FBU0MsUUFBUSxZQUFZLEVBQUUsSUFBSUgsT0FBT2pFO0FBQUFBLFFBQzNELE9BQU87QUFDSCtELGdCQUFNRjtBQUFBQSxRQUNWO0FBQUEsTUFDSixPQUFPO0FBQ0gsY0FBTVEsSUFBSVAsU0FBU04sZ0JBQWdCQztBQUNuQyxjQUFNYSxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsZUFBT0UsSUFBSSxjQUFjSCxFQUFFN0IsSUFBSTtBQUMvQjhCLGVBQU9FLElBQUksWUFBWUgsRUFBRTVCLEVBQUU7QUFDM0JzQixjQUFNLEdBQUd4RCxRQUFRLElBQUkrRCxPQUFPRyxTQUFTLENBQUM7QUFBQSxNQUMxQztBQUVBLFlBQU1DLFdBQVcsTUFBTTFFLE9BQVkrRCxHQUFHO0FBRXRDaEIsd0JBQWtCMkIsU0FBU0MsZUFBZTtBQUMxQzlCLG1CQUFhNkIsU0FBU0UsVUFBVUMsSUFBSTtBQUNwQzVCLHdCQUFrQnlCLFNBQVNFLFNBQVM7QUFBQSxJQUN4QyxTQUFTRSxPQUFPO0FBQ1ovRSxZQUFNK0UsTUFBTSw4Q0FBOEM7QUFDMURDLGNBQVFELE1BQU1BLEtBQUs7QUFBQSxJQUN2QixVQUFDO0FBQ0czQixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKLEdBQUcsRUFBRTtBQUVMeEQsWUFBVSxNQUFNO0FBQ1osU0FBS2lFLGVBQWVvQixRQUFXeEIsZ0JBQWdCQyxPQUFPO0FBQUEsRUFDMUQsR0FBRyxDQUFDRyxjQUFjLENBQUM7QUFFbkIsUUFBTXFCLGVBQWVBLE1BQU07QUFDdkIsUUFBSTdCLFdBQVdaLFNBQVNjLGFBQWFkLFFBQVFZLFdBQVdYLE9BQU9hLGFBQWFiLElBQUk7QUFDNUU7QUFBQSxJQUNKO0FBQ0FjLG9CQUFnQkgsVUFBVTtBQUMxQixTQUFLUSxlQUFlb0IsUUFBVzVCLFVBQVU7QUFBQSxFQUM3QztBQUVBLFFBQU04QixpQkFBaUJBLENBQUNDLE1BQTBDO0FBQzlELFVBQU1DLE9BQU9ELEVBQUVFO0FBQ2YsUUFBSUQsUUFBU0EsS0FBMkJFLFNBQVMsVUFBVTtBQUN2RDtBQUFBLElBQ0o7QUFDQUwsaUJBQWE7QUFBQSxFQUNqQjtBQUVBLFFBQU1NLG1CQUFtQkEsQ0FBQ3hCLFFBQWdCO0FBQ3RDSCxtQkFBZUcsR0FBRztBQUFBLEVBQ3RCO0FBRUEsUUFBTXlCLHFCQUFxQkEsQ0FBQ0wsTUFBdUI7QUFDL0NBLE1BQUVNLGVBQWU7QUFDakJSLGlCQUFhO0FBQUEsRUFDakI7QUFFQSxRQUFNUyx1QkFBdUIsWUFBWTtBQUNyQy9CLDBCQUFzQixJQUFJO0FBQzFCLFFBQUk7QUFDQSxZQUFNZ0MsV0FBVyw0Q0FBNENyQyxhQUFhZCxJQUFJLFlBQVljLGFBQWFiLEVBQUU7QUFDekcsWUFBTSxFQUFFbUQsTUFBTUMsU0FBUyxJQUFJLE1BQU01RixvQkFBb0IwRixRQUFRO0FBQzdELFlBQU1HLGVBQWUsNEJBQTRCeEMsYUFBYWQsSUFBSSxJQUFJYyxhQUFhYixFQUFFO0FBQ3JGdkMsbUJBQWEwRixNQUFNQyxhQUFhLGtCQUFrQkMsZUFBZUQsUUFBUTtBQUN6RTlGLFlBQU1nRyxRQUFRLG1CQUFtQjtBQUFBLElBQ3JDLFNBQVNqQixPQUFPO0FBQ1pDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQ2hEL0UsWUFBTStFLE1BQU0sOEJBQThCO0FBQUEsSUFDOUMsVUFBQztBQUNHbkIsNEJBQXNCLEtBQUs7QUFBQSxJQUMvQjtBQUFBLEVBQ0o7QUFFQSxRQUFNcUMsVUFBVTtBQUFBLElBQ1osRUFBRUMsS0FBSyxNQUFNdkUsT0FBTyxLQUFLO0FBQUEsSUFDekIsRUFBRXVFLEtBQUssb0JBQW9CdkUsT0FBTyxRQUFRO0FBQUEsSUFDMUMsRUFBRXVFLEtBQUssY0FBY3ZFLE9BQU8sYUFBYTtBQUFBLElBQ3pDLEVBQUV1RSxLQUFLLG1CQUFtQnZFLE9BQU8sZUFBZTtBQUFBLElBQ2hELEVBQUV1RSxLQUFLLFVBQVV2RSxPQUFPLFNBQVM7QUFBQSxJQUNqQyxFQUFFdUUsS0FBSyxTQUFTdkUsT0FBTyxPQUFPO0FBQUEsSUFDOUIsRUFBRXVFLEtBQUssVUFBVXZFLE9BQU8sUUFBUTtBQUFBLElBQ2hDLEVBQUV1RSxLQUFLLFdBQVd2RSxPQUFPLFFBQVE7QUFBQSxFQUFDO0FBR3RDLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSwyQkFBQyxVQUFLLFVBQVU4RCxvQkFBb0IsY0FBYSxPQUFNLFdBQVUsOERBQzdEO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFdBQU0sU0FBUSxhQUFZLFdBQVUsMkNBQTBDLHFCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFDcEY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLElBQUc7QUFBQSxZQUNILE9BQU9wQyxXQUFXWjtBQUFBQSxZQUNsQixVQUFVLENBQUEyQyxNQUFLOUIsY0FBYyxDQUFBNkMsVUFBUyxFQUFFLEdBQUdBLE1BQU0xRCxNQUFNMkMsRUFBRWdCLE9BQU9DLE1BQU0sRUFBRTtBQUFBLFlBQ3hFLFFBQVFsQjtBQUFBQSxZQUNSLFdBQVU7QUFBQSxZQUFxRixjQUFhO0FBQUE7QUFBQSxVQU5oSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNcUg7QUFBQSxXQVJ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFNBQVEsV0FBVSxXQUFVLDJDQUEwQyxxQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFFBQ2xGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSCxPQUFPOUIsV0FBV1g7QUFBQUEsWUFDbEIsVUFBVSxDQUFBMEMsTUFBSzlCLGNBQWMsQ0FBQTZDLFVBQVMsRUFBRSxHQUFHQSxNQUFNekQsSUFBSTBDLEVBQUVnQixPQUFPQyxNQUFNLEVBQUU7QUFBQSxZQUN0RSxRQUFRbEI7QUFBQUEsWUFDUixXQUFVO0FBQUEsWUFBcUYsY0FBYTtBQUFBO0FBQUEsVUFOaEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXFIO0FBQUEsV0FSekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVNRO0FBQUFBLFVBQ1QsVUFBVWhDO0FBQUFBLFVBQ1YsV0FBVTtBQUFBLFVBRVRBLCtCQUFxQixlQUFlO0FBQUE7QUFBQSxRQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ0E7QUFBQSxJQUVDUixVQUNHLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxJQUVmLG1DQUNJO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0k4QyxrQkFBUUs7QUFBQUEsVUFBSSxDQUFBQyxRQUNULHVCQUFDLFFBQWlCLE9BQU0sT0FBTSxXQUFXLDZEQUE2RCxDQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUUzRixTQUFTMkYsSUFBSUwsR0FBRyxJQUFJLGVBQWUsRUFBRSxJQUNyS0ssY0FBSTVFLFNBREE0RSxJQUFJTCxLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUNILEtBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1puRDtBQUFBQSw2QkFBbUIsUUFDaEIsdUJBQUMsUUFBRyxXQUFVLDBCQUNWO0FBQUEsbUNBQUMsUUFBRyxTQUFTa0QsUUFBUU8sU0FBUyxHQUFHLFdBQVUsOERBQTREO0FBQUE7QUFBQSxjQUMvRXBHLFlBQVltRCxhQUFhZCxNQUFNLE1BQU07QUFBQSxjQUFFO0FBQUEsaUJBRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw0REFDVHJDLHNCQUFZMkMsZ0JBQWdCLFVBQVUsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBR0hGLFVBQVV5RCxJQUFJLENBQUNwRixLQUFLdUYsVUFBVTtBQUMzQixrQkFBTUMsYUFBYTNGLGNBQWNHLElBQUlDLGFBQWFELElBQUl5RixTQUFTO0FBQy9ELGtCQUFNQyxhQUFhM0YsY0FBY0MsR0FBRztBQUNwQyxtQkFDSSx1QkFBQyxRQUNHO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhDQUNWLGlDQUFDLFFBQUssSUFBSSxVQUFVQSxJQUFJMkYsRUFBRSxJQUFJLFdBQVUseURBQ25DM0YsY0FBSTJGLE1BRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEN6RyxzQkFBWWMsSUFBSTRGLGtCQUFrQixNQUFNLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNHO0FBQUEsY0FDdEcsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQmpHLDRCQUFrQkssSUFBSUksWUFBWUosSUFBSUMsV0FBVyxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRjtBQUFBLGNBQ3RGLHVCQUFDLFFBQUcsV0FBVSxxQkFDVEQsY0FBSTZGLG9CQUFvQjdGLElBQUk4RixtQkFBbUIsT0FBT0MsT0FBTy9GLElBQUk4RixlQUFlLElBQUksUUFEekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLHFCQUNUTix1QkFDRyx1QkFBQyxRQUFLLElBQUlBLFlBQVksV0FBVSx5REFDM0JFLHdCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsSUFFQUEsY0FOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDeEcsc0JBQVljLElBQUlnRyxPQUFPLFVBQVUsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRix1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDOUcsc0JBQVljLElBQUlpRyxRQUFRLFVBQVUsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUNsRix1QkFBQyxRQUFHLFdBQVUsOENBQThDL0csc0JBQVljLElBQUlrRyxTQUFTLFVBQVUsS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUc7QUFBQSxpQkF0QjVGLEdBQUdsRyxJQUFJMkYsRUFBRSxJQUFJM0YsSUFBSW1HLGFBQWEsSUFBSVosS0FBSyxJQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFVBRVIsQ0FBQztBQUFBLGFBekNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxXQXBESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcURBLEtBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REE7QUFBQSxNQUNDeEQsa0JBQ0c7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQU1BO0FBQUFBLFVBQ04sY0FBY3VDO0FBQUFBO0FBQUFBLFFBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQztBQUFBLFNBNUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0RBO0FBQUEsT0F4R1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBHQTtBQUVSO0FBQUU1QyxHQW5OV0Qsa0JBQWdCO0FBQUEyRSxLQUFoQjNFO0FBQWdCLElBQUEyRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsInVzZVJlZiIsIkxpbmsiLCJ0b2FzdCIsInNlYXJjaCIsImdldEZpbGVCbG9iV2l0aE1ldGEiLCJkb3dubG9hZEJsb2IiLCJmb3JtYXRWYWx1ZSIsIkxvYWRpbmdTcGlubmVyIiwiUGFnaW5hdGlvbiIsIkZhRmlsdGVyIiwiRU5EUE9JTlQiLCJnZXRNb3Rpdm9MYWJlbCIsInNvdXJjZVR5cGUiLCJzaWduIiwiaW5jbHVkZXMiLCJnZXRWYWx1ZVR5cGVMYWJlbCIsInZhbHVlVHlwZSIsImdldE1vdGl2b0xpbmsiLCJzb3VyY2VJZCIsImdldE1vdGl2b1RleHQiLCJtb3YiLCJzb3VyY2VfdHlwZSIsInRpcG8iLCJ2YWx1ZVR5cGVMYWJlbCIsInZhbHVlX3R5cGUiLCJ0aXBvQ29uVmFsb3IiLCJwYXJ0IiwiYmFua19uYW1lIiwidHJpbSIsImxhYmVsIiwibmFtZSIsImNsaWVudF9uYW1lIiwidmVuZG9yX25hbWUiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsImNyZWF0ZURlZmF1bHREYXRlUmFuZ2UiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwib25lTW9udGhBZ28iLCJub3ciLCJmcm9tIiwidG8iLCJDYXNoU3RhdGVtZW50VGFiIiwiX3MiLCJtb3ZlbWVudHMiLCJzZXRNb3ZlbWVudHMiLCJpbml0aWFsQmFsYW5jZSIsInNldEluaXRpYWxCYWxhbmNlIiwicGFnaW5hdGlvbk1ldGEiLCJzZXRQYWdpbmF0aW9uTWV0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZHJhZnRSYW5nZSIsInNldERyYWZ0UmFuZ2UiLCJhcHBsaWVkUmFuZ2UiLCJzZXRBcHBsaWVkUmFuZ2UiLCJhcHBsaWVkUmFuZ2VSZWYiLCJjdXJyZW50IiwiaXNHZW5lcmF0aW5nUmVwb3J0Iiwic2V0SXNHZW5lcmF0aW5nUmVwb3J0IiwiZmV0Y2hNb3ZlbWVudHMiLCJwYWdlVXJsIiwicmFuZ2UiLCJ1cmwiLCJzdGFydHNXaXRoIiwidXJsT2JqIiwiVVJMIiwicGF0aG5hbWUiLCJyZXBsYWNlIiwiciIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNldCIsInRvU3RyaW5nIiwicmVzcG9uc2UiLCJpbml0aWFsX2JhbGFuY2UiLCJzdGF0ZW1lbnQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwidW5kZWZpbmVkIiwiYXBwbHlGaWx0ZXJzIiwiaGFuZGxlRGF0ZUJsdXIiLCJlIiwibmV4dCIsInJlbGF0ZWRUYXJnZXQiLCJ0eXBlIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUZpbHRlclN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlR2VuZXJhdGVSZXBvcnQiLCJlbmRwb2ludCIsImJsb2IiLCJmaWxlbmFtZSIsImZhbGxiYWNrTmFtZSIsInN1Y2Nlc3MiLCJjb2x1bW5zIiwia2V5IiwicHJldiIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiY29sIiwibGVuZ3RoIiwiaW5kZXgiLCJtb3Rpdm9QYXRoIiwic291cmNlX2lkIiwibW90aXZvVGV4dCIsImlkIiwidHJhbnNhY3Rpb25fZGF0ZSIsImRvY3VtZW50X251bWJlciIsImludGVybmFsX251bWJlciIsIlN0cmluZyIsImRlYml0IiwiY3JlZGl0IiwiYmFsYW5jZSIsImRvY3VtZW50X3R5cGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXNoU3RhdGVtZW50VGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjaywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBzZWFyY2gsIGdldEZpbGVCbG9iV2l0aE1ldGEgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IGRvd25sb2FkQmxvYiB9IGZyb20gJy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHR5cGUgeyBQYWdpbmF0ZWRSZXNwb25zZSB9IGZyb20gJy4uLy4uL2ludGVyZmFjZXMvQXBpJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IFBhZ2luYXRpb24gfSBmcm9tICcuL1BhZ2luYXRpb24nO1xuaW1wb3J0IHsgRmFGaWx0ZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5cbmludGVyZmFjZSBQYWdpbmF0aW9uTGluayB7XG4gICAgdXJsOiBzdHJpbmcgfCBudWxsO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgYWN0aXZlOiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgQ2FzaFN0YXRlbWVudFRyYW5zYWN0aW9uIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIHRyYW5zYWN0aW9uX2RhdGU6IHN0cmluZztcbiAgICBkb2N1bWVudF90eXBlOiBzdHJpbmc7XG4gICAgZG9jdW1lbnRfbnVtYmVyOiBzdHJpbmcgfCBudWxsO1xuICAgIGludGVybmFsX251bWJlcj86IG51bWJlcjtcbiAgICBzaWduPzogJ0UnIHwgJ1MnO1xuICAgIHZhbHVlX3R5cGU/OiBzdHJpbmcgfCBudWxsO1xuICAgIGRlYml0OiBudW1iZXI7XG4gICAgY3JlZGl0OiBudW1iZXI7XG4gICAgYmFsYW5jZTogbnVtYmVyO1xuICAgIHNvdXJjZV90eXBlPzogc3RyaW5nIHwgbnVsbDtcbiAgICBzb3VyY2VfaWQ/OiBudW1iZXIgfCBudWxsO1xuICAgIGNsaWVudF9uYW1lPzogc3RyaW5nIHwgbnVsbDtcbiAgICB2ZW5kb3JfbmFtZT86IHN0cmluZyB8IG51bGw7XG4gICAgYmFua19uYW1lPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuaW50ZXJmYWNlIENhc2hTdGF0ZW1lbnRTdGF0ZW1lbnQge1xuICAgIGN1cnJlbnRfcGFnZTogbnVtYmVyO1xuICAgIGRhdGE6IENhc2hTdGF0ZW1lbnRUcmFuc2FjdGlvbltdO1xuICAgIGZpcnN0X3BhZ2VfdXJsOiBzdHJpbmc7XG4gICAgZnJvbTogbnVtYmVyO1xuICAgIGxhc3RfcGFnZTogbnVtYmVyO1xuICAgIGxhc3RfcGFnZV91cmw6IHN0cmluZztcbiAgICBsaW5rczogUGFnaW5hdGlvbkxpbmtbXTtcbiAgICBuZXh0X3BhZ2VfdXJsOiBzdHJpbmcgfCBudWxsO1xuICAgIHBhdGg6IHN0cmluZztcbiAgICBwZXJfcGFnZTogbnVtYmVyO1xuICAgIHByZXZfcGFnZV91cmw6IHN0cmluZyB8IG51bGw7XG4gICAgdG86IG51bWJlcjtcbiAgICB0b3RhbDogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgQ2FzaFN0YXRlbWVudFJlc3BvbnNlIHtcbiAgICBpbml0aWFsX2JhbGFuY2U6IG51bWJlcjtcbiAgICBzdGF0ZW1lbnQ6IENhc2hTdGF0ZW1lbnRTdGF0ZW1lbnQ7XG4gICAgZmlsdGVycz86IHsgc3RhcnRfZGF0ZT86IHN0cmluZzsgZW5kX2RhdGU/OiBzdHJpbmc7IHBlcl9wYWdlPzogc3RyaW5nIH07XG59XG5cbmNvbnN0IEVORFBPSU5UID0gJ2Nhc2hlcy9zdGF0ZW1lbnQnO1xuXG5mdW5jdGlvbiBnZXRNb3Rpdm9MYWJlbChzb3VyY2VUeXBlOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLCBzaWduPzogJ0UnIHwgJ1MnKTogc3RyaW5nIHtcbiAgICBpZiAoIXNvdXJjZVR5cGUpIHJldHVybiAnTW92aW1pZW50byBDYWphJztcbiAgICBpZiAoc291cmNlVHlwZS5pbmNsdWRlcygnQ29sbGVjdGlvbicpKSByZXR1cm4gJ1JlY2libyc7XG4gICAgaWYgKHNvdXJjZVR5cGUuaW5jbHVkZXMoJ1BheW1lbnRPcmRlcicpKSByZXR1cm4gJ09yZGVuIGRlIFBhZ28nO1xuICAgIGlmIChzb3VyY2VUeXBlLmluY2x1ZGVzKCdCYW5rTW92ZW1lbnQnKSkgcmV0dXJuIHNpZ24gPT09ICdTJyA/ICdSZXRpcm8nIDogJ0RlcMOzc2l0byc7XG4gICAgcmV0dXJuIHNvdXJjZVR5cGU7XG59XG5cbmZ1bmN0aW9uIGdldFZhbHVlVHlwZUxhYmVsKHZhbHVlVHlwZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCwgc291cmNlVHlwZT86IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICAgIGlmICghdmFsdWVUeXBlKSByZXR1cm4gJyc7XG4gICAgc3dpdGNoICh2YWx1ZVR5cGUpIHtcbiAgICAgICAgY2FzZSAnRSc6IHJldHVybiAnRWZlY3Rpdm8nO1xuICAgICAgICBjYXNlICdIJzpcbiAgICAgICAgICAgIGlmIChzb3VyY2VUeXBlPy5pbmNsdWRlcygnQ29sbGVjdGlvbicpKSByZXR1cm4gJ0NoZXF1ZSByZWNpYmlkbyc7XG4gICAgICAgICAgICBpZiAoc291cmNlVHlwZT8uaW5jbHVkZXMoJ1BheW1lbnRPcmRlcicpKSByZXR1cm4gJ0NoZXF1ZSBlbnRyZWdhZG8nO1xuICAgICAgICAgICAgcmV0dXJuICdDaGVxdWUnO1xuICAgICAgICBjYXNlICdUJzogcmV0dXJuICdUcmFuc2ZlcmVuY2lhJztcbiAgICAgICAgZGVmYXVsdDogcmV0dXJuIHZhbHVlVHlwZTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGdldE1vdGl2b0xpbmsoc291cmNlVHlwZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCwgc291cmNlSWQ6IG51bWJlciB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBpZiAoc291cmNlSWQgPT0gbnVsbCB8fCAhc291cmNlVHlwZSkgcmV0dXJuIG51bGw7XG4gICAgaWYgKHNvdXJjZVR5cGUuaW5jbHVkZXMoJ0NvbGxlY3Rpb24nKSkgcmV0dXJuIGAvY29icmFuemFzLyR7c291cmNlSWR9YDtcbiAgICBpZiAoc291cmNlVHlwZS5pbmNsdWRlcygnUGF5bWVudE9yZGVyJykpIHJldHVybiBgL29yZGVuZXMtZGUtcGFnby8ke3NvdXJjZUlkfWA7XG4gICAgaWYgKHNvdXJjZVR5cGUuaW5jbHVkZXMoJ0JhbmtNb3ZlbWVudCcpKSByZXR1cm4gYC9tb3ZpbWllbnRvcy1iYW5jb3MvJHtzb3VyY2VJZH1gO1xuICAgIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBnZXRNb3Rpdm9UZXh0KG1vdjogQ2FzaFN0YXRlbWVudFRyYW5zYWN0aW9uKTogc3RyaW5nIHtcbiAgICBpZiAobW92LnNvdXJjZV90eXBlPy5pbmNsdWRlcygnQmFua01vdmVtZW50JykpIHtcbiAgICAgICAgY29uc3QgdGlwbyA9IGdldE1vdGl2b0xhYmVsKG1vdi5zb3VyY2VfdHlwZSwgbW92LnNpZ24pO1xuICAgICAgICBjb25zdCB2YWx1ZVR5cGVMYWJlbCA9IGdldFZhbHVlVHlwZUxhYmVsKG1vdi52YWx1ZV90eXBlLCBtb3Yuc291cmNlX3R5cGUpO1xuICAgICAgICBjb25zdCB0aXBvQ29uVmFsb3IgPSB2YWx1ZVR5cGVMYWJlbCA/IGAke3RpcG99ICgke3ZhbHVlVHlwZUxhYmVsfSlgIDogdGlwbztcbiAgICAgICAgY29uc3QgcGFydCA9IG1vdi5iYW5rX25hbWUgPyBgJHt0aXBvQ29uVmFsb3J9IC0gJHttb3YuYmFua19uYW1lfWAgOiB0aXBvQ29uVmFsb3I7XG4gICAgICAgIHJldHVybiBwYXJ0LnRyaW0oKSB8fCAn4oCUJztcbiAgICB9XG4gICAgY29uc3QgbGFiZWwgPSBnZXRNb3Rpdm9MYWJlbChtb3Yuc291cmNlX3R5cGUsIG1vdi5zaWduKTtcbiAgICBjb25zdCBuYW1lID0gbW92LnNvdXJjZV90eXBlPy5pbmNsdWRlcygnQ29sbGVjdGlvbicpXG4gICAgICAgID8gbW92LmNsaWVudF9uYW1lXG4gICAgICAgIDogbW92LnNvdXJjZV90eXBlPy5pbmNsdWRlcygnUGF5bWVudE9yZGVyJylcbiAgICAgICAgICAgID8gbW92LnZlbmRvcl9uYW1lXG4gICAgICAgICAgICA6IG51bGw7XG4gICAgY29uc3QgcGFydCA9IFtsYWJlbCwgbmFtZV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyAnKTtcbiAgICByZXR1cm4gcGFydC50cmltKCkgfHwgJ+KAlCc7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UoKTogeyBmcm9tOiBzdHJpbmc7IHRvOiBzdHJpbmcgfSB7XG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICBjb25zdCBvbmVNb250aEFnbyA9IG5ldyBEYXRlKERhdGUubm93KCkgLSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICByZXR1cm4geyBmcm9tOiBvbmVNb250aEFnbywgdG86IHRvZGF5IH07XG59XG5cbmV4cG9ydCBjb25zdCBDYXNoU3RhdGVtZW50VGFiID0gKCkgPT4ge1xuICAgIGNvbnN0IFttb3ZlbWVudHMsIHNldE1vdmVtZW50c10gPSB1c2VTdGF0ZTxDYXNoU3RhdGVtZW50VHJhbnNhY3Rpb25bXT4oW10pO1xuICAgIGNvbnN0IFtpbml0aWFsQmFsYW5jZSwgc2V0SW5pdGlhbEJhbGFuY2VdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW3BhZ2luYXRpb25NZXRhLCBzZXRQYWdpbmF0aW9uTWV0YV0gPSB1c2VTdGF0ZTxDYXNoU3RhdGVtZW50U3RhdGVtZW50IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgW2RyYWZ0UmFuZ2UsIHNldERyYWZ0UmFuZ2VdID0gdXNlU3RhdGUoKCkgPT4gY3JlYXRlRGVmYXVsdERhdGVSYW5nZSgpKTtcbiAgICBjb25zdCBbYXBwbGllZFJhbmdlLCBzZXRBcHBsaWVkUmFuZ2VdID0gdXNlU3RhdGUoKCkgPT4gY3JlYXRlRGVmYXVsdERhdGVSYW5nZSgpKTtcbiAgICBjb25zdCBhcHBsaWVkUmFuZ2VSZWYgPSB1c2VSZWYoYXBwbGllZFJhbmdlKTtcbiAgICBhcHBsaWVkUmFuZ2VSZWYuY3VycmVudCA9IGFwcGxpZWRSYW5nZTtcblxuICAgIGNvbnN0IFtpc0dlbmVyYXRpbmdSZXBvcnQsIHNldElzR2VuZXJhdGluZ1JlcG9ydF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBmZXRjaE1vdmVtZW50cyA9IHVzZUNhbGxiYWNrKGFzeW5jIChwYWdlVXJsPzogc3RyaW5nLCByYW5nZT86IHsgZnJvbTogc3RyaW5nOyB0bzogc3RyaW5nIH0pID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCB1cmw6IHN0cmluZztcblxuICAgICAgICAgICAgaWYgKHBhZ2VVcmwpIHtcbiAgICAgICAgICAgICAgICBpZiAocGFnZVVybC5zdGFydHNXaXRoKCdodHRwJykpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdXJsT2JqID0gbmV3IFVSTChwYWdlVXJsKTtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gdXJsT2JqLnBhdGhuYW1lLnJlcGxhY2UoL15cXC9hcGlcXC8vLCAnJykgKyB1cmxPYmouc2VhcmNoO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9IHBhZ2VVcmw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCByID0gcmFuZ2UgPz8gYXBwbGllZFJhbmdlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ3N0YXJ0X2RhdGUnLCByLmZyb20pO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ2VuZF9kYXRlJywgci50byk7XG4gICAgICAgICAgICAgICAgdXJsID0gYCR7RU5EUE9JTlR9PyR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8YW55Pih1cmwpIGFzIHVua25vd24gYXMgQ2FzaFN0YXRlbWVudFJlc3BvbnNlO1xuXG4gICAgICAgICAgICBzZXRJbml0aWFsQmFsYW5jZShyZXNwb25zZS5pbml0aWFsX2JhbGFuY2UpO1xuICAgICAgICAgICAgc2V0TW92ZW1lbnRzKHJlc3BvbnNlLnN0YXRlbWVudC5kYXRhKTtcbiAgICAgICAgICAgIHNldFBhZ2luYXRpb25NZXRhKHJlc3BvbnNlLnN0YXRlbWVudCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIGVsIGVzdGFkbyBkZSBjdWVudGEgZGUgY2FqYS4nKTtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB2b2lkIGZldGNoTW92ZW1lbnRzKHVuZGVmaW5lZCwgYXBwbGllZFJhbmdlUmVmLmN1cnJlbnQpO1xuICAgIH0sIFtmZXRjaE1vdmVtZW50c10pO1xuXG4gICAgY29uc3QgYXBwbHlGaWx0ZXJzID0gKCkgPT4ge1xuICAgICAgICBpZiAoZHJhZnRSYW5nZS5mcm9tID09PSBhcHBsaWVkUmFuZ2UuZnJvbSAmJiBkcmFmdFJhbmdlLnRvID09PSBhcHBsaWVkUmFuZ2UudG8pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRBcHBsaWVkUmFuZ2UoZHJhZnRSYW5nZSk7XG4gICAgICAgIHZvaWQgZmV0Y2hNb3ZlbWVudHModW5kZWZpbmVkLCBkcmFmdFJhbmdlKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRGF0ZUJsdXIgPSAoZTogUmVhY3QuRm9jdXNFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gZS5yZWxhdGVkVGFyZ2V0IGFzIEhUTUxFbGVtZW50IHwgbnVsbDtcbiAgICAgICAgaWYgKG5leHQgJiYgKG5leHQgYXMgSFRNTEJ1dHRvbkVsZW1lbnQpLnR5cGUgPT09ICdzdWJtaXQnKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgYXBwbHlGaWx0ZXJzKCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgZmV0Y2hNb3ZlbWVudHModXJsKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRmlsdGVyU3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGFwcGx5RmlsdGVycygpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVHZW5lcmF0ZVJlcG9ydCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0SXNHZW5lcmF0aW5nUmVwb3J0KHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBgY2FzaGVzL2NvbnNvbGlkYXRlZC1yZXBvcnQvcGRmP3N0YXJ0RGF0ZT0ke2FwcGxpZWRSYW5nZS5mcm9tfSZlbmREYXRlPSR7YXBwbGllZFJhbmdlLnRvfWA7XG4gICAgICAgICAgICBjb25zdCB7IGJsb2IsIGZpbGVuYW1lIH0gPSBhd2FpdCBnZXRGaWxlQmxvYldpdGhNZXRhKGVuZHBvaW50KTtcbiAgICAgICAgICAgIGNvbnN0IGZhbGxiYWNrTmFtZSA9IGByZXBvcnRlLWNhamEtY29uc29saWRhZG8tJHthcHBsaWVkUmFuZ2UuZnJvbX0tJHthcHBsaWVkUmFuZ2UudG99LnBkZmA7XG4gICAgICAgICAgICBkb3dubG9hZEJsb2IoYmxvYiwgZmlsZW5hbWUgPT09ICdkb2N1bWVudG8ucGRmJyA/IGZhbGxiYWNrTmFtZSA6IGZpbGVuYW1lKTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ1JlcG9ydGUgZ2VuZXJhZG8uJyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBnZW5lcmFyIHJlcG9ydGU6JywgZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGdlbmVyYXIgZWwgcmVwb3J0ZS4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzR2VuZXJhdGluZ1JlcG9ydChmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgeyBrZXk6ICdpZCcsIGxhYmVsOiAnSUQnIH0sXG4gICAgICAgIHsga2V5OiAndHJhbnNhY3Rpb25fZGF0ZScsIGxhYmVsOiAnRmVjaGEnIH0sXG4gICAgICAgIHsga2V5OiAndmFsdWVfdHlwZScsIGxhYmVsOiAnVGlwbyBWYWxvcicgfSxcbiAgICAgICAgeyBrZXk6ICdkb2N1bWVudF9udW1iZXInLCBsYWJlbDogJ07CuiBEb2N1bWVudG8nIH0sXG4gICAgICAgIHsga2V5OiAnbW90aXZvJywgbGFiZWw6ICdNb3Rpdm8nIH0sXG4gICAgICAgIHsga2V5OiAnZGViaXQnLCBsYWJlbDogJ0RlYmUnIH0sXG4gICAgICAgIHsga2V5OiAnY3JlZGl0JywgbGFiZWw6ICdIYWJlcicgfSxcbiAgICAgICAgeyBrZXk6ICdiYWxhbmNlJywgbGFiZWw6ICdTYWxkbycgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02XCI+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlRmlsdGVyU3VibWl0fSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtNCBtYi00IHAtNCBiZy1ncmF5LTUwIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkYXRlX2Zyb21cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5EZXNkZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlX2Zyb21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0UmFuZ2UuZnJvbX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldERyYWZ0UmFuZ2UocHJldiA9PiAoeyAuLi5wcmV2LCBmcm9tOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI9e2hhbmRsZURhdGVCbHVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkYXRlX3RvXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+SGFzdGE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZV90b1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHJhZnRSYW5nZS50b31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldERyYWZ0UmFuZ2UocHJldiA9PiAoeyAuLi5wcmV2LCB0bzogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25CbHVyPXtoYW5kbGVEYXRlQmx1cn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGYUZpbHRlciBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTJcIiAvPiBGaWx0cmFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2VuZXJhdGVSZXBvcnR9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0dlbmVyYXRpbmdSZXBvcnR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyYXktNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzR2VuZXJhdGluZ1JlcG9ydCA/ICdHZW5lcmFuZG/igKYnIDogJ0dlbmVyYXIgUmVwb3J0ZSd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxMb2FkaW5nU3Bpbm5lciAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbHVtbnMubWFwKGNvbCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17Y29sLmtleX0gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9e2BweS0zLjUgcHgtMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgJHtbJ2RlYml0JywgJ2NyZWRpdCcsICdiYWxhbmNlJ10uaW5jbHVkZXMoY29sLmtleSkgPyAndGV4dC1yaWdodCcgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbml0aWFsQmFsYW5jZSAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXtjb2x1bW5zLmxlbmd0aCAtIDF9IGNsYXNzTmFtZT1cInB5LTMgcGwtNCBwci0zIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU0FMRE8gQU5URVJJT1IgKGFsIHtmb3JtYXRWYWx1ZShhcHBsaWVkUmFuZ2UuZnJvbSwgJ2RhdGUnKX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtc20gdGV4dC1yaWdodCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGluaXRpYWxCYWxhbmNlLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW92ZW1lbnRzLm1hcCgobW92LCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbW90aXZvUGF0aCA9IGdldE1vdGl2b0xpbmsobW92LnNvdXJjZV90eXBlLCBtb3Yuc291cmNlX2lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vdGl2b1RleHQgPSBnZXRNb3Rpdm9UZXh0KG1vdik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2Ake21vdi5pZH0tJHttb3YuZG9jdW1lbnRfdHlwZX0tJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2AvY2FqYXMvJHttb3YuaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bW92LmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+e2Zvcm1hdFZhbHVlKG1vdi50cmFuc2FjdGlvbl9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbVwiPntnZXRWYWx1ZVR5cGVMYWJlbChtb3YudmFsdWVfdHlwZSwgbW92LnNvdXJjZV90eXBlKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb3YuZG9jdW1lbnRfbnVtYmVyID8/IChtb3YuaW50ZXJuYWxfbnVtYmVyICE9IG51bGwgPyBTdHJpbmcobW92LmludGVybmFsX251bWJlcikgOiAn4oCUJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vdGl2b1BhdGggPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e21vdGl2b1BhdGh9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb3Rpdm9UZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW90aXZvVGV4dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHRcIj57Zm9ybWF0VmFsdWUobW92LmRlYml0LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZShtb3YuY3JlZGl0LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCBmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKG1vdi5iYWxhbmNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0aW9uTWV0YSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnaW5hdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGE9e3BhZ2luYXRpb25NZXRhIGFzIFBhZ2luYXRlZFJlc3BvbnNlPGFueT5bJ21ldGEnXX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2NvbXBvbmVudHMvY29tbW9uL0Nhc2hTdGF0ZW1lbnRUYWIudHN4In0=