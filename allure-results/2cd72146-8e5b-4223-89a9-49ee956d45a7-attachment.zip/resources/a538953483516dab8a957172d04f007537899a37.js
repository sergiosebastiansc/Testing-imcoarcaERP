import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate, useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaBoxOpen } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, searchByField } from "/src/services/apiService.ts";
import { mercadoLibrePublicacionesConfig } from "/src/features/mercadolibre_publicaciones/mercadolibre_publicaciones.config.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { ToggleSwitch } from "/src/components/ui/ToggleSwitch.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const defaultInitialData = {
  id: 0,
  meli_id: "",
  is_active: true,
  stock_reduction_quantity: 1,
  product_id: null,
  product_name: "",
  product_code: ""
};
export const MercadoLibrePublicacionesFormPage = () => {
  _s();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData, error } = useCrudItem(mercadoLibrePublicacionesConfig, id);
  const { saveItem, loading: saving } = useCrudItem(mercadoLibrePublicacionesConfig, id);
  const [formData, setFormData] = useState(defaultInitialData);
  const [isInitialLoading, setIsInitialLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  useEffect(() => {
    const init = async () => {
      if (mode === "edit" && loadedData) {
        setFormData({
          ...defaultInitialData,
          ...loadedData,
          // ✅ Aseguramos cargar el código del producto existente
          product_code: loadedData.product?.sku || loadedData.product_code,
          product_name: loadedData.product?.name || loadedData.product_name
        });
      } else if (mode === "create") {
        const preSelectedProductId = searchParams.get("productId");
        if (preSelectedProductId) {
          setIsInitialLoading(true);
          try {
            const product = await getById(articulosModuleConfig.endpoint, Number(preSelectedProductId));
            handleProductSelect(product);
            toast.info(`Vinculando a: ${product.name}`);
          } catch (e) {
            console.error(e);
            toast.error("Error al cargar el producto pre-seleccionado.");
          } finally {
            setIsInitialLoading(false);
          }
        }
      }
    };
    init();
  }, [mode, loadedData, searchParams]);
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : type === "number" ? value === "" ? 0 : Number(value) : value
    }));
  };
  const handleToggleActive = (val) => {
    setFormData((prev) => ({ ...prev, is_active: val }));
  };
  const handleProductCodeChange = (code) => {
    setFormData((prev) => ({
      ...prev,
      product_code: code,
      // Si el usuario cambia el código manualmente, reseteamos el ID hasta que valide
      product_id: null,
      product_name: ""
    }));
  };
  const handleProductCodeSubmit = async () => {
    const codeValue = formData.product_code;
    if (!codeValue) return;
    try {
      const result = await searchByField(
        articulosModuleConfig.endpoint,
        [{ fieldName: "sku", value: codeValue }]
      );
      if (result) {
        handleProductSelect(result);
        toast.success("Producto encontrado.");
      } else {
        toast.error(`No se encontró ningún artículo con el código "${codeValue}".`);
        setFormData((prev) => ({ ...prev, product_id: null, product_name: "" }));
      }
    } catch (error2) {
      console.error(error2);
      toast.error("Error al buscar el artículo.");
    } finally {
    }
  };
  const handleProductSelect = (product) => {
    setFormData((prev) => ({
      ...prev,
      product_id: product.id,
      product_code: product.sku,
      // ✅ Importante: Rellenamos el código explícitamente
      product_name: product.name
    }));
    setIsModalOpen(false);
  };
  const handleSave = async () => {
    if (!formData.meli_id || !formData.product_id) {
      toast.warn("El ID de ML y el Producto son obligatorios.");
      return;
    }
    if (!formData.stock_reduction_quantity || Number(formData.stock_reduction_quantity) <= 0) {
      toast.warn("La cantidad a descontar debe ser mayor a 0.");
      return;
    }
    const payload = {
      ...formData,
      stock_reduction_quantity: Number(formData.stock_reduction_quantity)
    };
    const success = await saveItem(payload);
    if (success) {
      toast.success("Publicación guardada.");
      navigate(getListReturnPath(mercadoLibrePublicacionesConfig.baseRoute));
    }
  };
  if (loadingData || isInitialLoading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
    lineNumber: 189,
    columnNumber: 47
  }, this);
  if (error && mode === "edit") return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
    lineNumber: 190,
    columnNumber: 40
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Nueva Vinculación ML" : "Editar Vinculación ML" }, void 0, false, {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
      lineNumber: 194,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Producto Local (Artículo) (*)" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 202,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: formData.product_code || "",
            nameValue: formData.product_name || "",
            onCodeChange: handleProductCodeChange,
            onCodeSubmit: handleProductCodeSubmit,
            onSearchClick: () => setIsModalOpen(true),
            onClearClick: () => setFormData((prev) => ({ ...prev, product_id: null, product_code: "", product_name: "" })),
            mask: "sku",
            enableAutocomplete: true,
            autocompleteConfig: {
              endpoint: articulosModuleConfig.endpoint,
              codeField: "sku",
              nameField: "name",
              onSelect: (product) => {
                handleProductSelect(product);
              }
            }
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
            lineNumber: 203,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Escribe el Código/SKU y presiona Enter, o usa la lupa." }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
        lineNumber: 201,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "ID Publicación MercadoLibre (*)" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 228,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex rounded-md shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm", children: "MLA-" }, void 0, false, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
            lineNumber: 230,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "meli_id",
              value: formData.meli_id?.replace("MLA-", "") || "",
              onChange: handleInputChange,
              placeholder: "12345678",
              autoComplete: "off",
              className: "flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-r-md border border-gray-300 sm:text-sm focus:ring-indigo-500 focus:border-indigo-500"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
              lineNumber: 233,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 229,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
        lineNumber: 227,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cantidad a Descontar (*)" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 246,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1 relative rounded-md shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(FaBoxOpen, { className: "text-gray-400" }, void 0, false, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
            lineNumber: 249,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
            lineNumber: 248,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              name: "stock_reduction_quantity",
              value: formData.stock_reduction_quantity,
              onChange: (num) => setFormData((prev) => ({ ...prev, stock_reduction_quantity: num ?? 0 })),
              min: 1,
              step: "0.01",
              className: "focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
              lineNumber: 251,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 247,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-blue-600", children: 'Ej: Si esta publicación es "Pack x 24", pon 24 aquí.' }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 260,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
        lineNumber: 245,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 flex items-center space-x-3 bg-gray-50 p-3 rounded-md", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Estado de la vinculación:" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 267,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          ToggleSwitch,
          {
            enabled: formData.is_active ?? true,
            onChange: handleToggleActive,
            srLabel: "Activar vinculación"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
            lineNumber: 268,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm ${formData.is_active ? "text-green-600" : "text-gray-500"}`, children: formData.is_active ? "Activa (Sincronizando)" : "Pausada" }, void 0, false, {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 273,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
        lineNumber: 266,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
      lineNumber: 198,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => navigate(getListReturnPath(mercadoLibrePublicacionesConfig.baseRoute)),
          className: "mr-3 px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",
          children: "Cancelar"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 281,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: saving || isInitialLoading,
          className: "inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700",
          children: [
            saving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
              lineNumber: 294,
              columnNumber: 31
            }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
              lineNumber: 294,
              columnNumber: 85
            }, this),
            "Guardar Vinculación"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
          lineNumber: 288,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
      lineNumber: 280,
      columnNumber: 13
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: () => setIsModalOpen(false),
        onSelect: handleProductSelect,
        config: articulosModuleConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
        lineNumber: 301,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx",
    lineNumber: 193,
    columnNumber: 5
  }, this);
};
_s(MercadoLibrePublicacionesFormPage, "5K3GLZRcP57x5vMaJ1FqCsOPjOY=", false, function() {
  return [useParams, useSearchParams, useNavigate, useCrudItem, useCrudItem];
});
_c = MercadoLibrePublicacionesFormPage;
var _c;
$RefreshReg$(_c, "MercadoLibrePublicacionesFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUtnRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4S2hELFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxhQUFhQyxXQUFXQyx1QkFBdUI7QUFDeEQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxXQUFXQyxpQkFBaUI7QUFDN0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUd2QyxTQUFTQyx1Q0FBcUU7QUFDOUUsU0FBU0MsNkJBQTRDO0FBR3JELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLHFCQUF1RDtBQUFBLEVBQ3pEQyxJQUFJO0FBQUEsRUFDSkMsU0FBUztBQUFBLEVBQ1RDLFdBQVc7QUFBQSxFQUNYQywwQkFBMEI7QUFBQSxFQUMxQkMsWUFBWTtBQUFBLEVBQ1pDLGNBQWM7QUFBQSxFQUNkQyxjQUFjO0FBQ2xCO0FBRU8sYUFBTUMsb0NBQW9DQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkQsUUFBTSxFQUFFUixHQUFHLElBQUlsQixVQUEwQjtBQUN6QyxRQUFNLENBQUMyQixZQUFZLElBQUkxQixnQkFBZ0I7QUFDdkMsUUFBTTJCLFdBQVc3QixZQUFZO0FBQzdCLFFBQU04QixPQUFPWCxLQUFLLFNBQVM7QUFFM0IsUUFBTSxFQUFFWSxNQUFNQyxZQUFZQyxTQUFTQyxhQUFhQyxNQUFNLElBQUk1QixZQUFxQ0csaUNBQWlDUyxFQUFFO0FBQ2xJLFFBQU0sRUFBRWlCLFVBQVVILFNBQVNJLE9BQU8sSUFBSTlCLFlBQXFDRyxpQ0FBaUNTLEVBQUU7QUFHOUcsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJekMsU0FBMkNvQixrQkFBa0I7QUFDN0YsUUFBTSxDQUFDc0Isa0JBQWtCQyxtQkFBbUIsSUFBSTNDLFNBQVMsS0FBSztBQUc5RCxRQUFNLENBQUM0QyxhQUFhQyxjQUFjLElBQUk3QyxTQUFTLEtBQUs7QUFJcERDLFlBQVUsTUFBTTtBQUNaLFVBQU02QyxPQUFPLFlBQVk7QUFDckIsVUFBSWQsU0FBUyxVQUFVRSxZQUFZO0FBQy9CTyxvQkFBWTtBQUFBLFVBQ1IsR0FBR3JCO0FBQUFBLFVBQ0gsR0FBR2M7QUFBQUE7QUFBQUEsVUFFSFAsY0FBY08sV0FBV2EsU0FBU0MsT0FBUWQsV0FBbUJQO0FBQUFBLFVBQzdERCxjQUFjUSxXQUFXYSxTQUFTRSxRQUFTZixXQUFtQlI7QUFBQUEsUUFDbEUsQ0FBQztBQUFBLE1BQ0wsV0FBV00sU0FBUyxVQUFVO0FBQzFCLGNBQU1rQix1QkFBdUJwQixhQUFhcUIsSUFBSSxXQUFXO0FBQ3pELFlBQUlELHNCQUFzQjtBQUN0QlAsOEJBQW9CLElBQUk7QUFDeEIsY0FBSTtBQUNBLGtCQUFNSSxVQUFVLE1BQU1yQyxRQUFrQkcsc0JBQXNCdUMsVUFBVUMsT0FBT0gsb0JBQW9CLENBQUM7QUFFcEdJLGdDQUFvQlAsT0FBTztBQUMzQjFDLGtCQUFNa0QsS0FBSyxpQkFBaUJSLFFBQVFFLElBQUksRUFBRTtBQUFBLFVBQzlDLFNBQVNPLEdBQUc7QUFDUkMsb0JBQVFwQixNQUFNbUIsQ0FBQztBQUNmbkQsa0JBQU1nQyxNQUFNLCtDQUErQztBQUFBLFVBQy9ELFVBQUM7QUFDR00sZ0NBQW9CLEtBQUs7QUFBQSxVQUM3QjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUNBRyxTQUFLO0FBQUEsRUFDVCxHQUFHLENBQUNkLE1BQU1FLFlBQVlKLFlBQVksQ0FBQztBQUluQyxRQUFNNEIsb0JBQW9CQSxDQUFDRixNQUEyQztBQUNsRSxVQUFNLEVBQUVQLE1BQU1VLE9BQU9DLE1BQU1DLFFBQVEsSUFBSUwsRUFBRU07QUFDekNyQixnQkFBWSxDQUFBc0IsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2QsSUFBSSxHQUFHVyxTQUFTLGFBQWFDLFVBQVdELFNBQVMsV0FBWUQsVUFBVSxLQUFLLElBQUlOLE9BQU9NLEtBQUssSUFBS0E7QUFBQUEsSUFDdEcsRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNSyxxQkFBcUJBLENBQUNDLFFBQWlCO0FBQ3pDeEIsZ0JBQVksQ0FBQXNCLFVBQVMsRUFBRSxHQUFHQSxNQUFNeEMsV0FBVzBDLElBQUksRUFBRTtBQUFBLEVBQ3JEO0FBS0EsUUFBTUMsMEJBQTBCQSxDQUFDQyxTQUFpQjtBQUM5QzFCLGdCQUFZLENBQUFzQixVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSHBDLGNBQWN3QztBQUFBQTtBQUFBQSxNQUVkMUMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxJQUNsQixFQUFFO0FBQUEsRUFDTjtBQUdBLFFBQU0wQywwQkFBMEIsWUFBWTtBQUN4QyxVQUFNQyxZQUFZN0IsU0FBU2I7QUFDM0IsUUFBSSxDQUFDMEMsVUFBVztBQUdoQixRQUFJO0FBSUEsWUFBTUMsU0FBUyxNQUFNM0Q7QUFBQUEsUUFDakJFLHNCQUFzQnVDO0FBQUFBLFFBQ3RCLENBQUMsRUFBRW1CLFdBQVcsT0FBT1osT0FBT1UsVUFBVSxDQUFDO0FBQUEsTUFDM0M7QUFFQSxVQUFJQyxRQUFRO0FBQ1JoQiw0QkFBb0JnQixNQUFNO0FBQzFCakUsY0FBTW1FLFFBQVEsc0JBQXNCO0FBQUEsTUFDeEMsT0FBTztBQUNIbkUsY0FBTWdDLE1BQU0saURBQWlEZ0MsU0FBUyxJQUFJO0FBQzFFNUIsb0JBQVksQ0FBQXNCLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEMsWUFBWSxNQUFNQyxjQUFjLEdBQUcsRUFBRTtBQUFBLE1BQ3pFO0FBQUEsSUFDSixTQUFTVyxRQUFPO0FBQ1pvQixjQUFRcEIsTUFBTUEsTUFBSztBQUNuQmhDLFlBQU1nQyxNQUFNLDhCQUE4QjtBQUFBLElBQzlDLFVBQUM7QUFBQSxJQUNHO0FBQUEsRUFFUjtBQUdBLFFBQU1pQixzQkFBc0JBLENBQUNQLFlBQWlCO0FBQzFDTixnQkFBWSxDQUFBc0IsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0h0QyxZQUFZc0IsUUFBUTFCO0FBQUFBLE1BQ3BCTSxjQUFjb0IsUUFBUUM7QUFBQUE7QUFBQUEsTUFDdEJ0QixjQUFjcUIsUUFBUUU7QUFBQUEsSUFDMUIsRUFBRTtBQUNGSixtQkFBZSxLQUFLO0FBQUEsRUFDeEI7QUFFQSxRQUFNNEIsYUFBYSxZQUFZO0FBQzNCLFFBQUksQ0FBQ2pDLFNBQVNsQixXQUFXLENBQUNrQixTQUFTZixZQUFZO0FBQzNDcEIsWUFBTXFFLEtBQUssNkNBQTZDO0FBQ3hEO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQ2xDLFNBQVNoQiw0QkFBNEI2QixPQUFPYixTQUFTaEIsd0JBQXdCLEtBQUssR0FBRztBQUN0Rm5CLFlBQU1xRSxLQUFLLDZDQUE2QztBQUN4RDtBQUFBLElBQ0o7QUFFQSxVQUFNQyxVQUFVO0FBQUEsTUFDWixHQUFHbkM7QUFBQUEsTUFDSGhCLDBCQUEwQjZCLE9BQU9iLFNBQVNoQix3QkFBd0I7QUFBQSxJQUN0RTtBQUVBLFVBQU1nRCxVQUFVLE1BQU1sQyxTQUFTcUMsT0FBa0M7QUFDakUsUUFBSUgsU0FBUztBQUNUbkUsWUFBTW1FLFFBQVEsdUJBQXVCO0FBQ3JDekMsZUFBU1osa0JBQWtCUCxnQ0FBZ0NnRSxTQUFTLENBQUM7QUFBQSxJQUN6RTtBQUFBLEVBQ0o7QUFFQSxNQUFJeEMsZUFBZU0saUJBQWtCLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQzNELE1BQUlMLFNBQVNMLFNBQVMsT0FBUSxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JLLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRTFFLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHNEQUNYO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHVDQUNUTCxtQkFBUyxXQUFXLHlCQUF5QiwyQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBR1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLDZDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsUUFDeEY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVdRLFNBQVNiLGdCQUFnQjtBQUFBLFlBQ3BDLFdBQVdhLFNBQVNkLGdCQUFnQjtBQUFBLFlBQ3BDLGNBQWN3QztBQUFBQSxZQUNkLGNBQWNFO0FBQUFBLFlBQ2QsZUFBZSxNQUFNdkIsZUFBZSxJQUFJO0FBQUEsWUFDeEMsY0FBYyxNQUFNSixZQUFZLENBQUFzQixVQUFTLEVBQUUsR0FBR0EsTUFBTXRDLFlBQVksTUFBTUUsY0FBYyxJQUFJRCxjQUFjLEdBQUcsRUFBRTtBQUFBLFlBQzNHLE1BQUs7QUFBQSxZQUNMLG9CQUFvQjtBQUFBLFlBQ3BCLG9CQUFvQjtBQUFBLGNBQ2hCMEIsVUFBVXZDLHNCQUFzQnVDO0FBQUFBLGNBQ2hDeUIsV0FBVztBQUFBLGNBQ1hDLFdBQVc7QUFBQSxjQUNYQyxVQUFVQSxDQUFDaEMsWUFBWTtBQUNuQk8sb0NBQW9CUCxPQUFPO0FBQUEsY0FDL0I7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFnQk07QUFBQSxRQUVOLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEIsc0VBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxNQUdBLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFdBQVUsMkNBQTBDLCtDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG9IQUFrSCxvQkFBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9QLFNBQVNsQixTQUFTMEQsUUFBUSxRQUFRLEVBQUUsS0FBSztBQUFBLGNBQ2hELFVBQVV0QjtBQUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLGNBQWE7QUFBQSxjQUFNLFdBQVU7QUFBQTtBQUFBLFlBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1rTDtBQUFBLGFBVnRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFHQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDJDQUEwQyx3Q0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFFBQ25GLHVCQUFDLFNBQUksV0FBVSxzQ0FDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSx3RUFDWCxpQ0FBQyxhQUFVLFdBQVUsbUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxPQUFPbEIsU0FBU2hCO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQXlELFFBQU94QyxZQUFZLENBQUFzQixVQUFTLEVBQUUsR0FBR0EsTUFBTXZDLDBCQUEwQnlELE9BQU8sRUFBRSxFQUFFO0FBQUEsY0FDdEYsS0FBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBO0FBQUEsWUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNMkg7QUFBQSxhQVYvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNEIsb0VBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx1RUFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxxQ0FBb0MseUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csU0FBU3pDLFNBQVNqQixhQUFhO0FBQUEsWUFDL0IsVUFBVXlDO0FBQUFBLFlBQ1YsU0FBUTtBQUFBO0FBQUEsVUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHaUM7QUFBQSxRQUVqQyx1QkFBQyxVQUFLLFdBQVcsV0FBV3hCLFNBQVNqQixZQUFZLG1CQUFtQixlQUFlLElBQzlFaUIsbUJBQVNqQixZQUFZLDJCQUEyQixhQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBOUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxrQ0FDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1RLFNBQVNaLGtCQUFrQlAsZ0NBQWdDZ0UsU0FBUyxDQUFDO0FBQUEsVUFDcEYsV0FBVTtBQUFBLFVBQXdIO0FBQUE7QUFBQSxRQUh0STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVNIO0FBQUFBLFVBQ1QsVUFBVWxDLFVBQVVHO0FBQUFBLFVBQ3BCLFdBQVU7QUFBQSxVQUVUSDtBQUFBQSxxQkFBUyx1QkFBQyxhQUFVLFdBQVUsK0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdELElBQU0sdUJBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFOdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFHQ0ssZUFDRztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUUE7QUFBQUEsUUFDUixTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFFBQ25DLFVBQVVTO0FBQUFBLFFBQ1YsUUFBUXpDO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWtDO0FBQUEsT0FoSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSEE7QUFFUjtBQUFFZ0IsR0FwUVdELG1DQUFpQztBQUFBLFVBQzNCekIsV0FDUUMsaUJBQ05GLGFBR3lDTyxhQUNwQkEsV0FBVztBQUFBO0FBQUF5RSxLQVB4Q3REO0FBQWlDLElBQUFzRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInVzZVNlYXJjaFBhcmFtcyIsInRvYXN0IiwiRmFTYXZlIiwiRmFTcGlubmVyIiwiRmFCb3hPcGVuIiwidXNlQ3J1ZEl0ZW0iLCJnZXRCeUlkIiwic2VhcmNoQnlGaWVsZCIsIm1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWciLCJhcnRpY3Vsb3NNb2R1bGVDb25maWciLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsIkxvYWRpbmdTcGlubmVyIiwiVG9nZ2xlU3dpdGNoIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJkZWZhdWx0SW5pdGlhbERhdGEiLCJpZCIsIm1lbGlfaWQiLCJpc19hY3RpdmUiLCJzdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHkiLCJwcm9kdWN0X2lkIiwicHJvZHVjdF9uYW1lIiwicHJvZHVjdF9jb2RlIiwiTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlIiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJuYXZpZ2F0ZSIsIm1vZGUiLCJpdGVtIiwibG9hZGVkRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nRGF0YSIsImVycm9yIiwic2F2ZUl0ZW0iLCJzYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiaXNJbml0aWFsTG9hZGluZyIsInNldElzSW5pdGlhbExvYWRpbmciLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiaW5pdCIsInByb2R1Y3QiLCJza3UiLCJuYW1lIiwicHJlU2VsZWN0ZWRQcm9kdWN0SWQiLCJnZXQiLCJlbmRwb2ludCIsIk51bWJlciIsImhhbmRsZVByb2R1Y3RTZWxlY3QiLCJpbmZvIiwiZSIsImNvbnNvbGUiLCJoYW5kbGVJbnB1dENoYW5nZSIsInZhbHVlIiwidHlwZSIsImNoZWNrZWQiLCJ0YXJnZXQiLCJwcmV2IiwiaGFuZGxlVG9nZ2xlQWN0aXZlIiwidmFsIiwiaGFuZGxlUHJvZHVjdENvZGVDaGFuZ2UiLCJjb2RlIiwiaGFuZGxlUHJvZHVjdENvZGVTdWJtaXQiLCJjb2RlVmFsdWUiLCJyZXN1bHQiLCJmaWVsZE5hbWUiLCJzdWNjZXNzIiwiaGFuZGxlU2F2ZSIsIndhcm4iLCJwYXlsb2FkIiwiYmFzZVJvdXRlIiwiY29kZUZpZWxkIiwibmFtZUZpZWxkIiwib25TZWxlY3QiLCJyZXBsYWNlIiwibnVtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcywgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFTcGlubmVyLCBGYUJveE9wZW4gfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEJ5SWQsIHNlYXJjaEJ5RmllbGQgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJzsgLy8g4pyFIEltcG9ydGFtb3Mgc2VhcmNoQnlGaWVsZFxuXG4vLyBDb25maWdzXG5pbXBvcnQgeyBtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnLCB0eXBlIE1lcmNhZG9MaWJyZVB1YmxpY2F0aW9uIH0gZnJvbSAnLi4vbWVyY2Fkb2xpYnJlX3B1YmxpY2FjaW9uZXMuY29uZmlnJztcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZywgdHlwZSBBcnRpY3VsbyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJztcblxuLy8gQ29tcG9uZW50c1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBUb2dnbGVTd2l0Y2ggfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL1RvZ2dsZVN3aXRjaCc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuY29uc3QgZGVmYXVsdEluaXRpYWxEYXRhOiBQYXJ0aWFsPE1lcmNhZG9MaWJyZVB1YmxpY2F0aW9uPiA9IHtcbiAgICBpZDogMCxcbiAgICBtZWxpX2lkOiAnJyxcbiAgICBpc19hY3RpdmU6IHRydWUsXG4gICAgc3RvY2tfcmVkdWN0aW9uX3F1YW50aXR5OiAxLFxuICAgIHByb2R1Y3RfaWQ6IG51bGwsXG4gICAgcHJvZHVjdF9uYW1lOiAnJyxcbiAgICBwcm9kdWN0X2NvZGU6ICcnLFxufTtcblxuZXhwb3J0IGNvbnN0IE1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNGb3JtUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCB7IGl0ZW06IGxvYWRlZERhdGEsIGxvYWRpbmc6IGxvYWRpbmdEYXRhLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08TWVyY2Fkb0xpYnJlUHVibGljYXRpb24+KG1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWcsIGlkKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtLCBsb2FkaW5nOiBzYXZpbmcgfSA9IHVzZUNydWRJdGVtPE1lcmNhZG9MaWJyZVB1YmxpY2F0aW9uPihtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnLCBpZCk7XG5cbiAgICAvLyBFc3RhZG9zXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZTxQYXJ0aWFsPE1lcmNhZG9MaWJyZVB1YmxpY2F0aW9uPj4oZGVmYXVsdEluaXRpYWxEYXRhKTtcbiAgICBjb25zdCBbaXNJbml0aWFsTG9hZGluZywgc2V0SXNJbml0aWFsTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBFc3RhZG9zIE1vZGFsZXNcbiAgICBjb25zdCBbaXNNb2RhbE9wZW4sIHNldElzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIC8vIC0tLSBFRkVDVE9TIC0tLVxuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGlmIChtb2RlID09PSAnZWRpdCcgJiYgbG9hZGVkRGF0YSkge1xuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgLi4uZGVmYXVsdEluaXRpYWxEYXRhLFxuICAgICAgICAgICAgICAgICAgICAuLi5sb2FkZWREYXRhLFxuICAgICAgICAgICAgICAgICAgICAvLyDinIUgQXNlZ3VyYW1vcyBjYXJnYXIgZWwgY8OzZGlnbyBkZWwgcHJvZHVjdG8gZXhpc3RlbnRlXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfY29kZTogbG9hZGVkRGF0YS5wcm9kdWN0Py5za3UgfHwgKGxvYWRlZERhdGEgYXMgYW55KS5wcm9kdWN0X2NvZGUsXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3RfbmFtZTogbG9hZGVkRGF0YS5wcm9kdWN0Py5uYW1lIHx8IChsb2FkZWREYXRhIGFzIGFueSkucHJvZHVjdF9uYW1lLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtb2RlID09PSAnY3JlYXRlJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByZVNlbGVjdGVkUHJvZHVjdElkID0gc2VhcmNoUGFyYW1zLmdldCgncHJvZHVjdElkJyk7XG4gICAgICAgICAgICAgICAgaWYgKHByZVNlbGVjdGVkUHJvZHVjdElkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzSW5pdGlhbExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9kdWN0ID0gYXdhaXQgZ2V0QnlJZDxBcnRpY3Vsbz4oYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBOdW1iZXIocHJlU2VsZWN0ZWRQcm9kdWN0SWQpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJldXRpbGl6YW1vcyBsYSBsw7NnaWNhIGRlIHNlbGVjY2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVByb2R1Y3RTZWxlY3QocHJvZHVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b2FzdC5pbmZvKGBWaW5jdWxhbmRvIGE6ICR7cHJvZHVjdC5uYW1lfWApO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgZWwgcHJvZHVjdG8gcHJlLXNlbGVjY2lvbmFkby5cIik7XG4gICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0luaXRpYWxMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgaW5pdCgpO1xuICAgIH0sIFttb2RlLCBsb2FkZWREYXRhLCBzZWFyY2hQYXJhbXNdKTtcblxuICAgIC8vIC0tLSBIQU5ETEVSUyAtLS1cblxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUsIHR5cGUsIGNoZWNrZWQgfSA9IGUudGFyZ2V0O1xuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgW25hbWVdOiB0eXBlID09PSAnY2hlY2tib3gnID8gY2hlY2tlZCA6ICh0eXBlID09PSAnbnVtYmVyJyA/ICh2YWx1ZSA9PT0gJycgPyAwIDogTnVtYmVyKHZhbHVlKSkgOiB2YWx1ZSlcbiAgICAgICAgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUb2dnbGVBY3RpdmUgPSAodmFsOiBib29sZWFuKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgaXNfYWN0aXZlOiB2YWwgfSkpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gTMOTR0lDQSBSRUxBVElPTkFMIElOUFVUIChQUk9EVUNUTykgLS0tXG5cbiAgICAvLyAxLiBBY3R1YWxpemEgZWwgZXN0YWRvIG1pZW50cmFzIGVsIHVzdWFyaW8gZXNjcmliZSBlbiBlbCBpbnB1dCBkZSBjw7NkaWdvXG4gICAgY29uc3QgaGFuZGxlUHJvZHVjdENvZGVDaGFuZ2UgPSAoY29kZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBwcm9kdWN0X2NvZGU6IGNvZGUsXG4gICAgICAgICAgICAvLyBTaSBlbCB1c3VhcmlvIGNhbWJpYSBlbCBjw7NkaWdvIG1hbnVhbG1lbnRlLCByZXNldGVhbW9zIGVsIElEIGhhc3RhIHF1ZSB2YWxpZGVcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IG51bGwsXG4gICAgICAgICAgICBwcm9kdWN0X25hbWU6ICcnXG4gICAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgLy8gMi4g4pyFIELDunNxdWVkYSBwb3IgRU5URVIgKFNLVS9Dw7NkaWdvKVxuICAgIGNvbnN0IGhhbmRsZVByb2R1Y3RDb2RlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb2RlVmFsdWUgPSBmb3JtRGF0YS5wcm9kdWN0X2NvZGU7XG4gICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG5cbiAgICAgICAgLy9zZXRJc0luaXRpYWxMb2FkaW5nKHRydWUpOyAvLyBVc2Ftb3MgbG9hZGluZyB2aXN1YWxcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIOKchSBCdXNjYXIgY29uIGVsIGZvcm1hdG8gZGUgbcOhc2NhcmEgKGluY2x1eWUgcHVudG9zKVxuICAgICAgICAgICAgLy8gQnVzY2Ftb3MgdXNhbmRvIGxhIGNvbmZpZ3VyYWNpw7NuIGRlbCBtw7NkdWxvIGRlIGFydMOtY3Vsb3NcbiAgICAgICAgICAgIC8vIEFzdW1pbW9zIHF1ZSBlbCBjYW1wbyBkZSBiw7pzcXVlZGEgZXMgJ2NvZGUnIChhanVzdGFyIHNpIHR1IGJhY2tlbmQgdXNhICdza3UnKVxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxBcnRpY3Vsbz4oXG4gICAgICAgICAgICAgICAgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ3NrdScsIHZhbHVlOiBjb2RlVmFsdWUgfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVQcm9kdWN0U2VsZWN0KHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlByb2R1Y3RvIGVuY29udHJhZG8uXCIpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihgTm8gc2UgZW5jb250csOzIG5pbmfDum4gYXJ0w61jdWxvIGNvbiBlbCBjw7NkaWdvIFwiJHtjb2RlVmFsdWV9XCIuYCk7XG4gICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwcm9kdWN0X2lkOiBudWxsLCBwcm9kdWN0X25hbWU6ICcnIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgZWwgYXJ0w61jdWxvLlwiKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIC8vc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gMy4g4pyFIFNlbGVjY2nDs24gZGVzZGUgZWwgTW9kYWwgKG8gdHJhcyBiw7pzcXVlZGEgZXhpdG9zYSlcbiAgICBjb25zdCBoYW5kbGVQcm9kdWN0U2VsZWN0ID0gKHByb2R1Y3Q6IGFueSkgPT4ge1xuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdC5pZCxcbiAgICAgICAgICAgIHByb2R1Y3RfY29kZTogcHJvZHVjdC5za3UsIC8vIOKchSBJbXBvcnRhbnRlOiBSZWxsZW5hbW9zIGVsIGPDs2RpZ28gZXhwbMOtY2l0YW1lbnRlXG4gICAgICAgICAgICBwcm9kdWN0X25hbWU6IHByb2R1Y3QubmFtZSxcbiAgICAgICAgfSkpO1xuICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybURhdGEubWVsaV9pZCB8fCAhZm9ybURhdGEucHJvZHVjdF9pZCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybihcIkVsIElEIGRlIE1MIHkgZWwgUHJvZHVjdG8gc29uIG9ibGlnYXRvcmlvcy5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5zdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHkgfHwgTnVtYmVyKGZvcm1EYXRhLnN0b2NrX3JlZHVjdGlvbl9xdWFudGl0eSkgPD0gMCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybihcIkxhIGNhbnRpZGFkIGEgZGVzY29udGFyIGRlYmUgc2VyIG1heW9yIGEgMC5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICAgICAgLi4uZm9ybURhdGEsXG4gICAgICAgICAgICBzdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHk6IE51bWJlcihmb3JtRGF0YS5zdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHkpXG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3Qgc3VjY2VzcyA9IGF3YWl0IHNhdmVJdGVtKHBheWxvYWQgYXMgTWVyY2Fkb0xpYnJlUHVibGljYXRpb24pO1xuICAgICAgICBpZiAoc3VjY2Vzcykge1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlB1YmxpY2FjacOzbiBndWFyZGFkYS5cIik7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChtZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nRGF0YSB8fCBpc0luaXRpYWxMb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvciAmJiBtb2RlID09PSAnZWRpdCcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02XCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICB7bW9kZSA9PT0gJ2NyZWF0ZScgPyAnTnVldmEgVmluY3VsYWNpw7NuIE1MJyA6ICdFZGl0YXIgVmluY3VsYWNpw7NuIE1MJ31cbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuXG4gICAgICAgICAgICAgICAgey8qIDEuIFBST0RVQ1RPIExPQ0FMIChSZWxhdGlvbmFsSW5wdXQgQ29tcGxldG8pICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UHJvZHVjdG8gTG9jYWwgKEFydMOtY3VsbykgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtmb3JtRGF0YS5wcm9kdWN0X2NvZGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnByb2R1Y3RfbmFtZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17aGFuZGxlUHJvZHVjdENvZGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZVByb2R1Y3RDb2RlU3VibWl0fSAvLyDinIUgQ29uZWN0YWRvXG4gICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBzZXRJc01vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwcm9kdWN0X2lkOiBudWxsLCBwcm9kdWN0X2NvZGU6ICcnLCBwcm9kdWN0X25hbWU6ICcnIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG1hc2s9XCJza3VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZW5hYmxlQXV0b2NvbXBsZXRlPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgYXV0b2NvbXBsZXRlQ29uZmlnPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ6IGFydGljdWxvc01vZHVsZUNvbmZpZy5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlRmllbGQ6ICdza3UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ25hbWUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0OiAocHJvZHVjdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQcm9kdWN0U2VsZWN0KHByb2R1Y3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBFc2NyaWJlIGVsIEPDs2RpZ28vU0tVIHkgcHJlc2lvbmEgRW50ZXIsIG8gdXNhIGxhIGx1cGEuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiAyLiBJRCBQVUJMSUNBQ0nDk04gTUwgKi99XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPklEIFB1YmxpY2FjacOzbiBNZXJjYWRvTGlicmUgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggcm91bmRlZC1tZCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHJvdW5kZWQtbC1tZCBib3JkZXIgYm9yZGVyLXItMCBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCB0ZXh0LWdyYXktNTAwIHNtOnRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNTEEtXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1lbGlfaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5tZWxpX2lkPy5yZXBsYWNlKCdNTEEtJywgJycpIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjEyMzQ1Njc4XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMCBibG9jayB3LWZ1bGwgcHgtMyBweS0yIHJvdW5kZWQtbm9uZSByb3VuZGVkLXItbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBzbTp0ZXh0LXNtIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiAzLiBDQU5USURBRCBBIERFU0NPTlRBUiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Q2FudGlkYWQgYSBEZXNjb250YXIgKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHJlbGF0aXZlIHJvdW5kZWQtbWQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMyBmbGV4IGl0ZW1zLWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhQm94T3BlbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zdG9ja19yZWR1Y3Rpb25fcXVhbnRpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHN0b2NrX3JlZHVjdGlvbl9xdWFudGl0eTogbnVtID8/IDAgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGJsb2NrIHctZnVsbCBwbC0xMCBzbTp0ZXh0LXNtIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHB5LTJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWJsdWUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBFajogU2kgZXN0YSBwdWJsaWNhY2nDs24gZXMgXCJQYWNrIHggMjRcIiwgcG9uIDI0IGFxdcOtLlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogNC4gRVNUQURPICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMiBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgYmctZ3JheS01MCBwLTMgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Fc3RhZG8gZGUgbGEgdmluY3VsYWNpw7NuOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPFRvZ2dsZVN3aXRjaFxuICAgICAgICAgICAgICAgICAgICAgICAgZW5hYmxlZD17Zm9ybURhdGEuaXNfYWN0aXZlID8/IHRydWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVG9nZ2xlQWN0aXZlfVxuICAgICAgICAgICAgICAgICAgICAgICAgc3JMYWJlbD1cIkFjdGl2YXIgdmluY3VsYWNpw7NuXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSAke2Zvcm1EYXRhLmlzX2FjdGl2ZSA/ICd0ZXh0LWdyZWVuLTYwMCcgOiAndGV4dC1ncmF5LTUwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuaXNfYWN0aXZlID8gJ0FjdGl2YSAoU2luY3Jvbml6YW5kbyknIDogJ1BhdXNhZGEnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJPVE9ORVMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNDb25maWcuYmFzZVJvdXRlKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTMgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGhvdmVyOmJnLWdyYXktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nIHx8IGlzSW5pdGlhbExvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmcteWVsbG93LTYwMCBob3ZlcjpiZy15ZWxsb3ctNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgVmluY3VsYWNpw7NuXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1PREFMIELDmlNRVUVEQSBQUk9EVUNUTyAqL31cbiAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9e2hhbmRsZVByb2R1Y3RTZWxlY3R9IC8vIOKchSBVc2Ftb3MgZWwgaGFuZGxlciBjb3JyZWdpZG9cbiAgICAgICAgICAgICAgICAgICAgY29uZmlnPXthcnRpY3Vsb3NNb2R1bGVDb25maWd9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbWVyY2Fkb2xpYnJlX3B1YmxpY2FjaW9uZXMvcGFnZXMvTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlLnRzeCJ9