import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profiles/pages/ProfileCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/profiles/pages/ProfileCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { profilesModuleConfig } from "/src/features/profiles/profiles.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getPermissions } from "/src/services/apiService.ts";
import { groupBy } from "/src/utils/helpers.ts";
import { getPermissionLabel, getPermissionModuleTitle, sortPermissionsForDisplay } from "/src/utils/translations.ts";
export const ProfileCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(profilesModuleConfig);
  const [_, setAllPermissions] = useState([]);
  const [loadingPermissions, setLoadingPermissions] = useState(true);
  const [groupedPermissions, setGroupedPermissions] = useState({});
  const [selectedPermissions, setSelectedPermissions] = useState([]);
  const [profileName, setProfileName] = useState("");
  useEffect(() => {
    getPermissions().then((permissions) => {
      setAllPermissions(permissions);
      setGroupedPermissions(groupBy(permissions, (p) => p.name.split(".")[0]));
    }).catch((error) => console.error("Error loading permissions:", error)).finally(() => setLoadingPermissions(false));
  }, []);
  const handlePermissionChange = (permissionId, checked) => {
    setSelectedPermissions(
      (prev) => checked ? [...prev, permissionId] : prev.filter((id) => id !== permissionId)
    );
  };
  const handleSelectAll = () => {
    const allPermissionIds = Object.values(groupedPermissions).flat().map((p) => p.id);
    const allSelected = areAllPermissionsSelected();
    if (allSelected) {
      setSelectedPermissions([]);
    } else {
      setSelectedPermissions(allPermissionIds);
    }
  };
  const handleSelectAllForEntity = (entity) => {
    const entityPermissions = groupedPermissions[entity] || [];
    const entityPermissionIds = entityPermissions.map((p) => p.id);
    const allEntitySelected = areAllEntityPermissionsSelected(entity);
    setSelectedPermissions((prev) => {
      if (allEntitySelected) {
        return prev.filter((id) => !entityPermissionIds.includes(id));
      } else {
        const newSet = new Set(prev);
        entityPermissionIds.forEach((id) => newSet.add(id));
        return Array.from(newSet);
      }
    });
  };
  const areAllPermissionsSelected = () => {
    const allPermissionIds = Object.values(groupedPermissions).flat().map((p) => p.id);
    return allPermissionIds.length > 0 && allPermissionIds.every((id) => selectedPermissions.includes(id));
  };
  const areAllEntityPermissionsSelected = (entity) => {
    const entityPermissions = groupedPermissions[entity] || [];
    return entityPermissions.length > 0 && entityPermissions.every((p) => selectedPermissions.includes(p.id));
  };
  const handleSave = async () => {
    const saveData = { name: profileName, permissions: selectedPermissions };
    const newProfile = await saveItem(saveData);
    if (newProfile) {
      navigate("/configuracion/profiles");
    }
  };
  if (loadingPermissions) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando permisos..." }, void 0, false, {
    fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
    lineNumber: 109,
    columnNumber: 34
  }, this);
  return (
    // Ya no usamos GenericFormPage, construimos el formulario directamente aquí
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: "Crear Nuevo Perfil" }, void 0, false, {
          fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
          lineNumber: 115,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "profileName", className: "block text-sm font-medium text-gray-700", children: "Nombre del Perfil" }, void 0, false, {
            fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
            lineNumber: 117,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "profileName",
              value: profileName,
              onChange: (e) => setProfileName(e.target.value),
              className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
              lineNumber: 120,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
          lineNumber: 116,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
        lineNumber: 114,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-900", children: "Permisos" }, void 0, false, {
            fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
            lineNumber: 131,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleSelectAll,
              className: "px-3 py-1.5 text-sm font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded-md hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-indigo-500",
              children: areAllPermissionsSelected() ? "Deseleccionar Todos" : "Seleccionar Todos"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
              lineNumber: 132,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
          lineNumber: 130,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: Object.entries(groupedPermissions).map(
          ([entity, permissions]) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-700", children: [
                getPermissionModuleTitle(entity),
                ":"
              ] }, void 0, true, {
                fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
                lineNumber: 144,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleSelectAllForEntity(entity),
                  className: "px-2 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded hover:bg-indigo-100 focus:outline-none focus:ring-1 focus:ring-indigo-500",
                  children: areAllEntityPermissionsSelected(entity) ? "Desmarcar" : "Marcar Todos"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
                  lineNumber: 145,
                  columnNumber: 33
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
              lineNumber: 143,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-2 mt-2", children: sortPermissionsForDisplay(entity, permissions).map(
              (permission) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: `permission-${permission.id}`,
                    type: "checkbox",
                    value: permission.id,
                    checked: selectedPermissions.includes(permission.id),
                    onChange: (e) => handlePermissionChange(permission.id, e.target.checked),
                    className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
                    autoComplete: "off"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
                    lineNumber: 156,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: `permission-${permission.id}`, className: "ml-2 text-sm text-gray-700", children: getPermissionLabel(permission.name) }, void 0, false, {
                  fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
                  lineNumber: 163,
                  columnNumber: 41
                }, this)
              ] }, permission.id, true, {
                fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
                lineNumber: 155,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
              lineNumber: 153,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("hr", { className: "my-2 border-gray-200" }, void 0, false, {
              fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
              lineNumber: 169,
              columnNumber: 29
            }, this)
          ] }, entity, true, {
            fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
            lineNumber: 142,
            columnNumber: 11
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
          lineNumber: 140,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
        lineNumber: 129,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex justify-end", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate("/configuracion/profiles"),
            className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: "Cancelar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
            lineNumber: 176,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleSave,
            className: "px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
            children: "Crear Perfil"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
            lineNumber: 183,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
        lineNumber: 175,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/profiles/pages/ProfileCreatePage.tsx",
      lineNumber: 113,
      columnNumber: 5
    }, this)
  );
};
_s(ProfileCreatePage, "UsCflGW8j5D+yv3mdRWoFv4e+kI=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = ProfileCreatePage;
var _c;
$RefreshReg$(_c, "ProfileCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/profiles/pages/ProfileCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/profiles/pages/ProfileCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6Rm5DLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsNEJBQTJEO0FBQ3BFLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0JDLDBCQUEwQkMsaUNBQWlDO0FBRWpGLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLFdBQVdWLFlBQVk7QUFDN0IsUUFBTSxFQUFFVyxTQUFTLElBQUlULFlBQXFCRCxvQkFBb0I7QUFDOUQsUUFBTSxDQUFDVyxHQUFHQyxpQkFBaUIsSUFBSWYsU0FBdUIsRUFBRTtBQUN4RCxRQUFNLENBQUNnQixvQkFBb0JDLHFCQUFxQixJQUFJakIsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ2tCLG9CQUFvQkMscUJBQXFCLElBQUluQixTQUEwQyxDQUFDLENBQUM7QUFDaEcsUUFBTSxDQUFDb0IscUJBQXFCQyxzQkFBc0IsSUFBSXJCLFNBQW1CLEVBQUU7QUFHM0UsUUFBTSxDQUFDc0IsYUFBYUMsY0FBYyxJQUFJdkIsU0FBUyxFQUFFO0FBRWpEQyxZQUFVLE1BQU07QUFDWkksbUJBQTJCLEVBQ3RCbUIsS0FBSyxDQUFBQyxnQkFBZTtBQUNqQlYsd0JBQWtCVSxXQUFXO0FBQzdCTiw0QkFBc0JiLFFBQVFtQixhQUFhLENBQUNDLE1BQU1BLEVBQUVDLEtBQUtDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDM0UsQ0FBQyxFQUNBQyxNQUFNLENBQUFDLFVBQVNDLFFBQVFELE1BQU0sOEJBQThCQSxLQUFLLENBQUMsRUFDakVFLFFBQVEsTUFBTWYsc0JBQXNCLEtBQUssQ0FBQztBQUFBLEVBQ25ELEdBQUcsRUFBRTtBQUVMLFFBQU1nQix5QkFBeUJBLENBQUNDLGNBQXNCQyxZQUFxQjtBQUN2RWQ7QUFBQUEsTUFBdUIsQ0FBQWUsU0FDbkJELFVBQVUsQ0FBQyxHQUFHQyxNQUFNRixZQUFZLElBQUlFLEtBQUtDLE9BQU8sQ0FBQUMsT0FBTUEsT0FBT0osWUFBWTtBQUFBLElBQzdFO0FBQUEsRUFDSjtBQUdBLFFBQU1LLGtCQUFrQkEsTUFBTTtBQUMxQixVQUFNQyxtQkFBbUJDLE9BQU9DLE9BQU94QixrQkFBa0IsRUFBRXlCLEtBQUssRUFBRUMsSUFBSSxDQUFBbEIsTUFBS0EsRUFBRVksRUFBRTtBQUMvRSxVQUFNTyxjQUFjQywwQkFBMEI7QUFFOUMsUUFBSUQsYUFBYTtBQUVieEIsNkJBQXVCLEVBQUU7QUFBQSxJQUM3QixPQUFPO0FBRUhBLDZCQUF1Qm1CLGdCQUFnQjtBQUFBLElBQzNDO0FBQUEsRUFDSjtBQUdBLFFBQU1PLDJCQUEyQkEsQ0FBQ0MsV0FBbUI7QUFDakQsVUFBTUMsb0JBQW9CL0IsbUJBQW1COEIsTUFBTSxLQUFLO0FBQ3hELFVBQU1FLHNCQUFzQkQsa0JBQWtCTCxJQUFJLENBQUFsQixNQUFLQSxFQUFFWSxFQUFFO0FBQzNELFVBQU1hLG9CQUFvQkMsZ0NBQWdDSixNQUFNO0FBRWhFM0IsMkJBQXVCLENBQUFlLFNBQVE7QUFDM0IsVUFBSWUsbUJBQW1CO0FBRW5CLGVBQU9mLEtBQUtDLE9BQU8sQ0FBQUMsT0FBTSxDQUFDWSxvQkFBb0JHLFNBQVNmLEVBQUUsQ0FBQztBQUFBLE1BQzlELE9BQU87QUFFSCxjQUFNZ0IsU0FBUyxJQUFJQyxJQUFJbkIsSUFBSTtBQUMzQmMsNEJBQW9CTSxRQUFRLENBQUFsQixPQUFNZ0IsT0FBT0csSUFBSW5CLEVBQUUsQ0FBQztBQUNoRCxlQUFPb0IsTUFBTUMsS0FBS0wsTUFBTTtBQUFBLE1BQzVCO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUdBLFFBQU1SLDRCQUE0QkEsTUFBTTtBQUNwQyxVQUFNTixtQkFBbUJDLE9BQU9DLE9BQU94QixrQkFBa0IsRUFBRXlCLEtBQUssRUFBRUMsSUFBSSxDQUFBbEIsTUFBS0EsRUFBRVksRUFBRTtBQUMvRSxXQUFPRSxpQkFBaUJvQixTQUFTLEtBQUtwQixpQkFBaUJxQixNQUFNLENBQUF2QixPQUFNbEIsb0JBQW9CaUMsU0FBU2YsRUFBRSxDQUFDO0FBQUEsRUFDdkc7QUFHQSxRQUFNYyxrQ0FBa0NBLENBQUNKLFdBQW1CO0FBQ3hELFVBQU1DLG9CQUFvQi9CLG1CQUFtQjhCLE1BQU0sS0FBSztBQUN4RCxXQUFPQyxrQkFBa0JXLFNBQVMsS0FBS1gsa0JBQWtCWSxNQUFNLENBQUFuQyxNQUFLTixvQkFBb0JpQyxTQUFTM0IsRUFBRVksRUFBRSxDQUFDO0FBQUEsRUFDMUc7QUFFQSxRQUFNd0IsYUFBYSxZQUFZO0FBRTNCLFVBQU1DLFdBQVcsRUFBRXBDLE1BQU1MLGFBQWFHLGFBQWFMLG9CQUFvQjtBQUN2RSxVQUFNNEMsYUFBYSxNQUFNbkQsU0FBU2tELFFBQWU7QUFDakQsUUFBSUMsWUFBWTtBQUNacEQsZUFBUyx5QkFBeUI7QUFBQSxJQUN0QztBQUFBLEVBQ0o7QUFFQSxNQUFJSSxtQkFBb0IsUUFBTyx1QkFBQyxTQUFJLG9DQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUI7QUFFeEQ7QUFBQTtBQUFBLElBRUksdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEUsdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsZUFBYyxXQUFVLDJDQUF5QyxpQ0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILE9BQU9NO0FBQUFBLGNBQ1AsVUFBVSxDQUFDMkMsTUFBTTFDLGVBQWUwQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsY0FDOUMsV0FBVTtBQUFBLGNBQXNKLGNBQWE7QUFBQTtBQUFBLFlBTGpMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtzTDtBQUFBLGFBVDFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLHdCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFTNUI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVE8sb0NBQTBCLElBQUksd0JBQXdCO0FBQUE7QUFBQSxZQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDVkwsaUJBQU8yQixRQUFRbEQsa0JBQWtCLEVBQUUwQjtBQUFBQSxVQUFJLENBQUMsQ0FBQ0ksUUFBUXZCLFdBQVcsTUFDekQsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSw2QkFBNkJqQjtBQUFBQSx5Q0FBeUJ3QyxNQUFNO0FBQUEsZ0JBQUU7QUFBQSxtQkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkU7QUFBQSxjQUM3RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNRCx5QkFBeUJDLE1BQU07QUFBQSxrQkFDOUMsV0FBVTtBQUFBLGtCQUVUSSwwQ0FBZ0NKLE1BQU0sSUFBSSxjQUFjO0FBQUE7QUFBQSxnQkFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsdUVBQ1Z2QyxvQ0FBMEJ1QyxRQUFRdkIsV0FBVyxFQUFFbUI7QUFBQUEsY0FBSSxDQUFBeUIsZUFDaEQsdUJBQUMsU0FBd0IsV0FBVSxxQkFDL0I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxJQUFJLGNBQWNBLFdBQVcvQixFQUFFO0FBQUEsb0JBQy9CLE1BQUs7QUFBQSxvQkFDTCxPQUFPK0IsV0FBVy9CO0FBQUFBLG9CQUNsQixTQUFTbEIsb0JBQW9CaUMsU0FBU2dCLFdBQVcvQixFQUFFO0FBQUEsb0JBQ25ELFVBQVUsQ0FBQzJCLE1BQU1oQyx1QkFBdUJvQyxXQUFXL0IsSUFBSTJCLEVBQUVDLE9BQU8vQixPQUFPO0FBQUEsb0JBQ3ZFLFdBQVU7QUFBQSxvQkFBd0UsY0FBYTtBQUFBO0FBQUEsa0JBTm5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNd0c7QUFBQSxnQkFDeEcsdUJBQUMsV0FBTSxTQUFTLGNBQWNrQyxXQUFXL0IsRUFBRSxJQUFJLFdBQVUsOEJBQ3BEL0IsNkJBQW1COEQsV0FBVzFDLElBQUksS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVZNMEMsV0FBVy9CLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxZQUNILEtBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDBCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsZUEzQjlCVSxRQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsUUFDSCxLQS9CTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0EzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTXBDLFNBQVMseUJBQXlCO0FBQUEsWUFDakQsV0FBVTtBQUFBLFlBQW1IO0FBQUE7QUFBQSxVQUhqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNrRDtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFnSTtBQUFBO0FBQUEsVUFIOUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBN0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RUE7QUFBQTtBQUVSO0FBQUVuRCxHQXJLV0QsbUJBQWlCO0FBQUEsVUFDVFIsYUFDSUUsV0FBVztBQUFBO0FBQUFrRSxLQUZ2QjVEO0FBQWlCLElBQUE0RDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInByb2ZpbGVzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJnZXRQZXJtaXNzaW9ucyIsImdyb3VwQnkiLCJnZXRQZXJtaXNzaW9uTGFiZWwiLCJnZXRQZXJtaXNzaW9uTW9kdWxlVGl0bGUiLCJzb3J0UGVybWlzc2lvbnNGb3JEaXNwbGF5IiwiUHJvZmlsZUNyZWF0ZVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwic2F2ZUl0ZW0iLCJfIiwic2V0QWxsUGVybWlzc2lvbnMiLCJsb2FkaW5nUGVybWlzc2lvbnMiLCJzZXRMb2FkaW5nUGVybWlzc2lvbnMiLCJncm91cGVkUGVybWlzc2lvbnMiLCJzZXRHcm91cGVkUGVybWlzc2lvbnMiLCJzZWxlY3RlZFBlcm1pc3Npb25zIiwic2V0U2VsZWN0ZWRQZXJtaXNzaW9ucyIsInByb2ZpbGVOYW1lIiwic2V0UHJvZmlsZU5hbWUiLCJ0aGVuIiwicGVybWlzc2lvbnMiLCJwIiwibmFtZSIsInNwbGl0IiwiY2F0Y2giLCJlcnJvciIsImNvbnNvbGUiLCJmaW5hbGx5IiwiaGFuZGxlUGVybWlzc2lvbkNoYW5nZSIsInBlcm1pc3Npb25JZCIsImNoZWNrZWQiLCJwcmV2IiwiZmlsdGVyIiwiaWQiLCJoYW5kbGVTZWxlY3RBbGwiLCJhbGxQZXJtaXNzaW9uSWRzIiwiT2JqZWN0IiwidmFsdWVzIiwiZmxhdCIsIm1hcCIsImFsbFNlbGVjdGVkIiwiYXJlQWxsUGVybWlzc2lvbnNTZWxlY3RlZCIsImhhbmRsZVNlbGVjdEFsbEZvckVudGl0eSIsImVudGl0eSIsImVudGl0eVBlcm1pc3Npb25zIiwiZW50aXR5UGVybWlzc2lvbklkcyIsImFsbEVudGl0eVNlbGVjdGVkIiwiYXJlQWxsRW50aXR5UGVybWlzc2lvbnNTZWxlY3RlZCIsImluY2x1ZGVzIiwibmV3U2V0IiwiU2V0IiwiZm9yRWFjaCIsImFkZCIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsImV2ZXJ5IiwiaGFuZGxlU2F2ZSIsInNhdmVEYXRhIiwibmV3UHJvZmlsZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImVudHJpZXMiLCJwZXJtaXNzaW9uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZmlsZUNyZWF0ZVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgcHJvZmlsZXNNb2R1bGVDb25maWcsIHR5cGUgUHJvZmlsZSwgdHlwZSBQZXJtaXNzaW9uIH0gZnJvbSAnLi4vcHJvZmlsZXMuY29uZmlnLnRzeCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldFBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBncm91cEJ5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvaGVscGVycyc7XG5pbXBvcnQgeyBnZXRQZXJtaXNzaW9uTGFiZWwsIGdldFBlcm1pc3Npb25Nb2R1bGVUaXRsZSwgc29ydFBlcm1pc3Npb25zRm9yRGlzcGxheSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RyYW5zbGF0aW9ucy50cyc7XG5cbmV4cG9ydCBjb25zdCBQcm9maWxlQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08UHJvZmlsZT4ocHJvZmlsZXNNb2R1bGVDb25maWcpO1xuICAgIGNvbnN0IFtfLCBzZXRBbGxQZXJtaXNzaW9uc10gPSB1c2VTdGF0ZTxQZXJtaXNzaW9uW10+KFtdKTtcbiAgICBjb25zdCBbbG9hZGluZ1Blcm1pc3Npb25zLCBzZXRMb2FkaW5nUGVybWlzc2lvbnNdID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2dyb3VwZWRQZXJtaXNzaW9ucywgc2V0R3JvdXBlZFBlcm1pc3Npb25zXSA9IHVzZVN0YXRlPHsgW2tleTogc3RyaW5nXTogUGVybWlzc2lvbltdIH0+KHt9KTtcbiAgICBjb25zdCBbc2VsZWN0ZWRQZXJtaXNzaW9ucywgc2V0U2VsZWN0ZWRQZXJtaXNzaW9uc10gPSB1c2VTdGF0ZTxudW1iZXJbXT4oW10pO1xuXG4gICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBFc3RhZG8gbG9jYWwgcGFyYSBlbCBub21icmUgZGVsIHBlcmZpbFxuICAgIGNvbnN0IFtwcm9maWxlTmFtZSwgc2V0UHJvZmlsZU5hbWVdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgZ2V0UGVybWlzc2lvbnM8UGVybWlzc2lvbj4oKVxuICAgICAgICAgICAgLnRoZW4ocGVybWlzc2lvbnMgPT4ge1xuICAgICAgICAgICAgICAgIHNldEFsbFBlcm1pc3Npb25zKHBlcm1pc3Npb25zKTtcbiAgICAgICAgICAgICAgICBzZXRHcm91cGVkUGVybWlzc2lvbnMoZ3JvdXBCeShwZXJtaXNzaW9ucywgKHApID0+IHAubmFtZS5zcGxpdCgnLicpWzBdKSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKGVycm9yID0+IGNvbnNvbGUuZXJyb3IoXCJFcnJvciBsb2FkaW5nIHBlcm1pc3Npb25zOlwiLCBlcnJvcikpXG4gICAgICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nUGVybWlzc2lvbnMoZmFsc2UpKTtcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBoYW5kbGVQZXJtaXNzaW9uQ2hhbmdlID0gKHBlcm1pc3Npb25JZDogbnVtYmVyLCBjaGVja2VkOiBib29sZWFuKSA9PiB7XG4gICAgICAgIHNldFNlbGVjdGVkUGVybWlzc2lvbnMocHJldiA9PlxuICAgICAgICAgICAgY2hlY2tlZCA/IFsuLi5wcmV2LCBwZXJtaXNzaW9uSWRdIDogcHJldi5maWx0ZXIoaWQgPT4gaWQgIT09IHBlcm1pc3Npb25JZClcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgLy8g4pyFIEhhbmRsZXIgcGFyYSBzZWxlY2Npb25hci9kZXNlbGVjY2lvbmFyIHRvZG9zIGxvcyBwZXJtaXNvc1xuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEFsbCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgYWxsUGVybWlzc2lvbklkcyA9IE9iamVjdC52YWx1ZXMoZ3JvdXBlZFBlcm1pc3Npb25zKS5mbGF0KCkubWFwKHAgPT4gcC5pZCk7XG4gICAgICAgIGNvbnN0IGFsbFNlbGVjdGVkID0gYXJlQWxsUGVybWlzc2lvbnNTZWxlY3RlZCgpO1xuXG4gICAgICAgIGlmIChhbGxTZWxlY3RlZCkge1xuICAgICAgICAgICAgLy8gU2kgdG9kb3MgZXN0w6FuIHNlbGVjY2lvbmFkb3MsIGRlc2VsZWNjaW9uYXIgdG9kb3NcbiAgICAgICAgICAgIHNldFNlbGVjdGVkUGVybWlzc2lvbnMoW10pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gU2kgbm8gdG9kb3MgZXN0w6FuIHNlbGVjY2lvbmFkb3MsIHNlbGVjY2lvbmFyIHRvZG9zXG4gICAgICAgICAgICBzZXRTZWxlY3RlZFBlcm1pc3Npb25zKGFsbFBlcm1pc3Npb25JZHMpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIOKchSBIYW5kbGVyIHBhcmEgc2VsZWNjaW9uYXIvZGVzZWxlY2Npb25hciB0b2RvcyBsb3MgcGVybWlzb3MgZGUgdW5hIGVudGlkYWQgZXNwZWPDrWZpY2FcbiAgICBjb25zdCBoYW5kbGVTZWxlY3RBbGxGb3JFbnRpdHkgPSAoZW50aXR5OiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgZW50aXR5UGVybWlzc2lvbnMgPSBncm91cGVkUGVybWlzc2lvbnNbZW50aXR5XSB8fCBbXTtcbiAgICAgICAgY29uc3QgZW50aXR5UGVybWlzc2lvbklkcyA9IGVudGl0eVBlcm1pc3Npb25zLm1hcChwID0+IHAuaWQpO1xuICAgICAgICBjb25zdCBhbGxFbnRpdHlTZWxlY3RlZCA9IGFyZUFsbEVudGl0eVBlcm1pc3Npb25zU2VsZWN0ZWQoZW50aXR5KTtcblxuICAgICAgICBzZXRTZWxlY3RlZFBlcm1pc3Npb25zKHByZXYgPT4ge1xuICAgICAgICAgICAgaWYgKGFsbEVudGl0eVNlbGVjdGVkKSB7XG4gICAgICAgICAgICAgICAgLy8gU2kgdG9kb3MgbG9zIGRlIGxhIGVudGlkYWQgZXN0w6FuIHNlbGVjY2lvbmFkb3MsIGRlc2VsZWNjaW9uYXJsb3NcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJldi5maWx0ZXIoaWQgPT4gIWVudGl0eVBlcm1pc3Npb25JZHMuaW5jbHVkZXMoaWQpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gU2kgbm8gdG9kb3MgZXN0w6FuIHNlbGVjY2lvbmFkb3MsIHNlbGVjY2lvbmFyIHRvZG9zIGxvcyBkZSBsYSBlbnRpZGFkXG4gICAgICAgICAgICAgICAgY29uc3QgbmV3U2V0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgICAgICAgICAgICBlbnRpdHlQZXJtaXNzaW9uSWRzLmZvckVhY2goaWQgPT4gbmV3U2V0LmFkZChpZCkpO1xuICAgICAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKG5ld1NldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICAvLyDinIUgVmVyaWZpY2FyIHNpIHRvZG9zIGxvcyBwZXJtaXNvcyBlc3TDoW4gc2VsZWNjaW9uYWRvc1xuICAgIGNvbnN0IGFyZUFsbFBlcm1pc3Npb25zU2VsZWN0ZWQgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGFsbFBlcm1pc3Npb25JZHMgPSBPYmplY3QudmFsdWVzKGdyb3VwZWRQZXJtaXNzaW9ucykuZmxhdCgpLm1hcChwID0+IHAuaWQpO1xuICAgICAgICByZXR1cm4gYWxsUGVybWlzc2lvbklkcy5sZW5ndGggPiAwICYmIGFsbFBlcm1pc3Npb25JZHMuZXZlcnkoaWQgPT4gc2VsZWN0ZWRQZXJtaXNzaW9ucy5pbmNsdWRlcyhpZCkpO1xuICAgIH07XG5cbiAgICAvLyDinIUgVmVyaWZpY2FyIHNpIHRvZG9zIGxvcyBwZXJtaXNvcyBkZSB1bmEgZW50aWRhZCBlc3TDoW4gc2VsZWNjaW9uYWRvc1xuICAgIGNvbnN0IGFyZUFsbEVudGl0eVBlcm1pc3Npb25zU2VsZWN0ZWQgPSAoZW50aXR5OiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgZW50aXR5UGVybWlzc2lvbnMgPSBncm91cGVkUGVybWlzc2lvbnNbZW50aXR5XSB8fCBbXTtcbiAgICAgICAgcmV0dXJuIGVudGl0eVBlcm1pc3Npb25zLmxlbmd0aCA+IDAgJiYgZW50aXR5UGVybWlzc2lvbnMuZXZlcnkocCA9PiBzZWxlY3RlZFBlcm1pc3Npb25zLmluY2x1ZGVzKHAuaWQpKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gVXNhbW9zIGxvcyBlc3RhZG9zIGxvY2FsZXMgcGFyYSBjb25zdHJ1aXIgZWwgcGF5bG9hZFxuICAgICAgICBjb25zdCBzYXZlRGF0YSA9IHsgbmFtZTogcHJvZmlsZU5hbWUsIHBlcm1pc3Npb25zOiBzZWxlY3RlZFBlcm1pc3Npb25zIH07XG4gICAgICAgIGNvbnN0IG5ld1Byb2ZpbGUgPSBhd2FpdCBzYXZlSXRlbShzYXZlRGF0YSBhcyBhbnkpO1xuICAgICAgICBpZiAobmV3UHJvZmlsZSkge1xuICAgICAgICAgICAgbmF2aWdhdGUoJy9jb25maWd1cmFjaW9uL3Byb2ZpbGVzJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmdQZXJtaXNzaW9ucykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gcGVybWlzb3MuLi48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAvLyBZYSBubyB1c2Ftb3MgR2VuZXJpY0Zvcm1QYWdlLCBjb25zdHJ1aW1vcyBlbCBmb3JtdWxhcmlvIGRpcmVjdGFtZW50ZSBhcXXDrVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02XCI+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q3JlYXIgTnVldm8gUGVyZmlsPC9oMT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwcm9maWxlTmFtZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTm9tYnJlIGRlbCBQZXJmaWxcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInByb2ZpbGVOYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwcm9maWxlTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJvZmlsZU5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBtdC0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+UGVybWlzb3M8L2gyPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlbGVjdEFsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmRpZ28tNjAwIGJnLWluZGlnby01MCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1pbmRpZ28tMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FyZUFsbFBlcm1pc3Npb25zU2VsZWN0ZWQoKSA/ICdEZXNlbGVjY2lvbmFyIFRvZG9zJyA6ICdTZWxlY2Npb25hciBUb2Rvcyd9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhncm91cGVkUGVybWlzc2lvbnMpLm1hcCgoW2VudGl0eSwgcGVybWlzc2lvbnNdKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZW50aXR5fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPntnZXRQZXJtaXNzaW9uTW9kdWxlVGl0bGUoZW50aXR5KX06PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RBbGxGb3JFbnRpdHkoZW50aXR5KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTYwMCBiZy1pbmRpZ28tNTAgYm9yZGVyIGJvcmRlci1pbmRpZ28tMjAwIHJvdW5kZWQgaG92ZXI6YmctaW5kaWdvLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcmVBbGxFbnRpdHlQZXJtaXNzaW9uc1NlbGVjdGVkKGVudGl0eSkgPyAnRGVzbWFyY2FyJyA6ICdNYXJjYXIgVG9kb3MnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLXgtNCBnYXAteS0yIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NvcnRQZXJtaXNzaW9uc0ZvckRpc3BsYXkoZW50aXR5LCBwZXJtaXNzaW9ucykubWFwKHBlcm1pc3Npb24gPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3Blcm1pc3Npb24uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgcGVybWlzc2lvbi0ke3Blcm1pc3Npb24uaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Blcm1pc3Npb24uaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkUGVybWlzc2lvbnMuaW5jbHVkZXMocGVybWlzc2lvbi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlUGVybWlzc2lvbkNoYW5nZShwZXJtaXNzaW9uLmlkLCBlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDAgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YHBlcm1pc3Npb24tJHtwZXJtaXNzaW9uLmlkfWB9IGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRQZXJtaXNzaW9uTGFiZWwocGVybWlzc2lvbi5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJteS0yIGJvcmRlci1ncmF5LTIwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2NvbmZpZ3VyYWNpb24vcHJvZmlsZXMnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgbWwtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ3JlYXIgUGVyZmlsXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wcm9maWxlcy9wYWdlcy9Qcm9maWxlQ3JlYXRlUGFnZS50c3gifQ==