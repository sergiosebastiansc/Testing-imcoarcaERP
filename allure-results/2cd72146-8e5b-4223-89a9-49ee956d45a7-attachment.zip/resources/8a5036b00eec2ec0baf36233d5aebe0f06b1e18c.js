import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cheques/pages/ChequesDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cheques/pages/ChequesDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { IoArrowBack } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaUndo, FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { patch } from "/src/services/apiService.ts";
import { chequesModuleConfig } from "/src/features/cheques/cheques.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const ChequesDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: check, loading, error } = useCrudItem(chequesModuleConfig, id);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [returnReason, setReturnReason] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const handleReturnCheck = async () => {
    if (!returnReason.trim()) {
      toast.warn("Debe indicar la razón de devolución.");
      return;
    }
    if (!id) return;
    setIsSaving(true);
    try {
      await patch(chequesModuleConfig.endpoint, id, {
        is_returned: true,
        observation_return: returnReason.trim()
      });
      toast.success("Cheque marcado como devuelto.");
      setIsModalOpen(false);
      setReturnReason("");
      window.location.reload();
    } catch (e) {
      console.error(e);
      toast.error("Error al marcar la devolución del cheque.");
    } finally {
      setIsSaving(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
    lineNumber: 67,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
    lineNumber: 68,
    columnNumber: 21
  }, this);
  if (!check) return /* @__PURE__ */ jsxDEV("div", { children: "Cheque no encontrado." }, void 0, false, {
    fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
    lineNumber: 69,
    columnNumber: 22
  }, this);
  const DetailField = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-sm font-medium text-gray-500", children: label }, void 0, false, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 73,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: value || /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 74,
      columnNumber: 68
    }, this) }, void 0, false, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 74,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
    lineNumber: 72,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-6 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
        "Cheque Recibido:",
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-indigo-600", children: [
          "#",
          check.check_number
        ] }, void 0, true, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 85,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 83,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 82,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-3 space-x-3 sm:mt-0", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(getListReturnPath(chequesModuleConfig.baseRoute)),
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50",
            children: [
              /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
                lineNumber: 94,
                columnNumber: 25
              }, this),
              "Volver"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 89,
            columnNumber: 21
          },
          this
        ),
        !check.is_returned && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setIsModalOpen(true),
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700",
            children: [
              /* @__PURE__ */ jsxDEV(FaUndo, { className: "w-4 h-4 mr-2" }, void 0, false, {
                fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
                lineNumber: 103,
                columnNumber: 29
              }, this),
              "Devolver Cheque"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 98,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 88,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 81,
      columnNumber: 13
    }, this),
    check.is_returned && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-4 bg-red-50 border border-red-200 rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 text-sm font-semibold rounded-full bg-red-100 text-red-800", children: "Devuelto" }, void 0, false, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 114,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 113,
        columnNumber: 21
      }, this),
      check.observation_return && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-700", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Razón:" }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 118,
          columnNumber: 29
        }, this),
        " ",
        check.observation_return
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2 bg-gray-50 rounded-t-md", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: "Datos del Cheque" }, void 0, false, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 127,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 126,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-8 p-4 sm:grid-cols-2 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Nº Cheque", value: check.check_number }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 130,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Banco", value: check.bank_name }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 131,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Titular", value: check.check_holder }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 132,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "CUIT Emisor", value: check.issuer_cuit }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 133,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Referencia", value: check.reference_number }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 134,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Medio de Pago", value: check.payment_method_code }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 135,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Fecha del Cheque", value: formatValue(check.check_date, "date") }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 136,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Fecha de Vencimiento", value: formatValue(check.check_due_date, "date") }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 137,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(DetailField, { label: "Valor", value: formatValue(check.value, "currency") }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 138,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          DetailField,
          {
            label: "A la Orden",
            value: /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${check.is_to_order ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`, children: check.is_to_order ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
              lineNumber: 142,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 139,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DetailField,
          {
            label: "Entregado",
            value: /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${check.is_delivered ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`, children: check.is_delivered ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
              lineNumber: 150,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 147,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          DetailField,
          {
            label: "Devuelto",
            value: /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${check.is_returned ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}`, children: check.is_returned ? "Sí" : "No" }, void 0, false, {
              fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
              lineNumber: 158,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 155,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 129,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 125,
      columnNumber: 13
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-xl w-full max-w-md mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900", children: "Devolver Cheque" }, void 0, false, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 171,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: [
          "Cheque #",
          check.check_number,
          " - ",
          formatValue(check.value, "currency")
        ] }, void 0, true, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 172,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 170,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
          "Razón de devolución ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 178,
            columnNumber: 53
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
          lineNumber: 177,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 4,
            value: returnReason,
            onChange: (e) => setReturnReason(e.target.value),
            placeholder: "Indique el motivo de la devolución...",
            className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm",
            autoFocus: true,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 180,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 176,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 px-6 py-4 border-t bg-gray-50 rounded-b-lg", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setIsModalOpen(false);
              setReturnReason("");
            },
            disabled: isSaving,
            className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50",
            children: "Cancelar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 189,
            columnNumber: 29
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleReturnCheck,
            disabled: isSaving || !returnReason.trim(),
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700 disabled:opacity-50",
            children: [
              isSaving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-4 h-4 mr-2 animate-spin" }, void 0, false, {
                fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
                lineNumber: 203,
                columnNumber: 45
              }, this) : /* @__PURE__ */ jsxDEV(FaUndo, { className: "w-4 h-4 mr-2" }, void 0, false, {
                fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
                lineNumber: 203,
                columnNumber: 99
              }, this),
              "Confirmar Devolución"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
            lineNumber: 197,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
        lineNumber: 188,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 169,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/cheques/pages/ChequesDetailPage.tsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
};
_s(ChequesDetailPage, "v7EaXv7zsZ7Y4Uh/8WzMPKkFmxw=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ChequesDetailPage;
var _c;
$RefreshReg$(_c, "ChequesDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cheques/pages/ChequesDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cheques/pages/ChequesDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0N3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvQ3hCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxtQkFBbUI7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsUUFBUUMsaUJBQWlCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLDJCQUErQztBQUN4RCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLEVBQUVDLEdBQUcsSUFBSWQsVUFBMEI7QUFDekMsUUFBTWUsV0FBV2QsWUFBWTtBQUM3QixRQUFNLEVBQUVlLE1BQU1DLE9BQU9DLFNBQVNDLE1BQU0sSUFBSWIsWUFBMkJFLHFCQUFxQk0sRUFBRTtBQUUxRixRQUFNLENBQUNNLGFBQWFDLGNBQWMsSUFBSXRCLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN1QixjQUFjQyxlQUFlLElBQUl4QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDeUIsVUFBVUMsV0FBVyxJQUFJMUIsU0FBUyxLQUFLO0FBRTlDLFFBQU0yQixvQkFBb0IsWUFBWTtBQUNsQyxRQUFJLENBQUNKLGFBQWFLLEtBQUssR0FBRztBQUN0QnpCLFlBQU0wQixLQUFLLHNDQUFzQztBQUNqRDtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUNkLEdBQUk7QUFFVFcsZ0JBQVksSUFBSTtBQUNoQixRQUFJO0FBQ0EsWUFBTWxCLE1BQXFCQyxvQkFBb0JxQixVQUFVZixJQUFJO0FBQUEsUUFDekRnQixhQUFhO0FBQUEsUUFDYkMsb0JBQW9CVCxhQUFhSyxLQUFLO0FBQUEsTUFDMUMsQ0FBQztBQUNEekIsWUFBTThCLFFBQVEsK0JBQStCO0FBQzdDWCxxQkFBZSxLQUFLO0FBQ3BCRSxzQkFBZ0IsRUFBRTtBQUVsQlUsYUFBT0MsU0FBU0MsT0FBTztBQUFBLElBQzNCLFNBQVNDLEdBQUc7QUFDUkMsY0FBUWxCLE1BQU1pQixDQUFDO0FBQ2ZsQyxZQUFNaUIsTUFBTSwyQ0FBMkM7QUFBQSxJQUMzRCxVQUFDO0FBQ0dNLGtCQUFZLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFFQSxNQUFJUCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLE1BQU8sUUFBTyx1QkFBQyxTQUFJLHFDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEI7QUFFN0MsUUFBTXFCLGNBQWNBLENBQUMsRUFBRUMsT0FBT0MsTUFBaUQsTUFDM0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHFDQUFxQ0QsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUN6RCx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDQyxtQkFBUyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0c7QUFBQSxPQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFHSixTQUNJLHVCQUFDLFNBQUksV0FBVSw0Q0FFWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBLDZCQUFDLFNBQ0csaUNBQUMsUUFBRyxXQUFVLGlEQUErQztBQUFBO0FBQUEsUUFDeEM7QUFBQSxRQUNqQix1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxVQUFFdkIsTUFBTXdCO0FBQUFBLGFBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0xQixTQUFTSixrQkFBa0JILG9CQUFvQmtDLFNBQVMsQ0FBQztBQUFBLFlBQ3hFLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsZUFBWSxXQUFVLHdCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFDQyxDQUFDekIsTUFBTWEsZUFDSjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNVCxlQUFlLElBQUk7QUFBQSxZQUNsQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUxwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBakJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsSUFHQ0osTUFBTWEsZUFDSCx1QkFBQyxTQUFJLFdBQVUsdURBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQ1gsaUNBQUMsVUFBSyxXQUFVLHdFQUF1RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRixLQURuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDYixNQUFNYyxzQkFDSCx1QkFBQyxPQUFFLFdBQVUsNkJBQ1Q7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZUFBYyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFFBQU87QUFBQSxRQUFFZCxNQUFNYztBQUFBQSxXQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBSUosdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFFBQUcsV0FBVSxxQ0FBb0MsZ0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0UsS0FEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsc0VBQ1Y7QUFBQSwrQkFBQyxlQUFZLE9BQU0sYUFBWSxPQUFPZCxNQUFNd0IsZ0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUN6RCx1QkFBQyxlQUFZLE9BQU0sU0FBUSxPQUFPeEIsTUFBTTBCLGFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUNsRCx1QkFBQyxlQUFZLE9BQU0sV0FBVSxPQUFPMUIsTUFBTTJCLGdCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVEO0FBQUEsUUFDdkQsdUJBQUMsZUFBWSxPQUFNLGVBQWMsT0FBTzNCLE1BQU00QixlQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsZUFBWSxPQUFNLGNBQWEsT0FBTzVCLE1BQU02QixvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RDtBQUFBLFFBQzlELHVCQUFDLGVBQVksT0FBTSxpQkFBZ0IsT0FBTzdCLE1BQU04Qix1QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFLHVCQUFDLGVBQVksT0FBTSxvQkFBbUIsT0FBT3JDLFlBQVlPLE1BQU0rQixZQUFZLE1BQU0sS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFFBQ25GLHVCQUFDLGVBQVksT0FBTSx3QkFBdUIsT0FBT3RDLFlBQVlPLE1BQU1nQyxnQkFBZ0IsTUFBTSxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJGO0FBQUEsUUFDM0YsdUJBQUMsZUFBWSxPQUFNLFNBQVEsT0FBT3ZDLFlBQVlPLE1BQU11QixPQUFPLFVBQVUsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFFBQ3ZFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUFNO0FBQUEsWUFDTixPQUNJLHVCQUFDLFVBQUssV0FBVyxpRUFBaUV2QixNQUFNaUMsY0FBYyxnQ0FBZ0MsMkJBQTJCLElBQzVKakMsZ0JBQU1pQyxjQUFjLE9BQU8sUUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUEsVUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNSztBQUFBLFFBRUw7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQU07QUFBQSxZQUNOLE9BQ0ksdUJBQUMsVUFBSyxXQUFXLGlFQUFpRWpDLE1BQU1rQyxlQUFlLGdDQUFnQywyQkFBMkIsSUFDN0psQyxnQkFBTWtDLGVBQWUsT0FBTyxRQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQSxVQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1LO0FBQUEsUUFFTDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTTtBQUFBLFlBQ04sT0FDSSx1QkFBQyxVQUFLLFdBQVcsaUVBQWlFbEMsTUFBTWEsY0FBYyw0QkFBNEIsMkJBQTJCLElBQ3hKYixnQkFBTWEsY0FBYyxPQUFPLFFBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBLFVBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUs7QUFBQSxXQWhDVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0F0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLElBR0NWLGVBQ0csdUJBQUMsU0FBSSxXQUFVLG1FQUNYLGlDQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCO0FBQUE7QUFBQSxVQUM1QkgsTUFBTXdCO0FBQUFBLFVBQWE7QUFBQSxVQUFJL0IsWUFBWU8sTUFBTXVCLE9BQU8sVUFBVTtBQUFBLGFBRHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSxnREFBOEM7QUFBQTtBQUFBLFVBQ3ZDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxhQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFNO0FBQUEsWUFDTixPQUFPbEI7QUFBQUEsWUFDUCxVQUFVLENBQUNjLE1BQU1iLGdCQUFnQmEsRUFBRWdCLE9BQU9aLEtBQUs7QUFBQSxZQUMvQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUEsWUFDVixXQUFTO0FBQUEsWUFBQyxjQUFhO0FBQUE7QUFBQSxVQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNZ0M7QUFBQSxXQVZwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5RUFDWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU07QUFBRW5CLDZCQUFlLEtBQUs7QUFBR0UsOEJBQWdCLEVBQUU7QUFBQSxZQUFHO0FBQUEsWUFDN0QsVUFBVUM7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFBdUk7QUFBQTtBQUFBLFVBSnJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU0U7QUFBQUEsWUFDVCxVQUFVRixZQUFZLENBQUNGLGFBQWFLLEtBQUs7QUFBQSxZQUN6QyxXQUFVO0FBQUEsWUFFVEg7QUFBQUEseUJBQVcsdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRCxJQUFNLHVCQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBLFVBTnpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLFNBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0EsS0F2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdDQTtBQUFBLE9BaklSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSUE7QUFFUjtBQUFFWCxHQXBMV0QsbUJBQWlCO0FBQUEsVUFDWFosV0FDRUMsYUFDdUJLLFdBQVc7QUFBQTtBQUFBK0MsS0FIMUN6QztBQUFpQixJQUFBeUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsIklvQXJyb3dCYWNrIiwiRmFVbmRvIiwiRmFTcGlubmVyIiwidXNlQ3J1ZEl0ZW0iLCJwYXRjaCIsImNoZXF1ZXNNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJDaGVxdWVzRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJjaGVjayIsImxvYWRpbmciLCJlcnJvciIsImlzTW9kYWxPcGVuIiwic2V0SXNNb2RhbE9wZW4iLCJyZXR1cm5SZWFzb24iLCJzZXRSZXR1cm5SZWFzb24iLCJpc1NhdmluZyIsInNldElzU2F2aW5nIiwiaGFuZGxlUmV0dXJuQ2hlY2siLCJ0cmltIiwid2FybiIsImVuZHBvaW50IiwiaXNfcmV0dXJuZWQiLCJvYnNlcnZhdGlvbl9yZXR1cm4iLCJzdWNjZXNzIiwid2luZG93IiwibG9jYXRpb24iLCJyZWxvYWQiLCJlIiwiY29uc29sZSIsIkRldGFpbEZpZWxkIiwibGFiZWwiLCJ2YWx1ZSIsImNoZWNrX251bWJlciIsImJhc2VSb3V0ZSIsImJhbmtfbmFtZSIsImNoZWNrX2hvbGRlciIsImlzc3Vlcl9jdWl0IiwicmVmZXJlbmNlX251bWJlciIsInBheW1lbnRfbWV0aG9kX2NvZGUiLCJjaGVja19kYXRlIiwiY2hlY2tfZHVlX2RhdGUiLCJpc190b19vcmRlciIsImlzX2RlbGl2ZXJlZCIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoZXF1ZXNEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2sgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgRmFVbmRvLCBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHBhdGNoIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBjaGVxdWVzTW9kdWxlQ29uZmlnLCB0eXBlIFJlY2VpdmVkQ2hlY2sgfSBmcm9tICcuLi9jaGVxdWVzLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgQ2hlcXVlc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IGNoZWNrLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08UmVjZWl2ZWRDaGVjaz4oY2hlcXVlc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3JldHVyblJlYXNvbiwgc2V0UmV0dXJuUmVhc29uXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbaXNTYXZpbmcsIHNldElzU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IGhhbmRsZVJldHVybkNoZWNrID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXJldHVyblJlYXNvbi50cmltKCkpIHtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0RlYmUgaW5kaWNhciBsYSByYXrDs24gZGUgZGV2b2x1Y2nDs24uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpZCkgcmV0dXJuO1xuXG4gICAgICAgIHNldElzU2F2aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgcGF0Y2g8UmVjZWl2ZWRDaGVjaz4oY2hlcXVlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgaWQsIHtcbiAgICAgICAgICAgICAgICBpc19yZXR1cm5lZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBvYnNlcnZhdGlvbl9yZXR1cm46IHJldHVyblJlYXNvbi50cmltKCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0NoZXF1ZSBtYXJjYWRvIGNvbW8gZGV2dWVsdG8uJyk7XG4gICAgICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgICAgICAgICBzZXRSZXR1cm5SZWFzb24oJycpO1xuICAgICAgICAgICAgLy8gUmVjYXJnYXIgbGEgcMOhZ2luYSBwYXJhIHJlZmxlamFyIGVsIGNhbWJpb1xuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIG1hcmNhciBsYSBkZXZvbHVjacOzbiBkZWwgY2hlcXVlLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNTYXZpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWNoZWNrKSByZXR1cm4gPGRpdj5DaGVxdWUgbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICBjb25zdCBEZXRhaWxGaWVsZCA9ICh7IGxhYmVsLCB2YWx1ZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBSZWFjdC5SZWFjdE5vZGUgfSkgPT4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj57bGFiZWx9PC9kdD5cbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e3ZhbHVlIHx8IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4tPC9zcGFuPn08L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02XCI+XG4gICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IG1iLTYgYm9yZGVyLWIgc206ZmxleCBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlIFJlY2liaWRvOnsnICd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+I3tjaGVjay5jaGVja19udW1iZXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXQtMyBzcGFjZS14LTMgc206bXQtMFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGNoZXF1ZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9BcnJvd0JhY2sgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yIC1tbC0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZvbHZlclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgeyFjaGVjay5pc19yZXR1cm5lZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctcmVkLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLXJlZC03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVVuZG8gY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXZvbHZlciBDaGVxdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBFc3RhZG8gZGUgZGV2b2x1Y2nDs24gKi99XG4gICAgICAgICAgICB7Y2hlY2suaXNfcmV0dXJuZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwLTQgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtODAwXCI+RGV2dWVsdG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7Y2hlY2sub2JzZXJ2YXRpb25fcmV0dXJuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlJhesOzbjo8L3NwYW4+IHtjaGVjay5vYnNlcnZhdGlvbl9yZXR1cm59XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogRGF0b3MgZGVsIGNoZXF1ZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ncmF5LTUwIHJvdW5kZWQtdC1tZFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+RGF0b3MgZGVsIENoZXF1ZTwvaDQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLXgtNCBnYXAteS04IHAtNCBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsRmllbGQgbGFiZWw9XCJOwrogQ2hlcXVlXCIgdmFsdWU9e2NoZWNrLmNoZWNrX251bWJlcn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbEZpZWxkIGxhYmVsPVwiQmFuY29cIiB2YWx1ZT17Y2hlY2suYmFua19uYW1lfSAvPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsRmllbGQgbGFiZWw9XCJUaXR1bGFyXCIgdmFsdWU9e2NoZWNrLmNoZWNrX2hvbGRlcn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbEZpZWxkIGxhYmVsPVwiQ1VJVCBFbWlzb3JcIiB2YWx1ZT17Y2hlY2suaXNzdWVyX2N1aXR9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxGaWVsZCBsYWJlbD1cIlJlZmVyZW5jaWFcIiB2YWx1ZT17Y2hlY2sucmVmZXJlbmNlX251bWJlcn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbEZpZWxkIGxhYmVsPVwiTWVkaW8gZGUgUGFnb1wiIHZhbHVlPXtjaGVjay5wYXltZW50X21ldGhvZF9jb2RlfSAvPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsRmllbGQgbGFiZWw9XCJGZWNoYSBkZWwgQ2hlcXVlXCIgdmFsdWU9e2Zvcm1hdFZhbHVlKGNoZWNrLmNoZWNrX2RhdGUsICdkYXRlJyl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxGaWVsZCBsYWJlbD1cIkZlY2hhIGRlIFZlbmNpbWllbnRvXCIgdmFsdWU9e2Zvcm1hdFZhbHVlKGNoZWNrLmNoZWNrX2R1ZV9kYXRlLCAnZGF0ZScpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8RGV0YWlsRmllbGQgbGFiZWw9XCJWYWxvclwiIHZhbHVlPXtmb3JtYXRWYWx1ZShjaGVjay52YWx1ZSwgJ2N1cnJlbmN5Jyl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxEZXRhaWxGaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBIGxhIE9yZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7Y2hlY2suaXNfdG9fb3JkZXIgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJyA6ICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NoZWNrLmlzX3RvX29yZGVyID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkVudHJlZ2Fkb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2NoZWNrLmlzX2RlbGl2ZXJlZCA/ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hlY2suaXNfZGVsaXZlcmVkID8gJ1PDrScgOiAnTm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPERldGFpbEZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRldnVlbHRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7Y2hlY2suaXNfcmV0dXJuZWQgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hlY2suaXNfcmV0dXJuZWQgPyAnU8OtJyA6ICdObyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1vZGFsIGRlIGRldm9sdWNpw7NuICovfVxuICAgICAgICAgICAge2lzTW9kYWxPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay81MFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXhsIHctZnVsbCBtYXgtdy1tZCBteC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkRldm9sdmVyIENoZXF1ZTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlICN7Y2hlY2suY2hlY2tfbnVtYmVyfSAtIHtmb3JtYXRWYWx1ZShjaGVjay52YWx1ZSwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSYXrDs24gZGUgZGV2b2x1Y2nDs24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmV0dXJuUmVhc29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJldHVyblJlYXNvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSW5kaXF1ZSBlbCBtb3Rpdm8gZGUgbGEgZGV2b2x1Y2nDs24uLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHgtNiBweS00IGJvcmRlci10IGJnLWdyYXktNTAgcm91bmRlZC1iLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJc01vZGFsT3BlbihmYWxzZSk7IHNldFJldHVyblJlYXNvbignJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJldHVybkNoZWNrfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmcgfHwgIXJldHVyblJlYXNvbi50cmltKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXJlZC02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1yZWQtNzAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzU2F2aW5nID8gPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTIgYW5pbWF0ZS1zcGluXCIgLz4gOiA8RmFVbmRvIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb25maXJtYXIgRGV2b2x1Y2nDs25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jaGVxdWVzL3BhZ2VzL0NoZXF1ZXNEZXRhaWxQYWdlLnRzeCJ9