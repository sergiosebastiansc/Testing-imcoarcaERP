import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/PendingSignedDocumentsTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/PendingSignedDocumentsTable.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { FaFillDrip } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { formatValue } from "/src/utils/formatters.ts";
export function PendingSignedDocumentsTable({
  title,
  rows,
  appliedAmounts,
  footerTotal,
  showTypeColumn = false,
  onAmountChange,
  onFillBalance
}) {
  if (rows.length === 0) return null;
  const colSpanBeforeTotal = showTypeColumn ? 4 : 3;
  return /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-4 border rounded-md", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-2", children: title }, void 0, false, {
      fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
      lineNumber: 61,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-96", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        showTypeColumn && /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500", children: "Tipo" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 67,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500", children: "Fecha" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 69,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500", children: "Nº de Comprobante" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 70,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500", children: "Total" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 71,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500", children: "Saldo" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 72,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 w-40", children: "Monto a Aplicar" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 73,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
        lineNumber: 65,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
        lineNumber: 64,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: rows.map(
        (row) => /* @__PURE__ */ jsxDEV("tr", { children: [
          showTypeColumn && row.type && /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm", children: /* @__PURE__ */ jsxDEV(SignedDocumentTypeBadge, { type: row.type }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 81,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 80,
            columnNumber: 15
          }, this),
          showTypeColumn && !row.type && /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm" }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 84,
            columnNumber: 65
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm", children: row.date }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 85,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm", children: row.docNumber }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 86,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-right", children: formatValue(row.total, "currency") }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 87,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "td",
            {
              className: `px-4 py-2 text-sm text-right font-medium ${row.balanceDisplay < 0 ? "text-green-600" : "text-red-600"}`,
              children: formatValue(row.balanceDisplay, "currency")
            },
            void 0,
            false,
            {
              fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
              lineNumber: 88,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                step: "0.01",
                value: appliedAmounts[row.id],
                onChange: (num) => onAmountChange(row.id, num),
                onBlur: () => onAmountChange(row.id, appliedAmounts[row.id] ?? 0),
                placeholder: "0.00",
                className: "flex-1 min-w-0 text-right px-2 py-1 border border-gray-300 rounded-md shadow-sm sm:text-sm",
                "aria-label": `Monto a aplicar para ${row.docLabel}`
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
                lineNumber: 95,
                columnNumber: 41
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onFillBalance(row.id, row.balance),
                className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors",
                title: "Llenar con saldo pendiente",
                "aria-label": `Aplicar saldo completo (${formatValue(row.balance, "currency")}) para ${row.docLabel}`,
                children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
                  lineNumber: 111,
                  columnNumber: 45
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
                lineNumber: 104,
                columnNumber: 41
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 94,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
            lineNumber: 93,
            columnNumber: 33
          }, this)
        ] }, row.id, true, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 78,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
        lineNumber: 76,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50 sticky bottom-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { colSpan: colSpanBeforeTotal, className: "px-4 py-2 text-right text-sm font-semibold", children: "Total Aplicado:" }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 120,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-right text-sm font-bold", children: formatValue(footerTotal, "currency") }, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 123,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("td", {}, void 0, false, {
          fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
          lineNumber: 124,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
        lineNumber: 119,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
        lineNumber: 118,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
      lineNumber: 63,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
      lineNumber: 62,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
}
_c = PendingSignedDocumentsTable;
export function SignedDocumentTypeBadge({ type }) {
  const isDebit = type === "DEBIT";
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${isDebit ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`,
      children: isDebit ? "Débito" : "Crédito"
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/PendingSignedDocumentsTable.tsx",
      lineNumber: 137,
      columnNumber: 5
    },
    this
  );
}
_c2 = SignedDocumentTypeBadge;
var _c, _c2;
$RefreshReg$(_c, "PendingSignedDocumentsTable");
$RefreshReg$(_c2, "SignedDocumentTypeBadge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/PendingSignedDocumentsTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/PendingSignedDocumentsTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNZOzs7Ozs7Ozs7Ozs7Ozs7O0FBekNaLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBd0JyQixnQkFBU0MsNEJBQTRCO0FBQUEsRUFDeENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGlCQUFpQjtBQUFBLEVBQ2pCQztBQUFBQSxFQUNBQztBQUM4QixHQUFHO0FBQ2pDLE1BQUlMLEtBQUtNLFdBQVcsRUFBRyxRQUFPO0FBRTlCLFFBQU1DLHFCQUFxQkosaUJBQWlCLElBQUk7QUFFaEQsU0FDSSx1QkFBQyxTQUFJLFdBQVUsOEJBQ1g7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNEJBQTRCSixtQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRDtBQUFBLElBQ2hELHVCQUFDLFNBQUksV0FBVSw0QkFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsMkJBQ2IsaUNBQUMsUUFDSUk7QUFBQUEsMEJBQ0csdUJBQUMsUUFBRyxXQUFVLHlEQUF3RCxvQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFFBRTlFLHVCQUFDLFFBQUcsV0FBVSx5REFBd0QscUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyxRQUFHLFdBQVUseURBQXdELGlDQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsUUFDdkYsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxxQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzVFLHVCQUFDLFFBQUcsV0FBVSwwREFBeUQscUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RSx1QkFBQyxRQUFHLFdBQVUsK0RBQThELCtCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJGO0FBQUEsV0FSL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1pILGVBQUtRO0FBQUFBLFFBQUksQ0FBQUMsUUFDTix1QkFBQyxRQUNJTjtBQUFBQSw0QkFBa0JNLElBQUlDLFFBQ25CLHVCQUFDLFFBQUcsV0FBVSxxQkFDVixpQ0FBQywyQkFBd0IsTUFBTUQsSUFBSUMsUUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0MsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUhQLGtCQUFrQixDQUFDTSxJQUFJQyxRQUFRLHVCQUFDLFFBQUcsV0FBVSx1QkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLFVBQ2pFLHVCQUFDLFFBQUcsV0FBVSxxQkFBcUJELGNBQUlFLFFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQkYsY0FBSUcsYUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDZixzQkFBWVksSUFBSUksT0FBTyxVQUFVLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsVUFDakY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVcsNENBQTRDSixJQUFJSyxpQkFBaUIsSUFBSSxtQkFBbUIsY0FBYztBQUFBLGNBRWhIakIsc0JBQVlZLElBQUlLLGdCQUFnQixVQUFVO0FBQUE7QUFBQSxZQUgvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1YsaUNBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2IsZUFBZVEsSUFBSU0sRUFBRTtBQUFBLGdCQUM1QixVQUFVLENBQUFDLFFBQU9aLGVBQWVLLElBQUlNLElBQUlDLEdBQUc7QUFBQSxnQkFDM0MsUUFBUSxNQUFNWixlQUFlSyxJQUFJTSxJQUFJZCxlQUFlUSxJQUFJTSxFQUFFLEtBQUssQ0FBQztBQUFBLGdCQUNoRSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLGNBQVksd0JBQXdCTixJQUFJUSxRQUFRO0FBQUE7QUFBQSxjQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPdUQ7QUFBQSxZQUV2RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1aLGNBQWNJLElBQUlNLElBQUlOLElBQUlTLE9BQU87QUFBQSxnQkFDaEQsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFDTixjQUFZLDJCQUEyQnJCLFlBQVlZLElBQUlTLFNBQVMsVUFBVSxDQUFDLFVBQVVULElBQUlRLFFBQVE7QUFBQSxnQkFFakcsaUNBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUE7QUFBQSxjQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUFwQ0tSLElBQUlNLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLE1BQ0gsS0F4Q0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLDhCQUNiLGlDQUFDLFFBQ0c7QUFBQSwrQkFBQyxRQUFHLFNBQVNSLG9CQUFvQixXQUFVLDhDQUE0QywrQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsMENBQTBDVixzQkFBWUssYUFBYSxVQUFVLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUM3Rix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBLFdBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0EvREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdFQSxLQWpFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0VBO0FBQUEsT0FwRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFFQTtBQUVSO0FBRUFpQixLQXZGZ0JyQjtBQXdGVCxnQkFBU3NCLHdCQUF3QixFQUFFVixLQUFtQyxHQUFHO0FBQzVFLFFBQU1XLFVBQVVYLFNBQVM7QUFDekIsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csV0FBVyxpRUFBaUVXLFVBQVUsNEJBQTRCLDZCQUE2QjtBQUFBLE1BRTlJQSxvQkFBVSxXQUFXO0FBQUE7QUFBQSxJQUgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQTtBQUVSO0FBQUNDLE1BVGVGO0FBQXVCLElBQUFELElBQUFHO0FBQUFDLGFBQUFKLElBQUE7QUFBQUksYUFBQUQsS0FBQSIsIm5hbWVzIjpbIkZhRmlsbERyaXAiLCJEZWNpbWFsSW5wdXQiLCJmb3JtYXRWYWx1ZSIsIlBlbmRpbmdTaWduZWREb2N1bWVudHNUYWJsZSIsInRpdGxlIiwicm93cyIsImFwcGxpZWRBbW91bnRzIiwiZm9vdGVyVG90YWwiLCJzaG93VHlwZUNvbHVtbiIsIm9uQW1vdW50Q2hhbmdlIiwib25GaWxsQmFsYW5jZSIsImxlbmd0aCIsImNvbFNwYW5CZWZvcmVUb3RhbCIsIm1hcCIsInJvdyIsInR5cGUiLCJkYXRlIiwiZG9jTnVtYmVyIiwidG90YWwiLCJiYWxhbmNlRGlzcGxheSIsImlkIiwibnVtIiwiZG9jTGFiZWwiLCJiYWxhbmNlIiwiX2MiLCJTaWduZWREb2N1bWVudFR5cGVCYWRnZSIsImlzRGViaXQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGYUZpbGxEcmlwIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgRGVjaW1hbElucHV0IH0gZnJvbSAnLi9EZWNpbWFsSW5wdXQnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB0eXBlIHsgQXBwbGllZEFtb3VudHNSZWNvcmQgfSBmcm9tICcuLi8uLi91dGlscy9hcHBsaWVkU2lnbmVkRG9jdW1lbnRzJztcblxuZXhwb3J0IHR5cGUgUGVuZGluZ1NpZ25lZERvY3VtZW50Um93ID0ge1xuICAgIGlkOiBudW1iZXI7XG4gICAgZG9jTGFiZWw6IHN0cmluZztcbiAgICBiYWxhbmNlOiBudW1iZXI7XG4gICAgZGF0ZTogc3RyaW5nO1xuICAgIGRvY051bWJlcjogc3RyaW5nO1xuICAgIHRvdGFsOiBudW1iZXI7XG4gICAgYmFsYW5jZURpc3BsYXk6IG51bWJlcjtcbiAgICB0eXBlPzogJ0RFQklUJyB8ICdDUkVESVQnO1xufTtcblxudHlwZSBQZW5kaW5nU2lnbmVkRG9jdW1lbnRzVGFibGVQcm9wcyA9IHtcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHJvd3M6IFBlbmRpbmdTaWduZWREb2N1bWVudFJvd1tdO1xuICAgIGFwcGxpZWRBbW91bnRzOiBBcHBsaWVkQW1vdW50c1JlY29yZDtcbiAgICBmb290ZXJUb3RhbDogbnVtYmVyO1xuICAgIHNob3dUeXBlQ29sdW1uPzogYm9vbGVhbjtcbiAgICBvbkFtb3VudENoYW5nZTogKGlkOiBudW1iZXIsIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpID0+IHZvaWQ7XG4gICAgb25GaWxsQmFsYW5jZTogKGlkOiBudW1iZXIsIGJhbGFuY2U6IG51bWJlcikgPT4gdm9pZDtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBQZW5kaW5nU2lnbmVkRG9jdW1lbnRzVGFibGUoe1xuICAgIHRpdGxlLFxuICAgIHJvd3MsXG4gICAgYXBwbGllZEFtb3VudHMsXG4gICAgZm9vdGVyVG90YWwsXG4gICAgc2hvd1R5cGVDb2x1bW4gPSBmYWxzZSxcbiAgICBvbkFtb3VudENoYW5nZSxcbiAgICBvbkZpbGxCYWxhbmNlLFxufTogUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlUHJvcHMpIHtcbiAgICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgY29sU3BhbkJlZm9yZVRvdGFsID0gc2hvd1R5cGVDb2x1bW4gPyA0IDogMztcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwLTQgYm9yZGVyIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIG1iLTJcIj57dGl0bGV9PC9oMz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLTk2XCI+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHN0aWNreSB0b3AtMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93VHlwZUNvbHVtbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlRpcG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+RmVjaGE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPk7CuiBkZSBDb21wcm9iYW50ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+U2FsZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdy00MFwiPk1vbnRvIGEgQXBsaWNhcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cm93cy5tYXAocm93ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyb3cuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd1R5cGVDb2x1bW4gJiYgcm93LnR5cGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNpZ25lZERvY3VtZW50VHlwZUJhZGdlIHR5cGU9e3Jvdy50eXBlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dUeXBlQ29sdW1uICYmICFyb3cudHlwZSAmJiA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc21cIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtXCI+e3Jvdy5kYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbVwiPntyb3cuZG9jTnVtYmVyfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+e2Zvcm1hdFZhbHVlKHJvdy50b3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtICR7cm93LmJhbGFuY2VEaXNwbGF5IDwgMCA/ICd0ZXh0LWdyZWVuLTYwMCcgOiAndGV4dC1yZWQtNjAwJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUocm93LmJhbGFuY2VEaXNwbGF5LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbGllZEFtb3VudHNbcm93LmlkXX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBvbkFtb3VudENoYW5nZShyb3cuaWQsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQmx1cj17KCkgPT4gb25BbW91bnRDaGFuZ2Uocm93LmlkLCBhcHBsaWVkQW1vdW50c1tyb3cuaWRdID8/IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMCB0ZXh0LXJpZ2h0IHB4LTIgcHktMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgTW9udG8gYSBhcGxpY2FyIHBhcmEgJHtyb3cuZG9jTGFiZWx9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsbEJhbGFuY2Uocm93LmlkLCByb3cuYmFsYW5jZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgcC0xLjUgdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3ZlcjpiZy1pbmRpZ28tNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJvcmRlci1pbmRpZ28tMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMbGVuYXIgY29uIHNhbGRvIHBlbmRpZW50ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BBcGxpY2FyIHNhbGRvIGNvbXBsZXRvICgke2Zvcm1hdFZhbHVlKHJvdy5iYWxhbmNlLCAnY3VycmVuY3knKX0pIHBhcmEgJHtyb3cuZG9jTGFiZWx9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUZpbGxEcmlwIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8dGZvb3QgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBzdGlja3kgYm90dG9tLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Y29sU3BhbkJlZm9yZVRvdGFsfSBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQXBsaWNhZG86XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LWJvbGRcIj57Zm9ybWF0VmFsdWUoZm9vdGVyVG90YWwsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICA8L3Rmb290PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxuLyoqIEJhZGdlIETDqWJpdG8gLyBDcsOpZGl0byByZXV0aWxpemFibGUuICovXG5leHBvcnQgZnVuY3Rpb24gU2lnbmVkRG9jdW1lbnRUeXBlQmFkZ2UoeyB0eXBlIH06IHsgdHlwZTogJ0RFQklUJyB8ICdDUkVESVQnIH0pIHtcbiAgICBjb25zdCBpc0RlYml0ID0gdHlwZSA9PT0gJ0RFQklUJztcbiAgICByZXR1cm4gKFxuICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke2lzRGViaXQgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnIDogJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCd9YH1cbiAgICAgICAgPlxuICAgICAgICAgICAge2lzRGViaXQgPyAnRMOpYml0bycgOiAnQ3LDqWRpdG8nfVxuICAgICAgICA8L3NwYW4+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlLnRzeCJ9