import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/VendorMovementsTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/VendorMovementsTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { search } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { FaFilter } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
function createDefaultDateRange() {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
  return { from: oneMonthAgo, to: today };
}
const renderVendorDocumentType = (docType) => {
  let text = "";
  switch (docType) {
    case "Purchase":
      text = "Compra";
      break;
    case "PaymentOrder":
      text = "Orden de Pago";
      break;
    default:
      text = docType;
  }
  return text;
};
const renderVendorAccountDocumentLink = (mov) => {
  let path = "#";
  const docId = mov.id;
  const docNumber = mov.document_number || (mov.document_type === "PaymentOrder" ? `OP-${docId}` : "Ver Doc.");
  switch (mov.document_type) {
    case "Purchase":
      path = `/compras/${docId}`;
      break;
    case "PaymentOrder":
      path = `/ordenes-de-pago/${docId}`;
      break;
    default:
      return /* @__PURE__ */ jsxDEV("span", { children: docNumber }, void 0, false, {
        fileName: "/app/src/components/common/VendorMovementsTab.tsx",
        lineNumber: 118,
        columnNumber: 14
      }, this);
  }
  return /* @__PURE__ */ jsxDEV(Link, { to: path, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: docNumber }, void 0, false, {
    fileName: "/app/src/components/common/VendorMovementsTab.tsx",
    lineNumber: 122,
    columnNumber: 5
  }, this);
};
export const VendorMovementsTab = ({ entityId, endpoint }) => {
  _s();
  const [movements, setMovements] = useState([]);
  const [initialBalance, setInitialBalance] = useState(null);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [draftRange, setDraftRange] = useState(createDefaultDateRange);
  const [appliedRange, setAppliedRange] = useState(createDefaultDateRange);
  const appliedRangeRef = useRef(appliedRange);
  appliedRangeRef.current = appliedRange;
  const fetchMovements = useCallback(async (pageUrl, range) => {
    setLoading(true);
    try {
      let url;
      if (pageUrl) {
        if (pageUrl.startsWith("http")) {
          const urlObj = new URL(pageUrl);
          url = urlObj.pathname.replace(/^\/api\/?/, "") + urlObj.search;
        } else {
          url = pageUrl;
        }
      } else {
        const r = range ?? appliedRangeRef.current;
        const params = new URLSearchParams();
        params.set("start_date", r.from);
        params.set("end_date", r.to);
        params.set("vendor_id", entityId.toString());
        url = `${endpoint}?${params.toString()}`;
      }
      const response = await search(url);
      setInitialBalance(response.initial_balance);
      setMovements(response.statement.data);
      setPaginationMeta(response.statement);
    } catch (error) {
      toast.error("Error al cargar los movimientos del proveedor.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [endpoint, entityId]);
  useEffect(() => {
    const defaults = createDefaultDateRange();
    setDraftRange(defaults);
    setAppliedRange(defaults);
    void fetchMovements(void 0, defaults);
  }, [fetchMovements, entityId]);
  const handlePageChange = (url) => {
    void fetchMovements(url);
  };
  const handleFilterSubmit = (e) => {
    e.preventDefault();
    if (draftRange.from === appliedRange.from && draftRange.to === appliedRange.to) {
      return;
    }
    setAppliedRange(draftRange);
    void fetchMovements(void 0, draftRange);
  };
  const columns = [
    { key: "transaction_date", label: "Fecha" },
    { key: "document_type", label: "Tipo Documento" },
    { key: "document_number", label: "No. de Factura" },
    { key: "debit", label: "Debe" },
    { key: "credit", label: "Haber" },
    { key: "balance", label: "Saldo" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleFilterSubmit, autoComplete: "off", className: "flex items-end gap-4 mb-4 p-4 bg-gray-50 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_from", className: "block text-sm font-medium text-gray-700", children: "Desde" }, void 0, false, {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 209,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_from",
            value: draftRange.from,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, from: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/VendorMovementsTab.tsx",
            lineNumber: 210,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/VendorMovementsTab.tsx",
        lineNumber: 208,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "date_to", className: "block text-sm font-medium text-gray-700", children: "Hasta" }, void 0, false, {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 218,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            id: "date_to",
            value: draftRange.to,
            onChange: (e) => setDraftRange((prev) => ({ ...prev, to: e.target.value })),
            className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/VendorMovementsTab.tsx",
            lineNumber: 219,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/VendorMovementsTab.tsx",
        lineNumber: 217,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(FaFilter, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/components/common/VendorMovementsTab.tsx",
              lineNumber: 230,
              columnNumber: 21
            }, this),
            " Filtrar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 226,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/VendorMovementsTab.tsx",
      lineNumber: 207,
      columnNumber: 13
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/app/src/components/common/VendorMovementsTab.tsx",
      lineNumber: 235,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: columns.map(
          (col) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: `py-3.5 px-3 text-left text-sm font-semibold text-gray-900 ${["debit", "credit", "balance"].includes(col.key) ? "text-right" : ""}`, children: col.label }, col.key, false, {
            fileName: "/app/src/components/common/VendorMovementsTab.tsx",
            lineNumber: 243,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 241,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 240,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: [
          initialBalance !== null && /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-50 font-medium", children: [
            /* @__PURE__ */ jsxDEV("td", { colSpan: columns.length - 1, className: "py-3 pl-4 pr-3 text-sm font-semibold text-gray-900 sm:pl-6", children: [
              "SALDO ANTERIOR (al ",
              formatValue(appliedRange.from, "date"),
              ")"
            ] }, void 0, true, {
              fileName: "/app/src/components/common/VendorMovementsTab.tsx",
              lineNumber: 253,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-sm text-right font-semibold text-gray-900", children: formatValue(initialBalance, "currency") }, void 0, false, {
              fileName: "/app/src/components/common/VendorMovementsTab.tsx",
              lineNumber: 256,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/components/common/VendorMovementsTab.tsx",
            lineNumber: 252,
            columnNumber: 15
          }, this),
          movements.map(
            (mov, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: formatValue(mov.transaction_date, "date") }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 264,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: renderVendorDocumentType(mov.document_type) }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 265,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: renderVendorAccountDocumentLink(mov) }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 268,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.debit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 271,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right", children: formatValue(mov.credit, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 272,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-semibold", children: formatValue(mov.balance, "currency") }, void 0, false, {
                fileName: "/app/src/components/common/VendorMovementsTab.tsx",
                lineNumber: 273,
                columnNumber: 41
              }, this)
            ] }, `${mov.id}-${mov.document_type}-${index}`, true, {
              fileName: "/app/src/components/common/VendorMovementsTab.tsx",
              lineNumber: 263,
              columnNumber: 15
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 249,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/components/common/VendorMovementsTab.tsx",
        lineNumber: 239,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/VendorMovementsTab.tsx",
        lineNumber: 238,
        columnNumber: 21
      }, this),
      paginationMeta && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          meta: paginationMeta,
          onPageChange: handlePageChange
        },
        void 0,
        false,
        {
          fileName: "/app/src/components/common/VendorMovementsTab.tsx",
          lineNumber: 280,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/components/common/VendorMovementsTab.tsx",
      lineNumber: 237,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/VendorMovementsTab.tsx",
    lineNumber: 206,
    columnNumber: 5
  }, this);
};
_s(VendorMovementsTab, "b7nIBhyXAJBwDROKVm2xBfWdRoY=");
_c = VendorMovementsTab;
var _c;
$RefreshReg$(_c, "VendorMovementsTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/VendorMovementsTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/VendorMovementsTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dtQixTQXVISCxVQXZIRzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqR25CLFNBQVNBLFVBQVVDLFdBQVdDLGFBQWFDLGNBQWM7QUFDekQsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBc0R6QixTQUFTQyx5QkFBb0M7QUFDekMsUUFBTUMsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTUMsY0FBYyxJQUFJSCxLQUFLQSxLQUFLSSxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJLEVBQUVILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM5RixTQUFPLEVBQUVHLE1BQU1GLGFBQWFHLElBQUlQLE1BQU07QUFDMUM7QUFFQSxNQUFNUSwyQkFBMkJBLENBQUNDLFlBQW9CO0FBQ2xELE1BQUlDLE9BQU87QUFDWCxVQUFRRCxTQUFPO0FBQUEsSUFDWCxLQUFLO0FBQ0RDLGFBQU87QUFDUDtBQUFBLElBQ0osS0FBSztBQUNEQSxhQUFPO0FBQ1A7QUFBQSxJQUNKO0FBQ0lBLGFBQU9EO0FBQUFBLEVBQ2Y7QUFDQSxTQUFPQztBQUNYO0FBR0EsTUFBTUMsa0NBQWtDQSxDQUFDQyxRQUFrQztBQUN2RSxNQUFJQyxPQUFPO0FBQ1gsUUFBTUMsUUFBUUYsSUFBSUc7QUFDbEIsUUFBTUMsWUFBWUosSUFBSUssb0JBQW9CTCxJQUFJTSxrQkFBa0IsaUJBQWlCLE1BQU1KLEtBQUssS0FBSztBQUVqRyxVQUFRRixJQUFJTSxlQUFhO0FBQUEsSUFDckIsS0FBSztBQUNETCxhQUFPLFlBQVlDLEtBQUs7QUFDeEI7QUFBQSxJQUNKLEtBQUs7QUFDREQsYUFBTyxvQkFBb0JDLEtBQUs7QUFDaEM7QUFBQSxJQUNKO0FBQ0ksYUFBTyx1QkFBQyxVQUFNRSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsRUFDaEM7QUFFQSxTQUNJLHVCQUFDLFFBQUssSUFBSUgsTUFBTSxXQUFVLHlEQUNyQkcsdUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRVI7QUFFTyxhQUFNRyxxQkFBcUJBLENBQUMsRUFBRUMsVUFBVUMsU0FBa0MsTUFBTTtBQUFBQyxLQUFBO0FBQ25GLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJcEMsU0FBcUMsRUFBRTtBQUN6RSxRQUFNLENBQUNxQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEMsU0FBd0IsSUFBSTtBQUN4RSxRQUFNLENBQUN1QyxnQkFBZ0JDLGlCQUFpQixJQUFJeEMsU0FBd0MsSUFBSTtBQUN4RixRQUFNLENBQUN5QyxTQUFTQyxVQUFVLElBQUkxQyxTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDMkMsWUFBWUMsYUFBYSxJQUFJNUMsU0FBb0JXLHNCQUFzQjtBQUM5RSxRQUFNLENBQUNrQyxjQUFjQyxlQUFlLElBQUk5QyxTQUFvQlcsc0JBQXNCO0FBQ2xGLFFBQU1vQyxrQkFBa0I1QyxPQUFPMEMsWUFBWTtBQUMzQ0Usa0JBQWdCQyxVQUFVSDtBQUUxQixRQUFNSSxpQkFBaUIvQyxZQUFZLE9BQU9nRCxTQUFrQkMsVUFBc0I7QUFDOUVULGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFFQSxVQUFJVTtBQUVKLFVBQUlGLFNBQVM7QUFDVCxZQUFJQSxRQUFRRyxXQUFXLE1BQU0sR0FBRztBQUM1QixnQkFBTUMsU0FBUyxJQUFJQyxJQUFJTCxPQUFPO0FBQzlCRSxnQkFBTUUsT0FBT0UsU0FBU0MsUUFBUSxhQUFhLEVBQUUsSUFBSUgsT0FBT2hEO0FBQUFBLFFBQzVELE9BQU87QUFDSDhDLGdCQUFNRjtBQUFBQSxRQUNWO0FBQUEsTUFDSixPQUFPO0FBQ0gsY0FBTVEsSUFBSVAsU0FBU0osZ0JBQWdCQztBQUNuQyxjQUFNVyxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsZUFBT0UsSUFBSSxjQUFjSCxFQUFFeEMsSUFBSTtBQUMvQnlDLGVBQU9FLElBQUksWUFBWUgsRUFBRXZDLEVBQUU7QUFDM0J3QyxlQUFPRSxJQUFJLGFBQWE3QixTQUFTOEIsU0FBUyxDQUFDO0FBQzNDVixjQUFNLEdBQUduQixRQUFRLElBQUkwQixPQUFPRyxTQUFTLENBQUM7QUFBQSxNQUMxQztBQUVBLFlBQU1DLFdBQVcsTUFBTXpELE9BQVk4QyxHQUFHO0FBRXRDZCx3QkFBa0J5QixTQUFTQyxlQUFlO0FBQzFDNUIsbUJBQWEyQixTQUFTRSxVQUFVQyxJQUFJO0FBQ3BDMUIsd0JBQWtCdUIsU0FBU0UsU0FBUztBQUFBLElBRXhDLFNBQVNFLE9BQU87QUFDWjlELFlBQU04RCxNQUFNLGdEQUFnRDtBQUM1REMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCLFVBQUM7QUFDR3pCLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0osR0FBRyxDQUFDVCxVQUFVRCxRQUFRLENBQUM7QUFFdkIvQixZQUFVLE1BQU07QUFDWixVQUFNb0UsV0FBVzFELHVCQUF1QjtBQUN4Q2lDLGtCQUFjeUIsUUFBUTtBQUN0QnZCLG9CQUFnQnVCLFFBQVE7QUFDeEIsU0FBS3BCLGVBQWVxQixRQUFXRCxRQUFRO0FBQUEsRUFDM0MsR0FBRyxDQUFDcEIsZ0JBQWdCakIsUUFBUSxDQUFDO0FBRTdCLFFBQU11QyxtQkFBbUJBLENBQUNuQixRQUFnQjtBQUN0QyxTQUFLSCxlQUFlRyxHQUFHO0FBQUEsRUFDM0I7QUFFQSxRQUFNb0IscUJBQXFCQSxDQUFDQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJL0IsV0FBV3pCLFNBQVMyQixhQUFhM0IsUUFBUXlCLFdBQVd4QixPQUFPMEIsYUFBYTFCLElBQUk7QUFDNUU7QUFBQSxJQUNKO0FBQ0EyQixvQkFBZ0JILFVBQVU7QUFDMUIsU0FBS00sZUFBZXFCLFFBQVczQixVQUFVO0FBQUEsRUFDN0M7QUFHQSxRQUFNZ0MsVUFBVTtBQUFBLElBQ1osRUFBRUMsS0FBSyxvQkFBb0JDLE9BQU8sUUFBUTtBQUFBLElBQzFDLEVBQUVELEtBQUssaUJBQWlCQyxPQUFPLGlCQUFpQjtBQUFBLElBQ2hELEVBQUVELEtBQUssbUJBQW1CQyxPQUFPLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVELEtBQUssU0FBU0MsT0FBTyxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxVQUFVQyxPQUFPLFFBQVE7QUFBQSxJQUNoQyxFQUFFRCxLQUFLLFdBQVdDLE9BQU8sUUFBUTtBQUFBLEVBQUM7QUFHdEMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLDJCQUFDLFVBQUssVUFBVUwsb0JBQW9CLGNBQWEsT0FBTSxXQUFVLDhEQUM3RDtBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxXQUFNLFNBQVEsYUFBWSxXQUFVLDJDQUEwQyxxQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxJQUFHO0FBQUEsWUFDSCxPQUFPN0IsV0FBV3pCO0FBQUFBLFlBQ2xCLFVBQVUsQ0FBQXVELE1BQUs3QixjQUFjLENBQUFrQyxVQUFTLEVBQUUsR0FBR0EsTUFBTTVELE1BQU11RCxFQUFFTSxPQUFPQyxNQUFNLEVBQUU7QUFBQSxZQUN4RSxXQUFVO0FBQUEsWUFBcUYsY0FBYTtBQUFBO0FBQUEsVUFMaEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3FIO0FBQUEsV0FQekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsV0FBTSxTQUFRLFdBQVUsV0FBVSwyQ0FBMEMscUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsSUFBRztBQUFBLFlBQ0gsT0FBT3JDLFdBQVd4QjtBQUFBQSxZQUNsQixVQUFVLENBQUFzRCxNQUFLN0IsY0FBYyxDQUFBa0MsVUFBUyxFQUFFLEdBQUdBLE1BQU0zRCxJQUFJc0QsRUFBRU0sT0FBT0MsTUFBTSxFQUFFO0FBQUEsWUFDdEUsV0FBVTtBQUFBLFlBQXFGLGNBQWE7QUFBQTtBQUFBLFVBTGhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxSDtBQUFBLFdBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsSUFFQ3ZDLFVBQ0csdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLElBRWYsbUNBQ0k7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDSWtDLGtCQUFRTTtBQUFBQSxVQUFJLENBQUFDLFFBQ1QsdUJBQUMsUUFBaUIsT0FBTSxPQUFNLFdBQVcsNkRBQTZELENBQUMsU0FBUyxVQUFVLFNBQVMsRUFBRUMsU0FBU0QsSUFBSU4sR0FBRyxJQUFJLGVBQWUsRUFBRSxJQUNyS00sY0FBSUwsU0FEQUssSUFBSU4sS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFDSCxLQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUVadkM7QUFBQUEsNkJBQW1CLFFBQ2hCLHVCQUFDLFFBQUcsV0FBVSwwQkFDVjtBQUFBLG1DQUFDLFFBQUcsU0FBU3NDLFFBQVFTLFNBQVMsR0FBRyxXQUFVLDhEQUE0RDtBQUFBO0FBQUEsY0FDL0U3RSxZQUFZc0MsYUFBYTNCLE1BQU0sTUFBTTtBQUFBLGNBQUU7QUFBQSxpQkFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDREQUNUWCxzQkFBWThCLGdCQUFnQixVQUFVLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUdIRixVQUFVOEM7QUFBQUEsWUFBSSxDQUFDekQsS0FBSzZELFVBQ2pCLHVCQUFDLFFBQ0c7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsOENBQThDOUUsc0JBQVlpQixJQUFJOEQsa0JBQWtCLE1BQU0sS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0c7QUFBQSxjQUN0Ryx1QkFBQyxRQUFHLFdBQVUscUJBQ1RsRSxtQ0FBeUJJLElBQUlNLGFBQWEsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLHFCQUNUUCwwQ0FBZ0NDLEdBQUcsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ2pCLHNCQUFZaUIsSUFBSStELE9BQU8sVUFBVSxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRjtBQUFBLGNBQ2pGLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0NoRixzQkFBWWlCLElBQUlnRSxRQUFRLFVBQVUsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUNsRix1QkFBQyxRQUFHLFdBQVUsOENBQThDakYsc0JBQVlpQixJQUFJaUUsU0FBUyxVQUFVLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlHO0FBQUEsaUJBVjVGLEdBQUdqRSxJQUFJRyxFQUFFLElBQUlILElBQUlNLGFBQWEsSUFBSXVELEtBQUssSUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFVBQ0g7QUFBQSxhQTFCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0FyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQSxLQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsTUFDQzlDLGtCQUNHO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFNQTtBQUFBQSxVQUNOLGNBQWNnQztBQUFBQTtBQUFBQSxRQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUM7QUFBQSxTQTdDM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLE9BL0VSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpRkE7QUFFUjtBQUFFckMsR0FqS1dILG9CQUFrQjtBQUFBMkQsS0FBbEIzRDtBQUFrQixJQUFBMkQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJ1c2VSZWYiLCJMaW5rIiwidG9hc3QiLCJzZWFyY2giLCJmb3JtYXRWYWx1ZSIsIkxvYWRpbmdTcGlubmVyIiwiUGFnaW5hdGlvbiIsIkZhRmlsdGVyIiwiY3JlYXRlRGVmYXVsdERhdGVSYW5nZSIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJvbmVNb250aEFnbyIsIm5vdyIsImZyb20iLCJ0byIsInJlbmRlclZlbmRvckRvY3VtZW50VHlwZSIsImRvY1R5cGUiLCJ0ZXh0IiwicmVuZGVyVmVuZG9yQWNjb3VudERvY3VtZW50TGluayIsIm1vdiIsInBhdGgiLCJkb2NJZCIsImlkIiwiZG9jTnVtYmVyIiwiZG9jdW1lbnRfbnVtYmVyIiwiZG9jdW1lbnRfdHlwZSIsIlZlbmRvck1vdmVtZW50c1RhYiIsImVudGl0eUlkIiwiZW5kcG9pbnQiLCJfcyIsIm1vdmVtZW50cyIsInNldE1vdmVtZW50cyIsImluaXRpYWxCYWxhbmNlIiwic2V0SW5pdGlhbEJhbGFuY2UiLCJwYWdpbmF0aW9uTWV0YSIsInNldFBhZ2luYXRpb25NZXRhIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkcmFmdFJhbmdlIiwic2V0RHJhZnRSYW5nZSIsImFwcGxpZWRSYW5nZSIsInNldEFwcGxpZWRSYW5nZSIsImFwcGxpZWRSYW5nZVJlZiIsImN1cnJlbnQiLCJmZXRjaE1vdmVtZW50cyIsInBhZ2VVcmwiLCJyYW5nZSIsInVybCIsInN0YXJ0c1dpdGgiLCJ1cmxPYmoiLCJVUkwiLCJwYXRobmFtZSIsInJlcGxhY2UiLCJyIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwic2V0IiwidG9TdHJpbmciLCJyZXNwb25zZSIsImluaXRpYWxfYmFsYW5jZSIsInN0YXRlbWVudCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJkZWZhdWx0cyIsInVuZGVmaW5lZCIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVGaWx0ZXJTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJjb2x1bW5zIiwia2V5IiwibGFiZWwiLCJwcmV2IiwidGFyZ2V0IiwidmFsdWUiLCJtYXAiLCJjb2wiLCJpbmNsdWRlcyIsImxlbmd0aCIsImluZGV4IiwidHJhbnNhY3Rpb25fZGF0ZSIsImRlYml0IiwiY3JlZGl0IiwiYmFsYW5jZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlZlbmRvck1vdmVtZW50c1RhYi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2ssIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgc2VhcmNoIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgdHlwZSB7IFBhZ2luYXRlZFJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy9BcGknO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgUGFnaW5hdGlvbiB9IGZyb20gJy4vUGFnaW5hdGlvbic7XG5pbXBvcnQgeyBGYUZpbHRlciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcblxuLy8gLS0tIFRJUE9TIChFc3BlY8OtZmljb3MgZGUgUHJvdmVlZG9yLCBiYXNhZG9zIGVuIGVsIG51ZXZvIHBheWxvYWQpIC0tLVxuXG4vLyBUaXBvIHBhcmEgZWwgbGluayBkZSBwYWdpbmFjacOzblxuaW50ZXJmYWNlIFBhZ2luYXRpb25MaW5rIHtcbiAgICB1cmw6IHN0cmluZyB8IG51bGw7XG4gICAgbGFiZWw6IHN0cmluZztcbiAgICBhY3RpdmU6IGJvb2xlYW47XG59XG5cbi8vIEludGVyZmF6IHBhcmEgbGEgdHJhbnNhY2Npw7NuIChwYXlsb2FkLnN0YXRlbWVudC5kYXRhKVxuLy8gQXN1bW8gbG9zIGRvY3VtZW50X3R5cGUgJ1B1cmNoYXNlJyB5ICdQYXltZW50T3JkZXInXG5pbnRlcmZhY2UgVmVuZG9yQWNjb3VudFRyYW5zYWN0aW9uIHtcbiAgICBpZDogbnVtYmVyOyAvLyBJRCBkZWwgRG9jdW1lbnRvIChDb21wcmEgLyBPcmRlbiBkZSBQYWdvKVxuICAgIHRyYW5zYWN0aW9uX2RhdGU6IHN0cmluZztcbiAgICBkb2N1bWVudF90eXBlOiBzdHJpbmc7XG4gICAgZG9jdW1lbnRfbnVtYmVyOiBzdHJpbmcgfCBudWxsO1xuICAgIGRlYml0OiBudW1iZXI7XG4gICAgY3JlZGl0OiBudW1iZXI7XG4gICAgYmFsYW5jZTogbnVtYmVyO1xufVxuXG4vLyBJbnRlcmZheiBwYXJhIGVsIG9iamV0byAnc3RhdGVtZW50JyAocGFnaW5hY2nDs24pXG5pbnRlcmZhY2UgVmVuZG9yQWNjb3VudFN0YXRlbWVudCB7XG4gICAgY3VycmVudF9wYWdlOiBudW1iZXI7XG4gICAgZGF0YTogVmVuZG9yQWNjb3VudFRyYW5zYWN0aW9uW107XG4gICAgbGlua3M6IFBhZ2luYXRpb25MaW5rW107XG4gICAgZmlyc3RfcGFnZV91cmw6IHN0cmluZztcbiAgICBmcm9tOiBudW1iZXI7XG4gICAgbGFzdF9wYWdlOiBudW1iZXI7XG4gICAgbGFzdF9wYWdlX3VybDogc3RyaW5nO1xuICAgIG5leHRfcGFnZV91cmw6IHN0cmluZyB8IG51bGw7XG4gICAgcGF0aDogc3RyaW5nO1xuICAgIHBlcl9wYWdlOiBudW1iZXI7XG4gICAgcHJldl9wYWdlX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgICB0bzogbnVtYmVyO1xuICAgIHRvdGFsOiBudW1iZXI7XG59XG5cbi8vIEludGVyZmF6IHBhcmEgbGEgcmVzcHVlc3RhIGNvbXBsZXRhIGRlIC92ZW5kb3ItYWNjb3VudHNcbmludGVyZmFjZSBWZW5kb3JBY2NvdW50UmVzcG9uc2Uge1xuICAgIGluaXRpYWxfYmFsYW5jZTogbnVtYmVyO1xuICAgIHN0YXRlbWVudDogVmVuZG9yQWNjb3VudFN0YXRlbWVudDtcbiAgICBmaWx0ZXJzOiBhbnk7XG59XG5cbmludGVyZmFjZSBWZW5kb3JNb3ZlbWVudHNUYWJQcm9wcyB7XG4gICAgZW50aXR5SWQ6IHN0cmluZyB8IG51bWJlcjtcbiAgICBlbmRwb2ludDogc3RyaW5nOyAvLyBFajogJ3ZlbmRvci1hY2NvdW50cydcbn1cblxudHlwZSBEYXRlUmFuZ2UgPSB7IGZyb206IHN0cmluZzsgdG86IHN0cmluZyB9O1xuXG5mdW5jdGlvbiBjcmVhdGVEZWZhdWx0RGF0ZVJhbmdlKCk6IERhdGVSYW5nZSB7XG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICBjb25zdCBvbmVNb250aEFnbyA9IG5ldyBEYXRlKERhdGUubm93KCkgLSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbiAgICByZXR1cm4geyBmcm9tOiBvbmVNb250aEFnbywgdG86IHRvZGF5IH07XG59XG5cbmNvbnN0IHJlbmRlclZlbmRvckRvY3VtZW50VHlwZSA9IChkb2NUeXBlOiBzdHJpbmcpID0+IHtcbiAgICBsZXQgdGV4dCA9ICcnO1xuICAgIHN3aXRjaCAoZG9jVHlwZSkge1xuICAgICAgICBjYXNlICdQdXJjaGFzZSc6XG4gICAgICAgICAgICB0ZXh0ID0gJ0NvbXByYSc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnUGF5bWVudE9yZGVyJzpcbiAgICAgICAgICAgIHRleHQgPSAnT3JkZW4gZGUgUGFnbyc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRleHQgPSBkb2NUeXBlO1xuICAgIH1cbiAgICByZXR1cm4gdGV4dDtcbn1cblxuLy8gSGVscGVyIHBhcmEgcmVuZGVyaXphciBlbmxhY2VzIGEgQ29tcHJhcyB5IMOTcmRlbmVzIGRlIFBhZ29cbmNvbnN0IHJlbmRlclZlbmRvckFjY291bnREb2N1bWVudExpbmsgPSAobW92OiBWZW5kb3JBY2NvdW50VHJhbnNhY3Rpb24pID0+IHtcbiAgICBsZXQgcGF0aCA9ICcjJztcbiAgICBjb25zdCBkb2NJZCA9IG1vdi5pZDtcbiAgICBjb25zdCBkb2NOdW1iZXIgPSBtb3YuZG9jdW1lbnRfbnVtYmVyIHx8IChtb3YuZG9jdW1lbnRfdHlwZSA9PT0gJ1BheW1lbnRPcmRlcicgPyBgT1AtJHtkb2NJZH1gIDogJ1ZlciBEb2MuJyk7XG5cbiAgICBzd2l0Y2ggKG1vdi5kb2N1bWVudF90eXBlKSB7XG4gICAgICAgIGNhc2UgJ1B1cmNoYXNlJzpcbiAgICAgICAgICAgIHBhdGggPSBgL2NvbXByYXMvJHtkb2NJZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ1BheW1lbnRPcmRlcic6XG4gICAgICAgICAgICBwYXRoID0gYC9vcmRlbmVzLWRlLXBhZ28vJHtkb2NJZH1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gPHNwYW4+e2RvY051bWJlcn08L3NwYW4+O1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxMaW5rIHRvPXtwYXRofSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAge2RvY051bWJlcn1cbiAgICAgICAgPC9MaW5rPlxuICAgICk7XG59O1xuXG5leHBvcnQgY29uc3QgVmVuZG9yTW92ZW1lbnRzVGFiID0gKHsgZW50aXR5SWQsIGVuZHBvaW50IH06IFZlbmRvck1vdmVtZW50c1RhYlByb3BzKSA9PiB7XG4gICAgY29uc3QgW21vdmVtZW50cywgc2V0TW92ZW1lbnRzXSA9IHVzZVN0YXRlPFZlbmRvckFjY291bnRUcmFuc2FjdGlvbltdPihbXSk7XG4gICAgY29uc3QgW2luaXRpYWxCYWxhbmNlLCBzZXRJbml0aWFsQmFsYW5jZV0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbcGFnaW5hdGlvbk1ldGEsIHNldFBhZ2luYXRpb25NZXRhXSA9IHVzZVN0YXRlPFZlbmRvckFjY291bnRTdGF0ZW1lbnQgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBbZHJhZnRSYW5nZSwgc2V0RHJhZnRSYW5nZV0gPSB1c2VTdGF0ZTxEYXRlUmFuZ2U+KGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UpO1xuICAgIGNvbnN0IFthcHBsaWVkUmFuZ2UsIHNldEFwcGxpZWRSYW5nZV0gPSB1c2VTdGF0ZTxEYXRlUmFuZ2U+KGNyZWF0ZURlZmF1bHREYXRlUmFuZ2UpO1xuICAgIGNvbnN0IGFwcGxpZWRSYW5nZVJlZiA9IHVzZVJlZihhcHBsaWVkUmFuZ2UpO1xuICAgIGFwcGxpZWRSYW5nZVJlZi5jdXJyZW50ID0gYXBwbGllZFJhbmdlO1xuXG4gICAgY29uc3QgZmV0Y2hNb3ZlbWVudHMgPSB1c2VDYWxsYmFjayhhc3luYyAocGFnZVVybD86IHN0cmluZywgcmFuZ2U/OiBEYXRlUmFuZ2UpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIC0tLSBMw5NHSUNBIFBBUkEgUFJPVkVFRE9SRVMgKE5VRVZPIFBBWUxPQUQpIC0tLVxuICAgICAgICAgICAgbGV0IHVybDogc3RyaW5nO1xuXG4gICAgICAgICAgICBpZiAocGFnZVVybCkge1xuICAgICAgICAgICAgICAgIGlmIChwYWdlVXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1cmxPYmogPSBuZXcgVVJMKHBhZ2VVcmwpO1xuICAgICAgICAgICAgICAgICAgICB1cmwgPSB1cmxPYmoucGF0aG5hbWUucmVwbGFjZSgvXlxcL2FwaVxcLz8vLCAnJykgKyB1cmxPYmouc2VhcmNoO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9IHBhZ2VVcmw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCByID0gcmFuZ2UgPz8gYXBwbGllZFJhbmdlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ3N0YXJ0X2RhdGUnLCByLmZyb20pO1xuICAgICAgICAgICAgICAgIHBhcmFtcy5zZXQoJ2VuZF9kYXRlJywgci50byk7XG4gICAgICAgICAgICAgICAgcGFyYW1zLnNldCgndmVuZG9yX2lkJywgZW50aXR5SWQudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICAgICAgdXJsID0gYCR7ZW5kcG9pbnR9PyR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzZWFyY2g8YW55Pih1cmwpIGFzIHVua25vd24gYXMgVmVuZG9yQWNjb3VudFJlc3BvbnNlO1xuXG4gICAgICAgICAgICBzZXRJbml0aWFsQmFsYW5jZShyZXNwb25zZS5pbml0aWFsX2JhbGFuY2UpO1xuICAgICAgICAgICAgc2V0TW92ZW1lbnRzKHJlc3BvbnNlLnN0YXRlbWVudC5kYXRhKTtcbiAgICAgICAgICAgIHNldFBhZ2luYXRpb25NZXRhKHJlc3BvbnNlLnN0YXRlbWVudCk7XG5cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjYXJnYXIgbG9zIG1vdmltaWVudG9zIGRlbCBwcm92ZWVkb3IuJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW2VuZHBvaW50LCBlbnRpdHlJZF0pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZGVmYXVsdHMgPSBjcmVhdGVEZWZhdWx0RGF0ZVJhbmdlKCk7XG4gICAgICAgIHNldERyYWZ0UmFuZ2UoZGVmYXVsdHMpO1xuICAgICAgICBzZXRBcHBsaWVkUmFuZ2UoZGVmYXVsdHMpO1xuICAgICAgICB2b2lkIGZldGNoTW92ZW1lbnRzKHVuZGVmaW5lZCwgZGVmYXVsdHMpO1xuICAgIH0sIFtmZXRjaE1vdmVtZW50cywgZW50aXR5SWRdKTtcblxuICAgIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgdm9pZCBmZXRjaE1vdmVtZW50cyh1cmwpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVGaWx0ZXJTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKGRyYWZ0UmFuZ2UuZnJvbSA9PT0gYXBwbGllZFJhbmdlLmZyb20gJiYgZHJhZnRSYW5nZS50byA9PT0gYXBwbGllZFJhbmdlLnRvKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0QXBwbGllZFJhbmdlKGRyYWZ0UmFuZ2UpO1xuICAgICAgICB2b2lkIGZldGNoTW92ZW1lbnRzKHVuZGVmaW5lZCwgZHJhZnRSYW5nZSk7XG4gICAgfTtcblxuICAgIC8vIENvbHVtbmFzIEN0YS4gQ3RlLiBQcm92ZWVkb3JcbiAgICBjb25zdCBjb2x1bW5zID0gW1xuICAgICAgICB7IGtleTogJ3RyYW5zYWN0aW9uX2RhdGUnLCBsYWJlbDogJ0ZlY2hhJyB9LFxuICAgICAgICB7IGtleTogJ2RvY3VtZW50X3R5cGUnLCBsYWJlbDogJ1RpcG8gRG9jdW1lbnRvJyB9LFxuICAgICAgICB7IGtleTogJ2RvY3VtZW50X251bWJlcicsIGxhYmVsOiAnTm8uIGRlIEZhY3R1cmEnIH0sXG4gICAgICAgIHsga2V5OiAnZGViaXQnLCBsYWJlbDogJ0RlYmUnIH0sXG4gICAgICAgIHsga2V5OiAnY3JlZGl0JywgbGFiZWw6ICdIYWJlcicgfSxcbiAgICAgICAgeyBrZXk6ICdiYWxhbmNlJywgbGFiZWw6ICdTYWxkbycgfSxcbiAgICBdO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02XCI+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlRmlsdGVyU3VibWl0fSBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtNCBtYi00IHAtNCBiZy1ncmF5LTUwIGJvcmRlciByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkYXRlX2Zyb21cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5EZXNkZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlX2Zyb21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0UmFuZ2UuZnJvbX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldERyYWZ0UmFuZ2UocHJldiA9PiAoeyAuLi5wcmV2LCBmcm9tOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImRhdGVfdG9cIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5IYXN0YTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlX3RvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdFJhbmdlLnRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RHJhZnRSYW5nZShwcmV2ID0+ICh7IC4uLnByZXYsIHRvOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8RmFGaWx0ZXIgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gRmlsdHJhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2x1bW5zLm1hcChjb2wgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBrZXk9e2NvbC5rZXl9IHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPXtgcHktMy41IHB4LTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwICR7WydkZWJpdCcsICdjcmVkaXQnLCAnYmFsYW5jZSddLmluY2x1ZGVzKGNvbC5rZXkpID8gJ3RleHQtcmlnaHQnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb2wubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRmlsYSBkZSBTYWxkbyBJbmljaWFsICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5pdGlhbEJhbGFuY2UgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Y29sdW1ucy5sZW5ndGggLSAxfSBjbGFzc05hbWU9XCJweS0zIHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNBTERPIEFOVEVSSU9SIChhbCB7Zm9ybWF0VmFsdWUoYXBwbGllZFJhbmdlLmZyb20sICdkYXRlJyl9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpbml0aWFsQmFsYW5jZSwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge21vdmVtZW50cy5tYXAoKG1vdiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2Ake21vdi5pZH0tJHttb3YuZG9jdW1lbnRfdHlwZX0tJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+e2Zvcm1hdFZhbHVlKG1vdi50cmFuc2FjdGlvbl9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJWZW5kb3JEb2N1bWVudFR5cGUobW92LmRvY3VtZW50X3R5cGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJWZW5kb3JBY2NvdW50RG9jdW1lbnRMaW5rKG1vdil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZShtb3YuZGViaXQsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHRcIj57Zm9ybWF0VmFsdWUobW92LmNyZWRpdCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCBmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKG1vdi5iYWxhbmNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7cGFnaW5hdGlvbk1ldGEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2luYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRhPXtwYWdpbmF0aW9uTWV0YSBhcyBQYWdpbmF0ZWRSZXNwb25zZTxhbnk+WydtZXRhJ119IC8vIENhc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG5cbiJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vVmVuZG9yTW92ZW1lbnRzVGFiLnRzeCJ9