import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/compradores/pages/CompradoresEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/compradores/pages/CompradoresEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"];
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const CompradoresEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error, saveItem } = useCrudItem(compradoresModuleConfig, id);
  const initialData = useMemo(() => {
    if (!item) return void 0;
    return {
      ...item,
      client_name: item.client?.name || ""
    };
  }, [item]);
  const handleSave = async (data) => {
    const updatedItem = await saveItem(data);
    if (updatedItem) {
      toast.info(`Comprador actualizado con éxito!`);
      navigate(getListReturnPath(compradoresModuleConfig.baseRoute));
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresEditPage.tsx",
    lineNumber: 53,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresEditPage.tsx",
    lineNumber: 54,
    columnNumber: 21
  }, this);
  if (!initialData) return /* @__PURE__ */ jsxDEV("div", { children: "Comprador no encontrado." }, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresEditPage.tsx",
    lineNumber: 55,
    columnNumber: 28
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: compradoresModuleConfig,
      initialData,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/compradores/pages/CompradoresEditPage.tsx",
      lineNumber: 58,
      columnNumber: 5
    },
    this
  );
};
_s(CompradoresEditPage, "BVwHB5b24FKzcV5TZJoWvyMK804=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = CompradoresEditPage;
var _c;
$RefreshReg$(_c, "CompradoresEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/compradores/pages/CompradoresEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/compradores/pages/CompradoresEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUN3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqQ3hCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQywrQkFBK0M7QUFDeEQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVgsVUFBMEI7QUFDekMsUUFBTVksV0FBV1gsWUFBWTtBQUM3QixRQUFNLEVBQUVZLE1BQU1DLFNBQVNDLE9BQU9DLFNBQVMsSUFBSVgsWUFBdUJELHlCQUF5Qk8sRUFBRTtBQUc3RixRQUFNTSxjQUFjZixRQUFRLE1BQU07QUFDOUIsUUFBSSxDQUFDVyxLQUFNLFFBQU9LO0FBR2xCLFdBQU87QUFBQSxNQUNILEdBQUdMO0FBQUFBLE1BQ0hNLGFBQWFOLEtBQUtPLFFBQVFDLFFBQVE7QUFBQSxJQUN0QztBQUFBLEVBQ0osR0FBRyxDQUFDUixJQUFJLENBQUM7QUFFVCxRQUFNUyxhQUFhLE9BQU9DLFNBQW9CO0FBQzFDLFVBQU1DLGNBQWMsTUFBTVIsU0FBU08sSUFBSTtBQUN2QyxRQUFJQyxhQUFhO0FBQ2JsQixZQUFNbUIsS0FBSyxrQ0FBa0M7QUFDN0NiLGVBQVNKLGtCQUFrQkosd0JBQXdCc0IsU0FBUyxDQUFDO0FBQUEsSUFDakU7QUFBQSxFQUNKO0FBRUEsTUFBSVosUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDRSxZQUFhLFFBQU8sdUJBQUMsU0FBSSx3Q0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZCO0FBRXRELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFiO0FBQUFBLE1BQ1I7QUFBQSxNQUNBLFFBQVFrQjtBQUFBQSxNQUNSLE1BQUs7QUFBQTtBQUFBLElBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWU7QUFHdkI7QUFBRVosR0FwQ1dELHFCQUFtQjtBQUFBLFVBQ2JULFdBQ0VDLGFBQzBCSSxXQUFXO0FBQUE7QUFBQXNCLEtBSDdDbEI7QUFBbUIsSUFBQWtCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsInVzZU1lbW8iLCJHZW5lcmljRm9ybVBhZ2UiLCJjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJMb2FkaW5nU3Bpbm5lciIsImdldExpc3RSZXR1cm5QYXRoIiwiQ29tcHJhZG9yZXNFZGl0UGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsIml0ZW0iLCJsb2FkaW5nIiwiZXJyb3IiLCJzYXZlSXRlbSIsImluaXRpYWxEYXRhIiwidW5kZWZpbmVkIiwiY2xpZW50X25hbWUiLCJjbGllbnQiLCJuYW1lIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJ1cGRhdGVkSXRlbSIsImluZm8iLCJiYXNlUm91dGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wcmFkb3Jlc0VkaXRQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VNZW1vIH0gZnJvbSAncmVhY3QnOyAvLyBJbXBvcnRhbW9zIHVzZU1lbW9cbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBDb21wcmFkb3IgfSBmcm9tICcuLi9jb21wcmFkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IENvbXByYWRvcmVzRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08Q29tcHJhZG9yPihjb21wcmFkb3Jlc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgLy8gQ29ycmVnaW1vcyBsb3MgZGF0b3MgcGFyYSBlbCBmb3JtdWxhcmlvXG4gICAgY29uc3QgaW5pdGlhbERhdGEgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFpdGVtKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgICAgIC8vIENyZWFtb3MgZWwgY2FtcG8gJ2NsaWVudF9uYW1lJyBxdWUgZWwgZm9ybXVsYXJpbyBnZW7DqXJpY28gZXNwZXJhXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgY2xpZW50X25hbWU6IGl0ZW0uY2xpZW50Py5uYW1lIHx8ICcnLFxuICAgICAgICB9O1xuICAgIH0sIFtpdGVtXSk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IENvbXByYWRvcikgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkSXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAodXBkYXRlZEl0ZW0pIHtcbiAgICAgICAgICAgIHRvYXN0LmluZm8oYENvbXByYWRvciBhY3R1YWxpemFkbyBjb24gw6l4aXRvIWApO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgoY29tcHJhZG9yZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghaW5pdGlhbERhdGEpIHJldHVybiA8ZGl2PkNvbXByYWRvciBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17Y29tcHJhZG9yZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbERhdGF9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiZWRpdFwiXG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jb21wcmFkb3Jlcy9wYWdlcy9Db21wcmFkb3Jlc0VkaXRQYWdlLnRzeCJ9