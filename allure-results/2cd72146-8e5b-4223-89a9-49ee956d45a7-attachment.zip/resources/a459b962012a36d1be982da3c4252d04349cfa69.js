import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import {} from "/src/features/pedidos_venta/pedidos_venta_config.tsx";
import { autorizacionPedidoDetailModuleConfig } from "/src/features/autorizacion_pedidos/autorizacion_pedidos.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { isClientLeyExportacionTdfExempt } from "/src/utils/clientTaxExemption.ts";
import __vite__cjsImport11_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport11_react["useEffect"]; const useMemo = __vite__cjsImport11_react["useMemo"]; const useState = __vite__cjsImport11_react["useState"];
import { authorizeSalesOrder, getClientCurrentBalance } from "/src/services/apiService.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { useModal } from "/src/context/ModalContext.tsx";
import { ClienteCobranzasModal } from "/src/features/autorizacion_pedidos/components/ClienteCobranzasModal.tsx";
import { ClienteCuentaCorrienteModal } from "/src/features/autorizacion_pedidos/components/ClienteCuentaCorrienteModal.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) {
    return 0;
  }
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const AutorizacionPedidoDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const { showConfirmationModal } = useModal();
  const [isPrinting, setIsPrinting] = useState(false);
  const [isAuthorizing, setIsAuthorizing] = useState(false);
  const [isPagosModalOpen, setIsPagosModalOpen] = useState(false);
  const [isCuentaCorrienteModalOpen, setIsCuentaCorrienteModalOpen] = useState(false);
  const [clientBalance, setClientBalance] = useState(null);
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [balanceError, setBalanceError] = useState(null);
  const { item: order, loading, error } = useCrudItem(autorizacionPedidoDetailModuleConfig, id);
  const canAuthorize = hasModulePermission("sales_order_authorization", "edit");
  const orderClientId = order?.client_id ?? order?.client?.id ?? null;
  const canOpenClientModals = orderClientId != null && Number(orderClientId) > 0;
  useEffect(() => {
    if (!canOpenClientModals || orderClientId == null) {
      setClientBalance(null);
      setBalanceError(null);
      setBalanceLoading(false);
      return;
    }
    setBalanceLoading(true);
    setBalanceError(null);
    void getClientCurrentBalance(orderClientId).then((res) => setClientBalance(Number(res.balance))).catch(() => setBalanceError("No se pudo cargar la deuda del cliente.")).finally(() => setBalanceLoading(false));
  }, [orderClientId, canOpenClientModals]);
  const isClientTaxExempt = useMemo(
    () => isClientLeyExportacionTdfExempt(order?.client),
    [order?.client]
  );
  const calculatedTotals = useMemo(() => {
    if (!order) {
      return { subtotal: 0, totalItemDiscounts: 0, globalDiscountAmount: 0, taxBase: 0, totalTaxes: 0 };
    }
    const items = order.items || [];
    const subtotal = items.reduce((sum, item) => {
      return sum + Number(item.quantity) * Number(item.unit_price);
    }, 0);
    const totalItemDiscounts = items.reduce((sum, item) => {
      return sum + (Number(item.discount_amount) || 0);
    }, 0);
    const globalDiscountAmount = Number(order.discount_amount) || 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (order.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => {
          const itemTaxAmount = (item.taxes || []).reduce((itemSum, tax) => itemSum + Number(tax.amount), 0);
          return sum + itemTaxAmount;
        }, 0);
      } else {
        totalTaxes = (order.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes };
  }, [order, isClientTaxExempt]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
    lineNumber: 119,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar el pedido: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
    lineNumber: 120,
    columnNumber: 21
  }, this);
  if (!order) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el pedido." }, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
    lineNumber: 121,
    columnNumber: 22
  }, this);
  const getStatusText = (status) => {
    switch (String(status)) {
      case "1":
        return "Pendiente";
      case "2":
        return "Procesado";
      case "3":
        return "Autorizado";
      case "0":
        return "Anulado";
      default:
        return "Desconocido";
    }
  };
  const getStatusClassName = (status) => {
    switch (String(status)) {
      case "1":
        return "bg-yellow-100 text-yellow-800";
      case "2":
        return "bg-green-100 text-green-800";
      case "3":
        return "bg-green-100 text-green-800";
      case "0":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const handlePrint = async () => {
    if (!order) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/sales-orders/${order.id}/pdf`);
    } catch (err) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", err);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  const handleAuthorize = async () => {
    if (!order) return;
    setIsAuthorizing(true);
    try {
      await authorizeSalesOrder(order.id);
      toast.success("Pedido autorizado correctamente.");
      navigate(getListReturnPath(autorizacionPedidoDetailModuleConfig.baseRoute));
    } catch (err) {
      console.error(err);
      const msg = err && typeof err === "object" && "response" in err && err.response && typeof err.response === "object" && "data" in err.response && err.response.data && typeof err.response.data === "object" && "message" in err.response.data && typeof err.response.data.message === "string" ? err.response.data.message : null;
      toast.error(msg?.trim() ? msg : "No se pudo autorizar el pedido.");
    } finally {
      setIsAuthorizing(false);
    }
  };
  const openAuthorizeConfirm = () => {
    if (!order) return;
    showConfirmationModal({
      title: "Autorizar pedido",
      message: `¿Confirma autorizar el pedido ${order.order_number}? El estado pasará a Autorizado.`,
      onConfirm: () => {
        void handleAuthorize();
      }
    });
  };
  const isPendingStatus = String(order.status) === "1";
  const showAuthorizeButton = canAuthorize && isPendingStatus;
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(getListReturnPath(autorizacionPedidoDetailModuleConfig.baseRoute)),
            className: "p-2 text-gray-500 rounded-full hover:bg-gray-100",
            children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 218,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 213,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "Pedido: ",
            order.order_number
          ] }, void 0, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 221,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClassName(order.status)}`, children: getStatusText(order.status) }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 224,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 220,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 212,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4 flex flex-wrap items-center gap-2 justify-end", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 238,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 240,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 231,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setIsPagosModalOpen(true),
            disabled: !canOpenClientModals,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed",
            children: "Pagos"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 243,
            columnNumber: 21
          },
          this
        ),
        showAuthorizeButton && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: openAuthorizeConfirm,
            disabled: isAuthorizing,
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:opacity-50",
            children: isAuthorizing ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 258,
              columnNumber: 46
            }, this) : "Autorizar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 252,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 230,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 211,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 266,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/clientes/${order.client?.id}`,
            className: "text-indigo-600 hover:text-indigo-800 hover:underline",
            children: order.client?.name || order.client_name || "N/A"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 268,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 267,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 265,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Pedido" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 277,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: formatValue(order.order_date, "date") }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 278,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 276,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Entrega" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 281,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.delivery_date ? formatValue(order.delivery_date, "date") : "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 282,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 280,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 285,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.salesperson?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 286,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 284,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Comprador" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 289,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.buyer?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 290,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 288,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Transporte" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 293,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.transport?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 294,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 292,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 297,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.currency?.name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 298,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 296,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Nº O.C." }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 301,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.purchase_order_number || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 302,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 300,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Dirección Entrega" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 305,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.delivery_address || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 306,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 304,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 309,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.notes || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 310,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 308,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de cambio" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 313,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-sm text-gray-900", children: order.exchange_rate || "N/A" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 314,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 312,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 264,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-gray-800`, children: "Deuda del cliente:" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 321,
          columnNumber: 25
        }, this),
        balanceLoading ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-4 h-4 animate-spin text-gray-500", "aria-label": "Cargando deuda" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 323,
          columnNumber: 13
        }, this) : balanceError ? /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-red-600", children: balanceError }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 325,
          columnNumber: 13
        }, this) : canOpenClientModals && clientBalance != null ? /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: formatValue(clientBalance, "currency") }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 327,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: "-" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 331,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 320,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setIsCuentaCorrienteModalOpen(true),
          disabled: !canOpenClientModals,
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed",
          children: "Cuenta Corriente"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 334,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 319,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 318,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mb-4", children: "Items del Pedido" }, void 0, false, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 346,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 353,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 354,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 355,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Desc. (Monto)" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 356,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 357,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && order.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 359,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 361,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 352,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 351,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: (order.items || []).map((item, index) => {
          const subtotal = Number(item.quantity) * Number(item.unit_price);
          const discount = Number(item.discount_amount) || 0;
          const lineSubtotal = subtotal - discount;
          const itemTax = !isClientTaxExempt && order.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSubtotal + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: item.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${item.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
                lineNumber: 377,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
                lineNumber: 378,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 376,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
                lineNumber: 382,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
                lineNumber: 383,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 381,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 374,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: item.quantity }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 387,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 388,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(discount, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 389,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 390,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && order.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(itemTax, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 392,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 396,
              columnNumber: 41
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 373,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 364,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 350,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 349,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 345,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1" }, void 0, false, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 408,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !order.has_item_level_taxes && order.taxes && order.taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 412,
          columnNumber: 29
        }, this),
        order.taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle.replace("text-gray-600", "text-gray-700"), children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%):"
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 415,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 416,
              columnNumber: 37
            }, this)
          ] }, tax.tax_id || index, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 414,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 411,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 409,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 425,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 426,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 424,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Items):" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 429,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.totalItemDiscounts, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 430,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 428,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Global):" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 433,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.globalDiscountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 434,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 432,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 439,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-base")} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 440,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 438,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: order.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 443,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
              lineNumber: 446,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 442,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 437,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 451,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-lg")} font-bold text-indigo-600`, children: formatValue(order.total_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
            lineNumber: 452,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
          lineNumber: 450,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 423,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
      lineNumber: 407,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      ClienteCobranzasModal,
      {
        isOpen: isPagosModalOpen,
        onClose: () => setIsPagosModalOpen(false),
        clientId: orderClientId
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 459,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      ClienteCuentaCorrienteModal,
      {
        isOpen: isCuentaCorrienteModalOpen,
        onClose: () => setIsCuentaCorrienteModalOpen(false),
        clientId: orderClientId
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
        lineNumber: 464,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx",
    lineNumber: 209,
    columnNumber: 5
  }, this);
};
_s(AutorizacionPedidoDetailPage, "eDCCMedtvruZ+xBVVGnDNRfoRXg=", false, function() {
  return [useParams, useNavigate, usePermissions, useModal, useCrudItem];
});
_c = AutorizacionPedidoDetailPage;
var _c;
$RefreshReg$(_c, "AutorizacionPedidoDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUd3QixTQXNRd0IsVUF0UXhCOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5HeEIsU0FBU0EsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxtQkFBbUI7QUFDNUIsZUFBcUQ7QUFDckQsU0FBU0MsNENBQTRDO0FBQ3JELFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxhQUFhQyxlQUFlO0FBQ3JDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx1Q0FBdUM7QUFDaEQsU0FBU0MsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQzdDLFNBQVNDLHFCQUFxQkMsK0JBQStCO0FBQzdELFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBQ2xELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLG1DQUFtQztBQUM1QyxTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsa0JBQWtCQSxDQUFDQyxTQUF5QjtBQUM5QyxNQUFJLENBQUNBLEtBQUtDLFNBQVNELEtBQUtDLE1BQU1DLFdBQVcsR0FBRztBQUN4QyxXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQU9GLEtBQUtDLE1BQU1FLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFDdEU7QUFFTyxhQUFNQywrQkFBK0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QyxRQUFNLEVBQUVDLEdBQUcsSUFBSW5DLFVBQTBCO0FBQ3pDLFFBQU1vQyxXQUFXbkMsWUFBWTtBQUM3QixRQUFNLEVBQUVvQyxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTSxFQUFFbUIsc0JBQXNCLElBQUlsQixTQUFTO0FBQzNDLFFBQU0sQ0FBQ21CLFlBQVlDLGFBQWEsSUFBSTVCLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUM2QixlQUFlQyxnQkFBZ0IsSUFBSTlCLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUMrQixrQkFBa0JDLG1CQUFtQixJQUFJaEMsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2lDLDRCQUE0QkMsNkJBQTZCLElBQUlsQyxTQUFTLEtBQUs7QUFDbEYsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUF3QixJQUFJO0FBQ3RFLFFBQU0sQ0FBQ3FDLGdCQUFnQkMsaUJBQWlCLElBQUl0QyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDdUMsY0FBY0MsZUFBZSxJQUFJeEMsU0FBd0IsSUFBSTtBQUNwRSxRQUFNLEVBQUVhLE1BQU00QixPQUFPQyxTQUFTQyxNQUFNLElBQUlwRCxZQUF3QkMsc0NBQXNDK0IsRUFBRTtBQUV4RyxRQUFNcUIsZUFBZW5CLG9CQUFvQiw2QkFBNkIsTUFBTTtBQUU1RSxRQUFNb0IsZ0JBQWdCSixPQUFPSyxhQUFhTCxPQUFPTSxRQUFReEIsTUFBTTtBQUMvRCxRQUFNeUIsc0JBQXNCSCxpQkFBaUIsUUFBUTFCLE9BQU8wQixhQUFhLElBQUk7QUFFN0UvQyxZQUFVLE1BQU07QUFDWixRQUFJLENBQUNrRCx1QkFBdUJILGlCQUFpQixNQUFNO0FBQy9DVCx1QkFBaUIsSUFBSTtBQUNyQkksc0JBQWdCLElBQUk7QUFDcEJGLHdCQUFrQixLQUFLO0FBQ3ZCO0FBQUEsSUFDSjtBQUNBQSxzQkFBa0IsSUFBSTtBQUN0QkUsb0JBQWdCLElBQUk7QUFDcEIsU0FBS3RDLHdCQUF3QjJDLGFBQWEsRUFDckNJLEtBQUssQ0FBQUMsUUFBT2QsaUJBQWlCakIsT0FBTytCLElBQUlDLE9BQU8sQ0FBQyxDQUFDLEVBQ2pEQyxNQUFNLE1BQU1aLGdCQUFnQix5Q0FBeUMsQ0FBQyxFQUN0RWEsUUFBUSxNQUFNZixrQkFBa0IsS0FBSyxDQUFDO0FBQUEsRUFDL0MsR0FBRyxDQUFDTyxlQUFlRyxtQkFBbUIsQ0FBQztBQUV2QyxRQUFNTSxvQkFBb0J2RDtBQUFBQSxJQUN0QixNQUFNRixnQ0FBZ0M0QyxPQUFPTSxNQUFNO0FBQUEsSUFDbkQsQ0FBQ04sT0FBT00sTUFBTTtBQUFBLEVBQ2xCO0FBRUEsUUFBTVEsbUJBQW1CeEQsUUFBUSxNQUFNO0FBQ25DLFFBQUksQ0FBQzBDLE9BQU87QUFDUixhQUFPLEVBQUVlLFVBQVUsR0FBR0Msb0JBQW9CLEdBQUdDLHNCQUFzQixHQUFHQyxTQUFTLEdBQUdDLFlBQVksRUFBRTtBQUFBLElBQ3BHO0FBRUEsVUFBTUMsUUFBUXBCLE1BQU1vQixTQUFTO0FBRTdCLFVBQU1MLFdBQVdLLE1BQU03QyxPQUFPLENBQUNDLEtBQUtKLFNBQVM7QUFDekMsYUFBT0ksTUFBT0UsT0FBT04sS0FBS2lELFFBQVEsSUFBSTNDLE9BQU9OLEtBQUtrRCxVQUFVO0FBQUEsSUFDaEUsR0FBRyxDQUFDO0FBRUosVUFBTU4scUJBQXFCSSxNQUFNN0MsT0FBTyxDQUFDQyxLQUFLSixTQUFTO0FBQ25ELGFBQU9JLE9BQU9FLE9BQU9OLEtBQUttRCxlQUFlLEtBQUs7QUFBQSxJQUNsRCxHQUFHLENBQUM7QUFFSixVQUFNTix1QkFBdUJ2QyxPQUFPc0IsTUFBTXVCLGVBQWUsS0FBSztBQUU5RCxVQUFNTCxVQUFVSCxXQUFXQyxxQkFBcUJDO0FBRWhELFFBQUlFLGFBQWE7QUFDakIsUUFBSSxDQUFDTixtQkFBbUI7QUFDcEIsVUFBSWIsTUFBTXdCLHNCQUFzQjtBQUM1QkwscUJBQWFDLE1BQU03QyxPQUFPLENBQUNDLEtBQUtKLFNBQVM7QUFDckMsZ0JBQU1xRCxpQkFBaUJyRCxLQUFLQyxTQUFTLElBQUlFLE9BQU8sQ0FBQ21ELFNBQVNqRCxRQUFRaUQsVUFBVWhELE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQ2pHLGlCQUFPSCxNQUFNaUQ7QUFBQUEsUUFDakIsR0FBRyxDQUFDO0FBQUEsTUFDUixPQUFPO0FBQ0hOLHNCQUFjbkIsTUFBTTNCLFNBQVMsSUFBSUUsT0FBTyxDQUFDQyxLQUFLQyxRQUFRRCxNQUFNRSxPQUFPRCxJQUFJRSxNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQ3JGO0FBQUEsSUFDSjtBQUVBLFdBQU8sRUFBRW9DLFVBQVVDLG9CQUFvQkMsc0JBQXNCQyxTQUFTQyxXQUFXO0FBQUEsRUFDckYsR0FBRyxDQUFDbkIsT0FBT2EsaUJBQWlCLENBQUM7QUFFN0IsTUFBSVosUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUE0QkE7QUFBQUEsT0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnRTtBQUNsRixNQUFJLENBQUNGLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLHlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9FO0FBRXZGLFFBQU0yQixnQkFBZ0JBLENBQUNDLFdBQTRCO0FBQy9DLFlBQVFDLE9BQU9ELE1BQU0sR0FBQztBQUFBLE1BQ2xCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakI7QUFBUyxlQUFPO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQ0EsUUFBTUUscUJBQXFCQSxDQUFDRixXQUE0QjtBQUNwRCxZQUFRQyxPQUFPRCxNQUFNLEdBQUM7QUFBQSxNQUNsQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCO0FBQVMsZUFBTztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU1HLGNBQWMsWUFBWTtBQUM1QixRQUFJLENBQUMvQixNQUFPO0FBRVosVUFBTWdDLFVBQVV0RSxnQkFBZ0I7QUFDaEMsUUFBSSxDQUFDc0UsU0FBUztBQUNWcEUsWUFBTXNDLE1BQU0sOENBQThDO0FBQzFEO0FBQUEsSUFDSjtBQUVBZixrQkFBYyxJQUFJO0FBQ2xCLFFBQUk7QUFDQSxZQUFNeEIsaUJBQWlCcUUsU0FBUyxpQkFBaUJoQyxNQUFNbEIsRUFBRSxNQUFNO0FBQUEsSUFDbkUsU0FBU21ELEtBQUs7QUFDVixVQUFJLENBQUNELFFBQVFFLE9BQU9DLE9BQVFILFNBQVFFLE9BQU9FLE1BQU07QUFDakRDLGNBQVFuQyxNQUFNLDRCQUE0QitCLEdBQUc7QUFDN0NyRSxZQUFNc0MsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dmLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFFQSxRQUFNbUQsa0JBQWtCLFlBQVk7QUFDaEMsUUFBSSxDQUFDdEMsTUFBTztBQUNaWCxxQkFBaUIsSUFBSTtBQUNyQixRQUFJO0FBQ0EsWUFBTTdCLG9CQUFnQ3dDLE1BQU1sQixFQUFFO0FBQzlDbEIsWUFBTTJFLFFBQVEsa0NBQWtDO0FBQ2hEeEQsZUFBU2Isa0JBQWtCbkIscUNBQXFDeUYsU0FBUyxDQUFDO0FBQUEsSUFDOUUsU0FBU1AsS0FBYztBQUNuQkksY0FBUW5DLE1BQU0rQixHQUFHO0FBQ2pCLFlBQU1RLE1BQ0ZSLE9BQ0ksT0FBT0EsUUFBUSxZQUNmLGNBQWNBLE9BQ2RBLElBQUlTLFlBQ0osT0FBT1QsSUFBSVMsYUFBYSxZQUN4QixVQUFVVCxJQUFJUyxZQUNkVCxJQUFJUyxTQUFTQyxRQUNiLE9BQU9WLElBQUlTLFNBQVNDLFNBQVMsWUFDN0IsYUFBYVYsSUFBSVMsU0FBU0MsUUFDMUIsT0FBUVYsSUFBSVMsU0FBU0MsS0FBOEJDLFlBQVksV0FDNURYLElBQUlTLFNBQVNDLEtBQTZCQyxVQUMzQztBQUNWaEYsWUFBTXNDLE1BQU11QyxLQUFLSSxLQUFLLElBQUlKLE1BQU0saUNBQWlDO0FBQUEsSUFDckUsVUFBQztBQUNHcEQsdUJBQWlCLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0o7QUFFQSxRQUFNeUQsdUJBQXVCQSxNQUFNO0FBQy9CLFFBQUksQ0FBQzlDLE1BQU87QUFDWmYsMEJBQXNCO0FBQUEsTUFDbEI4RCxPQUFPO0FBQUEsTUFDUEgsU0FBUyxpQ0FBaUM1QyxNQUFNZ0QsWUFBWTtBQUFBLE1BQzVEQyxXQUFXQSxNQUFNO0FBQ2IsYUFBS1gsZ0JBQWdCO0FBQUEsTUFDekI7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTVksa0JBQWtCckIsT0FBTzdCLE1BQU00QixNQUFNLE1BQU07QUFDakQsUUFBTXVCLHNCQUFzQmhELGdCQUFnQitDO0FBRTVDLFFBQU1FLGtCQUFrQjtBQUN4QixRQUFNQyxrQkFBa0I7QUFFeEIsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBRVg7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUVBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNdEUsU0FBU2Isa0JBQWtCbkIscUNBQXFDeUYsU0FBUyxDQUFDO0FBQUEsWUFDekYsV0FBVTtBQUFBLFlBRVYsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUE7QUFBQSxVQUxwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxpREFBK0M7QUFBQTtBQUFBLFlBQ2hEeEMsTUFBTWdEO0FBQUFBLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVyx1REFBdURsQixtQkFBbUI5QixNQUFNNEIsTUFBTSxDQUFDLElBQ25HRCx3QkFBYzNCLE1BQU00QixNQUFNLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNHO0FBQUFBLFlBQ1QsVUFBVTdDO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLHVCQUNHLHVCQUFDLGFBQVUsV0FBVSwwQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsSUFFM0MsdUJBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUE7QUFBQSxVQVRwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUssb0JBQW9CLElBQUk7QUFBQSxZQUN2QyxVQUFVLENBQUNnQjtBQUFBQSxZQUNYLFdBQVU7QUFBQSxZQUE0TDtBQUFBO0FBQUEsVUFKMU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNDNEMsdUJBQ0c7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNMO0FBQUFBLFlBQ1QsVUFBVTFEO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLDBCQUFnQix1QkFBQyxhQUFVLFdBQVUsMEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLElBQU07QUFBQTtBQUFBLFVBTnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0E3QlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQTtBQUFBLFNBbERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtREE7QUFBQSxJQUVBLHVCQUFDLFFBQUcsV0FBVSxrRUFDVjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2dFLGlCQUFpQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBVSw4QkFDVjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csSUFBSSxhQUFhcEQsTUFBTU0sUUFBUXhCLEVBQUU7QUFBQSxZQUNqQyxXQUFVO0FBQUEsWUFFVGtCLGdCQUFNTSxRQUFRZ0QsUUFBUXRELE1BQU11RCxlQUFlO0FBQUE7QUFBQSxVQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdILGlCQUFpQiw0QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJqRyxzQkFBWTZDLE1BQU13RCxZQUFZLE1BQU0sS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFdBRnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXSixpQkFBaUIsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCcEQsZ0JBQU15RCxnQkFBZ0J0RyxZQUFZNkMsTUFBTXlELGVBQWUsTUFBTSxJQUFJLFNBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV0wsaUJBQWlCLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QnBELGdCQUFNMEQsYUFBYUosUUFBUSxTQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsV0FGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdGLGlCQUFpQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQ3pDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJwRCxnQkFBTTJELE9BQU9MLFFBQVEsU0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFdBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXRixpQkFBaUIsMEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUMxQyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCcEQsZ0JBQU00RCxXQUFXTixRQUFRLFNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxXQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV0YsaUJBQWlCLHNCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFDdEMsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QnBELGdCQUFNNkQsVUFBVVAsUUFBUSxTQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsV0FGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdGLGlCQUFpQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJwRCxnQkFBTThELHlCQUF5QixTQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsV0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdWLGlCQUFpQixpQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJwRCxnQkFBTStELG9CQUFvQixTQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsV0FGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdYLGlCQUFpQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFFBQUcsV0FBVSw4QkFBOEJwRCxnQkFBTWdFLFNBQVMsU0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFdBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXWixpQkFBaUIsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsOEJBQThCcEQsZ0JBQU1pRSxpQkFBaUIsU0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFdBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBbkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWCxpQ0FBQyxTQUFJLFdBQVUsc0dBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVcsR0FBR2IsZUFBZSxrQkFBa0Isa0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUN0RXhELGlCQUNHLHVCQUFDLGFBQVUsV0FBVSxzQ0FBcUMsY0FBVyxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRixJQUNyRkUsZUFDQSx1QkFBQyxVQUFLLFdBQVUsd0JBQXdCQSwwQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRCxJQUNyRFMsdUJBQXVCYixpQkFBaUIsT0FDeEMsdUJBQUMsVUFBSyxXQUFVLHVDQUNYdkMsc0JBQVl1QyxlQUFlLFVBQVUsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixpQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFdBWGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTUQsOEJBQThCLElBQUk7QUFBQSxVQUNqRCxVQUFVLENBQUNjO0FBQUFBLFVBQ1gsV0FBVTtBQUFBLFVBQTRMO0FBQUE7QUFBQSxRQUoxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLG9EQUFrRCxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxxQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsNkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNsRixDQUFDTSxxQkFBcUJiLE1BQU13Qix3QkFDekIsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx5QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUV4Rix1QkFBQyxRQUFHLFdBQVUsMkVBQTBFLDJCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBVHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNYeEIsaUJBQU1vQixTQUFTLElBQUk4QyxJQUFJLENBQUM5RixNQUFNK0YsVUFBVTtBQUN0QyxnQkFBTXBELFdBQVlyQyxPQUFPTixLQUFLaUQsUUFBUSxJQUFJM0MsT0FBT04sS0FBS2tELFVBQVU7QUFDaEUsZ0JBQU04QyxXQUFXMUYsT0FBT04sS0FBS21ELGVBQWUsS0FBSztBQUNqRCxnQkFBTThDLGVBQWV0RCxXQUFXcUQ7QUFDaEMsZ0JBQU1FLFVBQVUsQ0FBQ3pELHFCQUFxQmIsTUFBTXdCLHVCQUF1QnJELGdCQUFnQkMsSUFBSSxJQUFJO0FBQzNGLGdCQUFNbUcsWUFBWUYsZUFBZUM7QUFFakMsaUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxrQ0FDVGxHLGVBQUtvRyxhQUNGLHVCQUFDLFFBQUssSUFBSSxjQUFjcEcsS0FBS29HLFVBQVUsSUFBSSxXQUFVLHlEQUNqRDtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFBNkJwRyxlQUFLcUcsZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FDOUQsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsZ0JBQUVyRyxLQUFLc0c7QUFBQUEsZ0JBQWE7QUFBQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxJQUVBLG1DQUNJO0FBQUEscUNBQUMsU0FBSSxXQUFVLDZCQUE2QnRHLGVBQUtxRyxnQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxnQkFBRXJHLEtBQUtzRztBQUFBQSxnQkFBYTtBQUFBLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3RHLGVBQUtpRCxZQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENsRSxzQkFBWWlCLEtBQUtrRCxZQUFZLFVBQVUsS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUc7QUFBQSxZQUNyRyx1QkFBQyxRQUFHLFdBQVUsOENBQThDbkUsc0JBQVlpSCxVQUFVLFVBQVUsS0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUM5Rix1QkFBQyxRQUFHLFdBQVUsOENBQThDakgsc0JBQVlrSCxjQUFjLFVBQVUsS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0c7QUFBQSxZQUNqRyxDQUFDeEQscUJBQXFCYixNQUFNd0Isd0JBQ3pCLHVCQUFDLFFBQUcsV0FBVSw4Q0FDVHJFLHNCQUFZbUgsU0FBUyxVQUFVLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVKLHVCQUFDLFFBQUcsV0FBVSx1RUFDVG5ILHNCQUFZb0gsV0FBVyxVQUFVLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXpCS25HLEtBQUtVLE1BQU1xRixPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFFBRVIsQ0FBQyxLQXJDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsV0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFEQSxLQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsU0EzREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTREQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVEQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUM5Qix1QkFBQyxTQUFJLFdBQVUsaUJBQ1YsV0FBQ3RELHFCQUFxQixDQUFDYixNQUFNd0Isd0JBQXdCeEIsTUFBTTNCLFNBQVMyQixNQUFNM0IsTUFBTUMsU0FBUyxLQUN0Rix1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNENBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM3RTBCLE1BQU0zQixNQUFNNkY7QUFBQUEsVUFBSSxDQUFDekYsS0FBSzBGLFVBQ25CLHVCQUFDLFNBQThCLFdBQVUscUNBQ3JDO0FBQUEsbUNBQUMsVUFBSyxXQUFXZixnQkFBZ0J1QixRQUFRLGlCQUFpQixlQUFlLEdBQUlsRztBQUFBQSxrQkFBSW1HO0FBQUFBLGNBQVM7QUFBQSxjQUFHbkcsSUFBSW9HO0FBQUFBLGNBQUs7QUFBQSxpQkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUc7QUFBQSxZQUN6Ryx1QkFBQyxVQUFLLFdBQVd4QixpQkFBa0JsRyxzQkFBWXNCLElBQUlFLFFBQVEsVUFBVSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmpFRixJQUFJcUcsVUFBVVgsT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0g7QUFBQSxXQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHFEQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXZixpQkFBaUIsaUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBa0JsRyxzQkFBWTJELGlCQUFpQkMsVUFBVSxVQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsYUFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVdxQyxpQkFBaUIsOEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDaEQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUdsRyxZQUFZMkQsaUJBQWlCRSxvQkFBb0IsVUFBVTtBQUFBLGVBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsYUFGdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVdvQyxpQkFBaUIsK0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUdsRyxZQUFZMkQsaUJBQWlCRyxzQkFBc0IsVUFBVTtBQUFBLGVBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsYUFGeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQyxDQUFDSixxQkFDRSxtQ0FDSTtBQUFBLGlDQUFDLFNBQUksV0FBVSx3REFDWDtBQUFBLG1DQUFDLFVBQUssV0FBVyxHQUFHdUMsZUFBZSxrQkFBa0IsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGdCQUFnQnNCLFFBQVEsV0FBVyxXQUFXLENBQUMsa0JBQW1CeEgsc0JBQVkyRCxpQkFBaUJJLFNBQVMsVUFBVSxLQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3STtBQUFBLGVBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBV2tDLGlCQUNacEQsZ0JBQU13Qix1QkFBdUIsdUJBQXVCLHlCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVc2QixpQkFBaUI7QUFBQTtBQUFBLGNBQUdsRyxZQUFZMkQsaUJBQWlCSyxZQUFZLFVBQVU7QUFBQSxpQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxlQUo5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVKLHVCQUFDLFNBQUksV0FBVSx3REFDWDtBQUFBLGlDQUFDLFVBQUssV0FBVyxHQUFHaUMsZUFBZSwwQkFBMEIsNEJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGdCQUFnQnNCLFFBQVEsV0FBVyxTQUFTLENBQUMsOEJBQzVEeEgsc0JBQVk2QyxNQUFNK0UsY0FBYyxVQUFVLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQWpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUXpGO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSztBQUFBLFFBQ3hDLFVBQVVhO0FBQUFBO0FBQUFBLE1BSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzRCO0FBQUEsSUFFNUI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVFaO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyw4QkFBOEIsS0FBSztBQUFBLFFBQ2xELFVBQVVXO0FBQUFBO0FBQUFBLE1BSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzRCO0FBQUEsT0FsUWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvUUE7QUFFUjtBQUFFdkIsR0F6YVdELDhCQUE0QjtBQUFBLFVBQ3RCakMsV0FDRUMsYUFDZWtCLGdCQUNFQyxVQVFNakIsV0FBVztBQUFBO0FBQUFrSSxLQVoxQ3BHO0FBQTRCLElBQUFvRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlQ3J1ZEl0ZW0iLCJhdXRvcml6YWNpb25QZWRpZG9EZXRhaWxNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QcmludCIsImZvcm1hdFZhbHVlIiwiaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsImF1dGhvcml6ZVNhbGVzT3JkZXIiLCJnZXRDbGllbnRDdXJyZW50QmFsYW5jZSIsImJlZ2luUGRmUHJldmlldyIsImZpbmlzaFBkZlByZXZpZXciLCJ0b2FzdCIsIkZhU3Bpbm5lciIsInVzZVBlcm1pc3Npb25zIiwidXNlTW9kYWwiLCJDbGllbnRlQ29icmFuemFzTW9kYWwiLCJDbGllbnRlQ3VlbnRhQ29ycmllbnRlTW9kYWwiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImdldEl0ZW1UYXhUb3RhbCIsIml0ZW0iLCJ0YXhlcyIsImxlbmd0aCIsInJlZHVjZSIsInN1bSIsInRheCIsIk51bWJlciIsImFtb3VudCIsIkF1dG9yaXphY2lvblBlZGlkb0RldGFpbFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwic2hvd0NvbmZpcm1hdGlvbk1vZGFsIiwiaXNQcmludGluZyIsInNldElzUHJpbnRpbmciLCJpc0F1dGhvcml6aW5nIiwic2V0SXNBdXRob3JpemluZyIsImlzUGFnb3NNb2RhbE9wZW4iLCJzZXRJc1BhZ29zTW9kYWxPcGVuIiwiaXNDdWVudGFDb3JyaWVudGVNb2RhbE9wZW4iLCJzZXRJc0N1ZW50YUNvcnJpZW50ZU1vZGFsT3BlbiIsImNsaWVudEJhbGFuY2UiLCJzZXRDbGllbnRCYWxhbmNlIiwiYmFsYW5jZUxvYWRpbmciLCJzZXRCYWxhbmNlTG9hZGluZyIsImJhbGFuY2VFcnJvciIsInNldEJhbGFuY2VFcnJvciIsIm9yZGVyIiwibG9hZGluZyIsImVycm9yIiwiY2FuQXV0aG9yaXplIiwib3JkZXJDbGllbnRJZCIsImNsaWVudF9pZCIsImNsaWVudCIsImNhbk9wZW5DbGllbnRNb2RhbHMiLCJ0aGVuIiwicmVzIiwiYmFsYW5jZSIsImNhdGNoIiwiZmluYWxseSIsImlzQ2xpZW50VGF4RXhlbXB0IiwiY2FsY3VsYXRlZFRvdGFscyIsInN1YnRvdGFsIiwidG90YWxJdGVtRGlzY291bnRzIiwiZ2xvYmFsRGlzY291bnRBbW91bnQiLCJ0YXhCYXNlIiwidG90YWxUYXhlcyIsIml0ZW1zIiwicXVhbnRpdHkiLCJ1bml0X3ByaWNlIiwiZGlzY291bnRfYW1vdW50IiwiaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMiLCJpdGVtVGF4QW1vdW50IiwiaXRlbVN1bSIsImdldFN0YXR1c1RleHQiLCJzdGF0dXMiLCJTdHJpbmciLCJnZXRTdGF0dXNDbGFzc05hbWUiLCJoYW5kbGVQcmludCIsInNlc3Npb24iLCJlcnIiLCJ3aW5kb3ciLCJjbG9zZWQiLCJjbG9zZSIsImNvbnNvbGUiLCJoYW5kbGVBdXRob3JpemUiLCJzdWNjZXNzIiwiYmFzZVJvdXRlIiwibXNnIiwicmVzcG9uc2UiLCJkYXRhIiwibWVzc2FnZSIsInRyaW0iLCJvcGVuQXV0aG9yaXplQ29uZmlybSIsInRpdGxlIiwib3JkZXJfbnVtYmVyIiwib25Db25maXJtIiwiaXNQZW5kaW5nU3RhdHVzIiwic2hvd0F1dGhvcml6ZUJ1dHRvbiIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsIm5hbWUiLCJjbGllbnRfbmFtZSIsIm9yZGVyX2RhdGUiLCJkZWxpdmVyeV9kYXRlIiwic2FsZXNwZXJzb24iLCJidXllciIsInRyYW5zcG9ydCIsImN1cnJlbmN5IiwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyIiwiZGVsaXZlcnlfYWRkcmVzcyIsIm5vdGVzIiwiZXhjaGFuZ2VfcmF0ZSIsIm1hcCIsImluZGV4IiwiZGlzY291bnQiLCJsaW5lU3VidG90YWwiLCJpdGVtVGF4IiwibGluZVRvdGFsIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3RfY29kZSIsInJlcGxhY2UiLCJ0YXhfbmFtZSIsInJhdGUiLCJ0YXhfaWQiLCJ0b3RhbF9hbW91bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRvcml6YWNpb25QZWRpZG9EZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHR5cGUgU2FsZXNPcmRlciwgdHlwZSBTYWxlc09yZGVySXRlbSB9IGZyb20gJy4uLy4uL3BlZGlkb3NfdmVudGEvcGVkaWRvc192ZW50YV9jb25maWcnO1xuaW1wb3J0IHsgYXV0b3JpemFjaW9uUGVkaWRvRGV0YWlsTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vYXV0b3JpemFjaW9uX3BlZGlkb3MuY29uZmlnJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9QcmludCB9IGZyb20gJ3JlYWN0LWljb25zL2lvNSc7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2NsaWVudFRheEV4ZW1wdGlvbic7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgYXV0aG9yaXplU2FsZXNPcmRlciwgZ2V0Q2xpZW50Q3VycmVudEJhbGFuY2UgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IGJlZ2luUGRmUHJldmlldywgZmluaXNoUGRmUHJldmlldyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IHVzZU1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29udGV4dC9Nb2RhbENvbnRleHQnO1xuaW1wb3J0IHsgQ2xpZW50ZUNvYnJhbnphc01vZGFsIH0gZnJvbSAnLi4vY29tcG9uZW50cy9DbGllbnRlQ29icmFuemFzTW9kYWwnO1xuaW1wb3J0IHsgQ2xpZW50ZUN1ZW50YUNvcnJpZW50ZU1vZGFsIH0gZnJvbSAnLi4vY29tcG9uZW50cy9DbGllbnRlQ3VlbnRhQ29ycmllbnRlTW9kYWwnO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmNvbnN0IGdldEl0ZW1UYXhUb3RhbCA9IChpdGVtOiBTYWxlc09yZGVySXRlbSkgPT4ge1xuICAgIGlmICghaXRlbS50YXhlcyB8fCBpdGVtLnRheGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgcmV0dXJuIGl0ZW0udGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbn07XG5cbmV4cG9ydCBjb25zdCBBdXRvcml6YWNpb25QZWRpZG9EZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IHsgc2hvd0NvbmZpcm1hdGlvbk1vZGFsIH0gPSB1c2VNb2RhbCgpO1xuICAgIGNvbnN0IFtpc1ByaW50aW5nLCBzZXRJc1ByaW50aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaXNBdXRob3JpemluZywgc2V0SXNBdXRob3JpemluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzUGFnb3NNb2RhbE9wZW4sIHNldElzUGFnb3NNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtpc0N1ZW50YUNvcnJpZW50ZU1vZGFsT3Blbiwgc2V0SXNDdWVudGFDb3JyaWVudGVNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjbGllbnRCYWxhbmNlLCBzZXRDbGllbnRCYWxhbmNlXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtiYWxhbmNlTG9hZGluZywgc2V0QmFsYW5jZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtiYWxhbmNlRXJyb3IsIHNldEJhbGFuY2VFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCB7IGl0ZW06IG9yZGVyLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08U2FsZXNPcmRlcj4oYXV0b3JpemFjaW9uUGVkaWRvRGV0YWlsTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBjYW5BdXRob3JpemUgPSBoYXNNb2R1bGVQZXJtaXNzaW9uKCdzYWxlc19vcmRlcl9hdXRob3JpemF0aW9uJywgJ2VkaXQnKTtcblxuICAgIGNvbnN0IG9yZGVyQ2xpZW50SWQgPSBvcmRlcj8uY2xpZW50X2lkID8/IG9yZGVyPy5jbGllbnQ/LmlkID8/IG51bGw7XG4gICAgY29uc3QgY2FuT3BlbkNsaWVudE1vZGFscyA9IG9yZGVyQ2xpZW50SWQgIT0gbnVsbCAmJiBOdW1iZXIob3JkZXJDbGllbnRJZCkgPiAwO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFjYW5PcGVuQ2xpZW50TW9kYWxzIHx8IG9yZGVyQ2xpZW50SWQgPT0gbnVsbCkge1xuICAgICAgICAgICAgc2V0Q2xpZW50QmFsYW5jZShudWxsKTtcbiAgICAgICAgICAgIHNldEJhbGFuY2VFcnJvcihudWxsKTtcbiAgICAgICAgICAgIHNldEJhbGFuY2VMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZXRCYWxhbmNlTG9hZGluZyh0cnVlKTtcbiAgICAgICAgc2V0QmFsYW5jZUVycm9yKG51bGwpO1xuICAgICAgICB2b2lkIGdldENsaWVudEN1cnJlbnRCYWxhbmNlKG9yZGVyQ2xpZW50SWQpXG4gICAgICAgICAgICAudGhlbihyZXMgPT4gc2V0Q2xpZW50QmFsYW5jZShOdW1iZXIocmVzLmJhbGFuY2UpKSlcbiAgICAgICAgICAgIC5jYXRjaCgoKSA9PiBzZXRCYWxhbmNlRXJyb3IoJ05vIHNlIHB1ZG8gY2FyZ2FyIGxhIGRldWRhIGRlbCBjbGllbnRlLicpKVxuICAgICAgICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0QmFsYW5jZUxvYWRpbmcoZmFsc2UpKTtcbiAgICB9LCBbb3JkZXJDbGllbnRJZCwgY2FuT3BlbkNsaWVudE1vZGFsc10pO1xuXG4gICAgY29uc3QgaXNDbGllbnRUYXhFeGVtcHQgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0KG9yZGVyPy5jbGllbnQpLFxuICAgICAgICBbb3JkZXI/LmNsaWVudF1cbiAgICApO1xuXG4gICAgY29uc3QgY2FsY3VsYXRlZFRvdGFscyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIW9yZGVyKSB7XG4gICAgICAgICAgICByZXR1cm4geyBzdWJ0b3RhbDogMCwgdG90YWxJdGVtRGlzY291bnRzOiAwLCBnbG9iYWxEaXNjb3VudEFtb3VudDogMCwgdGF4QmFzZTogMCwgdG90YWxUYXhlczogMCB9O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaXRlbXMgPSBvcmRlci5pdGVtcyB8fCBbXTtcblxuICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gc3VtICsgKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKTtcbiAgICAgICAgfSwgMCk7XG5cbiAgICAgICAgY29uc3QgdG90YWxJdGVtRGlzY291bnRzID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHtcbiAgICAgICAgICAgIHJldHVybiBzdW0gKyAoTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwKTtcbiAgICAgICAgfSwgMCk7XG5cbiAgICAgICAgY29uc3QgZ2xvYmFsRGlzY291bnRBbW91bnQgPSBOdW1iZXIob3JkZXIuZGlzY291bnRfYW1vdW50KSB8fCAwO1xuXG4gICAgICAgIGNvbnN0IHRheEJhc2UgPSBzdWJ0b3RhbCAtIHRvdGFsSXRlbURpc2NvdW50cyAtIGdsb2JhbERpc2NvdW50QW1vdW50O1xuXG4gICAgICAgIGxldCB0b3RhbFRheGVzID0gMDtcbiAgICAgICAgaWYgKCFpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgaWYgKG9yZGVyLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICAgICAgdG90YWxUYXhlcyA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXhBbW91bnQgPSAoaXRlbS50YXhlcyB8fCBbXSkucmVkdWNlKChpdGVtU3VtLCB0YXgpID0+IGl0ZW1TdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3VtICsgaXRlbVRheEFtb3VudDtcbiAgICAgICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG90YWxUYXhlcyA9IChvcmRlci50YXhlcyB8fCBbXSkucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbEl0ZW1EaXNjb3VudHMsIGdsb2JhbERpc2NvdW50QW1vdW50LCB0YXhCYXNlLCB0b3RhbFRheGVzIH07XG4gICAgfSwgW29yZGVyLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBhbCBjYXJnYXIgZWwgcGVkaWRvOiB7ZXJyb3J9PC9kaXY+O1xuICAgIGlmICghb3JkZXIpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5ObyBzZSBlbmNvbnRyw7MgZWwgcGVkaWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IGdldFN0YXR1c1RleHQgPSAoc3RhdHVzOiBzdHJpbmcgfCBudW1iZXIpID0+IHtcbiAgICAgICAgc3dpdGNoIChTdHJpbmcoc3RhdHVzKSkge1xuICAgICAgICAgICAgY2FzZSAnMSc6IHJldHVybiAnUGVuZGllbnRlJztcbiAgICAgICAgICAgIGNhc2UgJzInOiByZXR1cm4gJ1Byb2Nlc2Fkbyc7XG4gICAgICAgICAgICBjYXNlICczJzogcmV0dXJuICdBdXRvcml6YWRvJztcbiAgICAgICAgICAgIGNhc2UgJzAnOiByZXR1cm4gJ0FudWxhZG8nO1xuICAgICAgICAgICAgZGVmYXVsdDogcmV0dXJuICdEZXNjb25vY2lkbyc7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGdldFN0YXR1c0NsYXNzTmFtZSA9IChzdGF0dXM6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBzd2l0Y2ggKFN0cmluZyhzdGF0dXMpKSB7XG4gICAgICAgICAgICBjYXNlICcxJzogcmV0dXJuICdiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCc7XG4gICAgICAgICAgICBjYXNlICcyJzogcmV0dXJuICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnO1xuICAgICAgICAgICAgY2FzZSAnMyc6IHJldHVybiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgICAgICAgIGNhc2UgJzAnOiByZXR1cm4gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJztcbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghb3JkZXIpIHJldHVybjtcblxuICAgICAgICBjb25zdCBzZXNzaW9uID0gYmVnaW5QZGZQcmV2aWV3KCk7XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1Blcm1pdMOtIHZlbnRhbmFzIGVtZXJnZW50ZXMgcGFyYSB2ZXIgZWwgUERGLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNQcmludGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9zYWxlcy1vcmRlcnMvJHtvcmRlci5pZH0vcGRmYCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBnZW5lcmFyIGVsIFBERjonLCBlcnIpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCBjb21wcm9iYW50ZSBQREYuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1ByaW50aW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBdXRob3JpemUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghb3JkZXIpIHJldHVybjtcbiAgICAgICAgc2V0SXNBdXRob3JpemluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGF1dGhvcml6ZVNhbGVzT3JkZXI8U2FsZXNPcmRlcj4ob3JkZXIuaWQpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnUGVkaWRvIGF1dG9yaXphZG8gY29ycmVjdGFtZW50ZS4nKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGF1dG9yaXphY2lvblBlZGlkb0RldGFpbE1vZHVsZUNvbmZpZy5iYXNlUm91dGUpKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICBjb25zdCBtc2cgPVxuICAgICAgICAgICAgICAgIGVyciAmJlxuICAgICAgICAgICAgICAgICAgICB0eXBlb2YgZXJyID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgICAgICAgICAncmVzcG9uc2UnIGluIGVyciAmJlxuICAgICAgICAgICAgICAgICAgICBlcnIucmVzcG9uc2UgJiZcbiAgICAgICAgICAgICAgICAgICAgdHlwZW9mIGVyci5yZXNwb25zZSA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgICAgICAgICAgICAgJ2RhdGEnIGluIGVyci5yZXNwb25zZSAmJlxuICAgICAgICAgICAgICAgICAgICBlcnIucmVzcG9uc2UuZGF0YSAmJlxuICAgICAgICAgICAgICAgICAgICB0eXBlb2YgZXJyLnJlc3BvbnNlLmRhdGEgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAgICAgICAgICdtZXNzYWdlJyBpbiBlcnIucmVzcG9uc2UuZGF0YSAmJlxuICAgICAgICAgICAgICAgICAgICB0eXBlb2YgKGVyci5yZXNwb25zZS5kYXRhIGFzIHsgbWVzc2FnZT86IHN0cmluZyB9KS5tZXNzYWdlID09PSAnc3RyaW5nJ1xuICAgICAgICAgICAgICAgICAgICA/IChlcnIucmVzcG9uc2UuZGF0YSBhcyB7IG1lc3NhZ2U6IHN0cmluZyB9KS5tZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgIDogbnVsbDtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKG1zZz8udHJpbSgpID8gbXNnIDogJ05vIHNlIHB1ZG8gYXV0b3JpemFyIGVsIHBlZGlkby4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzQXV0aG9yaXppbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9wZW5BdXRob3JpemVDb25maXJtID0gKCkgPT4ge1xuICAgICAgICBpZiAoIW9yZGVyKSByZXR1cm47XG4gICAgICAgIHNob3dDb25maXJtYXRpb25Nb2RhbCh7XG4gICAgICAgICAgICB0aXRsZTogJ0F1dG9yaXphciBwZWRpZG8nLFxuICAgICAgICAgICAgbWVzc2FnZTogYMK/Q29uZmlybWEgYXV0b3JpemFyIGVsIHBlZGlkbyAke29yZGVyLm9yZGVyX251bWJlcn0/IEVsIGVzdGFkbyBwYXNhcsOhIGEgQXV0b3JpemFkby5gLFxuICAgICAgICAgICAgb25Db25maXJtOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdm9pZCBoYW5kbGVBdXRob3JpemUoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBpc1BlbmRpbmdTdGF0dXMgPSBTdHJpbmcob3JkZXIuc3RhdHVzKSA9PT0gJzEnO1xuICAgIGNvbnN0IHNob3dBdXRob3JpemVCdXR0b24gPSBjYW5BdXRob3JpemUgJiYgaXNQZW5kaW5nU3RhdHVzO1xuXG4gICAgY29uc3QgdG90YWxMYWJlbFN0eWxlID0gJ3RleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCc7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gJ3RleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRleHQtcmlnaHQnO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgbWItNCBib3JkZXItYiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGF1dG9yaXphY2lvblBlZGlkb0RldGFpbE1vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWdyYXktNTAwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVkaWRvOiB7b3JkZXIub3JkZXJfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG10LTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSAke2dldFN0YXR1c0NsYXNzTmFtZShvcmRlci5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNUZXh0KG9yZGVyLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNtOm10LTAgc206bWwtNCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1ByaW50aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQcmludGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUHJpbnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1BhZ29zTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5PcGVuQ2xpZW50TW9kYWxzfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgUGFnb3NcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIHtzaG93QXV0aG9yaXplQnV0dG9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvcGVuQXV0aG9yaXplQ29uZmlybX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNBdXRob3JpemluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNBdXRob3JpemluZyA/IDxGYVNwaW5uZXIgY2xhc3NOYW1lPVwidy01IGgtNSBhbmltYXRlLXNwaW5cIiAvPiA6ICdBdXRvcml6YXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLXgtNCBnYXAteS02IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q2xpZW50ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9jbGllbnRlcy8ke29yZGVyLmNsaWVudD8uaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyLmNsaWVudD8ubmFtZSB8fCBvcmRlci5jbGllbnRfbmFtZSB8fCAnTi9BJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5GZWNoYSBQZWRpZG88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUob3JkZXIub3JkZXJfZGF0ZSwgJ2RhdGUnKX08L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIEVudHJlZ2E8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuZGVsaXZlcnlfZGF0ZSA/IGZvcm1hdFZhbHVlKG9yZGVyLmRlbGl2ZXJ5X2RhdGUsICdkYXRlJykgOiAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlZlbmRlZG9yPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+e29yZGVyLnNhbGVzcGVyc29uPy5uYW1lIHx8ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q29tcHJhZG9yPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+e29yZGVyLmJ1eWVyPy5uYW1lIHx8ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VHJhbnNwb3J0ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntvcmRlci50cmFuc3BvcnQ/Lm5hbWUgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Nb25lZGE8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuY3VycmVuY3k/Lm5hbWUgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5OwrogTy5DLjwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPntvcmRlci5wdXJjaGFzZV9vcmRlcl9udW1iZXIgfHwgJ04vQSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5EaXJlY2Npw7NuIEVudHJlZ2E8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuZGVsaXZlcnlfYWRkcmVzcyB8fCAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9Pk5vdGFzPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+e29yZGVyLm5vdGVzIHx8ICdOL0EnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VGlwbyBkZSBjYW1iaW88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj57b3JkZXIuZXhjaGFuZ2VfcmF0ZSB8fCAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kbD5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHAtNCBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtZ3JheS04MDBgfT5EZXVkYSBkZWwgY2xpZW50ZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YmFsYW5jZUxvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiB0ZXh0LWdyYXktNTAwXCIgYXJpYS1sYWJlbD1cIkNhcmdhbmRvIGRldWRhXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBiYWxhbmNlRXJyb3IgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57YmFsYW5jZUVycm9yfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBjYW5PcGVuQ2xpZW50TW9kYWxzICYmIGNsaWVudEJhbGFuY2UgIT0gbnVsbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUoY2xpZW50QmFsYW5jZSwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj4tPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNDdWVudGFDb3JyaWVudGVNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbk9wZW5DbGllbnRNb2RhbHN9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBDdWVudGEgQ29ycmllbnRlXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgSXRlbXMgZGVsIFBlZGlkb1xuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5BcnTDrWN1bG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RGVzYy4gKE1vbnRvKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+U3VidG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIG9yZGVyLmhhc19pdGVtX2xldmVsX3RheGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+SW1wdWVzdG9zPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC0zIHByLTQgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwci02XCI+VG90YWwgTMOtbmVhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KG9yZGVyLml0ZW1zIHx8IFtdKS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN1YnRvdGFsID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzY291bnQgPSBOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWJ0b3RhbCA9IHN1YnRvdGFsIC0gZGlzY291bnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXggPSAhaXNDbGllbnRUYXhFeGVtcHQgJiYgb3JkZXIuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgPyBnZXRJdGVtVGF4VG90YWwoaXRlbSkgOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsaW5lVG90YWwgPSBsaW5lU3VidG90YWwgKyBpdGVtVGF4O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2R1Y3RfaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9hcnRpY3Vsb3MvJHtpdGVtLnByb2R1Y3RfaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+KHtpdGVtLnByb2R1Y3RfY29kZX0pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntpdGVtLnByb2R1Y3RfbmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntpdGVtLnF1YW50aXR5fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShpdGVtLnVuaXRfcHJpY2UsICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZShkaXNjb3VudCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGxpbmVTdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIG9yZGVyLmhhc19pdGVtX2xldmVsX3RheGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGl0ZW1UYXgsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtMyBwci00IHRleHQtc20gdGV4dC1yaWdodCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIHNtOnByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKGxpbmVUb3RhbCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiAhb3JkZXIuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgb3JkZXIudGF4ZXMgJiYgb3JkZXIudGF4ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgR2xvYmFsZXMgQXBsaWNhZG9zPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXIudGF4ZXMubWFwKCh0YXgsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXt0YXgudGF4X2lkIHx8IGluZGV4fSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlLnJlcGxhY2UoJ3RleHQtZ3JheS02MDAnLCAndGV4dC1ncmF5LTcwMCcpfT57dGF4LnRheF9uYW1lfSAoe3RheC5yYXRlfSUpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHAtNCBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+U3VidG90YWwgKEl0ZW1zKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RGVzYy4gKEl0ZW1zKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+LSB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbEl0ZW1EaXNjb3VudHMsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RGVzYy4gKEdsb2JhbCk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuZ2xvYmFsRGlzY291bnRBbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IGZvbnQtc2VtaWJvbGRgfT5CYXNlIEltcG9uaWJsZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1iYXNlJyl9IGZvbnQtc2VtaWJvbGRgfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50YXhCYXNlLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyLmhhc19pdGVtX2xldmVsX3RheGVzID8gJ0ltcHVlc3RvcyAoSXRlbXMpOicgOiAnSW1wdWVzdG9zIChHbG9iYWwpOid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pisge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxUYXhlcywgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTIgYm9yZGVyLXQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtbGcgZm9udC1zZW1pYm9sZGB9PlRvdGFsIEZpbmFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1sZycpfSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKG9yZGVyLnRvdGFsX2Ftb3VudCwgJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxDbGllbnRlQ29icmFuemFzTW9kYWxcbiAgICAgICAgICAgICAgICBpc09wZW49e2lzUGFnb3NNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNQYWdvc01vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xpZW50SWQ9e29yZGVyQ2xpZW50SWR9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPENsaWVudGVDdWVudGFDb3JyaWVudGVNb2RhbFxuICAgICAgICAgICAgICAgIGlzT3Blbj17aXNDdWVudGFDb3JyaWVudGVNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNDdWVudGFDb3JyaWVudGVNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsaWVudElkPXtvcmRlckNsaWVudElkfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2F1dG9yaXphY2lvbl9wZWRpZG9zL3BhZ2VzL0F1dG9yaXphY2lvblBlZGlkb0RldGFpbFBhZ2UudHN4In0=