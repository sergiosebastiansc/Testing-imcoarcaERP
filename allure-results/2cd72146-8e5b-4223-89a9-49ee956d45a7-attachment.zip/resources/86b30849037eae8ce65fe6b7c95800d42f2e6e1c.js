import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/compradores/pages/CompradoresDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/compradores/pages/CompradoresDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
export const CompradoresDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error } = useCrudItem(compradoresModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Comprador no encontrado." }, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: compradoresModuleConfig, item }, void 0, false, {
    fileName: "/app/src/features/compradores/pages/CompradoresDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(CompradoresDetailPage, "6YQMcrxNTGjd60HB6xOhIbiA4BI=", false, function() {
  return [useParams, useCrudItem];
});
_c = CompradoresDetailPage;
var _c;
$RefreshReg$(_c, "CompradoresDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/compradores/pages/CompradoresDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/compradores/pages/CompradoresDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLCtCQUErQztBQUN4RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBRXhCLGFBQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsR0FBRyxJQUFJUCxVQUEwQjtBQUN6QyxRQUFNLEVBQUVRLE1BQU1DLFNBQVNDLE1BQU0sSUFBSVAsWUFBdUJELHlCQUF5QkssRUFBRTtBQUVuRixNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHdDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkI7QUFFL0MsU0FBTyx1QkFBQyxxQkFBa0IsUUFBUU4seUJBQXlCLFFBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0Q7QUFDMUU7QUFBRUksR0FUV0QsdUJBQXFCO0FBQUEsVUFDZkwsV0FDa0JHLFdBQVc7QUFBQTtBQUFBUSxLQUZuQ047QUFBcUIsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwiY29tcHJhZG9yZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIkxvYWRpbmdTcGlubmVyIiwiQ29tcHJhZG9yZXNEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJsb2FkaW5nIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wcmFkb3Jlc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZywgdHlwZSBDb21wcmFkb3IgfSBmcm9tICcuLi9jb21wcmFkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuXG5leHBvcnQgY29uc3QgQ29tcHJhZG9yZXNEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxDb21wcmFkb3I+KGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFpdGVtKSByZXR1cm4gPGRpdj5Db21wcmFkb3Igbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gPEdlbmVyaWNEZXRhaWxQYWdlIGNvbmZpZz17Y29tcHJhZG9yZXNNb2R1bGVDb25maWd9IGl0ZW09e2l0ZW19IC8+O1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NvbXByYWRvcmVzL3BhZ2VzL0NvbXByYWRvcmVzRGV0YWlsUGFnZS50c3gifQ==