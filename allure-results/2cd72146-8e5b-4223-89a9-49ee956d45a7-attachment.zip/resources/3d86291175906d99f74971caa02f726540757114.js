import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/compradores/pages/CompradoresCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/compradores/pages/CompradoresCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialValues = {
  code: "",
  name: "",
  commission: "0.00",
  client_id: 0,
  client_name: ""
};
export const CompradoresCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(compradoresModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.success(`Comprador creado con éxito!`);
      navigate(getListReturnPath(compradoresModuleConfig.baseRoute));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: compradoresModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/compradores/pages/CompradoresCreatePage.tsx",
      lineNumber: 49,
      columnNumber: 5
    },
    this
  );
};
_s(CompradoresCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = CompradoresCreatePage;
var _c;
$RefreshReg$(_c, "CompradoresCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/compradores/pages/CompradoresCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/compradores/pages/CompradoresCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLCtCQUErQztBQUN4RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFHbEMsTUFBTUMsZ0JBQW9DO0FBQUEsRUFDdENDLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQ2pCO0FBRU8sYUFBTUMsd0JBQXdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdkMsUUFBTUMsV0FBV2QsWUFBWTtBQUM3QixRQUFNLEVBQUVlLFNBQVMsSUFBSVosWUFBdUJELHVCQUF1QjtBQUVuRSxRQUFNYyxhQUFhLE9BQU9DLFNBQW9CO0FBQzFDLFVBQU1DLFVBQVUsTUFBTUgsU0FBU0UsSUFBSTtBQUNuQyxRQUFJQyxTQUFTO0FBQ1RkLFlBQU1lLFFBQVEsNkJBQTZCO0FBQzNDTCxlQUFTVCxrQkFBa0JILHdCQUF3QmtCLFNBQVMsQ0FBQztBQUFBLElBQ2pFO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFsQjtBQUFBQSxNQUNSLGFBQWFJO0FBQUFBLE1BQ2IsUUFBUVU7QUFBQUEsTUFDUixNQUFLO0FBQUE7QUFBQSxJQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlpQjtBQUd6QjtBQUFFSCxHQXBCV0QsdUJBQXFCO0FBQUEsVUFDYlosYUFDSUcsV0FBVztBQUFBO0FBQUFrQixLQUZ2QlQ7QUFBcUIsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwiY29tcHJhZG9yZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInRvYXN0IiwiZ2V0TGlzdFJldHVyblBhdGgiLCJpbml0aWFsVmFsdWVzIiwiY29kZSIsIm5hbWUiLCJjb21taXNzaW9uIiwiY2xpZW50X2lkIiwiY2xpZW50X25hbWUiLCJDb21wcmFkb3Jlc0NyZWF0ZVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwic2F2ZUl0ZW0iLCJoYW5kbGVTYXZlIiwiZGF0YSIsIm5ld0l0ZW0iLCJzdWNjZXNzIiwiYmFzZVJvdXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcHJhZG9yZXNDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLCB0eXBlIENvbXByYWRvciB9IGZyb20gJy4uL2NvbXByYWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbi8vIFZhbG9yZXMgaW5pY2lhbGVzIHBhcmEgdW4gY29tcHJhZG9yIG51ZXZvXG5jb25zdCBpbml0aWFsVmFsdWVzOiBQYXJ0aWFsPENvbXByYWRvcj4gPSB7XG4gICAgY29kZTogJycsXG4gICAgbmFtZTogJycsXG4gICAgY29tbWlzc2lvbjogJzAuMDAnLFxuICAgIGNsaWVudF9pZDogMCxcbiAgICBjbGllbnRfbmFtZTogJycsXG59O1xuXG5leHBvcnQgY29uc3QgQ29tcHJhZG9yZXNDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxDb21wcmFkb3I+KGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogQ29tcHJhZG9yKSA9PiB7XG4gICAgICAgIGNvbnN0IG5ld0l0ZW0gPSBhd2FpdCBzYXZlSXRlbShkYXRhKTtcbiAgICAgICAgaWYgKG5ld0l0ZW0pIHtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYENvbXByYWRvciBjcmVhZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17Y29tcHJhZG9yZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFZhbHVlcyBhcyBDb21wcmFkb3J9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NvbXByYWRvcmVzL3BhZ2VzL0NvbXByYWRvcmVzQ3JlYXRlUGFnZS50c3gifQ==