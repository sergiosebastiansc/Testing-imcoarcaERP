import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/impuestos/components/RetentionProfilesEditorModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import {
  fetchTaxRetentionProfiles,
  updateTaxRetentionProfiles
} from "/src/services/taxRetentionProfilesService.ts";
function cloneProfiles(profiles) {
  return JSON.parse(JSON.stringify(profiles));
}
export function RetentionProfilesEditorModal({
  isOpen,
  taxId,
  canEdit,
  onClose,
  onSaved
}) {
  _s();
  const [taxMeta, setTaxMeta] = useState(null);
  const [profiles, setProfiles] = useState([]);
  const [selectedProfileId, setSelectedProfileId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchTaxRetentionProfiles(taxId);
      setTaxMeta(data.tax);
      const cloned = cloneProfiles(data.profiles);
      setProfiles(cloned);
      setSelectedProfileId(cloned[0]?.id ?? null);
    } catch (e) {
      console.error(e);
      toast.error("No se pudieron cargar los perfiles de retención.");
      setProfiles([]);
      setTaxMeta(null);
      setSelectedProfileId(null);
    } finally {
      setLoading(false);
    }
  }, [taxId]);
  useEffect(() => {
    if (isOpen && taxId) {
      void load();
    }
  }, [isOpen, taxId, load]);
  const selectedProfile = useMemo(
    () => profiles.find((p) => p.id === selectedProfileId) ?? null,
    [profiles, selectedProfileId]
  );
  const updateProfile = useCallback((profileId, updater) => {
    setProfiles((prev) => prev.map((p) => p.id === profileId ? updater(p) : p));
  }, []);
  const updateRange = useCallback(
    (profileId, rangeId, patch) => {
      updateProfile(profileId, (p) => ({
        ...p,
        ranges: p.ranges.map((r) => r.id === rangeId ? { ...r, ...patch } : r)
      }));
    },
    [updateProfile]
  );
  const handleSave = async () => {
    if (!canEdit) return;
    setSaving(true);
    try {
      await updateTaxRetentionProfiles(taxId, {
        profiles: profiles.map((p) => ({
          id: p.id,
          is_active: p.is_active,
          ranges: p.ranges.map((r) => ({
            id: r.id,
            min_base: Number(r.min_base) || 0,
            max_base: r.max_base == null ? null : Number(r.max_base),
            fixed_amount: Number(r.fixed_amount) || 0,
            variable_rate: Number(r.variable_rate) || 0,
            apply_over_excess: Boolean(r.apply_over_excess)
          }))
        }))
      });
      toast.success("Tabla de retención guardada.");
      onSaved?.();
      onClose();
    } catch (e) {
      console.error(e);
      toast.error("No se pudo guardar la tabla de retención.");
    } finally {
      setSaving(false);
    }
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black bg-opacity-50",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "retention-profiles-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[92vh] overflow-hidden flex flex-col",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 px-6 py-4 border-b border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { id: "retention-profiles-modal-title", className: "text-lg font-medium text-gray-900", children: "Tabla de retención" }, void 0, false, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 147,
                  columnNumber: 25
                }, this),
                taxMeta && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-600", children: [
                  taxMeta.name,
                  taxMeta.type_label ? ` · ${taxMeta.type_label}` : ""
                ] }, void 0, true, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 151,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                lineNumber: 146,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: onClose,
                    className: "px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50",
                    children: "Cerrar"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 158,
                    columnNumber: 25
                  },
                  this
                ),
                canEdit && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => void handleSave(),
                    disabled: saving || loading,
                    className: "px-3 py-1.5 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700 disabled:opacity-50",
                    children: saving ? "Guardando…" : "Guardar"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 166,
                    columnNumber: 13
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                lineNumber: 157,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
              lineNumber: 145,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-y-auto flex-1 space-y-4", children: loading ? /* @__PURE__ */ jsxDEV("p", { className: "py-12 text-center text-gray-500", children: "Cargando…" }, void 0, false, {
              fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
              lineNumber: 180,
              columnNumber: 11
            }, this) : profiles.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "py-8 text-center text-sm text-gray-500", children: "No hay perfiles configurados." }, void 0, false, {
              fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
              lineNumber: 182,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { htmlFor: "retention-profile-select", className: "text-sm font-medium text-gray-700", children: "Perfil (caso)" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 187,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      id: "retention-profile-select",
                      value: selectedProfileId ?? "",
                      onChange: (e) => setSelectedProfileId(Number(e.target.value) || null),
                      className: "block w-full sm:w-64 px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm",
                      children: profiles.map(
                        (p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.case_code }, p.id, false, {
                          fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                          lineNumber: 197,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 190,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 186,
                  columnNumber: 33
                }, this),
                selectedProfile && /* @__PURE__ */ jsxDEV("label", { className: "inline-flex items-center gap-2 text-sm text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: selectedProfile.is_active,
                      disabled: !canEdit,
                      onChange: (e) => updateProfile(selectedProfile.id, (p) => ({
                        ...p,
                        is_active: e.target.checked
                      })),
                      className: "rounded border-gray-300 text-indigo-600 focus:ring-indigo-500",
                      autoComplete: "off"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 205,
                      columnNumber: 41
                    },
                    this
                  ),
                  "Activo"
                ] }, void 0, true, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 204,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                lineNumber: 185,
                columnNumber: 29
              }, this),
              selectedProfile && /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 overflow-x-auto border border-gray-200 rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200 text-sm", children: [
                /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left font-medium text-gray-700", children: "Mín. base" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 225,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left font-medium text-gray-700", children: "Máx. base" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 226,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left font-medium text-gray-700", children: "Monto fijo" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 227,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left font-medium text-gray-700", children: "Tasa variable (%)" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 228,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left font-medium text-gray-700", children: "Sobre excedente" }, void 0, false, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 229,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 224,
                  columnNumber: 45
                }, this) }, void 0, false, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 223,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200 bg-white", children: selectedProfile.ranges.map(
                  (r) => /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                      DecimalInput,
                      {
                        className: "w-full min-w-[6rem] px-2 py-1 border border-gray-300 rounded",
                        value: r.min_base,
                        disabled: !canEdit,
                        emptyWhenZero: false,
                        onChange: (num) => updateRange(selectedProfile.id, r.id, { min_base: num ?? 0 })
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                        lineNumber: 236,
                        columnNumber: 57
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 235,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                      DecimalInput,
                      {
                        className: "w-full min-w-[6rem] px-2 py-1 border border-gray-300 rounded",
                        value: r.max_base,
                        disabled: !canEdit,
                        placeholder: "Sin tope",
                        nullable: true,
                        whenEmpty: null,
                        onChange: (num) => updateRange(selectedProfile.id, r.id, { max_base: num })
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                        lineNumber: 245,
                        columnNumber: 57
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 244,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                      DecimalInput,
                      {
                        className: "w-full min-w-[6rem] px-2 py-1 border border-gray-300 rounded",
                        value: r.fixed_amount,
                        disabled: !canEdit,
                        emptyWhenZero: false,
                        onChange: (num) => updateRange(selectedProfile.id, r.id, { fixed_amount: num ?? 0 })
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                        lineNumber: 256,
                        columnNumber: 57
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 255,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                      DecimalInput,
                      {
                        step: "0.01",
                        className: "w-full min-w-[6rem] px-2 py-1 border border-gray-300 rounded",
                        value: Number.isFinite(r.variable_rate) ? r.variable_rate * 100 : 0,
                        disabled: !canEdit,
                        emptyWhenZero: false,
                        onChange: (pct) => updateRange(selectedProfile.id, r.id, {
                          variable_rate: (pct ?? 0) / 100
                        })
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                        lineNumber: 265,
                        columnNumber: 57
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 264,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "checkbox",
                        checked: r.apply_over_excess,
                        disabled: !canEdit,
                        onChange: (e) => updateRange(selectedProfile.id, r.id, {
                          apply_over_excess: e.target.checked
                        }),
                        className: "rounded border-gray-300 text-indigo-600 focus:ring-indigo-500",
                        autoComplete: "off"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                        lineNumber: 277,
                        columnNumber: 57
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                      lineNumber: 276,
                      columnNumber: 53
                    }, this)
                  ] }, r.id, true, {
                    fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                    lineNumber: 234,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                  lineNumber: 232,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                lineNumber: 222,
                columnNumber: 37
              }, this) }, void 0, false, {
                fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
                lineNumber: 221,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
              lineNumber: 184,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
              lineNumber: 178,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
          lineNumber: 141,
          columnNumber: 13
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx",
      lineNumber: 135,
      columnNumber: 5
    },
    this
  );
}
_s(RetentionProfilesEditorModal, "I9sCx/Dw7clj+pJJo59pNbW0lRc=");
_c = RetentionProfilesEditorModal;
var _c;
$RefreshReg$(_c, "RetentionProfilesEditorModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/impuestos/components/RetentionProfilesEditorModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0h3QixTQXFDQSxVQXJDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvSHhCLFNBQVNBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUMxRCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLG9CQUFvQjtBQU03QjtBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0c7QUFFUCxTQUFTQyxjQUFjQyxVQUF3RDtBQUMzRSxTQUFPQyxLQUFLQyxNQUFNRCxLQUFLRSxVQUFVSCxRQUFRLENBQUM7QUFDOUM7QUFXTyxnQkFBU0ksNkJBQTZCO0FBQUEsRUFDekNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQytCLEdBQUc7QUFBQUMsS0FBQTtBQUNsQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWxCLFNBQXFDLElBQUk7QUFDdkUsUUFBTSxDQUFDTSxVQUFVYSxXQUFXLElBQUluQixTQUFnQyxFQUFFO0FBQ2xFLFFBQU0sQ0FBQ29CLG1CQUFtQkMsb0JBQW9CLElBQUlyQixTQUF3QixJQUFJO0FBQzlFLFFBQU0sQ0FBQ3NCLFNBQVNDLFVBQVUsSUFBSXZCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUN3QixRQUFRQyxTQUFTLElBQUl6QixTQUFTLEtBQUs7QUFFMUMsUUFBTTBCLE9BQU83QixZQUFZLFlBQVk7QUFDakMwQixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0EsWUFBTUksT0FBTyxNQUFNeEIsMEJBQTBCUyxLQUFLO0FBQ2xETSxpQkFBV1MsS0FBS0MsR0FBRztBQUNuQixZQUFNQyxTQUFTeEIsY0FBY3NCLEtBQUtyQixRQUFRO0FBQzFDYSxrQkFBWVUsTUFBTTtBQUNsQlIsMkJBQXFCUSxPQUFPLENBQUMsR0FBR0MsTUFBTSxJQUFJO0FBQUEsSUFDOUMsU0FBU0MsR0FBRztBQUNSQyxjQUFRQyxNQUFNRixDQUFDO0FBQ2Y5QixZQUFNZ0MsTUFBTSxrREFBa0Q7QUFDOURkLGtCQUFZLEVBQUU7QUFDZEQsaUJBQVcsSUFBSTtBQUNmRywyQkFBcUIsSUFBSTtBQUFBLElBQzdCLFVBQUM7QUFDR0UsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSixHQUFHLENBQUNYLEtBQUssQ0FBQztBQUVWZCxZQUFVLE1BQU07QUFDWixRQUFJYSxVQUFVQyxPQUFPO0FBQ2pCLFdBQUtjLEtBQUs7QUFBQSxJQUNkO0FBQUEsRUFDSixHQUFHLENBQUNmLFFBQVFDLE9BQU9jLElBQUksQ0FBQztBQUV4QixRQUFNUSxrQkFBa0JuQztBQUFBQSxJQUNwQixNQUFNTyxTQUFTNkIsS0FBSyxDQUFBQyxNQUFLQSxFQUFFTixPQUFPVixpQkFBaUIsS0FBSztBQUFBLElBQ3hELENBQUNkLFVBQVVjLGlCQUFpQjtBQUFBLEVBQ2hDO0FBRUEsUUFBTWlCLGdCQUFnQnhDLFlBQVksQ0FBQ3lDLFdBQW1CQyxZQUE2RDtBQUMvR3BCLGdCQUFZLENBQUFxQixTQUFRQSxLQUFLQyxJQUFJLENBQUFMLE1BQU1BLEVBQUVOLE9BQU9RLFlBQVlDLFFBQVFILENBQUMsSUFBSUEsQ0FBRSxDQUFDO0FBQUEsRUFDNUUsR0FBRyxFQUFFO0FBRUwsUUFBTU0sY0FBYzdDO0FBQUFBLElBQ2hCLENBQUN5QyxXQUFtQkssU0FBaUJDLFVBQXNDO0FBQ3ZFUCxvQkFBY0MsV0FBVyxDQUFBRixPQUFNO0FBQUEsUUFDM0IsR0FBR0E7QUFBQUEsUUFDSFMsUUFBUVQsRUFBRVMsT0FBT0osSUFBSSxDQUFBSyxNQUFNQSxFQUFFaEIsT0FBT2EsVUFBVSxFQUFFLEdBQUdHLEdBQUcsR0FBR0YsTUFBTSxJQUFJRSxDQUFFO0FBQUEsTUFDekUsRUFBRTtBQUFBLElBQ047QUFBQSxJQUNBLENBQUNULGFBQWE7QUFBQSxFQUNsQjtBQUVBLFFBQU1VLGFBQWEsWUFBWTtBQUMzQixRQUFJLENBQUNsQyxRQUFTO0FBQ2RZLGNBQVUsSUFBSTtBQUNkLFFBQUk7QUFDQSxZQUFNckIsMkJBQTJCUSxPQUFPO0FBQUEsUUFDcENOLFVBQVVBLFNBQVNtQyxJQUFJLENBQUFMLE9BQU07QUFBQSxVQUN6Qk4sSUFBSU0sRUFBRU47QUFBQUEsVUFDTmtCLFdBQVdaLEVBQUVZO0FBQUFBLFVBQ2JILFFBQVFULEVBQUVTLE9BQU9KLElBQUksQ0FBQUssT0FBTTtBQUFBLFlBQ3ZCaEIsSUFBSWdCLEVBQUVoQjtBQUFBQSxZQUNObUIsVUFBVUMsT0FBT0osRUFBRUcsUUFBUSxLQUFLO0FBQUEsWUFDaENFLFVBQVVMLEVBQUVLLFlBQVksT0FBTyxPQUFPRCxPQUFPSixFQUFFSyxRQUFRO0FBQUEsWUFDdkRDLGNBQWNGLE9BQU9KLEVBQUVNLFlBQVksS0FBSztBQUFBLFlBQ3hDQyxlQUFlSCxPQUFPSixFQUFFTyxhQUFhLEtBQUs7QUFBQSxZQUMxQ0MsbUJBQW1CQyxRQUFRVCxFQUFFUSxpQkFBaUI7QUFBQSxVQUNsRCxFQUFFO0FBQUEsUUFDTixFQUFFO0FBQUEsTUFDTixDQUFDO0FBQ0RyRCxZQUFNdUQsUUFBUSw4QkFBOEI7QUFDNUN6QyxnQkFBVTtBQUNWRCxjQUFRO0FBQUEsSUFDWixTQUFTaUIsR0FBRztBQUNSQyxjQUFRQyxNQUFNRixDQUFDO0FBQ2Y5QixZQUFNZ0MsTUFBTSwyQ0FBMkM7QUFBQSxJQUMzRCxVQUFDO0FBQ0dSLGdCQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0o7QUFFQSxNQUFJLENBQUNkLE9BQVEsUUFBTztBQUVwQixTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFVO0FBQUEsTUFDVixNQUFLO0FBQUEsTUFDTCxjQUFXO0FBQUEsTUFDWCxtQkFBZ0I7QUFBQSxNQUVoQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csV0FBVTtBQUFBLFVBQ1YsU0FBUyxDQUFBb0IsTUFBS0EsRUFBRTBCLGdCQUFnQjtBQUFBLFVBRWhDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdGQUNYO0FBQUEscUNBQUMsU0FDRztBQUFBLHVDQUFDLFFBQUcsSUFBRyxrQ0FBaUMsV0FBVSxxQ0FBbUMsa0NBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ3hDLFdBQ0csdUJBQUMsT0FBRSxXQUFVLDhCQUNSQTtBQUFBQSwwQkFBUXlDO0FBQUFBLGtCQUNSekMsUUFBUTBDLGFBQWEsTUFBTTFDLFFBQVEwQyxVQUFVLEtBQUs7QUFBQSxxQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxTQUFTN0M7QUFBQUEsb0JBQ1QsV0FBVTtBQUFBLG9CQUEyRztBQUFBO0FBQUEsa0JBSHpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNDRCxXQUNHO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU0sS0FBS2tDLFdBQVc7QUFBQSxvQkFDL0IsVUFBVXZCLFVBQVVGO0FBQUFBLG9CQUNwQixXQUFVO0FBQUEsb0JBRVRFLG1CQUFTLGVBQWU7QUFBQTtBQUFBLGtCQU43QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxtQkFoQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxpQkE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3Q0FDVkYsb0JBQ0csdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyx5QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0QsSUFDeERoQixTQUFTc0QsV0FBVyxJQUNwQix1QkFBQyxPQUFFLFdBQVUsMENBQXlDLDZDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRixJQUVuRixtQ0FDSTtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLHVDQUFDLFNBQUksV0FBVSxtREFDWDtBQUFBLHlDQUFDLFdBQU0sU0FBUSw0QkFBMkIsV0FBVSxxQ0FBbUMsNkJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxJQUFHO0FBQUEsc0JBQ0gsT0FBT3hDLHFCQUFxQjtBQUFBLHNCQUM1QixVQUFVLENBQUFXLE1BQUtWLHFCQUFxQjZCLE9BQU9uQixFQUFFOEIsT0FBT0MsS0FBSyxLQUFLLElBQUk7QUFBQSxzQkFDbEUsV0FBVTtBQUFBLHNCQUVUeEQsbUJBQVNtQztBQUFBQSx3QkFBSSxDQUFBTCxNQUNWLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVOLElBQ3ZCTSxZQUFFMkIsYUFETTNCLEVBQUVOLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNIO0FBQUE7QUFBQSxvQkFWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxxQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQTtBQUFBLGdCQUNDSSxtQkFDRyx1QkFBQyxXQUFNLFdBQVUsd0RBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxNQUFLO0FBQUEsc0JBQ0wsU0FBU0EsZ0JBQWdCYztBQUFBQSxzQkFDekIsVUFBVSxDQUFDbkM7QUFBQUEsc0JBQ1gsVUFBVSxDQUFBa0IsTUFBS00sY0FBY0gsZ0JBQWdCSixJQUFJLENBQUFNLE9BQU07QUFBQSx3QkFDL0MsR0FBR0E7QUFBQUEsd0JBQ0hZLFdBQVdqQixFQUFFOEIsT0FBT0c7QUFBQUEsc0JBQ3hCLEVBQUU7QUFBQSxzQkFFTixXQUFVO0FBQUEsc0JBQWdFLGNBQWE7QUFBQTtBQUFBLG9CQVQzRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU2dHO0FBQUE7QUFBQSxxQkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQS9CUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlDQTtBQUFBLGNBRUM5QixtQkFDRyx1QkFBQyxTQUFJLFdBQVUsNkRBQ1gsaUNBQUMsV0FBTSxXQUFVLCtDQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLHlDQUFDLFFBQUcsV0FBVSxpREFBZ0QseUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEsa0JBQ3ZFLHVCQUFDLFFBQUcsV0FBVSxpREFBZ0QseUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEsa0JBQ3ZFLHVCQUFDLFFBQUcsV0FBVSxpREFBZ0QsMEJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdFO0FBQUEsa0JBQ3hFLHVCQUFDLFFBQUcsV0FBVSxpREFBZ0QsaUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStFO0FBQUEsa0JBQy9FLHVCQUFDLFFBQUcsV0FBVSxpREFBZ0QsK0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZFO0FBQUEscUJBTGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaQSwwQkFBZ0JXLE9BQU9KO0FBQUFBLGtCQUFJLENBQUFLLE1BQ3hCLHVCQUFDLFFBQ0c7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsYUFDVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFVO0FBQUEsd0JBQ1YsT0FBT0EsRUFBRUc7QUFBQUEsd0JBQ1QsVUFBVSxDQUFDcEM7QUFBQUEsd0JBQ1gsZUFBZTtBQUFBLHdCQUNmLFVBQVUsQ0FBQW9ELFFBQU92QixZQUFZUixnQkFBZ0JKLElBQUlnQixFQUFFaEIsSUFBSSxFQUFFbUIsVUFBVWdCLE9BQU8sRUFBRSxDQUFDO0FBQUE7QUFBQSxzQkFMakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUttRixLQU52RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1Y7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVTtBQUFBLHdCQUNWLE9BQU9uQixFQUFFSztBQUFBQSx3QkFDVCxVQUFVLENBQUN0QztBQUFBQSx3QkFDWCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXO0FBQUEsd0JBQ1gsVUFBVSxDQUFBb0QsUUFBT3ZCLFlBQVlSLGdCQUFnQkosSUFBSWdCLEVBQUVoQixJQUFJLEVBQUVxQixVQUFVYyxJQUFJLENBQUM7QUFBQTtBQUFBLHNCQVA1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTzhFLEtBUmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFVO0FBQUEsd0JBQ1YsT0FBT25CLEVBQUVNO0FBQUFBLHdCQUNULFVBQVUsQ0FBQ3ZDO0FBQUFBLHdCQUNYLGVBQWU7QUFBQSx3QkFDZixVQUFVLENBQUFvRCxRQUFPdkIsWUFBWVIsZ0JBQWdCSixJQUFJZ0IsRUFBRWhCLElBQUksRUFBRXNCLGNBQWNhLE9BQU8sRUFBRSxDQUFDO0FBQUE7QUFBQSxzQkFMckY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUt1RixLQU4zRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1Y7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPZixPQUFPZ0IsU0FBU3BCLEVBQUVPLGFBQWEsSUFBSVAsRUFBRU8sZ0JBQWdCLE1BQU07QUFBQSx3QkFDbEUsVUFBVSxDQUFDeEM7QUFBQUEsd0JBQ1gsZUFBZTtBQUFBLHdCQUNmLFVBQVUsQ0FBQXNELFFBQU96QixZQUFZUixnQkFBZ0JKLElBQUlnQixFQUFFaEIsSUFBSTtBQUFBLDBCQUNuRHVCLGdCQUFnQmMsT0FBTyxLQUFLO0FBQUEsd0JBQ2hDLENBQUM7QUFBQTtBQUFBLHNCQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRTyxLQVRYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBV0E7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxNQUFLO0FBQUEsd0JBQ0wsU0FBU3JCLEVBQUVRO0FBQUFBLHdCQUNYLFVBQVUsQ0FBQ3pDO0FBQUFBLHdCQUNYLFVBQVUsQ0FBQWtCLE1BQUtXLFlBQVlSLGdCQUFnQkosSUFBSWdCLEVBQUVoQixJQUFJO0FBQUEsMEJBQzdDd0IsbUJBQW1CdkIsRUFBRThCLE9BQU9HO0FBQUFBLHdCQUNoQyxDQUFDO0FBQUEsd0JBRUwsV0FBVTtBQUFBLHdCQUFnRSxjQUFhO0FBQUE7QUFBQSxzQkFSM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVFnRyxLQVRwRztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVVBO0FBQUEsdUJBcERLbEIsRUFBRWhCLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxREE7QUFBQSxnQkFDSCxLQXhETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlEQTtBQUFBLG1CQW5FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9FQSxLQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNFQTtBQUFBLGlCQTNHUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZHQSxLQW5IUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFIQTtBQUFBO0FBQUE7QUFBQSxRQTFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEySkE7QUFBQTtBQUFBLElBaktKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtLQTtBQUVSO0FBQUNkLEdBN1BlTiw4QkFBNEI7QUFBQTBELEtBQTVCMUQ7QUFBNEIsSUFBQTBEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInRvYXN0IiwiRGVjaW1hbElucHV0IiwiZmV0Y2hUYXhSZXRlbnRpb25Qcm9maWxlcyIsInVwZGF0ZVRheFJldGVudGlvblByb2ZpbGVzIiwiY2xvbmVQcm9maWxlcyIsInByb2ZpbGVzIiwiSlNPTiIsInBhcnNlIiwic3RyaW5naWZ5IiwiUmV0ZW50aW9uUHJvZmlsZXNFZGl0b3JNb2RhbCIsImlzT3BlbiIsInRheElkIiwiY2FuRWRpdCIsIm9uQ2xvc2UiLCJvblNhdmVkIiwiX3MiLCJ0YXhNZXRhIiwic2V0VGF4TWV0YSIsInNldFByb2ZpbGVzIiwic2VsZWN0ZWRQcm9maWxlSWQiLCJzZXRTZWxlY3RlZFByb2ZpbGVJZCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2F2aW5nIiwic2V0U2F2aW5nIiwibG9hZCIsImRhdGEiLCJ0YXgiLCJjbG9uZWQiLCJpZCIsImUiLCJjb25zb2xlIiwiZXJyb3IiLCJzZWxlY3RlZFByb2ZpbGUiLCJmaW5kIiwicCIsInVwZGF0ZVByb2ZpbGUiLCJwcm9maWxlSWQiLCJ1cGRhdGVyIiwicHJldiIsIm1hcCIsInVwZGF0ZVJhbmdlIiwicmFuZ2VJZCIsInBhdGNoIiwicmFuZ2VzIiwiciIsImhhbmRsZVNhdmUiLCJpc19hY3RpdmUiLCJtaW5fYmFzZSIsIk51bWJlciIsIm1heF9iYXNlIiwiZml4ZWRfYW1vdW50IiwidmFyaWFibGVfcmF0ZSIsImFwcGx5X292ZXJfZXhjZXNzIiwiQm9vbGVhbiIsInN1Y2Nlc3MiLCJzdG9wUHJvcGFnYXRpb24iLCJuYW1lIiwidHlwZV9sYWJlbCIsImxlbmd0aCIsInRhcmdldCIsInZhbHVlIiwiY2FzZV9jb2RlIiwiY2hlY2tlZCIsIm51bSIsImlzRmluaXRlIiwicGN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmV0ZW50aW9uUHJvZmlsZXNFZGl0b3JNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgdHlwZSB7XG4gICAgVGF4UmV0ZW50aW9uUHJvZmlsZSxcbiAgICBUYXhSZXRlbnRpb25SYW5nZSxcbiAgICBUYXhSZXRlbnRpb25UYXhNZXRhLFxufSBmcm9tICcuLi90YXhSZXRlbnRpb25Qcm9maWxlcy50eXBlcyc7XG5pbXBvcnQge1xuICAgIGZldGNoVGF4UmV0ZW50aW9uUHJvZmlsZXMsXG4gICAgdXBkYXRlVGF4UmV0ZW50aW9uUHJvZmlsZXMsXG59IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL3RheFJldGVudGlvblByb2ZpbGVzU2VydmljZSc7XG5cbmZ1bmN0aW9uIGNsb25lUHJvZmlsZXMocHJvZmlsZXM6IFRheFJldGVudGlvblByb2ZpbGVbXSk6IFRheFJldGVudGlvblByb2ZpbGVbXSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocHJvZmlsZXMpKSBhcyBUYXhSZXRlbnRpb25Qcm9maWxlW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmV0ZW50aW9uUHJvZmlsZXNFZGl0b3JNb2RhbFByb3BzIHtcbiAgICBpc09wZW46IGJvb2xlYW47XG4gICAgdGF4SWQ6IG51bWJlcjtcbiAgICBjYW5FZGl0OiBib29sZWFuO1xuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gICAgLyoqIFRyYXMgZ3VhcmRhciBjb24gw6l4aXRvICovXG4gICAgb25TYXZlZD86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsKHtcbiAgICBpc09wZW4sXG4gICAgdGF4SWQsXG4gICAgY2FuRWRpdCxcbiAgICBvbkNsb3NlLFxuICAgIG9uU2F2ZWQsXG59OiBSZXRlbnRpb25Qcm9maWxlc0VkaXRvck1vZGFsUHJvcHMpIHtcbiAgICBjb25zdCBbdGF4TWV0YSwgc2V0VGF4TWV0YV0gPSB1c2VTdGF0ZTxUYXhSZXRlbnRpb25UYXhNZXRhIHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW3Byb2ZpbGVzLCBzZXRQcm9maWxlc10gPSB1c2VTdGF0ZTxUYXhSZXRlbnRpb25Qcm9maWxlW10+KFtdKTtcbiAgICBjb25zdCBbc2VsZWN0ZWRQcm9maWxlSWQsIHNldFNlbGVjdGVkUHJvZmlsZUlkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgbG9hZCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBmZXRjaFRheFJldGVudGlvblByb2ZpbGVzKHRheElkKTtcbiAgICAgICAgICAgIHNldFRheE1ldGEoZGF0YS50YXgpO1xuICAgICAgICAgICAgY29uc3QgY2xvbmVkID0gY2xvbmVQcm9maWxlcyhkYXRhLnByb2ZpbGVzKTtcbiAgICAgICAgICAgIHNldFByb2ZpbGVzKGNsb25lZCk7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFByb2ZpbGVJZChjbG9uZWRbMF0/LmlkID8/IG51bGwpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZGllcm9uIGNhcmdhciBsb3MgcGVyZmlsZXMgZGUgcmV0ZW5jacOzbi4nKTtcbiAgICAgICAgICAgIHNldFByb2ZpbGVzKFtdKTtcbiAgICAgICAgICAgIHNldFRheE1ldGEobnVsbCk7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFByb2ZpbGVJZChudWxsKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW3RheElkXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNPcGVuICYmIHRheElkKSB7XG4gICAgICAgICAgICB2b2lkIGxvYWQoKTtcbiAgICAgICAgfVxuICAgIH0sIFtpc09wZW4sIHRheElkLCBsb2FkXSk7XG5cbiAgICBjb25zdCBzZWxlY3RlZFByb2ZpbGUgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBwcm9maWxlcy5maW5kKHAgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQcm9maWxlSWQpID8/IG51bGwsXG4gICAgICAgIFtwcm9maWxlcywgc2VsZWN0ZWRQcm9maWxlSWRdXG4gICAgKTtcblxuICAgIGNvbnN0IHVwZGF0ZVByb2ZpbGUgPSB1c2VDYWxsYmFjaygocHJvZmlsZUlkOiBudW1iZXIsIHVwZGF0ZXI6IChwOiBUYXhSZXRlbnRpb25Qcm9maWxlKSA9PiBUYXhSZXRlbnRpb25Qcm9maWxlKSA9PiB7XG4gICAgICAgIHNldFByb2ZpbGVzKHByZXYgPT4gcHJldi5tYXAocCA9PiAocC5pZCA9PT0gcHJvZmlsZUlkID8gdXBkYXRlcihwKSA6IHApKSk7XG4gICAgfSwgW10pO1xuXG4gICAgY29uc3QgdXBkYXRlUmFuZ2UgPSB1c2VDYWxsYmFjayhcbiAgICAgICAgKHByb2ZpbGVJZDogbnVtYmVyLCByYW5nZUlkOiBudW1iZXIsIHBhdGNoOiBQYXJ0aWFsPFRheFJldGVudGlvblJhbmdlPikgPT4ge1xuICAgICAgICAgICAgdXBkYXRlUHJvZmlsZShwcm9maWxlSWQsIHAgPT4gKHtcbiAgICAgICAgICAgICAgICAuLi5wLFxuICAgICAgICAgICAgICAgIHJhbmdlczogcC5yYW5nZXMubWFwKHIgPT4gKHIuaWQgPT09IHJhbmdlSWQgPyB7IC4uLnIsIC4uLnBhdGNoIH0gOiByKSksXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH0sXG4gICAgICAgIFt1cGRhdGVQcm9maWxlXVxuICAgICk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWNhbkVkaXQpIHJldHVybjtcbiAgICAgICAgc2V0U2F2aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgdXBkYXRlVGF4UmV0ZW50aW9uUHJvZmlsZXModGF4SWQsIHtcbiAgICAgICAgICAgICAgICBwcm9maWxlczogcHJvZmlsZXMubWFwKHAgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6IHAuaWQsXG4gICAgICAgICAgICAgICAgICAgIGlzX2FjdGl2ZTogcC5pc19hY3RpdmUsXG4gICAgICAgICAgICAgICAgICAgIHJhbmdlczogcC5yYW5nZXMubWFwKHIgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiByLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWluX2Jhc2U6IE51bWJlcihyLm1pbl9iYXNlKSB8fCAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4X2Jhc2U6IHIubWF4X2Jhc2UgPT0gbnVsbCA/IG51bGwgOiBOdW1iZXIoci5tYXhfYmFzZSksXG4gICAgICAgICAgICAgICAgICAgICAgICBmaXhlZF9hbW91bnQ6IE51bWJlcihyLmZpeGVkX2Ftb3VudCkgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhYmxlX3JhdGU6IE51bWJlcihyLnZhcmlhYmxlX3JhdGUpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBseV9vdmVyX2V4Y2VzczogQm9vbGVhbihyLmFwcGx5X292ZXJfZXhjZXNzKSxcbiAgICAgICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnVGFibGEgZGUgcmV0ZW5jacOzbiBndWFyZGFkYS4nKTtcbiAgICAgICAgICAgIG9uU2F2ZWQ/LigpO1xuICAgICAgICAgICAgb25DbG9zZSgpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ3VhcmRhciBsYSB0YWJsYSBkZSByZXRlbmNpw7NuLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzIwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrIGJnLW9wYWNpdHktNTBcIlxuICAgICAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJyZXRlbnRpb24tcHJvZmlsZXMtbW9kYWwtdGl0bGVcIlxuICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cteGwgdy1mdWxsIG1heC13LTV4bCBtYXgtaC1bOTJ2aF0gb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2xcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2UgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGlkPVwicmV0ZW50aW9uLXByb2ZpbGVzLW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGEgZGUgcmV0ZW5jacOzblxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YXhNZXRhICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGF4TWV0YS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGF4TWV0YS50eXBlX2xhYmVsID8gYCDCtyAke3RheE1ldGEudHlwZV9sYWJlbH1gIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgaG92ZXI6YmctZ3JheS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2VycmFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5FZGl0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVNhdmUoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCBsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctaW5kaWdvLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyAnR3VhcmRhbmRv4oCmJyA6ICdHdWFyZGFyJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgb3ZlcmZsb3cteS1hdXRvIGZsZXgtMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+Q2FyZ2FuZG/igKY8L3A+XG4gICAgICAgICAgICAgICAgICAgICkgOiBwcm9maWxlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweS04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPk5vIGhheSBwZXJmaWxlcyBjb25maWd1cmFkb3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJldGVudGlvbi1wcm9maWxlLXNlbGVjdFwiIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlcmZpbCAoY2FzbylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJyZXRlbnRpb24tcHJvZmlsZS1zZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFByb2ZpbGVJZCA/PyAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTZWxlY3RlZFByb2ZpbGVJZChOdW1iZXIoZS50YXJnZXQudmFsdWUpIHx8IG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBzbTp3LTY0IHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9maWxlcy5tYXAocCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cC5jYXNlX2NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQcm9maWxlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkUHJvZmlsZS5pc19hY3RpdmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuRWRpdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gdXBkYXRlUHJvZmlsZShzZWxlY3RlZFByb2ZpbGUuaWQsIHAgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzX2FjdGl2ZTogZS50YXJnZXQuY2hlY2tlZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyLWdyYXktMzAwIHRleHQtaW5kaWdvLTYwMCBmb2N1czpyaW5nLWluZGlnby01MDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjdGl2b1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFByb2ZpbGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgb3ZlcmZsb3cteC1hdXRvIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdCBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TcOtbi4gYmFzZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdCBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TcOheC4gYmFzZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdCBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TW9udG8gZmlqbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtbGVmdCBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VGFzYSB2YXJpYWJsZSAoJSk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlNvYnJlIGV4Y2VkZW50ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwIGJnLXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFByb2ZpbGUucmFuZ2VzLm1hcChyID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3IuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi13LVs2cmVtXSBweC0yIHB5LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyLm1pbl9iYXNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5FZGl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1wdHlXaGVuWmVybz17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IHVwZGF0ZVJhbmdlKHNlbGVjdGVkUHJvZmlsZS5pZCwgci5pZCwgeyBtaW5fYmFzZTogbnVtID8/IDAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bNnJlbV0gcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ci5tYXhfYmFzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuRWRpdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2luIHRvcGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVsbGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdoZW5FbXB0eT17bnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gdXBkYXRlUmFuZ2Uoc2VsZWN0ZWRQcm9maWxlLmlkLCByLmlkLCB7IG1heF9iYXNlOiBudW0gfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bNnJlbV0gcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ci5maXhlZF9hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbkVkaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbXB0eVdoZW5aZXJvPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gdXBkYXRlUmFuZ2Uoc2VsZWN0ZWRQcm9maWxlLmlkLCByLmlkLCB7IGZpeGVkX2Ftb3VudDogbnVtID8/IDAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWNpbWFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bNnJlbV0gcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyLmlzRmluaXRlKHIudmFyaWFibGVfcmF0ZSkgPyByLnZhcmlhYmxlX3JhdGUgKiAxMDAgOiAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5FZGl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1wdHlXaGVuWmVybz17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17cGN0ID0+IHVwZGF0ZVJhbmdlKHNlbGVjdGVkUHJvZmlsZS5pZCwgci5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhYmxlX3JhdGU6IChwY3QgPz8gMCkgLyAxMDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ci5hcHBseV9vdmVyX2V4Y2Vzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuRWRpdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHVwZGF0ZVJhbmdlKHNlbGVjdGVkUHJvZmlsZS5pZCwgci5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBseV9vdmVyX2V4Y2VzczogZS50YXJnZXQuY2hlY2tlZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItZ3JheS0zMDAgdGV4dC1pbmRpZ28tNjAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvaW1wdWVzdG9zL2NvbXBvbmVudHMvUmV0ZW50aW9uUHJvZmlsZXNFZGl0b3JNb2RhbC50c3gifQ==