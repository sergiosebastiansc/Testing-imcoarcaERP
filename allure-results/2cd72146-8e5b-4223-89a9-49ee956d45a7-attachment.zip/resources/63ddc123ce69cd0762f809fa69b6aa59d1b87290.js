import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/AuthorizationModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/AuthorizationModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
export const AuthorizationModal = ({
  isOpen,
  onClose,
  onConfirm,
  message,
  title = "Autorización Requerida"
}) => {
  _s();
  const [password, setPassword] = useState("");
  if (!isOpen) return null;
  const handleSubmit = (e) => {
    e.preventDefault();
    onConfirm(password);
    setPassword("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black bg-opacity-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b bg-yellow-50", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-yellow-800", children: title }, void 0, false, {
      fileName: "/app/src/components/common/AuthorizationModal.tsx",
      lineNumber: 52,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/components/common/AuthorizationModal.tsx",
      lineNumber: 51,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "p-6", autoComplete: "off", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-gray-600", children: message }, void 0, false, {
        fileName: "/app/src/components/common/AuthorizationModal.tsx",
        lineNumber: 56,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Clave de Supervisor" }, void 0, false, {
          fileName: "/app/src/components/common/AuthorizationModal.tsx",
          lineNumber: 59,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "password",
            value: password,
            onChange: (e) => setPassword(e.target.value),
            className: "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500",
            placeholder: "Ingrese la clave...",
            autoComplete: "off",
            autoFocus: true,
            required: true
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/AuthorizationModal.tsx",
            lineNumber: 62,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/AuthorizationModal.tsx",
        lineNumber: 58,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 mt-6", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onClose,
            className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
            children: "Cancelar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/AuthorizationModal.tsx",
            lineNumber: 75,
            columnNumber: 25
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
            children: "Autorizar"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/AuthorizationModal.tsx",
            lineNumber: 82,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/components/common/AuthorizationModal.tsx",
        lineNumber: 74,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/AuthorizationModal.tsx",
      lineNumber: 55,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/AuthorizationModal.tsx",
    lineNumber: 50,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/common/AuthorizationModal.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_s(AuthorizationModal, "Y/4oil5yuJ8nKfSTE84bnqMxt48=");
_c = AuthorizationModal;
var _c;
$RefreshReg$(_c, "AuthorizationModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/AuthorizationModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/AuthorizationModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvQnBCLE9BQU9BLFNBQVNDLGdCQUFnQjtBQVV6QixhQUFNQyxxQkFBd0RBLENBQUM7QUFBQSxFQUNsRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsUUFBUTtBQUNaLE1BQU07QUFBQUMsS0FBQTtBQUNGLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJVCxTQUFTLEVBQUU7QUFFM0MsTUFBSSxDQUFDRSxPQUFRLFFBQU87QUFFcEIsUUFBTVEsZUFBZUEsQ0FBQ0MsTUFBdUI7QUFDekNBLE1BQUVDLGVBQWU7QUFDakJSLGNBQVVJLFFBQVE7QUFDbEJDLGdCQUFZLEVBQUU7QUFBQSxFQUNsQjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHFGQUNYLGlDQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxtQ0FDWCxpQ0FBQyxRQUFHLFdBQVUsdUNBQXVDSCxtQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVUksY0FBYyxXQUFVLE9BQU0sY0FBYSxPQUN2RDtBQUFBLDZCQUFDLE9BQUUsV0FBVSw4QkFBOEJMLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFFbkQsdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsZ0RBQThDLG1DQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxPQUFPRztBQUFBQSxZQUNQLFVBQVUsQ0FBQ0csTUFBTUYsWUFBWUUsRUFBRUUsT0FBT0MsS0FBSztBQUFBLFlBQzNDLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQSxZQUNaLGNBQWE7QUFBQSxZQUNiO0FBQUEsWUFDQSxVQUFRO0FBQUE7QUFBQSxVQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFZO0FBQUEsV0FaaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1g7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU1g7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBbUw7QUFBQTtBQUFBLFVBSGpNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQTJMO0FBQUE7QUFBQSxVQUZ6TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0FqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLE9BdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0EsS0F6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBDQTtBQUVSO0FBQUVJLEdBOURXTixvQkFBcUQ7QUFBQWMsS0FBckRkO0FBQXFELElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiQXV0aG9yaXphdGlvbk1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsIm9uQ29uZmlybSIsIm1lc3NhZ2UiLCJ0aXRsZSIsIl9zIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aG9yaXphdGlvbk1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy9jb21tb24vQXV0aG9yaXphdGlvbk1vZGFsLnRzeFxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgQXV0aG9yaXphdGlvbk1vZGFsUHJvcHMge1xuICAgIGlzT3BlbjogYm9vbGVhbjtcbiAgICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICAgIG9uQ29uZmlybTogKHBhc3N3b3JkOiBzdHJpbmcpID0+IHZvaWQ7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHRpdGxlPzogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgQXV0aG9yaXphdGlvbk1vZGFsOiBSZWFjdC5GQzxBdXRob3JpemF0aW9uTW9kYWxQcm9wcz4gPSAoe1xuICAgIGlzT3BlbixcbiAgICBvbkNsb3NlLFxuICAgIG9uQ29uZmlybSxcbiAgICBtZXNzYWdlLFxuICAgIHRpdGxlID0gJ0F1dG9yaXphY2nDs24gUmVxdWVyaWRhJ1xufSkgPT4ge1xuICAgIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIG9uQ29uZmlybShwYXNzd29yZCk7XG4gICAgICAgIHNldFBhc3N3b3JkKCcnKTsgLy8gTGltcGlhciBwYXJhIGxhIHByw7N4aW1hXG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVsyMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjayBiZy1vcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXhsIHctZnVsbCBtYXgtdy1tZCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBiZy15ZWxsb3ctNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC15ZWxsb3ctODAwXCI+e3RpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJwLTZcIiBhdXRvQ29tcGxldGU9XCJvZmZcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj57bWVzc2FnZX08L3A+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGF2ZSBkZSBTdXBlcnZpc29yXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSW5ncmVzZSBsYSBjbGF2ZS4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBtdC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTUwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIGhvdmVyOmJnLWluZGlnby03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQXV0b3JpemFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvY29tcG9uZW50cy9jb21tb24vQXV0aG9yaXphdGlvbk1vZGFsLnRzeCJ9