import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { comisionesVendedoresConfig } from "/src/features/comisiones_vendedores/comisiones_vendedores.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
export const ComisionesVendedoresListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(comisionesVendedoresConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx",
    lineNumber: 40,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: comisionesVendedoresConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? ""
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx",
      lineNumber: 43,
      columnNumber: 5
    },
    this
  );
};
_s(ComisionesVendedoresListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = ComisionesVendedoresListPage;
var _c;
$RefreshReg$(_c, "ComisionesVendedoresListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxrQ0FBNkQ7QUFDdEUsU0FBU0MsZUFBZTtBQUVqQixhQUFNQywrQkFBK0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QyxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZCxRQUE4QkQsMEJBQTBCO0FBRTVELE1BQUlPLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRUDtBQUFBQSxNQUNSLG9CQUFvQkk7QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhQyxRQUFRO0FBQUE7QUFBQSxJQVpyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZd0M7QUFHaEQ7QUFBRWIsR0FsQ1dELDhCQUE0QjtBQUFBLFVBY2pDRCxPQUFPO0FBQUE7QUFBQWdCLEtBZEZmO0FBQTRCLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZyIsInVzZUNydWQiLCJDb21pc2lvbmVzVmVuZGVkb3Jlc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbWlzaW9uZXNWZW5kZWRvcmVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyBjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZywgdHlwZSBDb21taXNzaW9uTWFyZ2luVGllciB9IGZyb20gJy4uL2NvbWlzaW9uZXNfdmVuZGVkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuXG5leHBvcnQgY29uc3QgQ29taXNpb25lc1ZlbmRlZG9yZXNMaXN0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7XG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgICBsb2FkaW5nLFxuICAgICAgICBpc0FwcGVuZGluZyxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIGRlbGV0ZUl0ZW0sXG4gICAgICAgIGhhbmRsZVNvcnQsXG4gICAgICAgIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbixcbiAgICAgICAgaGFuZGxlUGFnZUNoYW5nZSxcbiAgICAgICAgaGFuZGxlTG9hZE1vcmUsXG4gICAgICAgIGhhbmRsZVNlYXJjaCxcbiAgICAgICAgc2VhcmNoUGFyYW1zLFxuICAgIH0gPSB1c2VDcnVkPENvbW1pc3Npb25NYXJnaW5UaWVyPihjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZyk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPENvbW1pc3Npb25NYXJnaW5UaWVyPlxuICAgICAgICAgICAgY29uZmlnPXtjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZ31cbiAgICAgICAgICAgIHBhZ2luYXRpb25SZXNwb25zZT17cmVzcG9uc2V9XG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgb25EZWxldGU9e2RlbGV0ZUl0ZW19XG4gICAgICAgICAgICBvblNvcnQ9e2hhbmRsZVNvcnR9XG4gICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgIHNvcnREaXJlY3Rpb249e3NvcnREaXJlY3Rpb259XG4gICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgIG9uU2VhcmNoPXtoYW5kbGVTZWFyY2h9XG4gICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hQYXJhbXMudGVybSA/PyAnJ31cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY29taXNpb25lc192ZW5kZWRvcmVzL3BhZ2VzL0NvbWlzaW9uZXNWZW5kZWRvcmVzTGlzdFBhZ2UudHN4In0=