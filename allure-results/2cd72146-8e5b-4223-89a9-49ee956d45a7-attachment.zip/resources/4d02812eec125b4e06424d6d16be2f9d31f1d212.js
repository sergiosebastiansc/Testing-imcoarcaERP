import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { salesOrdersModuleConfig, isSalesOrderEditable } from "/src/features/pedidos_venta/pedidos_venta_config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const PedidosVentaListPage = () => {
  _s();
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(salesOrdersModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEditModule = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(salesOrdersModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx",
    lineNumber: 48,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: salesOrdersModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit: (item) => canEditModule && isSalesOrderEditable(item)
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
};
_s(PedidosVentaListPage, "U7OgbRX0ZCzyZDMmol+qg3l1kKI=", false, function() {
  return [usePermissions, useCrud];
});
_c = PedidosVentaListPage;
var _c;
$RefreshReg$(_c, "PedidosVentaListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHlCQUF5QkMsNEJBQTZDO0FBQy9FLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx1QkFBdUJDLCtCQUErQjtBQUMvRCxTQUFTQywrQkFBK0I7QUFFakMsYUFBTUMsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxFQUFFQyxvQkFBb0IsSUFBSU4sZUFBZTtBQUMvQyxRQUFNTyxtQkFBbUJOLHNCQUFzQkgsd0JBQXdCVSxTQUFTO0FBQ2hGLFFBQU1DLGFBQWFGLG1CQUFtQkwsd0JBQXdCSyxnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxnQkFBZ0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFFN0UsUUFBTTtBQUFBLElBQ0ZFO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSXpCLFFBQW9CQyx5QkFBeUJLLHdCQUF3QixDQUFDO0FBRTFFLE1BQUlXLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRaEI7QUFBQUEsTUFDUixvQkFBb0JhO0FBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBVUk7QUFBQUEsTUFDVixRQUFRQztBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0EsY0FBY0c7QUFBQUEsTUFDZCxZQUFZQztBQUFBQSxNQUNaLFVBQVVDO0FBQUFBLE1BQ1YsWUFBWUMsYUFBYUMsUUFBUTtBQUFBLE1BQ2pDLGlCQUFpQkQsYUFBYUUsYUFBYTtBQUFBLE1BQzNDLGVBQWVGLGFBQWFHLFdBQVc7QUFBQSxNQUN2Qyx1QkFBdUI7QUFBQSxNQUN2QixTQUFTLENBQUNDLFNBQVNoQixpQkFBaUJYLHFCQUFxQjJCLElBQUk7QUFBQTtBQUFBLElBaEJqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQm1FO0FBRzNFO0FBQUVyQixHQTNDV0Qsc0JBQW9CO0FBQUEsVUFDR0osZ0JBa0I1QkgsT0FBTztBQUFBO0FBQUE4QixLQW5CRnZCO0FBQW9CLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsInNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnIiwiaXNTYWxlc09yZGVyRWRpdGFibGUiLCJ1c2VQZXJtaXNzaW9ucyIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJQZWRpZG9zVmVudGFMaXN0UGFnZSIsIl9zIiwiaGFzTW9kdWxlUGVybWlzc2lvbiIsIm1vZHVsZVBlcm1pc3Npb24iLCJiYXNlUm91dGUiLCJtb2R1bGVCYXNlIiwiY2FuRWRpdE1vZHVsZSIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJ0ZXJtIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsIml0ZW0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZWRpZG9zVmVudGFMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2VuZXJpY0xpc3RQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IHVzZUNydWQgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkJztcbmltcG9ydCB7IHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLCBpc1NhbGVzT3JkZXJFZGl0YWJsZSwgdHlwZSBTYWxlc09yZGVyIH0gZnJvbSAnLi4vcGVkaWRvc192ZW50YV9jb25maWcnO1xuaW1wb3J0IHsgdXNlUGVybWlzc2lvbnMgfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VQZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXRSZXF1aXJlZFBlcm1pc3Npb24sIGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0RGF0ZVJhbmdlJztcblxuZXhwb3J0IGNvbnN0IFBlZGlkb3NWZW50YUxpc3RQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaGFzTW9kdWxlUGVybWlzc2lvbiB9ID0gdXNlUGVybWlzc2lvbnMoKTtcbiAgICBjb25zdCBtb2R1bGVQZXJtaXNzaW9uID0gZ2V0UmVxdWlyZWRQZXJtaXNzaW9uKHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSk7XG4gICAgY29uc3QgbW9kdWxlQmFzZSA9IG1vZHVsZVBlcm1pc3Npb24gPyBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbihtb2R1bGVQZXJtaXNzaW9uKSA6IG51bGw7XG4gICAgY29uc3QgY2FuRWRpdE1vZHVsZSA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuXG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxTYWxlc09yZGVyPihzYWxlc09yZGVyc01vZHVsZUNvbmZpZywgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UoKSk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPFNhbGVzT3JkZXI+XG4gICAgICAgICAgICBjb25maWc9e3NhbGVzT3JkZXJzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgICAgICBjYW5FZGl0PXsoaXRlbSkgPT4gY2FuRWRpdE1vZHVsZSAmJiBpc1NhbGVzT3JkZXJFZGl0YWJsZShpdGVtKX1cbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3BlZGlkb3NfdmVudGEvcGFnZXMvUGVkaWRvc1ZlbnRhTGlzdFBhZ2UudHN4In0=