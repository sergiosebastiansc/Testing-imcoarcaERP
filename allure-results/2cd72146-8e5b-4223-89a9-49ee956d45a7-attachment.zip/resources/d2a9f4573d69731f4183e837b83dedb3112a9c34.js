import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useMemo = __vite__cjsImport4_react["useMemo"]; const useCallback = __vite__cjsImport4_react["useCallback"];
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { ordenesPagoModuleConfig, PAYMENT_METHOD_RETENTION_GANANCIAS, parseTaxIdFromVendorRetentionCode, appliedFinancialNoteTypeLabel } from "/src/features/ordenes_pago/ordenes_pago.config.tsx";
import { notasFinancierasCompraModuleConfig } from "/src/features/notas_financieras_compra/notas_financieras_compra.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
function gananciasAppliedTaxRows(taxes) {
  if (!taxes?.length) return [];
  return taxes.filter((t) => {
    const name = (t.tax_name ?? "").toLowerCase();
    const isRet = t.tax_type === 3;
    return isRet && (name.includes("ganancias") || name.includes("ganancia")) || name.includes("ganancias");
  });
}
const SHOW_APPLIED_TAXES_BLOCK = false;
export const OrdenesPagoDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const { item: paymentOrder, loading, error } = useCrudItem(ordenesPagoModuleConfig, id);
  const [isDownloadingRetentionPdf, setIsDownloadingRetentionPdf] = useState(false);
  const [isDownloadingReceiptPdf, setIsDownloadingReceiptPdf] = useState(false);
  const [selectedGananciasTaxId, setSelectedGananciasTaxId] = useState(null);
  const gananciasTaxRows = useMemo(
    () => gananciasAppliedTaxRows(paymentOrder?.applied_taxes),
    [paymentOrder?.applied_taxes]
  );
  useEffect(() => {
    if (gananciasTaxRows.length > 0) {
      const firstId = gananciasTaxRows[0].id;
      setSelectedGananciasTaxId(typeof firstId === "number" ? firstId : null);
    } else {
      setSelectedGananciasTaxId(null);
    }
  }, [gananciasTaxRows]);
  const showRetentionCertificateAction = paymentOrder && !paymentOrder.is_annulled && paymentOrder.items.some((i) => i.payment_method_code === PAYMENT_METHOD_RETENTION_GANANCIAS);
  const handlePrintReceipt = useCallback(async () => {
    if (!paymentOrder?.id || paymentOrder.is_annulled) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsDownloadingReceiptPdf(true);
    try {
      await finishPdfPreview(session, `/payment-orders/${paymentOrder.id}/pdf`);
    } catch (e) {
      if (!session.window.closed) session.window.close();
      console.error(e);
      toast.error("No se pudo generar el recibo en PDF.");
    } finally {
      setIsDownloadingReceiptPdf(false);
    }
  }, [paymentOrder]);
  const handleDownloadGananciasRetentionCertificate = useCallback(async () => {
    if (!paymentOrder) return;
    let path = `/payment-orders/${paymentOrder.id}/ganancias-retention-certificate/pdf`;
    if (gananciasTaxRows.length > 1) {
      if (selectedGananciasTaxId == null) {
        toast.error("Seleccione qué retención Ganancias desea certificar.");
        return;
      }
      path += `?payment_order_tax_id=${selectedGananciasTaxId}`;
    }
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsDownloadingRetentionPdf(true);
    try {
      await finishPdfPreview(session, path);
    } catch (e) {
      if (!session.window.closed) session.window.close();
      console.error(e);
      toast.error("No se pudo generar el certificado de retención Ganancias.");
    } finally {
      setIsDownloadingRetentionPdf(false);
    }
  }, [paymentOrder, gananciasTaxRows, selectedGananciasTaxId]);
  const modulePermission = getRequiredPermission(ordenesPagoModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const totals = useMemo(() => {
    if (!paymentOrder) return { grossAmount: 0, discount: 0, totalTaxes: 0, netAmount: 0 };
    const grossAmount = paymentOrder.gross_amount || 0;
    const discount = paymentOrder.discount || 0;
    const totalTaxes = paymentOrder.applied_taxes?.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0) || 0;
    const netAmount = grossAmount - discount - totalTaxes;
    return { grossAmount, discount, totalTaxes, netAmount };
  }, [paymentOrder]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
    lineNumber: 147,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
    lineNumber: 148,
    columnNumber: 21
  }, this);
  if (!paymentOrder) return /* @__PURE__ */ jsxDEV("div", { children: "No se encontró la orden de pago." }, void 0, false, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
    lineNumber: 149,
    columnNumber: 29
  }, this);
  const mainDetails = [
    {
      label: "Proveedor",
      render: () => paymentOrder.vendor ? /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/proveedores/${paymentOrder.vendor.id}`,
          className: "text-indigo-600 hover:text-indigo-800 hover:underline",
          children: paymentOrder.vendor?.name
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 156,
          columnNumber: 5
        },
        this
      ) : "N/A"
    },
    { label: "Fecha de Pago", value: formatValue(paymentOrder.payment_date, "date") },
    { label: "Nº Orden", value: paymentOrder.payment_order_number },
    { label: "Referencia", value: paymentOrder.reference || "-" }
  ];
  const amountDetails = [
    { label: "Importe Bruto (Facturas)", value: formatValue(totals.grossAmount, "currency") },
    { label: "Descuento", value: formatValue(totals.discount, "currency"), isNegative: true },
    { label: "Impuestos", value: formatValue(totals.totalTaxes, "currency"), isNegative: true },
    { label: "IMPORTE NETO", value: formatValue(totals.netAmount, "currency"), isBold: true }
  ];
  const getPaymentMethodName = (code) => {
    switch (code) {
      case "EFE":
        return "Efectivo";
      case "CHE":
        return "Cheque";
      case "TRA":
        return "Transferencia enviada";
      case "CHR":
        return "Cheque recibido";
      case "SAL":
        return "Saldo anticipado";
      case PAYMENT_METHOD_RETENTION_GANANCIAS:
        return "Retención de Impuestos a la Ganancias";
      case "1":
        return "Efectivo";
      case "2":
        return "Cheque";
      case "3":
        return "Transferencia enviada";
      default: {
        const dynTaxId = parseTaxIdFromVendorRetentionCode(code ?? "");
        if (dynTaxId != null) {
          const taxRow = paymentOrder.applied_taxes?.find((t) => t.tax_id === dynTaxId);
          const nm = taxRow?.tax_name?.trim();
          return nm ? `Retención ${nm}` : `Retención (impuesto ${dynTaxId})`;
        }
        return code || "-";
      }
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: [
          "Orden de Pago #",
          paymentOrder.payment_order_number
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 218,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: `mt-1 text-sm font-semibold ${!paymentOrder.is_annulled ? "text-green-600" : "text-red-600"}`, children: !paymentOrder.is_annulled ? "Activa" : "Anulada" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 217,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 mt-3 sm:mt-0", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(ordenesPagoModuleConfig.baseRoute)), className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: [
          /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 227,
            columnNumber: 25
          }, this),
          " Volver"
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 226,
          columnNumber: 21
        }, this),
        canEdit && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(`${ordenesPagoModuleConfig.baseRoute}/${id}/editar`), className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
          /* @__PURE__ */ jsxDEV(IoPencil, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 231,
            columnNumber: 29
          }, this),
          " Editar"
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 230,
          columnNumber: 11
        }, this),
        !paymentOrder.is_annulled && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => void handlePrintReceipt(),
            disabled: isDownloadingReceiptPdf,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            title: "Abrir orden de pago en PDF",
            children: [
              isDownloadingReceiptPdf ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 -ml-1 animate-spin", "aria-hidden": true }, void 0, false, {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                lineNumber: 243,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5 mr-2 -ml-1", "aria-hidden": true }, void 0, false, {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                lineNumber: 245,
                columnNumber: 13
              }, this),
              "Imprimir orden de pago"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 235,
            columnNumber: 11
          },
          this
        ),
        showRetentionCertificateAction && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          gananciasTaxRows.length > 1 && /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: selectedGananciasTaxId ?? "",
              onChange: (e) => setSelectedGananciasTaxId(Number(e.target.value) || null),
              className: "px-2 py-2 text-sm border border-gray-300 rounded-md shadow-sm bg-white max-w-[14rem]",
              "aria-label": "Retención Ganancias a certificar",
              children: gananciasTaxRows.map(
                (row) => /* @__PURE__ */ jsxDEV("option", { value: row.id ?? "", children: (row.tax_name ?? "Retención") + (row.amount != null ? ` (${formatValue(row.amount, "currency")})` : "") }, row.id ?? row.tax_id, false, {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                  lineNumber: 260,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 253,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => void handleDownloadGananciasRetentionCertificate(),
              disabled: isDownloadingRetentionPdf || gananciasTaxRows.length > 1 && selectedGananciasTaxId == null,
              className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
              title: "Abrir certificado de retención Ganancias (PDF)",
              children: [
                isDownloadingRetentionPdf ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 -ml-1 animate-spin" }, void 0, false, {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                  lineNumber: 274,
                  columnNumber: 15
                }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                  fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                  lineNumber: 276,
                  columnNumber: 15
                }, this),
                "Certificado retención Ganancias"
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 266,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 251,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 225,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 216,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-8 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Detalles Generales" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 288,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-2", children: mainDetails.map(
          (detail) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
            /* @__PURE__ */ jsxDEV("dt", { className: "font-medium text-gray-500", children: [
              detail.label,
              ":"
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 292,
              columnNumber: 33
            }, this),
            "render" in detail ? detail.render ? detail.render() : null : detail.value
          ] }, detail.label, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 291,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 289,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 287,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Resumen de Importes" }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 299,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-2", children: amountDetails.map(
          (detail) => /* @__PURE__ */ jsxDEV("div", { className: `flex justify-between text-sm ${detail.isBold ? "font-bold text-base" : ""}`, children: [
            /* @__PURE__ */ jsxDEV("dt", { className: "text-gray-500", children: [
              detail.label,
              ":"
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 303,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { className: `text-gray-900 ${detail.isNegative ? "text-red-600" : ""}`, children: [
              detail.isNegative && "- ",
              detail.value
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 304,
              columnNumber: 33
            }, this)
          ] }, detail.label, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 302,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 300,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 298,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 286,
      columnNumber: 13
    }, this),
    paymentOrder.applied_purchases && paymentOrder.applied_purchases.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Facturas Aplicadas en el Pago" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 314,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Fecha Factura" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 319,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº de Factura" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 320,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Remito" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 321,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto Aplicado" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 322,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 318,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 317,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: paymentOrder.applied_purchases.map(
          (ap) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: formatValue(ap.purchase.purchase_date, "date") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 328,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm font-medium", children: ap.purchase.document_number }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 329,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: ap.purchase.internal_voucher || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 330,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500 font-semibold", children: formatValue(ap.amount_applied, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 331,
              columnNumber: 41
            }, this)
          ] }, ap.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 327,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 325,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 316,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 315,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 313,
      columnNumber: 7
    }, this),
    paymentOrder.applied_financial_notes && paymentOrder.applied_financial_notes.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Notas Financieras Aplicadas" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 343,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Tipo" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 348,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 349,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Comprobante" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 350,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Remito" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 351,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto Aplicado" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 352,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 347,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 346,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: paymentOrder.applied_financial_notes.map((an) => {
          const note = an.purchase_financial_note;
          const amountApplied = Number(an.amount_applied) || 0;
          const isDebit = amountApplied > 0;
          const typeLabel = amountApplied !== 0 ? appliedFinancialNoteTypeLabel(amountApplied) : null;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: typeLabel ? /* @__PURE__ */ jsxDEV("span", { className: `px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${isDebit ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`, children: typeLabel }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 365,
              columnNumber: 23
            }, this) : "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 363,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm", children: formatValue(note.issue_date, "date") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 370,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm font-medium", children: /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `${notasFinancierasCompraModuleConfig.baseRoute}/${note.id}`,
                className: "text-indigo-600 hover:text-indigo-800 hover:underline",
                children: note.voucher_number
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                lineNumber: 372,
                columnNumber: 49
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 371,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: note.purchase?.internal_voucher || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 379,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500 font-semibold", children: formatValue(an.amount_applied, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 380,
              columnNumber: 45
            }, this)
          ] }, an.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 362,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 355,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 345,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 344,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 342,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Medios de Pago Aplicados" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 392,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Medio de Pago" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 397,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cuenta Contable" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 398,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Banco" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 399,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Nº Cheque" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 400,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Fecha Cheque" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 401,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Referencia" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 402,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Emisor" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 403,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Importe" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 404,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 396,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 395,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: paymentOrder.items.map((item) => {
          const isChr = item.payment_method_code === "CHR";
          const check = isChr ? item.received_check : null;
          const bankName = check ? check.bank_name : item.bank_name;
          const checkNumber = check ? check.check_number : item.check_number;
          const checkDate = check ? check.check_date : item.check_date;
          const referenceNumber = check ? check.reference_number : null;
          const holder = check ? check.check_holder : null;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: getPaymentMethodName(item.payment_method_code) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 418,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: item.chart_account?.name || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 419,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: bankName || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 420,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: checkNumber || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 421,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: checkDate ? formatValue(checkDate, "date") : "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 422,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: referenceNumber || "-" }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 423,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-gray-500", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { children: holder || "-" }, void 0, false, {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                lineNumber: 426,
                columnNumber: 49
              }, this),
              check?.issuer_cuit ? /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: [
                "CUIT: ",
                check.issuer_cuit
              ] }, void 0, true, {
                fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
                lineNumber: 428,
                columnNumber: 25
              }, this) : null
            ] }, void 0, true, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 425,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 424,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right font-medium text-gray-800", children: formatValue(item.value, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 432,
              columnNumber: 41
            }, this)
          ] }, item.id, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 417,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 407,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 394,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 393,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 391,
      columnNumber: 13
    }, this),
    SHOW_APPLIED_TAXES_BLOCK && paymentOrder.applied_taxes && paymentOrder.applied_taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Impuestos Aplicados" }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 444,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Impuesto" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 449,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Tasa (%)" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 450,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Monto" }, void 0, false, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 451,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 448,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 447,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: paymentOrder.applied_taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: tax.tax_name }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 457,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: tax.rate }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 458,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
              lineNumber: 459,
              columnNumber: 41
            }, this)
          ] }, tax.id || index, true, {
            fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
            lineNumber: 456,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
          lineNumber: 454,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 446,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
        lineNumber: 445,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
      lineNumber: 443,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx",
    lineNumber: 214,
    columnNumber: 5
  }, this);
};
_s(OrdenesPagoDetailPage, "ygqV88sNQgWnHhm/Oxc/uxEjaL0=", false, function() {
  return [useParams, useNavigate, usePermissions, useCrudItem];
});
_c = OrdenesPagoDetailPage;
var _c;
$RefreshReg$(_c, "OrdenesPagoDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0h3QixTQXdHQSxVQXhHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvSHhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsVUFBVUMsV0FBV0MsU0FBU0MsbUJBQW1CO0FBQzFELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QkMsb0NBQW9DQyxtQ0FBbUNDLHFDQUF3RDtBQUNqSyxTQUFTQywwQ0FBMEM7QUFDbkQsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLFVBQVVDLGVBQWU7QUFDL0MsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCQywrQkFBK0I7QUFDL0QsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFFbEQsU0FBU0MseUJBQXlCO0FBR2xDLFNBQVNDLHdCQUF3QkMsT0FBK0M7QUFDNUUsTUFBSSxDQUFDQSxPQUFPQyxPQUFRLFFBQU87QUFDM0IsU0FBT0QsTUFBTUUsT0FBTyxDQUFBQyxNQUFLO0FBQ3JCLFVBQU1DLFFBQVFELEVBQUVFLFlBQVksSUFBSUMsWUFBWTtBQUM1QyxVQUFNQyxRQUFRSixFQUFFSyxhQUFhO0FBQzdCLFdBQVFELFVBQVVILEtBQUtLLFNBQVMsV0FBVyxLQUFLTCxLQUFLSyxTQUFTLFVBQVUsTUFBT0wsS0FBS0ssU0FBUyxXQUFXO0FBQUEsRUFDNUcsQ0FBQztBQUNMO0FBR0EsTUFBTUMsMkJBQTJCO0FBRTFCLGFBQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsR0FBRyxJQUFJeEMsVUFBMEI7QUFDekMsUUFBTXlDLFdBQVd4QyxZQUFZO0FBQzdCLFFBQU0sRUFBRXlDLG9CQUFvQixJQUFJdEIsZUFBZTtBQUMvQyxRQUFNLEVBQUV1QixNQUFNQyxjQUFjQyxTQUFTQyxNQUFNLElBQUl0QyxZQUEwQkMseUJBQXlCK0IsRUFBRTtBQUVwRyxRQUFNLENBQUNPLDJCQUEyQkMsNEJBQTRCLElBQUk3QyxTQUFTLEtBQUs7QUFDaEYsUUFBTSxDQUFDOEMseUJBQXlCQywwQkFBMEIsSUFBSS9DLFNBQVMsS0FBSztBQUM1RSxRQUFNLENBQUNnRCx3QkFBd0JDLHlCQUF5QixJQUFJakQsU0FBd0IsSUFBSTtBQUV4RixRQUFNa0QsbUJBQW1CaEQ7QUFBQUEsSUFDckIsTUFBTXFCLHdCQUF3QmtCLGNBQWNVLGFBQWE7QUFBQSxJQUN6RCxDQUFDVixjQUFjVSxhQUFhO0FBQUEsRUFDaEM7QUFFQWxELFlBQVUsTUFBTTtBQUNaLFFBQUlpRCxpQkFBaUJ6QixTQUFTLEdBQUc7QUFDN0IsWUFBTTJCLFVBQVVGLGlCQUFpQixDQUFDLEVBQUViO0FBQ3BDWSxnQ0FBMEIsT0FBT0csWUFBWSxXQUFXQSxVQUFVLElBQUk7QUFBQSxJQUMxRSxPQUFPO0FBQ0hILGdDQUEwQixJQUFJO0FBQUEsSUFDbEM7QUFBQSxFQUNKLEdBQUcsQ0FBQ0MsZ0JBQWdCLENBQUM7QUFFckIsUUFBTUcsaUNBQ0ZaLGdCQUNBLENBQUNBLGFBQWFhLGVBQ2RiLGFBQWFjLE1BQU1DLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsd0JBQXdCbkQsa0NBQWtDO0FBRTdGLFFBQU1vRCxxQkFBcUJ4RCxZQUFZLFlBQVk7QUFDL0MsUUFBSSxDQUFDc0MsY0FBY0osTUFBTUksYUFBYWEsWUFBYTtBQUVuRCxVQUFNTSxVQUFVeEMsZ0JBQWdCO0FBQ2hDLFFBQUksQ0FBQ3dDLFNBQVM7QUFDVnhELFlBQU11QyxNQUFNLDhDQUE4QztBQUMxRDtBQUFBLElBQ0o7QUFFQUksK0JBQTJCLElBQUk7QUFDL0IsUUFBSTtBQUNBLFlBQU0xQixpQkFBaUJ1QyxTQUFTLG1CQUFtQm5CLGFBQWFKLEVBQUUsTUFBTTtBQUFBLElBQzVFLFNBQVN3QixHQUFHO0FBQ1IsVUFBSSxDQUFDRCxRQUFRRSxPQUFPQyxPQUFRSCxTQUFRRSxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFRdEIsTUFBTWtCLENBQUM7QUFDZnpELFlBQU11QyxNQUFNLHNDQUFzQztBQUFBLElBQ3RELFVBQUM7QUFDR0ksaUNBQTJCLEtBQUs7QUFBQSxJQUNwQztBQUFBLEVBQ0osR0FBRyxDQUFDTixZQUFZLENBQUM7QUFFakIsUUFBTXlCLDhDQUE4Qy9ELFlBQVksWUFBWTtBQUN4RSxRQUFJLENBQUNzQyxhQUFjO0FBRW5CLFFBQUkwQixPQUFPLG1CQUFtQjFCLGFBQWFKLEVBQUU7QUFDN0MsUUFBSWEsaUJBQWlCekIsU0FBUyxHQUFHO0FBQzdCLFVBQUl1QiwwQkFBMEIsTUFBTTtBQUNoQzVDLGNBQU11QyxNQUFNLHNEQUFzRDtBQUNsRTtBQUFBLE1BQ0o7QUFDQXdCLGNBQVEseUJBQXlCbkIsc0JBQXNCO0FBQUEsSUFDM0Q7QUFFQSxVQUFNWSxVQUFVeEMsZ0JBQWdCO0FBQ2hDLFFBQUksQ0FBQ3dDLFNBQVM7QUFDVnhELFlBQU11QyxNQUFNLDhDQUE4QztBQUMxRDtBQUFBLElBQ0o7QUFFQUUsaUNBQTZCLElBQUk7QUFDakMsUUFBSTtBQUNBLFlBQU14QixpQkFBaUJ1QyxTQUFTTyxJQUFJO0FBQUEsSUFDeEMsU0FBU04sR0FBRztBQUNSLFVBQUksQ0FBQ0QsUUFBUUUsT0FBT0MsT0FBUUgsU0FBUUUsT0FBT0UsTUFBTTtBQUNqREMsY0FBUXRCLE1BQU1rQixDQUFDO0FBQ2Z6RCxZQUFNdUMsTUFBTSwyREFBMkQ7QUFBQSxJQUMzRSxVQUFDO0FBQ0dFLG1DQUE2QixLQUFLO0FBQUEsSUFDdEM7QUFBQSxFQUNKLEdBQUcsQ0FBQ0osY0FBY1Msa0JBQWtCRixzQkFBc0IsQ0FBQztBQUczRCxRQUFNb0IsbUJBQW1CbEQsc0JBQXNCWix3QkFBd0IrRCxTQUFTO0FBQ2hGLFFBQU1DLGFBQWFGLG1CQUFtQmpELHdCQUF3QmlELGdCQUFnQixJQUFJO0FBQ2xGLFFBQU1HLFVBQVVELGFBQWEvQixvQkFBb0IrQixZQUFZLE1BQU0sSUFBSTtBQUd2RSxRQUFNRSxTQUFTdEUsUUFBUSxNQUFNO0FBQ3pCLFFBQUksQ0FBQ3VDLGFBQWMsUUFBTyxFQUFFZ0MsYUFBYSxHQUFHQyxVQUFVLEdBQUdDLFlBQVksR0FBR0MsV0FBVyxFQUFFO0FBRXJGLFVBQU1ILGNBQWNoQyxhQUFhb0MsZ0JBQWdCO0FBQ2pELFVBQU1ILFdBQVdqQyxhQUFhaUMsWUFBWTtBQUUxQyxVQUFNQyxhQUFhbEMsYUFBYVUsZUFBZTJCLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsT0FBT0UsT0FBT0QsSUFBSUUsTUFBTSxLQUFLLElBQUksQ0FBQyxLQUFLO0FBQzNHLFVBQU1OLFlBQVlILGNBQWNDLFdBQVdDO0FBRTNDLFdBQU8sRUFBRUYsYUFBYUMsVUFBVUMsWUFBWUMsVUFBVTtBQUFBLEVBQzFELEdBQUcsQ0FBQ25DLFlBQVksQ0FBQztBQUVqQixNQUFJQyxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLGFBQWMsUUFBTyx1QkFBQyxTQUFJLGdEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFL0QsUUFBTTBDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLE1BQ0lDLE9BQU87QUFBQSxNQUNQQyxRQUFRQSxNQUNKNUMsYUFBYTZDLFNBQ1Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLElBQUksZ0JBQWdCN0MsYUFBYTZDLE9BQU9qRCxFQUFFO0FBQUEsVUFDMUMsV0FBVTtBQUFBLFVBRVRJLHVCQUFhNkMsUUFBUTFEO0FBQUFBO0FBQUFBLFFBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBLElBRUE7QUFBQSxJQUdaO0FBQUEsSUFDQSxFQUFFd0QsT0FBTyxpQkFBaUJHLE9BQU92RSxZQUFZeUIsYUFBYStDLGNBQWMsTUFBTSxFQUFFO0FBQUEsSUFDaEYsRUFBRUosT0FBTyxZQUFZRyxPQUFPOUMsYUFBYWdELHFCQUFxQjtBQUFBLElBQzlELEVBQUVMLE9BQU8sY0FBY0csT0FBTzlDLGFBQWFpRCxhQUFhLElBQUk7QUFBQSxFQUFDO0FBSWpFLFFBQU1DLGdCQUFnQjtBQUFBLElBQ2xCLEVBQUVQLE9BQU8sNEJBQTRCRyxPQUFPdkUsWUFBWXdELE9BQU9DLGFBQWEsVUFBVSxFQUFFO0FBQUEsSUFDeEYsRUFBRVcsT0FBTyxhQUFhRyxPQUFPdkUsWUFBWXdELE9BQU9FLFVBQVUsVUFBVSxHQUFHa0IsWUFBWSxLQUFLO0FBQUEsSUFDeEYsRUFBRVIsT0FBTyxhQUFhRyxPQUFPdkUsWUFBWXdELE9BQU9HLFlBQVksVUFBVSxHQUFHaUIsWUFBWSxLQUFLO0FBQUEsSUFDMUYsRUFBRVIsT0FBTyxnQkFBZ0JHLE9BQU92RSxZQUFZd0QsT0FBT0ksV0FBVyxVQUFVLEdBQUdpQixRQUFRLEtBQUs7QUFBQSxFQUFDO0FBSTdGLFFBQU1DLHVCQUF1QkEsQ0FBQ0MsU0FBd0I7QUFDbEQsWUFBUUEsTUFBSTtBQUFBLE1BQ1IsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1gsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLeEY7QUFDRCxlQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsZUFBTztBQUFBLE1BQ1gsS0FBSztBQUNELGVBQU87QUFBQSxNQUNYLEtBQUs7QUFDRCxlQUFPO0FBQUEsTUFDWCxTQUFTO0FBQ0wsY0FBTXlGLFdBQVd4RixrQ0FBa0N1RixRQUFRLEVBQUU7QUFDN0QsWUFBSUMsWUFBWSxNQUFNO0FBQ2xCLGdCQUFNQyxTQUFTeEQsYUFBYVUsZUFBZStDLEtBQUssQ0FBQXZFLE1BQUtBLEVBQUV3RSxXQUFXSCxRQUFRO0FBQzFFLGdCQUFNSSxLQUFLSCxRQUFRcEUsVUFBVXdFLEtBQUs7QUFDbEMsaUJBQU9ELEtBQUssYUFBYUEsRUFBRSxLQUFLLHVCQUF1QkosUUFBUTtBQUFBLFFBQ25FO0FBQ0EsZUFBT0QsUUFBUTtBQUFBLE1BQ25CO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFFWDtBQUFBLDJCQUFDLFNBQUksV0FBVSw0REFDWDtBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUNBQXFDO0FBQUE7QUFBQSxVQUMvQnRELGFBQWFnRDtBQUFBQSxhQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVyw4QkFBOEIsQ0FBQ2hELGFBQWFhLGNBQWMsbUJBQW1CLGNBQWMsSUFDcEcsV0FBQ2IsYUFBYWEsY0FBYyxXQUFXLGFBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ1g7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1oQixTQUFTaEIsa0JBQWtCaEIsd0JBQXdCK0QsU0FBUyxDQUFDLEdBQUcsV0FBVSw4SUFDM0c7QUFBQSxpQ0FBQyxlQUFZLFdBQVUsd0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFBRztBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0NFLFdBQ0csdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNakMsU0FBUyxHQUFHaEMsd0JBQXdCK0QsU0FBUyxJQUFJaEMsRUFBRSxTQUFTLEdBQUcsV0FBVSxzSkFDMUc7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsVUFBRztBQUFBLGFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUgsQ0FBQ0ksYUFBYWEsZUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNLEtBQUtLLG1CQUFtQjtBQUFBLFlBQ3ZDLFVBQVViO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBQ1YsT0FBTTtBQUFBLFlBRUxBO0FBQUFBLHdDQUNHLHVCQUFDLGFBQVUsV0FBVSxtQ0FBa0MsZUFBVyxRQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRSxJQUVsRSx1QkFBQyxXQUFRLFdBQVUsc0JBQXFCLGVBQVcsUUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxjQUN0RDtBQUFBO0FBQUE7QUFBQSxVQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWFBO0FBQUEsUUFFSE8sa0NBQ0csbUNBQ0tIO0FBQUFBLDJCQUFpQnpCLFNBQVMsS0FDdkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU91QiwwQkFBMEI7QUFBQSxjQUNqQyxVQUFVLENBQUFhLE1BQUtaLDBCQUEwQmdDLE9BQU9wQixFQUFFeUMsT0FBT2YsS0FBSyxLQUFLLElBQUk7QUFBQSxjQUN2RSxXQUFVO0FBQUEsY0FDVixjQUFXO0FBQUEsY0FFVnJDLDJCQUFpQnFEO0FBQUFBLGdCQUFJLENBQUFDLFFBQ2xCLHVCQUFDLFlBQWtDLE9BQU9BLElBQUluRSxNQUFNLElBQzlDbUUsZUFBSTNFLFlBQVksZ0JBQWdCMkUsSUFBSXRCLFVBQVUsT0FBTyxLQUFLbEUsWUFBWXdGLElBQUl0QixRQUFRLFVBQVUsQ0FBQyxNQUFNLE9BRDVGc0IsSUFBSW5FLE1BQU1tRSxJQUFJTCxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDSDtBQUFBO0FBQUEsWUFWTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBRUo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTSxLQUFLakMsNENBQTRDO0FBQUEsY0FDaEUsVUFBVXRCLDZCQUE4Qk0saUJBQWlCekIsU0FBUyxLQUFLdUIsMEJBQTBCO0FBQUEsY0FDakcsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRUxKO0FBQUFBLDRDQUNHLHVCQUFDLGFBQVUsV0FBVSxxQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0QsSUFFdEQsdUJBQUMsV0FBUSxXQUFVLHdCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLGdCQUMxQztBQUFBO0FBQUE7QUFBQSxZQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsYUE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQTtBQUFBLFdBdkRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5REE7QUFBQSxTQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyxrQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFLHVCQUFDLFFBQUcsV0FBVSxrQkFDVHVDLHNCQUFZb0I7QUFBQUEsVUFBSSxDQUFBRSxXQUNiLHVCQUFDLFNBQXVCLFdBQVUsZ0NBQzlCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDZCQUE2QkE7QUFBQUEscUJBQU9yQjtBQUFBQSxjQUFNO0FBQUEsaUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDeEQsWUFBWXFCLFNBQVVBLE9BQU9wQixTQUFTb0IsT0FBT3BCLE9BQU8sSUFBSSxPQUFRb0IsT0FBT2xCO0FBQUFBLGVBRmxFa0IsT0FBT3JCLE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxRQUNILEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLG1DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsUUFDckUsdUJBQUMsUUFBRyxXQUFVLGtCQUNUTyx3QkFBY1k7QUFBQUEsVUFBSSxDQUFBRSxXQUNmLHVCQUFDLFNBQXVCLFdBQVcsZ0NBQWdDQSxPQUFPWixTQUFTLHdCQUF3QixFQUFFLElBQ3pHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlCQUFpQlk7QUFBQUEscUJBQU9yQjtBQUFBQSxjQUFNO0FBQUEsaUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDN0MsdUJBQUMsUUFBRyxXQUFXLGlCQUFpQnFCLE9BQU9iLGFBQWEsaUJBQWlCLEVBQUUsSUFBS2E7QUFBQUEscUJBQU9iLGNBQWM7QUFBQSxjQUFNYSxPQUFPbEI7QUFBQUEsaUJBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9IO0FBQUEsZUFGOUdrQixPQUFPckIsT0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0gsS0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdDM0MsYUFBYWlFLHFCQUFxQmpFLGFBQWFpRSxrQkFBa0JqRixTQUFTLEtBQ3ZFLHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLDZDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsTUFDL0UsdUJBQUMsU0FBSSxXQUFVLHlFQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEVBQXlFLDZCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLFVBQ3BHLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsNkJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCxzQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELDhCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBSjdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaZ0IsdUJBQWFpRSxrQkFBa0JIO0FBQUFBLFVBQUksQ0FBQUksT0FDaEMsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxrQ0FBa0MzRixzQkFBWTJGLEdBQUdDLFNBQVNDLGVBQWUsTUFBTSxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRjtBQUFBLFlBQy9GLHVCQUFDLFFBQUcsV0FBVSxpQ0FBaUNGLGFBQUdDLFNBQVNFLG1CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNILGFBQUdDLFNBQVNHLG9CQUFvQixPQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLFlBQ3JGLHVCQUFDLFFBQUcsV0FBVSw0REFBNEQvRixzQkFBWTJGLEdBQUdLLGdCQUFnQixVQUFVLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFIO0FBQUEsZUFKaEhMLEdBQUd0RSxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxRQUNILEtBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsU0F2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLElBSUhJLGFBQWF3RSwyQkFBMkJ4RSxhQUFhd0Usd0JBQXdCeEYsU0FBUyxLQUNuRix1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQywyQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RTtBQUFBLE1BQzdFLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSxvQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsOEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCxzQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELDhCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBTDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaZ0IsdUJBQWF3RSx3QkFBd0JWLElBQUksQ0FBQVcsT0FBTTtBQUM1QyxnQkFBTUMsT0FBT0QsR0FBR0U7QUFDaEIsZ0JBQU1DLGdCQUFnQnBDLE9BQU9pQyxHQUFHRixjQUFjLEtBQUs7QUFDbkQsZ0JBQU1NLFVBQVVELGdCQUFnQjtBQUNoQyxnQkFBTUUsWUFBWUYsa0JBQWtCLElBQUk1Ryw4QkFBOEI0RyxhQUFhLElBQUk7QUFDdkYsaUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxrQ0FDVEUsc0JBQ0csdUJBQUMsVUFBSyxXQUFXLGlFQUFpRUQsVUFBVSw0QkFBNEIsNkJBQTZCLElBQ2hKQyx1QkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLElBQ0EsT0FMUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUscUJBQXFCdkcsc0JBQVltRyxLQUFLSyxZQUFZLE1BQU0sS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RSx1QkFBQyxRQUFHLFdBQVUsaUNBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxJQUFJLEdBQUc5RyxtQ0FBbUMyRCxTQUFTLElBQUk4QyxLQUFLOUUsRUFBRTtBQUFBLGdCQUM5RCxXQUFVO0FBQUEsZ0JBRVQ4RSxlQUFLTTtBQUFBQTtBQUFBQSxjQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ04sZUFBS1AsVUFBVUcsb0JBQW9CLE9BQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsUUFBRyxXQUFVLDREQUE0RC9GLHNCQUFZa0csR0FBR0YsZ0JBQWdCLFVBQVUsS0FBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUg7QUFBQSxlQWxCaEhFLEdBQUc3RSxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsUUFFUixDQUFDLEtBNUJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxXQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBLEtBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxTQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkNBO0FBQUEsSUFJSix1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyx3Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLE1BQzFFLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSw2QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxVQUNwRyx1QkFBQyxRQUFHLFdBQVUsNkRBQTRELCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCx5QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxRQUFHLFdBQVUsNkRBQTRELDRCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsMEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCxzQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHVCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLGFBUnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQSxLQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaSSx1QkFBYWMsTUFBTWdELElBQUksQ0FBQS9ELFNBQVE7QUFDNUIsZ0JBQU1rRixRQUFRbEYsS0FBS2tCLHdCQUF3QjtBQUMzQyxnQkFBTWlFLFFBQVFELFFBQVFsRixLQUFLb0YsaUJBQWlCO0FBQzVDLGdCQUFNQyxXQUFXRixRQUFRQSxNQUFNRyxZQUFZdEYsS0FBS3NGO0FBQ2hELGdCQUFNQyxjQUFjSixRQUFRQSxNQUFNSyxlQUFleEYsS0FBS3dGO0FBQ3RELGdCQUFNQyxZQUFZTixRQUFRQSxNQUFNTyxhQUFhMUYsS0FBSzBGO0FBQ2xELGdCQUFNQyxrQkFBa0JSLFFBQVFBLE1BQU1TLG1CQUFtQjtBQUN6RCxnQkFBTUMsU0FBU1YsUUFBUUEsTUFBTVcsZUFBZTtBQUM1QyxpQkFDSSx1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhDQUE4Q3hDLCtCQUFxQnRELEtBQUtrQixtQkFBbUIsS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkc7QUFBQSxZQUMzRyx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DbEIsZUFBSytGLGVBQWUzRyxRQUFRLE9BQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakYsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ2lHLHNCQUFZLE9BQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFO0FBQUEsWUFDakUsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ0UseUJBQWUsT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxRQUFHLFdBQVUsbUNBQW1DRSxzQkFBWWpILFlBQVlpSCxXQUFXLE1BQU0sSUFBSSxPQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2xHLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNFLDZCQUFtQixPQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFLHVCQUFDLFFBQUcsV0FBVSxtQ0FDVixpQ0FBQyxTQUNHO0FBQUEscUNBQUMsU0FBS0Usb0JBQVUsT0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0I7QUFBQSxjQUNuQlYsT0FBT2EsY0FDSix1QkFBQyxTQUFJLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxnQkFBT2IsTUFBTWE7QUFBQUEsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFLElBQ2hFO0FBQUEsaUJBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSwwREFBMER4SCxzQkFBWXdCLEtBQUsrQyxPQUFPLFVBQVUsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEc7QUFBQSxlQWZ2Ry9DLEtBQUtILElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxRQUVSLENBQUMsS0E1Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQTtBQUFBLFdBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0EsS0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLFNBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREE7QUFBQSxJQUdDSCw0QkFBNEJPLGFBQWFVLGlCQUFpQlYsYUFBYVUsY0FBYzFCLFNBQVMsS0FDM0YsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNyRSx1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLGFBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaZ0IsdUJBQWFVLGNBQWNvRDtBQUFBQSxVQUFJLENBQUN2QixLQUFLeUQsVUFDbEMsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FBOEN6RCxjQUFJbkQsWUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxRQUFHLFdBQVUsOENBQThDbUQsY0FBSTBELFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzFILHNCQUFZZ0UsSUFBSUUsUUFBUSxVQUFVLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsZUFIM0ZGLElBQUkzQyxNQUFNb0csT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFFBQ0gsS0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsT0EzUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZQQTtBQUVSO0FBQUVyRyxHQXBhV0QsdUJBQXFCO0FBQUEsVUFDZnRDLFdBQ0VDLGFBQ2VtQixnQkFDZVosV0FBVztBQUFBO0FBQUFzSSxLQUpqRHhHO0FBQXFCLElBQUF3RztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlQ2FsbGJhY2siLCJ0b2FzdCIsInVzZUNydWRJdGVtIiwib3JkZW5lc1BhZ29Nb2R1bGVDb25maWciLCJQQVlNRU5UX01FVEhPRF9SRVRFTlRJT05fR0FOQU5DSUFTIiwicGFyc2VUYXhJZEZyb21WZW5kb3JSZXRlbnRpb25Db2RlIiwiYXBwbGllZEZpbmFuY2lhbE5vdGVUeXBlTGFiZWwiLCJub3Rhc0ZpbmFuY2llcmFzQ29tcHJhTW9kdWxlQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJJb0Fycm93QmFjayIsIklvUGVuY2lsIiwiSW9QcmludCIsIkZhU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwidXNlUGVybWlzc2lvbnMiLCJnZXRSZXF1aXJlZFBlcm1pc3Npb24iLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImJlZ2luUGRmUHJldmlldyIsImZpbmlzaFBkZlByZXZpZXciLCJnZXRMaXN0UmV0dXJuUGF0aCIsImdhbmFuY2lhc0FwcGxpZWRUYXhSb3dzIiwidGF4ZXMiLCJsZW5ndGgiLCJmaWx0ZXIiLCJ0IiwibmFtZSIsInRheF9uYW1lIiwidG9Mb3dlckNhc2UiLCJpc1JldCIsInRheF90eXBlIiwiaW5jbHVkZXMiLCJTSE9XX0FQUExJRURfVEFYRVNfQkxPQ0siLCJPcmRlbmVzUGFnb0RldGFpbFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwiaXRlbSIsInBheW1lbnRPcmRlciIsImxvYWRpbmciLCJlcnJvciIsImlzRG93bmxvYWRpbmdSZXRlbnRpb25QZGYiLCJzZXRJc0Rvd25sb2FkaW5nUmV0ZW50aW9uUGRmIiwiaXNEb3dubG9hZGluZ1JlY2VpcHRQZGYiLCJzZXRJc0Rvd25sb2FkaW5nUmVjZWlwdFBkZiIsInNlbGVjdGVkR2FuYW5jaWFzVGF4SWQiLCJzZXRTZWxlY3RlZEdhbmFuY2lhc1RheElkIiwiZ2FuYW5jaWFzVGF4Um93cyIsImFwcGxpZWRfdGF4ZXMiLCJmaXJzdElkIiwic2hvd1JldGVudGlvbkNlcnRpZmljYXRlQWN0aW9uIiwiaXNfYW5udWxsZWQiLCJpdGVtcyIsInNvbWUiLCJpIiwicGF5bWVudF9tZXRob2RfY29kZSIsImhhbmRsZVByaW50UmVjZWlwdCIsInNlc3Npb24iLCJlIiwid2luZG93IiwiY2xvc2VkIiwiY2xvc2UiLCJjb25zb2xlIiwiaGFuZGxlRG93bmxvYWRHYW5hbmNpYXNSZXRlbnRpb25DZXJ0aWZpY2F0ZSIsInBhdGgiLCJtb2R1bGVQZXJtaXNzaW9uIiwiYmFzZVJvdXRlIiwibW9kdWxlQmFzZSIsImNhbkVkaXQiLCJ0b3RhbHMiLCJncm9zc0Ftb3VudCIsImRpc2NvdW50IiwidG90YWxUYXhlcyIsIm5ldEFtb3VudCIsImdyb3NzX2Ftb3VudCIsInJlZHVjZSIsInN1bSIsInRheCIsIk51bWJlciIsImFtb3VudCIsIm1haW5EZXRhaWxzIiwibGFiZWwiLCJyZW5kZXIiLCJ2ZW5kb3IiLCJ2YWx1ZSIsInBheW1lbnRfZGF0ZSIsInBheW1lbnRfb3JkZXJfbnVtYmVyIiwicmVmZXJlbmNlIiwiYW1vdW50RGV0YWlscyIsImlzTmVnYXRpdmUiLCJpc0JvbGQiLCJnZXRQYXltZW50TWV0aG9kTmFtZSIsImNvZGUiLCJkeW5UYXhJZCIsInRheFJvdyIsImZpbmQiLCJ0YXhfaWQiLCJubSIsInRyaW0iLCJ0YXJnZXQiLCJtYXAiLCJyb3ciLCJkZXRhaWwiLCJhcHBsaWVkX3B1cmNoYXNlcyIsImFwIiwicHVyY2hhc2UiLCJwdXJjaGFzZV9kYXRlIiwiZG9jdW1lbnRfbnVtYmVyIiwiaW50ZXJuYWxfdm91Y2hlciIsImFtb3VudF9hcHBsaWVkIiwiYXBwbGllZF9maW5hbmNpYWxfbm90ZXMiLCJhbiIsIm5vdGUiLCJwdXJjaGFzZV9maW5hbmNpYWxfbm90ZSIsImFtb3VudEFwcGxpZWQiLCJpc0RlYml0IiwidHlwZUxhYmVsIiwiaXNzdWVfZGF0ZSIsInZvdWNoZXJfbnVtYmVyIiwiaXNDaHIiLCJjaGVjayIsInJlY2VpdmVkX2NoZWNrIiwiYmFua05hbWUiLCJiYW5rX25hbWUiLCJjaGVja051bWJlciIsImNoZWNrX251bWJlciIsImNoZWNrRGF0ZSIsImNoZWNrX2RhdGUiLCJyZWZlcmVuY2VOdW1iZXIiLCJyZWZlcmVuY2VfbnVtYmVyIiwiaG9sZGVyIiwiY2hlY2tfaG9sZGVyIiwiY2hhcnRfYWNjb3VudCIsImlzc3Vlcl9jdWl0IiwiaW5kZXgiLCJyYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3JkZW5lc1BhZ29EZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBvcmRlbmVzUGFnb01vZHVsZUNvbmZpZywgUEFZTUVOVF9NRVRIT0RfUkVURU5USU9OX0dBTkFOQ0lBUywgcGFyc2VUYXhJZEZyb21WZW5kb3JSZXRlbnRpb25Db2RlLCBhcHBsaWVkRmluYW5jaWFsTm90ZVR5cGVMYWJlbCwgdHlwZSBQYXltZW50T3JkZXIgfSBmcm9tICcuLi9vcmRlbmVzX3BhZ28uY29uZmlnJztcbmltcG9ydCB7IG5vdGFzRmluYW5jaWVyYXNDb21wcmFNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9ub3Rhc19maW5hbmNpZXJhc19jb21wcmEvbm90YXNfZmluYW5jaWVyYXNfY29tcHJhLmNvbmZpZyc7XG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2ssIElvUGVuY2lsLCBJb1ByaW50IH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IEZhU3Bpbm5lciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBiZWdpblBkZlByZXZpZXcsIGZpbmlzaFBkZlByZXZpZXcgfSBmcm9tICcuLi8uLi8uLi91dGlscy9ibG9iSGVscGVyJztcbmltcG9ydCB0eXBlIHsgQXBwbGllZFRheCB9IGZyb20gJy4uLy4uLy4uL3R5cGVzL2FwcGxpZWRUYXhlcyc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLyoqIEZpbGFzIGRlIGBhcHBsaWVkX3RheGVzYCBhc29jaWFkYXMgYSByZXRlbmNpw7NuIEdhbmFuY2lhcyAocGFyYSBxdWVyeSBgcGF5bWVudF9vcmRlcl90YXhfaWRgIHNpIGhheSB2YXJpYXMpLiAqL1xuZnVuY3Rpb24gZ2FuYW5jaWFzQXBwbGllZFRheFJvd3ModGF4ZXM6IEFwcGxpZWRUYXhbXSB8IHVuZGVmaW5lZCk6IEFwcGxpZWRUYXhbXSB7XG4gICAgaWYgKCF0YXhlcz8ubGVuZ3RoKSByZXR1cm4gW107XG4gICAgcmV0dXJuIHRheGVzLmZpbHRlcih0ID0+IHtcbiAgICAgICAgY29uc3QgbmFtZSA9ICh0LnRheF9uYW1lID8/ICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBjb25zdCBpc1JldCA9IHQudGF4X3R5cGUgPT09IDM7XG4gICAgICAgIHJldHVybiAoaXNSZXQgJiYgKG5hbWUuaW5jbHVkZXMoJ2dhbmFuY2lhcycpIHx8IG5hbWUuaW5jbHVkZXMoJ2dhbmFuY2lhJykpKSB8fCBuYW1lLmluY2x1ZGVzKCdnYW5hbmNpYXMnKTtcbiAgICB9KTtcbn1cblxuLyoqIE9jdWx0byB0ZW1wb3JhbG1lbnRlOiBzZWNjacOzbiBcIkltcHVlc3RvcyBBcGxpY2Fkb3NcIiBlbiBlbCBkZXRhbGxlLiBQb25lciBlbiBgdHJ1ZWAgcGFyYSB2b2x2ZXIgYSBtb3N0cmFyLiAqL1xuY29uc3QgU0hPV19BUFBMSUVEX1RBWEVTX0JMT0NLID0gZmFsc2U7XG5cbmV4cG9ydCBjb25zdCBPcmRlbmVzUGFnb0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGhhc01vZHVsZVBlcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gICAgY29uc3QgeyBpdGVtOiBwYXltZW50T3JkZXIsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxQYXltZW50T3JkZXI+KG9yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBjb25zdCBbaXNEb3dubG9hZGluZ1JldGVudGlvblBkZiwgc2V0SXNEb3dubG9hZGluZ1JldGVudGlvblBkZl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzRG93bmxvYWRpbmdSZWNlaXB0UGRmLCBzZXRJc0Rvd25sb2FkaW5nUmVjZWlwdFBkZl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW3NlbGVjdGVkR2FuYW5jaWFzVGF4SWQsIHNldFNlbGVjdGVkR2FuYW5jaWFzVGF4SWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBnYW5hbmNpYXNUYXhSb3dzID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gZ2FuYW5jaWFzQXBwbGllZFRheFJvd3MocGF5bWVudE9yZGVyPy5hcHBsaWVkX3RheGVzKSxcbiAgICAgICAgW3BheW1lbnRPcmRlcj8uYXBwbGllZF90YXhlc11cbiAgICApO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGdhbmFuY2lhc1RheFJvd3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgZmlyc3RJZCA9IGdhbmFuY2lhc1RheFJvd3NbMF0uaWQ7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZEdhbmFuY2lhc1RheElkKHR5cGVvZiBmaXJzdElkID09PSAnbnVtYmVyJyA/IGZpcnN0SWQgOiBudWxsKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkR2FuYW5jaWFzVGF4SWQobnVsbCk7XG4gICAgICAgIH1cbiAgICB9LCBbZ2FuYW5jaWFzVGF4Um93c10pO1xuXG4gICAgY29uc3Qgc2hvd1JldGVudGlvbkNlcnRpZmljYXRlQWN0aW9uID1cbiAgICAgICAgcGF5bWVudE9yZGVyICYmXG4gICAgICAgICFwYXltZW50T3JkZXIuaXNfYW5udWxsZWQgJiZcbiAgICAgICAgcGF5bWVudE9yZGVyLml0ZW1zLnNvbWUoaSA9PiBpLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09IFBBWU1FTlRfTUVUSE9EX1JFVEVOVElPTl9HQU5BTkNJQVMpO1xuXG4gICAgY29uc3QgaGFuZGxlUHJpbnRSZWNlaXB0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXBheW1lbnRPcmRlcj8uaWQgfHwgcGF5bWVudE9yZGVyLmlzX2FubnVsbGVkKSByZXR1cm47XG5cbiAgICAgICAgY29uc3Qgc2Vzc2lvbiA9IGJlZ2luUGRmUHJldmlldygpO1xuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdQZXJtaXTDrSB2ZW50YW5hcyBlbWVyZ2VudGVzIHBhcmEgdmVyIGVsIFBERi4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldElzRG93bmxvYWRpbmdSZWNlaXB0UGRmKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZmluaXNoUGRmUHJldmlldyhzZXNzaW9uLCBgL3BheW1lbnQtb3JkZXJzLyR7cGF5bWVudE9yZGVyLmlkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKCFzZXNzaW9uLndpbmRvdy5jbG9zZWQpIHNlc3Npb24ud2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCByZWNpYm8gZW4gUERGLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNEb3dubG9hZGluZ1JlY2VpcHRQZGYoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW3BheW1lbnRPcmRlcl0pO1xuXG4gICAgY29uc3QgaGFuZGxlRG93bmxvYWRHYW5hbmNpYXNSZXRlbnRpb25DZXJ0aWZpY2F0ZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFwYXltZW50T3JkZXIpIHJldHVybjtcblxuICAgICAgICBsZXQgcGF0aCA9IGAvcGF5bWVudC1vcmRlcnMvJHtwYXltZW50T3JkZXIuaWR9L2dhbmFuY2lhcy1yZXRlbnRpb24tY2VydGlmaWNhdGUvcGRmYDtcbiAgICAgICAgaWYgKGdhbmFuY2lhc1RheFJvd3MubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgaWYgKHNlbGVjdGVkR2FuYW5jaWFzVGF4SWQgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdTZWxlY2Npb25lIHF1w6kgcmV0ZW5jacOzbiBHYW5hbmNpYXMgZGVzZWEgY2VydGlmaWNhci4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwYXRoICs9IGA/cGF5bWVudF9vcmRlcl90YXhfaWQ9JHtzZWxlY3RlZEdhbmFuY2lhc1RheElkfWA7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzZXNzaW9uID0gYmVnaW5QZGZQcmV2aWV3KCk7XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1Blcm1pdMOtIHZlbnRhbmFzIGVtZXJnZW50ZXMgcGFyYSB2ZXIgZWwgUERGLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNEb3dubG9hZGluZ1JldGVudGlvblBkZih0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgcGF0aCk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRvIGdlbmVyYXIgZWwgY2VydGlmaWNhZG8gZGUgcmV0ZW5jacOzbiBHYW5hbmNpYXMuJyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc0Rvd25sb2FkaW5nUmV0ZW50aW9uUGRmKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH0sIFtwYXltZW50T3JkZXIsIGdhbmFuY2lhc1RheFJvd3MsIHNlbGVjdGVkR2FuYW5jaWFzVGF4SWRdKTtcblxuICAgIC8vIOKchSBWYWxpZGFyIHBlcm1pc29zIHBhcmEgZWRpdGFyXG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihvcmRlbmVzUGFnb01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkVkaXQgPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnZWRpdCcpIDogdHJ1ZTtcblxuICAgIC8vIOKchSBDT1JSRUNDScOTTjogU2UgY2FsY3VsYW4gbG9zIHRvdGFsZXMgYSBwYXJ0aXIgZGUgbG9zIGRhdG9zIHJlYWxlcyBwYXJhIGNvbnNpc3RlbmNpYS5cbiAgICBjb25zdCB0b3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFwYXltZW50T3JkZXIpIHJldHVybiB7IGdyb3NzQW1vdW50OiAwLCBkaXNjb3VudDogMCwgdG90YWxUYXhlczogMCwgbmV0QW1vdW50OiAwIH07XG5cbiAgICAgICAgY29uc3QgZ3Jvc3NBbW91bnQgPSBwYXltZW50T3JkZXIuZ3Jvc3NfYW1vdW50IHx8IDA7XG4gICAgICAgIGNvbnN0IGRpc2NvdW50ID0gcGF5bWVudE9yZGVyLmRpc2NvdW50IHx8IDA7XG4gICAgICAgIC8vIFNlIHN1bWEgZWwgJ2Ftb3VudCcgZGUgY2FkYSBpbXB1ZXN0byBhcGxpY2Fkby5cbiAgICAgICAgY29uc3QgdG90YWxUYXhlcyA9IHBheW1lbnRPcmRlci5hcHBsaWVkX3RheGVzPy5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyAoTnVtYmVyKHRheC5hbW91bnQpIHx8IDApLCAwKSB8fCAwO1xuICAgICAgICBjb25zdCBuZXRBbW91bnQgPSBncm9zc0Ftb3VudCAtIGRpc2NvdW50IC0gdG90YWxUYXhlcztcblxuICAgICAgICByZXR1cm4geyBncm9zc0Ftb3VudCwgZGlzY291bnQsIHRvdGFsVGF4ZXMsIG5ldEFtb3VudCB9O1xuICAgIH0sIFtwYXltZW50T3JkZXJdKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIXBheW1lbnRPcmRlcikgcmV0dXJuIDxkaXY+Tm8gc2UgZW5jb250csOzIGxhIG9yZGVuIGRlIHBhZ28uPC9kaXY+O1xuXG4gICAgY29uc3QgbWFpbkRldGFpbHMgPSBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxhYmVsOiAnUHJvdmVlZG9yJyxcbiAgICAgICAgICAgIHJlbmRlcjogKCkgPT4gKFxuICAgICAgICAgICAgICAgIHBheW1lbnRPcmRlci52ZW5kb3IgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9wcm92ZWVkb3Jlcy8ke3BheW1lbnRPcmRlci52ZW5kb3IuaWR9YH0gLy8gQXN1bW8gcnV0YSAvcHJvdmVlZG9yZXMvOmlkXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50T3JkZXIudmVuZG9yPy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgJ04vQSdcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgIH0sXG4gICAgICAgIHsgbGFiZWw6ICdGZWNoYSBkZSBQYWdvJywgdmFsdWU6IGZvcm1hdFZhbHVlKHBheW1lbnRPcmRlci5wYXltZW50X2RhdGUsICdkYXRlJykgfSxcbiAgICAgICAgeyBsYWJlbDogJ07CuiBPcmRlbicsIHZhbHVlOiBwYXltZW50T3JkZXIucGF5bWVudF9vcmRlcl9udW1iZXIgfSxcbiAgICAgICAgeyBsYWJlbDogJ1JlZmVyZW5jaWEnLCB2YWx1ZTogcGF5bWVudE9yZGVyLnJlZmVyZW5jZSB8fCAnLScgfSxcbiAgICBdO1xuXG4gICAgLy8g4pyFIENPUlJFQ0NJw5NOOiBTZSB1c2EgZWwgJ3RvdGFsVGF4ZXMnIGNhbGN1bGFkby5cbiAgICBjb25zdCBhbW91bnREZXRhaWxzID0gW1xuICAgICAgICB7IGxhYmVsOiAnSW1wb3J0ZSBCcnV0byAoRmFjdHVyYXMpJywgdmFsdWU6IGZvcm1hdFZhbHVlKHRvdGFscy5ncm9zc0Ftb3VudCwgJ2N1cnJlbmN5JykgfSxcbiAgICAgICAgeyBsYWJlbDogJ0Rlc2N1ZW50bycsIHZhbHVlOiBmb3JtYXRWYWx1ZSh0b3RhbHMuZGlzY291bnQsICdjdXJyZW5jeScpLCBpc05lZ2F0aXZlOiB0cnVlIH0sXG4gICAgICAgIHsgbGFiZWw6ICdJbXB1ZXN0b3MnLCB2YWx1ZTogZm9ybWF0VmFsdWUodG90YWxzLnRvdGFsVGF4ZXMsICdjdXJyZW5jeScpLCBpc05lZ2F0aXZlOiB0cnVlIH0sXG4gICAgICAgIHsgbGFiZWw6ICdJTVBPUlRFIE5FVE8nLCB2YWx1ZTogZm9ybWF0VmFsdWUodG90YWxzLm5ldEFtb3VudCwgJ2N1cnJlbmN5JyksIGlzQm9sZDogdHJ1ZSB9LFxuICAgIF07XG5cbiAgICAvLyBGdW5jacOzbiBwYXJhIG9idGVuZXIgZWwgbm9tYnJlIGRlbCBtw6l0b2RvIGRlIHBhZ28gKGPDs2RpZ29zIEFQSTogRUZFLCBDSEUsIFRSQSwgQ0hSLCBTQUw7IGxlZ2FjeTogMSwgMiwgMylcbiAgICBjb25zdCBnZXRQYXltZW50TWV0aG9kTmFtZSA9IChjb2RlOiBzdHJpbmcgfCBudWxsKSA9PiB7XG4gICAgICAgIHN3aXRjaCAoY29kZSkge1xuICAgICAgICAgICAgY2FzZSAnRUZFJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ0VmZWN0aXZvJztcbiAgICAgICAgICAgIGNhc2UgJ0NIRSc6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdDaGVxdWUnO1xuICAgICAgICAgICAgY2FzZSAnVFJBJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ1RyYW5zZmVyZW5jaWEgZW52aWFkYSc7XG4gICAgICAgICAgICBjYXNlICdDSFInOlxuICAgICAgICAgICAgICAgIHJldHVybiAnQ2hlcXVlIHJlY2liaWRvJztcbiAgICAgICAgICAgIGNhc2UgJ1NBTCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdTYWxkbyBhbnRpY2lwYWRvJztcbiAgICAgICAgICAgIGNhc2UgUEFZTUVOVF9NRVRIT0RfUkVURU5USU9OX0dBTkFOQ0lBUzpcbiAgICAgICAgICAgICAgICByZXR1cm4gJ1JldGVuY2nDs24gZGUgSW1wdWVzdG9zIGEgbGEgR2FuYW5jaWFzJztcbiAgICAgICAgICAgIGNhc2UgJzEnOlxuICAgICAgICAgICAgICAgIHJldHVybiAnRWZlY3Rpdm8nO1xuICAgICAgICAgICAgY2FzZSAnMic6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdDaGVxdWUnO1xuICAgICAgICAgICAgY2FzZSAnMyc6XG4gICAgICAgICAgICAgICAgcmV0dXJuICdUcmFuc2ZlcmVuY2lhIGVudmlhZGEnO1xuICAgICAgICAgICAgZGVmYXVsdDoge1xuICAgICAgICAgICAgICAgIGNvbnN0IGR5blRheElkID0gcGFyc2VUYXhJZEZyb21WZW5kb3JSZXRlbnRpb25Db2RlKGNvZGUgPz8gJycpO1xuICAgICAgICAgICAgICAgIGlmIChkeW5UYXhJZCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRheFJvdyA9IHBheW1lbnRPcmRlci5hcHBsaWVkX3RheGVzPy5maW5kKHQgPT4gdC50YXhfaWQgPT09IGR5blRheElkKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgbm0gPSB0YXhSb3c/LnRheF9uYW1lPy50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBubSA/IGBSZXRlbmNpw7NuICR7bm19YCA6IGBSZXRlbmNpw7NuIChpbXB1ZXN0byAke2R5blRheElkfSlgO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gY29kZSB8fCAnLSc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc206cC02IHNwYWNlLXktOFwiPlxuICAgICAgICAgICAgey8qIC0tLSBDQUJFQ0VSQSAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgYm9yZGVyLWIgc206ZmxleCBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBPcmRlbiBkZSBQYWdvICN7cGF5bWVudE9yZGVyLnBheW1lbnRfb3JkZXJfbnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2BtdC0xIHRleHQtc20gZm9udC1zZW1pYm9sZCAkeyFwYXltZW50T3JkZXIuaXNfYW5udWxsZWQgPyAndGV4dC1ncmVlbi02MDAnIDogJ3RleHQtcmVkLTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7IXBheW1lbnRPcmRlci5pc19hbm51bGxlZCA/ICdBY3RpdmEnIDogJ0FudWxhZGEnfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMyBzbTptdC0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG9yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiAvPiBWb2x2ZXJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIHtjYW5FZGl0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAke29yZGVuZXNQYWdvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZX0vJHtpZH0vZWRpdGFyYCl9IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVuY2lsIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+IEVkaXRhclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHshcGF5bWVudE9yZGVyLmlzX2FubnVsbGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZVByaW50UmVjZWlwdCgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nUmVjZWlwdFBkZn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itd2FpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJBYnJpciBvcmRlbiBkZSBwYWdvIGVuIFBERlwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRG93bmxvYWRpbmdSZWNlaXB0UGRmID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMSBhbmltYXRlLXNwaW5cIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb1ByaW50IGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbXByaW1pciBvcmRlbiBkZSBwYWdvXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge3Nob3dSZXRlbnRpb25DZXJ0aWZpY2F0ZUFjdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnYW5hbmNpYXNUYXhSb3dzLmxlbmd0aCA+IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHYW5hbmNpYXNUYXhJZCA/PyAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlbGVjdGVkR2FuYW5jaWFzVGF4SWQoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB8fCBudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gYmctd2hpdGUgbWF4LXctWzE0cmVtXVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiUmV0ZW5jacOzbiBHYW5hbmNpYXMgYSBjZXJ0aWZpY2FyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dhbmFuY2lhc1RheFJvd3MubWFwKHJvdyA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Jvdy5pZCA/PyByb3cudGF4X2lkfSB2YWx1ZT17cm93LmlkID8/ICcnfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhyb3cudGF4X25hbWUgPz8gJ1JldGVuY2nDs24nKSArIChyb3cuYW1vdW50ICE9IG51bGwgPyBgICgke2Zvcm1hdFZhbHVlKHJvdy5hbW91bnQsICdjdXJyZW5jeScpfSlgIDogJycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVEb3dubG9hZEdhbmFuY2lhc1JldGVudGlvbkNlcnRpZmljYXRlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nUmV0ZW50aW9uUGRmIHx8IChnYW5hbmNpYXNUYXhSb3dzLmxlbmd0aCA+IDEgJiYgc2VsZWN0ZWRHYW5hbmNpYXNUYXhJZCA9PSBudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFicmlyIGNlcnRpZmljYWRvIGRlIHJldGVuY2nDs24gR2FuYW5jaWFzIChQREYpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0Rvd25sb2FkaW5nUmV0ZW50aW9uUGRmID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTEgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb1ByaW50IGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENlcnRpZmljYWRvIHJldGVuY2nDs24gR2FuYW5jaWFzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIERFVEFMTEVTIFBSSU5DSVBBTEVTIFkgTU9OVE9TIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtOCBsZzpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5EZXRhbGxlcyBHZW5lcmFsZXM8L2gyPlxuICAgICAgICAgICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttYWluRGV0YWlscy5tYXAoZGV0YWlsID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZGV0YWlsLmxhYmVsfSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+e2RldGFpbC5sYWJlbH06PC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeydyZW5kZXInIGluIGRldGFpbCA/IChkZXRhaWwucmVuZGVyID8gZGV0YWlsLnJlbmRlcigpIDogbnVsbCkgOiBkZXRhaWwudmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UmVzdW1lbiBkZSBJbXBvcnRlczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Ftb3VudERldGFpbHMubWFwKGRldGFpbCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2RldGFpbC5sYWJlbH0gY2xhc3NOYW1lPXtgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSAke2RldGFpbC5pc0JvbGQgPyAnZm9udC1ib2xkIHRleHQtYmFzZScgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57ZGV0YWlsLmxhYmVsfTo8L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPXtgdGV4dC1ncmF5LTkwMCAke2RldGFpbC5pc05lZ2F0aXZlID8gJ3RleHQtcmVkLTYwMCcgOiAnJ31gfT57ZGV0YWlsLmlzTmVnYXRpdmUgJiYgJy0gJ317ZGV0YWlsLnZhbHVlfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIEZBQ1RVUkFTIEFQTElDQURBUyAtLS0gKi99XG4gICAgICAgICAgICB7cGF5bWVudE9yZGVyLmFwcGxpZWRfcHVyY2hhc2VzICYmIHBheW1lbnRPcmRlci5hcHBsaWVkX3B1cmNoYXNlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+RmFjdHVyYXMgQXBsaWNhZGFzIGVuIGVsIFBhZ288L2gyPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5GZWNoYSBGYWN0dXJhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5OwrogZGUgRmFjdHVyYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+UmVtaXRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+TW9udG8gQXBsaWNhZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudE9yZGVyLmFwcGxpZWRfcHVyY2hhc2VzLm1hcChhcCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXthcC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gc206cGwtNlwiPntmb3JtYXRWYWx1ZShhcC5wdXJjaGFzZS5wdXJjaGFzZV9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+e2FwLnB1cmNoYXNlLmRvY3VtZW50X251bWJlcn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2FwLnB1cmNoYXNlLmludGVybmFsX3ZvdWNoZXIgfHwgJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMCBmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKGFwLmFtb3VudF9hcHBsaWVkLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIC0tLSBOT1RBUyBGSU5BTkNJRVJBUyBBUExJQ0FEQVMgLS0tICovfVxuICAgICAgICAgICAge3BheW1lbnRPcmRlci5hcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyAmJiBwYXltZW50T3JkZXIuYXBwbGllZF9maW5hbmNpYWxfbm90ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPk5vdGFzIEZpbmFuY2llcmFzIEFwbGljYWRhczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPlRpcG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkZlY2hhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5OwrogQ29tcHJvYmFudGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlJlbWl0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk1vbnRvIEFwbGljYWRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnRPcmRlci5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcy5tYXAoYW4gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgbm90ZSA9IGFuLnB1cmNoYXNlX2ZpbmFuY2lhbF9ub3RlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYW1vdW50QXBwbGllZCA9IE51bWJlcihhbi5hbW91bnRfYXBwbGllZCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGViaXQgPSBhbW91bnRBcHBsaWVkID4gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVMYWJlbCA9IGFtb3VudEFwcGxpZWQgIT09IDAgPyBhcHBsaWVkRmluYW5jaWFsTm90ZVR5cGVMYWJlbChhbW91bnRBcHBsaWVkKSA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2FuLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R5cGVMYWJlbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsICR7aXNEZWJpdCA/ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCcgOiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R5cGVMYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogJy0nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc21cIj57Zm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7bm90YXNGaW5hbmNpZXJhc0NvbXByYU1vZHVsZUNvbmZpZy5iYXNlUm91dGV9LyR7bm90ZS5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bm90ZS52b3VjaGVyX251bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57bm90ZS5wdXJjaGFzZT8uaW50ZXJuYWxfdm91Y2hlciB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMCBmb250LXNlbWlib2xkXCI+e2Zvcm1hdFZhbHVlKGFuLmFtb3VudF9hcHBsaWVkLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogLS0tIElURU1TIERFIFBBR08gLS0tICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+TWVkaW9zIGRlIFBhZ28gQXBsaWNhZG9zPC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPk1lZGlvIGRlIFBhZ288L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q3VlbnRhIENvbnRhYmxlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkJhbmNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPk7CuiBDaGVxdWU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RmVjaGEgQ2hlcXVlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlJlZmVyZW5jaWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RW1pc29yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5JbXBvcnRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudE9yZGVyLml0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDaHIgPSBpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSFInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGVjayA9IGlzQ2hyID8gaXRlbS5yZWNlaXZlZF9jaGVjayA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhbmtOYW1lID0gY2hlY2sgPyBjaGVjay5iYW5rX25hbWUgOiBpdGVtLmJhbmtfbmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tOdW1iZXIgPSBjaGVjayA/IGNoZWNrLmNoZWNrX251bWJlciA6IGl0ZW0uY2hlY2tfbnVtYmVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGVja0RhdGUgPSBjaGVjayA/IGNoZWNrLmNoZWNrX2RhdGUgOiBpdGVtLmNoZWNrX2RhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZmVyZW5jZU51bWJlciA9IGNoZWNrID8gY2hlY2sucmVmZXJlbmNlX251bWJlciA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGhvbGRlciA9IGNoZWNrID8gY2hlY2suY2hlY2tfaG9sZGVyIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNtOnBsLTZcIj57Z2V0UGF5bWVudE1ldGhvZE5hbWUoaXRlbS5wYXltZW50X21ldGhvZF9jb2RlKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e2l0ZW0uY2hhcnRfYWNjb3VudD8ubmFtZSB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntiYW5rTmFtZSB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntjaGVja051bWJlciB8fCAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntjaGVja0RhdGUgPyBmb3JtYXRWYWx1ZShjaGVja0RhdGUsICdkYXRlJykgOiAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntyZWZlcmVuY2VOdW1iZXIgfHwgJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+e2hvbGRlciB8fCAnLSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hlY2s/Lmlzc3Vlcl9jdWl0ID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Q1VJVDoge2NoZWNrLmlzc3Vlcl9jdWl0fTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPntmb3JtYXRWYWx1ZShpdGVtLnZhbHVlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBJTVBVRVNUT1MgLS0tICovfVxuICAgICAgICAgICAge1NIT1dfQVBQTElFRF9UQVhFU19CTE9DSyAmJiBwYXltZW50T3JkZXIuYXBwbGllZF90YXhlcyAmJiBwYXltZW50T3JkZXIuYXBwbGllZF90YXhlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIEFwbGljYWRvczwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy14LWF1dG8gcmluZy0xIHJpbmctZ3JheS0zMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkltcHVlc3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+VGFzYSAoJSk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Nb250bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50T3JkZXIuYXBwbGllZF90YXhlcy5tYXAoKHRheCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3RheC5pZCB8fCBpbmRleH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPnt0YXgudGF4X25hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e3RheC5yYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG5cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvb3JkZW5lc19wYWdvL3BhZ2VzL09yZGVuZXNQYWdvRGV0YWlsUGFnZS50c3gifQ==