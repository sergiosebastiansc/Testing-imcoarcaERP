import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/bancos/pages/BancosCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/bancos/pages/BancosCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { bancosModuleConfig } from "/src/features/bancos/bancos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
const initialValues = {
  code: "",
  name: "",
  account_code: ""
};
export const BancosCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(bancosModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.info(`Banco creado con éxito!`);
      navigate("/bancos");
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: bancosModuleConfig,
      initialData: initialValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/bancos/pages/BancosCreatePage.tsx",
      lineNumber: 45,
      columnNumber: 5
    },
    this
  );
};
_s(BancosCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = BancosCreatePage;
var _c;
$RefreshReg$(_c, "BancosCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/bancos/pages/BancosCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/bancos/pages/BancosCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDBCQUFzQztBQUMvQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUV0QixNQUFNQyxnQkFBZ0M7QUFBQSxFQUNsQ0MsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxjQUFjO0FBQ2xCO0FBRU8sYUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTUMsV0FBV1gsWUFBWTtBQUM3QixRQUFNLEVBQUVZLFNBQVMsSUFBSVQsWUFBbUJELGtCQUFrQjtBQUUxRCxRQUFNVyxhQUFhLE9BQU9DLFNBQWdCO0FBQ3RDLFVBQU1DLFVBQVUsTUFBTUgsU0FBU0UsSUFBSTtBQUNuQyxRQUFJQyxTQUFTO0FBQ1RYLFlBQU1ZLEtBQUsseUJBQXlCO0FBQ3BDTCxlQUFTLFNBQVM7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRVDtBQUFBQSxNQUNSLGFBQWFHO0FBQUFBLE1BQ2IsUUFBUVE7QUFBQUEsTUFDUixNQUFLO0FBQUE7QUFBQSxJQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlpQjtBQUd6QjtBQUFFSCxHQXBCV0Qsa0JBQWdCO0FBQUEsVUFDUlQsYUFDSUcsV0FBVztBQUFBO0FBQUFjLEtBRnZCUjtBQUFnQixJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJiYW5jb3NNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsInRvYXN0IiwiaW5pdGlhbFZhbHVlcyIsImNvZGUiLCJuYW1lIiwiYWNjb3VudF9jb2RlIiwiQmFuY29zQ3JlYXRlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJzYXZlSXRlbSIsImhhbmRsZVNhdmUiLCJkYXRhIiwibmV3SXRlbSIsImluZm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYW5jb3NDcmVhdGVQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IGJhbmNvc01vZHVsZUNvbmZpZywgdHlwZSBCYW5jbyB9IGZyb20gJy4uL2JhbmNvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcblxuY29uc3QgaW5pdGlhbFZhbHVlczogUGFydGlhbDxCYW5jbz4gPSB7XG4gICAgY29kZTogJycsXG4gICAgbmFtZTogJycsXG4gICAgYWNjb3VudF9jb2RlOiAnJyxcbn07XG5cbmV4cG9ydCBjb25zdCBCYW5jb3NDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxCYW5jbz4oYmFuY29zTW9kdWxlQ29uZmlnKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogQmFuY28pID0+IHtcbiAgICAgICAgY29uc3QgbmV3SXRlbSA9IGF3YWl0IHNhdmVJdGVtKGRhdGEpO1xuICAgICAgICBpZiAobmV3SXRlbSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhgQmFuY28gY3JlYWRvIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL2JhbmNvcycpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17YmFuY29zTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2luaXRpYWxWYWx1ZXMgYXMgQmFuY299XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvYmFuY29zL3BhZ2VzL0JhbmNvc0NyZWF0ZVBhZ2UudHN4In0=