import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash, FaPercentage, FaTags, FaWarehouse } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { useSupervisorLowProfitAuth } from "/src/hooks/useSupervisorLowProfitAuth.tsx";
import { getById, getSalesOrderPendingInvoiceItems, searchByField } from "/src/services/apiService.ts";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { salesOrdersModuleConfig } from "/src/features/pedidos_venta/pedidos_venta_config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { articulosModuleConfig, articulosItemSearchFilters } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { AlertModal } from "/src/components/ui/AlertModal.tsx";
import { ToggleSwitch } from "/src/components/ui/ToggleSwitch.tsx";
import { ItemTaxModal } from "/src/components/common/ItemTaxModal.tsx";
import { ProductHistoryModal } from "/src/components/common/ProductHistoryModal.tsx";
import { formatValue, formatSalesInvoiceNumber } from "/src/utils/formatters.ts";
import { productCostToBaseCostPrice } from "/src/utils/productCostToBase.ts";
import {} from "/src/types/appliedTaxes.ts";
import { computeSalesAppliedTaxes } from "/src/utils/salesRelatedTaxComputation.ts";
import {
  computeExemptDocumentTotal,
  getEffectiveClientTaxes,
  hasValidArgentineCuit,
  isClientLeyExportacionTdfExempt,
  resolveInvoiceSeriesForClient,
  sanitizeTaxPayloadForExemptClient
} from "/src/utils/clientTaxExemption.ts";
import { initialHistoryModalState, priceListColumns } from "/src/types/historyModal.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const costListColumns = [
  { header: "Fecha Compra", accessor: "purchase_date", format: "date" },
  { header: "Factura Compra", accessor: "document_number" },
  { header: "Proveedor", accessor: "vendor_name" },
  { header: "Costo Unit.", accessor: "price_cost", format: "currency" },
  { header: "Cantidad", accessor: "quantity" }
];
const EMPTY_INVOICE_ITEM = {
  id: 0,
  tempId: "",
  line_number: 0,
  product_id: 0,
  product_code: "",
  product_name: "",
  quantity: 1,
  pending_quantity: 0,
  unit_price: 0,
  cost_price: 0,
  discount_amount: 0,
  commission_percentage: 0,
  // ✅ NUEVO
  taxes: [],
  base_sales_price: 0,
  base_cost_price: 0,
  stock_quantity: 0
};
const roundToTwoDecimals = (num) => {
  return Math.round(num * 100) / 100;
};
const defaultInitialData = {
  id: 0,
  invoice_number: "",
  status: "1",
  // Pendiente
  series: "A",
  // ✅ NUEVO: Serie por defecto
  invoice_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  delivery_date: null,
  total_amount: 0,
  notes: null,
  delivery_address: null,
  discount_amount: 0,
  exchange_rate: 1,
  client_id: null,
  salesperson_id: null,
  buyer_id: null,
  currency_id: null,
  transport_id: null,
  sales_order_id: null,
  client_code: null,
  salesperson_code: null,
  buyer_code: null,
  currency_code: null,
  transport_code: null,
  sales_order_number: null,
  sales_order_code: null,
  // mismo valor que order_number; RelationalInput usa *_code
  client: void 0,
  salesperson: void 0,
  buyer: void 0,
  currency: void 0,
  transport: void 0,
  sales_order: void 0,
  items: [],
  taxes: [],
  appliedTaxes: [],
  has_item_level_taxes: false,
  show_currency_equivalence: false
};
const isLineOverAvailableStock = (item) => {
  if (!item.product_id) return false;
  const q = Number(item.quantity) || 0;
  const s = Number(item.stock_quantity) || 0;
  return q > s;
};
const stockExcessMessage = (item) => {
  const q = Number(item.quantity) || 0;
  const s = Number(item.stock_quantity) || 0;
  const name = item.product_name || "el artículo";
  const code = item.product_code ? ` (${item.product_code})` : "";
  return `Está intentando facturar ${q} unidad(es) de "${name}"${code} pero el stock disponible es ${s}.`;
};
export const FacturasVentaFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedData, loading: loadingData, error } = useCrudItem(salesInvoicesModuleConfig, id);
  const { saveItem, loading: saving } = useCrudItem(salesInvoicesModuleConfig, id);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState([]);
  const [clientTaxes, setClientTaxes] = useState([]);
  const [selectedClientCuit, setSelectedClientCuit] = useState(null);
  const [clientTaxCondition, setClientTaxCondition] = useState(null);
  const [isClientTaxExempt, setIsClientTaxExempt] = useState(false);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [loadingOrderData, setLoadingOrderData] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const { gateSave, authModal } = useSupervisorLowProfitAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingItemIndex, setEditingItemIndex] = useState(null);
  const [isItemTaxModalOpen, setIsItemTaxModalOpen] = useState(false);
  const [currentItemIndexForTax, setCurrentItemIndexForTax] = useState(null);
  const [historyModalState, setHistoryModalState] = useState(initialHistoryModalState);
  const [stockAlert, setStockAlert] = useState({
    open: false,
    title: "",
    message: ""
  });
  const pendingAfterStockAckRef = useRef(null);
  const [clientAddresses, setClientAddresses] = useState([]);
  const [isCustomAddress, setIsCustomAddress] = useState(false);
  const [tempDeliveryAddress, setTempDeliveryAddress] = useState("");
  const [simboloMoneda, setSimboloMoneda] = useState("$");
  const [isExchangeRateReadonly, setIsExchangeRateReadonly] = useState(false);
  const effectiveExchangeRate = useMemo(() => {
    const rate = Number(formData.exchange_rate) || 1;
    return formData.currency_code === "01" ? 1 : rate;
  }, [formData.exchange_rate, formData.currency_code]);
  const calculateItemTaxes = (item, taxes = clientTaxes) => {
    if (!taxes || taxes.length === 0) return [];
    const taxBase = Number(item.quantity) * Number(item.unit_price) - (Number(item.discount_amount) || 0);
    return computeSalesAppliedTaxes({
      netBase: taxBase,
      clientTaxCondition,
      taxes
    });
  };
  useEffect(() => {
    const loadEditData = async () => {
      if (mode === "edit" && loadedData) {
        if (loadedData.status === "ISSUED") {
          toast.error("No se puede editar una factura que ha sido enviada a ARCA.");
          navigate(getListReturnPath(salesInvoicesModuleConfig.baseRoute));
          return;
        }
        setIsInitialLoading(true);
        const hydratedData = {
          ...defaultInitialData,
          ...loadedData,
          // Aplanamos Cliente
          client_code: loadedData.client?.[clientesModuleConfig.relationalFields.codeField] || "",
          client_name: loadedData.client?.[clientesModuleConfig.relationalFields.nameField] || "",
          // Aplanamos Vendedor
          salesperson_code: loadedData.salesperson?.[vendedoresModuleConfig.relationalFields.codeField] || "",
          salesperson_name: loadedData.salesperson?.[vendedoresModuleConfig.relationalFields.nameField] || "",
          // ... (repetir para buyer, currency, transport) ...
          buyer_code: loadedData.buyer?.[compradoresModuleConfig.relationalFields.codeField] || "",
          buyer_name: loadedData.buyer?.[compradoresModuleConfig.relationalFields.nameField] || "",
          currency_code: loadedData.currency?.[monedasModuleConfig.relationalFields.codeField] || "",
          currency_name: loadedData.currency?.[monedasModuleConfig.relationalFields.nameField] || "",
          transport_code: loadedData.transport?.[transportesModuleConfig.relationalFields.codeField] || "",
          transport_name: loadedData.transport?.[transportesModuleConfig.relationalFields.nameField] || "",
          // Aplanamos Pedido Origen (código visible = order_number)
          sales_order_number: loadedData.sales_order?.order_number || null,
          sales_order_code: loadedData.sales_order?.order_number != null && loadedData.sales_order?.order_number !== "" ? String(loadedData.sales_order.order_number) : null
        };
        let loadedClientTaxes = [];
        let isExemptOnLoad = false;
        try {
          if (hydratedData.client_id) {
            const clientData = hydratedData.client ? hydratedData.client : await getById(clientesModuleConfig.endpoint, hydratedData.client_id);
            if (clientData) {
              isExemptOnLoad = isClientLeyExportacionTdfExempt(clientData);
              setIsClientTaxExempt(isExemptOnLoad);
              setSelectedClientCuit(clientData.cuit ?? null);
              setClientTaxCondition(clientData.tax ?? null);
              loadedClientTaxes = getEffectiveClientTaxes(clientData, clientData.relatedTaxes);
            }
          }
          if (loadedData.client?.shipaddress) {
            setClientAddresses(loadedData.client.shipaddress);
            const isCustom = loadedData.delivery_address && !loadedData.client.shipaddress.includes(loadedData.delivery_address);
            setIsCustomAddress(!!isCustom);
            setTempDeliveryAddress(loadedData.delivery_address || "");
          } else {
            setTempDeliveryAddress(loadedData.delivery_address || "");
          }
          setFormData(hydratedData);
          let mappedEditItems = hydratedData.items.map((item) => ({
            ...item,
            tempId: crypto.randomUUID(),
            cost_price: item.cost_price || 0,
            commission_percentage: item.commission_percentage || 0,
            taxes: item.taxes || [],
            pending_quantity: Number(item.pending_quantity) || 0
          }));
          if (hydratedData.sales_order_id && id) {
            try {
              const invoiceIdNum = Number(id);
              const pendingRes = await getSalesOrderPendingInvoiceItems(hydratedData.sales_order_id, {
                excludeSalesInvoiceId: !Number.isNaN(invoiceIdNum) && invoiceIdNum > 0 ? invoiceIdNum : void 0
              });
              mappedEditItems = mappedEditItems.map((invItem) => {
                const sid = invItem.sales_order_item_id;
                const row = sid != null && sid > 0 ? pendingRes.items.find((p) => p.sales_order_item_id === sid) : pendingRes.items.find(
                  (p) => p.product_id === invItem.product_id && Number(p.line_number) === Number(invItem.line_number)
                );
                if (row == null) return invItem;
                const maxP = Number(row.quantity_pending);
                if (Number.isNaN(maxP) || maxP < 0) return invItem;
                return { ...invItem, pending_quantity: maxP };
              });
            } catch {
            }
          }
          const finalEditItems = isExemptOnLoad ? mappedEditItems.map((item) => ({ ...item, taxes: [] })) : mappedEditItems;
          setItems(finalEditItems);
          setClientTaxes(loadedClientTaxes);
          if (isExemptOnLoad) {
            setAppliedTaxes([]);
            setFormData((prev) => ({ ...prev, has_item_level_taxes: false }));
          } else if (!hydratedData.has_item_level_taxes) {
            setAppliedTaxes(hydratedData.appliedTaxes || hydratedData.taxes || []);
          }
        } catch (loadError) {
          toast.error(`Error al cargar datos relacionados: ${loadError.message || "Error desconocido"}`);
        } finally {
          setIsInitialLoading(false);
        }
      } else if (mode === "create") {
        setIsInitialLoading(false);
      }
    };
    loadEditData();
  }, [mode, loadedData]);
  useEffect(() => {
    const exchangeRate = effectiveExchangeRate;
    if (isNaN(exchangeRate) || exchangeRate === 0) return;
    setItems((prevItems) => prevItems.map((item) => {
      const basePrice = Number(item.base_sales_price) || 0;
      const baseCost = Number(item.base_cost_price) || 0;
      if (basePrice === 0 && baseCost === 0) return item;
      const newItem = {
        ...item,
        // Convertimos: Precio Base / Tasa de Cambio
        unit_price: roundToTwoDecimals(basePrice / exchangeRate),
        cost_price: roundToTwoDecimals(baseCost / exchangeRate)
      };
      if (formData.has_item_level_taxes && !isClientTaxExempt) {
        newItem.taxes = calculateItemTaxes(newItem, clientTaxes);
      }
      return newItem;
    }));
  }, [effectiveExchangeRate, clientTaxes, formData.has_item_level_taxes, clientTaxCondition, isClientTaxExempt]);
  useEffect(() => {
    if (isInitialLoading) return;
    if (formData.client_id) {
      getById(clientesModuleConfig.endpoint, formData.client_id).then((clientData) => {
        const exempt = isClientLeyExportacionTdfExempt(clientData);
        const newClientTaxes = getEffectiveClientTaxes(clientData, clientData.relatedTaxes);
        setIsClientTaxExempt(exempt);
        setSelectedClientCuit(clientData.cuit ?? null);
        setClientTaxCondition(clientData.tax ?? null);
        setClientTaxes(newClientTaxes);
        if (exempt) {
          setAppliedTaxes([]);
          setFormData((prev) => ({
            ...prev,
            has_item_level_taxes: false,
            series: "E"
          }));
          setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
        } else if (formData.has_item_level_taxes) {
          setItems((prev) => prev.map((item) => ({
            ...item,
            taxes: calculateItemTaxes(item, newClientTaxes)
          })));
        }
      }).catch(() => {
        toast.error("No se pudieron cargar los impuestos del cliente.");
        setIsClientTaxExempt(false);
        setSelectedClientCuit(null);
        setClientTaxCondition(null);
        setClientTaxes([]);
      });
    } else {
      setIsClientTaxExempt(false);
      setSelectedClientCuit(null);
      setClientTaxCondition(null);
      setClientTaxes([]);
      setAppliedTaxes([]);
      if (formData.has_item_level_taxes) {
        setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
      }
    }
  }, [formData.client_id, formData.has_item_level_taxes, isInitialLoading]);
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((sum, item) => sum + Number(item.quantity || 0) * Number(item.unit_price || 0), 0);
    const totalItemDiscounts = items.reduce((sum, item) => sum + (Number(item.discount_amount) || 0), 0);
    const globalDiscountAmount = Number(formData.discount_amount) || 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (formData.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => {
          const itemTaxAmount = (item.taxes || []).reduce((itemSum, tax) => itemSum + Number(tax.amount), 0);
          return sum + itemTaxAmount;
        }, 0);
      } else {
        totalTaxes = appliedTaxes.reduce((sum, tax) => sum + (Number(tax.amount) || 0), 0);
      }
    }
    const total = isClientTaxExempt ? computeExemptDocumentTotal(subtotal, totalItemDiscounts, globalDiscountAmount) : taxBase + totalTaxes;
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes, total };
  }, [items, formData.discount_amount, appliedTaxes, formData.has_item_level_taxes, isClientTaxExempt]);
  useEffect(() => {
    if (isInitialLoading) return;
    if (isClientTaxExempt) {
      setAppliedTaxes([]);
      return;
    }
    if (formData.has_item_level_taxes) {
      setAppliedTaxes([]);
      return;
    }
    if (clientTaxes.length > 0) {
      const { taxBase } = calculatedTotals;
      setAppliedTaxes(computeSalesAppliedTaxes({
        netBase: taxBase,
        clientTaxCondition,
        taxes: clientTaxes
      }));
    } else {
      setAppliedTaxes([]);
    }
  }, [calculatedTotals.taxBase, clientTaxes, formData.has_item_level_taxes, clientTaxCondition, isInitialLoading, formData.client_id, isClientTaxExempt]);
  const handleHeaderChange = (e) => {
    const target = e.target;
    const { name } = target;
    let finalValue;
    if (target instanceof HTMLInputElement && target.type === "checkbox") {
      finalValue = target.checked;
    } else {
      const { value } = target;
      finalValue = value;
      if (name === "discount_amount") finalValue = Number(value) || 0;
      if (name === "exchange_rate") finalValue = Number(value) || 1;
    }
    setFormData((prev) => ({ ...prev, [name]: finalValue }));
  };
  const applyHeaderSelection = async (field, selectedItem) => {
    const moduleConfigMap = {
      "client": clientesModuleConfig,
      "salesperson": vendedoresModuleConfig,
      "buyer": compradoresModuleConfig,
      "currency": monedasModuleConfig,
      "transport": transportesModuleConfig,
      "sales_order": salesOrdersModuleConfig
    };
    const moduleConfig = moduleConfigMap[field];
    if (!moduleConfig || !moduleConfig.relationalFields) {
      toast.error(`Error: Falta 'relationalFields' en la config de ${field}`);
      return;
    }
    const { codeField, nameField } = moduleConfig.relationalFields;
    if (field === "sales_order") {
      toast.info("Cargando datos del pedido...");
      setLoadingOrderData(true);
      setIsInitialLoading(true);
      try {
        const fullOrder = await getById(salesOrdersModuleConfig.endpoint, selectedItem.id);
        let loadedClientTaxes = [];
        let orderClientExempt = false;
        let orderClientTaxCondition = null;
        let orderClientForSeries = fullOrder.client ?? null;
        if (fullOrder.client_id) {
          try {
            const client = await getById(clientesModuleConfig.endpoint, fullOrder.client_id);
            orderClientExempt = isClientLeyExportacionTdfExempt(client);
            loadedClientTaxes = getEffectiveClientTaxes(client, client.relatedTaxes);
            orderClientTaxCondition = client.tax ?? null;
            setIsClientTaxExempt(orderClientExempt);
            setSelectedClientCuit(client.cuit ?? null);
            setClientTaxCondition(orderClientTaxCondition);
            setClientTaxes(loadedClientTaxes);
            orderClientForSeries = client;
          } catch {
            toast.error("Error cargando impuestos del cliente del pedido.");
          }
        }
        const resolvedOrderSeries = resolveInvoiceSeriesForClient(orderClientForSeries, "A");
        if (fullOrder.client?.shipaddress) {
          setClientAddresses(fullOrder.client.shipaddress);
          const isCustom = fullOrder.delivery_address && !fullOrder.client.shipaddress.includes(fullOrder.delivery_address);
          setIsCustomAddress(!!isCustom);
          setTempDeliveryAddress(fullOrder.delivery_address || "");
        } else {
          setClientAddresses([]);
          setIsCustomAddress(false);
          setTempDeliveryAddress(fullOrder.delivery_address || "");
        }
        setIsExchangeRateReadonly(!!fullOrder.is_exchange_rate_fixed);
        const excludeInvoiceId = mode === "edit" && id ? Number(id) : void 0;
        let pendingByOrderItemId = /* @__PURE__ */ new Map();
        try {
          const pendingRes = await getSalesOrderPendingInvoiceItems(fullOrder.id, {
            excludeSalesInvoiceId: excludeInvoiceId != null && !Number.isNaN(excludeInvoiceId) ? excludeInvoiceId : void 0
          });
          pendingByOrderItemId = new Map(
            pendingRes.items.map((p) => [p.sales_order_item_id, p.quantity_pending])
          );
          if (pendingByOrderItemId.size === 0) {
            toast.warn("No quedan cantidades por facturar para este pedido.");
          }
        } catch {
          toast.warn(
            "No se pudo obtener el pendiente de facturación; se usan las cantidades del pedido."
          );
          fullOrder.items.forEach((item) => {
            pendingByOrderItemId.set(Number(item.id), Number(item.quantity));
          });
        }
        const newItems = fullOrder.items.filter((item) => pendingByOrderItemId.has(Number(item.id))).map((item) => {
          const qtyPending = Number(pendingByOrderItemId.get(Number(item.id)) ?? 0);
          const invoiceItem = {
            ...EMPTY_INVOICE_ITEM,
            tempId: crypto.randomUUID(),
            sales_order_item_id: Number(item.id),
            product_id: item.product_id,
            product_code: item.product_code,
            product_name: item.product_name,
            quantity: qtyPending,
            pending_quantity: qtyPending,
            unit_price: item.unit_price,
            cost_price: Number(item.cost_price) || 0,
            discount_amount: item.discount_amount,
            commission_percentage: item.commission_percentage || 0,
            line_number: item.line_number,
            taxes: [],
            base_cost_price: item.base_cost_price,
            base_sales_price: Number(item.base_sales_price) || 0,
            stock_quantity: item.stock_quantity
          };
          if (fullOrder.has_item_level_taxes && !orderClientExempt) {
            const itemNet = Number(invoiceItem.quantity) * Number(invoiceItem.unit_price) - (Number(invoiceItem.discount_amount) || 0);
            invoiceItem.taxes = computeSalesAppliedTaxes({
              netBase: itemNet,
              clientTaxCondition: orderClientTaxCondition,
              taxes: loadedClientTaxes
            });
          }
          return invoiceItem;
        });
        setItems(newItems);
        setFormData((prev) => ({
          ...prev,
          series: resolvedOrderSeries,
          invoice_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          // Nueva fecha
          // Datos del Pedido
          sales_order_id: fullOrder.id,
          sales_order_number: fullOrder.order_number,
          sales_order_code: fullOrder.order_number != null && fullOrder.order_number !== "" ? String(fullOrder.order_number) : null,
          sales_order_name: fullOrder.client?.name,
          purchase_order_number: fullOrder.purchase_order_number,
          delivery_date: fullOrder.delivery_date,
          notes: fullOrder.notes,
          discount_amount: fullOrder.discount_amount ?? 0,
          exchange_rate: fullOrder.exchange_rate ?? 1,
          has_item_level_taxes: orderClientExempt ? false : fullOrder.has_item_level_taxes,
          // Datos Relacionales (aplanados)
          client_id: fullOrder.client_id,
          client_code: fullOrder.client?.[clientesModuleConfig.relationalFields.codeField] || "",
          client_name: fullOrder.client?.[clientesModuleConfig.relationalFields.nameField] || "",
          delivery_address: fullOrder.delivery_address || fullOrder.client?.address || "",
          salesperson_id: fullOrder.salesperson_id,
          salesperson_code: fullOrder.salesperson?.[vendedoresModuleConfig.relationalFields.codeField] || "",
          salesperson_name: fullOrder.salesperson?.[vendedoresModuleConfig.relationalFields.nameField] || "",
          buyer_id: fullOrder.buyer_id,
          buyer_code: fullOrder.buyer?.[compradoresModuleConfig.relationalFields.codeField] || "",
          buyer_name: fullOrder.buyer?.[compradoresModuleConfig.relationalFields.nameField] || "",
          currency_id: fullOrder.currency_id,
          currency_code: fullOrder.currency?.[monedasModuleConfig.relationalFields.codeField] || "",
          currency_name: fullOrder.currency?.[monedasModuleConfig.relationalFields.nameField] || "",
          transport_id: fullOrder.transport_id,
          transport_code: fullOrder.transport?.[transportesModuleConfig.relationalFields.codeField] || "",
          transport_name: fullOrder.transport?.[transportesModuleConfig.relationalFields.nameField] || ""
        }));
        if (orderClientExempt) {
          setAppliedTaxes([]);
        } else if (!fullOrder.has_item_level_taxes) {
          const subtotal = newItems.reduce((sum, i) => sum + Number(i.quantity) * Number(i.unit_price), 0);
          const itemDiscount = newItems.reduce((sum, i) => sum + Number(i.discount_amount), 0);
          const globalDiscount = Number(fullOrder.discount_amount || 0);
          const taxBase = subtotal - itemDiscount - globalDiscount;
          setAppliedTaxes(computeSalesAppliedTaxes({
            netBase: taxBase,
            clientTaxCondition: orderClientTaxCondition,
            taxes: loadedClientTaxes
          }));
        } else {
          setAppliedTaxes([]);
        }
      } catch (loadError) {
        toast.error(`No se pudieron cargar los datos del pedido: ${loadError.message}`);
      } finally {
        setIsInitialLoading(false);
        setLoadingOrderData(false);
      }
    } else {
      setIsExchangeRateReadonly(false);
      let resolvedItem = selectedItem;
      if (field === "client" && selectedItem?.id) {
        const rawSerie = selectedItem.serie;
        if (rawSerie == null || String(rawSerie).trim() === "") {
          try {
            resolvedItem = await getById(clientesModuleConfig.endpoint, selectedItem.id);
          } catch {
            resolvedItem = selectedItem;
          }
        }
      }
      setFormData((prev) => {
        const updatedData = { ...prev };
        if (resolvedItem) {
          updatedData[`${field}_id`] = resolvedItem.id;
          updatedData[`${field}_code`] = resolvedItem[codeField];
          updatedData[`${field}_name`] = resolvedItem[nameField];
          if (field === "client") {
            const addresses = resolvedItem.shipaddress || [];
            setClientAddresses(addresses);
            setIsCustomAddress(false);
            setSelectedClientCuit(resolvedItem.cuit ?? null);
            updatedData.series = resolveInvoiceSeriesForClient(resolvedItem, prev.series || "A");
            if (addresses.length > 0) {
              setTempDeliveryAddress(addresses[0]);
              updatedData.delivery_address = addresses[0];
            } else {
              setTempDeliveryAddress("");
              updatedData.delivery_address = null;
            }
            if (resolvedItem.salesrep) {
              updatedData.salesperson_id = resolvedItem.salesrep;
              updatedData.salesperson_code = resolvedItem.salesRepRelation?.code || null;
              updatedData.salesperson_name = resolvedItem.salesRepRelation?.name || null;
            }
            if (resolvedItem.transport_id) {
              updatedData.transport_id = resolvedItem.transport_id;
              updatedData.transport_code = resolvedItem.transport?.code || null;
              updatedData.transport_name = resolvedItem.transport?.name || null;
            }
            if (resolvedItem.currency_id) {
              updatedData.currency_id = resolvedItem.currency_id;
              updatedData.currency_code = resolvedItem.currency?.code || null;
              updatedData.currency_name = resolvedItem.currency?.name || null;
              updatedData.exchange_rate = resolvedItem.currency?.exchange_rate || null;
              if (updatedData.currency_code !== "01")
                setSimboloMoneda("USD");
              else
                setSimboloMoneda("$");
            }
            if (resolvedItem.buyer_id) {
              updatedData.buyer_id = resolvedItem.buyer_id;
              updatedData.buyer_code = resolvedItem.buyer?.code || null;
              updatedData.buyer_name = resolvedItem.buyer?.name || null;
            }
          } else if (field === "currency") {
            updatedData.exchange_rate = resolvedItem.exchange_rate || null;
            if (updatedData.currency_code !== "01")
              setSimboloMoneda("USD");
            else
              setSimboloMoneda("$");
          }
        }
        return updatedData;
      });
    }
    if (field === "client") setAppliedTaxes([]);
  };
  const handleOpenModal = (target, config, itemIndex = null) => {
    let modalConfig2 = config;
    if (target === "sales_order") {
      if (!formData.client_id) {
        toast.info("Seleccione un cliente primero para filtrar los pedidos.");
      }
      modalConfig2 = {
        ...config,
        initialFilters: { client_id: formData.client_id || void 0, status: "3" }
        // Filtra por cliente y autorizados
      };
    } else if (target === "item") {
      modalConfig2 = {
        ...config,
        initialFilters: articulosItemSearchFilters
      };
      setEditingItemIndex(itemIndex);
    }
    setEditingTarget(target);
    setModalConfig(modalConfig2);
    setIsModalOpen(true);
  };
  const handleSelectModal = async (selectedItem) => {
    if (!editingTarget) return;
    if (editingTarget === "item" && editingItemIndex !== null) {
      const skuValue = selectedItem.sku ? String(selectedItem.sku) : "";
      const product = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: "sku", value: skuValue },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      setItems((prevItems) => {
        const newItems = [...prevItems];
        const item = newItems[editingItemIndex];
        const { codeField, nameField } = articulosModuleConfig.relationalFields;
        const exchangeRate = effectiveExchangeRate;
        const basePrice = product.suggested_price || selectedItem.sale_price || 0;
        const baseCost = productCostToBaseCostPrice(
          product.cost_price ?? selectedItem.cost_price ?? 0,
          product.cost_currency,
          formData.exchange_rate
        );
        item.product_id = selectedItem.id;
        item.product_code = selectedItem[codeField];
        item.product_name = selectedItem[nameField];
        item.unit_price = selectedItem.sale_price || 0;
        item.cost_price = selectedItem.cost_price || 0;
        item.stock_quantity = product.stock_quantity ?? 0;
        item.base_sales_price = basePrice;
        item.base_cost_price = baseCost;
        item.base_sales_price = basePrice;
        item.base_cost_price = baseCost;
        item.unit_price = roundToTwoDecimals(basePrice / exchangeRate);
        item.cost_price = roundToTwoDecimals(baseCost / exchangeRate);
        if (formData.has_item_level_taxes && !isClientTaxExempt) {
          item.taxes = calculateItemTaxes(item, clientTaxes);
        } else {
          item.taxes = [];
        }
        newItems[editingItemIndex] = item;
        return newItems;
      });
      setEditingItemIndex(null);
    } else if (typeof editingTarget === "string" && editingTarget !== "item") {
      applyHeaderSelection(editingTarget, selectedItem);
    }
    setIsModalOpen(false);
  };
  const handleDeliveryAddressChange = (e) => {
    const value = e.target.value;
    if (value === "CUSTOM_NEW_ADDRESS") {
      setIsCustomAddress(true);
      setTempDeliveryAddress("");
    } else {
      setIsCustomAddress(false);
      setTempDeliveryAddress(value);
    }
  };
  const handleItemChange = (index, e) => {
    const { name, value } = e.target;
    const exchangeRate = effectiveExchangeRate;
    const numFields = ["quantity", "unit_price", "discount_amount", "commission_percentage"];
    let storedValue = numFields.includes(name) ? value === "" ? 0 : Number(value) || 0 : value;
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const prevRow = newItems[index];
      if (name === "quantity") {
        let q = Number(storedValue) || 0;
        if (q < 0) q = 0;
        const maxPending = Number(prevRow.pending_quantity) || 0;
        if (maxPending > 0 && q > maxPending) {
          toast.warn(
            `La cantidad máxima a facturar para ${prevRow.product_name || "este ítem"} es ${maxPending}.`
          );
          q = maxPending;
        }
        storedValue = q;
      }
      const item = { ...prevRow, [name]: storedValue };
      if (name === "unit_price") {
        const newValue = Number(storedValue) || 0;
        item.base_sales_price = newValue * exchangeRate;
        const baseCost = Number(item.base_cost_price) || 0;
        item.cost_price = roundToTwoDecimals(baseCost / exchangeRate);
      }
      if (formData.has_item_level_taxes && !isClientTaxExempt && (name === "quantity" || name === "unit_price" || name === "discount_amount")) {
        item.taxes = calculateItemTaxes(item, clientTaxes);
      } else if (name === "quantity" || name === "unit_price" || name === "discount_amount") {
        item.taxes = [];
      }
      newItems[index] = item;
      return newItems;
    });
  };
  const dispatchItemNumericChange = (index, name, value) => {
    handleItemChange(index, { target: { name, value: String(value) } });
  };
  const handleItemCodeSubmit = async (index) => {
    const item = items[index];
    if (!item.product_code) return;
    const { codeField, nameField } = articulosModuleConfig.relationalFields;
    const exchangeRate = effectiveExchangeRate;
    try {
      const product = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: codeField, value: item.product_code },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      if (product) {
        setItems((prevItems) => {
          const newItems = [...prevItems];
          const basePrice = product.suggested_price || product.sale_price || 0;
          const baseCost = productCostToBaseCostPrice(
            product.cost_price || 0,
            product.cost_currency,
            formData.exchange_rate
          );
          const currentPrice = Number(newItems[index].unit_price) || 0;
          const currentCost = Number(newItems[index].cost_price) || 0;
          const calculatedPrice = roundToTwoDecimals(basePrice / exchangeRate);
          const calculatedCost = roundToTwoDecimals(baseCost / exchangeRate);
          const updatedItem = {
            ...newItems[index],
            product_id: product.id,
            product_code: product[codeField],
            product_name: product[nameField],
            base_sales_price: basePrice,
            base_cost_price: baseCost,
            stock_quantity: product.stock_quantity,
            pending_quantity: 0,
            sales_order_item_id: void 0,
            unit_price: currentPrice > 0 ? currentPrice : calculatedPrice,
            cost_price: currentCost > 0 ? currentCost : calculatedCost
          };
          if (formData.has_item_level_taxes && !isClientTaxExempt) {
            updatedItem.taxes = calculateItemTaxes(updatedItem, clientTaxes);
          }
          newItems[index] = updatedItem;
          return newItems;
        });
        toast.success(`'${product[nameField]}' seleccionado.`);
      } else {
        toast.error(`No se encontró ningún artículo con el código "${item.product_code}".`);
      }
    } catch (err) {
      toast.error("Error al buscar artículo por código.");
    }
  };
  const handleItemCodeChange = (index, newCode) => {
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const item = { ...newItems[index] };
      item.product_code = newCode;
      item.product_id = 0;
      item.product_name = "";
      item.unit_price = 0;
      item.stock_quantity = 0;
      item.taxes = [];
      item.pending_quantity = 0;
      item.sales_order_item_id = void 0;
      newItems[index] = item;
      return newItems;
    });
  };
  const handleItemAutocompleteSelect = async (index, product) => {
    const { codeField, nameField } = articulosModuleConfig.relationalFields;
    const exchangeRate = effectiveExchangeRate;
    try {
      const skuValue = product.sku ? String(product.sku) : "";
      const fullProduct = await searchByField(
        "products/find-by-sku",
        [
          { fieldName: "sku", value: skuValue },
          { fieldName: "client_id", value: formData.client_id?.toString() ?? "" }
        ]
      );
      if (fullProduct) {
        setItems((prevItems) => {
          const newItems = [...prevItems];
          const item = newItems[index];
          const basePrice = fullProduct.suggested_price || fullProduct.sale_price || 0;
          const baseCost = productCostToBaseCostPrice(
            fullProduct.cost_price || 0,
            fullProduct.cost_currency,
            formData.exchange_rate
          );
          const currentPrice = Number(item.unit_price) || 0;
          const currentCost = Number(item.cost_price) || 0;
          item.product_id = fullProduct.id;
          item.product_code = fullProduct[codeField];
          item.product_name = fullProduct[nameField];
          item.stock_quantity = fullProduct.stock_quantity || 0;
          item.base_sales_price = basePrice;
          item.base_cost_price = baseCost;
          item.pending_quantity = 0;
          item.sales_order_item_id = void 0;
          if (currentPrice <= 0) item.unit_price = roundToTwoDecimals(basePrice / exchangeRate);
          if (currentCost <= 0) item.cost_price = roundToTwoDecimals(baseCost / exchangeRate);
          if (formData.has_item_level_taxes && !isClientTaxExempt) {
            item.taxes = calculateItemTaxes(item, clientTaxes);
          } else {
            item.taxes = [];
          }
          newItems[index] = item;
          return newItems;
        });
      }
    } catch (error2) {
      console.error("Error al cargar producto completo:", error2);
    }
  };
  const handleItemClear = (index) => {
    setItems((prevItems) => {
      const newItems = [...prevItems];
      const item = { ...newItems[index] };
      item.product_id = 0;
      item.product_code = "";
      item.product_name = "";
      item.unit_price = 0;
      item.stock_quantity = 0;
      item.taxes = [];
      item.discount_amount = 0;
      item.pending_quantity = 0;
      item.sales_order_item_id = void 0;
      newItems[index] = item;
      return newItems;
    });
  };
  const handleAddItem = () => {
    setItems((prev) => [...prev, { ...EMPTY_INVOICE_ITEM, tempId: crypto.randomUUID(), line_number: prev.length + 1 }]);
  };
  const handleRemoveItem = (index) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };
  const handleOpenItemTaxModal = (index) => {
    if (isClientTaxExempt) return;
    if (!formData.client_id) {
      toast.warn("Por favor, seleccione un cliente primero.");
      return;
    }
    setCurrentItemIndexForTax(index);
    setIsItemTaxModalOpen(true);
  };
  const handleSaveItemTaxes = (taxes) => {
    if (currentItemIndexForTax === null) return;
    setItems((prev) => prev.map((item, index) => index === currentItemIndexForTax ? { ...item, taxes } : item));
    setCurrentItemIndexForTax(null);
    setIsItemTaxModalOpen(false);
  };
  const handleTaxModeChange = (enabled) => {
    setFormData((prev) => ({ ...prev, has_item_level_taxes: enabled }));
    if (enabled) {
      setItems((prev) => prev.map((item) => ({ ...item, taxes: calculateItemTaxes(item, clientTaxes) })));
    } else {
      setItems((prev) => prev.map((item) => ({ ...item, taxes: [] })));
    }
  };
  const executeSave = async () => {
    setLoading(true);
    const cleanItems = items.map((item) => {
      const { tempId, sales_order_item_id: _uiOrderLineId, ...rest } = item;
      return {
        ...rest,
        id: rest.id || 0,
        taxes: formData.has_item_level_taxes && !isClientTaxExempt ? rest.taxes || [] : [],
        base_sales_price: rest.base_sales_price || 0,
        base_cost_price: rest.base_cost_price || 0
      };
    });
    const {
      client,
      salesperson,
      buyer,
      currency,
      transport,
      sales_order,
      client_code,
      client_name,
      salesperson_code,
      salesperson_name,
      buyer_code,
      buyer_name,
      currency_code,
      currency_name,
      transport_code,
      transport_name,
      sales_order_number,
      sales_order_code,
      appliedTaxes: _,
      ...headerPayload
    } = formData;
    const sanitized = isClientTaxExempt ? sanitizeTaxPayloadForExemptClient({
      taxes: appliedTaxes,
      items: cleanItems,
      has_item_level_taxes: formData.has_item_level_taxes
    }) : null;
    const dataToSend = {
      ...headerPayload,
      items: sanitized?.items ?? cleanItems,
      has_item_level_taxes: sanitized?.has_item_level_taxes ?? !!formData.has_item_level_taxes,
      total_amount: calculatedTotals.total,
      discount_amount: Number(formData.discount_amount) || 0,
      exchange_rate: Number(formData.exchange_rate) || 1,
      show_currency_equivalence: !!formData.show_currency_equivalence,
      taxes: sanitized ? sanitized.taxes : !formData.has_item_level_taxes ? appliedTaxes.filter((t) => t.amount > 0) : [],
      delivery_address: tempDeliveryAddress,
      invoice_number: formData.invoice_number == null || formData.invoice_number === "" ? "" : String(formData.invoice_number)
    };
    try {
      const saved = await saveItem(dataToSend);
      if (saved) {
        toast.success(`Factura ${mode === "create" ? "creada" : "actualizada"} con éxito.`);
        navigate(getListReturnPath(salesInvoicesModuleConfig.baseRoute));
      }
    } catch (apiError) {
      toast.error(`Error al guardar: ${apiError.message || "Error desconocido"}`);
    } finally {
      setLoading(false);
    }
  };
  const handleSave = async () => {
    if (!formData.client_id || !formData.salesperson_id || !formData.currency_id) {
      toast.error("Cliente, Vendedor y Moneda son obligatorios.");
      return;
    }
    let clientCuit = selectedClientCuit ?? formData.client?.cuit ?? null;
    if (isClientTaxExempt && !hasValidArgentineCuit(clientCuit) && formData.client_id) {
      try {
        const clientData = await getById(clientesModuleConfig.endpoint, formData.client_id);
        clientCuit = clientData.cuit ?? null;
        setSelectedClientCuit(clientCuit);
      } catch {
      }
    }
    if (isClientTaxExempt && !hasValidArgentineCuit(clientCuit)) {
      toast.error("El cliente con Ley Exportación TDF debe tener un CUIT válido (11 dígitos) para emitir factura E.");
      return;
    }
    if (items.length === 0) {
      toast.error("Añada al menos un producto.");
      return;
    }
    if (!tempDeliveryAddress || !tempDeliveryAddress.trim()) {
      toast.error("Debe especificar una Dirección de Entrega.");
      return;
    }
    for (const item of items) {
      const maxP = Number(item.pending_quantity) || 0;
      if (maxP > 0 && Number(item.quantity) > maxP) {
        toast.error(
          `La cantidad de "${item.product_name || "un ítem"}" (${Number(item.quantity)}) supera el pendiente de facturación (${maxP}).`
        );
        return;
      }
    }
    const proceedToSave = () => {
      gateSave(items, () => {
        void executeSave();
      });
    };
    const overStockItem = items.find(isLineOverAvailableStock);
    if (overStockItem) {
      pendingAfterStockAckRef.current = proceedToSave;
      setStockAlert({
        open: true,
        title: "Stock insuficiente",
        message: stockExcessMessage(overStockItem)
      });
      return;
    }
    proceedToSave();
  };
  const handleHeaderCodeChange = (field, newCode) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: newCode,
      [`${field}_name`]: "",
      [`${field}`]: void 0
    }));
    if (field === "client") {
      setClientTaxes([]);
      setSelectedClientCuit(null);
      setClientTaxCondition(null);
      setIsClientTaxExempt(false);
    }
  };
  const handleHeaderCodeSubmit = async (field, config) => {
    const codeValue = formData[`${field}_code`];
    if (!codeValue) return;
    if (!config?.relationalFields) return toast.error(`Configuración relacional faltante para ${field}`);
    const { endpoint, relationalFields } = config;
    try {
      const item = await searchByField(endpoint, [{ fieldName: relationalFields.codeField, value: codeValue }]);
      if (item) {
        if (field === "sales_order" && String(item.status) !== "3") {
          toast.error("Solo se pueden cargar pedidos autorizados.");
          return;
        }
        applyHeaderSelection(field, item);
        toast.success(`'${item[relationalFields.nameField]}' seleccionado.`);
      } else {
        toast.error(`No se encontró ítem con ese código.`);
      }
    } catch (err) {
      toast.error("Error al buscar por código.");
    }
  };
  const handleHeaderClear = (field) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: null,
      [`${field}_name`]: null,
      [`${field}`]: void 0
    }));
    if (field === "client") {
      setClientTaxes([]);
      setClientTaxCondition(null);
      setSelectedClientCuit(null);
      setIsClientTaxExempt(false);
    }
  };
  const handleOpenHistoryModal = (productId, type, productName) => {
    if (!productId) {
      toast.warn("El ítem no tiene un producto seleccionado.");
      return;
    }
    if (type === "price") {
      setHistoryModalState({
        isOpen: true,
        title: `Historial de Precios de Venta: ${productName}`,
        endpoint: "products/sales-history",
        productId,
        clientId: formData.client_id || null,
        columns: priceListColumns
      });
    } else {
      setHistoryModalState({
        isOpen: true,
        title: "Historial de Costos de Compra",
        endpoint: "products/purchases-history",
        productId,
        clientId: formData.client_id || null,
        columns: costListColumns
      });
    }
  };
  const handleCloseHistoryModal = () => setHistoryModalState(initialHistoryModalState);
  const handleCloseStockAlert = () => {
    setStockAlert((prev) => ({ ...prev, open: false }));
    const continueSave = pendingAfterStockAckRef.current;
    pendingAfterStockAckRef.current = null;
    continueSave?.();
  };
  const handleQuantityBlur = (index) => {
    const item = items[index];
    if (!item || !isLineOverAvailableStock(item)) return;
    pendingAfterStockAckRef.current = null;
    setStockAlert({
      open: true,
      title: "Stock insuficiente",
      message: stockExcessMessage(item)
    });
  };
  if ((loadingData || isInitialLoading) && mode === "edit") return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
    lineNumber: 1297,
    columnNumber: 68
  }, this);
  if (error && mode === "edit") return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar datos: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
    lineNumber: 1298,
    columnNumber: 40
  }, this);
  const totalLabelStyle = "text-sm text-gray-700";
  const totalValueStyle = "text-sm font-semibold text-gray-800 text-right";
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6", children: [
      (isLoading || saving) && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px] transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-6 bg-white shadow-xl rounded-2xl border border-indigo-100", children: [
        /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-10 h-10 text-indigo-600 animate-spin mb-3" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1314,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-800", children: "Conectando con ARCA" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1315,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 animate-pulse", children: "Obteniendo CAE y validando datos..." }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1316,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1313,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1312,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Crear Factura de Venta" : `Editando Factura ${formData.invoice_number != null && String(formData.invoice_number).trim() !== "" ? formatSalesInvoiceNumber(formData.series, formData.afip_pos, formData.invoice_number) : `#${id}`}` }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1321,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Pedido Origen" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1335,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.sales_order_code || "",
                nameValue: formData.sales_order_name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("sales_order", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("sales_order", salesOrdersModuleConfig),
                onSearchClick: () => handleOpenModal("sales_order", salesOrdersModuleConfig),
                onClearClick: () => {
                  setFormData(defaultInitialData);
                  setItems([]);
                  setClientTaxes([]);
                  setAppliedTaxes([]);
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1336,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1334,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente (*)" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1349,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.client_code || "",
                nameValue: formData.client_name || formData.client?.name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("client", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("client", clientesModuleConfig),
                onSearchClick: () => handleOpenModal("client", clientesModuleConfig),
                onClearClick: () => handleHeaderClear("client")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1350,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1348,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Vendedor" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1360,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.salesperson_code || "",
                nameValue: formData.salesperson_name || formData.salesperson?.name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("salesperson", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("salesperson", vendedoresModuleConfig),
                onSearchClick: () => handleOpenModal("salesperson", vendedoresModuleConfig),
                onClearClick: () => handleHeaderClear("salesperson")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1361,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1359,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1332,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1375,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "series",
                value: formData.series || "A",
                onChange: handleHeaderChange,
                disabled: isClientTaxExempt,
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm bg-white disabled:bg-gray-100",
                children: isClientTaxExempt ? /* @__PURE__ */ jsxDEV("option", { value: "E", children: "E" }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1384,
                  columnNumber: 17
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A" }, void 0, false, {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1387,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B" }, void 0, false, {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1388,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C" }, void 0, false, {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1389,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1386,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1376,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1374,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Factura (*)" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1395,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                name: "invoice_date",
                value: formData.invoice_date?.split("T")[0] || "",
                onChange: handleHeaderChange,
                autoComplete: "off",
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1396,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1394,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Entrega" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1405,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                name: "delivery_date",
                value: formData.delivery_date?.split("T")[0] || "",
                onChange: handleHeaderChange,
                autoComplete: "off",
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1406,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1404,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1372,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Comprador" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1418,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.buyer_code || "",
                nameValue: formData.buyer_name || formData.buyer?.name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("buyer", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("buyer", compradoresModuleConfig),
                onSearchClick: () => handleOpenModal("buyer", compradoresModuleConfig),
                onClearClick: () => handleHeaderClear("buyer")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1419,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1417,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Transporte" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1429,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.transport_code || "",
                nameValue: formData.transport_name || formData.transport?.name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("transport", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("transport", transportesModuleConfig),
                onSearchClick: () => handleOpenModal("transport", transportesModuleConfig),
                onClearClick: () => handleHeaderClear("transport")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1430,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1428,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Moneda" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1440,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: formData.currency_code || "",
                nameValue: formData.currency_name || formData.currency?.name || "",
                onCodeChange: (newCode) => handleHeaderCodeChange("currency", newCode),
                onCodeSubmit: () => handleHeaderCodeSubmit("currency", monedasModuleConfig),
                onSearchClick: () => handleOpenModal("currency", monedasModuleConfig),
                onClearClick: () => handleHeaderClear("currency")
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1441,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1439,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo de cambio" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1452,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  name: "exchange_rate",
                  value: formData.exchange_rate ?? 1,
                  emptyWhenZero: false,
                  onChange: (num) => setFormData((prev) => ({ ...prev, exchange_rate: num || 1 })),
                  readOnly: isExchangeRateReadonly,
                  disabled: isExchangeRateReadonly,
                  className: "block min-w-0 flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1454,
                  columnNumber: 33
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: "show_currency_equivalence",
                    name: "show_currency_equivalence",
                    type: "checkbox",
                    checked: !!formData.show_currency_equivalence,
                    onChange: handleHeaderChange,
                    autoComplete: "off",
                    className: "h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1464,
                    columnNumber: 37
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "show_currency_equivalence", className: "text-sm text-gray-900 whitespace-nowrap", children: "Mostrar valor en dolares" }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1472,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1463,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1453,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1451,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1416,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Nº Orden Compra" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1482,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "purchase_order_number",
                value: formData.purchase_order_number || "",
                onChange: handleHeaderChange,
                autoComplete: "off",
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1483,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1481,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Dirección de Entrega *" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1493,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "delivery_address_selector",
                value: isCustomAddress ? "CUSTOM_NEW_ADDRESS" : tempDeliveryAddress || (clientAddresses.length > 0 ? clientAddresses[0] : ""),
                onChange: handleDeliveryAddressChange,
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
                disabled: !formData.client_id,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecciona una dirección" }, void 0, false, {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1502,
                    columnNumber: 37
                  }, this),
                  (clientAddresses || []).map(
                    (address, index) => /* @__PURE__ */ jsxDEV("option", { value: address, children: address }, index, false, {
                      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                      lineNumber: 1505,
                      columnNumber: 19
                    }, this)
                  ),
                  /* @__PURE__ */ jsxDEV("option", { value: "CUSTOM_NEW_ADDRESS", children: "--- Ingresar Otra Dirección ---" }, void 0, false, {
                    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                    lineNumber: 1510,
                    columnNumber: 37
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1494,
                columnNumber: 33
              },
              this
            ),
            isCustomAddress && /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                name: "delivery_address_input",
                rows: 3,
                value: tempDeliveryAddress,
                onChange: (e) => setTempDeliveryAddress(e.target.value),
                placeholder: "Ingrese la nueva dirección de entrega",
                className: "mt-2 block w-full px-3 py-2 border border-indigo-500 rounded-md shadow-sm sm:text-sm",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1515,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1492,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1491,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1480,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1330,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Items de la Factura" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1533,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2 hidden", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-medium ${!formData.has_item_level_taxes ? "text-indigo-600" : "text-gray-500"}`, children: "Imp. Global" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1535,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(ToggleSwitch, { enabled: formData.has_item_level_taxes ?? false, onChange: handleTaxModeChange, srLabel: "Modo de impuestos" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1536,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-medium ${formData.has_item_level_taxes ? "text-indigo-600" : "text-gray-500"}`, children: "Imp. por Ítem" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1537,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1534,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1532,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-2/5", children: "Artículo" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1546,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Cant." }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1547,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Stock" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1548,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: [
              "P. Unit. (",
              simboloMoneda,
              ")"
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1549,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden", children: "Desc. (Monto)" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1550,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden", children: "Comisión %" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1552,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Subtotal" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1553,
              columnNumber: 37
            }, this),
            !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Impuestos" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1555,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Utilidad" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1557,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Total Línea" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1558,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Acc." }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1559,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1545,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1544,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map((item, index) => {
            const subtotal = Number(item.quantity) * Number(item.unit_price);
            const discount = Number(item.discount_amount) || 0;
            const lineSubtotal = subtotal - discount;
            const lineCost = Number(item.quantity) * Number(item.cost_price);
            const profit = (lineSubtotal - lineCost) / lineCost * 100;
            const itemTaxTotal = !isClientTaxExempt && formData.has_item_level_taxes ? (item.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0) : 0;
            const lineTotal = lineSubtotal + itemTaxTotal;
            return /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(
                RelationalInput,
                {
                  codeValue: item.product_code || "",
                  nameValue: item.product_name || "",
                  onCodeChange: (newCode) => handleItemCodeChange(index, newCode),
                  onCodeSubmit: () => handleItemCodeSubmit(index),
                  onSearchClick: () => handleOpenModal("item", articulosModuleConfig, index),
                  onClearClick: () => handleItemClear(index),
                  mask: "sku",
                  enableAutocomplete: true,
                  autocompleteConfig: {
                    endpoint: articulosModuleConfig.endpoint,
                    codeField: "sku",
                    nameField: "name",
                    searchParams: articulosItemSearchFilters,
                    onSelect: (product) => {
                      handleItemAutocompleteSelect(index, product);
                    }
                  }
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1575,
                  columnNumber: 49
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1574,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("p", { children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "quantity", value: item.quantity, onChange: (num) => dispatchItemNumericChange(index, "quantity", num), onBlur: () => handleQuantityBlur(index), className: "mt-1 block w-20 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1596,
                columnNumber: 52
              }, this) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1596,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1595,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: item.stock_quantity }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1598,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "unit_price", value: item.unit_price, onChange: (num) => dispatchItemNumericChange(index, "unit_price", num), className: "mt-1 block w-28 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1602,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1601,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap hidden", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "discount_amount", value: item.discount_amount, onChange: (num) => dispatchItemNumericChange(index, "discount_amount", num), className: "mt-1 block w-24 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1605,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1604,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap hidden", children: /* @__PURE__ */ jsxDEV(DecimalInput, { name: "commission_percentage", value: item.commission_percentage, onChange: (num) => dispatchItemNumericChange(index, "commission_percentage", num), className: "mt-1 block w-20 px-2 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1609,
                columnNumber: 49
              }, this) }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1608,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1611,
                columnNumber: 45
              }, this),
              !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm text-gray-500", children: formatValue(itemTaxTotal, "currency") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1615,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: `px-3 py-2 whitespace-nowrap text-sm font-medium ${profit >= 0 ? "text-green-600" : "text-red-600"}`, children: formatValue(profit, "percentual") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1619,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-semibold text-gray-700", children: formatValue(lineTotal, "currency") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1622,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-medium space-x-2", children: [
                /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenHistoryModal(item.product_id, "price", item.product_name), className: "p-2 text-blue-600 hover:text-blue-900", title: "Ver historial de precios", children: /* @__PURE__ */ jsxDEV(FaTags, {}, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1627,
                  columnNumber: 53
                }, this) }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1626,
                  columnNumber: 49
                }, this),
                /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenHistoryModal(item.product_id, "cost", item.product_name), className: "p-2 text-gray-600 hover:text-gray-900", title: "Ver historial de costos", children: /* @__PURE__ */ jsxDEV(FaWarehouse, {}, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1630,
                  columnNumber: 53
                }, this) }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1629,
                  columnNumber: 49
                }, this),
                !isClientTaxExempt && formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleOpenItemTaxModal(index), className: "p-2 text-indigo-600 hover:text-indigo-900", title: "Gestionar impuestos del ítem", children: /* @__PURE__ */ jsxDEV(FaPercentage, {}, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1634,
                  columnNumber: 57
                }, this) }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1633,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveItem(index), className: "p-2 text-red-600 hover:text-red-900", title: "Eliminar ítem", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1638,
                  columnNumber: 53
                }, this) }, void 0, false, {
                  fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                  lineNumber: 1637,
                  columnNumber: 49
                }, this)
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1625,
                columnNumber: 45
              }, this)
            ] }, item.tempId, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1573,
              columnNumber: 21
            }, this);
          }) }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1562,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1543,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1542,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddItem, className: "mt-4 inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700", children: [
          /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-5 h-5 mr-2" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1648,
            columnNumber: 25
          }, this),
          "Agregar Ítem"
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1647,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1531,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "hidden", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Descuento Global (Monto)" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1657,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                name: "discount_amount",
                value: formData.discount_amount,
                onChange: (num) => setFormData((prev) => ({ ...prev, discount_amount: num })),
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1658,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1656,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Observaciones:" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1666,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                name: "notes",
                rows: 3,
                value: formData.notes || "",
                onChange: handleHeaderChange,
                autoComplete: "off",
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1667,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1665,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1655,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !formData.has_item_level_taxes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1681,
            columnNumber: 33
          }, this),
          appliedTaxes.length > 0 ? appliedTaxes.map(
            (tax) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: [
                tax.tax_name,
                " (",
                tax.rate,
                "%):"
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1685,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1686,
                columnNumber: 45
              }, this)
            ] }, tax.tax_id, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1684,
              columnNumber: 15
            }, this)
          ) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No hay impuestos globales aplicados." }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1690,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1680,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1678,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1699,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1700,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1698,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center hidden", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Items):" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1703,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "- ",
              formatValue(calculatedTotals.totalItemDiscounts, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1704,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1702,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center hidden", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Global):" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1707,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "- ",
              formatValue(calculatedTotals.globalDiscountAmount, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1708,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1706,
            columnNumber: 29
          }, this),
          !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1713,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1714,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1712,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: formData.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1717,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
                "+ ",
                formatValue(calculatedTotals.totalTaxes, "currency")
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1720,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1716,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1711,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1725,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-lg font-bold text-indigo-600`, children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1726,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1724,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1697,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1696,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1654,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(salesInvoicesModuleConfig.baseRoute)), className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1734,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleSave,
            disabled: saving || isInitialLoading || loadingOrderData,
            className: `inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white border border-transparent rounded-md shadow-sm 
                        ${saving ? "bg-indigo-500 cursor-wait" : "bg-green-600 hover:bg-green-700"}`,
            children: saving || isInitialLoading || loadingOrderData ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1745,
                columnNumber: 33
              }, this),
              saving ? "Procesando en ARCA..." : "Cargando..."
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1744,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
                lineNumber: 1751,
                columnNumber: 33
              }, this),
              "Guardar Factura"
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
              lineNumber: 1750,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
            lineNumber: 1735,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
        lineNumber: 1733,
        columnNumber: 17
      }, this),
      isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
        SearchModal,
        {
          isOpen: isModalOpen,
          onClose: () => setIsModalOpen(false),
          onSelect: handleSelectModal,
          config: modalConfig
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1760,
          columnNumber: 9
        },
        this
      ),
      isItemTaxModalOpen && currentItemIndexForTax !== null && /* @__PURE__ */ jsxDEV(
        ItemTaxModal,
        {
          isOpen: isItemTaxModalOpen,
          onClose: () => setIsItemTaxModalOpen(false),
          onSave: handleSaveItemTaxes,
          item: items[currentItemIndexForTax],
          clientTaxes,
          clientTaxCondition
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1768,
          columnNumber: 9
        },
        this
      ),
      historyModalState.isOpen && /* @__PURE__ */ jsxDEV(
        ProductHistoryModal,
        {
          isOpen: historyModalState.isOpen,
          onClose: handleCloseHistoryModal,
          title: historyModalState.title,
          endpoint: historyModalState.endpoint,
          productId: historyModalState.productId,
          clientId: historyModalState.clientId,
          columns: historyModalState.columns
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1778,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        AlertModal,
        {
          isOpen: stockAlert.open,
          onClose: handleCloseStockAlert,
          title: stockAlert.title,
          message: stockAlert.message
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
          lineNumber: 1788,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
      lineNumber: 1307,
      columnNumber: 13
    }, this),
    authModal
  ] }, void 0, true, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx",
    lineNumber: 1306,
    columnNumber: 5
  }, this);
};
_s(FacturasVentaFormPage, "JMc/9qC0ET/gfgeVcK9ZBa0ZNHo=", false, function() {
  return [useParams, useNavigate, useCrudItem, useCrudItem, useSupervisorLowProfitAuth];
});
_c = FacturasVentaFormPage;
var _c;
$RefreshReg$(_c, "FacturasVentaFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNnZDcUUsU0F5RmpDLFVBekZpQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzdkNyRSxTQUFTQSxVQUFVQyxXQUFXQyxTQUFTQyxjQUFjO0FBQ3JELFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFFBQVFDLFdBQVdDLFFBQVFDLFNBQVNDLGNBQWNDLFFBQVFDLG1CQUFtQjtBQUN0RixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msa0NBQWtDO0FBQzNDLFNBQVNDLFNBQVNDLGtDQUFrQ0MscUJBQXFCO0FBRXpFLFNBQVNDLGlDQUEyRTtBQUVwRixTQUFTQywrQkFBa0Y7QUFHM0YsU0FBU0MsNEJBQTBDO0FBQ25ELFNBQVNDLDhCQUE2QztBQUN0RCxTQUFTQywrQkFBK0M7QUFDeEQsU0FBU0MsMkJBQXdDO0FBQ2pELFNBQVNDLCtCQUFnRDtBQUN6RCxTQUFTQyx1QkFBdUJDLGtDQUFrQztBQUdsRSxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLGFBQWFDLGdDQUFnQztBQUN0RCxTQUFTQyxrQ0FBa0M7QUFDM0MsZUFBOEQ7QUFDOUQsU0FBU0MsZ0NBQWdDO0FBQ3pDO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDRztBQUVQLFNBQVNDLDBCQUEwQkMsd0JBQWdEO0FBQ25GLFNBQVNDLHlCQUF5QjtBQXdCbEMsTUFBTUMsa0JBQXVEO0FBQUEsRUFDekQsRUFBRUMsUUFBUSxnQkFBZ0JDLFVBQVUsaUJBQWlCQyxRQUFRLE9BQU87QUFBQSxFQUNwRSxFQUFFRixRQUFRLGtCQUFrQkMsVUFBVSxrQkFBa0I7QUFBQSxFQUN4RCxFQUFFRCxRQUFRLGFBQWFDLFVBQVUsY0FBYztBQUFBLEVBQy9DLEVBQUVELFFBQVEsZUFBZUMsVUFBVSxjQUFjQyxRQUFRLFdBQVc7QUFBQSxFQUNwRSxFQUFFRixRQUFRLFlBQVlDLFVBQVUsV0FBVztBQUFDO0FBV2hELE1BQU1FLHFCQUEyQztBQUFBLEVBQzdDQyxJQUFJO0FBQUEsRUFBR0MsUUFBUTtBQUFBLEVBQUlDLGFBQWE7QUFBQSxFQUFHQyxZQUFZO0FBQUEsRUFDL0NDLGNBQWM7QUFBQSxFQUFJQyxjQUFjO0FBQUEsRUFBSUMsVUFBVTtBQUFBLEVBQUdDLGtCQUFrQjtBQUFBLEVBQ25FQyxZQUFZO0FBQUEsRUFBR0MsWUFBWTtBQUFBLEVBQUdDLGlCQUFpQjtBQUFBLEVBQy9DQyx1QkFBdUI7QUFBQTtBQUFBLEVBQ3ZCQyxPQUFPO0FBQUEsRUFDUEMsa0JBQWtCO0FBQUEsRUFDbEJDLGlCQUFpQjtBQUFBLEVBQ2pCQyxnQkFBZ0I7QUFDcEI7QUFFQSxNQUFNQyxxQkFBcUJBLENBQUNDLFFBQXdCO0FBQ2hELFNBQU9DLEtBQUtDLE1BQU1GLE1BQU0sR0FBRyxJQUFJO0FBQ25DO0FBSUEsTUFBTUcscUJBQTRDO0FBQUEsRUFDOUNwQixJQUFJO0FBQUEsRUFBR3FCLGdCQUFnQjtBQUFBLEVBQ3ZCQyxRQUFRO0FBQUE7QUFBQSxFQUNSQyxRQUFRO0FBQUE7QUFBQSxFQUNSQyxlQUFjLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ25EQyxlQUFlO0FBQUEsRUFDZkMsY0FBYztBQUFBLEVBQUdDLE9BQU87QUFBQSxFQUFNQyxrQkFBa0I7QUFBQSxFQUNoRHJCLGlCQUFpQjtBQUFBLEVBQUdzQixlQUFlO0FBQUEsRUFDbkNDLFdBQVc7QUFBQSxFQUFNQyxnQkFBZ0I7QUFBQSxFQUFNQyxVQUFVO0FBQUEsRUFDakRDLGFBQWE7QUFBQSxFQUFNQyxjQUFjO0FBQUEsRUFBTUMsZ0JBQWdCO0FBQUEsRUFDdkRDLGFBQWE7QUFBQSxFQUFNQyxrQkFBa0I7QUFBQSxFQUFNQyxZQUFZO0FBQUEsRUFDdkRDLGVBQWU7QUFBQSxFQUFNQyxnQkFBZ0I7QUFBQSxFQUFNQyxvQkFBb0I7QUFBQSxFQUMvREMsa0JBQWtCO0FBQUE7QUFBQSxFQUNsQkMsUUFBUUM7QUFBQUEsRUFBV0MsYUFBYUQ7QUFBQUEsRUFBV0UsT0FBT0Y7QUFBQUEsRUFDbERHLFVBQVVIO0FBQUFBLEVBQVdJLFdBQVdKO0FBQUFBLEVBQVdLLGFBQWFMO0FBQUFBLEVBQ3hETSxPQUFPO0FBQUEsRUFBSXpDLE9BQU87QUFBQSxFQUFJMEMsY0FBYztBQUFBLEVBQ3BDQyxzQkFBc0I7QUFBQSxFQUN0QkMsMkJBQTJCO0FBQy9CO0FBRUEsTUFBTUMsMkJBQTJCQSxDQUFDQyxTQUF3QztBQUN0RSxNQUFJLENBQUNBLEtBQUt2RCxXQUFZLFFBQU87QUFDN0IsUUFBTXdELElBQUlDLE9BQU9GLEtBQUtwRCxRQUFRLEtBQUs7QUFDbkMsUUFBTXVELElBQUlELE9BQU9GLEtBQUszQyxjQUFjLEtBQUs7QUFDekMsU0FBTzRDLElBQUlFO0FBQ2Y7QUFFQSxNQUFNQyxxQkFBcUJBLENBQUNKLFNBQXVDO0FBQy9ELFFBQU1DLElBQUlDLE9BQU9GLEtBQUtwRCxRQUFRLEtBQUs7QUFDbkMsUUFBTXVELElBQUlELE9BQU9GLEtBQUszQyxjQUFjLEtBQUs7QUFDekMsUUFBTWdELE9BQU9MLEtBQUtyRCxnQkFBZ0I7QUFDbEMsUUFBTTJELE9BQU9OLEtBQUt0RCxlQUFlLEtBQUtzRCxLQUFLdEQsWUFBWSxNQUFNO0FBQzdELFNBQU8sNEJBQTRCdUQsQ0FBQyxtQkFBbUJJLElBQUksSUFBSUMsSUFBSSxnQ0FBZ0NILENBQUM7QUFDeEc7QUFHTyxhQUFNSSx3QkFBd0JBLE1BQU07QUFBQUMsS0FBQTtBQUN2QyxRQUFNLEVBQUVsRSxHQUFHLElBQUlqRCxVQUEwQjtBQUN6QyxRQUFNb0gsV0FBV3JILFlBQVk7QUFDN0IsUUFBTXNILE9BQU9wRSxLQUFLLFNBQVM7QUFFM0IsUUFBTSxFQUFFMEQsTUFBTVcsWUFBWUMsU0FBU0MsYUFBYUMsTUFBTSxJQUFJaEgsWUFBMEJLLDJCQUEyQm1DLEVBQUU7QUFDakgsUUFBTSxFQUFFeUUsVUFBVUgsU0FBU0ksT0FBTyxJQUFJbEgsWUFBMEJLLDJCQUEyQm1DLEVBQUU7QUFHN0YsUUFBTSxDQUFDMkUsVUFBVUMsV0FBVyxJQUFJbEksU0FBZ0MwRSxrQkFBa0I7QUFDbEYsUUFBTSxDQUFDaUMsT0FBT3dCLFFBQVEsSUFBSW5JLFNBQWlDLEVBQUU7QUFDN0QsUUFBTSxDQUFDb0ksYUFBYUMsY0FBYyxJQUFJckksU0FBc0IsRUFBRTtBQUM5RCxRQUFNLENBQUNzSSxvQkFBb0JDLHFCQUFxQixJQUFJdkksU0FBd0IsSUFBSTtBQUNoRixRQUFNLENBQUN3SSxvQkFBb0JDLHFCQUFxQixJQUFJekksU0FBd0IsSUFBSTtBQUNoRixRQUFNLENBQUMwSSxtQkFBbUJDLG9CQUFvQixJQUFJM0ksU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzRHLGNBQWNnQyxlQUFlLElBQUk1SSxTQUF1QixFQUFFO0FBQ2pFLFFBQU0sQ0FBQzZJLGtCQUFrQkMsbUJBQW1CLElBQUk5SSxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDK0ksa0JBQWtCQyxtQkFBbUIsSUFBSWhKLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNpSixXQUFXQyxVQUFVLElBQUlsSixTQUFTLEtBQUs7QUFDOUMsUUFBTSxFQUFFbUosVUFBVUMsVUFBVSxJQUFJckksMkJBQTJCO0FBRzNELFFBQU0sQ0FBQ3NJLGFBQWFDLGNBQWMsSUFBSXRKLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN1SixlQUFlQyxnQkFBZ0IsSUFBSXhKLFNBQStCLElBQUk7QUFDN0UsUUFBTSxDQUFDeUosYUFBYUMsY0FBYyxJQUFJMUosU0FBOEQsSUFBSTtBQUN4RyxRQUFNLENBQUMySixrQkFBa0JDLG1CQUFtQixJQUFJNUosU0FBd0IsSUFBSTtBQUU1RSxRQUFNLENBQUM2SixvQkFBb0JDLHFCQUFxQixJQUFJOUosU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQytKLHdCQUF3QkMseUJBQXlCLElBQUloSyxTQUF3QixJQUFJO0FBRXhGLFFBQU0sQ0FBQ2lLLG1CQUFtQkMsb0JBQW9CLElBQUlsSyxTQUE0QjhDLHdCQUF3QjtBQUV0RyxRQUFNLENBQUNxSCxZQUFZQyxhQUFhLElBQUlwSyxTQUE0RDtBQUFBLElBQzVGcUssTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsRUFDYixDQUFDO0FBQ0QsUUFBTUMsMEJBQTBCckssT0FBNEIsSUFBSTtBQUVoRSxRQUFNLENBQUNzSyxpQkFBaUJDLGtCQUFrQixJQUFJMUssU0FBbUIsRUFBRTtBQUNuRSxRQUFNLENBQUMySyxpQkFBaUJDLGtCQUFrQixJQUFJNUssU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZLLHFCQUFxQkMsc0JBQXNCLElBQUk5SyxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDK0ssZUFBZUMsZ0JBQWdCLElBQUloTCxTQUFTLEdBQUc7QUFDdEQsUUFBTSxDQUFDaUwsd0JBQXdCQyx5QkFBeUIsSUFBSWxMLFNBQVMsS0FBSztBQUcxRSxRQUFNbUwsd0JBQXdCakwsUUFBUSxNQUFNO0FBQ3hDLFVBQU1rTCxPQUFPbEUsT0FBT2UsU0FBUzNDLGFBQWEsS0FBSztBQUUvQyxXQUFPMkMsU0FBU2pDLGtCQUFrQixPQUFPLElBQUlvRjtBQUFBQSxFQUNqRCxHQUFHLENBQUNuRCxTQUFTM0MsZUFBZTJDLFNBQVNqQyxhQUFhLENBQUM7QUFFbkQsUUFBTXFGLHFCQUFxQkEsQ0FBQ3JFLE1BQTRCOUMsUUFBcUJrRSxnQkFBOEI7QUFDdkcsUUFBSSxDQUFDbEUsU0FBU0EsTUFBTW9ILFdBQVcsRUFBRyxRQUFPO0FBQ3pDLFVBQU1DLFVBQVdyRSxPQUFPRixLQUFLcEQsUUFBUSxJQUFJc0QsT0FBT0YsS0FBS2xELFVBQVUsS0FBTW9ELE9BQU9GLEtBQUtoRCxlQUFlLEtBQUs7QUFDckcsV0FBT3pCLHlCQUF5QjtBQUFBLE1BQzVCaUosU0FBU0Q7QUFBQUEsTUFDVC9DO0FBQUFBLE1BQ0F0RTtBQUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBSUFqRSxZQUFVLE1BQU07QUFDWixVQUFNd0wsZUFBZSxZQUFZO0FBQzdCLFVBQUkvRCxTQUFTLFVBQVVDLFlBQVk7QUFFL0IsWUFBSUEsV0FBVy9DLFdBQVcsVUFBVTtBQUNoQ3RFLGdCQUFNd0gsTUFBTSw0REFBNEQ7QUFDeEVMLG1CQUFTekUsa0JBQWtCN0IsMEJBQTBCdUssU0FBUyxDQUFDO0FBQy9EO0FBQUEsUUFDSjtBQUVBNUMsNEJBQW9CLElBQUk7QUFFeEIsY0FBTTZDLGVBQWU7QUFBQSxVQUNqQixHQUFHakg7QUFBQUEsVUFDSCxHQUFHaUQ7QUFBQUE7QUFBQUEsVUFFSDlCLGFBQWE4QixXQUFXdkIsU0FBUy9FLHFCQUFxQnVLLGlCQUFrQkMsU0FBMEIsS0FBZTtBQUFBLFVBQ2pIQyxhQUFhbkUsV0FBV3ZCLFNBQVMvRSxxQkFBcUJ1SyxpQkFBa0JHLFNBQTBCLEtBQWU7QUFBQTtBQUFBLFVBRWpIakcsa0JBQWtCNkIsV0FBV3JCLGNBQWNoRix1QkFBdUJzSyxpQkFBa0JDLFNBQTJCLEtBQWU7QUFBQSxVQUM5SEcsa0JBQWtCckUsV0FBV3JCLGNBQWNoRix1QkFBdUJzSyxpQkFBa0JHLFNBQTJCLEtBQWU7QUFBQTtBQUFBLFVBRTlIaEcsWUFBWTRCLFdBQVdwQixRQUFRaEYsd0JBQXdCcUssaUJBQWtCQyxTQUE0QixLQUFlO0FBQUEsVUFDcEhJLFlBQVl0RSxXQUFXcEIsUUFBUWhGLHdCQUF3QnFLLGlCQUFrQkcsU0FBNEIsS0FBZTtBQUFBLFVBQ3BIL0YsZUFBZTJCLFdBQVduQixXQUFXaEYsb0JBQW9Cb0ssaUJBQWtCQyxTQUF5QixLQUFlO0FBQUEsVUFDbkhLLGVBQWV2RSxXQUFXbkIsV0FBV2hGLG9CQUFvQm9LLGlCQUFrQkcsU0FBeUIsS0FBZTtBQUFBLFVBQ25IOUYsZ0JBQWdCMEIsV0FBV2xCLFlBQVloRix3QkFBd0JtSyxpQkFBa0JDLFNBQTZCLEtBQWU7QUFBQSxVQUM3SE0sZ0JBQWdCeEUsV0FBV2xCLFlBQVloRix3QkFBd0JtSyxpQkFBa0JHLFNBQTZCLEtBQWU7QUFBQTtBQUFBLFVBRTdIN0Ysb0JBQW9CeUIsV0FBV2pCLGFBQWEwRixnQkFBZ0I7QUFBQSxVQUM1RGpHLGtCQUNJd0IsV0FBV2pCLGFBQWEwRixnQkFBZ0IsUUFBUXpFLFdBQVdqQixhQUFhMEYsaUJBQWlCLEtBQ25GQyxPQUFPMUUsV0FBV2pCLFlBQVkwRixZQUFZLElBQzFDO0FBQUEsUUFDZDtBQUVBLFlBQUlFLG9CQUFpQztBQUNyQyxZQUFJQyxpQkFBaUI7QUFFckIsWUFBSTtBQUVBLGNBQUlaLGFBQWFwRyxXQUFXO0FBRXhCLGtCQUFNaUgsYUFBYWIsYUFBYXZGLFNBQzFCdUYsYUFBYXZGLFNBQ2IsTUFBTXBGLFFBQWlCSyxxQkFBcUJvTCxVQUFVZCxhQUFhcEcsU0FBUztBQUVsRixnQkFBSWlILFlBQVk7QUFDWkQsK0JBQWlCNUosZ0NBQWdDNkosVUFBVTtBQUMzRDdELG1DQUFxQjRELGNBQWM7QUFDbkNoRSxvQ0FBc0JpRSxXQUFXRSxRQUFRLElBQUk7QUFDN0NqRSxvQ0FBc0IrRCxXQUFXRyxPQUFPLElBQUk7QUFDNUNMLGtDQUFvQjdKLHdCQUF3QitKLFlBQVlBLFdBQVdJLFlBQVk7QUFBQSxZQUNuRjtBQUFBLFVBQ0o7QUFFQSxjQUFJakYsV0FBV3ZCLFFBQVF5RyxhQUFhO0FBQ2hDbkMsK0JBQW1CL0MsV0FBV3ZCLE9BQU95RyxXQUF1QjtBQUc1RCxrQkFBTUMsV0FBV25GLFdBQVd0QyxvQkFDckIsQ0FBQ3NDLFdBQVd2QixPQUFPeUcsWUFBWUUsU0FBU3BGLFdBQVd0QyxnQkFBZ0I7QUFFMUV1RiwrQkFBbUIsQ0FBQyxDQUFDa0MsUUFBUTtBQUM3QmhDLG1DQUF1Qm5ELFdBQVd0QyxvQkFBb0IsRUFBRTtBQUFBLFVBQzVELE9BQU87QUFDSHlGLG1DQUF1Qm5ELFdBQVd0QyxvQkFBb0IsRUFBRTtBQUFBLFVBQzVEO0FBRUE2QyxzQkFBWXlELFlBQVk7QUFFeEIsY0FBSXFCLGtCQUEwQ3JCLGFBQWFoRixNQUFNc0csSUFBSSxDQUFBakcsVUFBUztBQUFBLFlBQzFFLEdBQUdBO0FBQUFBLFlBQ0h6RCxRQUFRMkosT0FBT0MsV0FBVztBQUFBLFlBQzFCcEosWUFBYWlELEtBQWFqRCxjQUFjO0FBQUEsWUFDeENFLHVCQUF3QitDLEtBQWEvQyx5QkFBeUI7QUFBQSxZQUM5REMsT0FBTzhDLEtBQUs5QyxTQUFTO0FBQUEsWUFDckJMLGtCQUFrQnFELE9BQU9GLEtBQUtuRCxnQkFBZ0IsS0FBSztBQUFBLFVBQ3ZELEVBQUU7QUFFRixjQUFJOEgsYUFBYS9GLGtCQUFrQnRDLElBQUk7QUFDbkMsZ0JBQUk7QUFDQSxvQkFBTThKLGVBQWVsRyxPQUFPNUQsRUFBRTtBQUM5QixvQkFBTStKLGFBQWEsTUFBTXBNLGlDQUFpQzBLLGFBQWEvRixnQkFBZ0I7QUFBQSxnQkFDbkYwSCx1QkFDSSxDQUFDcEcsT0FBT3FHLE1BQU1ILFlBQVksS0FBS0EsZUFBZSxJQUFJQSxlQUFlL0c7QUFBQUEsY0FDekUsQ0FBQztBQUNEMkcsZ0NBQWtCQSxnQkFBZ0JDLElBQUksQ0FBQU8sWUFBVztBQUM3QyxzQkFBTUMsTUFBTUQsUUFBUUU7QUFDcEIsc0JBQU1DLE1BQ0ZGLE9BQU8sUUFBUUEsTUFBTSxJQUNmSixXQUFXMUcsTUFBTWlILEtBQUssQ0FBQUMsTUFBS0EsRUFBRUgsd0JBQXdCRCxHQUFHLElBQ3hESixXQUFXMUcsTUFBTWlIO0FBQUFBLGtCQUNmLENBQUFDLE1BQ0lBLEVBQUVwSyxlQUFlK0osUUFBUS9KLGNBQ3pCeUQsT0FBTzJHLEVBQUVySyxXQUFXLE1BQU0wRCxPQUFPc0csUUFBUWhLLFdBQVc7QUFBQSxnQkFDNUQ7QUFDUixvQkFBSW1LLE9BQU8sS0FBTSxRQUFPSDtBQUN4QixzQkFBTU0sT0FBTzVHLE9BQU95RyxJQUFJSSxnQkFBZ0I7QUFDeEMsb0JBQUk3RyxPQUFPcUcsTUFBTU8sSUFBSSxLQUFLQSxPQUFPLEVBQUcsUUFBT047QUFDM0MsdUJBQU8sRUFBRSxHQUFHQSxTQUFTM0osa0JBQWtCaUssS0FBSztBQUFBLGNBQ2hELENBQUM7QUFBQSxZQUNMLFFBQVE7QUFBQSxZQUNKO0FBQUEsVUFFUjtBQUVBLGdCQUFNRSxpQkFBaUJ6QixpQkFDakJTLGdCQUFnQkMsSUFBSSxDQUFBakcsVUFBUyxFQUFFLEdBQUdBLE1BQU05QyxPQUFPLEdBQUcsRUFBRSxJQUNwRDhJO0FBRU43RSxtQkFBUzZGLGNBQWM7QUFDdkIzRix5QkFBZWlFLGlCQUFpQjtBQUVoQyxjQUFJQyxnQkFBZ0I7QUFDaEIzRCw0QkFBZ0IsRUFBRTtBQUNsQlYsd0JBQVksQ0FBQStGLFVBQVMsRUFBRSxHQUFHQSxNQUFNcEgsc0JBQXNCLE1BQU0sRUFBRTtBQUFBLFVBQ2xFLFdBQVcsQ0FBQzhFLGFBQWE5RSxzQkFBc0I7QUFDM0MrQiw0QkFBZ0IrQyxhQUFhL0UsZ0JBQWdCK0UsYUFBYXpILFNBQVMsRUFBRTtBQUFBLFVBQ3pFO0FBQUEsUUFFSixTQUFTZ0ssV0FBZ0I7QUFDckI1TixnQkFBTXdILE1BQU0sdUNBQXVDb0csVUFBVTNELFdBQVcsbUJBQW1CLEVBQUU7QUFBQSxRQUNqRyxVQUFDO0FBQ0d6Qiw4QkFBb0IsS0FBSztBQUFBLFFBQzdCO0FBQUEsTUFFSixXQUFXcEIsU0FBUyxVQUFVO0FBQzFCb0IsNEJBQW9CLEtBQUs7QUFBQSxNQUM3QjtBQUFBLElBQ0o7QUFDQTJDLGlCQUFhO0FBQUEsRUFDakIsR0FBRyxDQUFDL0QsTUFBTUMsVUFBVSxDQUFDO0FBR3JCMUgsWUFBVSxNQUFNO0FBQ1osVUFBTWtPLGVBQWVoRDtBQUVyQixRQUFJb0MsTUFBTVksWUFBWSxLQUFLQSxpQkFBaUIsRUFBRztBQUUvQ2hHLGFBQVMsQ0FBQWlHLGNBQWFBLFVBQVVuQixJQUFJLENBQUFqRyxTQUFRO0FBQ3hDLFlBQU1xSCxZQUFZbkgsT0FBUUYsS0FBYTdDLGdCQUFnQixLQUFLO0FBQzVELFlBQU1tSyxXQUFXcEgsT0FBUUYsS0FBYTVDLGVBQWUsS0FBSztBQUcxRCxVQUFJaUssY0FBYyxLQUFLQyxhQUFhLEVBQUcsUUFBT3RIO0FBRTlDLFlBQU11SCxVQUFnQztBQUFBLFFBQ2xDLEdBQUd2SDtBQUFBQTtBQUFBQSxRQUVIbEQsWUFBWVEsbUJBQW1CK0osWUFBWUYsWUFBWTtBQUFBLFFBQ3ZEcEssWUFBWU8sbUJBQW1CZ0ssV0FBV0gsWUFBWTtBQUFBLE1BQzFEO0FBR0EsVUFBSWxHLFNBQVNwQix3QkFBd0IsQ0FBQzZCLG1CQUFtQjtBQUNyRDZGLGdCQUFRckssUUFBUW1ILG1CQUFtQmtELFNBQVNuRyxXQUFXO0FBQUEsTUFDM0Q7QUFFQSxhQUFPbUc7QUFBQUEsSUFDWCxDQUFDLENBQUM7QUFBQSxFQUNOLEdBQUcsQ0FBQ3BELHVCQUF1Qi9DLGFBQWFILFNBQVNwQixzQkFBc0IyQixvQkFBb0JFLGlCQUFpQixDQUFDO0FBRzdHekksWUFBVSxNQUFNO0FBRVosUUFBSTRJLGlCQUFrQjtBQUV0QixRQUFJWixTQUFTMUMsV0FBVztBQUNwQnZFLGNBQWlCSyxxQkFBcUJvTCxVQUFVeEUsU0FBUzFDLFNBQVMsRUFDN0RpSixLQUFLLENBQUFoQyxlQUFjO0FBQ2hCLGNBQU1pQyxTQUFTOUwsZ0NBQWdDNkosVUFBVTtBQUN6RCxjQUFNa0MsaUJBQWlCak0sd0JBQXdCK0osWUFBWUEsV0FBV0ksWUFBWTtBQUNsRmpFLDZCQUFxQjhGLE1BQU07QUFDM0JsRyw4QkFBc0JpRSxXQUFXRSxRQUFRLElBQUk7QUFDN0NqRSw4QkFBc0IrRCxXQUFXRyxPQUFPLElBQUk7QUFDNUN0RSx1QkFBZXFHLGNBQWM7QUFDN0IsWUFBSUQsUUFBUTtBQUNSN0YsMEJBQWdCLEVBQUU7QUFDbEJWLHNCQUFZLENBQUErRixVQUFTO0FBQUEsWUFDakIsR0FBR0E7QUFBQUEsWUFDSHBILHNCQUFzQjtBQUFBLFlBQ3RCaEMsUUFBUTtBQUFBLFVBQ1osRUFBRTtBQUNGc0QsbUJBQVMsQ0FBQThGLFNBQVFBLEtBQUtoQixJQUFJLENBQUFqRyxVQUFTLEVBQUUsR0FBR0EsTUFBTTlDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUMvRCxXQUFXK0QsU0FBU3BCLHNCQUFzQjtBQUN0Q3NCLG1CQUFTLENBQUE4RixTQUFRQSxLQUFLaEIsSUFBSSxDQUFBakcsVUFBUztBQUFBLFlBQy9CLEdBQUdBO0FBQUFBLFlBQ0g5QyxPQUFPbUgsbUJBQW1CckUsTUFBTTBILGNBQWM7QUFBQSxVQUNsRCxFQUFFLENBQUM7QUFBQSxRQUNQO0FBQUEsTUFDSixDQUFDLEVBQ0FDLE1BQU0sTUFBTTtBQUNUck8sY0FBTXdILE1BQU0sa0RBQWtEO0FBQzlEYSw2QkFBcUIsS0FBSztBQUMxQkosOEJBQXNCLElBQUk7QUFDMUJFLDhCQUFzQixJQUFJO0FBQzFCSix1QkFBZSxFQUFFO0FBQUEsTUFDckIsQ0FBQztBQUFBLElBQ1QsT0FBTztBQUNITSwyQkFBcUIsS0FBSztBQUMxQkosNEJBQXNCLElBQUk7QUFDMUJFLDRCQUFzQixJQUFJO0FBQzFCSixxQkFBZSxFQUFFO0FBQ2pCTyxzQkFBZ0IsRUFBRTtBQUNsQixVQUFJWCxTQUFTcEIsc0JBQXNCO0FBQy9Cc0IsaUJBQVMsQ0FBQThGLFNBQVFBLEtBQUtoQixJQUFJLENBQUFqRyxVQUFTLEVBQUUsR0FBR0EsTUFBTTlDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUMvRDtBQUFBLElBQ0o7QUFBQSxFQUVKLEdBQUcsQ0FBQytELFNBQVMxQyxXQUFXMEMsU0FBU3BCLHNCQUFzQmdDLGdCQUFnQixDQUFDO0FBSXhFLFFBQU0rRixtQkFBbUIxTyxRQUFRLE1BQU07QUFDbkMsVUFBTTJPLFdBQVdsSSxNQUFNbUksT0FBTyxDQUFDQyxLQUFLL0gsU0FBVStILE1BQU83SCxPQUFPRixLQUFLcEQsWUFBWSxDQUFDLElBQUlzRCxPQUFPRixLQUFLbEQsY0FBYyxDQUFDLEdBQUssQ0FBQztBQUNuSCxVQUFNa0wscUJBQXFCckksTUFBTW1JLE9BQU8sQ0FBQ0MsS0FBSy9ILFNBQVMrSCxPQUFPN0gsT0FBT0YsS0FBS2hELGVBQWUsS0FBSyxJQUFJLENBQUM7QUFDbkcsVUFBTWlMLHVCQUF1Qi9ILE9BQU9lLFNBQVNqRSxlQUFlLEtBQUs7QUFDakUsVUFBTXVILFVBQVVzRCxXQUFXRyxxQkFBcUJDO0FBRWhELFFBQUlDLGFBQWE7QUFDakIsUUFBSSxDQUFDeEcsbUJBQW1CO0FBQ3BCLFVBQUlULFNBQVNwQixzQkFBc0I7QUFDL0JxSSxxQkFBYXZJLE1BQU1tSSxPQUFPLENBQUNDLEtBQUsvSCxTQUFTO0FBQ3JDLGdCQUFNbUksaUJBQWlCbkksS0FBSzlDLFNBQVMsSUFBSTRLLE9BQU8sQ0FBQ00sU0FBU3pDLFFBQVF5QyxVQUFVbEksT0FBT3lGLElBQUkwQyxNQUFNLEdBQUcsQ0FBQztBQUNqRyxpQkFBT04sTUFBTUk7QUFBQUEsUUFDakIsR0FBRyxDQUFDO0FBQUEsTUFDUixPQUFPO0FBQ0hELHFCQUFhdEksYUFBYWtJLE9BQU8sQ0FBQ0MsS0FBS3BDLFFBQVFvQyxPQUFPN0gsT0FBT3lGLElBQUkwQyxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDckY7QUFBQSxJQUNKO0FBQ0EsVUFBTUMsUUFBUTVHLG9CQUNSbEcsMkJBQTJCcU0sVUFBVUcsb0JBQW9CQyxvQkFBb0IsSUFDN0UxRCxVQUFVMkQ7QUFDaEIsV0FBTyxFQUFFTCxVQUFVRyxvQkFBb0JDLHNCQUFzQjFELFNBQVMyRCxZQUFZSSxNQUFNO0FBQUEsRUFDNUYsR0FBRyxDQUFDM0ksT0FBT3NCLFNBQVNqRSxpQkFBaUI0QyxjQUFjcUIsU0FBU3BCLHNCQUFzQjZCLGlCQUFpQixDQUFDO0FBSXBHekksWUFBVSxNQUFNO0FBRVosUUFBSTRJLGlCQUFrQjtBQUV0QixRQUFJSCxtQkFBbUI7QUFDbkJFLHNCQUFnQixFQUFFO0FBQ2xCO0FBQUEsSUFDSjtBQUVBLFFBQUlYLFNBQVNwQixzQkFBc0I7QUFDL0IrQixzQkFBZ0IsRUFBRTtBQUNsQjtBQUFBLElBQ0o7QUFDQSxRQUFJUixZQUFZa0QsU0FBUyxHQUFHO0FBQ3hCLFlBQU0sRUFBRUMsUUFBUSxJQUFJcUQ7QUFDcEJoRyxzQkFBZ0JyRyx5QkFBeUI7QUFBQSxRQUNyQ2lKLFNBQVNEO0FBQUFBLFFBQ1QvQztBQUFBQSxRQUNBdEUsT0FBT2tFO0FBQUFBLE1BQ1gsQ0FBQyxDQUFDO0FBQUEsSUFDTixPQUFPO0FBQ0hRLHNCQUFnQixFQUFFO0FBQUEsSUFDdEI7QUFBQSxFQUVKLEdBQUcsQ0FBQ2dHLGlCQUFpQnJELFNBQVNuRCxhQUFhSCxTQUFTcEIsc0JBQXNCMkIsb0JBQW9CSyxrQkFBa0JaLFNBQVMxQyxXQUFXbUQsaUJBQWlCLENBQUM7QUFNdEosUUFBTTZHLHFCQUFxQkEsQ0FBQ0MsTUFBcUY7QUFDN0csVUFBTUMsU0FBU0QsRUFBRUM7QUFDakIsVUFBTSxFQUFFcEksS0FBSyxJQUFJb0k7QUFFakIsUUFBSUM7QUFDSixRQUFJRCxrQkFBa0JFLG9CQUFvQkYsT0FBT0csU0FBUyxZQUFZO0FBQ2xFRixtQkFBYUQsT0FBT0k7QUFBQUEsSUFDeEIsT0FBTztBQUNILFlBQU0sRUFBRUMsTUFBTSxJQUFJTDtBQUNsQkMsbUJBQWFJO0FBQ2IsVUFBSXpJLFNBQVMsa0JBQW1CcUksY0FBYXhJLE9BQU80SSxLQUFLLEtBQUs7QUFDOUQsVUFBSXpJLFNBQVMsZ0JBQWlCcUksY0FBYXhJLE9BQU80SSxLQUFLLEtBQUs7QUFBQSxJQUNoRTtBQUVBNUgsZ0JBQVksQ0FBQStGLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUM1RyxJQUFJLEdBQUdxSSxXQUFXLEVBQUU7QUFBQSxFQUN6RDtBQUdBLFFBQU1LLHVCQUF1QixPQUFPQyxPQUFvQkMsaUJBQXNCO0FBQzFFLFVBQU1DLGtCQUFxRDtBQUFBLE1BQ3ZELFVBQVU3TztBQUFBQSxNQUNWLGVBQWVDO0FBQUFBLE1BQ2YsU0FBU0M7QUFBQUEsTUFDVCxZQUFZQztBQUFBQSxNQUNaLGFBQWFDO0FBQUFBLE1BQ2IsZUFBZUw7QUFBQUEsSUFDbkI7QUFDQSxVQUFNK08sZUFBZUQsZ0JBQWdCRixLQUFLO0FBQzFDLFFBQUksQ0FBQ0csZ0JBQWdCLENBQUNBLGFBQWF2RSxrQkFBa0I7QUFDakR0TCxZQUFNd0gsTUFBTSxtREFBbURrSSxLQUFLLEVBQUU7QUFDdEU7QUFBQSxJQUNKO0FBQ0EsVUFBTSxFQUFFbkUsV0FBV0UsVUFBVSxJQUFJb0UsYUFBYXZFO0FBRTlDLFFBQUlvRSxVQUFVLGVBQWU7QUFDekIxUCxZQUFNOFAsS0FBSyw4QkFBOEI7QUFDekNwSCwwQkFBb0IsSUFBSTtBQUN4QkYsMEJBQW9CLElBQUk7QUFDeEIsVUFBSTtBQUNBLGNBQU11SCxZQUFZLE1BQU1yUCxRQUFvQkksd0JBQXdCcUwsVUFBVXdELGFBQWEzTSxFQUFFO0FBRzdGLFlBQUlnSixvQkFBaUM7QUFDckMsWUFBSWdFLG9CQUFvQjtBQUN4QixZQUFJQywwQkFBeUM7QUFDN0MsWUFBSUMsdUJBQ0FILFVBQVVqSyxVQUFVO0FBQ3hCLFlBQUlpSyxVQUFVOUssV0FBVztBQUNyQixjQUFJO0FBQ0Esa0JBQU1hLFNBQVMsTUFBTXBGLFFBQWlCSyxxQkFBcUJvTCxVQUFVNEQsVUFBVTlLLFNBQVM7QUFDeEYrSyxnQ0FBb0IzTixnQ0FBZ0N5RCxNQUFNO0FBQzFEa0csZ0NBQW9CN0osd0JBQXdCMkQsUUFBUUEsT0FBT3dHLFlBQVk7QUFDdkUyRCxzQ0FBMEJuSyxPQUFPdUcsT0FBTztBQUN4Q2hFLGlDQUFxQjJILGlCQUFpQjtBQUN0Qy9ILGtDQUFzQm5DLE9BQU9zRyxRQUFRLElBQUk7QUFDekNqRSxrQ0FBc0I4SCx1QkFBdUI7QUFDN0NsSSwyQkFBZWlFLGlCQUFpQjtBQUNoQ2tFLG1DQUF1QnBLO0FBQUFBLFVBQzNCLFFBQVE7QUFBRTlGLGtCQUFNd0gsTUFBTSxrREFBa0Q7QUFBQSxVQUFHO0FBQUEsUUFDL0U7QUFFQSxjQUFNMkksc0JBQXNCN04sOEJBQThCNE4sc0JBQXNCLEdBQUc7QUFFbkYsWUFBSUgsVUFBVWpLLFFBQVF5RyxhQUFhO0FBQy9CbkMsNkJBQW1CMkYsVUFBVWpLLE9BQU95RyxXQUF1QjtBQUMzRCxnQkFBTUMsV0FBV3VELFVBQVVoTCxvQkFDcEIsQ0FBQ2dMLFVBQVVqSyxPQUFPeUcsWUFBWUUsU0FBU3NELFVBQVVoTCxnQkFBZ0I7QUFFeEV1Riw2QkFBbUIsQ0FBQyxDQUFDa0MsUUFBUTtBQUM3QmhDLGlDQUF1QnVGLFVBQVVoTCxvQkFBb0IsRUFBRTtBQUFBLFFBQzNELE9BQU87QUFDSHFGLDZCQUFtQixFQUFFO0FBQ3JCRSw2QkFBbUIsS0FBSztBQUN4QkUsaUNBQXVCdUYsVUFBVWhMLG9CQUFvQixFQUFFO0FBQUEsUUFDM0Q7QUFFQTZGLGtDQUEwQixDQUFDLENBQUNtRixVQUFVSyxzQkFBc0I7QUFFNUQsY0FBTUMsbUJBQ0ZqSixTQUFTLFVBQVVwRSxLQUFLNEQsT0FBTzVELEVBQUUsSUFBSStDO0FBQ3pDLFlBQUl1Syx1QkFBdUIsb0JBQUlDLElBQW9CO0FBQ25ELFlBQUk7QUFDQSxnQkFBTXhELGFBQWEsTUFBTXBNLGlDQUFpQ29QLFVBQVUvTSxJQUFJO0FBQUEsWUFDcEVnSyx1QkFDSXFELG9CQUFvQixRQUFRLENBQUN6SixPQUFPcUcsTUFBTW9ELGdCQUFnQixJQUNwREEsbUJBQ0F0SztBQUFBQSxVQUNkLENBQUM7QUFDRHVLLGlDQUF1QixJQUFJQztBQUFBQSxZQUN2QnhELFdBQVcxRyxNQUFNc0csSUFBSSxDQUFDWSxNQUFNLENBQUNBLEVBQUVILHFCQUFxQkcsRUFBRUUsZ0JBQWdCLENBQUM7QUFBQSxVQUMzRTtBQUNBLGNBQUk2QyxxQkFBcUJFLFNBQVMsR0FBRztBQUNqQ3hRLGtCQUFNeVEsS0FBSyxxREFBcUQ7QUFBQSxVQUNwRTtBQUFBLFFBQ0osUUFBUTtBQUNKelEsZ0JBQU15UTtBQUFBQSxZQUNGO0FBQUEsVUFDSjtBQUNBVixvQkFBVTFKLE1BQU1xSyxRQUFRLENBQUNoSyxTQUFvQjtBQUN6QzRKLGlDQUFxQkssSUFBSS9KLE9BQU9GLEtBQUsxRCxFQUFFLEdBQUc0RCxPQUFPRixLQUFLcEQsUUFBUSxDQUFDO0FBQUEsVUFDbkUsQ0FBQztBQUFBLFFBQ0w7QUFFQSxjQUFNc04sV0FBV2IsVUFBVTFKLE1BQ3RCd0ssT0FBTyxDQUFDbkssU0FBb0I0SixxQkFBcUJRLElBQUlsSyxPQUFPRixLQUFLMUQsRUFBRSxDQUFDLENBQUMsRUFDckUySixJQUFJLENBQUNqRyxTQUEwQztBQUM1QyxnQkFBTXFLLGFBQWFuSyxPQUFPMEoscUJBQXFCVSxJQUFJcEssT0FBT0YsS0FBSzFELEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDeEUsZ0JBQU1pTyxjQUFvQztBQUFBLFlBQ3RDLEdBQUdsTztBQUFBQSxZQUNIRSxRQUFRMkosT0FBT0MsV0FBVztBQUFBLFlBQzFCTyxxQkFBcUJ4RyxPQUFPRixLQUFLMUQsRUFBRTtBQUFBLFlBQ25DRyxZQUFZdUQsS0FBS3ZEO0FBQUFBLFlBQ2pCQyxjQUFjc0QsS0FBS3REO0FBQUFBLFlBQ25CQyxjQUFjcUQsS0FBS3JEO0FBQUFBLFlBQ25CQyxVQUFVeU47QUFBQUEsWUFDVnhOLGtCQUFrQndOO0FBQUFBLFlBQ2xCdk4sWUFBWWtELEtBQUtsRDtBQUFBQSxZQUNqQkMsWUFBWW1ELE9BQU9GLEtBQUtqRCxVQUFVLEtBQUs7QUFBQSxZQUN2Q0MsaUJBQWlCZ0QsS0FBS2hEO0FBQUFBLFlBQ3RCQyx1QkFBd0IrQyxLQUFhL0MseUJBQXlCO0FBQUEsWUFDOURULGFBQWF3RCxLQUFLeEQ7QUFBQUEsWUFDbEJVLE9BQU87QUFBQSxZQUNQRSxpQkFBaUI0QyxLQUFLNUM7QUFBQUEsWUFDdEJELGtCQUFrQitDLE9BQU9GLEtBQUs3QyxnQkFBZ0IsS0FBSztBQUFBLFlBQ25ERSxnQkFBZ0IyQyxLQUFLM0M7QUFBQUEsVUFDekI7QUFFQSxjQUFJZ00sVUFBVXhKLHdCQUF3QixDQUFDeUosbUJBQW1CO0FBQ3RELGtCQUFNa0IsVUFBV3RLLE9BQU9xSyxZQUFZM04sUUFBUSxJQUFJc0QsT0FBT3FLLFlBQVl6TixVQUFVLEtBQ3RFb0QsT0FBT3FLLFlBQVl2TixlQUFlLEtBQUs7QUFDOUN1Tix3QkFBWXJOLFFBQVEzQix5QkFBeUI7QUFBQSxjQUN6Q2lKLFNBQVNnRztBQUFBQSxjQUNUaEosb0JBQW9CK0g7QUFBQUEsY0FDcEJyTSxPQUFPb0k7QUFBQUEsWUFDWCxDQUFDO0FBQUEsVUFDTDtBQUNBLGlCQUFPaUY7QUFBQUEsUUFDWCxDQUFDO0FBQ0xwSixpQkFBUytJLFFBQVE7QUFHakJoSixvQkFBWSxDQUFBK0YsVUFBUztBQUFBLFVBQ2pCLEdBQUdBO0FBQUFBLFVBQ0hwSixRQUFRNEw7QUFBQUEsVUFDUjNMLGVBQWMsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUE7QUFBQTtBQUFBLFVBR25EVyxnQkFBZ0J5SyxVQUFVL007QUFBQUEsVUFDMUI0QyxvQkFBb0JtSyxVQUFVakU7QUFBQUEsVUFDOUJqRyxrQkFDSWtLLFVBQVVqRSxnQkFBZ0IsUUFBUWlFLFVBQVVqRSxpQkFBaUIsS0FDdkRDLE9BQU9nRSxVQUFVakUsWUFBWSxJQUM3QjtBQUFBLFVBQ1ZxRixrQkFBa0JwQixVQUFVakssUUFBUWlCO0FBQUFBLFVBQ3BDcUssdUJBQXVCckIsVUFBVXFCO0FBQUFBLFVBQ2pDeE0sZUFBZW1MLFVBQVVuTDtBQUFBQSxVQUN6QkUsT0FBT2lMLFVBQVVqTDtBQUFBQSxVQUNqQnBCLGlCQUFpQnFNLFVBQVVyTSxtQkFBbUI7QUFBQSxVQUM5Q3NCLGVBQWUrSyxVQUFVL0ssaUJBQWlCO0FBQUEsVUFDMUN1QixzQkFBc0J5SixvQkFBb0IsUUFBUUQsVUFBVXhKO0FBQUFBO0FBQUFBLFVBRzVEdEIsV0FBVzhLLFVBQVU5SztBQUFBQSxVQUNyQk0sYUFBYXdLLFVBQVVqSyxTQUFTL0UscUJBQXFCdUssaUJBQWtCQyxTQUEwQixLQUFlO0FBQUEsVUFDaEhDLGFBQWF1RSxVQUFVakssU0FBUy9FLHFCQUFxQnVLLGlCQUFrQkcsU0FBMEIsS0FBZTtBQUFBLFVBQ2hIMUcsa0JBQWtCZ0wsVUFBVWhMLG9CQUFxQmdMLFVBQVVqSyxRQUFRdUwsV0FBVztBQUFBLFVBRTlFbk0sZ0JBQWdCNkssVUFBVTdLO0FBQUFBLFVBQzFCTSxrQkFBa0J1SyxVQUFVL0osY0FBY2hGLHVCQUF1QnNLLGlCQUFrQkMsU0FBMkIsS0FBZTtBQUFBLFVBQzdIRyxrQkFBa0JxRSxVQUFVL0osY0FBY2hGLHVCQUF1QnNLLGlCQUFrQkcsU0FBMkIsS0FBZTtBQUFBLFVBRTdIdEcsVUFBVTRLLFVBQVU1SztBQUFBQSxVQUNwQk0sWUFBWXNLLFVBQVU5SixRQUFRaEYsd0JBQXdCcUssaUJBQWtCQyxTQUE0QixLQUFlO0FBQUEsVUFDbkhJLFlBQVlvRSxVQUFVOUosUUFBUWhGLHdCQUF3QnFLLGlCQUFrQkcsU0FBNEIsS0FBZTtBQUFBLFVBRW5IckcsYUFBYTJLLFVBQVUzSztBQUFBQSxVQUN2Qk0sZUFBZXFLLFVBQVU3SixXQUFXaEYsb0JBQW9Cb0ssaUJBQWtCQyxTQUF5QixLQUFlO0FBQUEsVUFDbEhLLGVBQWVtRSxVQUFVN0osV0FBV2hGLG9CQUFvQm9LLGlCQUFrQkcsU0FBeUIsS0FBZTtBQUFBLFVBRWxIcEcsY0FBYzBLLFVBQVUxSztBQUFBQSxVQUN4Qk0sZ0JBQWdCb0ssVUFBVTVKLFlBQVloRix3QkFBd0JtSyxpQkFBa0JDLFNBQTZCLEtBQWU7QUFBQSxVQUM1SE0sZ0JBQWdCa0UsVUFBVTVKLFlBQVloRix3QkFBd0JtSyxpQkFBa0JHLFNBQTZCLEtBQWU7QUFBQSxRQUNoSSxFQUFFO0FBR0YsWUFBSXVFLG1CQUFtQjtBQUNuQjFILDBCQUFnQixFQUFFO0FBQUEsUUFDdEIsV0FBVyxDQUFDeUgsVUFBVXhKLHNCQUFzQjtBQUN4QyxnQkFBTWdJLFdBQVdxQyxTQUFTcEMsT0FBTyxDQUFDQyxLQUFLNkMsTUFBTTdDLE1BQU83SCxPQUFPMEssRUFBRWhPLFFBQVEsSUFBSXNELE9BQU8wSyxFQUFFOU4sVUFBVSxHQUFJLENBQUM7QUFDakcsZ0JBQU0rTixlQUFlWCxTQUFTcEMsT0FBTyxDQUFDQyxLQUFLNkMsTUFBTTdDLE1BQU03SCxPQUFPMEssRUFBRTVOLGVBQWUsR0FBRyxDQUFDO0FBQ25GLGdCQUFNOE4saUJBQWlCNUssT0FBT21KLFVBQVVyTSxtQkFBbUIsQ0FBQztBQUM1RCxnQkFBTXVILFVBQVVzRCxXQUFXZ0QsZUFBZUM7QUFFMUNsSiwwQkFBZ0JyRyx5QkFBeUI7QUFBQSxZQUNyQ2lKLFNBQVNEO0FBQUFBLFlBQ1QvQyxvQkFBb0IrSDtBQUFBQSxZQUNwQnJNLE9BQU9vSTtBQUFBQSxVQUNYLENBQUMsQ0FBQztBQUFBLFFBQ04sT0FBTztBQUNIMUQsMEJBQWdCLEVBQUU7QUFBQSxRQUN0QjtBQUFBLE1BRUosU0FBU3NGLFdBQWdCO0FBQ3JCNU4sY0FBTXdILE1BQU0sK0NBQStDb0csVUFBVTNELE9BQU8sRUFBRTtBQUFBLE1BQ2xGLFVBQUM7QUFDR3pCLDRCQUFvQixLQUFLO0FBQ3pCRSw0QkFBb0IsS0FBSztBQUFBLE1BQzdCO0FBQUEsSUFHSixPQUFPO0FBQ0hrQyxnQ0FBMEIsS0FBSztBQUMvQixVQUFJNkcsZUFBZTlCO0FBQ25CLFVBQUlELFVBQVUsWUFBWUMsY0FBYzNNLElBQUk7QUFDeEMsY0FBTTBPLFdBQVcvQixhQUFhZ0M7QUFDOUIsWUFBSUQsWUFBWSxRQUFRM0YsT0FBTzJGLFFBQVEsRUFBRUUsS0FBSyxNQUFNLElBQUk7QUFDcEQsY0FBSTtBQUNBSCwyQkFBZSxNQUFNL1EsUUFBaUJLLHFCQUFxQm9MLFVBQVV3RCxhQUFhM00sRUFBRTtBQUFBLFVBQ3hGLFFBQVE7QUFDSnlPLDJCQUFlOUI7QUFBQUEsVUFDbkI7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUNBL0gsa0JBQVksQ0FBQStGLFNBQVE7QUFDaEIsY0FBTWtFLGNBQWMsRUFBRSxHQUFHbEUsS0FBSztBQUM5QixZQUFJOEQsY0FBYztBQUNkSSxzQkFBWSxHQUFHbkMsS0FBSyxLQUFLLElBQUkrQixhQUFhek87QUFDMUM2TyxzQkFBWSxHQUFHbkMsS0FBSyxPQUFPLElBQUkrQixhQUFhbEcsU0FBbUI7QUFDL0RzRyxzQkFBWSxHQUFHbkMsS0FBSyxPQUFPLElBQUkrQixhQUFhaEcsU0FBbUI7QUFJL0QsY0FBSWlFLFVBQVUsVUFBVTtBQUNwQixrQkFBTW9DLFlBQVlMLGFBQWFsRixlQUFlO0FBQzlDbkMsK0JBQW1CMEgsU0FBUztBQUM1QnhILCtCQUFtQixLQUFLO0FBQ3hCckMsa0NBQXNCd0osYUFBYXJGLFFBQVEsSUFBSTtBQUUvQ3lGLHdCQUFZdE4sU0FBU2pDLDhCQUE4Qm1QLGNBQWM5RCxLQUFLcEosVUFBVSxHQUFHO0FBR25GLGdCQUFJdU4sVUFBVTlHLFNBQVMsR0FBRztBQUN0QlIscUNBQXVCc0gsVUFBVSxDQUFDLENBQUM7QUFDbkNELDBCQUFZOU0sbUJBQW1CK00sVUFBVSxDQUFDO0FBQUEsWUFDOUMsT0FBTztBQUNIdEgscUNBQXVCLEVBQUU7QUFDekJxSCwwQkFBWTlNLG1CQUFtQjtBQUFBLFlBQ25DO0FBQ0EsZ0JBQUkwTSxhQUFhTSxVQUFVO0FBQ3ZCRiwwQkFBWTNNLGlCQUFpQnVNLGFBQWFNO0FBQzFDRiwwQkFBWXJNLG1CQUFtQmlNLGFBQWFPLGtCQUFrQmhMLFFBQVE7QUFDdEU2SywwQkFBWW5HLG1CQUFtQitGLGFBQWFPLGtCQUFrQmpMLFFBQVE7QUFBQSxZQUMxRTtBQUNBLGdCQUFJMEssYUFBYXBNLGNBQWM7QUFDM0J3TSwwQkFBWXhNLGVBQWVvTSxhQUFhcE07QUFDeEN3TSwwQkFBWWxNLGlCQUFrQjhMLGFBQWF0TCxXQUFtQmEsUUFBUTtBQUN0RTZLLDBCQUFZaEcsaUJBQWtCNEYsYUFBYXRMLFdBQW1CWSxRQUFRO0FBQUEsWUFDMUU7QUFDQSxnQkFBSTBLLGFBQWFyTSxhQUFhO0FBQzFCeU0sMEJBQVl6TSxjQUFjcU0sYUFBYXJNO0FBQ3ZDeU0sMEJBQVluTSxnQkFBaUIrTCxhQUFhdkwsVUFBa0JjLFFBQVE7QUFDcEU2SywwQkFBWWpHLGdCQUFpQjZGLGFBQWF2TCxVQUFrQmEsUUFBUTtBQUNwRThLLDBCQUFZN00sZ0JBQWdCeU0sYUFBYXZMLFVBQVVsQixpQkFBaUI7QUFDcEUsa0JBQUk2TSxZQUFZbk0sa0JBQWtCO0FBQzlCZ0YsaUNBQWlCLEtBQUs7QUFBQTtBQUV0QkEsaUNBQWlCLEdBQUc7QUFBQSxZQUM1QjtBQUNBLGdCQUFJK0csYUFBYXRNLFVBQVU7QUFDdkIwTSwwQkFBWTFNLFdBQVdzTSxhQUFhdE07QUFDcEMwTSwwQkFBWXBNLGFBQWNnTSxhQUFheEwsT0FBZWUsUUFBUTtBQUM5RDZLLDBCQUFZbEcsYUFBYzhGLGFBQWF4TCxPQUFlYyxRQUFRO0FBQUEsWUFDbEU7QUFBQSxVQUNKLFdBQVcySSxVQUFVLFlBQVk7QUFDN0JtQyx3QkFBWTdNLGdCQUFnQnlNLGFBQWF6TSxpQkFBaUI7QUFDMUQsZ0JBQUk2TSxZQUFZbk0sa0JBQWtCO0FBQzlCZ0YsK0JBQWlCLEtBQUs7QUFBQTtBQUV0QkEsK0JBQWlCLEdBQUc7QUFBQSxVQUM1QjtBQUFBLFFBQ0o7QUFDQSxlQUFPbUg7QUFBQUEsTUFDWCxDQUFDO0FBQUEsSUFDTDtBQUVBLFFBQUluQyxVQUFVLFNBQVVwSCxpQkFBZ0IsRUFBRTtBQUFBLEVBQzlDO0FBR0EsUUFBTTJKLGtCQUFrQkEsQ0FBQzlDLFFBQXVCK0MsUUFBMkJDLFlBQTJCLFNBQVM7QUFDM0csUUFBSWhKLGVBQXFFK0k7QUFFekUsUUFBSS9DLFdBQVcsZUFBZTtBQUMxQixVQUFJLENBQUN4SCxTQUFTMUMsV0FBVztBQUNyQmpGLGNBQU04UCxLQUFLLHlEQUF5RDtBQUFBLE1BQ3hFO0FBQ0EzRyxxQkFBYztBQUFBLFFBQ1YsR0FBRytJO0FBQUFBLFFBQ0hFLGdCQUFnQixFQUFFbk4sV0FBVzBDLFNBQVMxQyxhQUFhYyxRQUFXekIsUUFBUSxJQUFJO0FBQUE7QUFBQSxNQUM5RTtBQUFBLElBQ0osV0FBVzZLLFdBQVcsUUFBUTtBQUMxQmhHLHFCQUFjO0FBQUEsUUFDVixHQUFHK0k7QUFBQUEsUUFDSEUsZ0JBQWdCL1E7QUFBQUEsTUFDcEI7QUFDQWlJLDBCQUFvQjZJLFNBQVM7QUFBQSxJQUNqQztBQUVBakoscUJBQWlCaUcsTUFBTTtBQUN2Qi9GLG1CQUFlRCxZQUFXO0FBQzFCSCxtQkFBZSxJQUFJO0FBQUEsRUFDdkI7QUFHQSxRQUFNcUosb0JBQW9CLE9BQU8xQyxpQkFBc0I7QUFDbkQsUUFBSSxDQUFDMUcsY0FBZTtBQUdwQixRQUFJQSxrQkFBa0IsVUFBVUkscUJBQXFCLE1BQU07QUFFdkQsWUFBTWlKLFdBQVczQyxhQUFhNEMsTUFBTXhHLE9BQU80RCxhQUFhNEMsR0FBRyxJQUFJO0FBQy9ELFlBQU1DLFVBQVUsTUFBTTVSO0FBQUFBLFFBQW1CO0FBQUEsUUFDckM7QUFBQSxVQUFDLEVBQUU2UixXQUFXLE9BQWlCakQsT0FBTzhDLFNBQVM7QUFBQSxVQUMvQyxFQUFFRyxXQUFXLGFBQWFqRCxPQUFPN0gsU0FBUzFDLFdBQVd5TixTQUFTLEtBQUssR0FBRztBQUFBLFFBQUM7QUFBQSxNQUN0RTtBQUVMN0ssZUFBUyxDQUFBaUcsY0FBYTtBQUNsQixjQUFNOEMsV0FBVyxDQUFDLEdBQUc5QyxTQUFTO0FBQzlCLGNBQU1wSCxPQUFPa0ssU0FBU3ZILGdCQUFnQjtBQUN0QyxjQUFNLEVBQUVrQyxXQUFXRSxVQUFVLElBQUlySyxzQkFBc0JrSztBQUN2RCxjQUFNdUMsZUFBZWhEO0FBR3JCLGNBQU1rRCxZQUFZeUUsUUFBUUcsbUJBQW1CaEQsYUFBYWlELGNBQWM7QUFDeEUsY0FBTTVFLFdBQVdoTTtBQUFBQSxVQUNid1EsUUFBUS9PLGNBQWNrTSxhQUFhbE0sY0FBYztBQUFBLFVBQ2pEK08sUUFBUUs7QUFBQUEsVUFDUmxMLFNBQVMzQztBQUFBQSxRQUNiO0FBRUEwQixhQUFLdkQsYUFBYXdNLGFBQWEzTTtBQUMvQjBELGFBQUt0RCxlQUFldU0sYUFBYXBFLFNBQW1CO0FBQ3BEN0UsYUFBS3JELGVBQWVzTSxhQUFhbEUsU0FBbUI7QUFDcEQvRSxhQUFLbEQsYUFBYW1NLGFBQWFpRCxjQUFjO0FBQzdDbE0sYUFBS2pELGFBQWFrTSxhQUFhbE0sY0FBYztBQUM3Q2lELGFBQUszQyxpQkFBaUJ5TyxRQUFRek8sa0JBQWtCO0FBQ2hEMkMsYUFBSzdDLG1CQUFtQmtLO0FBQ3hCckgsYUFBSzVDLGtCQUFrQmtLO0FBSXZCLFFBQUN0SCxLQUFhN0MsbUJBQW1Ca0s7QUFDakMsUUFBQ3JILEtBQWE1QyxrQkFBa0JrSztBQUdoQ3RILGFBQUtsRCxhQUFhUSxtQkFBbUIrSixZQUFZRixZQUFZO0FBQzdEbkgsYUFBS2pELGFBQWFPLG1CQUFtQmdLLFdBQVdILFlBQVk7QUFFNUQsWUFBSWxHLFNBQVNwQix3QkFBd0IsQ0FBQzZCLG1CQUFtQjtBQUNyRDFCLGVBQUs5QyxRQUFRbUgsbUJBQW1CckUsTUFBTW9CLFdBQVc7QUFBQSxRQUNyRCxPQUFPO0FBQ0hwQixlQUFLOUMsUUFBUTtBQUFBLFFBQ2pCO0FBRUFnTixpQkFBU3ZILGdCQUFnQixJQUFJM0M7QUFDN0IsZUFBT2tLO0FBQUFBLE1BQ1gsQ0FBQztBQUNEdEgsMEJBQW9CLElBQUk7QUFBQSxJQUc1QixXQUFXLE9BQU9MLGtCQUFrQixZQUFZQSxrQkFBa0IsUUFBUTtBQUN0RXdHLDJCQUFxQnhHLGVBQThCMEcsWUFBWTtBQUFBLElBQ25FO0FBQ0EzRyxtQkFBZSxLQUFLO0FBQUEsRUFDeEI7QUFFQSxRQUFNOEosOEJBQThCQSxDQUFDNUQsTUFBa0U7QUFDbkcsVUFBTU0sUUFBUU4sRUFBRUMsT0FBT0s7QUFDdkIsUUFBSUEsVUFBVSxzQkFBc0I7QUFDaENsRix5QkFBbUIsSUFBSTtBQUN2QkUsNkJBQXVCLEVBQUU7QUFBQSxJQUM3QixPQUFPO0FBQ0hGLHlCQUFtQixLQUFLO0FBQ3hCRSw2QkFBdUJnRixLQUFLO0FBQUEsSUFDaEM7QUFBQSxFQUNKO0FBR0EsUUFBTXVELG1CQUFtQkEsQ0FBQ0MsT0FBZTlELE1BQTJDO0FBQ2hGLFVBQU0sRUFBRW5JLE1BQU15SSxNQUFNLElBQUlOLEVBQUVDO0FBQzFCLFVBQU10QixlQUFlaEQ7QUFDckIsVUFBTW9JLFlBQVksQ0FBQyxZQUFZLGNBQWMsbUJBQW1CLHVCQUF1QjtBQUN2RixRQUFJQyxjQUErQkQsVUFBVXhHLFNBQVMxRixJQUFJLElBQUt5SSxVQUFVLEtBQUssSUFBSTVJLE9BQU80SSxLQUFLLEtBQUssSUFBS0E7QUFFeEczSCxhQUFTLENBQUFpRyxjQUFhO0FBQ2xCLFlBQU04QyxXQUFXLENBQUMsR0FBRzlDLFNBQVM7QUFDOUIsWUFBTXFGLFVBQVV2QyxTQUFTb0MsS0FBSztBQUU5QixVQUFJak0sU0FBUyxZQUFZO0FBQ3JCLFlBQUlKLElBQUlDLE9BQU9zTSxXQUFXLEtBQUs7QUFDL0IsWUFBSXZNLElBQUksRUFBR0EsS0FBSTtBQUNmLGNBQU15TSxhQUFheE0sT0FBT3VNLFFBQVE1UCxnQkFBZ0IsS0FBSztBQUN2RCxZQUFJNlAsYUFBYSxLQUFLek0sSUFBSXlNLFlBQVk7QUFDbENwVCxnQkFBTXlRO0FBQUFBLFlBQ0Ysc0NBQXNDMEMsUUFBUTlQLGdCQUFnQixXQUFXLE9BQU8rUCxVQUFVO0FBQUEsVUFDOUY7QUFDQXpNLGNBQUl5TTtBQUFBQSxRQUNSO0FBQ0FGLHNCQUFjdk07QUFBQUEsTUFDbEI7QUFFQSxZQUFNRCxPQUFPLEVBQUUsR0FBR3lNLFNBQVMsQ0FBQ3BNLElBQUksR0FBR21NLFlBQVk7QUFFL0MsVUFBSW5NLFNBQVMsY0FBYztBQUN2QixjQUFNc00sV0FBV3pNLE9BQU9zTSxXQUFXLEtBQUs7QUFFeEMsUUFBQ3hNLEtBQWE3QyxtQkFBbUJ3UCxXQUFXeEY7QUFHNUMsY0FBTUcsV0FBV3BILE9BQVFGLEtBQWE1QyxlQUFlLEtBQUs7QUFDMUQ0QyxhQUFLakQsYUFBYU8sbUJBQW1CZ0ssV0FBV0gsWUFBWTtBQUFBLE1BQ2hFO0FBRUEsVUFBSWxHLFNBQVNwQix3QkFBd0IsQ0FBQzZCLHNCQUFzQnJCLFNBQVMsY0FBY0EsU0FBUyxnQkFBZ0JBLFNBQVMsb0JBQW9CO0FBQ3JJTCxhQUFLOUMsUUFBUW1ILG1CQUFtQnJFLE1BQU1vQixXQUFXO0FBQUEsTUFDckQsV0FBV2YsU0FBUyxjQUFjQSxTQUFTLGdCQUFnQkEsU0FBUyxtQkFBbUI7QUFDbkZMLGFBQUs5QyxRQUFRO0FBQUEsTUFDakI7QUFFQWdOLGVBQVNvQyxLQUFLLElBQUl0TTtBQUNsQixhQUFPa0s7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU0wQyw0QkFBNEJBLENBQUNOLE9BQWVqTSxNQUFjeUksVUFBa0I7QUFDOUV1RCxxQkFBaUJDLE9BQU8sRUFBRTdELFFBQVEsRUFBRXBJLE1BQU15SSxPQUFPekQsT0FBT3lELEtBQUssRUFBRSxFQUFFLENBQXdDO0FBQUEsRUFDN0c7QUFHQSxRQUFNK0QsdUJBQXVCLE9BQU9QLFVBQWtCO0FBQ2xELFVBQU10TSxPQUFPTCxNQUFNMk0sS0FBSztBQUN4QixRQUFJLENBQUN0TSxLQUFLdEQsYUFBYztBQUN4QixVQUFNLEVBQUVtSSxXQUFXRSxVQUFVLElBQUlySyxzQkFBc0JrSztBQUN2RCxVQUFNdUMsZUFBZWhEO0FBRXJCLFFBQUk7QUFFQSxZQUFNMkgsVUFBVSxNQUFNNVI7QUFBQUEsUUFBbUI7QUFBQSxRQUNyQztBQUFBLFVBQUMsRUFBRTZSLFdBQVdsSCxXQUFxQmlFLE9BQU85SSxLQUFLdEQsYUFBYTtBQUFBLFVBQzVELEVBQUVxUCxXQUFXLGFBQWFqRCxPQUFPN0gsU0FBUzFDLFdBQVd5TixTQUFTLEtBQUssR0FBRztBQUFBLFFBQUM7QUFBQSxNQUN0RTtBQUNMLFVBQUlGLFNBQVM7QUFDVDNLLGlCQUFTLENBQUFpRyxjQUFhO0FBQ2xCLGdCQUFNOEMsV0FBVyxDQUFDLEdBQUc5QyxTQUFTO0FBQzlCLGdCQUFNQyxZQUFZeUUsUUFBUUcsbUJBQW1CSCxRQUFRSSxjQUFjO0FBQ25FLGdCQUFNNUUsV0FBV2hNO0FBQUFBLFlBQ2J3USxRQUFRL08sY0FBYztBQUFBLFlBQ3RCK08sUUFBUUs7QUFBQUEsWUFDUmxMLFNBQVMzQztBQUFBQSxVQUNiO0FBQ0EsZ0JBQU13TyxlQUFlNU0sT0FBT2dLLFNBQVNvQyxLQUFLLEVBQUV4UCxVQUFVLEtBQUs7QUFDM0QsZ0JBQU1pUSxjQUFjN00sT0FBT2dLLFNBQVNvQyxLQUFLLEVBQUV2UCxVQUFVLEtBQUs7QUFDMUQsZ0JBQU1pUSxrQkFBa0IxUCxtQkFBbUIrSixZQUFZRixZQUFZO0FBQ25FLGdCQUFNOEYsaUJBQWlCM1AsbUJBQW1CZ0ssV0FBV0gsWUFBWTtBQUVqRSxnQkFBTStGLGNBQWM7QUFBQSxZQUNoQixHQUFHaEQsU0FBU29DLEtBQUs7QUFBQSxZQUNqQjdQLFlBQVlxUCxRQUFReFA7QUFBQUEsWUFDcEJJLGNBQWNvUCxRQUFRakgsU0FBbUI7QUFBQSxZQUN6Q2xJLGNBQWNtUCxRQUFRL0csU0FBbUI7QUFBQSxZQUV6QzVILGtCQUFrQmtLO0FBQUFBLFlBQ2xCakssaUJBQWlCa0s7QUFBQUEsWUFDakJqSyxnQkFBZ0J5TyxRQUFRek87QUFBQUEsWUFDeEJSLGtCQUFrQjtBQUFBLFlBQ2xCNkoscUJBQXFCckg7QUFBQUEsWUFFckJ2QyxZQUFZZ1EsZUFBZSxJQUFJQSxlQUFlRTtBQUFBQSxZQUM5Q2pRLFlBQVlnUSxjQUFjLElBQUlBLGNBQWNFO0FBQUFBLFVBQ2hEO0FBQ0EsY0FBSWhNLFNBQVNwQix3QkFBd0IsQ0FBQzZCLG1CQUFtQjtBQUNyRHdMLHdCQUFZaFEsUUFBUW1ILG1CQUFtQjZJLGFBQWE5TCxXQUFXO0FBQUEsVUFDbkU7QUFDQThJLG1CQUFTb0MsS0FBSyxJQUFJWTtBQUNsQixpQkFBT2hEO0FBQUFBLFFBQ1gsQ0FBQztBQUNENVEsY0FBTTZULFFBQVEsSUFBSXJCLFFBQVEvRyxTQUFtQixDQUFDLGlCQUFpQjtBQUFBLE1BQ25FLE9BQU87QUFDSHpMLGNBQU13SCxNQUFNLGlEQUFpRGQsS0FBS3RELFlBQVksSUFBSTtBQUFBLE1BQ3RGO0FBQUEsSUFDSixTQUFTMFEsS0FBSztBQUFFOVQsWUFBTXdILE1BQU0sc0NBQXNDO0FBQUEsSUFBRztBQUFBLEVBQ3pFO0FBRUEsUUFBTXVNLHVCQUF1QkEsQ0FBQ2YsT0FBZWdCLFlBQW9CO0FBQzdEbk0sYUFBUyxDQUFBaUcsY0FBYTtBQUNsQixZQUFNOEMsV0FBVyxDQUFDLEdBQUc5QyxTQUFTO0FBQzlCLFlBQU1wSCxPQUFPLEVBQUUsR0FBR2tLLFNBQVNvQyxLQUFLLEVBQUU7QUFDbEN0TSxXQUFLdEQsZUFBZTRRO0FBQ3BCdE4sV0FBS3ZELGFBQWE7QUFBR3VELFdBQUtyRCxlQUFlO0FBQ3pDcUQsV0FBS2xELGFBQWE7QUFBR2tELFdBQUszQyxpQkFBaUI7QUFBRzJDLFdBQUs5QyxRQUFRO0FBQzNEOEMsV0FBS25ELG1CQUFtQjtBQUN4Qm1ELFdBQUswRyxzQkFBc0JySDtBQUMzQjZLLGVBQVNvQyxLQUFLLElBQUl0TTtBQUNsQixhQUFPa0s7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUdBLFFBQU1xRCwrQkFBK0IsT0FBT2pCLE9BQWVSLFlBQWlCO0FBQ3hFLFVBQU0sRUFBRWpILFdBQVdFLFVBQVUsSUFBSXJLLHNCQUFzQmtLO0FBQ3ZELFVBQU11QyxlQUFlaEQ7QUFHckIsUUFBSTtBQUNBLFlBQU15SCxXQUFXRSxRQUFRRCxNQUFNeEcsT0FBT3lHLFFBQVFELEdBQUcsSUFBSTtBQUNyRCxZQUFNMkIsY0FBYyxNQUFNdFQ7QUFBQUEsUUFBbUI7QUFBQSxRQUN6QztBQUFBLFVBQUMsRUFBRTZSLFdBQVcsT0FBaUJqRCxPQUFPOEMsU0FBUztBQUFBLFVBQy9DLEVBQUVHLFdBQVcsYUFBYWpELE9BQU83SCxTQUFTMUMsV0FBV3lOLFNBQVMsS0FBSyxHQUFHO0FBQUEsUUFBQztBQUFBLE1BQ3RFO0FBRUwsVUFBSXdCLGFBQWE7QUFDYnJNLGlCQUFTLENBQUFpRyxjQUFhO0FBQ2xCLGdCQUFNOEMsV0FBVyxDQUFDLEdBQUc5QyxTQUFTO0FBQzlCLGdCQUFNcEgsT0FBT2tLLFNBQVNvQyxLQUFLO0FBQzNCLGdCQUFNakYsWUFBWW1HLFlBQVl2QixtQkFBbUJ1QixZQUFZdEIsY0FBYztBQUMzRSxnQkFBTTVFLFdBQVdoTTtBQUFBQSxZQUNia1MsWUFBWXpRLGNBQWM7QUFBQSxZQUMxQnlRLFlBQVlyQjtBQUFBQSxZQUNabEwsU0FBUzNDO0FBQUFBLFVBQ2I7QUFDQSxnQkFBTXdPLGVBQWU1TSxPQUFPRixLQUFLbEQsVUFBVSxLQUFLO0FBQ2hELGdCQUFNaVEsY0FBYzdNLE9BQU9GLEtBQUtqRCxVQUFVLEtBQUs7QUFFL0NpRCxlQUFLdkQsYUFBYStRLFlBQVlsUjtBQUM5QjBELGVBQUt0RCxlQUFlOFEsWUFBWTNJLFNBQW1CO0FBQ25EN0UsZUFBS3JELGVBQWU2USxZQUFZekksU0FBbUI7QUFDbkQvRSxlQUFLM0MsaUJBQWlCbVEsWUFBWW5RLGtCQUFrQjtBQUNwRDJDLGVBQUs3QyxtQkFBbUJrSztBQUN4QnJILGVBQUs1QyxrQkFBa0JrSztBQUN2QnRILGVBQUtuRCxtQkFBbUI7QUFDeEJtRCxlQUFLMEcsc0JBQXNCckg7QUFFM0IsY0FBSXlOLGdCQUFnQixFQUFHOU0sTUFBS2xELGFBQWFRLG1CQUFtQitKLFlBQVlGLFlBQVk7QUFDcEYsY0FBSTRGLGVBQWUsRUFBRy9NLE1BQUtqRCxhQUFhTyxtQkFBbUJnSyxXQUFXSCxZQUFZO0FBRWxGLGNBQUlsRyxTQUFTcEIsd0JBQXdCLENBQUM2QixtQkFBbUI7QUFDckQxQixpQkFBSzlDLFFBQVFtSCxtQkFBbUJyRSxNQUFNb0IsV0FBVztBQUFBLFVBQ3JELE9BQU87QUFDSHBCLGlCQUFLOUMsUUFBUTtBQUFBLFVBQ2pCO0FBRUFnTixtQkFBU29DLEtBQUssSUFBSXRNO0FBQ2xCLGlCQUFPa0s7QUFBQUEsUUFDWCxDQUFDO0FBQUEsTUFDTDtBQUFBLElBQ0osU0FBU3BKLFFBQU87QUFDWjJNLGNBQVEzTSxNQUFNLHNDQUFzQ0EsTUFBSztBQUFBLElBQzdEO0FBQUEsRUFDSjtBQUVBLFFBQU00TSxrQkFBa0JBLENBQUNwQixVQUFrQjtBQUN2Q25MLGFBQVMsQ0FBQWlHLGNBQWE7QUFDbEIsWUFBTThDLFdBQVcsQ0FBQyxHQUFHOUMsU0FBUztBQUM5QixZQUFNcEgsT0FBTyxFQUFFLEdBQUdrSyxTQUFTb0MsS0FBSyxFQUFFO0FBQ2xDdE0sV0FBS3ZELGFBQWE7QUFBR3VELFdBQUt0RCxlQUFlO0FBQUlzRCxXQUFLckQsZUFBZTtBQUNqRXFELFdBQUtsRCxhQUFhO0FBQUdrRCxXQUFLM0MsaUJBQWlCO0FBQUcyQyxXQUFLOUMsUUFBUTtBQUFJOEMsV0FBS2hELGtCQUFrQjtBQUN0RmdELFdBQUtuRCxtQkFBbUI7QUFDeEJtRCxXQUFLMEcsc0JBQXNCckg7QUFDM0I2SyxlQUFTb0MsS0FBSyxJQUFJdE07QUFDbEIsYUFBT2tLO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNeUQsZ0JBQWdCQSxNQUFNO0FBQ3hCeE0sYUFBUyxDQUFBOEYsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRSxHQUFHNUssb0JBQW9CRSxRQUFRMkosT0FBT0MsV0FBVyxHQUFHM0osYUFBYXlLLEtBQUszQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0FBQUEsRUFDcEg7QUFDQSxRQUFNc0osbUJBQW1CQSxDQUFDdEIsVUFBa0I7QUFDeENuTCxhQUFTLENBQUE4RixTQUFRQSxLQUFLa0QsT0FBTyxDQUFDMEQsR0FBR2pELE1BQU1BLE1BQU0wQixLQUFLLENBQUM7QUFBQSxFQUN2RDtBQUdBLFFBQU13Qix5QkFBeUJBLENBQUN4QixVQUFrQjtBQUM5QyxRQUFJNUssa0JBQW1CO0FBQ3ZCLFFBQUksQ0FBQ1QsU0FBUzFDLFdBQVc7QUFBRWpGLFlBQU15USxLQUFLLDJDQUEyQztBQUFHO0FBQUEsSUFBUTtBQUM1Ri9HLDhCQUEwQnNKLEtBQUs7QUFDL0J4SiwwQkFBc0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTWlMLHNCQUFzQkEsQ0FBQzdRLFVBQXdCO0FBQ2pELFFBQUk2RiwyQkFBMkIsS0FBTTtBQUNyQzVCLGFBQVMsQ0FBQThGLFNBQVFBLEtBQUtoQixJQUFJLENBQUNqRyxNQUFNc00sVUFBVUEsVUFBVXZKLHlCQUF5QixFQUFFLEdBQUcvQyxNQUFNOUMsTUFBYSxJQUFJOEMsSUFBSSxDQUFDO0FBQy9HZ0QsOEJBQTBCLElBQUk7QUFDOUJGLDBCQUFzQixLQUFLO0FBQUEsRUFDL0I7QUFDQSxRQUFNa0wsc0JBQXNCQSxDQUFDQyxZQUFxQjtBQUM5Qy9NLGdCQUFZLENBQUErRixVQUFTLEVBQUUsR0FBR0EsTUFBTXBILHNCQUFzQm9PLFFBQVEsRUFBRTtBQUNoRSxRQUFJQSxTQUFTO0FBQ1Q5TSxlQUFTLENBQUE4RixTQUFRQSxLQUFLaEIsSUFBSSxDQUFBakcsVUFBUyxFQUFFLEdBQUdBLE1BQU05QyxPQUFPbUgsbUJBQW1CckUsTUFBTW9CLFdBQVcsRUFBRSxFQUFFLENBQUM7QUFBQSxJQUNsRyxPQUFPO0FBQ0hELGVBQVMsQ0FBQThGLFNBQVFBLEtBQUtoQixJQUFJLENBQUFqRyxVQUFTLEVBQUUsR0FBR0EsTUFBTTlDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0o7QUFHQSxRQUFNZ1IsY0FBYyxZQUFZO0FBQzVCaE0sZUFBVyxJQUFJO0FBRWYsVUFBTWlNLGFBQWF4TyxNQUFNc0csSUFBSSxDQUFBakcsU0FBUTtBQUNqQyxZQUFNLEVBQUV6RCxRQUFRbUsscUJBQXFCMEgsZ0JBQWdCLEdBQUdDLEtBQUssSUFBSXJPO0FBQ2pFLGFBQU87QUFBQSxRQUNILEdBQUdxTztBQUFBQSxRQUNIL1IsSUFBSStSLEtBQUsvUixNQUFNO0FBQUEsUUFDZlksT0FBTytELFNBQVNwQix3QkFBd0IsQ0FBQzZCLG9CQUFxQjJNLEtBQUtuUixTQUFTLEtBQU07QUFBQSxRQUNsRkMsa0JBQW1Ca1IsS0FBYWxSLG9CQUFvQjtBQUFBLFFBQ3BEQyxpQkFBa0JpUixLQUFhalIsbUJBQW1CO0FBQUEsTUFDdEQ7QUFBQSxJQUNKLENBQUM7QUFHRCxVQUFNO0FBQUEsTUFBRWdDO0FBQUFBLE1BQVFFO0FBQUFBLE1BQWFDO0FBQUFBLE1BQU9DO0FBQUFBLE1BQVVDO0FBQUFBLE1BQVdDO0FBQUFBLE1BQ3JEYjtBQUFBQSxNQUFhaUc7QUFBQUEsTUFBYWhHO0FBQUFBLE1BQWtCa0c7QUFBQUEsTUFDNUNqRztBQUFBQSxNQUFZa0c7QUFBQUEsTUFBWWpHO0FBQUFBLE1BQWVrRztBQUFBQSxNQUN2Q2pHO0FBQUFBLE1BQWdCa0c7QUFBQUEsTUFBZ0JqRztBQUFBQSxNQUFvQkM7QUFBQUEsTUFDcERTLGNBQWNpTztBQUFBQSxNQUFHLEdBQUdTO0FBQUFBLElBQWMsSUFBSXJOO0FBRTFDLFVBQU1zTixZQUFZN00sb0JBQ1o3RixrQ0FBa0M7QUFBQSxNQUNoQ3FCLE9BQU8wQztBQUFBQSxNQUNQRCxPQUFPd087QUFBQUEsTUFDUHRPLHNCQUFzQm9CLFNBQVNwQjtBQUFBQSxJQUNuQyxDQUFDLElBQ0M7QUFFTixVQUFNMk8sYUFBb0M7QUFBQSxNQUN0QyxHQUFHRjtBQUFBQSxNQUNIM08sT0FBTzRPLFdBQVc1TyxTQUFTd087QUFBQUEsTUFDM0J0TyxzQkFBc0IwTyxXQUFXMU8sd0JBQXdCLENBQUMsQ0FBQ29CLFNBQVNwQjtBQUFBQSxNQUNwRTFCLGNBQWN5SixpQkFBaUJVO0FBQUFBLE1BQy9CdEwsaUJBQWlCa0QsT0FBT2UsU0FBU2pFLGVBQWUsS0FBSztBQUFBLE1BQ3JEc0IsZUFBZTRCLE9BQU9lLFNBQVMzQyxhQUFhLEtBQUs7QUFBQSxNQUNqRHdCLDJCQUEyQixDQUFDLENBQUNtQixTQUFTbkI7QUFBQUEsTUFDdEM1QyxPQUFPcVIsWUFDREEsVUFBVXJSLFFBQ1QsQ0FBQytELFNBQVNwQix1QkFBdUJELGFBQWF1SyxPQUFPLENBQUFzRSxNQUFLQSxFQUFFcEcsU0FBUyxDQUFDLElBQUk7QUFBQSxNQUNqRmhLLGtCQUFrQndGO0FBQUFBLE1BQ2xCbEcsZ0JBQ0lzRCxTQUFTdEQsa0JBQWtCLFFBQVFzRCxTQUFTdEQsbUJBQW1CLEtBQ3pELEtBQ0EwSCxPQUFPcEUsU0FBU3RELGNBQWM7QUFBQSxJQUM1QztBQUVBLFFBQUk7QUFDQSxZQUFNK1EsUUFBUSxNQUFNM04sU0FBU3lOLFVBQTBCO0FBQ3ZELFVBQUlFLE9BQU87QUFDUHBWLGNBQU02VCxRQUFRLFdBQVd6TSxTQUFTLFdBQVcsV0FBVyxhQUFhLGFBQWE7QUFDbEZELGlCQUFTekUsa0JBQWtCN0IsMEJBQTBCdUssU0FBUyxDQUFDO0FBQUEsTUFDbkU7QUFBQSxJQUNKLFNBQVNpSyxVQUFlO0FBQ3BCclYsWUFBTXdILE1BQU0scUJBQXFCNk4sU0FBU3BMLFdBQVcsbUJBQW1CLEVBQUU7QUFBQSxJQUM5RSxVQUFDO0FBQ0dyQixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTTBNLGFBQWEsWUFBWTtBQUMzQixRQUFJLENBQUMzTixTQUFTMUMsYUFBYSxDQUFDMEMsU0FBU3pDLGtCQUFrQixDQUFDeUMsU0FBU3ZDLGFBQWE7QUFDMUVwRixZQUFNd0gsTUFBTSw4Q0FBOEM7QUFBRztBQUFBLElBQ2pFO0FBQ0EsUUFBSStOLGFBQWF2TixzQkFBc0JMLFNBQVM3QixRQUFRc0csUUFBUTtBQUNoRSxRQUFJaEUscUJBQXFCLENBQUNoRyxzQkFBc0JtVCxVQUFVLEtBQUs1TixTQUFTMUMsV0FBVztBQUMvRSxVQUFJO0FBQ0EsY0FBTWlILGFBQWEsTUFBTXhMLFFBQWlCSyxxQkFBcUJvTCxVQUFVeEUsU0FBUzFDLFNBQVM7QUFDM0ZzUSxxQkFBYXJKLFdBQVdFLFFBQVE7QUFDaENuRSw4QkFBc0JzTixVQUFVO0FBQUEsTUFDcEMsUUFBUTtBQUFBLE1BQ0o7QUFBQSxJQUVSO0FBQ0EsUUFBSW5OLHFCQUFxQixDQUFDaEcsc0JBQXNCbVQsVUFBVSxHQUFHO0FBQ3pEdlYsWUFBTXdILE1BQU0sa0dBQWtHO0FBQzlHO0FBQUEsSUFDSjtBQUNBLFFBQUluQixNQUFNMkUsV0FBVyxHQUFHO0FBQUVoTCxZQUFNd0gsTUFBTSw2QkFBNkI7QUFBRztBQUFBLElBQVE7QUFDOUUsUUFBSSxDQUFDK0MsdUJBQXVCLENBQUNBLG9CQUFvQnFILEtBQUssR0FBRztBQUNyRDVSLFlBQU13SCxNQUFNLDRDQUE0QztBQUN4RDtBQUFBLElBQ0o7QUFFQSxlQUFXZCxRQUFRTCxPQUFPO0FBQ3RCLFlBQU1tSCxPQUFPNUcsT0FBT0YsS0FBS25ELGdCQUFnQixLQUFLO0FBQzlDLFVBQUlpSyxPQUFPLEtBQUs1RyxPQUFPRixLQUFLcEQsUUFBUSxJQUFJa0ssTUFBTTtBQUMxQ3hOLGNBQU13SDtBQUFBQSxVQUNGLG1CQUFtQmQsS0FBS3JELGdCQUFnQixTQUFTLE1BQU11RCxPQUFPRixLQUFLcEQsUUFBUSxDQUFDLHlDQUF5Q2tLLElBQUk7QUFBQSxRQUM3SDtBQUNBO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxVQUFNZ0ksZ0JBQWdCQSxNQUFNO0FBQ3hCM00sZUFBU3hDLE9BQU8sTUFBTTtBQUNsQixhQUFLdU8sWUFBWTtBQUFBLE1BQ3JCLENBQUM7QUFBQSxJQUNMO0FBRUEsVUFBTWEsZ0JBQWdCcFAsTUFBTWlILEtBQUs3Ryx3QkFBd0I7QUFDekQsUUFBSWdQLGVBQWU7QUFDZnZMLDhCQUF3QndMLFVBQVVGO0FBQ2xDMUwsb0JBQWM7QUFBQSxRQUNWQyxNQUFNO0FBQUEsUUFDTkMsT0FBTztBQUFBLFFBQ1BDLFNBQVNuRCxtQkFBbUIyTyxhQUFhO0FBQUEsTUFDN0MsQ0FBQztBQUNEO0FBQUEsSUFDSjtBQUVBRCxrQkFBYztBQUFBLEVBQ2xCO0FBR0EsUUFBTUcseUJBQXlCQSxDQUFDakcsT0FBb0JzRSxZQUFvQjtBQUNwRXBNLGdCQUFZLENBQUErRixVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDLEdBQUcrQixLQUFLLEtBQUssR0FBRztBQUFBLE1BQ2pCLENBQUMsR0FBR0EsS0FBSyxPQUFPLEdBQUdzRTtBQUFBQSxNQUNuQixDQUFDLEdBQUd0RSxLQUFLLE9BQU8sR0FBRztBQUFBLE1BQ25CLENBQUMsR0FBR0EsS0FBSyxFQUFFLEdBQUczSjtBQUFBQSxJQUNsQixFQUFFO0FBQ0YsUUFBSTJKLFVBQVUsVUFBVTtBQUNwQjNILHFCQUFlLEVBQUU7QUFDakJFLDRCQUFzQixJQUFJO0FBQzFCRSw0QkFBc0IsSUFBSTtBQUMxQkUsMkJBQXFCLEtBQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFFQSxRQUFNdU4seUJBQXlCLE9BQU9sRyxPQUFvQndDLFdBQThCO0FBQ3BGLFVBQU0yRCxZQUFZbE8sU0FBUyxHQUFHK0gsS0FBSyxPQUE2QjtBQUNoRSxRQUFJLENBQUNtRyxVQUFXO0FBQ2hCLFFBQUksQ0FBQzNELFFBQVE1RyxpQkFBa0IsUUFBT3RMLE1BQU13SCxNQUFNLDBDQUEwQ2tJLEtBQUssRUFBRTtBQUVuRyxVQUFNLEVBQUV2RCxVQUFVYixpQkFBaUIsSUFBSTRHO0FBQ3ZDLFFBQUk7QUFDQSxZQUFNeEwsT0FBTyxNQUFNOUYsY0FBbUJ1TCxVQUFVLENBQUMsRUFBRXNHLFdBQVduSCxpQkFBaUJDLFdBQXFCaUUsT0FBT3FHLFVBQVUsQ0FBQyxDQUFDO0FBQ3ZILFVBQUluUCxNQUFNO0FBQ04sWUFBSWdKLFVBQVUsaUJBQWlCM0QsT0FBT3JGLEtBQUtwQyxNQUFNLE1BQU0sS0FBSztBQUN4RHRFLGdCQUFNd0gsTUFBTSw0Q0FBNEM7QUFDeEQ7QUFBQSxRQUNKO0FBQ0FpSSw2QkFBcUJDLE9BQU9oSixJQUFJO0FBQ2hDMUcsY0FBTTZULFFBQVEsSUFBSW5OLEtBQUs0RSxpQkFBaUJHLFNBQW1CLENBQUMsaUJBQWlCO0FBQUEsTUFDakYsT0FBTztBQUNIekwsY0FBTXdILE1BQU0scUNBQXFDO0FBQUEsTUFDckQ7QUFBQSxJQUNKLFNBQVNzTSxLQUFLO0FBQUU5VCxZQUFNd0gsTUFBTSw2QkFBNkI7QUFBQSxJQUFHO0FBQUEsRUFDaEU7QUFFQSxRQUFNc08sb0JBQW9CQSxDQUFDcEcsVUFBdUI7QUFDOUM5SCxnQkFBWSxDQUFBK0YsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQyxHQUFHK0IsS0FBSyxLQUFLLEdBQUc7QUFBQSxNQUNqQixDQUFDLEdBQUdBLEtBQUssT0FBTyxHQUFHO0FBQUEsTUFDbkIsQ0FBQyxHQUFHQSxLQUFLLE9BQU8sR0FBRztBQUFBLE1BQ25CLENBQUMsR0FBR0EsS0FBSyxFQUFFLEdBQUczSjtBQUFBQSxJQUNsQixFQUFFO0FBQ0YsUUFBSTJKLFVBQVUsVUFBVTtBQUNwQjNILHFCQUFlLEVBQUU7QUFDakJJLDRCQUFzQixJQUFJO0FBQzFCRiw0QkFBc0IsSUFBSTtBQUMxQkksMkJBQXFCLEtBQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFHQSxRQUFNME4seUJBQXlCQSxDQUFDQyxXQUFtQjFHLE1BQXdCMkcsZ0JBQXdCO0FBQy9GLFFBQUksQ0FBQ0QsV0FBVztBQUFFaFcsWUFBTXlRLEtBQUssNENBQTRDO0FBQUc7QUFBQSxJQUFRO0FBQ3BGLFFBQUluQixTQUFTLFNBQVM7QUFDbEIxRiwyQkFBcUI7QUFBQSxRQUNqQnNNLFFBQVE7QUFBQSxRQUFNbE0sT0FBTyxrQ0FBa0NpTSxXQUFXO0FBQUEsUUFBSTlKLFVBQVU7QUFBQSxRQUNoRjZKO0FBQUFBLFFBQXNCRyxVQUFVeE8sU0FBUzFDLGFBQWE7QUFBQSxRQUFNbVIsU0FBUzNUO0FBQUFBLE1BQ3pFLENBQUM7QUFBQSxJQUNMLE9BQU87QUFDSG1ILDJCQUFxQjtBQUFBLFFBQ2pCc00sUUFBUTtBQUFBLFFBQU1sTSxPQUFPO0FBQUEsUUFBaUNtQyxVQUFVO0FBQUEsUUFDaEU2SjtBQUFBQSxRQUFzQkcsVUFBVXhPLFNBQVMxQyxhQUFhO0FBQUEsUUFBTW1SLFNBQVN6VDtBQUFBQSxNQUN6RSxDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFDQSxRQUFNMFQsMEJBQTBCQSxNQUFNek0scUJBQXFCcEgsd0JBQXdCO0FBRW5GLFFBQU04VCx3QkFBd0JBLE1BQU07QUFDaEN4TSxrQkFBYyxDQUFBNkQsVUFBUyxFQUFFLEdBQUdBLE1BQU01RCxNQUFNLE1BQU0sRUFBRTtBQUNoRCxVQUFNd00sZUFBZXJNLHdCQUF3QndMO0FBQzdDeEwsNEJBQXdCd0wsVUFBVTtBQUNsQ2EsbUJBQWU7QUFBQSxFQUNuQjtBQUVBLFFBQU1DLHFCQUFxQkEsQ0FBQ3hELFVBQWtCO0FBQzFDLFVBQU10TSxPQUFPTCxNQUFNMk0sS0FBSztBQUN4QixRQUFJLENBQUN0TSxRQUFRLENBQUNELHlCQUF5QkMsSUFBSSxFQUFHO0FBQzlDd0QsNEJBQXdCd0wsVUFBVTtBQUNsQzVMLGtCQUFjO0FBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxTQUFTbkQsbUJBQW1CSixJQUFJO0FBQUEsSUFDcEMsQ0FBQztBQUFBLEVBQ0w7QUFFQSxPQUFLYSxlQUFlZ0IscUJBQXFCbkIsU0FBUyxPQUFRLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ2hGLE1BQUlJLFNBQVNKLFNBQVMsT0FBUSxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZTtBQUFBO0FBQUEsSUFBd0JJO0FBQUFBLE9BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEQ7QUFFakcsUUFBTWlQLGtCQUFrQjtBQUN4QixRQUFNQyxrQkFBa0I7QUFJeEIsU0FDSSxtQ0FDSTtBQUFBLDJCQUFDLFNBQUksV0FBVSwrREFJVC9OO0FBQUFBLG9CQUFhakIsV0FDWCx1QkFBQyxTQUFJLFdBQVUsMElBQ1gsaUNBQUMsU0FBSSxXQUFVLDBGQUNYO0FBQUEsK0JBQUMsYUFBVSxXQUFVLGlEQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDbEUsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQyxtQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FLHVCQUFDLE9BQUUsV0FBVSx1Q0FBc0MsbURBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxXQUgxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUdKLHVCQUFDLFFBQUcsV0FBVSx1Q0FDVE4sbUJBQVMsV0FDSiwyQkFDQSxvQkFBb0JPLFNBQVN0RCxrQkFBa0IsUUFBUTBILE9BQU9wRSxTQUFTdEQsY0FBYyxFQUFFdU4sS0FBSyxNQUFNLEtBQzlGN1AseUJBQXlCNEYsU0FBU3BELFFBQVFvRCxTQUFTZ1AsVUFBVWhQLFNBQVN0RCxjQUFjLElBQ3BGLElBQUlyQixFQUFFLEVBQUUsTUFMdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBRVg7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBRVg7QUFBQSxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVcyRSxTQUFTOUIsb0JBQW9CO0FBQUEsZ0JBQ3hDLFdBQVc4QixTQUFTd0osb0JBQW9CO0FBQUEsZ0JBQ3hDLGNBQWMsQ0FBQzZDLFlBQVkyQix1QkFBdUIsZUFBZTNCLE9BQU87QUFBQSxnQkFDeEUsY0FBYyxNQUFNNEIsdUJBQXVCLGVBQWU5VSx1QkFBdUI7QUFBQSxnQkFDakYsZUFBZSxNQUFNbVIsZ0JBQWdCLGVBQWVuUix1QkFBdUI7QUFBQSxnQkFDM0UsY0FBYyxNQUFNO0FBQ2hCOEcsOEJBQVl4RCxrQkFBa0I7QUFBR3lELDJCQUFTLEVBQUU7QUFDNUNFLGlDQUFlLEVBQUU7QUFBR08sa0NBQWdCLEVBQUU7QUFBQSxnQkFDMUM7QUFBQTtBQUFBLGNBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU007QUFBQSxlQVhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDJCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3RFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV1gsU0FBU3BDLGVBQWU7QUFBQSxnQkFDbkMsV0FBV29DLFNBQVM2RCxlQUFlN0QsU0FBUzdCLFFBQVFpQixRQUFRO0FBQUEsZ0JBQzVELGNBQWMsQ0FBQ2lOLFlBQVkyQix1QkFBdUIsVUFBVTNCLE9BQU87QUFBQSxnQkFDbkUsY0FBYyxNQUFNNEIsdUJBQXVCLFVBQVU3VSxvQkFBb0I7QUFBQSxnQkFDekUsZUFBZSxNQUFNa1IsZ0JBQWdCLFVBQVVsUixvQkFBb0I7QUFBQSxnQkFDbkUsY0FBYyxNQUFNK1Usa0JBQWtCLFFBQVE7QUFBQTtBQUFBLGNBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1vRDtBQUFBLGVBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLHdCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV25PLFNBQVNuQyxvQkFBb0I7QUFBQSxnQkFDeEMsV0FBV21DLFNBQVMrRCxvQkFBb0IvRCxTQUFTM0IsYUFBYWUsUUFBUTtBQUFBLGdCQUN0RSxjQUFjLENBQUNpTixZQUFZMkIsdUJBQXVCLGVBQWUzQixPQUFPO0FBQUEsZ0JBQ3hFLGNBQWMsTUFBTTRCLHVCQUF1QixlQUFlNVUsc0JBQXNCO0FBQUEsZ0JBQ2hGLGVBQWUsTUFBTWlSLGdCQUFnQixlQUFlalIsc0JBQXNCO0FBQUEsZ0JBQzFFLGNBQWMsTUFBTThVLGtCQUFrQixhQUFhO0FBQUE7QUFBQSxjQU52RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNeUQ7QUFBQSxlQVI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUVYO0FBQUEsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMseUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT25PLFNBQVNwRCxVQUFVO0FBQUEsZ0JBQzFCLFVBQVUwSztBQUFBQSxnQkFDVixVQUFVN0c7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUVUQSw4QkFDRyx1QkFBQyxZQUFPLE9BQU0sS0FBSSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsSUFFbkIsbUNBQ0k7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sS0FBSSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUI7QUFBQSxrQkFDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUEsa0JBQ25CLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQjtBQUFBLHFCQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUE7QUFBQSxjQWRSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLGVBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUM1RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT1QsU0FBU25ELGNBQWNHLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLGdCQUMvQyxVQUFVc0s7QUFBQUEsZ0JBQ1YsY0FBYTtBQUFBLGdCQUFNLFdBQVU7QUFBQTtBQUFBLGNBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtxSDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPdEgsU0FBUy9DLGVBQWVELE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLGdCQUNoRCxVQUFVc0s7QUFBQUEsZ0JBQ1YsY0FBYTtBQUFBLGdCQUFNLFdBQVU7QUFBQTtBQUFBLGNBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtxSDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVd0SCxTQUFTbEMsY0FBYztBQUFBLGdCQUNsQyxXQUFXa0MsU0FBU2dFLGNBQWNoRSxTQUFTMUIsT0FBT2MsUUFBUTtBQUFBLGdCQUMxRCxjQUFjLENBQUNpTixZQUFZMkIsdUJBQXVCLFNBQVMzQixPQUFPO0FBQUEsZ0JBQ2xFLGNBQWMsTUFBTTRCLHVCQUF1QixTQUFTM1UsdUJBQXVCO0FBQUEsZ0JBQzNFLGVBQWUsTUFBTWdSLGdCQUFnQixTQUFTaFIsdUJBQXVCO0FBQUEsZ0JBQ3JFLGNBQWMsTUFBTTZVLGtCQUFrQixPQUFPO0FBQUE7QUFBQSxjQU5qRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNbUQ7QUFBQSxlQVJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQywwQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVduTyxTQUFTaEMsa0JBQWtCO0FBQUEsZ0JBQ3RDLFdBQVdnQyxTQUFTa0Usa0JBQWtCbEUsU0FBU3hCLFdBQVdZLFFBQVE7QUFBQSxnQkFDbEUsY0FBYyxDQUFDaU4sWUFBWTJCLHVCQUF1QixhQUFhM0IsT0FBTztBQUFBLGdCQUN0RSxjQUFjLE1BQU00Qix1QkFBdUIsYUFBYXpVLHVCQUF1QjtBQUFBLGdCQUMvRSxlQUFlLE1BQU04USxnQkFBZ0IsYUFBYTlRLHVCQUF1QjtBQUFBLGdCQUN6RSxjQUFjLE1BQU0yVSxrQkFBa0IsV0FBVztBQUFBO0FBQUEsY0FOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXVEO0FBQUEsZUFSM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMsc0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFO0FBQUEsWUFDakU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFXbk8sU0FBU2pDLGlCQUFpQjtBQUFBLGdCQUNyQyxXQUFXaUMsU0FBU2lFLGlCQUFpQmpFLFNBQVN6QixVQUFVYSxRQUFRO0FBQUEsZ0JBQ2hFLGNBQWMsQ0FBQ2lOLFlBQVkyQix1QkFBdUIsWUFBWTNCLE9BQU87QUFBQSxnQkFDckUsY0FBYyxNQUFNNEIsdUJBQXVCLFlBQVkxVSxtQkFBbUI7QUFBQSxnQkFDMUUsZUFBZSxNQUFNK1EsZ0JBQWdCLFlBQVkvUSxtQkFBbUI7QUFBQSxnQkFDcEUsY0FBYyxNQUFNNFUsa0JBQWtCLFVBQVU7QUFBQTtBQUFBLGNBTnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1zRDtBQUFBLGVBUjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQ3pFLHVCQUFDLFNBQUksV0FBVSxpRUFDWDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxPQUFPbk8sU0FBUzNDLGlCQUFpQjtBQUFBLGtCQUNqQyxlQUFlO0FBQUEsa0JBQ2YsVUFBVSxDQUFBZixRQUFPMkQsWUFBWSxDQUFBK0YsVUFBUyxFQUFFLEdBQUdBLE1BQU0zSSxlQUFlZixPQUFPLEVBQUUsRUFBRTtBQUFBLGtCQUMzRSxVQUFVMEc7QUFBQUEsa0JBQ1YsVUFBVUE7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBO0FBQUEsZ0JBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT3FHO0FBQUEsY0FFckcsdUJBQUMsU0FBSSxXQUFVLG9DQUNYO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csSUFBRztBQUFBLG9CQUNILE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxDQUFDLENBQUNoRCxTQUFTbkI7QUFBQUEsb0JBQ3BCLFVBQVV5STtBQUFBQSxvQkFDVixjQUFhO0FBQUEsb0JBQU0sV0FBVTtBQUFBO0FBQUEsa0JBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNd0c7QUFBQSxnQkFFeEcsdUJBQUMsV0FBTSxTQUFRLDZCQUE0QixXQUFVLDJDQUF5Qyx3Q0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxlQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLGFBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4REE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLGlDQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLCtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPdEgsU0FBU3lKLHlCQUF5QjtBQUFBLGdCQUN6QyxVQUFVbkM7QUFBQUEsZ0JBQ1YsY0FBYTtBQUFBLGdCQUFNLFdBQVU7QUFBQTtBQUFBLGNBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtxSDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWCxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyxzQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUNqRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFFTCxPQUFPNUUsa0JBQWtCLHVCQUF3QkUsd0JBQXdCSixnQkFBZ0JhLFNBQVMsSUFBSWIsZ0JBQWdCLENBQUMsSUFBSTtBQUFBLGdCQUMzSCxVQUFVMkk7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUNWLFVBQVUsQ0FBQ25MLFNBQVMxQztBQUFBQSxnQkFFcEI7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sSUFBRyx3Q0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUM7QUFBQSxtQkFFdkNrRixtQkFBbUIsSUFBSXdDO0FBQUFBLG9CQUFJLENBQUMwRSxTQUFTMkIsVUFDbkMsdUJBQUMsWUFBbUIsT0FBTzNCLFNBQ3RCQSxxQkFEUTJCLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNIO0FBQUEsa0JBRUQsdUJBQUMsWUFBTyxPQUFNLHNCQUFxQiwrQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQTtBQUFBO0FBQUEsY0FoQnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQTtBQUFBLFlBR0MzSSxtQkFDRztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxNQUFNO0FBQUEsZ0JBQ04sT0FBT0U7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBMkUsTUFBSzFFLHVCQUF1QjBFLEVBQUVDLE9BQU9LLEtBQUs7QUFBQSxnQkFDcEQsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQSxnQkFBdUYsY0FBYTtBQUFBO0FBQUEsY0FObEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXVIO0FBQUEsZUE3Qi9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsYUE1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThDQTtBQUFBLFdBcE1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxTUE7QUFBQSxNQUlBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSwrQ0FBOEMsbUNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsU0FBSSxXQUFVLHNDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXLHVCQUF1QixDQUFDN0gsU0FBU3BCLHVCQUF1QixvQkFBb0IsZUFBZSxJQUFJLDJCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySDtBQUFBLFlBQzNILHVCQUFDLGdCQUFhLFNBQVNvQixTQUFTcEIsd0JBQXdCLE9BQU8sVUFBVW1PLHFCQUFxQixTQUFRLHVCQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SDtBQUFBLFlBQ3pILHVCQUFDLFVBQUssV0FBVyx1QkFBdUIvTSxTQUFTcEIsdUJBQXVCLG9CQUFvQixlQUFlLElBQUksNkJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRIO0FBQUEsZUFIaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSx3RkFBdUYsd0JBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsWUFDN0csdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixxQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0c7QUFBQSxZQUNwRyx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHFCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLFlBQ3BHLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUY7QUFBQTtBQUFBLGNBQVdrRTtBQUFBQSxjQUFjO0FBQUEsaUJBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlIO0FBQUEsWUFDekgsdUJBQUMsUUFBRyxXQUFVLHlGQUF3Riw2QkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUg7QUFBQSxZQUVuSCx1QkFBQyxRQUFHLFdBQVUseUZBQXdGLDBCQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSDtBQUFBLFlBQ2hILHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsd0JBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHO0FBQUEsWUFDdEcsQ0FBQ3JDLHFCQUFxQlQsU0FBU3BCLHdCQUM1Qix1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHlCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLFlBRTVHLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsd0JBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHO0FBQUEsWUFDdkcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRiwyQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEc7QUFBQSxZQUMxRyx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLG9CQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLGVBZHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWkYsZ0JBQU1zRyxJQUFJLENBQUNqRyxNQUFNc00sVUFBVTtBQUN4QixrQkFBTXpFLFdBQVkzSCxPQUFPRixLQUFLcEQsUUFBUSxJQUFJc0QsT0FBT0YsS0FBS2xELFVBQVU7QUFDaEUsa0JBQU1vVCxXQUFXaFEsT0FBT0YsS0FBS2hELGVBQWUsS0FBSztBQUNqRCxrQkFBTW1ULGVBQWV0SSxXQUFXcUk7QUFDaEMsa0JBQU1FLFdBQVlsUSxPQUFPRixLQUFLcEQsUUFBUSxJQUFJc0QsT0FBT0YsS0FBS2pELFVBQVU7QUFDaEUsa0JBQU1zVCxVQUFVRixlQUFlQyxZQUFZQSxXQUFXO0FBQ3RELGtCQUFNRSxlQUFlLENBQUM1TyxxQkFBcUJULFNBQVNwQix3QkFBd0JHLEtBQUs5QyxTQUFTLElBQUk0SyxPQUFPLENBQUNDLEtBQUtwQyxRQUFRb0MsTUFBTTdILE9BQU95RixJQUFJMEMsTUFBTSxHQUFHLENBQUMsSUFBSTtBQUNsSixrQkFBTWtJLFlBQVlKLGVBQWVHO0FBRWpDLG1CQUNJLHVCQUFDLFFBQ0c7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsK0JBQ1Y7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csV0FBV3RRLEtBQUt0RCxnQkFBZ0I7QUFBQSxrQkFDaEMsV0FBV3NELEtBQUtyRCxnQkFBZ0I7QUFBQSxrQkFDaEMsY0FBYyxDQUFDMlEsWUFBWUQscUJBQXFCZixPQUFPZ0IsT0FBTztBQUFBLGtCQUM5RCxjQUFjLE1BQU1ULHFCQUFxQlAsS0FBSztBQUFBLGtCQUM5QyxlQUFlLE1BQU1mLGdCQUFnQixRQUFRN1EsdUJBQXVCNFIsS0FBSztBQUFBLGtCQUN6RSxjQUFjLE1BQU1vQixnQkFBZ0JwQixLQUFLO0FBQUEsa0JBQ3pDLE1BQUs7QUFBQSxrQkFDTCxvQkFBb0I7QUFBQSxrQkFDcEIsb0JBQW9CO0FBQUEsb0JBQ2hCN0csVUFBVS9LLHNCQUFzQitLO0FBQUFBLG9CQUNoQ1osV0FBVztBQUFBLG9CQUNYRSxXQUFXO0FBQUEsb0JBQ1h5TCxjQUFjN1Y7QUFBQUEsb0JBQ2Q4VixVQUFVQSxDQUFDM0UsWUFBWTtBQUNuQnlCLG1EQUE2QmpCLE9BQU9SLE9BQU87QUFBQSxvQkFDL0M7QUFBQSxrQkFDSjtBQUFBO0FBQUEsZ0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCTSxLQWxCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNWLGlDQUFDLE9BQUUsaUNBQUMsZ0JBQWEsTUFBSyxZQUFXLE9BQU85TCxLQUFLcEQsVUFBVSxVQUFVLENBQUFXLFFBQU9xUCwwQkFBMEJOLE9BQU8sWUFBWS9PLEdBQUcsR0FBRyxRQUFRLE1BQU11UyxtQkFBbUJ4RCxLQUFLLEdBQUcsV0FBVSxzRkFBM0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNlAsS0FBaFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbVEsS0FEdlE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNUdE0sZUFBSzNDLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFDVixpQ0FBQyxnQkFBYSxNQUFLLGNBQWEsT0FBTzJDLEtBQUtsRCxZQUFZLFVBQVUsQ0FBQVMsUUFBT3FQLDBCQUEwQk4sT0FBTyxjQUFjL08sR0FBRyxHQUFHLFdBQVUsc0ZBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBOLEtBRDlOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxzQ0FDVixpQ0FBQyxnQkFBYSxNQUFLLG1CQUFrQixPQUFPeUMsS0FBS2hELGlCQUFpQixVQUFVLENBQUFPLFFBQU9xUCwwQkFBMEJOLE9BQU8sbUJBQW1CL08sR0FBRyxHQUFHLFdBQVUsc0ZBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlPLEtBRDdPO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLFFBQUcsV0FBVSxzQ0FDVixpQ0FBQyxnQkFBYSxNQUFLLHlCQUF3QixPQUFPeUMsS0FBSy9DLHVCQUF1QixVQUFVLENBQUFNLFFBQU9xUCwwQkFBMEJOLE9BQU8seUJBQXlCL08sR0FBRyxHQUFHLFdBQVUsc0ZBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJQLEtBRC9QO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxxREFDVG5DLHNCQUFZK1UsY0FBYyxVQUFVLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNDLENBQUN6TyxxQkFBcUJULFNBQVNwQix3QkFDNUIsdUJBQUMsUUFBRyxXQUFVLHFEQUNUekUsc0JBQVlrVixjQUFjLFVBQVUsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUosdUJBQUMsUUFBRyxXQUFXLG1EQUFtREQsVUFBVSxJQUFJLG1CQUFtQixjQUFjLElBQzVHalYsc0JBQVlpVixRQUFRLFlBQVksS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLG1FQUNUalYsc0JBQVltVixXQUFXLFVBQVUsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDZEQUNWO0FBQUEsdUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNbEIsdUJBQXVCclAsS0FBS3ZELFlBQVksU0FBU3VELEtBQUtyRCxZQUFZLEdBQUcsV0FBVSx5Q0FBd0MsT0FBTSw0QkFDOUosaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFPLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTBTLHVCQUF1QnJQLEtBQUt2RCxZQUFZLFFBQVF1RCxLQUFLckQsWUFBWSxHQUFHLFdBQVUseUNBQXdDLE9BQU0sMkJBQzdKLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVksS0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDLENBQUMrRSxxQkFBcUJULFNBQVNwQix3QkFDNUIsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNaU8sdUJBQXVCeEIsS0FBSyxHQUFHLFdBQVUsNkNBQTRDLE9BQU0sZ0NBQzVILGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWEsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVKLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTXNCLGlCQUFpQnRCLEtBQUssR0FBRyxXQUFVLHVDQUFzQyxPQUFNLGlCQUNoSCxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVEsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQW5FS3RNLEtBQUt6RCxRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0VBO0FBQUEsVUFFUixDQUFDLEtBakZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0ZBO0FBQUEsYUFyR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNHQSxLQXZHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0dBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTb1IsZUFBZSxXQUFVLDJKQUNwRDtBQUFBLGlDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQTtBQUFBLGFBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBdkhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3SEE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUNYO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx3Q0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxPQUFPMU0sU0FBU2pFO0FBQUFBLGdCQUNoQixVQUFVLENBQUFPLFFBQU8yRCxZQUFZLENBQUErRixVQUFTLEVBQUUsR0FBR0EsTUFBTWpLLGlCQUFpQk8sSUFBSSxFQUFFO0FBQUEsZ0JBQ3hFLFdBQVU7QUFBQTtBQUFBLGNBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWtHO0FBQUEsZUFOdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsTUFBTTtBQUFBLGdCQUNOLE9BQU8wRCxTQUFTN0MsU0FBUztBQUFBLGdCQUN6QixVQUFVbUs7QUFBQUEsZ0JBQ1YsY0FBYTtBQUFBLGdCQUFNLFdBQVU7QUFBQTtBQUFBLGNBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtxSDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1YsV0FBQzdHLHFCQUFxQixDQUFDVCxTQUFTcEIsd0JBQzdCLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHFDQUFvQyw0Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUM3RUQsYUFBYTBFLFNBQVMsSUFDbkIxRSxhQUFhcUc7QUFBQUEsWUFBSSxDQUFBTixRQUNiLHVCQUFDLFNBQXFCLFdBQVUscUNBQzVCO0FBQUEscUNBQUMsVUFBSyxXQUFXb0ssaUJBQWtCcEs7QUFBQUEsb0JBQUkrSztBQUFBQSxnQkFBUztBQUFBLGdCQUFHL0ssSUFBSXZCO0FBQUFBLGdCQUFLO0FBQUEsbUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0QsdUJBQUMsVUFBSyxXQUFXNEwsaUJBQWtCNVUsc0JBQVl1SyxJQUFJMEMsUUFBUSxVQUFVLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsaUJBRmpFMUMsSUFBSWdMLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0gsSUFFRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLG9EQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLGFBVmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQSxLQWRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDWCxpQ0FBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBV1osaUJBQWlCLGlDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25ELHVCQUFDLFVBQUssV0FBV0MsaUJBQWtCNVUsc0JBQVl3TSxpQkFBaUJDLFVBQVUsVUFBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBV2tJLGlCQUFpQiw4QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUNoRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsY0FBRzVVLFlBQVl3TSxpQkFBaUJJLG9CQUFvQixVQUFVO0FBQUEsaUJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUEsZUFGdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFXK0gsaUJBQWlCLCtCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pELHVCQUFDLFVBQUssV0FBV0MsaUJBQWlCO0FBQUE7QUFBQSxjQUFHNVUsWUFBWXdNLGlCQUFpQkssc0JBQXNCLFVBQVU7QUFBQSxpQkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0c7QUFBQSxlQUZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQyxDQUFDdkcscUJBQ0UsbUNBQ0k7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsd0RBQ1g7QUFBQSxxQ0FBQyxVQUFLLFdBQVcsR0FBR3FPLGVBQWUsa0JBQWtCLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLFVBQUssV0FBVyxHQUFHQyxlQUFlLGtCQUFtQjVVLHNCQUFZd00saUJBQWlCckQsU0FBUyxVQUFVLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdHO0FBQUEsaUJBRjVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLHFDQUFDLFVBQUssV0FBV3dMLGlCQUNaOU8sbUJBQVNwQix1QkFBdUIsdUJBQXVCLHlCQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVdtUSxpQkFBaUI7QUFBQTtBQUFBLGdCQUFHNVUsWUFBWXdNLGlCQUFpQk0sWUFBWSxVQUFVO0FBQUEsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBGO0FBQUEsaUJBSjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVKLHVCQUFDLFNBQUksV0FBVSx3REFDWDtBQUFBLG1DQUFDLFVBQUssV0FBVyxHQUFHNkgsZUFBZSwwQkFBMEIsNEJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGVBQWUsc0NBQXVDNVUsc0JBQVl3TSxpQkFBaUJVLE9BQU8sVUFBVSxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSDtBQUFBLGVBRjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0E7QUFBQSxXQTNFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU03SCxTQUFTekUsa0JBQWtCN0IsMEJBQTBCdUssU0FBUyxDQUFDLEdBQUcsV0FBVSw4SUFBNkksd0JBQTlQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc1E7QUFBQSxRQUN0UTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBU2tLO0FBQUFBLFlBQ1QsVUFBVTVOLFVBQVVhLG9CQUFvQkU7QUFBQUEsWUFFeEMsV0FBVztBQUFBLDBCQUNUZixTQUFTLDhCQUE4QixpQ0FBaUM7QUFBQSxZQUV4RUEsb0JBQVVhLG9CQUFvQkUsbUJBQzVCLG1DQUNJO0FBQUEscUNBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBRS9DZixTQUFTLDBCQUEwQjtBQUFBLGlCQUh4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBLElBRUEsbUNBQ0k7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUE7QUFBQSxpQkFEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBO0FBQUEsVUFsQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBO0FBQUEsV0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BR0NxQixlQUFlSSxlQUNaO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxRQUFRSjtBQUFBQSxVQUNSLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsVUFDbkMsVUFBVXFKO0FBQUFBLFVBQ1YsUUFBUWxKO0FBQUFBO0FBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXdCO0FBQUEsTUFHM0JJLHNCQUFzQkUsMkJBQTJCLFFBQzlDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxRQUFRRjtBQUFBQSxVQUNSLFNBQVMsTUFBTUMsc0JBQXNCLEtBQUs7QUFBQSxVQUMxQyxRQUFRaUw7QUFBQUEsVUFDUixNQUFNcE8sTUFBTW9ELHNCQUFzQjtBQUFBLFVBQ2xDO0FBQUEsVUFDQTtBQUFBO0FBQUEsUUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNMkM7QUFBQSxNQUc5Q0Usa0JBQWtCdU0sVUFDZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csUUFBUXZNLGtCQUFrQnVNO0FBQUFBLFVBQzFCLFNBQVNHO0FBQUFBLFVBQ1QsT0FBTzFNLGtCQUFrQks7QUFBQUEsVUFDekIsVUFBVUwsa0JBQWtCd0M7QUFBQUEsVUFDNUIsV0FBV3hDLGtCQUFrQnFNO0FBQUFBLFVBQzdCLFVBQVVyTSxrQkFBa0J3TTtBQUFBQSxVQUM1QixTQUFTeE0sa0JBQWtCeU07QUFBQUE7QUFBQUEsUUFQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT3VDO0FBQUEsTUFHM0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLFFBQVF2TSxXQUFXRTtBQUFBQSxVQUNuQixTQUFTdU07QUFBQUEsVUFDVCxPQUFPek0sV0FBV0c7QUFBQUEsVUFDbEIsU0FBU0gsV0FBV0k7QUFBQUE7QUFBQUEsUUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWdDO0FBQUEsU0FyZXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1ZUE7QUFBQSxJQUNDbkI7QUFBQUEsT0F6ZUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBlQTtBQUVSO0FBQUU1QixHQXhtRFdELHVCQUFxQjtBQUFBLFVBQ2ZsSCxXQUNFRCxhQUd5Q1UsYUFDcEJBLGFBYU5DLDBCQUEwQjtBQUFBO0FBQUE2VyxLQW5CakRyUTtBQUFxQixJQUFBcVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVJlZiIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidG9hc3QiLCJGYVNhdmUiLCJGYVNwaW5uZXIiLCJGYVBsdXMiLCJGYVRyYXNoIiwiRmFQZXJjZW50YWdlIiwiRmFUYWdzIiwiRmFXYXJlaG91c2UiLCJ1c2VDcnVkSXRlbSIsInVzZVN1cGVydmlzb3JMb3dQcm9maXRBdXRoIiwiZ2V0QnlJZCIsImdldFNhbGVzT3JkZXJQZW5kaW5nSW52b2ljZUl0ZW1zIiwic2VhcmNoQnlGaWVsZCIsInNhbGVzSW52b2ljZXNNb2R1bGVDb25maWciLCJzYWxlc09yZGVyc01vZHVsZUNvbmZpZyIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwidmVuZGVkb3Jlc01vZHVsZUNvbmZpZyIsImNvbXByYWRvcmVzTW9kdWxlQ29uZmlnIiwibW9uZWRhc01vZHVsZUNvbmZpZyIsInRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMiLCJSZWxhdGlvbmFsSW5wdXQiLCJEZWNpbWFsSW5wdXQiLCJTZWFyY2hNb2RhbCIsIkxvYWRpbmdTcGlubmVyIiwiQWxlcnRNb2RhbCIsIlRvZ2dsZVN3aXRjaCIsIkl0ZW1UYXhNb2RhbCIsIlByb2R1Y3RIaXN0b3J5TW9kYWwiLCJmb3JtYXRWYWx1ZSIsImZvcm1hdFNhbGVzSW52b2ljZU51bWJlciIsInByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlIiwiY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzIiwiY29tcHV0ZUV4ZW1wdERvY3VtZW50VG90YWwiLCJnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyIsImhhc1ZhbGlkQXJnZW50aW5lQ3VpdCIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJyZXNvbHZlSW52b2ljZVNlcmllc0ZvckNsaWVudCIsInNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCIsImluaXRpYWxIaXN0b3J5TW9kYWxTdGF0ZSIsInByaWNlTGlzdENvbHVtbnMiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImNvc3RMaXN0Q29sdW1ucyIsImhlYWRlciIsImFjY2Vzc29yIiwiZm9ybWF0IiwiRU1QVFlfSU5WT0lDRV9JVEVNIiwiaWQiLCJ0ZW1wSWQiLCJsaW5lX251bWJlciIsInByb2R1Y3RfaWQiLCJwcm9kdWN0X2NvZGUiLCJwcm9kdWN0X25hbWUiLCJxdWFudGl0eSIsInBlbmRpbmdfcXVhbnRpdHkiLCJ1bml0X3ByaWNlIiwiY29zdF9wcmljZSIsImRpc2NvdW50X2Ftb3VudCIsImNvbW1pc3Npb25fcGVyY2VudGFnZSIsInRheGVzIiwiYmFzZV9zYWxlc19wcmljZSIsImJhc2VfY29zdF9wcmljZSIsInN0b2NrX3F1YW50aXR5Iiwicm91bmRUb1R3b0RlY2ltYWxzIiwibnVtIiwiTWF0aCIsInJvdW5kIiwiZGVmYXVsdEluaXRpYWxEYXRhIiwiaW52b2ljZV9udW1iZXIiLCJzdGF0dXMiLCJzZXJpZXMiLCJpbnZvaWNlX2RhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImRlbGl2ZXJ5X2RhdGUiLCJ0b3RhbF9hbW91bnQiLCJub3RlcyIsImRlbGl2ZXJ5X2FkZHJlc3MiLCJleGNoYW5nZV9yYXRlIiwiY2xpZW50X2lkIiwic2FsZXNwZXJzb25faWQiLCJidXllcl9pZCIsImN1cnJlbmN5X2lkIiwidHJhbnNwb3J0X2lkIiwic2FsZXNfb3JkZXJfaWQiLCJjbGllbnRfY29kZSIsInNhbGVzcGVyc29uX2NvZGUiLCJidXllcl9jb2RlIiwiY3VycmVuY3lfY29kZSIsInRyYW5zcG9ydF9jb2RlIiwic2FsZXNfb3JkZXJfbnVtYmVyIiwic2FsZXNfb3JkZXJfY29kZSIsImNsaWVudCIsInVuZGVmaW5lZCIsInNhbGVzcGVyc29uIiwiYnV5ZXIiLCJjdXJyZW5jeSIsInRyYW5zcG9ydCIsInNhbGVzX29yZGVyIiwiaXRlbXMiLCJhcHBsaWVkVGF4ZXMiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsInNob3dfY3VycmVuY3lfZXF1aXZhbGVuY2UiLCJpc0xpbmVPdmVyQXZhaWxhYmxlU3RvY2siLCJpdGVtIiwicSIsIk51bWJlciIsInMiLCJzdG9ja0V4Y2Vzc01lc3NhZ2UiLCJuYW1lIiwiY29kZSIsIkZhY3R1cmFzVmVudGFGb3JtUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJtb2RlIiwibG9hZGVkRGF0YSIsImxvYWRpbmciLCJsb2FkaW5nRGF0YSIsImVycm9yIiwic2F2ZUl0ZW0iLCJzYXZpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2V0SXRlbXMiLCJjbGllbnRUYXhlcyIsInNldENsaWVudFRheGVzIiwic2VsZWN0ZWRDbGllbnRDdWl0Iiwic2V0U2VsZWN0ZWRDbGllbnRDdWl0IiwiY2xpZW50VGF4Q29uZGl0aW9uIiwic2V0Q2xpZW50VGF4Q29uZGl0aW9uIiwiaXNDbGllbnRUYXhFeGVtcHQiLCJzZXRJc0NsaWVudFRheEV4ZW1wdCIsInNldEFwcGxpZWRUYXhlcyIsImlzSW5pdGlhbExvYWRpbmciLCJzZXRJc0luaXRpYWxMb2FkaW5nIiwibG9hZGluZ09yZGVyRGF0YSIsInNldExvYWRpbmdPcmRlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRMb2FkaW5nIiwiZ2F0ZVNhdmUiLCJhdXRoTW9kYWwiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwiZWRpdGluZ0l0ZW1JbmRleCIsInNldEVkaXRpbmdJdGVtSW5kZXgiLCJpc0l0ZW1UYXhNb2RhbE9wZW4iLCJzZXRJc0l0ZW1UYXhNb2RhbE9wZW4iLCJjdXJyZW50SXRlbUluZGV4Rm9yVGF4Iiwic2V0Q3VycmVudEl0ZW1JbmRleEZvclRheCIsImhpc3RvcnlNb2RhbFN0YXRlIiwic2V0SGlzdG9yeU1vZGFsU3RhdGUiLCJzdG9ja0FsZXJ0Iiwic2V0U3RvY2tBbGVydCIsIm9wZW4iLCJ0aXRsZSIsIm1lc3NhZ2UiLCJwZW5kaW5nQWZ0ZXJTdG9ja0Fja1JlZiIsImNsaWVudEFkZHJlc3NlcyIsInNldENsaWVudEFkZHJlc3NlcyIsImlzQ3VzdG9tQWRkcmVzcyIsInNldElzQ3VzdG9tQWRkcmVzcyIsInRlbXBEZWxpdmVyeUFkZHJlc3MiLCJzZXRUZW1wRGVsaXZlcnlBZGRyZXNzIiwic2ltYm9sb01vbmVkYSIsInNldFNpbWJvbG9Nb25lZGEiLCJpc0V4Y2hhbmdlUmF0ZVJlYWRvbmx5Iiwic2V0SXNFeGNoYW5nZVJhdGVSZWFkb25seSIsImVmZmVjdGl2ZUV4Y2hhbmdlUmF0ZSIsInJhdGUiLCJjYWxjdWxhdGVJdGVtVGF4ZXMiLCJsZW5ndGgiLCJ0YXhCYXNlIiwibmV0QmFzZSIsImxvYWRFZGl0RGF0YSIsImJhc2VSb3V0ZSIsImh5ZHJhdGVkRGF0YSIsInJlbGF0aW9uYWxGaWVsZHMiLCJjb2RlRmllbGQiLCJjbGllbnRfbmFtZSIsIm5hbWVGaWVsZCIsInNhbGVzcGVyc29uX25hbWUiLCJidXllcl9uYW1lIiwiY3VycmVuY3lfbmFtZSIsInRyYW5zcG9ydF9uYW1lIiwib3JkZXJfbnVtYmVyIiwiU3RyaW5nIiwibG9hZGVkQ2xpZW50VGF4ZXMiLCJpc0V4ZW1wdE9uTG9hZCIsImNsaWVudERhdGEiLCJlbmRwb2ludCIsImN1aXQiLCJ0YXgiLCJyZWxhdGVkVGF4ZXMiLCJzaGlwYWRkcmVzcyIsImlzQ3VzdG9tIiwiaW5jbHVkZXMiLCJtYXBwZWRFZGl0SXRlbXMiLCJtYXAiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiaW52b2ljZUlkTnVtIiwicGVuZGluZ1JlcyIsImV4Y2x1ZGVTYWxlc0ludm9pY2VJZCIsImlzTmFOIiwiaW52SXRlbSIsInNpZCIsInNhbGVzX29yZGVyX2l0ZW1faWQiLCJyb3ciLCJmaW5kIiwicCIsIm1heFAiLCJxdWFudGl0eV9wZW5kaW5nIiwiZmluYWxFZGl0SXRlbXMiLCJwcmV2IiwibG9hZEVycm9yIiwiZXhjaGFuZ2VSYXRlIiwicHJldkl0ZW1zIiwiYmFzZVByaWNlIiwiYmFzZUNvc3QiLCJuZXdJdGVtIiwidGhlbiIsImV4ZW1wdCIsIm5ld0NsaWVudFRheGVzIiwiY2F0Y2giLCJjYWxjdWxhdGVkVG90YWxzIiwic3VidG90YWwiLCJyZWR1Y2UiLCJzdW0iLCJ0b3RhbEl0ZW1EaXNjb3VudHMiLCJnbG9iYWxEaXNjb3VudEFtb3VudCIsInRvdGFsVGF4ZXMiLCJpdGVtVGF4QW1vdW50IiwiaXRlbVN1bSIsImFtb3VudCIsInRvdGFsIiwiaGFuZGxlSGVhZGVyQ2hhbmdlIiwiZSIsInRhcmdldCIsImZpbmFsVmFsdWUiLCJIVE1MSW5wdXRFbGVtZW50IiwidHlwZSIsImNoZWNrZWQiLCJ2YWx1ZSIsImFwcGx5SGVhZGVyU2VsZWN0aW9uIiwiZmllbGQiLCJzZWxlY3RlZEl0ZW0iLCJtb2R1bGVDb25maWdNYXAiLCJtb2R1bGVDb25maWciLCJpbmZvIiwiZnVsbE9yZGVyIiwib3JkZXJDbGllbnRFeGVtcHQiLCJvcmRlckNsaWVudFRheENvbmRpdGlvbiIsIm9yZGVyQ2xpZW50Rm9yU2VyaWVzIiwicmVzb2x2ZWRPcmRlclNlcmllcyIsImlzX2V4Y2hhbmdlX3JhdGVfZml4ZWQiLCJleGNsdWRlSW52b2ljZUlkIiwicGVuZGluZ0J5T3JkZXJJdGVtSWQiLCJNYXAiLCJzaXplIiwid2FybiIsImZvckVhY2giLCJzZXQiLCJuZXdJdGVtcyIsImZpbHRlciIsImhhcyIsInF0eVBlbmRpbmciLCJnZXQiLCJpbnZvaWNlSXRlbSIsIml0ZW1OZXQiLCJzYWxlc19vcmRlcl9uYW1lIiwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyIiwiYWRkcmVzcyIsImkiLCJpdGVtRGlzY291bnQiLCJnbG9iYWxEaXNjb3VudCIsInJlc29sdmVkSXRlbSIsInJhd1NlcmllIiwic2VyaWUiLCJ0cmltIiwidXBkYXRlZERhdGEiLCJhZGRyZXNzZXMiLCJzYWxlc3JlcCIsInNhbGVzUmVwUmVsYXRpb24iLCJoYW5kbGVPcGVuTW9kYWwiLCJjb25maWciLCJpdGVtSW5kZXgiLCJpbml0aWFsRmlsdGVycyIsImhhbmRsZVNlbGVjdE1vZGFsIiwic2t1VmFsdWUiLCJza3UiLCJwcm9kdWN0IiwiZmllbGROYW1lIiwidG9TdHJpbmciLCJzdWdnZXN0ZWRfcHJpY2UiLCJzYWxlX3ByaWNlIiwiY29zdF9jdXJyZW5jeSIsImhhbmRsZURlbGl2ZXJ5QWRkcmVzc0NoYW5nZSIsImhhbmRsZUl0ZW1DaGFuZ2UiLCJpbmRleCIsIm51bUZpZWxkcyIsInN0b3JlZFZhbHVlIiwicHJldlJvdyIsIm1heFBlbmRpbmciLCJuZXdWYWx1ZSIsImRpc3BhdGNoSXRlbU51bWVyaWNDaGFuZ2UiLCJoYW5kbGVJdGVtQ29kZVN1Ym1pdCIsImN1cnJlbnRQcmljZSIsImN1cnJlbnRDb3N0IiwiY2FsY3VsYXRlZFByaWNlIiwiY2FsY3VsYXRlZENvc3QiLCJ1cGRhdGVkSXRlbSIsInN1Y2Nlc3MiLCJlcnIiLCJoYW5kbGVJdGVtQ29kZUNoYW5nZSIsIm5ld0NvZGUiLCJoYW5kbGVJdGVtQXV0b2NvbXBsZXRlU2VsZWN0IiwiZnVsbFByb2R1Y3QiLCJjb25zb2xlIiwiaGFuZGxlSXRlbUNsZWFyIiwiaGFuZGxlQWRkSXRlbSIsImhhbmRsZVJlbW92ZUl0ZW0iLCJfIiwiaGFuZGxlT3Blbkl0ZW1UYXhNb2RhbCIsImhhbmRsZVNhdmVJdGVtVGF4ZXMiLCJoYW5kbGVUYXhNb2RlQ2hhbmdlIiwiZW5hYmxlZCIsImV4ZWN1dGVTYXZlIiwiY2xlYW5JdGVtcyIsIl91aU9yZGVyTGluZUlkIiwicmVzdCIsImhlYWRlclBheWxvYWQiLCJzYW5pdGl6ZWQiLCJkYXRhVG9TZW5kIiwidCIsInNhdmVkIiwiYXBpRXJyb3IiLCJoYW5kbGVTYXZlIiwiY2xpZW50Q3VpdCIsInByb2NlZWRUb1NhdmUiLCJvdmVyU3RvY2tJdGVtIiwiY3VycmVudCIsImhhbmRsZUhlYWRlckNvZGVDaGFuZ2UiLCJoYW5kbGVIZWFkZXJDb2RlU3VibWl0IiwiY29kZVZhbHVlIiwiaGFuZGxlSGVhZGVyQ2xlYXIiLCJoYW5kbGVPcGVuSGlzdG9yeU1vZGFsIiwicHJvZHVjdElkIiwicHJvZHVjdE5hbWUiLCJpc09wZW4iLCJjbGllbnRJZCIsImNvbHVtbnMiLCJoYW5kbGVDbG9zZUhpc3RvcnlNb2RhbCIsImhhbmRsZUNsb3NlU3RvY2tBbGVydCIsImNvbnRpbnVlU2F2ZSIsImhhbmRsZVF1YW50aXR5Qmx1ciIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsImFmaXBfcG9zIiwiZGlzY291bnQiLCJsaW5lU3VidG90YWwiLCJsaW5lQ29zdCIsInByb2ZpdCIsIml0ZW1UYXhUb3RhbCIsImxpbmVUb3RhbCIsInNlYXJjaFBhcmFtcyIsIm9uU2VsZWN0IiwidGF4X25hbWUiLCJ0YXhfaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGYWN0dXJhc1ZlbnRhRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFycyAqL1xuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNhdmUsIEZhU3Bpbm5lciwgRmFQbHVzLCBGYVRyYXNoLCBGYVBlcmNlbnRhZ2UsIEZhVGFncywgRmFXYXJlaG91c2UgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHVzZVN1cGVydmlzb3JMb3dQcm9maXRBdXRoIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlU3VwZXJ2aXNvckxvd1Byb2ZpdEF1dGgnO1xuaW1wb3J0IHsgZ2V0QnlJZCwgZ2V0U2FsZXNPcmRlclBlbmRpbmdJbnZvaWNlSXRlbXMsIHNlYXJjaEJ5RmllbGQgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbi8vIFVzYW1vcyBjb25maWcgeSB0aXBvcyBkZSBGYWN0dXJhXG5pbXBvcnQgeyBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLCB0eXBlIFNhbGVzSW52b2ljZSwgdHlwZSBTYWxlc0ludm9pY2VJdGVtIH0gZnJvbSAnLi4vZmFjdHVyYXNfdmVudGEuY29uZmlnJztcbi8vIEltcG9ydGFtb3MgY29uZmlnIHkgdGlwbyBkZSBQZWRpZG8gcGFyYSBsYSByZWxhY2nDs25cbmltcG9ydCB7IHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLCB0eXBlIFNhbGVzT3JkZXIsIHR5cGUgU2FsZXNPcmRlckl0ZW0gYXMgT3JkZXJJdGVtIH0gZnJvbSAnLi4vLi4vcGVkaWRvc192ZW50YS9wZWRpZG9zX3ZlbnRhX2NvbmZpZyc7XG5cbi8vIEltcG9ydGFtb3MgdG9kYXMgbGFzIGNvbmZpZ3MgcGFyYSBsb3MgUmVsYXRpb25hbElucHV0XG5pbXBvcnQgeyBjbGllbnRlc01vZHVsZUNvbmZpZywgdHlwZSBDbGllbnRlIH0gZnJvbSAnLi4vLi4vY2xpZW50ZXMvY2xpZW50ZXMuY29uZmlnJztcbmltcG9ydCB7IHZlbmRlZG9yZXNNb2R1bGVDb25maWcsIHR5cGUgVmVuZGVkb3IgfSBmcm9tICcuLi8uLi92ZW5kZWRvcmVzL3ZlbmRlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLCB0eXBlIENvbXByYWRvciB9IGZyb20gJy4uLy4uL2NvbXByYWRvcmVzL2NvbXByYWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBtb25lZGFzTW9kdWxlQ29uZmlnLCB0eXBlIE1vbmVkYSB9IGZyb20gJy4uLy4uL21vbmVkYXMvbW9uZWRhcy5jb25maWcnO1xuaW1wb3J0IHsgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcsIHR5cGUgVHJhbnNwb3J0ZSB9IGZyb20gJy4uLy4uL3RyYW5zcG9ydGVzL3RyYW5zcG9ydGVzLmNvbmZpZyc7XG5pbXBvcnQgeyBhcnRpY3Vsb3NNb2R1bGVDb25maWcsIGFydGljdWxvc0l0ZW1TZWFyY2hGaWx0ZXJzIH0gZnJvbSAnLi4vLi4vYXJ0aWN1bG9zL2FydGljdWxvcy5jb25maWcnO1xuXG4vLyBJbXBvcnRhbW9zIENvbXBvbmVudGVzXG5pbXBvcnQgeyBSZWxhdGlvbmFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9SZWxhdGlvbmFsSW5wdXQnO1xuaW1wb3J0IHsgRGVjaW1hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vRGVjaW1hbElucHV0JztcbmltcG9ydCB7IFNlYXJjaE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IEFsZXJ0TW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0FsZXJ0TW9kYWwnO1xuaW1wb3J0IHsgVG9nZ2xlU3dpdGNoIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Ub2dnbGVTd2l0Y2gnO1xuaW1wb3J0IHsgSXRlbVRheE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vSXRlbVRheE1vZGFsJztcbmltcG9ydCB7IFByb2R1Y3RIaXN0b3J5TW9kYWwgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Qcm9kdWN0SGlzdG9yeU1vZGFsJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlLCBmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcHJvZHVjdENvc3RUb0Jhc2UnO1xuaW1wb3J0IHsgdHlwZSBBcHBsaWVkVGF4LCB0eXBlIFJlbGF0ZWRUYXggYXMgQ2xpZW50VGF4IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzJztcbmltcG9ydCB7IGNvbXB1dGVTYWxlc0FwcGxpZWRUYXhlcyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3NhbGVzUmVsYXRlZFRheENvbXB1dGF0aW9uJztcbmltcG9ydCB7XG4gICAgY29tcHV0ZUV4ZW1wdERvY3VtZW50VG90YWwsXG4gICAgZ2V0RWZmZWN0aXZlQ2xpZW50VGF4ZXMsXG4gICAgaGFzVmFsaWRBcmdlbnRpbmVDdWl0LFxuICAgIGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQsXG4gICAgcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JDbGllbnQsXG4gICAgc2FuaXRpemVUYXhQYXlsb2FkRm9yRXhlbXB0Q2xpZW50LFxufSBmcm9tICcuLi8uLi8uLi91dGlscy9jbGllbnRUYXhFeGVtcHRpb24nO1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcsIENvbHVtbkRlZmluaXRpb24gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgaW5pdGlhbEhpc3RvcnlNb2RhbFN0YXRlLCBwcmljZUxpc3RDb2x1bW5zLCB0eXBlIEhpc3RvcnlNb2RhbFN0YXRlIH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvaGlzdG9yeU1vZGFsJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5cbi8vIC0tLSBJTlRFUkZBQ0VTIFkgVElQT1MgLS0tXG5cbi8vIEludGVyZmF6IGV4dGVuZGlkYSBwYXJhIGVsIGl0ZW0gREVOVFJPIGRlbCBmb3JtdWxhcmlvXG50eXBlIEZvcm1TYWxlc0ludm9pY2VJdGVtID0gU2FsZXNJbnZvaWNlSXRlbSAmIHtcbiAgICB0ZW1wSWQ6IHN0cmluZztcbiAgICBjb3N0X3ByaWNlOiBudW1iZXI7IC8vIFBhcmEgY2FsY3VsYXIgdXRpbGlkYWRcbiAgICBjb21taXNzaW9uX3BlcmNlbnRhZ2U6IG51bWJlcjsgLy8g4pyFIE5VRVZPOiBDYW1wbyBkZSBjb21pc2nDs25cbiAgICB0YXhlczogQXBwbGllZFRheFtdO1xuICAgIC8qKiBJZCBsw61uZWEgZGVsIHBlZGlkbzsgc29sbyBVSSwgcGFyYSBlbXBhcmVqYXIgcGVuZGllbnRlIGVuIGVkaWNpw7NuICovXG4gICAgc2FsZXNfb3JkZXJfaXRlbV9pZD86IG51bWJlcjtcbn07XG5cbi8vIFRpcG9zIHBhcmEgZWwgbW9kYWwgZGUgaGlzdG9yaWFsIChjb3BpYWRvcyBkZSBQZWRpZG9zKVxuXG5pbnRlcmZhY2UgQ29zdEhpc3RvcnlJdGVtIHtcbiAgICBpZDogbnVtYmVyO1xuICAgIHB1cmNoYXNlX2RhdGU6IHN0cmluZzsgcHJpY2VfY29zdDogbnVtYmVyOyBkb2N1bWVudF9udW1iZXI6IHN0cmluZzsgdmVuZG9yX25hbWU6IHN0cmluZzsgcXVhbnRpdHk6IG51bWJlcjtcbn1cblxuLy8gQ29sdW1uYXMgcGFyYSBlbCBtb2RhbCBkZSBoaXN0b3JpYWwgKGNvcGlhZGFzIGRlIFBlZGlkb3MpXG5cbmNvbnN0IGNvc3RMaXN0Q29sdW1uczogQ29sdW1uRGVmaW5pdGlvbjxDb3N0SGlzdG9yeUl0ZW0+W10gPSBbXG4gICAgeyBoZWFkZXI6ICdGZWNoYSBDb21wcmEnLCBhY2Nlc3NvcjogJ3B1cmNoYXNlX2RhdGUnLCBmb3JtYXQ6ICdkYXRlJyB9LFxuICAgIHsgaGVhZGVyOiAnRmFjdHVyYSBDb21wcmEnLCBhY2Nlc3NvcjogJ2RvY3VtZW50X251bWJlcicgfSxcbiAgICB7IGhlYWRlcjogJ1Byb3ZlZWRvcicsIGFjY2Vzc29yOiAndmVuZG9yX25hbWUnIH0sXG4gICAgeyBoZWFkZXI6ICdDb3N0byBVbml0LicsIGFjY2Vzc29yOiAncHJpY2VfY29zdCcsIGZvcm1hdDogJ2N1cnJlbmN5JyB9LFxuICAgIHsgaGVhZGVyOiAnQ2FudGlkYWQnLCBhY2Nlc3NvcjogJ3F1YW50aXR5JyB9LFxuXTtcblxuLy8gRXN0YWRvIHBhcmEgZWwgbW9kYWwgZGUgaGlzdG9yaWFsXG5cblxuLy8gVGFyZ2V0IHBhcmEgZWwgbW9kYWwgcHJpbmNpcGFsXG50eXBlIEVkaXRpbmdUYXJnZXQgPSAnY2xpZW50JyB8ICdzYWxlc3BlcnNvbicgfCAnYnV5ZXInIHwgJ2N1cnJlbmN5JyB8ICd0cmFuc3BvcnQnIHwgJ3NhbGVzX29yZGVyJyB8ICdpdGVtJztcbnR5cGUgSGVhZGVyRmllbGQgPSAnY2xpZW50JyB8ICdzYWxlc3BlcnNvbicgfCAnYnV5ZXInIHwgJ2N1cnJlbmN5JyB8ICd0cmFuc3BvcnQnIHwgJ3NhbGVzX29yZGVyJztcblxuLy8gSXRlbSB2YWPDrW9cbmNvbnN0IEVNUFRZX0lOVk9JQ0VfSVRFTTogRm9ybVNhbGVzSW52b2ljZUl0ZW0gPSB7XG4gICAgaWQ6IDAsIHRlbXBJZDogJycsIGxpbmVfbnVtYmVyOiAwLCBwcm9kdWN0X2lkOiAwLFxuICAgIHByb2R1Y3RfY29kZTogJycsIHByb2R1Y3RfbmFtZTogJycsIHF1YW50aXR5OiAxLCBwZW5kaW5nX3F1YW50aXR5OiAwLFxuICAgIHVuaXRfcHJpY2U6IDAsIGNvc3RfcHJpY2U6IDAsIGRpc2NvdW50X2Ftb3VudDogMCxcbiAgICBjb21taXNzaW9uX3BlcmNlbnRhZ2U6IDAsIC8vIOKchSBOVUVWT1xuICAgIHRheGVzOiBbXSxcbiAgICBiYXNlX3NhbGVzX3ByaWNlOiAwLFxuICAgIGJhc2VfY29zdF9wcmljZTogMCxcbiAgICBzdG9ja19xdWFudGl0eTogMCxcbn07XG5cbmNvbnN0IHJvdW5kVG9Ud29EZWNpbWFscyA9IChudW06IG51bWJlcik6IG51bWJlciA9PiB7XG4gICAgcmV0dXJuIE1hdGgucm91bmQobnVtICogMTAwKSAvIDEwMDtcbn07XG5cblxuLy8gRGF0b3MgaW5pY2lhbGVzIHBhcmEgZWwgZm9ybXVsYXJpbyAoYmFzZSlcbmNvbnN0IGRlZmF1bHRJbml0aWFsRGF0YTogUGFydGlhbDxTYWxlc0ludm9pY2U+ID0ge1xuICAgIGlkOiAwLCBpbnZvaWNlX251bWJlcjogJycsXG4gICAgc3RhdHVzOiAnMScsIC8vIFBlbmRpZW50ZVxuICAgIHNlcmllczogJ0EnLCAvLyDinIUgTlVFVk86IFNlcmllIHBvciBkZWZlY3RvXG4gICAgaW52b2ljZV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICBkZWxpdmVyeV9kYXRlOiBudWxsLFxuICAgIHRvdGFsX2Ftb3VudDogMCwgbm90ZXM6IG51bGwsIGRlbGl2ZXJ5X2FkZHJlc3M6IG51bGwsXG4gICAgZGlzY291bnRfYW1vdW50OiAwLCBleGNoYW5nZV9yYXRlOiAxLFxuICAgIGNsaWVudF9pZDogbnVsbCwgc2FsZXNwZXJzb25faWQ6IG51bGwsIGJ1eWVyX2lkOiBudWxsLFxuICAgIGN1cnJlbmN5X2lkOiBudWxsLCB0cmFuc3BvcnRfaWQ6IG51bGwsIHNhbGVzX29yZGVyX2lkOiBudWxsLFxuICAgIGNsaWVudF9jb2RlOiBudWxsLCBzYWxlc3BlcnNvbl9jb2RlOiBudWxsLCBidXllcl9jb2RlOiBudWxsLFxuICAgIGN1cnJlbmN5X2NvZGU6IG51bGwsIHRyYW5zcG9ydF9jb2RlOiBudWxsLCBzYWxlc19vcmRlcl9udW1iZXI6IG51bGwsXG4gICAgc2FsZXNfb3JkZXJfY29kZTogbnVsbCwgLy8gbWlzbW8gdmFsb3IgcXVlIG9yZGVyX251bWJlcjsgUmVsYXRpb25hbElucHV0IHVzYSAqX2NvZGVcbiAgICBjbGllbnQ6IHVuZGVmaW5lZCwgc2FsZXNwZXJzb246IHVuZGVmaW5lZCwgYnV5ZXI6IHVuZGVmaW5lZCxcbiAgICBjdXJyZW5jeTogdW5kZWZpbmVkLCB0cmFuc3BvcnQ6IHVuZGVmaW5lZCwgc2FsZXNfb3JkZXI6IHVuZGVmaW5lZCxcbiAgICBpdGVtczogW10sIHRheGVzOiBbXSwgYXBwbGllZFRheGVzOiBbXSxcbiAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsXG4gICAgc2hvd19jdXJyZW5jeV9lcXVpdmFsZW5jZTogZmFsc2UsXG59O1xuXG5jb25zdCBpc0xpbmVPdmVyQXZhaWxhYmxlU3RvY2sgPSAoaXRlbTogRm9ybVNhbGVzSW52b2ljZUl0ZW0pOiBib29sZWFuID0+IHtcbiAgICBpZiAoIWl0ZW0ucHJvZHVjdF9pZCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IHEgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgfHwgMDtcbiAgICBjb25zdCBzID0gTnVtYmVyKGl0ZW0uc3RvY2tfcXVhbnRpdHkpIHx8IDA7XG4gICAgcmV0dXJuIHEgPiBzO1xufTtcblxuY29uc3Qgc3RvY2tFeGNlc3NNZXNzYWdlID0gKGl0ZW06IEZvcm1TYWxlc0ludm9pY2VJdGVtKTogc3RyaW5nID0+IHtcbiAgICBjb25zdCBxID0gTnVtYmVyKGl0ZW0ucXVhbnRpdHkpIHx8IDA7XG4gICAgY29uc3QgcyA9IE51bWJlcihpdGVtLnN0b2NrX3F1YW50aXR5KSB8fCAwO1xuICAgIGNvbnN0IG5hbWUgPSBpdGVtLnByb2R1Y3RfbmFtZSB8fCAnZWwgYXJ0w61jdWxvJztcbiAgICBjb25zdCBjb2RlID0gaXRlbS5wcm9kdWN0X2NvZGUgPyBgICgke2l0ZW0ucHJvZHVjdF9jb2RlfSlgIDogJyc7XG4gICAgcmV0dXJuIGBFc3TDoSBpbnRlbnRhbmRvIGZhY3R1cmFyICR7cX0gdW5pZGFkKGVzKSBkZSBcIiR7bmFtZX1cIiR7Y29kZX0gcGVybyBlbCBzdG9jayBkaXNwb25pYmxlIGVzICR7c30uYDtcbn07XG5cblxuZXhwb3J0IGNvbnN0IEZhY3R1cmFzVmVudGFGb3JtUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IG1vZGUgPSBpZCA/ICdlZGl0JyA6ICdjcmVhdGUnO1xuXG4gICAgY29uc3QgeyBpdGVtOiBsb2FkZWREYXRhLCBsb2FkaW5nOiBsb2FkaW5nRGF0YSwgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFNhbGVzSW52b2ljZT4oc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IHsgc2F2ZUl0ZW0sIGxvYWRpbmc6IHNhdmluZyB9ID0gdXNlQ3J1ZEl0ZW08U2FsZXNJbnZvaWNlPihzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICAvLyAtLS0gRVNUQURPUyAtLS1cbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPFBhcnRpYWw8U2FsZXNJbnZvaWNlPj4oZGVmYXVsdEluaXRpYWxEYXRhKTtcbiAgICBjb25zdCBbaXRlbXMsIHNldEl0ZW1zXSA9IHVzZVN0YXRlPEZvcm1TYWxlc0ludm9pY2VJdGVtW10+KFtdKTtcbiAgICBjb25zdCBbY2xpZW50VGF4ZXMsIHNldENsaWVudFRheGVzXSA9IHVzZVN0YXRlPENsaWVudFRheFtdPihbXSk7XG4gICAgY29uc3QgW3NlbGVjdGVkQ2xpZW50Q3VpdCwgc2V0U2VsZWN0ZWRDbGllbnRDdWl0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtjbGllbnRUYXhDb25kaXRpb24sIHNldENsaWVudFRheENvbmRpdGlvbl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbaXNDbGllbnRUYXhFeGVtcHQsIHNldElzQ2xpZW50VGF4RXhlbXB0XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYXBwbGllZFRheGVzLCBzZXRBcHBsaWVkVGF4ZXNdID0gdXNlU3RhdGU8QXBwbGllZFRheFtdPihbXSk7IC8vIFBhcmEgaW1wdWVzdG9zIGdsb2JhbGVzXG4gICAgY29uc3QgW2lzSW5pdGlhbExvYWRpbmcsIHNldElzSW5pdGlhbExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gICAgY29uc3QgW2xvYWRpbmdPcmRlckRhdGEsIHNldExvYWRpbmdPcmRlckRhdGFdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHsgZ2F0ZVNhdmUsIGF1dGhNb2RhbCB9ID0gdXNlU3VwZXJ2aXNvckxvd1Byb2ZpdEF1dGgoKTtcblxuICAgIC8vIEVzdGFkb3MgZGUgTW9kYWxlc1xuICAgIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtlZGl0aW5nVGFyZ2V0LCBzZXRFZGl0aW5nVGFyZ2V0XSA9IHVzZVN0YXRlPEVkaXRpbmdUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbbW9kYWxDb25maWcsIHNldE1vZGFsQ29uZmlnXSA9IHVzZVN0YXRlPE1vZHVsZUNvbmZpZzxhbnk+ICYgeyBpbml0aWFsRmlsdGVycz86IGFueSB9IHwgbnVsbD4obnVsbCk7XG4gICAgY29uc3QgW2VkaXRpbmdJdGVtSW5kZXgsIHNldEVkaXRpbmdJdGVtSW5kZXhdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBbaXNJdGVtVGF4TW9kYWxPcGVuLCBzZXRJc0l0ZW1UYXhNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtjdXJyZW50SXRlbUluZGV4Rm9yVGF4LCBzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4XSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuXG4gICAgY29uc3QgW2hpc3RvcnlNb2RhbFN0YXRlLCBzZXRIaXN0b3J5TW9kYWxTdGF0ZV0gPSB1c2VTdGF0ZTxIaXN0b3J5TW9kYWxTdGF0ZT4oaW5pdGlhbEhpc3RvcnlNb2RhbFN0YXRlKTtcblxuICAgIGNvbnN0IFtzdG9ja0FsZXJ0LCBzZXRTdG9ja0FsZXJ0XSA9IHVzZVN0YXRlPHsgb3BlbjogYm9vbGVhbjsgdGl0bGU6IHN0cmluZzsgbWVzc2FnZTogc3RyaW5nIH0+KHtcbiAgICAgICAgb3BlbjogZmFsc2UsXG4gICAgICAgIHRpdGxlOiAnJyxcbiAgICAgICAgbWVzc2FnZTogJycsXG4gICAgfSk7XG4gICAgY29uc3QgcGVuZGluZ0FmdGVyU3RvY2tBY2tSZWYgPSB1c2VSZWY8KCgpID0+IHZvaWQpIHwgbnVsbD4obnVsbCk7XG5cbiAgICBjb25zdCBbY2xpZW50QWRkcmVzc2VzLCBzZXRDbGllbnRBZGRyZXNzZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgICBjb25zdCBbaXNDdXN0b21BZGRyZXNzLCBzZXRJc0N1c3RvbUFkZHJlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt0ZW1wRGVsaXZlcnlBZGRyZXNzLCBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbc2ltYm9sb01vbmVkYSwgc2V0U2ltYm9sb01vbmVkYV0gPSB1c2VTdGF0ZSgnJCcpO1xuICAgIGNvbnN0IFtpc0V4Y2hhbmdlUmF0ZVJlYWRvbmx5LCBzZXRJc0V4Y2hhbmdlUmF0ZVJlYWRvbmx5XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuXG4gICAgY29uc3QgZWZmZWN0aXZlRXhjaGFuZ2VSYXRlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJhdGUgPSBOdW1iZXIoZm9ybURhdGEuZXhjaGFuZ2VfcmF0ZSkgfHwgMTtcbiAgICAgICAgLy8gU2kgZWwgY8OzZGlnbyBkZSBtb25lZGEgZXMgJzAxJyAoTW9uZWRhIExvY2FsL0Jhc2UpLCBsYSB0YXNhIGVmZWN0aXZhIGVzIDEuXG4gICAgICAgIHJldHVybiBmb3JtRGF0YS5jdXJyZW5jeV9jb2RlID09PSAnMDEnID8gMSA6IHJhdGU7XG4gICAgfSwgW2Zvcm1EYXRhLmV4Y2hhbmdlX3JhdGUsIGZvcm1EYXRhLmN1cnJlbmN5X2NvZGVdKTtcblxuICAgIGNvbnN0IGNhbGN1bGF0ZUl0ZW1UYXhlcyA9IChpdGVtOiBGb3JtU2FsZXNJbnZvaWNlSXRlbSwgdGF4ZXM6IENsaWVudFRheFtdID0gY2xpZW50VGF4ZXMpOiBBcHBsaWVkVGF4W10gPT4ge1xuICAgICAgICBpZiAoIXRheGVzIHx8IHRheGVzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCB0YXhCYXNlID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKSAtIChOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDApO1xuICAgICAgICByZXR1cm4gY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgICAgIG5ldEJhc2U6IHRheEJhc2UsXG4gICAgICAgICAgICBjbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICB0YXhlcyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyAtLS0gRUZFQ1RPUyAtLS1cblxuICAgIC8vIEVmZWN0byBwYXJhIGNhcmdhIGluaWNpYWwgKGVkaXQpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgbG9hZEVkaXREYXRhID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKG1vZGUgPT09ICdlZGl0JyAmJiBsb2FkZWREYXRhKSB7XG4gICAgICAgICAgICAgICAgLy8g4pyFIFZhbGlkYXIgcXVlIG5vIGVzdMOpIGVudmlhZGEgYSBBUkNBXG4gICAgICAgICAgICAgICAgaWYgKGxvYWRlZERhdGEuc3RhdHVzID09PSAnSVNTVUVEJykge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVlZGUgZWRpdGFyIHVuYSBmYWN0dXJhIHF1ZSBoYSBzaWRvIGVudmlhZGEgYSBBUkNBLicpO1xuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgICAgICAvLyBcIkFwbGFuYW1vc1wiIGxvcyBkYXRvcyByZWxhY2lvbmFsZXMgcXVlIHZpZW5lbiBkZSBsYSBBUElcbiAgICAgICAgICAgICAgICBjb25zdCBoeWRyYXRlZERhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRJbml0aWFsRGF0YSxcbiAgICAgICAgICAgICAgICAgICAgLi4ubG9hZGVkRGF0YSxcbiAgICAgICAgICAgICAgICAgICAgLy8gQXBsYW5hbW9zIENsaWVudGVcbiAgICAgICAgICAgICAgICAgICAgY2xpZW50X2NvZGU6IGxvYWRlZERhdGEuY2xpZW50Py5bY2xpZW50ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEuY29kZUZpZWxkIGFzIGtleW9mIENsaWVudGVdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgY2xpZW50X25hbWU6IGxvYWRlZERhdGEuY2xpZW50Py5bY2xpZW50ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIENsaWVudGVdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgLy8gQXBsYW5hbW9zIFZlbmRlZG9yXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX2NvZGU6IGxvYWRlZERhdGEuc2FsZXNwZXJzb24/Llt2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMhLmNvZGVGaWVsZCBhcyBrZXlvZiBWZW5kZWRvcl0gYXMgc3RyaW5nIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBzYWxlc3BlcnNvbl9uYW1lOiBsb2FkZWREYXRhLnNhbGVzcGVyc29uPy5bdmVuZGVkb3Jlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzIS5uYW1lRmllbGQgYXMga2V5b2YgVmVuZGVkb3JdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgLy8gLi4uIChyZXBldGlyIHBhcmEgYnV5ZXIsIGN1cnJlbmN5LCB0cmFuc3BvcnQpIC4uLlxuICAgICAgICAgICAgICAgICAgICBidXllcl9jb2RlOiBsb2FkZWREYXRhLmJ1eWVyPy5bY29tcHJhZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEuY29kZUZpZWxkIGFzIGtleW9mIENvbXByYWRvcl0gYXMgc3RyaW5nIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBidXllcl9uYW1lOiBsb2FkZWREYXRhLmJ1eWVyPy5bY29tcHJhZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIENvbXByYWRvcl0gYXMgc3RyaW5nIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBjdXJyZW5jeV9jb2RlOiBsb2FkZWREYXRhLmN1cnJlbmN5Py5bbW9uZWRhc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzIS5jb2RlRmllbGQgYXMga2V5b2YgTW9uZWRhXSBhcyBzdHJpbmcgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbmN5X25hbWU6IGxvYWRlZERhdGEuY3VycmVuY3k/Llttb25lZGFzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMhLm5hbWVGaWVsZCBhcyBrZXlvZiBNb25lZGFdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0X2NvZGU6IGxvYWRlZERhdGEudHJhbnNwb3J0Py5bdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEuY29kZUZpZWxkIGFzIGtleW9mIFRyYW5zcG9ydGVdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0X25hbWU6IGxvYWRlZERhdGEudHJhbnNwb3J0Py5bdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIFRyYW5zcG9ydGVdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgLy8gQXBsYW5hbW9zIFBlZGlkbyBPcmlnZW4gKGPDs2RpZ28gdmlzaWJsZSA9IG9yZGVyX251bWJlcilcbiAgICAgICAgICAgICAgICAgICAgc2FsZXNfb3JkZXJfbnVtYmVyOiBsb2FkZWREYXRhLnNhbGVzX29yZGVyPy5vcmRlcl9udW1iZXIgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgc2FsZXNfb3JkZXJfY29kZTpcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlZERhdGEuc2FsZXNfb3JkZXI/Lm9yZGVyX251bWJlciAhPSBudWxsICYmIGxvYWRlZERhdGEuc2FsZXNfb3JkZXI/Lm9yZGVyX251bWJlciAhPT0gJydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFN0cmluZyhsb2FkZWREYXRhLnNhbGVzX29yZGVyLm9yZGVyX251bWJlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGwsXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGxldCBsb2FkZWRDbGllbnRUYXhlczogQ2xpZW50VGF4W10gPSBbXTtcbiAgICAgICAgICAgICAgICBsZXQgaXNFeGVtcHRPbkxvYWQgPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIENhcmdhciBJbXB1ZXN0b3MgZGVsIENsaWVudGUgKHlhIHF1ZSBsb3Mgb2JqZXRvcyBhcGxhbmFkb3MgeWEgZXN0w6FuKVxuICAgICAgICAgICAgICAgICAgICBpZiAoaHlkcmF0ZWREYXRhLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVXNhbW9zIGVsICdjbGllbnQnIHlhIGNhcmdhZG8gc2kgZXhpc3RlLCBzaSBubywgbG8gYnVzY2Ftb3NcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNsaWVudERhdGEgPSBoeWRyYXRlZERhdGEuY2xpZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBoeWRyYXRlZERhdGEuY2xpZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBhd2FpdCBnZXRCeUlkPENsaWVudGU+KGNsaWVudGVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBoeWRyYXRlZERhdGEuY2xpZW50X2lkKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNsaWVudERhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4ZW1wdE9uTG9hZCA9IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQoY2xpZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoaXNFeGVtcHRPbkxvYWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2xpZW50Q3VpdChjbGllbnREYXRhLmN1aXQgPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGNsaWVudERhdGEudGF4ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlZENsaWVudFRheGVzID0gZ2V0RWZmZWN0aXZlQ2xpZW50VGF4ZXMoY2xpZW50RGF0YSwgY2xpZW50RGF0YS5yZWxhdGVkVGF4ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGxvYWRlZERhdGEuY2xpZW50Py5zaGlwYWRkcmVzcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWRkcmVzc2VzKGxvYWRlZERhdGEuY2xpZW50LnNoaXBhZGRyZXNzIGFzIHN0cmluZ1tdKTsgLy8gR3VhcmRhbW9zIGVsIGFycmF5XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIERldGVybWluYW1vcyBzaSBsYSBkaXJlY2Npw7NuIGd1YXJkYWRhIGVzIHVuYSBkaXJlY2Npw7NuIG51ZXZhIChjdXN0b20pXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0N1c3RvbSA9IGxvYWRlZERhdGEuZGVsaXZlcnlfYWRkcmVzc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmICFsb2FkZWREYXRhLmNsaWVudC5zaGlwYWRkcmVzcy5pbmNsdWRlcyhsb2FkZWREYXRhLmRlbGl2ZXJ5X2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3MoISFpc0N1c3RvbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGxvYWRlZERhdGEuZGVsaXZlcnlfYWRkcmVzcyB8fCAnJyk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGxvYWRlZERhdGEuZGVsaXZlcnlfYWRkcmVzcyB8fCAnJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShoeWRyYXRlZERhdGEpO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBtYXBwZWRFZGl0SXRlbXM6IEZvcm1TYWxlc0ludm9pY2VJdGVtW10gPSBoeWRyYXRlZERhdGEuaXRlbXMubWFwKGl0ZW0gPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCksXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3N0X3ByaWNlOiAoaXRlbSBhcyBhbnkpLmNvc3RfcHJpY2UgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25fcGVyY2VudGFnZTogKGl0ZW0gYXMgYW55KS5jb21taXNzaW9uX3BlcmNlbnRhZ2UgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRheGVzOiBpdGVtLnRheGVzIHx8IFtdLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ19xdWFudGl0eTogTnVtYmVyKGl0ZW0ucGVuZGluZ19xdWFudGl0eSkgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChoeWRyYXRlZERhdGEuc2FsZXNfb3JkZXJfaWQgJiYgaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW52b2ljZUlkTnVtID0gTnVtYmVyKGlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nUmVzID0gYXdhaXQgZ2V0U2FsZXNPcmRlclBlbmRpbmdJbnZvaWNlSXRlbXMoaHlkcmF0ZWREYXRhLnNhbGVzX29yZGVyX2lkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4Y2x1ZGVTYWxlc0ludm9pY2VJZDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFOdW1iZXIuaXNOYU4oaW52b2ljZUlkTnVtKSAmJiBpbnZvaWNlSWROdW0gPiAwID8gaW52b2ljZUlkTnVtIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcHBlZEVkaXRJdGVtcyA9IG1hcHBlZEVkaXRJdGVtcy5tYXAoaW52SXRlbSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNpZCA9IGludkl0ZW0uc2FsZXNfb3JkZXJfaXRlbV9pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpZCAhPSBudWxsICYmIHNpZCA+IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHBlbmRpbmdSZXMuaXRlbXMuZmluZChwID0+IHAuc2FsZXNfb3JkZXJfaXRlbV9pZCA9PT0gc2lkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcGVuZGluZ1Jlcy5pdGVtcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwLnByb2R1Y3RfaWQgPT09IGludkl0ZW0ucHJvZHVjdF9pZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKHAubGluZV9udW1iZXIpID09PSBOdW1iZXIoaW52SXRlbS5saW5lX251bWJlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocm93ID09IG51bGwpIHJldHVybiBpbnZJdGVtO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXhQID0gTnVtYmVyKHJvdy5xdWFudGl0eV9wZW5kaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlci5pc05hTihtYXhQKSB8fCBtYXhQIDwgMCkgcmV0dXJuIGludkl0ZW07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLmludkl0ZW0sIHBlbmRpbmdfcXVhbnRpdHk6IG1heFAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNpbiBibG9xdWVhciBlZGljacOzbiBzaSBlbCBlbmRwb2ludCBmYWxsYVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmluYWxFZGl0SXRlbXMgPSBpc0V4ZW1wdE9uTG9hZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyBtYXBwZWRFZGl0SXRlbXMubWFwKGl0ZW0gPT4gKHsgLi4uaXRlbSwgdGF4ZXM6IFtdIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBtYXBwZWRFZGl0SXRlbXM7XG5cbiAgICAgICAgICAgICAgICAgICAgc2V0SXRlbXMoZmluYWxFZGl0SXRlbXMpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhsb2FkZWRDbGllbnRUYXhlcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzRXhlbXB0T25Mb2FkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UgfSkpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCFoeWRyYXRlZERhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhoeWRyYXRlZERhdGEuYXBwbGllZFRheGVzIHx8IGh5ZHJhdGVkRGF0YS50YXhlcyB8fCBbXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGxvYWRFcnJvcjogYW55KSB7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKGBFcnJvciBhbCBjYXJnYXIgZGF0b3MgcmVsYWNpb25hZG9zOiAke2xvYWRFcnJvci5tZXNzYWdlIHx8ICdFcnJvciBkZXNjb25vY2lkbyd9YCk7XG4gICAgICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1vZGUgPT09ICdjcmVhdGUnKSB7XG4gICAgICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyhmYWxzZSk7IC8vIE5vIGhheSBuYWRhIHF1ZSBjYXJnYXJcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgbG9hZEVkaXREYXRhKCk7XG4gICAgfSwgW21vZGUsIGxvYWRlZERhdGFdKTtcblxuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZXhjaGFuZ2VSYXRlID0gZWZmZWN0aXZlRXhjaGFuZ2VSYXRlO1xuXG4gICAgICAgIGlmIChpc05hTihleGNoYW5nZVJhdGUpIHx8IGV4Y2hhbmdlUmF0ZSA9PT0gMCkgcmV0dXJuOyAvLyBFdml0YXIgZGl2aXNpw7NuIHBvciBjZXJvXG5cbiAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHByZXZJdGVtcy5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgICBjb25zdCBiYXNlUHJpY2UgPSBOdW1iZXIoKGl0ZW0gYXMgYW55KS5iYXNlX3NhbGVzX3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgY29uc3QgYmFzZUNvc3QgPSBOdW1iZXIoKGl0ZW0gYXMgYW55KS5iYXNlX2Nvc3RfcHJpY2UpIHx8IDA7XG5cbiAgICAgICAgICAgIC8vIFNpIGxvcyB2YWxvcmVzIGJhc2UgZXN0w6FuIHZhY8Otb3MgbyBzb24gMCwgbm8gaGF5IG5hZGEgcXVlIGNvbnZlcnRpclxuICAgICAgICAgICAgaWYgKGJhc2VQcmljZSA9PT0gMCAmJiBiYXNlQ29zdCA9PT0gMCkgcmV0dXJuIGl0ZW07XG5cbiAgICAgICAgICAgIGNvbnN0IG5ld0l0ZW06IEZvcm1TYWxlc0ludm9pY2VJdGVtID0ge1xuICAgICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgICAgLy8gQ29udmVydGltb3M6IFByZWNpbyBCYXNlIC8gVGFzYSBkZSBDYW1iaW9cbiAgICAgICAgICAgICAgICB1bml0X3ByaWNlOiByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZVByaWNlIC8gZXhjaGFuZ2VSYXRlKSxcbiAgICAgICAgICAgICAgICBjb3N0X3ByaWNlOiByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpLFxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gUmVjYWxjdWxhbW9zIGxvcyBpbXB1ZXN0b3MgZGVsIMOtdGVtIGlubWVkaWF0YW1lbnRlIChzaSBhcGxpY2EpXG4gICAgICAgICAgICBpZiAoZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgbmV3SXRlbS50YXhlcyA9IGNhbGN1bGF0ZUl0ZW1UYXhlcyhuZXdJdGVtLCBjbGllbnRUYXhlcyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBuZXdJdGVtO1xuICAgICAgICB9KSk7XG4gICAgfSwgW2VmZmVjdGl2ZUV4Y2hhbmdlUmF0ZSwgY2xpZW50VGF4ZXMsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBjbGllbnRUYXhDb25kaXRpb24sIGlzQ2xpZW50VGF4RXhlbXB0XSk7IC8vIERlcGVuZGUgZGUgbGEgdGFzYSBkZSBjYW1iaW9cblxuICAgIC8vIEVmZWN0byBwYXJhIENBTUJJTyBkZSBjbGllbnRlIChtYW51YWwpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgLy8gTm8gZWplY3V0YXIgZXN0ZSBlZmVjdG8gc2kgZXN0YW1vcyBjYXJnYW5kbyBkYXRvcyAobW9kbyBlZGl0KVxuICAgICAgICBpZiAoaXNJbml0aWFsTG9hZGluZykgcmV0dXJuO1xuXG4gICAgICAgIGlmIChmb3JtRGF0YS5jbGllbnRfaWQpIHtcbiAgICAgICAgICAgIGdldEJ5SWQ8Q2xpZW50ZT4oY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGZvcm1EYXRhLmNsaWVudF9pZClcbiAgICAgICAgICAgICAgICAudGhlbihjbGllbnREYXRhID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhlbXB0ID0gaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdChjbGllbnREYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3Q2xpZW50VGF4ZXMgPSBnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyhjbGllbnREYXRhLCBjbGllbnREYXRhLnJlbGF0ZWRUYXhlcyk7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGV4ZW1wdCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2xpZW50Q3VpdChjbGllbnREYXRhLmN1aXQgPz8gbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihjbGllbnREYXRhLnRheCA/PyBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMobmV3Q2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlcmllczogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2Lm1hcChpdGVtID0+ICh7IC4uLml0ZW0sIHRheGVzOiBbXSB9KSkpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYubWFwKGl0ZW0gPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRheGVzOiBjYWxjdWxhdGVJdGVtVGF4ZXMoaXRlbSwgbmV3Q2xpZW50VGF4ZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkaWVyb24gY2FyZ2FyIGxvcyBpbXB1ZXN0b3MgZGVsIGNsaWVudGUuJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDbGllbnRDdWl0KG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhDb25kaXRpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGZhbHNlKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkQ2xpZW50Q3VpdChudWxsKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihudWxsKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgICAgICBpZiAoZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMpIHtcbiAgICAgICAgICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYubWFwKGl0ZW0gPT4gKHsgLi4uaXRlbSwgdGF4ZXM6IFtdIH0pKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgIH0sIFtmb3JtRGF0YS5jbGllbnRfaWQsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBpc0luaXRpYWxMb2FkaW5nXSk7XG5cblxuICAgIC8vIC0tLSBMw5NHSUNBIERFIEPDgUxDVUxPIChVU0UgTUVNTykgLS0tXG4gICAgY29uc3QgY2FsY3VsYXRlZFRvdGFscyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBzdWJ0b3RhbCA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiAoc3VtICsgKE51bWJlcihpdGVtLnF1YW50aXR5IHx8IDApICogTnVtYmVyKGl0ZW0udW5pdF9wcmljZSB8fCAwKSkpLCAwKTtcbiAgICAgICAgY29uc3QgdG90YWxJdGVtRGlzY291bnRzID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDApLCAwKTtcbiAgICAgICAgY29uc3QgZ2xvYmFsRGlzY291bnRBbW91bnQgPSBOdW1iZXIoZm9ybURhdGEuZGlzY291bnRfYW1vdW50KSB8fCAwO1xuICAgICAgICBjb25zdCB0YXhCYXNlID0gc3VidG90YWwgLSB0b3RhbEl0ZW1EaXNjb3VudHMgLSBnbG9iYWxEaXNjb3VudEFtb3VudDtcblxuICAgICAgICBsZXQgdG90YWxUYXhlcyA9IDA7XG4gICAgICAgIGlmICghaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtVGF4QW1vdW50ID0gKGl0ZW0udGF4ZXMgfHwgW10pLnJlZHVjZSgoaXRlbVN1bSwgdGF4KSA9PiBpdGVtU3VtICsgTnVtYmVyKHRheC5hbW91bnQpLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN1bSArIGl0ZW1UYXhBbW91bnQ7XG4gICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBhcHBsaWVkVGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgKE51bWJlcih0YXguYW1vdW50KSB8fCAwKSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdG90YWwgPSBpc0NsaWVudFRheEV4ZW1wdFxuICAgICAgICAgICAgPyBjb21wdXRlRXhlbXB0RG9jdW1lbnRUb3RhbChzdWJ0b3RhbCwgdG90YWxJdGVtRGlzY291bnRzLCBnbG9iYWxEaXNjb3VudEFtb3VudClcbiAgICAgICAgICAgIDogdGF4QmFzZSArIHRvdGFsVGF4ZXM7XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbEl0ZW1EaXNjb3VudHMsIGdsb2JhbERpc2NvdW50QW1vdW50LCB0YXhCYXNlLCB0b3RhbFRheGVzLCB0b3RhbCB9O1xuICAgIH0sIFtpdGVtcywgZm9ybURhdGEuZGlzY291bnRfYW1vdW50LCBhcHBsaWVkVGF4ZXMsIGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG5cbiAgICAvLyBFZmVjdG8gcGFyYSBjYWxjdWxhciBJTVBVRVNUT1MgR0xPQkFMRVNcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICAvLyBObyBlamVjdXRhciBzaSBlc3RhbW9zIGNhcmdhbmRvXG4gICAgICAgIGlmIChpc0luaXRpYWxMb2FkaW5nKSByZXR1cm47XG5cbiAgICAgICAgaWYgKGlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjbGllbnRUYXhlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCB7IHRheEJhc2UgfSA9IGNhbGN1bGF0ZWRUb3RhbHM7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgICAgICAgICBuZXRCYXNlOiB0YXhCYXNlLFxuICAgICAgICAgICAgICAgIGNsaWVudFRheENvbmRpdGlvbixcbiAgICAgICAgICAgICAgICB0YXhlczogY2xpZW50VGF4ZXMsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICB9XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICB9LCBbY2FsY3VsYXRlZFRvdGFscy50YXhCYXNlLCBjbGllbnRUYXhlcywgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMsIGNsaWVudFRheENvbmRpdGlvbiwgaXNJbml0aWFsTG9hZGluZywgZm9ybURhdGEuY2xpZW50X2lkLCBpc0NsaWVudFRheEV4ZW1wdF0pO1xuXG5cbiAgICAvLyAtLS0gTUFORUpBRE9SRVMgLS0tXG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgY2FtYmlvcyBlbiBsYSBjYWJlY2VyYVxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudCB8IEhUTUxTZWxlY3RFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldDtcbiAgICAgICAgY29uc3QgeyBuYW1lIH0gPSB0YXJnZXQ7XG5cbiAgICAgICAgbGV0IGZpbmFsVmFsdWU6IGFueTtcbiAgICAgICAgaWYgKHRhcmdldCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgdGFyZ2V0LnR5cGUgPT09ICdjaGVja2JveCcpIHtcbiAgICAgICAgICAgIGZpbmFsVmFsdWUgPSB0YXJnZXQuY2hlY2tlZDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IHsgdmFsdWUgfSA9IHRhcmdldDtcbiAgICAgICAgICAgIGZpbmFsVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgIGlmIChuYW1lID09PSAnZGlzY291bnRfYW1vdW50JykgZmluYWxWYWx1ZSA9IE51bWJlcih2YWx1ZSkgfHwgMDtcbiAgICAgICAgICAgIGlmIChuYW1lID09PSAnZXhjaGFuZ2VfcmF0ZScpIGZpbmFsVmFsdWUgPSBOdW1iZXIodmFsdWUpIHx8IDE7XG4gICAgICAgIH1cblxuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIFtuYW1lXTogZmluYWxWYWx1ZSB9KSk7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXIgZGUgYXV0by1yZWxsZW5hZG8gKGNvcGlhZG8gZGUgUGVkaWRvcylcbiAgICBjb25zdCBhcHBseUhlYWRlclNlbGVjdGlvbiA9IGFzeW5jIChmaWVsZDogSGVhZGVyRmllbGQsIHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG4gICAgICAgIGNvbnN0IG1vZHVsZUNvbmZpZ01hcDogUmVjb3JkPHN0cmluZywgTW9kdWxlQ29uZmlnPGFueT4+ID0ge1xuICAgICAgICAgICAgJ2NsaWVudCc6IGNsaWVudGVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ3NhbGVzcGVyc29uJzogdmVuZGVkb3Jlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICdidXllcic6IGNvbXByYWRvcmVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ2N1cnJlbmN5JzogbW9uZWRhc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICd0cmFuc3BvcnQnOiB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyxcbiAgICAgICAgICAgICdzYWxlc19vcmRlcic6IHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBtb2R1bGVDb25maWcgPSBtb2R1bGVDb25maWdNYXBbZmllbGRdO1xuICAgICAgICBpZiAoIW1vZHVsZUNvbmZpZyB8fCAhbW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKGBFcnJvcjogRmFsdGEgJ3JlbGF0aW9uYWxGaWVsZHMnIGVuIGxhIGNvbmZpZyBkZSAke2ZpZWxkfWApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IG1vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzO1xuXG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ3NhbGVzX29yZGVyJykge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhcIkNhcmdhbmRvIGRhdG9zIGRlbCBwZWRpZG8uLi5cIik7XG4gICAgICAgICAgICBzZXRMb2FkaW5nT3JkZXJEYXRhKHRydWUpO1xuICAgICAgICAgICAgc2V0SXNJbml0aWFsTG9hZGluZyh0cnVlKTsgLy8gQmxvcXVlYW1vcyBlZmVjdG9zXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZ1bGxPcmRlciA9IGF3YWl0IGdldEJ5SWQ8U2FsZXNPcmRlcj4oc2FsZXNPcmRlcnNNb2R1bGVDb25maWcuZW5kcG9pbnQsIHNlbGVjdGVkSXRlbS5pZCk7XG5cbiAgICAgICAgICAgICAgICAvLyAxLiBDYXJnYXIgZWwgQ2xpZW50ZSBkZWwgUGVkaWRvIChwYXJhIGxvcyBpbXB1ZXN0b3MgeSBzZXJpZSBkZSBmYWN0dXJhKVxuICAgICAgICAgICAgICAgIGxldCBsb2FkZWRDbGllbnRUYXhlczogQ2xpZW50VGF4W10gPSBbXTtcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJDbGllbnRFeGVtcHQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJDbGllbnRUYXhDb25kaXRpb246IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgICAgICAgICAgICAgIGxldCBvcmRlckNsaWVudEZvclNlcmllczogUGljazxDbGllbnRlLCAnbGV5X2V4cG9ydGFjaW9uX3RkZicgfCAnc2VyaWUnIHwgJ3RheCc+IHwgbnVsbCA9XG4gICAgICAgICAgICAgICAgICAgIGZ1bGxPcmRlci5jbGllbnQgPz8gbnVsbDtcbiAgICAgICAgICAgICAgICBpZiAoZnVsbE9yZGVyLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gYXdhaXQgZ2V0QnlJZDxDbGllbnRlPihjbGllbnRlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgZnVsbE9yZGVyLmNsaWVudF9pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBvcmRlckNsaWVudEV4ZW1wdCA9IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQoY2xpZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRlZENsaWVudFRheGVzID0gZ2V0RWZmZWN0aXZlQ2xpZW50VGF4ZXMoY2xpZW50LCBjbGllbnQucmVsYXRlZFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVyQ2xpZW50VGF4Q29uZGl0aW9uID0gY2xpZW50LnRheCA/PyBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQob3JkZXJDbGllbnRFeGVtcHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDbGllbnRDdWl0KGNsaWVudC5jdWl0ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKG9yZGVyQ2xpZW50VGF4Q29uZGl0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKGxvYWRlZENsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVyQ2xpZW50Rm9yU2VyaWVzID0gY2xpZW50O1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIHsgdG9hc3QuZXJyb3IoXCJFcnJvciBjYXJnYW5kbyBpbXB1ZXN0b3MgZGVsIGNsaWVudGUgZGVsIHBlZGlkby5cIik7IH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCByZXNvbHZlZE9yZGVyU2VyaWVzID0gcmVzb2x2ZUludm9pY2VTZXJpZXNGb3JDbGllbnQob3JkZXJDbGllbnRGb3JTZXJpZXMsICdBJyk7XG5cbiAgICAgICAgICAgICAgICBpZiAoZnVsbE9yZGVyLmNsaWVudD8uc2hpcGFkZHJlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWRkcmVzc2VzKGZ1bGxPcmRlci5jbGllbnQuc2hpcGFkZHJlc3MgYXMgc3RyaW5nW10pO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0N1c3RvbSA9IGZ1bGxPcmRlci5kZWxpdmVyeV9hZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgICAmJiAhZnVsbE9yZGVyLmNsaWVudC5zaGlwYWRkcmVzcy5pbmNsdWRlcyhmdWxsT3JkZXIuZGVsaXZlcnlfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgc2V0SXNDdXN0b21BZGRyZXNzKCEhaXNDdXN0b20pO1xuICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGZ1bGxPcmRlci5kZWxpdmVyeV9hZGRyZXNzIHx8ICcnKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRBZGRyZXNzZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3MoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGZ1bGxPcmRlci5kZWxpdmVyeV9hZGRyZXNzIHx8ICcnKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBzZXRJc0V4Y2hhbmdlUmF0ZVJlYWRvbmx5KCEhZnVsbE9yZGVyLmlzX2V4Y2hhbmdlX3JhdGVfZml4ZWQpO1xuICAgICAgICAgICAgICAgIC8vIDIuIFBlbmRpZW50ZSBhIGZhY3R1cmFyIChtaXNtYSBpZGVhIHF1ZSBwZW5kaW5nLWl0ZW1zIGVuIHJlbWl0b3MpICsgbWFwZW8gYSDDrXRlbXMgZGUgZmFjdHVyYVxuICAgICAgICAgICAgICAgIGNvbnN0IGV4Y2x1ZGVJbnZvaWNlSWQgPVxuICAgICAgICAgICAgICAgICAgICBtb2RlID09PSAnZWRpdCcgJiYgaWQgPyBOdW1iZXIoaWQpIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgIGxldCBwZW5kaW5nQnlPcmRlckl0ZW1JZCA9IG5ldyBNYXA8bnVtYmVyLCBudW1iZXI+KCk7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVuZGluZ1JlcyA9IGF3YWl0IGdldFNhbGVzT3JkZXJQZW5kaW5nSW52b2ljZUl0ZW1zKGZ1bGxPcmRlci5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXhjbHVkZVNhbGVzSW52b2ljZUlkOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4Y2x1ZGVJbnZvaWNlSWQgIT0gbnVsbCAmJiAhTnVtYmVyLmlzTmFOKGV4Y2x1ZGVJbnZvaWNlSWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZXhjbHVkZUludm9pY2VJZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHBlbmRpbmdCeU9yZGVySXRlbUlkID0gbmV3IE1hcChcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdSZXMuaXRlbXMubWFwKChwKSA9PiBbcC5zYWxlc19vcmRlcl9pdGVtX2lkLCBwLnF1YW50aXR5X3BlbmRpbmddKVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICBpZiAocGVuZGluZ0J5T3JkZXJJdGVtSWQuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3Qud2FybignTm8gcXVlZGFuIGNhbnRpZGFkZXMgcG9yIGZhY3R1cmFyIHBhcmEgZXN0ZSBwZWRpZG8uJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3Qud2FybihcbiAgICAgICAgICAgICAgICAgICAgICAgICdObyBzZSBwdWRvIG9idGVuZXIgZWwgcGVuZGllbnRlIGRlIGZhY3R1cmFjacOzbjsgc2UgdXNhbiBsYXMgY2FudGlkYWRlcyBkZWwgcGVkaWRvLidcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgZnVsbE9yZGVyLml0ZW1zLmZvckVhY2goKGl0ZW06IE9yZGVySXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0J5T3JkZXJJdGVtSWQuc2V0KE51bWJlcihpdGVtLmlkKSwgTnVtYmVyKGl0ZW0ucXVhbnRpdHkpKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBmdWxsT3JkZXIuaXRlbXNcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoaXRlbTogT3JkZXJJdGVtKSA9PiBwZW5kaW5nQnlPcmRlckl0ZW1JZC5oYXMoTnVtYmVyKGl0ZW0uaWQpKSlcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgoaXRlbTogT3JkZXJJdGVtKTogRm9ybVNhbGVzSW52b2ljZUl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcXR5UGVuZGluZyA9IE51bWJlcihwZW5kaW5nQnlPcmRlckl0ZW1JZC5nZXQoTnVtYmVyKGl0ZW0uaWQpKSA/PyAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGludm9pY2VJdGVtOiBGb3JtU2FsZXNJbnZvaWNlSXRlbSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5FTVBUWV9JTlZPSUNFX0lURU0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhbGVzX29yZGVyX2l0ZW1faWQ6IE51bWJlcihpdGVtLmlkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2lkOiBpdGVtLnByb2R1Y3RfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9jb2RlOiBpdGVtLnByb2R1Y3RfY29kZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X25hbWU6IGl0ZW0ucHJvZHVjdF9uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1YW50aXR5OiBxdHlQZW5kaW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdfcXVhbnRpdHk6IHF0eVBlbmRpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5pdF9wcmljZTogaXRlbS51bml0X3ByaWNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvc3RfcHJpY2U6IE51bWJlcihpdGVtLmNvc3RfcHJpY2UpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzY291bnRfYW1vdW50OiBpdGVtLmRpc2NvdW50X2Ftb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uX3BlcmNlbnRhZ2U6IChpdGVtIGFzIGFueSkuY29tbWlzc2lvbl9wZXJjZW50YWdlIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGluZV9udW1iZXI6IGl0ZW0ubGluZV9udW1iZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGF4ZXM6IFtdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2VfY29zdF9wcmljZTogaXRlbS5iYXNlX2Nvc3RfcHJpY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFzZV9zYWxlc19wcmljZTogTnVtYmVyKGl0ZW0uYmFzZV9zYWxlc19wcmljZSkgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdG9ja19xdWFudGl0eTogaXRlbS5zdG9ja19xdWFudGl0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmdWxsT3JkZXIuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgIW9yZGVyQ2xpZW50RXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXRlbU5ldCA9IChOdW1iZXIoaW52b2ljZUl0ZW0ucXVhbnRpdHkpICogTnVtYmVyKGludm9pY2VJdGVtLnVuaXRfcHJpY2UpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtIChOdW1iZXIoaW52b2ljZUl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnZvaWNlSXRlbS50YXhlcyA9IGNvbXB1dGVTYWxlc0FwcGxpZWRUYXhlcyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldEJhc2U6IGl0ZW1OZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudFRheENvbmRpdGlvbjogb3JkZXJDbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRheGVzOiBsb2FkZWRDbGllbnRUYXhlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnZvaWNlSXRlbTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgc2V0SXRlbXMobmV3SXRlbXMpO1xuXG4gICAgICAgICAgICAgICAgLy8gMy4gUmVsbGVuYXIgQ2FiZWNlcmEgZGUgbGEgRmFjdHVyYVxuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgc2VyaWVzOiByZXNvbHZlZE9yZGVyU2VyaWVzLFxuICAgICAgICAgICAgICAgICAgICBpbnZvaWNlX2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLCAvLyBOdWV2YSBmZWNoYVxuXG4gICAgICAgICAgICAgICAgICAgIC8vIERhdG9zIGRlbCBQZWRpZG9cbiAgICAgICAgICAgICAgICAgICAgc2FsZXNfb3JkZXJfaWQ6IGZ1bGxPcmRlci5pZCxcbiAgICAgICAgICAgICAgICAgICAgc2FsZXNfb3JkZXJfbnVtYmVyOiBmdWxsT3JkZXIub3JkZXJfbnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICBzYWxlc19vcmRlcl9jb2RlOlxuICAgICAgICAgICAgICAgICAgICAgICAgZnVsbE9yZGVyLm9yZGVyX251bWJlciAhPSBudWxsICYmIGZ1bGxPcmRlci5vcmRlcl9udW1iZXIgIT09ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBTdHJpbmcoZnVsbE9yZGVyLm9yZGVyX251bWJlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzX29yZGVyX25hbWU6IGZ1bGxPcmRlci5jbGllbnQ/Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHB1cmNoYXNlX29yZGVyX251bWJlcjogZnVsbE9yZGVyLnB1cmNoYXNlX29yZGVyX251bWJlcixcbiAgICAgICAgICAgICAgICAgICAgZGVsaXZlcnlfZGF0ZTogZnVsbE9yZGVyLmRlbGl2ZXJ5X2RhdGUsXG4gICAgICAgICAgICAgICAgICAgIG5vdGVzOiBmdWxsT3JkZXIubm90ZXMsXG4gICAgICAgICAgICAgICAgICAgIGRpc2NvdW50X2Ftb3VudDogZnVsbE9yZGVyLmRpc2NvdW50X2Ftb3VudCA/PyAwLFxuICAgICAgICAgICAgICAgICAgICBleGNoYW5nZV9yYXRlOiBmdWxsT3JkZXIuZXhjaGFuZ2VfcmF0ZSA/PyAxLFxuICAgICAgICAgICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogb3JkZXJDbGllbnRFeGVtcHQgPyBmYWxzZSA6IGZ1bGxPcmRlci5oYXNfaXRlbV9sZXZlbF90YXhlcyxcblxuICAgICAgICAgICAgICAgICAgICAvLyBEYXRvcyBSZWxhY2lvbmFsZXMgKGFwbGFuYWRvcylcbiAgICAgICAgICAgICAgICAgICAgY2xpZW50X2lkOiBmdWxsT3JkZXIuY2xpZW50X2lkLFxuICAgICAgICAgICAgICAgICAgICBjbGllbnRfY29kZTogZnVsbE9yZGVyLmNsaWVudD8uW2NsaWVudGVzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMhLmNvZGVGaWVsZCBhcyBrZXlvZiBDbGllbnRlXSBhcyBzdHJpbmcgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiBmdWxsT3JkZXIuY2xpZW50Py5bY2xpZW50ZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIENsaWVudGVdIGFzIHN0cmluZyB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgZGVsaXZlcnlfYWRkcmVzczogZnVsbE9yZGVyLmRlbGl2ZXJ5X2FkZHJlc3MgfHwgKGZ1bGxPcmRlci5jbGllbnQ/LmFkZHJlc3MgfHwgJycpLFxuXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX2lkOiBmdWxsT3JkZXIuc2FsZXNwZXJzb25faWQsXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX2NvZGU6IGZ1bGxPcmRlci5zYWxlc3BlcnNvbj8uW3ZlbmRlZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEuY29kZUZpZWxkIGFzIGtleW9mIFZlbmRlZG9yXSBhcyBzdHJpbmcgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX25hbWU6IGZ1bGxPcmRlci5zYWxlc3BlcnNvbj8uW3ZlbmRlZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIFZlbmRlZG9yXSBhcyBzdHJpbmcgfHwgJycsXG5cbiAgICAgICAgICAgICAgICAgICAgYnV5ZXJfaWQ6IGZ1bGxPcmRlci5idXllcl9pZCxcbiAgICAgICAgICAgICAgICAgICAgYnV5ZXJfY29kZTogZnVsbE9yZGVyLmJ1eWVyPy5bY29tcHJhZG9yZXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEuY29kZUZpZWxkIGFzIGtleW9mIENvbXByYWRvcl0gYXMgc3RyaW5nIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBidXllcl9uYW1lOiBmdWxsT3JkZXIuYnV5ZXI/Lltjb21wcmFkb3Jlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzIS5uYW1lRmllbGQgYXMga2V5b2YgQ29tcHJhZG9yXSBhcyBzdHJpbmcgfHwgJycsXG5cbiAgICAgICAgICAgICAgICAgICAgY3VycmVuY3lfaWQ6IGZ1bGxPcmRlci5jdXJyZW5jeV9pZCxcbiAgICAgICAgICAgICAgICAgICAgY3VycmVuY3lfY29kZTogZnVsbE9yZGVyLmN1cnJlbmN5Py5bbW9uZWRhc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzIS5jb2RlRmllbGQgYXMga2V5b2YgTW9uZWRhXSBhcyBzdHJpbmcgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbmN5X25hbWU6IGZ1bGxPcmRlci5jdXJyZW5jeT8uW21vbmVkYXNNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyEubmFtZUZpZWxkIGFzIGtleW9mIE1vbmVkYV0gYXMgc3RyaW5nIHx8ICcnLFxuXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zcG9ydF9pZDogZnVsbE9yZGVyLnRyYW5zcG9ydF9pZCxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0X2NvZGU6IGZ1bGxPcmRlci50cmFuc3BvcnQ/Llt0cmFuc3BvcnRlc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzIS5jb2RlRmllbGQgYXMga2V5b2YgVHJhbnNwb3J0ZV0gYXMgc3RyaW5nIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICB0cmFuc3BvcnRfbmFtZTogZnVsbE9yZGVyLnRyYW5zcG9ydD8uW3RyYW5zcG9ydGVzTW9kdWxlQ29uZmlnLnJlbGF0aW9uYWxGaWVsZHMhLm5hbWVGaWVsZCBhcyBrZXlvZiBUcmFuc3BvcnRlXSBhcyBzdHJpbmcgfHwgJycsXG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgLy8gNC4gQ2FsY3VsYXIgSW1wdWVzdG9zIEdsb2JhbGVzIChzaSBhcGxpY2EpXG4gICAgICAgICAgICAgICAgaWYgKG9yZGVyQ2xpZW50RXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICghZnVsbE9yZGVyLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN1YnRvdGFsID0gbmV3SXRlbXMucmVkdWNlKChzdW0sIGkpID0+IHN1bSArIChOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSksIDApO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtRGlzY291bnQgPSBuZXdJdGVtcy5yZWR1Y2UoKHN1bSwgaSkgPT4gc3VtICsgTnVtYmVyKGkuZGlzY291bnRfYW1vdW50KSwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGdsb2JhbERpc2NvdW50ID0gTnVtYmVyKGZ1bGxPcmRlci5kaXNjb3VudF9hbW91bnQgfHwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRheEJhc2UgPSBzdWJ0b3RhbCAtIGl0ZW1EaXNjb3VudCAtIGdsb2JhbERpc2NvdW50O1xuXG4gICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhjb21wdXRlU2FsZXNBcHBsaWVkVGF4ZXMoe1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV0QmFzZTogdGF4QmFzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudFRheENvbmRpdGlvbjogb3JkZXJDbGllbnRUYXhDb25kaXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXhlczogbG9hZGVkQ2xpZW50VGF4ZXMsXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfSBjYXRjaCAobG9hZEVycm9yOiBhbnkpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihgTm8gc2UgcHVkaWVyb24gY2FyZ2FyIGxvcyBkYXRvcyBkZWwgcGVkaWRvOiAke2xvYWRFcnJvci5tZXNzYWdlfWApO1xuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzZXRJc0luaXRpYWxMb2FkaW5nKGZhbHNlKTsgLy8gRGVzYmxvcXVlYW1vcyBsb3MgZWZlY3Rvc1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmdPcmRlckRhdGEoZmFsc2UpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyAtLS0gQi4gTMOTR0lDQSBERSDDjVRFTVMgKElEw4lOVElDQSBBIFBFRElET1MpIC0tLVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0SXNFeGNoYW5nZVJhdGVSZWFkb25seShmYWxzZSk7XG4gICAgICAgICAgICBsZXQgcmVzb2x2ZWRJdGVtID0gc2VsZWN0ZWRJdGVtO1xuICAgICAgICAgICAgaWYgKGZpZWxkID09PSAnY2xpZW50JyAmJiBzZWxlY3RlZEl0ZW0/LmlkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmF3U2VyaWUgPSBzZWxlY3RlZEl0ZW0uc2VyaWU7XG4gICAgICAgICAgICAgICAgaWYgKHJhd1NlcmllID09IG51bGwgfHwgU3RyaW5nKHJhd1NlcmllKS50cmltKCkgPT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlZEl0ZW0gPSBhd2FpdCBnZXRCeUlkPENsaWVudGU+KGNsaWVudGVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBzZWxlY3RlZEl0ZW0uaWQpO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmVkSXRlbSA9IHNlbGVjdGVkSXRlbTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWREYXRhID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICAgICAgaWYgKHJlc29sdmVkSXRlbSkge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YVtgJHtmaWVsZH1faWRgXSA9IHJlc29sdmVkSXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGFbYCR7ZmllbGR9X2NvZGVgXSA9IHJlc29sdmVkSXRlbVtjb2RlRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGFbYCR7ZmllbGR9X25hbWVgXSA9IHJlc29sdmVkSXRlbVtuYW1lRmllbGQgYXMgc3RyaW5nXTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBMw7NnaWNhIGRlIGF1dG8tcmVsbGVubyBhbCBzZWxlY2Npb25hciBDbGllbnRlXG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSAnY2xpZW50Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWRkcmVzc2VzID0gcmVzb2x2ZWRJdGVtLnNoaXBhZGRyZXNzIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWRkcmVzc2VzKGFkZHJlc3Nlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3MoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDbGllbnRDdWl0KHJlc29sdmVkSXRlbS5jdWl0ID8/IG51bGwpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5zZXJpZXMgPSByZXNvbHZlSW52b2ljZVNlcmllc0ZvckNsaWVudChyZXNvbHZlZEl0ZW0sIHByZXYuc2VyaWVzIHx8ICdBJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNlbGVjY2lvbmFtb3MgbGEgcHJpbWVyYSBkaXJlY2Npw7NuIGNvbW8gdmFsb3IgcG9yIGRlZmVjdG8gc2kgZXhpc3RlXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWRkcmVzc2VzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGFkZHJlc3Nlc1swXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuZGVsaXZlcnlfYWRkcmVzcyA9IGFkZHJlc3Nlc1swXTsgLy8gU2V0ZWFtb3MgZW4gZm9ybURhdGEgcGFyYSB2YWxpZGFjacOzblxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5kZWxpdmVyeV9hZGRyZXNzID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlZEl0ZW0uc2FsZXNyZXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5zYWxlc3BlcnNvbl9pZCA9IHJlc29sdmVkSXRlbS5zYWxlc3JlcDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5zYWxlc3BlcnNvbl9jb2RlID0gcmVzb2x2ZWRJdGVtLnNhbGVzUmVwUmVsYXRpb24/LmNvZGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5zYWxlc3BlcnNvbl9uYW1lID0gcmVzb2x2ZWRJdGVtLnNhbGVzUmVwUmVsYXRpb24/Lm5hbWUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlZEl0ZW0udHJhbnNwb3J0X2lkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEudHJhbnNwb3J0X2lkID0gcmVzb2x2ZWRJdGVtLnRyYW5zcG9ydF9pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS50cmFuc3BvcnRfY29kZSA9IChyZXNvbHZlZEl0ZW0udHJhbnNwb3J0IGFzIGFueSk/LmNvZGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS50cmFuc3BvcnRfbmFtZSA9IChyZXNvbHZlZEl0ZW0udHJhbnNwb3J0IGFzIGFueSk/Lm5hbWUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlZEl0ZW0uY3VycmVuY3lfaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5jdXJyZW5jeV9pZCA9IHJlc29sdmVkSXRlbS5jdXJyZW5jeV9pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5jdXJyZW5jeV9jb2RlID0gKHJlc29sdmVkSXRlbS5jdXJyZW5jeSBhcyBhbnkpPy5jb2RlIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEuY3VycmVuY3lfbmFtZSA9IChyZXNvbHZlZEl0ZW0uY3VycmVuY3kgYXMgYW55KT8ubmFtZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmV4Y2hhbmdlX3JhdGUgPSByZXNvbHZlZEl0ZW0uY3VycmVuY3k/LmV4Y2hhbmdlX3JhdGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXBkYXRlZERhdGEuY3VycmVuY3lfY29kZSAhPT0gJzAxJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltYm9sb01vbmVkYSgnVVNEJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNpbWJvbG9Nb25lZGEoJyQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc29sdmVkSXRlbS5idXllcl9pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmJ1eWVyX2lkID0gcmVzb2x2ZWRJdGVtLmJ1eWVyX2lkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmJ1eWVyX2NvZGUgPSAocmVzb2x2ZWRJdGVtLmJ1eWVyIGFzIGFueSk/LmNvZGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5idXllcl9uYW1lID0gKHJlc29sdmVkSXRlbS5idXllciBhcyBhbnkpPy5uYW1lIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZmllbGQgPT09ICdjdXJyZW5jeScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLmV4Y2hhbmdlX3JhdGUgPSByZXNvbHZlZEl0ZW0uZXhjaGFuZ2VfcmF0ZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVwZGF0ZWREYXRhLmN1cnJlbmN5X2NvZGUgIT09ICcwMScpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltYm9sb01vbmVkYSgnVVNEJylcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaW1ib2xvTW9uZWRhKCckJylcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ2NsaWVudCcpIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXIgcGFyYSBhYnJpciBtb2RhbCBkZSBiw7pzcXVlZGFcbiAgICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAodGFyZ2V0OiBFZGl0aW5nVGFyZ2V0LCBjb25maWc6IE1vZHVsZUNvbmZpZzxhbnk+LCBpdGVtSW5kZXg6IG51bWJlciB8IG51bGwgPSBudWxsKSA9PiB7XG4gICAgICAgIGxldCBtb2RhbENvbmZpZzogKE1vZHVsZUNvbmZpZzxhbnk+ICYgeyBpbml0aWFsRmlsdGVycz86IGFueSB9KSB8IG51bGwgPSBjb25maWc7XG5cbiAgICAgICAgaWYgKHRhcmdldCA9PT0gJ3NhbGVzX29yZGVyJykge1xuICAgICAgICAgICAgaWYgKCFmb3JtRGF0YS5jbGllbnRfaWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5pbmZvKFwiU2VsZWNjaW9uZSB1biBjbGllbnRlIHByaW1lcm8gcGFyYSBmaWx0cmFyIGxvcyBwZWRpZG9zLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG1vZGFsQ29uZmlnID0ge1xuICAgICAgICAgICAgICAgIC4uLmNvbmZpZyxcbiAgICAgICAgICAgICAgICBpbml0aWFsRmlsdGVyczogeyBjbGllbnRfaWQ6IGZvcm1EYXRhLmNsaWVudF9pZCB8fCB1bmRlZmluZWQsIHN0YXR1czogJzMnIH0gLy8gRmlsdHJhIHBvciBjbGllbnRlIHkgYXV0b3JpemFkb3NcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSBpZiAodGFyZ2V0ID09PSAnaXRlbScpIHtcbiAgICAgICAgICAgIG1vZGFsQ29uZmlnID0ge1xuICAgICAgICAgICAgICAgIC4uLmNvbmZpZyxcbiAgICAgICAgICAgICAgICBpbml0aWFsRmlsdGVyczogYXJ0aWN1bG9zSXRlbVNlYXJjaEZpbHRlcnMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgc2V0RWRpdGluZ0l0ZW1JbmRleChpdGVtSW5kZXgpO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0RWRpdGluZ1RhcmdldCh0YXJnZXQpO1xuICAgICAgICBzZXRNb2RhbENvbmZpZyhtb2RhbENvbmZpZyk7XG4gICAgICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gTUFORUpBRE9SIERFIFNFTEVDQ0nDk04gREUgTU9EQUwgKExBIENMQVZFKSAtLS1cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RNb2RhbCA9IGFzeW5jIChzZWxlY3RlZEl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoIWVkaXRpbmdUYXJnZXQpIHJldHVybjtcblxuICAgICAgICAvLyAtLS0gQS4gTMOTR0lDQSBERSBDQVJHQSBERVNERSBQRURJRE8gREUgVkVOVEEgLS0tXG4gICAgICAgIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAnaXRlbScgJiYgZWRpdGluZ0l0ZW1JbmRleCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgLy8g4pyFIEJ1c2NhciBjb24gZWwgZm9ybWF0byBkZSBtw6FzY2FyYSAoaW5jbHV5ZSBwdW50b3MpXG4gICAgICAgICAgICBjb25zdCBza3VWYWx1ZSA9IHNlbGVjdGVkSXRlbS5za3UgPyBTdHJpbmcoc2VsZWN0ZWRJdGVtLnNrdSkgOiAnJztcbiAgICAgICAgICAgIGNvbnN0IHByb2R1Y3QgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oJ3Byb2R1Y3RzL2ZpbmQtYnktc2t1JyxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6ICdza3UnIGFzIHN0cmluZywgdmFsdWU6IHNrdVZhbHVlIH0sXG4gICAgICAgICAgICAgICAgeyBmaWVsZE5hbWU6ICdjbGllbnRfaWQnLCB2YWx1ZTogZm9ybURhdGEuY2xpZW50X2lkPy50b1N0cmluZygpID8/ICcnIH1cbiAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXdJdGVtcyA9IFsuLi5wcmV2SXRlbXNdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBuZXdJdGVtc1tlZGl0aW5nSXRlbUluZGV4XTtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBhcnRpY3Vsb3NNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyE7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhjaGFuZ2VSYXRlID0gZWZmZWN0aXZlRXhjaGFuZ2VSYXRlO1xuXG5cbiAgICAgICAgICAgICAgICBjb25zdCBiYXNlUHJpY2UgPSBwcm9kdWN0LnN1Z2dlc3RlZF9wcmljZSB8fCBzZWxlY3RlZEl0ZW0uc2FsZV9wcmljZSB8fCAwO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJhc2VDb3N0ID0gcHJvZHVjdENvc3RUb0Jhc2VDb3N0UHJpY2UoXG4gICAgICAgICAgICAgICAgICAgIHByb2R1Y3QuY29zdF9wcmljZSA/PyBzZWxlY3RlZEl0ZW0uY29zdF9wcmljZSA/PyAwLFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0LmNvc3RfY3VycmVuY3ksXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmV4Y2hhbmdlX3JhdGVcbiAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgaXRlbS5wcm9kdWN0X2lkID0gc2VsZWN0ZWRJdGVtLmlkO1xuICAgICAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9jb2RlID0gc2VsZWN0ZWRJdGVtW2NvZGVGaWVsZCBhcyBzdHJpbmddO1xuICAgICAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9uYW1lID0gc2VsZWN0ZWRJdGVtW25hbWVGaWVsZCBhcyBzdHJpbmddO1xuICAgICAgICAgICAgICAgIGl0ZW0udW5pdF9wcmljZSA9IHNlbGVjdGVkSXRlbS5zYWxlX3ByaWNlIHx8IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5jb3N0X3ByaWNlID0gc2VsZWN0ZWRJdGVtLmNvc3RfcHJpY2UgfHwgMDtcbiAgICAgICAgICAgICAgICBpdGVtLnN0b2NrX3F1YW50aXR5ID0gcHJvZHVjdC5zdG9ja19xdWFudGl0eSA/PyAwO1xuICAgICAgICAgICAgICAgIGl0ZW0uYmFzZV9zYWxlc19wcmljZSA9IGJhc2VQcmljZTtcbiAgICAgICAgICAgICAgICBpdGVtLmJhc2VfY29zdF9wcmljZSA9IGJhc2VDb3N0O1xuICAgICAgICAgICAgICAgIC8vIGl0ZW0uY29tbWlzc2lvbl9wZXJjZW50YWdlID0gc2VsZWN0ZWRJdGVtLmNvbW1pc3Npb25fcGVyY2VudGFnZSB8fCAwOyAvLyBTaSB2aW5pZXJhIGRlbCBwcm9kdWN0b1xuXG4gICAgICAgICAgICAgICAgLy8g4pyFIE5VRVZPOiBHdWFyZGFyIHByZWNpb3MgQkFTRSBlbiBlbCDDrXRlbVxuICAgICAgICAgICAgICAgIChpdGVtIGFzIGFueSkuYmFzZV9zYWxlc19wcmljZSA9IGJhc2VQcmljZTtcbiAgICAgICAgICAgICAgICAoaXRlbSBhcyBhbnkpLmJhc2VfY29zdF9wcmljZSA9IGJhc2VDb3N0O1xuXG4gICAgICAgICAgICAgICAgLy8g4pyFIENhbGN1bGFyIHByZWNpb3MgQ09OIFRBU0FcbiAgICAgICAgICAgICAgICBpdGVtLnVuaXRfcHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZVByaWNlIC8gZXhjaGFuZ2VSYXRlKTtcbiAgICAgICAgICAgICAgICBpdGVtLmNvc3RfcHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpO1xuXG4gICAgICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnRheGVzID0gY2FsY3VsYXRlSXRlbVRheGVzKGl0ZW0sIGNsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLnRheGVzID0gW107XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgbmV3SXRlbXNbZWRpdGluZ0l0ZW1JbmRleF0gPSBpdGVtO1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgc2V0RWRpdGluZ0l0ZW1JbmRleChudWxsKTtcblxuICAgICAgICAgICAgLy8gLS0tIEMuIEzDk0dJQ0EgREUgQ0FCRUNFUkEgKElEw4lOVElDQSBBIFBFRElET1MpIC0tLVxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBlZGl0aW5nVGFyZ2V0ID09PSAnc3RyaW5nJyAmJiBlZGl0aW5nVGFyZ2V0ICE9PSAnaXRlbScpIHtcbiAgICAgICAgICAgIGFwcGx5SGVhZGVyU2VsZWN0aW9uKGVkaXRpbmdUYXJnZXQgYXMgSGVhZGVyRmllbGQsIHNlbGVjdGVkSXRlbSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVEZWxpdmVyeUFkZHJlc3NDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTFNlbGVjdEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICBpZiAodmFsdWUgPT09ICdDVVNUT01fTkVXX0FERFJFU1MnKSB7XG4gICAgICAgICAgICBzZXRJc0N1c3RvbUFkZHJlc3ModHJ1ZSk7XG4gICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKCcnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldElzQ3VzdG9tQWRkcmVzcyhmYWxzZSk7XG4gICAgICAgICAgICBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKHZhbHVlKTsgLy8gU2V0ZWFtb3MgZWwgdmFsb3Igc2VsZWNjaW9uYWRvXG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gSGFuZGxlciBwYXJhIGNhbWJpb3MgZW4gbG9zIGl0ZW1zXG4gICAgY29uc3QgaGFuZGxlSXRlbUNoYW5nZSA9IChpbmRleDogbnVtYmVyLCBlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcbiAgICAgICAgY29uc3QgZXhjaGFuZ2VSYXRlID0gZWZmZWN0aXZlRXhjaGFuZ2VSYXRlOyAvLyBUYXNhIGFjdHVhbFxuICAgICAgICBjb25zdCBudW1GaWVsZHMgPSBbJ3F1YW50aXR5JywgJ3VuaXRfcHJpY2UnLCAnZGlzY291bnRfYW1vdW50JywgJ2NvbW1pc3Npb25fcGVyY2VudGFnZSddO1xuICAgICAgICBsZXQgc3RvcmVkVmFsdWU6IHN0cmluZyB8IG51bWJlciA9IG51bUZpZWxkcy5pbmNsdWRlcyhuYW1lKSA/ICh2YWx1ZSA9PT0gJycgPyAwIDogTnVtYmVyKHZhbHVlKSB8fCAwKSA6IHZhbHVlO1xuXG4gICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdJdGVtcyA9IFsuLi5wcmV2SXRlbXNdO1xuICAgICAgICAgICAgY29uc3QgcHJldlJvdyA9IG5ld0l0ZW1zW2luZGV4XTtcblxuICAgICAgICAgICAgaWYgKG5hbWUgPT09ICdxdWFudGl0eScpIHtcbiAgICAgICAgICAgICAgICBsZXQgcSA9IE51bWJlcihzdG9yZWRWYWx1ZSkgfHwgMDtcbiAgICAgICAgICAgICAgICBpZiAocSA8IDApIHEgPSAwO1xuICAgICAgICAgICAgICAgIGNvbnN0IG1heFBlbmRpbmcgPSBOdW1iZXIocHJldlJvdy5wZW5kaW5nX3F1YW50aXR5KSB8fCAwO1xuICAgICAgICAgICAgICAgIGlmIChtYXhQZW5kaW5nID4gMCAmJiBxID4gbWF4UGVuZGluZykge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC53YXJuKFxuICAgICAgICAgICAgICAgICAgICAgICAgYExhIGNhbnRpZGFkIG3DoXhpbWEgYSBmYWN0dXJhciBwYXJhICR7cHJldlJvdy5wcm9kdWN0X25hbWUgfHwgJ2VzdGUgw610ZW0nfSBlcyAke21heFBlbmRpbmd9LmBcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgcSA9IG1heFBlbmRpbmc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHN0b3JlZFZhbHVlID0gcTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHsgLi4ucHJldlJvdywgW25hbWVdOiBzdG9yZWRWYWx1ZSB9O1xuXG4gICAgICAgICAgICBpZiAobmFtZSA9PT0gJ3VuaXRfcHJpY2UnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBOdW1iZXIoc3RvcmVkVmFsdWUpIHx8IDA7XG4gICAgICAgICAgICAgICAgLy8g4pyFIENhbGN1bGFyIHkgZ3VhcmRhciBlbCBudWV2byBwcmVjaW8gQkFTRSBiYXNhZG8gZW4gbGEgZW50cmFkYSBkZWwgdXN1YXJpb1xuICAgICAgICAgICAgICAgIChpdGVtIGFzIGFueSkuYmFzZV9zYWxlc19wcmljZSA9IG5ld1ZhbHVlICogZXhjaGFuZ2VSYXRlO1xuXG4gICAgICAgICAgICAgICAgLy8gTWFudGVuZW1vcyBlbCBjb3N0X3ByaWNlIHNpbmNyb25pemFkbyAoYXVucXVlIG5vIGVzIGVkaXRhYmxlKVxuICAgICAgICAgICAgICAgIGNvbnN0IGJhc2VDb3N0ID0gTnVtYmVyKChpdGVtIGFzIGFueSkuYmFzZV9jb3N0X3ByaWNlKSB8fCAwO1xuICAgICAgICAgICAgICAgIGl0ZW0uY29zdF9wcmljZSA9IHJvdW5kVG9Ud29EZWNpbWFscyhiYXNlQ29zdCAvIGV4Y2hhbmdlUmF0ZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAhaXNDbGllbnRUYXhFeGVtcHQgJiYgKG5hbWUgPT09ICdxdWFudGl0eScgfHwgbmFtZSA9PT0gJ3VuaXRfcHJpY2UnIHx8IG5hbWUgPT09ICdkaXNjb3VudF9hbW91bnQnKSkge1xuICAgICAgICAgICAgICAgIGl0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXMoaXRlbSwgY2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAncXVhbnRpdHknIHx8IG5hbWUgPT09ICd1bml0X3ByaWNlJyB8fCBuYW1lID09PSAnZGlzY291bnRfYW1vdW50Jykge1xuICAgICAgICAgICAgICAgIGl0ZW0udGF4ZXMgPSBbXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gaXRlbTtcbiAgICAgICAgICAgIHJldHVybiBuZXdJdGVtcztcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGRpc3BhdGNoSXRlbU51bWVyaWNDaGFuZ2UgPSAoaW5kZXg6IG51bWJlciwgbmFtZTogc3RyaW5nLCB2YWx1ZTogbnVtYmVyKSA9PiB7XG4gICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsIHsgdGFyZ2V0OiB7IG5hbWUsIHZhbHVlOiBTdHJpbmcodmFsdWUpIH0gfSBhcyBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50Pik7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXJzIGRlIGLDunNxdWVkYSBwb3IgY8OzZGlnbyAoaWTDqW50aWNvcyBhIFBlZGlkb3MpXG4gICAgY29uc3QgaGFuZGxlSXRlbUNvZGVTdWJtaXQgPSBhc3luYyAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0gaXRlbXNbaW5kZXhdO1xuICAgICAgICBpZiAoIWl0ZW0ucHJvZHVjdF9jb2RlKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHsgY29kZUZpZWxkLCBuYW1lRmllbGQgfSA9IGFydGljdWxvc01vZHVsZUNvbmZpZy5yZWxhdGlvbmFsRmllbGRzITtcbiAgICAgICAgY29uc3QgZXhjaGFuZ2VSYXRlID0gZWZmZWN0aXZlRXhjaGFuZ2VSYXRlO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyDinIUgQnVzY2FyIGNvbiBlbCBmb3JtYXRvIGRlIG3DoXNjYXJhIChpbmNsdXllIHB1bnRvcylcbiAgICAgICAgICAgIGNvbnN0IHByb2R1Y3QgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oJ3Byb2R1Y3RzL2ZpbmQtYnktc2t1JyxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6IGNvZGVGaWVsZCBhcyBzdHJpbmcsIHZhbHVlOiBpdGVtLnByb2R1Y3RfY29kZSB9LFxuICAgICAgICAgICAgICAgIHsgZmllbGROYW1lOiAnY2xpZW50X2lkJywgdmFsdWU6IGZvcm1EYXRhLmNsaWVudF9pZD8udG9TdHJpbmcoKSA/PyAnJyB9XG4gICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICBpZiAocHJvZHVjdCkge1xuICAgICAgICAgICAgICAgIHNldEl0ZW1zKHByZXZJdGVtcyA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0l0ZW1zID0gWy4uLnByZXZJdGVtc107XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhc2VQcmljZSA9IHByb2R1Y3Quc3VnZ2VzdGVkX3ByaWNlIHx8IHByb2R1Y3Quc2FsZV9wcmljZSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBiYXNlQ29zdCA9IHByb2R1Y3RDb3N0VG9CYXNlQ29zdFByaWNlKFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdC5jb3N0X3ByaWNlIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0LmNvc3RfY3VycmVuY3ksXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5leGNoYW5nZV9yYXRlXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQcmljZSA9IE51bWJlcihuZXdJdGVtc1tpbmRleF0udW5pdF9wcmljZSkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudENvc3QgPSBOdW1iZXIobmV3SXRlbXNbaW5kZXhdLmNvc3RfcHJpY2UpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhbGN1bGF0ZWRQcmljZSA9IHJvdW5kVG9Ud29EZWNpbWFscyhiYXNlUHJpY2UgLyBleGNoYW5nZVJhdGUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjYWxjdWxhdGVkQ29zdCA9IHJvdW5kVG9Ud29EZWNpbWFscyhiYXNlQ29zdCAvIGV4Y2hhbmdlUmF0ZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZEl0ZW0gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5uZXdJdGVtc1tpbmRleF0sXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9jb2RlOiBwcm9kdWN0W2NvZGVGaWVsZCBhcyBzdHJpbmddLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdF9uYW1lOiBwcm9kdWN0W25hbWVGaWVsZCBhcyBzdHJpbmddLFxuXG4gICAgICAgICAgICAgICAgICAgICAgICBiYXNlX3NhbGVzX3ByaWNlOiBiYXNlUHJpY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBiYXNlX2Nvc3RfcHJpY2U6IGJhc2VDb3N0LFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RvY2tfcXVhbnRpdHk6IHByb2R1Y3Quc3RvY2tfcXVhbnRpdHksXG4gICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nX3F1YW50aXR5OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2FsZXNfb3JkZXJfaXRlbV9pZDogdW5kZWZpbmVkLFxuXG4gICAgICAgICAgICAgICAgICAgICAgICB1bml0X3ByaWNlOiBjdXJyZW50UHJpY2UgPiAwID8gY3VycmVudFByaWNlIDogY2FsY3VsYXRlZFByaWNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29zdF9wcmljZTogY3VycmVudENvc3QgPiAwID8gY3VycmVudENvc3QgOiBjYWxjdWxhdGVkQ29zdCxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXModXBkYXRlZEl0ZW0sIGNsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBuZXdJdGVtc1tpbmRleF0gPSB1cGRhdGVkSXRlbTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ld0l0ZW1zO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCcke3Byb2R1Y3RbbmFtZUZpZWxkIGFzIHN0cmluZ119JyBzZWxlY2Npb25hZG8uYCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKGBObyBzZSBlbmNvbnRyw7MgbmluZ8O6biBhcnTDrWN1bG8gY29uIGVsIGPDs2RpZ28gXCIke2l0ZW0ucHJvZHVjdF9jb2RlfVwiLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHsgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgYXJ0w61jdWxvIHBvciBjw7NkaWdvLlwiKTsgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVJdGVtQ29kZUNoYW5nZSA9IChpbmRleDogbnVtYmVyLCBuZXdDb2RlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0l0ZW1zID0gWy4uLnByZXZJdGVtc107XG4gICAgICAgICAgICBjb25zdCBpdGVtID0geyAuLi5uZXdJdGVtc1tpbmRleF0gfTtcbiAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9jb2RlID0gbmV3Q29kZTtcbiAgICAgICAgICAgIGl0ZW0ucHJvZHVjdF9pZCA9IDA7IGl0ZW0ucHJvZHVjdF9uYW1lID0gJyc7XG4gICAgICAgICAgICBpdGVtLnVuaXRfcHJpY2UgPSAwOyBpdGVtLnN0b2NrX3F1YW50aXR5ID0gMDsgaXRlbS50YXhlcyA9IFtdO1xuICAgICAgICAgICAgaXRlbS5wZW5kaW5nX3F1YW50aXR5ID0gMDtcbiAgICAgICAgICAgIGl0ZW0uc2FsZXNfb3JkZXJfaXRlbV9pZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIG5ld0l0ZW1zW2luZGV4XSA9IGl0ZW07XG4gICAgICAgICAgICByZXR1cm4gbmV3SXRlbXM7XG4gICAgICAgIH0pO1xuICAgIH07XG5cbiAgICAvLyDinIUgRnVuY2nDs24gcGFyYSBtYW5lamFyIHNlbGVjY2nDs24gZGVzZGUgYXV0b2NvbXBsZXRhZG9cbiAgICBjb25zdCBoYW5kbGVJdGVtQXV0b2NvbXBsZXRlU2VsZWN0ID0gYXN5bmMgKGluZGV4OiBudW1iZXIsIHByb2R1Y3Q6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBhcnRpY3Vsb3NNb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcyE7XG4gICAgICAgIGNvbnN0IGV4Y2hhbmdlUmF0ZSA9IGVmZmVjdGl2ZUV4Y2hhbmdlUmF0ZTtcblxuICAgICAgICAvLyBCdXNjYXIgZWwgcHJvZHVjdG8gY29tcGxldG8gY29uIHByZWNpb3Mgc3VnZXJpZG9zXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBza3VWYWx1ZSA9IHByb2R1Y3Quc2t1ID8gU3RyaW5nKHByb2R1Y3Quc2t1KSA6ICcnO1xuICAgICAgICAgICAgY29uc3QgZnVsbFByb2R1Y3QgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oJ3Byb2R1Y3RzL2ZpbmQtYnktc2t1JyxcbiAgICAgICAgICAgICAgICBbeyBmaWVsZE5hbWU6ICdza3UnIGFzIHN0cmluZywgdmFsdWU6IHNrdVZhbHVlIH0sXG4gICAgICAgICAgICAgICAgeyBmaWVsZE5hbWU6ICdjbGllbnRfaWQnLCB2YWx1ZTogZm9ybURhdGEuY2xpZW50X2lkPy50b1N0cmluZygpID8/ICcnIH1cbiAgICAgICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgaWYgKGZ1bGxQcm9kdWN0KSB7XG4gICAgICAgICAgICAgICAgc2V0SXRlbXMocHJldkl0ZW1zID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBbLi4ucHJldkl0ZW1zXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXRlbSA9IG5ld0l0ZW1zW2luZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZVByaWNlID0gZnVsbFByb2R1Y3Quc3VnZ2VzdGVkX3ByaWNlIHx8IGZ1bGxQcm9kdWN0LnNhbGVfcHJpY2UgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZUNvc3QgPSBwcm9kdWN0Q29zdFRvQmFzZUNvc3RQcmljZShcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxQcm9kdWN0LmNvc3RfcHJpY2UgfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxQcm9kdWN0LmNvc3RfY3VycmVuY3ksXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5leGNoYW5nZV9yYXRlXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQcmljZSA9IE51bWJlcihpdGVtLnVuaXRfcHJpY2UpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRDb3N0ID0gTnVtYmVyKGl0ZW0uY29zdF9wcmljZSkgfHwgMDtcblxuICAgICAgICAgICAgICAgICAgICBpdGVtLnByb2R1Y3RfaWQgPSBmdWxsUHJvZHVjdC5pZDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5wcm9kdWN0X2NvZGUgPSBmdWxsUHJvZHVjdFtjb2RlRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5wcm9kdWN0X25hbWUgPSBmdWxsUHJvZHVjdFtuYW1lRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5zdG9ja19xdWFudGl0eSA9IGZ1bGxQcm9kdWN0LnN0b2NrX3F1YW50aXR5IHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uYmFzZV9zYWxlc19wcmljZSA9IGJhc2VQcmljZTtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5iYXNlX2Nvc3RfcHJpY2UgPSBiYXNlQ29zdDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5wZW5kaW5nX3F1YW50aXR5ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5zYWxlc19vcmRlcl9pdGVtX2lkID0gdW5kZWZpbmVkO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50UHJpY2UgPD0gMCkgaXRlbS51bml0X3ByaWNlID0gcm91bmRUb1R3b0RlY2ltYWxzKGJhc2VQcmljZSAvIGV4Y2hhbmdlUmF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Q29zdCA8PSAwKSBpdGVtLmNvc3RfcHJpY2UgPSByb3VuZFRvVHdvRGVjaW1hbHMoYmFzZUNvc3QgLyBleGNoYW5nZVJhdGUpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAhaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0udGF4ZXMgPSBjYWxjdWxhdGVJdGVtVGF4ZXMoaXRlbSwgY2xpZW50VGF4ZXMpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS50YXhlcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgbmV3SXRlbXNbaW5kZXhdID0gaXRlbTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ld0l0ZW1zO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIHByb2R1Y3RvIGNvbXBsZXRvOicsIGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVJdGVtQ2xlYXIgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRJdGVtcyhwcmV2SXRlbXMgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3SXRlbXMgPSBbLi4ucHJldkl0ZW1zXTtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSB7IC4uLm5ld0l0ZW1zW2luZGV4XSB9O1xuICAgICAgICAgICAgaXRlbS5wcm9kdWN0X2lkID0gMDsgaXRlbS5wcm9kdWN0X2NvZGUgPSAnJzsgaXRlbS5wcm9kdWN0X25hbWUgPSAnJztcbiAgICAgICAgICAgIGl0ZW0udW5pdF9wcmljZSA9IDA7IGl0ZW0uc3RvY2tfcXVhbnRpdHkgPSAwOyBpdGVtLnRheGVzID0gW107IGl0ZW0uZGlzY291bnRfYW1vdW50ID0gMDtcbiAgICAgICAgICAgIGl0ZW0ucGVuZGluZ19xdWFudGl0eSA9IDA7XG4gICAgICAgICAgICBpdGVtLnNhbGVzX29yZGVyX2l0ZW1faWQgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBuZXdJdGVtc1tpbmRleF0gPSBpdGVtO1xuICAgICAgICAgICAgcmV0dXJuIG5ld0l0ZW1zO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQWRkSXRlbSA9ICgpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBbLi4ucHJldiwgeyAuLi5FTVBUWV9JTlZPSUNFX0lURU0sIHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSwgbGluZV9udW1iZXI6IHByZXYubGVuZ3RoICsgMSB9XSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZW1vdmVJdGVtID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0SXRlbXMocHJldiA9PiBwcmV2LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcbiAgICB9O1xuXG4gICAgLy8gSGFuZGxlcnMgZGUgSW1wdWVzdG9zIChpZMOpbnRpY29zIGEgUGVkaWRvcylcbiAgICBjb25zdCBoYW5kbGVPcGVuSXRlbVRheE1vZGFsID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgaWYgKGlzQ2xpZW50VGF4RXhlbXB0KSByZXR1cm47XG4gICAgICAgIGlmICghZm9ybURhdGEuY2xpZW50X2lkKSB7IHRvYXN0Lndhcm4oJ1BvciBmYXZvciwgc2VsZWNjaW9uZSB1biBjbGllbnRlIHByaW1lcm8uJyk7IHJldHVybjsgfVxuICAgICAgICBzZXRDdXJyZW50SXRlbUluZGV4Rm9yVGF4KGluZGV4KTtcbiAgICAgICAgc2V0SXNJdGVtVGF4TW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlU2F2ZUl0ZW1UYXhlcyA9ICh0YXhlczogQXBwbGllZFRheFtdKSA9PiB7XG4gICAgICAgIGlmIChjdXJyZW50SXRlbUluZGV4Rm9yVGF4ID09PSBudWxsKSByZXR1cm47XG4gICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoKGl0ZW0sIGluZGV4KSA9PiBpbmRleCA9PT0gY3VycmVudEl0ZW1JbmRleEZvclRheCA/IHsgLi4uaXRlbSwgdGF4ZXM6IHRheGVzIH0gOiBpdGVtKSk7XG4gICAgICAgIHNldEN1cnJlbnRJdGVtSW5kZXhGb3JUYXgobnVsbCk7XG4gICAgICAgIHNldElzSXRlbVRheE1vZGFsT3BlbihmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVUYXhNb2RlQ2hhbmdlID0gKGVuYWJsZWQ6IGJvb2xlYW4pID0+IHtcbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBoYXNfaXRlbV9sZXZlbF90YXhlczogZW5hYmxlZCB9KSk7XG4gICAgICAgIGlmIChlbmFibGVkKSB7XG4gICAgICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYubWFwKGl0ZW0gPT4gKHsgLi4uaXRlbSwgdGF4ZXM6IGNhbGN1bGF0ZUl0ZW1UYXhlcyhpdGVtLCBjbGllbnRUYXhlcykgfSkpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEl0ZW1zKHByZXYgPT4gcHJldi5tYXAoaXRlbSA9PiAoeyAuLi5pdGVtLCB0YXhlczogW10gfSkpKTtcbiAgICAgICAgfVxuICAgIH07XG5cblxuICAgIGNvbnN0IGV4ZWN1dGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICAvLyBMaW1waWFtb3MgY2FtcG9zIGRlIFVJIGRlIGxvcyBpdGVtc1xuICAgICAgICBjb25zdCBjbGVhbkl0ZW1zID0gaXRlbXMubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgICAgY29uc3QgeyB0ZW1wSWQsIHNhbGVzX29yZGVyX2l0ZW1faWQ6IF91aU9yZGVyTGluZUlkLCAuLi5yZXN0IH0gPSBpdGVtO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGlkOiByZXN0LmlkIHx8IDAsXG4gICAgICAgICAgICAgICAgdGF4ZXM6IGZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmICFpc0NsaWVudFRheEV4ZW1wdCA/IChyZXN0LnRheGVzIHx8IFtdKSA6IFtdLFxuICAgICAgICAgICAgICAgIGJhc2Vfc2FsZXNfcHJpY2U6IChyZXN0IGFzIGFueSkuYmFzZV9zYWxlc19wcmljZSB8fCAwLFxuICAgICAgICAgICAgICAgIGJhc2VfY29zdF9wcmljZTogKHJlc3QgYXMgYW55KS5iYXNlX2Nvc3RfcHJpY2UgfHwgMCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIExpbXBpYW1vcyBjYW1wb3MgZGUgVUkgZGUgbGEgY2FiZWNlcmFcbiAgICAgICAgY29uc3QgeyBjbGllbnQsIHNhbGVzcGVyc29uLCBidXllciwgY3VycmVuY3ksIHRyYW5zcG9ydCwgc2FsZXNfb3JkZXIsXG4gICAgICAgICAgICBjbGllbnRfY29kZSwgY2xpZW50X25hbWUsIHNhbGVzcGVyc29uX2NvZGUsIHNhbGVzcGVyc29uX25hbWUsXG4gICAgICAgICAgICBidXllcl9jb2RlLCBidXllcl9uYW1lLCBjdXJyZW5jeV9jb2RlLCBjdXJyZW5jeV9uYW1lLFxuICAgICAgICAgICAgdHJhbnNwb3J0X2NvZGUsIHRyYW5zcG9ydF9uYW1lLCBzYWxlc19vcmRlcl9udW1iZXIsIHNhbGVzX29yZGVyX2NvZGUsXG4gICAgICAgICAgICBhcHBsaWVkVGF4ZXM6IF8sIC4uLmhlYWRlclBheWxvYWQgfSA9IGZvcm1EYXRhO1xuXG4gICAgICAgIGNvbnN0IHNhbml0aXplZCA9IGlzQ2xpZW50VGF4RXhlbXB0XG4gICAgICAgICAgICA/IHNhbml0aXplVGF4UGF5bG9hZEZvckV4ZW1wdENsaWVudCh7XG4gICAgICAgICAgICAgICAgdGF4ZXM6IGFwcGxpZWRUYXhlcyxcbiAgICAgICAgICAgICAgICBpdGVtczogY2xlYW5JdGVtcyxcbiAgICAgICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgOiBudWxsO1xuXG4gICAgICAgIGNvbnN0IGRhdGFUb1NlbmQ6IFBhcnRpYWw8U2FsZXNJbnZvaWNlPiA9IHtcbiAgICAgICAgICAgIC4uLmhlYWRlclBheWxvYWQsXG4gICAgICAgICAgICBpdGVtczogc2FuaXRpemVkPy5pdGVtcyA/PyBjbGVhbkl0ZW1zLFxuICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IHNhbml0aXplZD8uaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgPz8gISFmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyxcbiAgICAgICAgICAgIHRvdGFsX2Ftb3VudDogY2FsY3VsYXRlZFRvdGFscy50b3RhbCxcbiAgICAgICAgICAgIGRpc2NvdW50X2Ftb3VudDogTnVtYmVyKGZvcm1EYXRhLmRpc2NvdW50X2Ftb3VudCkgfHwgMCxcbiAgICAgICAgICAgIGV4Y2hhbmdlX3JhdGU6IE51bWJlcihmb3JtRGF0YS5leGNoYW5nZV9yYXRlKSB8fCAxLFxuICAgICAgICAgICAgc2hvd19jdXJyZW5jeV9lcXVpdmFsZW5jZTogISFmb3JtRGF0YS5zaG93X2N1cnJlbmN5X2VxdWl2YWxlbmNlLFxuICAgICAgICAgICAgdGF4ZXM6IHNhbml0aXplZFxuICAgICAgICAgICAgICAgID8gc2FuaXRpemVkLnRheGVzXG4gICAgICAgICAgICAgICAgOiAoIWZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzID8gYXBwbGllZFRheGVzLmZpbHRlcih0ID0+IHQuYW1vdW50ID4gMCkgOiBbXSksXG4gICAgICAgICAgICBkZWxpdmVyeV9hZGRyZXNzOiB0ZW1wRGVsaXZlcnlBZGRyZXNzLFxuICAgICAgICAgICAgaW52b2ljZV9udW1iZXI6XG4gICAgICAgICAgICAgICAgZm9ybURhdGEuaW52b2ljZV9udW1iZXIgPT0gbnVsbCB8fCBmb3JtRGF0YS5pbnZvaWNlX251bWJlciA9PT0gJydcbiAgICAgICAgICAgICAgICAgICAgPyAnJ1xuICAgICAgICAgICAgICAgICAgICA6IFN0cmluZyhmb3JtRGF0YS5pbnZvaWNlX251bWJlciksXG4gICAgICAgIH07XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHNhdmVkID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YVRvU2VuZCBhcyBTYWxlc0ludm9pY2UpO1xuICAgICAgICAgICAgaWYgKHNhdmVkKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgRmFjdHVyYSAke21vZGUgPT09ICdjcmVhdGUnID8gJ2NyZWFkYScgOiAnYWN0dWFsaXphZGEnfSBjb24gw6l4aXRvLmApO1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGFwaUVycm9yOiBhbnkpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKGBFcnJvciBhbCBndWFyZGFyOiAke2FwaUVycm9yLm1lc3NhZ2UgfHwgJ0Vycm9yIGRlc2Nvbm9jaWRvJ31gKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghZm9ybURhdGEuY2xpZW50X2lkIHx8ICFmb3JtRGF0YS5zYWxlc3BlcnNvbl9pZCB8fCAhZm9ybURhdGEuY3VycmVuY3lfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiQ2xpZW50ZSwgVmVuZGVkb3IgeSBNb25lZGEgc29uIG9ibGlnYXRvcmlvcy5cIik7IHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgY2xpZW50Q3VpdCA9IHNlbGVjdGVkQ2xpZW50Q3VpdCA/PyBmb3JtRGF0YS5jbGllbnQ/LmN1aXQgPz8gbnVsbDtcbiAgICAgICAgaWYgKGlzQ2xpZW50VGF4RXhlbXB0ICYmICFoYXNWYWxpZEFyZ2VudGluZUN1aXQoY2xpZW50Q3VpdCkgJiYgZm9ybURhdGEuY2xpZW50X2lkKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNsaWVudERhdGEgPSBhd2FpdCBnZXRCeUlkPENsaWVudGU+KGNsaWVudGVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBmb3JtRGF0YS5jbGllbnRfaWQpO1xuICAgICAgICAgICAgICAgIGNsaWVudEN1aXQgPSBjbGllbnREYXRhLmN1aXQgPz8gbnVsbDtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENsaWVudEN1aXQoY2xpZW50Q3VpdCk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBTZSB2YWxpZGEgYWJham8gY29uIGVsIENVSVQgZGlzcG9uaWJsZS5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNDbGllbnRUYXhFeGVtcHQgJiYgIWhhc1ZhbGlkQXJnZW50aW5lQ3VpdChjbGllbnRDdWl0KSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIGNsaWVudGUgY29uIExleSBFeHBvcnRhY2nDs24gVERGIGRlYmUgdGVuZXIgdW4gQ1VJVCB2w6FsaWRvICgxMSBkw61naXRvcykgcGFyYSBlbWl0aXIgZmFjdHVyYSBFLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHsgdG9hc3QuZXJyb3IoXCJBw7FhZGEgYWwgbWVub3MgdW4gcHJvZHVjdG8uXCIpOyByZXR1cm47IH1cbiAgICAgICAgaWYgKCF0ZW1wRGVsaXZlcnlBZGRyZXNzIHx8ICF0ZW1wRGVsaXZlcnlBZGRyZXNzLnRyaW0oKSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJEZWJlIGVzcGVjaWZpY2FyIHVuYSBEaXJlY2Npw7NuIGRlIEVudHJlZ2EuXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgICAgICBjb25zdCBtYXhQID0gTnVtYmVyKGl0ZW0ucGVuZGluZ19xdWFudGl0eSkgfHwgMDtcbiAgICAgICAgICAgIGlmIChtYXhQID4gMCAmJiBOdW1iZXIoaXRlbS5xdWFudGl0eSkgPiBtYXhQKSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoXG4gICAgICAgICAgICAgICAgICAgIGBMYSBjYW50aWRhZCBkZSBcIiR7aXRlbS5wcm9kdWN0X25hbWUgfHwgJ3VuIMOtdGVtJ31cIiAoJHtOdW1iZXIoaXRlbS5xdWFudGl0eSl9KSBzdXBlcmEgZWwgcGVuZGllbnRlIGRlIGZhY3R1cmFjacOzbiAoJHttYXhQfSkuYFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcHJvY2VlZFRvU2F2ZSA9ICgpID0+IHtcbiAgICAgICAgICAgIGdhdGVTYXZlKGl0ZW1zLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdm9pZCBleGVjdXRlU2F2ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3Qgb3ZlclN0b2NrSXRlbSA9IGl0ZW1zLmZpbmQoaXNMaW5lT3ZlckF2YWlsYWJsZVN0b2NrKTtcbiAgICAgICAgaWYgKG92ZXJTdG9ja0l0ZW0pIHtcbiAgICAgICAgICAgIHBlbmRpbmdBZnRlclN0b2NrQWNrUmVmLmN1cnJlbnQgPSBwcm9jZWVkVG9TYXZlO1xuICAgICAgICAgICAgc2V0U3RvY2tBbGVydCh7XG4gICAgICAgICAgICAgICAgb3BlbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB0aXRsZTogJ1N0b2NrIGluc3VmaWNpZW50ZScsXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogc3RvY2tFeGNlc3NNZXNzYWdlKG92ZXJTdG9ja0l0ZW0pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBwcm9jZWVkVG9TYXZlKCk7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXJzIGRlIGNhYmVjZXJhIChpZMOpbnRpY29zIGEgUGVkaWRvcylcbiAgICBjb25zdCBoYW5kbGVIZWFkZXJDb2RlQ2hhbmdlID0gKGZpZWxkOiBIZWFkZXJGaWVsZCwgbmV3Q29kZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBbYCR7ZmllbGR9X2lkYF06IG51bGwsXG4gICAgICAgICAgICBbYCR7ZmllbGR9X2NvZGVgXTogbmV3Q29kZSxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1fbmFtZWBdOiAnJyxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1gXTogdW5kZWZpbmVkLFxuICAgICAgICB9KSk7XG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ2NsaWVudCcpIHtcbiAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkQ2xpZW50Q3VpdChudWxsKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihudWxsKTtcbiAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVIZWFkZXJDb2RlU3VibWl0ID0gYXN5bmMgKGZpZWxkOiBIZWFkZXJGaWVsZCwgY29uZmlnOiBNb2R1bGVDb25maWc8YW55PikgPT4ge1xuICAgICAgICBjb25zdCBjb2RlVmFsdWUgPSBmb3JtRGF0YVtgJHtmaWVsZH1fY29kZWAgYXMga2V5b2YgU2FsZXNJbnZvaWNlXSBhcyBzdHJpbmc7XG4gICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG4gICAgICAgIGlmICghY29uZmlnPy5yZWxhdGlvbmFsRmllbGRzKSByZXR1cm4gdG9hc3QuZXJyb3IoYENvbmZpZ3VyYWNpw7NuIHJlbGFjaW9uYWwgZmFsdGFudGUgcGFyYSAke2ZpZWxkfWApO1xuXG4gICAgICAgIGNvbnN0IHsgZW5kcG9pbnQsIHJlbGF0aW9uYWxGaWVsZHMgfSA9IGNvbmZpZztcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogcmVsYXRpb25hbEZpZWxkcy5jb2RlRmllbGQgYXMgc3RyaW5nLCB2YWx1ZTogY29kZVZhbHVlIH1dKTtcbiAgICAgICAgICAgIGlmIChpdGVtKSB7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSAnc2FsZXNfb3JkZXInICYmIFN0cmluZyhpdGVtLnN0YXR1cykgIT09ICczJykge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignU29sbyBzZSBwdWVkZW4gY2FyZ2FyIHBlZGlkb3MgYXV0b3JpemFkb3MuJyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZmllbGQsIGl0ZW0pO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCcke2l0ZW1bcmVsYXRpb25hbEZpZWxkcy5uYW1lRmllbGQgYXMgc3RyaW5nXX0nIHNlbGVjY2lvbmFkby5gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyDDrXRlbSBjb24gZXNlIGPDs2RpZ28uYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikgeyB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGJ1c2NhciBwb3IgY8OzZGlnby5cIik7IH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSGVhZGVyQ2xlYXIgPSAoZmllbGQ6IEhlYWRlckZpZWxkKSA9PiB7XG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBbYCR7ZmllbGR9X2lkYF06IG51bGwsXG4gICAgICAgICAgICBbYCR7ZmllbGR9X2NvZGVgXTogbnVsbCxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1fbmFtZWBdOiBudWxsLFxuICAgICAgICAgICAgW2Ake2ZpZWxkfWBdOiB1bmRlZmluZWQsXG4gICAgICAgIH0pKTtcbiAgICAgICAgaWYgKGZpZWxkID09PSAnY2xpZW50Jykge1xuICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMoW10pO1xuICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKG51bGwpO1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWRDbGllbnRDdWl0KG51bGwpO1xuICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXJzIGRlIG1vZGFsIGRlIGhpc3RvcmlhbCAoaWTDqW50aWNvcyBhIFBlZGlkb3MpXG4gICAgY29uc3QgaGFuZGxlT3Blbkhpc3RvcnlNb2RhbCA9IChwcm9kdWN0SWQ6IG51bWJlciwgdHlwZTogJ3ByaWNlJyB8ICdjb3N0JywgcHJvZHVjdE5hbWU6IHN0cmluZykgPT4ge1xuICAgICAgICBpZiAoIXByb2R1Y3RJZCkgeyB0b2FzdC53YXJuKCdFbCDDrXRlbSBubyB0aWVuZSB1biBwcm9kdWN0byBzZWxlY2Npb25hZG8uJyk7IHJldHVybjsgfVxuICAgICAgICBpZiAodHlwZSA9PT0gJ3ByaWNlJykge1xuICAgICAgICAgICAgc2V0SGlzdG9yeU1vZGFsU3RhdGUoe1xuICAgICAgICAgICAgICAgIGlzT3BlbjogdHJ1ZSwgdGl0bGU6IGBIaXN0b3JpYWwgZGUgUHJlY2lvcyBkZSBWZW50YTogJHtwcm9kdWN0TmFtZX1gLCBlbmRwb2ludDogJ3Byb2R1Y3RzL3NhbGVzLWhpc3RvcnknLFxuICAgICAgICAgICAgICAgIHByb2R1Y3RJZDogcHJvZHVjdElkLCBjbGllbnRJZDogZm9ybURhdGEuY2xpZW50X2lkIHx8IG51bGwsIGNvbHVtbnM6IHByaWNlTGlzdENvbHVtbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEhpc3RvcnlNb2RhbFN0YXRlKHtcbiAgICAgICAgICAgICAgICBpc09wZW46IHRydWUsIHRpdGxlOiAnSGlzdG9yaWFsIGRlIENvc3RvcyBkZSBDb21wcmEnLCBlbmRwb2ludDogJ3Byb2R1Y3RzL3B1cmNoYXNlcy1oaXN0b3J5JyxcbiAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCwgY2xpZW50SWQ6IGZvcm1EYXRhLmNsaWVudF9pZCB8fCBudWxsLCBjb2x1bW5zOiBjb3N0TGlzdENvbHVtbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaGFuZGxlQ2xvc2VIaXN0b3J5TW9kYWwgPSAoKSA9PiBzZXRIaXN0b3J5TW9kYWxTdGF0ZShpbml0aWFsSGlzdG9yeU1vZGFsU3RhdGUpO1xuXG4gICAgY29uc3QgaGFuZGxlQ2xvc2VTdG9ja0FsZXJ0ID0gKCkgPT4ge1xuICAgICAgICBzZXRTdG9ja0FsZXJ0KHByZXYgPT4gKHsgLi4ucHJldiwgb3BlbjogZmFsc2UgfSkpO1xuICAgICAgICBjb25zdCBjb250aW51ZVNhdmUgPSBwZW5kaW5nQWZ0ZXJTdG9ja0Fja1JlZi5jdXJyZW50O1xuICAgICAgICBwZW5kaW5nQWZ0ZXJTdG9ja0Fja1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgY29udGludWVTYXZlPy4oKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlUXVhbnRpdHlCbHVyID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3QgaXRlbSA9IGl0ZW1zW2luZGV4XTtcbiAgICAgICAgaWYgKCFpdGVtIHx8ICFpc0xpbmVPdmVyQXZhaWxhYmxlU3RvY2soaXRlbSkpIHJldHVybjtcbiAgICAgICAgcGVuZGluZ0FmdGVyU3RvY2tBY2tSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIHNldFN0b2NrQWxlcnQoe1xuICAgICAgICAgICAgb3BlbjogdHJ1ZSxcbiAgICAgICAgICAgIHRpdGxlOiAnU3RvY2sgaW5zdWZpY2llbnRlJyxcbiAgICAgICAgICAgIG1lc3NhZ2U6IHN0b2NrRXhjZXNzTWVzc2FnZShpdGVtKSxcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGlmICgobG9hZGluZ0RhdGEgfHwgaXNJbml0aWFsTG9hZGluZykgJiYgbW9kZSA9PT0gJ2VkaXQnKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvciAmJiBtb2RlID09PSAnZWRpdCcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBkYXRvczoge2Vycm9yfTwvZGl2PjtcblxuICAgIGNvbnN0IHRvdGFsTGFiZWxTdHlsZSA9IFwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0XCI7XG5cblxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LTZcIj5cblxuICAgICAgICAgICAgICAgIHsvKiDinIUgMi4gQkxPUVVFIERFIE9WRVJMQVkgKE5VRVZPKSAqL31cbiAgICAgICAgICAgICAgICB7LyogU2UgbXVlc3RyYSBzaSAnaXNMb2FkaW5nJyAodHUgZXN0YWRvIGxvY2FsKSBvICdzYXZpbmcnIChlbCBob29rKSBzb24gdHJ1ZSAqL31cbiAgICAgICAgICAgICAgICB7KGlzTG9hZGluZyB8fCBzYXZpbmcpICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHotNTAgYmctd2hpdGUvODAgcm91bmRlZC1sZyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiYWNrZHJvcC1ibHVyLVsxcHhdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBwLTYgYmctd2hpdGUgc2hhZG93LXhsIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItaW5kaWdvLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNwaW5uZXIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtaW5kaWdvLTYwMCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5Db25lY3RhbmRvIGNvbiBBUkNBPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgYW5pbWF0ZS1wdWxzZVwiPk9idGVuaWVuZG8gQ0FFIHkgdmFsaWRhbmRvIGRhdG9zLi4uPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge21vZGUgPT09ICdjcmVhdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdDcmVhciBGYWN0dXJhIGRlIFZlbnRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBgRWRpdGFuZG8gRmFjdHVyYSAke2Zvcm1EYXRhLmludm9pY2VfbnVtYmVyICE9IG51bGwgJiYgU3RyaW5nKGZvcm1EYXRhLmludm9pY2VfbnVtYmVyKS50cmltKCkgIT09ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIoZm9ybURhdGEuc2VyaWVzLCBmb3JtRGF0YS5hZmlwX3BvcywgZm9ybURhdGEuaW52b2ljZV9udW1iZXIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgIyR7aWR9YH1gfVxuICAgICAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgICAgICB7LyogLS0tIFNFQ0NJw5NOIERFIENBQkVDRVJBIChBZGFwdGFkYSkgLS0tICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNlwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQ29sdW1uYSAxICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIE5VRVZPOiBQZWRpZG8gT3JpZ2VuICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UGVkaWRvIE9yaWdlbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLnNhbGVzX29yZGVyX2NvZGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17Zm9ybURhdGEuc2FsZXNfb3JkZXJfbmFtZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnc2FsZXNfb3JkZXInLCBuZXdDb2RlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVIZWFkZXJDb2RlU3VibWl0KCdzYWxlc19vcmRlcicsIHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdzYWxlc19vcmRlcicsIHNhbGVzT3JkZXJzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShkZWZhdWx0SW5pdGlhbERhdGEpOyBzZXRJdGVtcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhbXSk7IHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Q2xpZW50ZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtmb3JtRGF0YS5jbGllbnRfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5jbGllbnRfbmFtZSB8fCBmb3JtRGF0YS5jbGllbnQ/Lm5hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UoJ2NsaWVudCcsIG5ld0NvZGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ2NsaWVudCcsIGNsaWVudGVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdjbGllbnQnLCBjbGllbnRlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSGVhZGVyQ2xlYXIoJ2NsaWVudCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlZlbmRlZG9yPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuc2FsZXNwZXJzb25fY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5zYWxlc3BlcnNvbl9uYW1lIHx8IGZvcm1EYXRhLnNhbGVzcGVyc29uPy5uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhuZXdDb2RlKSA9PiBoYW5kbGVIZWFkZXJDb2RlQ2hhbmdlKCdzYWxlc3BlcnNvbicsIG5ld0NvZGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ3NhbGVzcGVyc29uJywgdmVuZGVkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnc2FsZXNwZXJzb24nLCB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVIZWFkZXJDbGVhcignc2FsZXNwZXJzb24nKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7LyogQ29sdW1uYSAyICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIE5VRVZPOiBTZXJpZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlNlcmllICgqKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VyaWVzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnNlcmllcyB8fCAnQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0NsaWVudFRheEV4ZW1wdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbSBiZy13aGl0ZSBkaXNhYmxlZDpiZy1ncmF5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDbGllbnRUYXhFeGVtcHQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRVwiPkU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFcIj5BPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJcIj5CPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNcIj5DPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmVjaGEgRmFjdHVyYSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpbnZvaWNlX2RhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuaW52b2ljZV9kYXRlPy5zcGxpdCgnVCcpWzBdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GZWNoYSBFbnRyZWdhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVsaXZlcnlfZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kZWxpdmVyeV9kYXRlPy5zcGxpdCgnVCcpWzBdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7LyogQ29sdW1uYSAzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Db21wcmFkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtmb3JtRGF0YS5idXllcl9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLmJ1eWVyX25hbWUgfHwgZm9ybURhdGEuYnV5ZXI/Lm5hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KG5ld0NvZGUpID0+IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UoJ2J1eWVyJywgbmV3Q29kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCgnYnV5ZXInLCBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnYnV5ZXInLCBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSGVhZGVyQ2xlYXIoJ2J1eWVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VHJhbnNwb3J0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2Zvcm1EYXRhLnRyYW5zcG9ydF9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnRyYW5zcG9ydF9uYW1lIHx8IGZvcm1EYXRhLnRyYW5zcG9ydD8ubmFtZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgndHJhbnNwb3J0JywgbmV3Q29kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCgndHJhbnNwb3J0JywgdHJhbnNwb3J0ZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoJ3RyYW5zcG9ydCcsIHRyYW5zcG9ydGVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVIZWFkZXJDbGVhcigndHJhbnNwb3J0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+TW9uZWRhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuY3VycmVuY3lfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZVZhbHVlPXtmb3JtRGF0YS5jdXJyZW5jeV9uYW1lIHx8IGZvcm1EYXRhLmN1cnJlbmN5Py5uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyhuZXdDb2RlKSA9PiBoYW5kbGVIZWFkZXJDb2RlQ2hhbmdlKCdjdXJyZW5jeScsIG5ld0NvZGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ2N1cnJlbmN5JywgbW9uZWRhc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnY3VycmVuY3knLCBtb25lZGFzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiBoYW5kbGVIZWFkZXJDbGVhcignY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIE5VRVZPOiBDQU1QTyBUQVNBIERFIENBTUJJTyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlRpcG8gZGUgY2FtYmlvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBmbGV4LWNvbCBnYXAtMiBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206Z2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImV4Y2hhbmdlX3JhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmV4Y2hhbmdlX3JhdGUgPz8gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtcHR5V2hlblplcm89e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGV4Y2hhbmdlX3JhdGU6IG51bSB8fCAxIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5PXtpc0V4Y2hhbmdlUmF0ZVJlYWRvbmx5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRXhjaGFuZ2VSYXRlUmVhZG9ubHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtaW4tdy0wIGZsZXgtMSBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzaG93X2N1cnJlbmN5X2VxdWl2YWxlbmNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2hvd19jdXJyZW5jeV9lcXVpdmFsZW5jZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXshIWZvcm1EYXRhLnNob3dfY3VycmVuY3lfZXF1aXZhbGVuY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUhlYWRlckNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJoLTQgdy00IHJvdW5kZWQgYm9yZGVyLWdyYXktMzAwIHRleHQtaW5kaWdvLTYwMCBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic2hvd19jdXJyZW5jeV9lcXVpdmFsZW5jZVwiIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTkwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1vc3RyYXIgdmFsb3IgZW4gZG9sYXJlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIDQgKFRleHRhcmVhcykgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk7CuiBPcmRlbiBDb21wcmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwdXJjaGFzZV9vcmRlcl9udW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucHVyY2hhc2Vfb3JkZXJfbnVtYmVyIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIiBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkRpcmVjY2nDs24gZGUgRW50cmVnYSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRlbGl2ZXJ5X2FkZHJlc3Nfc2VsZWN0b3JcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRWwgdmFsb3Igc2VsZWNjaW9uYWRvIGVuIGVsIHNlbGVjdG9yIGRlYmUgc2VyICdDVVNUT01fTkVXX0FERFJFU1MnIG8gbGEgZGlyZWNjacOzbiBhY3R1YWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpc0N1c3RvbUFkZHJlc3MgPyAnQ1VTVE9NX05FV19BRERSRVNTJyA6ICh0ZW1wRGVsaXZlcnlBZGRyZXNzIHx8IChjbGllbnRBZGRyZXNzZXMubGVuZ3RoID4gMCA/IGNsaWVudEFkZHJlc3Nlc1swXSA6ICcnKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRGVsaXZlcnlBZGRyZXNzQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWZvcm1EYXRhLmNsaWVudF9pZH0gLy8gRGVzaGFiaWxpdGFkbyBzaSBubyBoYXkgY2xpZW50ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNjaW9uYSB1bmEgZGlyZWNjacOzbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9wY2lvbmVzIGRlbCBjbGllbnRlIChzaGlwYWRkcmVzcyBhcnJheSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGNsaWVudEFkZHJlc3NlcyB8fCBbXSkubWFwKChhZGRyZXNzLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtpbmRleH0gdmFsdWU9e2FkZHJlc3N9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9wY2nDs24gJ090cmEgRGlyZWNjacOzbicgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1VTVE9NX05FV19BRERSRVNTXCI+LS0tIEluZ3Jlc2FyIE90cmEgRGlyZWNjacOzbiAtLS08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSA3LiBJTlBVVCBWSVNJQkxFIHNpIHNlIHNlbGVjY2lvbmEgJ090cmEgRGlyZWNjacOzbicgbyBzaSBsYSBkaXJlY2Npw7NuIGNhcmdhZGEgZXJhIGN1c3RvbSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQ3VzdG9tQWRkcmVzcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVsaXZlcnlfYWRkcmVzc19pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcERlbGl2ZXJ5QWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRUZW1wRGVsaXZlcnlBZGRyZXNzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZ3Jlc2UgbGEgbnVldmEgZGlyZWNjacOzbiBkZSBlbnRyZWdhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1pbmRpZ28tNTAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cblxuICAgICAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgSVRFTVMgLS0tICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPkl0ZW1zIGRlIGxhIEZhY3R1cmE8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1lZGl1bSAkeyFmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/ICd0ZXh0LWluZGlnby02MDAnIDogJ3RleHQtZ3JheS01MDAnfWB9PkltcC4gR2xvYmFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb2dnbGVTd2l0Y2ggZW5hYmxlZD17Zm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgPz8gZmFsc2V9IG9uQ2hhbmdlPXtoYW5kbGVUYXhNb2RlQ2hhbmdlfSBzckxhYmVsPVwiTW9kbyBkZSBpbXB1ZXN0b3NcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/ICd0ZXh0LWluZGlnby02MDAnIDogJ3RleHQtZ3JheS01MDAnfWB9PkltcC4gcG9yIMONdGVtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUYWJsYSBkZSBJdGVtcyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdy0yLzVcIj5BcnTDrWN1bG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5TdG9jazwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+UC4gVW5pdC4gKHtzaW1ib2xvTW9uZWRhfSk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBoaWRkZW5cIj5EZXNjLiAoTW9udG8pPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDinIUgTlVFVk86IENvbWlzacOzbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgaGlkZGVuXCI+Q29taXNpw7NuICU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlN1YnRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5JbXB1ZXN0b3M8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5VdGlsaWRhZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG90YWwgTMOtbmVhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5BY2MuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN1YnRvdGFsID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRpc2NvdW50ID0gTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGluZVN1YnRvdGFsID0gc3VidG90YWwgLSBkaXNjb3VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVDb3N0ID0gKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLmNvc3RfcHJpY2UpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHByb2ZpdCA9IChsaW5lU3VidG90YWwgLSBsaW5lQ29zdCkgLyBsaW5lQ29zdCAqIDEwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXhUb3RhbCA9ICFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IChpdGVtLnRheGVzIHx8IFtdKS5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXhUb3RhbDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLnRlbXBJZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2l0ZW0ucHJvZHVjdF9jb2RlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5wcm9kdWN0X25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsobmV3Q29kZSkgPT4gaGFuZGxlSXRlbUNvZGVDaGFuZ2UoaW5kZXgsIG5ld0NvZGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSXRlbUNvZGVTdWJtaXQoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgnaXRlbScsIGFydGljdWxvc01vZHVsZUNvbmZpZywgaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSXRlbUNsZWFyKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXNrPVwic2t1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmFibGVBdXRvY29tcGxldGU9e3RydWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b2NvbXBsZXRlQ29uZmlnPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZHBvaW50OiBhcnRpY3Vsb3NNb2R1bGVDb25maWcuZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVGaWVsZDogJ3NrdScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVGaWVsZDogJ25hbWUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hQYXJhbXM6IGFydGljdWxvc0l0ZW1TZWFyY2hGaWx0ZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdDogKHByb2R1Y3QpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1BdXRvY29tcGxldGVTZWxlY3QoaW5kZXgsIHByb2R1Y3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxEZWNpbWFsSW5wdXQgbmFtZT1cInF1YW50aXR5XCIgdmFsdWU9e2l0ZW0ucXVhbnRpdHl9IG9uQ2hhbmdlPXtudW0gPT4gZGlzcGF0Y2hJdGVtTnVtZXJpY0NoYW5nZShpbmRleCwgJ3F1YW50aXR5JywgbnVtKX0gb25CbHVyPXsoKSA9PiBoYW5kbGVRdWFudGl0eUJsdXIoaW5kZXgpfSBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctMjAgcHgtMiBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIC8+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdG9ja19xdWFudGl0eX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCBuYW1lPVwidW5pdF9wcmljZVwiIHZhbHVlPXtpdGVtLnVuaXRfcHJpY2V9IG9uQ2hhbmdlPXtudW0gPT4gZGlzcGF0Y2hJdGVtTnVtZXJpY0NoYW5nZShpbmRleCwgJ3VuaXRfcHJpY2UnLCBudW0pfSBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctMjggcHgtMiBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXAgaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0IG5hbWU9XCJkaXNjb3VudF9hbW91bnRcIiB2YWx1ZT17aXRlbS5kaXNjb3VudF9hbW91bnR9IG9uQ2hhbmdlPXtudW0gPT4gZGlzcGF0Y2hJdGVtTnVtZXJpY0NoYW5nZShpbmRleCwgJ2Rpc2NvdW50X2Ftb3VudCcsIG51bSl9IGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy0yNCBweC0yIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSBOVUVWTzogQ2VsZGEgQ29taXNpw7NuICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwIGhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dCBuYW1lPVwiY29tbWlzc2lvbl9wZXJjZW50YWdlXCIgdmFsdWU9e2l0ZW0uY29tbWlzc2lvbl9wZXJjZW50YWdlfSBvbkNoYW5nZT17bnVtID0+IGRpc3BhdGNoSXRlbU51bWVyaWNDaGFuZ2UoaW5kZXgsICdjb21taXNzaW9uX3BlcmNlbnRhZ2UnLCBudW0pfSBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctMjAgcHgtMiBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUobGluZVN1YnRvdGFsLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBmb3JtRGF0YS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShpdGVtVGF4VG90YWwsICdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtICR7cHJvZml0ID49IDAgPyAndGV4dC1ncmVlbi02MDAnIDogJ3RleHQtcmVkLTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUocHJvZml0LCAncGVyY2VudHVhbCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUobGluZVRvdGFsLCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHNwYWNlLXgtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbkhpc3RvcnlNb2RhbChpdGVtLnByb2R1Y3RfaWQsICdwcmljZScsIGl0ZW0ucHJvZHVjdF9uYW1lKX0gY2xhc3NOYW1lPVwicC0yIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTkwMFwiIHRpdGxlPVwiVmVyIGhpc3RvcmlhbCBkZSBwcmVjaW9zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhVGFncyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuSGlzdG9yeU1vZGFsKGl0ZW0ucHJvZHVjdF9pZCwgJ2Nvc3QnLCBpdGVtLnByb2R1Y3RfbmFtZSl9IGNsYXNzTmFtZT1cInAtMiB0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZ3JheS05MDBcIiB0aXRsZT1cIlZlciBoaXN0b3JpYWwgZGUgY29zdG9zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhV2FyZWhvdXNlIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgZm9ybURhdGEuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5JdGVtVGF4TW9kYWwoaW5kZXgpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTkwMFwiIHRpdGxlPVwiR2VzdGlvbmFyIGltcHVlc3RvcyBkZWwgw610ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGVyY2VudGFnZSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZUl0ZW0oaW5kZXgpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1yZWQtNjAwIGhvdmVyOnRleHQtcmVkLTkwMFwiIHRpdGxlPVwiRWxpbWluYXIgw610ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFUcmFzaCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQWRkSXRlbX0gY2xhc3NOYW1lPVwibXQtNCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWdyZWdhciDDjXRlbVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgVE9UQUxFUyAtLS0gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0naGlkZGVuJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RGVzY3VlbnRvIEdsb2JhbCAoTW9udG8pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXNjb3VudF9hbW91bnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGlzY291bnRfYW1vdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgZGlzY291bnRfYW1vdW50OiBudW0gfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5PYnNlcnZhY2lvbmVzOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3Rlc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9IC8vIERhbW9zIG3DoXMgZXNwYWNpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgIWZvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+SW1wdWVzdG9zIEdsb2JhbGVzIEFwbGljYWRvczwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBsaWVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGxpZWRUYXhlcy5tYXAodGF4ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dGF4LnRheF9pZH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT57dGF4LnRheF9uYW1lfSAoe3RheC5yYXRlfSUpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+Tm8gaGF5IGltcHVlc3RvcyBnbG9iYWxlcyBhcGxpY2Fkb3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHAtNCBiZy1ncmF5LTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlN1YnRvdGFsIChJdGVtcyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBoaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIChJdGVtcyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+LSB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbEl0ZW1EaXNjb3VudHMsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBoaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIChHbG9iYWwpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuZ2xvYmFsRGlzY291bnRBbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTIgYm9yZGVyLXQgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSBmb250LXNlbWlib2xkYH0+QmFzZSBJbXBvbmlibGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlfSBmb250LXNlbWlib2xkYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmhhc19pdGVtX2xldmVsX3RheGVzID8gXCJJbXB1ZXN0b3MgKEl0ZW1zKTpcIiA6IFwiSW1wdWVzdG9zIChHbG9iYWwpOlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IHRleHQtbGcgZm9udC1zZW1pYm9sZGB9PlRvdGFsIEZpbmFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbFZhbHVlU3R5bGV9IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5kaWdvLTYwMGB9Pntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogLS0tIEJvdG9uZXMgZGUgR3VhcmRhci9DYW5jZWxhciAtLS0gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgoc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCI+Q2FuY2VsYXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCBpc0luaXRpYWxMb2FkaW5nIHx8IGxvYWRpbmdPcmRlckRhdGF9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyDinIUgQ2FtYmlhbW9zIGVsIGNvbG9yIGJhc2UgYSBpbmRpZ28gc2kgZXN0w6EgY2FyZ2FuZG8gcGFyYSBpbmRpY2FyIFwicHJvY2VzbyBkZWwgc2lzdGVtYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIG1sLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gXG4gICAgICAgICAgICAgICAgICAgICAgICAke3NhdmluZyA/ICdiZy1pbmRpZ28tNTAwIGN1cnNvci13YWl0JyA6ICdiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwJ31gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7KHNhdmluZyB8fCBpc0luaXRpYWxMb2FkaW5nIHx8IGxvYWRpbmdPcmRlckRhdGEpID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNwaW5uZXIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHctNSBoLTUgbXItMlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDinIUgVEVYVE8gRElOw4FNSUNPIFNPTElDSVRBRE8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzYXZpbmcgPyAnUHJvY2VzYW5kbyBlbiBBUkNBLi4uJyA6ICdDYXJnYW5kby4uLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3VhcmRhciBGYWN0dXJhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RhbGVzICovfVxuICAgICAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiBtb2RhbENvbmZpZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxTZWFyY2hNb2RhbFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXtpc01vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RNb2RhbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpZz17bW9kYWxDb25maWd9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7aXNJdGVtVGF4TW9kYWxPcGVuICYmIGN1cnJlbnRJdGVtSW5kZXhGb3JUYXggIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8SXRlbVRheE1vZGFsXG4gICAgICAgICAgICAgICAgICAgICAgICBpc09wZW49e2lzSXRlbVRheE1vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzSXRlbVRheE1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmVJdGVtVGF4ZXN9XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtPXtpdGVtc1tjdXJyZW50SXRlbUluZGV4Rm9yVGF4XX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudFRheGVzPXtjbGllbnRUYXhlc31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudFRheENvbmRpdGlvbj17Y2xpZW50VGF4Q29uZGl0aW9ufVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge2hpc3RvcnlNb2RhbFN0YXRlLmlzT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxQcm9kdWN0SGlzdG9yeU1vZGFsXG4gICAgICAgICAgICAgICAgICAgICAgICBpc09wZW49e2hpc3RvcnlNb2RhbFN0YXRlLmlzT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlSGlzdG9yeU1vZGFsfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2hpc3RvcnlNb2RhbFN0YXRlLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kcG9pbnQ9e2hpc3RvcnlNb2RhbFN0YXRlLmVuZHBvaW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdElkPXtoaXN0b3J5TW9kYWxTdGF0ZS5wcm9kdWN0SWQhfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50SWQ9e2hpc3RvcnlNb2RhbFN0YXRlLmNsaWVudElkIX0gLy8gUGFzYW1vcyBjbGllbnRJZFxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17aGlzdG9yeU1vZGFsU3RhdGUuY29sdW1uc31cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxBbGVydE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17c3RvY2tBbGVydC5vcGVufVxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZVN0b2NrQWxlcnR9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXtzdG9ja0FsZXJ0LnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlPXtzdG9ja0FsZXJ0Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2F1dGhNb2RhbH1cbiAgICAgICAgPC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9mYWN0dXJhc192ZW50YS9wYWdlcy9GYWN0dXJhc1ZlbnRhRm9ybVBhZ2UudHN4In0=