import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/components/AuthLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/auth/components/AuthLayout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { OrganizationLogo } from "/src/components/common/OrganizationLogo.tsx";
export const AuthLayout = ({ children }) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center min-h-screen bg-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
      OrganizationLogo,
      {
        alt: "Logo ERP",
        className: "h-auto max-h-20 w-full max-w-[280px] object-contain"
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/auth/components/AuthLayout.tsx",
        lineNumber: 32,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/features/auth/components/AuthLayout.tsx",
      lineNumber: 31,
      columnNumber: 17
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/app/src/features/auth/components/AuthLayout.tsx",
    lineNumber: 30,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/features/auth/components/AuthLayout.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
};
_c = AuthLayout;
var _c;
$RefreshReg$(_c, "AuthLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/auth/components/AuthLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/auth/components/AuthLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWW9COzs7Ozs7Ozs7Ozs7Ozs7O0FBWnBCLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0Msd0JBQXdCO0FBTTFCLGFBQU1DLGFBQWFBLENBQUMsRUFBRUMsU0FBMEIsTUFBTTtBQUN6RCxTQUNJLHVCQUFDLFNBQUksV0FBVSw2REFDWCxpQ0FBQyxTQUFJLFdBQVUsK0RBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0NBQ1g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLEtBQUk7QUFBQSxRQUNKLFdBQVU7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1FLEtBSHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0NBO0FBQUFBLE9BUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRVI7QUFBRUMsS0FkV0Y7QUFBVSxJQUFBRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJPcmdhbml6YXRpb25Mb2dvIiwiQXV0aExheW91dCIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aExheW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE9yZ2FuaXphdGlvbkxvZ28gfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9Pcmdhbml6YXRpb25Mb2dvJztcblxuaW50ZXJmYWNlIEF1dGhMYXlvdXRQcm9wcyB7XG4gICAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbn1cblxuZXhwb3J0IGNvbnN0IEF1dGhMYXlvdXQgPSAoeyBjaGlsZHJlbiB9OiBBdXRoTGF5b3V0UHJvcHMpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLXNjcmVlbiBiZy1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgcC04IHNwYWNlLXktNiBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPE9yZ2FuaXphdGlvbkxvZ29cbiAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkxvZ28gRVJQXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtYXV0byBtYXgtaC0yMCB3LWZ1bGwgbWF4LXctWzI4MHB4XSBvYmplY3QtY29udGFpblwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9hdXRoL2NvbXBvbmVudHMvQXV0aExheW91dC50c3gifQ==