import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AppRouter.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/routes/AppRouter.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ClientesListPage } from "/src/features/clientes/pages/ClientesListPage.tsx";
import { createBrowserRouter, Navigate, Outlet, RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { ProtectedRoute } from "/src/routes/ProtectedRoute.tsx";
import { PermissionRoute } from "/src/routes/PermissionRoute.tsx";
import { MainLayout } from "/src/components/layouts/MainLayout.tsx";
import { DashboardPage } from "/src/features/dashboards/pages/DashboardPage.tsx";
import { ClienteDetailPage } from "/src/features/clientes/pages/ClientesDetailPage.tsx";
import { ClienteEditPage } from "/src/features/clientes/pages/ClientesEditPage.tsx";
import { ArticulosListPage } from "/src/features/articulos/pages/ArticulosListPage.tsx";
import { ArticuloDetailPage } from "/src/features/articulos/pages/ArticulosDetailPage.tsx";
import { ArticuloEditPage } from "/src/features/articulos/pages/ArticulosEditPage.tsx";
import { ProveedoresListPage } from "/src/features/proveedores/pages/ProveedoresListPage.tsx";
import { ProveedorDetailPage } from "/src/features/proveedores/pages/ProveedoresDetailPage.tsx";
import { ProveedorEditPage } from "/src/features/proveedores/pages/ProveedoresEditPage.tsx";
import { LoginPage } from "/src/features/auth/pages/LoginPage.tsx";
import { ClienteCreatePage } from "/src/features/clientes/pages/ClientesCreatePage.tsx";
import { ArticuloCreatePage } from "/src/features/articulos/pages/ArticulosCreatePage.tsx";
import { ProveedorCreatePage } from "/src/features/proveedores/pages/ProveedoresCreatePage.tsx";
import { UsuariosListPage } from "/src/features/usuarios/pages/UsuariosListPage.tsx";
import { UsuarioDetailPage } from "/src/features/usuarios/pages/UsuariosDetailPage.tsx";
import { UsuarioEditPage } from "/src/features/usuarios/pages/UsuariosEditPage.tsx";
import { UsuarioCreatePage } from "/src/features/usuarios/pages/UsuariosCreatePage.tsx";
import { ForgotPasswordPage } from "/src/features/auth/pages/ForgotPasswordPage.tsx";
import { ProfilesListPage } from "/src/features/profiles/pages/ProfilesListPage.tsx";
import { ProfileEditPage } from "/src/features/profiles/pages/ProfileEditPage.tsx";
import { ProfileCreatePage } from "/src/features/profiles/pages/ProfileCreatePage.tsx";
import { PlanDeCuentasListPage } from "/src/features/plan_de_cuentas/pages/PlanDeCuentasListPage.tsx";
import { PlanDeCuentasCreatePage } from "/src/features/plan_de_cuentas/pages/PlanDeCuentasCreatePage.tsx";
import { PlanDeCuentasDetailPage } from "/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx";
import { PlanDeCuentasEditPage } from "/src/features/plan_de_cuentas/pages/PlanDeCuentasEditPage.tsx";
import { ChequesListPage } from "/src/features/cheques/pages/ChequesListPage.tsx";
import { ChequesDetailPage } from "/src/features/cheques/pages/ChequesDetailPage.tsx";
import { BancosListPage } from "/src/features/bancos/pages/BancosListPage.tsx";
import { BancosCreatePage } from "/src/features/bancos/pages/BancosCreatePage.tsx";
import { BancosDetailPage } from "/src/features/bancos/pages/BancosDetailPage.tsx";
import { BancosEditPage } from "/src/features/bancos/pages/BancosEditPage.tsx";
import { CajasListPage } from "/src/features/cajas/pages/CajasListPage.tsx";
import { CajasCreatePage } from "/src/features/cajas/pages/CajasCreatePage.tsx";
import { CajasDetailPage } from "/src/features/cajas/pages/CajasDetailPage.tsx";
import { CajasEditPage } from "/src/features/cajas/pages/CajasEditPage.tsx";
import { MovimientosBancosListPage } from "/src/features/movimientos_bancos/pages/MovimientosBancosListPage.tsx";
import { MovimientosBancosFormPage } from "/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx";
import { MovimientosBancosDetailPage } from "/src/features/movimientos_bancos/pages/MovimientosBancosDetailPage.tsx";
import { MovStockListPage } from "/src/features/mov_stock/pages/MovStockListPage.tsx";
import { MovStockCreatePage } from "/src/features/mov_stock/pages/MovStockCreatePage.tsx";
import { MovStockDetailPage } from "/src/features/mov_stock/pages/MovStockDetailPage.tsx";
import { MovStockEditPage } from "/src/features/mov_stock/pages/MovStockEditPage.tsx";
import { FractioningCreatePage } from "/src/features/fractionings/pages/FractioningCreatePage.tsx";
import { FractioningListPage } from "/src/features/fractionings/pages/FractioningListPage.tsx";
import { FractioningDetailPage } from "/src/features/fractionings/pages/FractioningDetailPage.tsx";
import { ComprasListPage } from "/src/features/compras/pages/ComprasListPage.tsx";
import { ComprasFormPage } from "/src/features/compras/pages/ComprasFormPage.tsx";
import { ComprasDetailPage } from "/src/features/compras/pages/ComprasDetailPage.tsx";
import { OrdenesPagoListPage } from "/src/features/ordenes_pago/pages/OrdenesPagoListPage.tsx";
import { OrdenesPagoDetailPage } from "/src/features/ordenes_pago/pages/OrdenesPagoDetailPage.tsx";
import { OrdenesPagoFormPage } from "/src/features/ordenes_pago/pages/OrdenesPagoFormPage.tsx";
import { ImpuestosListPage } from "/src/features/impuestos/pages/ImpuestosListPage.tsx";
import { ImpuestosCreatePage } from "/src/features/impuestos/pages/ImpuestosCreatePage.tsx";
import { ImpuestosDetailPage } from "/src/features/impuestos/pages/ImpuestosDetailPage.tsx";
import { ImpuestosEditPage } from "/src/features/impuestos/pages/ImpuestosEditPage.tsx";
import { ComisionesVendedoresListPage } from "/src/features/comisiones_vendedores/pages/ComisionesVendedoresListPage.tsx";
import { ComisionesVendedoresCreatePage } from "/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx";
import { ComisionesVendedoresDetailPage } from "/src/features/comisiones_vendedores/pages/ComisionesVendedoresDetailPage.tsx";
import { ComisionesVendedoresEditPage } from "/src/features/comisiones_vendedores/pages/ComisionesVendedoresEditPage.tsx";
import { OrganizationDetailsPage } from "/src/features/organization_details/pages/OrganizationDetailsPage.tsx";
import { TablasAccesoriasPage } from "/src/features/tablas_accesorias/pages/TablasAccesoriasPage.tsx";
import { TransportesListPage } from "/src/features/transportes/pages/TransportesListPage.tsx";
import { TransportesCreatePage } from "/src/features/transportes/pages/TransportesCreatePage.tsx";
import { TransportesDetailPage } from "/src/features/transportes/pages/TransportesDetailPage.tsx";
import { TransportesEditPage } from "/src/features/transportes/pages/TransportesEditPage.tsx";
import { MonedasListPage } from "/src/features/monedas/pages/MonedasListPage.tsx";
import { MonedasCreatePage } from "/src/features/monedas/pages/MonedasCreatePage.tsx";
import { MonedasDetailPage } from "/src/features/monedas/pages/MonedasDetailPage.tsx";
import { MonedasEditPage } from "/src/features/monedas/pages/MonedasEditPage.tsx";
import { VendedoresListPage } from "/src/features/vendedores/pages/VendedoresListPage.tsx";
import { VendedoresCreatePage } from "/src/features/vendedores/pages/VendedoresCreatePage.tsx";
import { VendedoresDetailPage } from "/src/features/vendedores/pages/VendedoresDetailPage.tsx";
import { VendedoresEditPage } from "/src/features/vendedores/pages/VendedoresEditPage.tsx";
import { CompradoresListPage } from "/src/features/compradores/pages/CompradoresListPage.tsx";
import { CompradoresCreatePage } from "/src/features/compradores/pages/CompradoresCreatePage.tsx";
import { CompradoresDetailPage } from "/src/features/compradores/pages/CompradoresDetailPage.tsx";
import { CompradoresEditPage } from "/src/features/compradores/pages/CompradoresEditPage.tsx";
import { PedidosVentaListPage } from "/src/features/pedidos_venta/pages/PedidosVentaListPage.tsx";
import { PedidosVentaFormPage } from "/src/features/pedidos_venta/pages/PedidosVentaFormPage.tsx";
import { PedidosVentaDetailPage } from "/src/features/pedidos_venta/pages/PedidosVentaDetailPage.tsx";
import { AutorizacionPedidosListPage } from "/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx";
import { AutorizacionPedidoDetailPage } from "/src/features/autorizacion_pedidos/pages/AutorizacionPedidoDetailPage.tsx";
import { FacturasVentaListPage } from "/src/features/facturas_venta/pages/FacturasVentaListPage.tsx";
import { FacturasVentaFormPage } from "/src/features/facturas_venta/pages/FacturasVentaFormPage.tsx";
import { FacturasVentaDetailPage } from "/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx";
import { CobranzasListPage } from "/src/features/cobranzas/pages/CobranzasListPage.tsx";
import { CobranzasFormPage } from "/src/features/cobranzas/pages/CobranzasFormPage.tsx";
import { CobranzasDetailPage } from "/src/features/cobranzas/pages/CobranzasDetailPage.tsx";
import { ListasDePreciosListPage } from "/src/features/lista_precios/pages/ListasPreciosListPage.tsx";
import { ListasDePreciosDetailPage } from "/src/features/lista_precios/pages/ListasPreciosDetailPage.tsx";
import { ListasDePreciosFormPage } from "/src/features/lista_precios/pages/ListasPreciosFormPage.tsx";
import { RemitosListPage } from "/src/features/remitos/pages/RemitosListPage.tsx";
import { RemitosFormPage } from "/src/features/remitos/pages/RemitosFormPage.tsx";
import { RemitosDetailPage } from "/src/features/remitos/pages/RemitosDetailPage.tsx";
import { NotasCreditoListPage } from "/src/features/notas_credito/pages/NotasCreditoListPage.tsx";
import { NotasCreditoFormPage } from "/src/features/notas_credito/pages/NotasCreditoFormPage.tsx";
import { NotasCreditoDetailPage } from "/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx";
import { NotasFinancierasListPage } from "/src/features/notas_financieras/pages/NotasFinancierasListPage.tsx";
import { NotasFinancierasFormPage } from "/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx";
import { NotasFinancierasDetailPage } from "/src/features/notas_financieras/pages/NotasFinancierasDetailPage.tsx";
import { NotasCreditoCompraListPage } from "/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx";
import { NotasCreditoCompraFormPage } from "/src/features/notas_credito_compra/pages/NotasCreditoCompraFormPage.tsx";
import { NotasCreditoCompraDetailPage } from "/src/features/notas_credito_compra/pages/NotasCreditoCompraDetailPage.tsx";
import { NotasFinancierasCompraListPage } from "/src/features/notas_financieras_compra/pages/NotasFinancierasCompraListPage.tsx";
import { NotasFinancierasCompraFormPage } from "/src/features/notas_financieras_compra/pages/NotasFinancierasCompraFormPage.tsx";
import { NotasFinancierasCompraDetailPage } from "/src/features/notas_financieras_compra/pages/NotasFinancierasCompraDetailPage.tsx";
import { MercadoLibrePublicacionesListPage } from "/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesListPage.tsx";
import { MercadoLibrePublicacionesFormPage } from "/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesFormPage.tsx";
import { MercadoLibrePublicacionesDetailPage } from "/src/features/mercadolibre_publicaciones/pages/MercadoLibrePublicacionesDetailPage.tsx";
import { ReportesListPage } from "/src/features/reportes/pages/ReportesListPage.tsx";
import { ReportesRunnerPage } from "/src/features/reportes/pages/ReportesRunnerPage.tsx";
import { LeadsListPage } from "/src/features/leads/pages/LeadsListPage.tsx";
import { LeadsDetailPage } from "/src/features/leads/pages/LeadsDetailPage.tsx";
import { LeadsCreatePage } from "/src/features/leads/pages/LeadsCreatePage.tsx";
import { LeadsEditPage } from "/src/features/leads/pages/LeadsEditPage.tsx";
import { CajasStatementPage } from "/src/features/cajas/pages/CajasStatementPage.tsx";
const router = createBrowserRouter(
  [
    {
      path: "/login",
      element: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
        fileName: "/app/src/routes/AppRouter.tsx",
        lineNumber: 156,
        columnNumber: 12
      }, this)
    },
    {
      path: "/recuperar-password",
      element: /* @__PURE__ */ jsxDEV(ForgotPasswordPage, {}, void 0, false, {
        fileName: "/app/src/routes/AppRouter.tsx",
        lineNumber: 160,
        columnNumber: 12
      }, this)
    },
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, {}, void 0, false, {
        fileName: "/app/src/routes/AppRouter.tsx",
        lineNumber: 164,
        columnNumber: 12
      }, this),
      children: [
        {
          element: /* @__PURE__ */ jsxDEV(MainLayout, {}, void 0, false, {
            fileName: "/app/src/routes/AppRouter.tsx",
            lineNumber: 167,
            columnNumber: 14
          }, this),
          children: [
            {
              path: "dashboard",
              element: /* @__PURE__ */ jsxDEV(DashboardPage, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 171,
                columnNumber: 16
              }, this)
            },
            // AÑADIMOS LA RUTA PARA CLIENTES
            {
              path: "clientes",
              // Este Outlet es opcional, pero permite crear un layout específico para clientes si se necesita
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 177,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/clientes", children: /* @__PURE__ */ jsxDEV(ClientesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 179,
                  columnNumber: 84
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 179,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/clientes", children: /* @__PURE__ */ jsxDEV(ClienteCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 180,
                  columnNumber: 88
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 180,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/clientes", children: /* @__PURE__ */ jsxDEV(ClienteDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 181,
                  columnNumber: 84
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 181,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/clientes", children: /* @__PURE__ */ jsxDEV(ClienteEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 182,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 182,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "articulos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 187,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/articulos", children: /* @__PURE__ */ jsxDEV(ArticulosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 189,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 189,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/articulos", children: /* @__PURE__ */ jsxDEV(ArticuloCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 190,
                  columnNumber: 89
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 190,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/articulos", children: /* @__PURE__ */ jsxDEV(ArticuloDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 191,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 191,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/articulos", children: /* @__PURE__ */ jsxDEV(ArticuloEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 192,
                  columnNumber: 92
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 192,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "mercadolibre-publicaciones",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 197,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/mercadolibre-publicaciones", children: /* @__PURE__ */ jsxDEV(MercadoLibrePublicacionesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 199,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 199,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/mercadolibre-publicaciones", children: /* @__PURE__ */ jsxDEV(MercadoLibrePublicacionesFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 200,
                  columnNumber: 106
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 200,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/mercadolibre-publicaciones", children: /* @__PURE__ */ jsxDEV(MercadoLibrePublicacionesDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 201,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 201,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/mercadolibre-publicaciones", children: /* @__PURE__ */ jsxDEV(MercadoLibrePublicacionesFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 202,
                  columnNumber: 109
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 202,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "leads",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 207,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/leads", children: /* @__PURE__ */ jsxDEV(LeadsListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 209,
                  columnNumber: 81
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 209,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/leads", children: /* @__PURE__ */ jsxDEV(LeadsCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 210,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 210,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/leads", children: /* @__PURE__ */ jsxDEV(LeadsDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 211,
                  columnNumber: 81
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 211,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/leads", children: /* @__PURE__ */ jsxDEV(LeadsEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 212,
                  columnNumber: 88
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 212,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "proveedores",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 217,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/proveedores", children: /* @__PURE__ */ jsxDEV(ProveedoresListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 219,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 219,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/proveedores", children: /* @__PURE__ */ jsxDEV(ProveedorCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 220,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 220,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/proveedores", children: /* @__PURE__ */ jsxDEV(ProveedorDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 221,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 221,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/proveedores", children: /* @__PURE__ */ jsxDEV(ProveedorEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 222,
                  columnNumber: 94
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 222,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "transportes",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 228,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/transportes", children: /* @__PURE__ */ jsxDEV(TransportesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 230,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 230,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/transportes", children: /* @__PURE__ */ jsxDEV(TransportesCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 231,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 231,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/transportes", children: /* @__PURE__ */ jsxDEV(TransportesDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 232,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 232,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/transportes", children: /* @__PURE__ */ jsxDEV(TransportesEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 233,
                  columnNumber: 94
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 233,
                  columnNumber: 38
                }, this) }
              ]
            },
            // AÑADIMOS RUTAS PLACEHOLDER PARA QUE LOS LINKS NO ROMPAN LA APP
            {
              path: "vendedores",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 240,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/vendedores", children: /* @__PURE__ */ jsxDEV(VendedoresListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 242,
                  columnNumber: 86
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 242,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/vendedores", children: /* @__PURE__ */ jsxDEV(VendedoresCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 243,
                  columnNumber: 90
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 243,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/vendedores", children: /* @__PURE__ */ jsxDEV(VendedoresDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 244,
                  columnNumber: 86
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 244,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/vendedores", children: /* @__PURE__ */ jsxDEV(VendedoresEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 245,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 245,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "compradores",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 250,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/compradores", children: /* @__PURE__ */ jsxDEV(CompradoresListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 252,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 252,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/compradores", children: /* @__PURE__ */ jsxDEV(CompradoresCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 253,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 253,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/compradores", children: /* @__PURE__ */ jsxDEV(CompradoresDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 254,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 254,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/compradores", children: /* @__PURE__ */ jsxDEV(CompradoresEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 255,
                  columnNumber: 94
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 255,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "facturas-de-venta",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 260,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/facturas-de-venta", children: /* @__PURE__ */ jsxDEV(FacturasVentaListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 262,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 262,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/facturas-de-venta", children: /* @__PURE__ */ jsxDEV(FacturasVentaFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 263,
                  columnNumber: 97
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 263,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/facturas-de-venta", children: /* @__PURE__ */ jsxDEV(FacturasVentaDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 264,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 264,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/facturas-de-venta", children: /* @__PURE__ */ jsxDEV(FacturasVentaFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 265,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 265,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "notas-credito",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 270,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-credito", children: /* @__PURE__ */ jsxDEV(NotasCreditoListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 272,
                  columnNumber: 89
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 272,
                  columnNumber: 31
                }, this) },
                // Lista
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/notas-credito", children: /* @__PURE__ */ jsxDEV(NotasCreditoFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 273,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 273,
                  columnNumber: 33
                }, this) },
                // Crear (Formulario vacío)
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-credito", children: /* @__PURE__ */ jsxDEV(NotasCreditoDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 274,
                  columnNumber: 89
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 274,
                  columnNumber: 31
                }, this) },
                // Ver Detalle
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/notas-credito", children: /* @__PURE__ */ jsxDEV(NotasCreditoFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 275,
                  columnNumber: 96
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 275,
                  columnNumber: 38
                }, this) }
                // Editar (Formulario con datos)
              ]
            },
            {
              path: "notas-financieras",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 280,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-financieras", children: /* @__PURE__ */ jsxDEV(NotasFinancierasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 282,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 282,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/notas-financieras", children: /* @__PURE__ */ jsxDEV(NotasFinancierasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 283,
                  columnNumber: 97
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 283,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-financieras", children: /* @__PURE__ */ jsxDEV(NotasFinancierasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 284,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 284,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/notas-financieras", children: /* @__PURE__ */ jsxDEV(NotasFinancierasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 285,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 285,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "remitos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 290,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/remitos", children: /* @__PURE__ */ jsxDEV(RemitosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 292,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 292,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/remitos", children: /* @__PURE__ */ jsxDEV(RemitosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 293,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 293,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/remitos", children: /* @__PURE__ */ jsxDEV(RemitosDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 294,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 294,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/remitos", children: /* @__PURE__ */ jsxDEV(RemitosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 295,
                  columnNumber: 90
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 295,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "cobranzas",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 300,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cobranzas", children: /* @__PURE__ */ jsxDEV(CobranzasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 302,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 302,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/cobranzas", children: /* @__PURE__ */ jsxDEV(CobranzasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 303,
                  columnNumber: 89
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 303,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cobranzas", children: /* @__PURE__ */ jsxDEV(CobranzasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 304,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 304,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/cobranzas", children: /* @__PURE__ */ jsxDEV(CobranzasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 305,
                  columnNumber: 92
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 305,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "pedidos-de-venta",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 310,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/pedidos-de-venta", children: /* @__PURE__ */ jsxDEV(PedidosVentaListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 312,
                  columnNumber: 92
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 312,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/pedidos-de-venta", children: /* @__PURE__ */ jsxDEV(PedidosVentaFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 313,
                  columnNumber: 96
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 313,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/pedidos-de-venta", children: /* @__PURE__ */ jsxDEV(PedidosVentaDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 314,
                  columnNumber: 92
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 314,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/pedidos-de-venta", children: /* @__PURE__ */ jsxDEV(PedidosVentaFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 315,
                  columnNumber: 99
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 315,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "autorizacion-pedidos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 320,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/autorizacion-pedidos", children: /* @__PURE__ */ jsxDEV(AutorizacionPedidosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 322,
                  columnNumber: 96
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 322,
                  columnNumber: 31
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { requiredPermission: "sales_order_authorization.detail", children: /* @__PURE__ */ jsxDEV(AutorizacionPedidoDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 323,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 323,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "compras",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 327,
                columnNumber: 33
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/compras", children: /* @__PURE__ */ jsxDEV(ComprasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 329,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 329,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/compras", children: /* @__PURE__ */ jsxDEV(ComprasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 330,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 330,
                  columnNumber: 33
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/compras", children: /* @__PURE__ */ jsxDEV(ComprasFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 331,
                  columnNumber: 90
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 331,
                  columnNumber: 38
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/compras", children: /* @__PURE__ */ jsxDEV(ComprasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 332,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 332,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "ordenes-de-pago",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 337,
                columnNumber: 41
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/ordenes-de-pago", children: /* @__PURE__ */ jsxDEV(OrdenesPagoListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 339,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 339,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/ordenes-de-pago", children: /* @__PURE__ */ jsxDEV(OrdenesPagoFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 340,
                  columnNumber: 95
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 340,
                  columnNumber: 33
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/ordenes-de-pago", children: /* @__PURE__ */ jsxDEV(OrdenesPagoFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 341,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 341,
                  columnNumber: 38
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/ordenes-de-pago", children: /* @__PURE__ */ jsxDEV(OrdenesPagoDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 342,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 342,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "notas-credito-compra",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 349,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-credito-compra", children: /* @__PURE__ */ jsxDEV(NotasCreditoCompraListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 351,
                  columnNumber: 96
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 351,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/notas-credito-compra", children: /* @__PURE__ */ jsxDEV(NotasCreditoCompraFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 352,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 352,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-credito-compra", children: /* @__PURE__ */ jsxDEV(NotasCreditoCompraDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 353,
                  columnNumber: 96
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 353,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/notas-credito-compra", children: /* @__PURE__ */ jsxDEV(NotasCreditoCompraFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 354,
                  columnNumber: 103
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 354,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "notas-financieras-compra",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 359,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-financieras-compra", children: /* @__PURE__ */ jsxDEV(NotasFinancierasCompraListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 361,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 361,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/notas-financieras-compra", children: /* @__PURE__ */ jsxDEV(NotasFinancierasCompraFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 362,
                  columnNumber: 104
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 362,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/notas-financieras-compra", children: /* @__PURE__ */ jsxDEV(NotasFinancierasCompraDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 363,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 363,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/notas-financieras-compra", children: /* @__PURE__ */ jsxDEV(NotasFinancierasCompraFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 364,
                  columnNumber: 107
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 364,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "plan-de-cuentas",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 370,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/plan-de-cuentas", children: /* @__PURE__ */ jsxDEV(PlanDeCuentasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 372,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 372,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/plan-de-cuentas", children: /* @__PURE__ */ jsxDEV(PlanDeCuentasCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 373,
                  columnNumber: 95
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 373,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/plan-de-cuentas", children: /* @__PURE__ */ jsxDEV(PlanDeCuentasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 374,
                  columnNumber: 91
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 374,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/plan-de-cuentas", children: /* @__PURE__ */ jsxDEV(PlanDeCuentasEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 375,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 375,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "bancos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 380,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/bancos", children: /* @__PURE__ */ jsxDEV(BancosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 382,
                  columnNumber: 82
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 382,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/bancos", children: /* @__PURE__ */ jsxDEV(BancosCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 383,
                  columnNumber: 86
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 383,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/bancos", children: /* @__PURE__ */ jsxDEV(BancosDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 384,
                  columnNumber: 82
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 384,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/bancos", children: /* @__PURE__ */ jsxDEV(BancosEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 385,
                  columnNumber: 89
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 385,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "cajas",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 390,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cajas", children: /* @__PURE__ */ jsxDEV(CajasStatementPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 392,
                  columnNumber: 81
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 392,
                  columnNumber: 31
                }, this) },
                { path: "list", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/cajas", children: /* @__PURE__ */ jsxDEV(CajasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 393,
                  columnNumber: 84
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 393,
                  columnNumber: 32
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/cajas", children: /* @__PURE__ */ jsxDEV(CajasCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 394,
                  columnNumber: 85
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 394,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cajas", children: /* @__PURE__ */ jsxDEV(CajasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 395,
                  columnNumber: 81
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 395,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/cajas", children: /* @__PURE__ */ jsxDEV(CajasEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 396,
                  columnNumber: 88
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 396,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "movimientos-bancos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 401,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/movimientos-bancos", children: /* @__PURE__ */ jsxDEV(MovimientosBancosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 403,
                  columnNumber: 94
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 403,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/movimientos-bancos", children: /* @__PURE__ */ jsxDEV(MovimientosBancosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 404,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 404,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/movimientos-bancos", children: /* @__PURE__ */ jsxDEV(MovimientosBancosDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 405,
                  columnNumber: 94
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 405,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/movimientos-bancos", children: /* @__PURE__ */ jsxDEV(MovimientosBancosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 406,
                  columnNumber: 101
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 406,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "cheques",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 411,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cheques", children: /* @__PURE__ */ jsxDEV(ChequesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 413,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 413,
                  columnNumber: 31
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/cheques", children: /* @__PURE__ */ jsxDEV(ChequesDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 414,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 414,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "monedas",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 419,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/monedas", children: /* @__PURE__ */ jsxDEV(MonedasListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 421,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 421,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/monedas", children: /* @__PURE__ */ jsxDEV(MonedasCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 422,
                  columnNumber: 87
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 422,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/monedas", children: /* @__PURE__ */ jsxDEV(MonedasDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 423,
                  columnNumber: 83
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 423,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/monedas", children: /* @__PURE__ */ jsxDEV(MonedasEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 424,
                  columnNumber: 90
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 424,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "stock/movimientos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 429,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/stock/movimientos", children: /* @__PURE__ */ jsxDEV(MovStockListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 431,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 431,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/stock/movimientos", children: /* @__PURE__ */ jsxDEV(MovStockCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 432,
                  columnNumber: 97
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 432,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/stock/movimientos", children: /* @__PURE__ */ jsxDEV(MovStockDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 433,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 433,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/stock/movimientos", children: /* @__PURE__ */ jsxDEV(MovStockEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 434,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 434,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "stock/fraccionamientos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 440,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/stock/fraccionamientos", children: /* @__PURE__ */ jsxDEV(FractioningListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 442,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 442,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/stock/fraccionamientos", children: /* @__PURE__ */ jsxDEV(FractioningCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 443,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 443,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/stock/fraccionamientos", children: /* @__PURE__ */ jsxDEV(FractioningDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 444,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 444,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "configuracion/usuarios",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 449,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/usuarios", children: /* @__PURE__ */ jsxDEV(UsuariosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 451,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 451,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/configuracion/usuarios", children: /* @__PURE__ */ jsxDEV(UsuarioCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 452,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 452,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/usuarios", children: /* @__PURE__ */ jsxDEV(UsuarioDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 453,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 453,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/configuracion/usuarios", children: /* @__PURE__ */ jsxDEV(UsuarioEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 454,
                  columnNumber: 105
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 454,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "configuracion/profiles",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 459,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/profiles", children: /* @__PURE__ */ jsxDEV(ProfilesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 461,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 461,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/configuracion/profiles", children: /* @__PURE__ */ jsxDEV(ProfileCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 462,
                  columnNumber: 102
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 462,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/profiles", children: /* @__PURE__ */ jsxDEV(ProfileEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 463,
                  columnNumber: 98
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 463,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/configuracion/profiles", children: /* @__PURE__ */ jsxDEV(ProfileEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 464,
                  columnNumber: 105
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 464,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "configuracion/impuestos",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 470,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/impuestos", children: /* @__PURE__ */ jsxDEV(ImpuestosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 472,
                  columnNumber: 99
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 472,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/configuracion/impuestos", children: /* @__PURE__ */ jsxDEV(ImpuestosCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 473,
                  columnNumber: 103
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 473,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/impuestos", children: /* @__PURE__ */ jsxDEV(ImpuestosDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 474,
                  columnNumber: 99
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 474,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/configuracion/impuestos", children: /* @__PURE__ */ jsxDEV(ImpuestosEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 475,
                  columnNumber: 106
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 475,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "configuracion/comisiones-vendedores",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 480,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/comisiones-vendedores", children: /* @__PURE__ */ jsxDEV(ComisionesVendedoresListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 482,
                  columnNumber: 111
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 482,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/configuracion/comisiones-vendedores", children: /* @__PURE__ */ jsxDEV(ComisionesVendedoresCreatePage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 483,
                  columnNumber: 115
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 483,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/configuracion/comisiones-vendedores", children: /* @__PURE__ */ jsxDEV(ComisionesVendedoresDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 484,
                  columnNumber: 111
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 484,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/configuracion/comisiones-vendedores", children: /* @__PURE__ */ jsxDEV(ComisionesVendedoresEditPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 485,
                  columnNumber: 118
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 485,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "configuracion/sistema",
              element: /* @__PURE__ */ jsxDEV(PermissionRoute, { requiredPermission: "configuracion.edit", children: /* @__PURE__ */ jsxDEV(OrganizationDetailsPage, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 492,
                columnNumber: 33
              }, this) }, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 491,
                columnNumber: 7
              }, this)
            },
            {
              path: "configuracion/tablas-accesorias",
              element: /* @__PURE__ */ jsxDEV(PermissionRoute, { requiredPermission: "configuracion.edit", children: /* @__PURE__ */ jsxDEV(TablasAccesoriasPage, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 500,
                columnNumber: 33
              }, this) }, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 499,
                columnNumber: 7
              }, this)
            },
            {
              path: "listas-de-precios",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 507,
                columnNumber: 16
              }, this),
              children: [
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/listas-de-precios", children: /* @__PURE__ */ jsxDEV(ListasDePreciosListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 509,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 509,
                  columnNumber: 31
                }, this) },
                { path: "nuevo", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "create", baseRoute: "/listas-de-precios", children: /* @__PURE__ */ jsxDEV(ListasDePreciosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 510,
                  columnNumber: 97
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 510,
                  columnNumber: 33
                }, this) },
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/listas-de-precios", children: /* @__PURE__ */ jsxDEV(ListasDePreciosDetailPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 511,
                  columnNumber: 93
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 511,
                  columnNumber: 31
                }, this) },
                { path: ":id/editar", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "edit", baseRoute: "/listas-de-precios", children: /* @__PURE__ */ jsxDEV(ListasDePreciosFormPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 512,
                  columnNumber: 100
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 512,
                  columnNumber: 38
                }, this) }
              ]
            },
            {
              path: "reportes",
              element: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 517,
                columnNumber: 16
              }, this),
              children: [
                // 1. Lista de reportes disponibles (La entrada del módulo)
                { index: true, element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/reportes", children: /* @__PURE__ */ jsxDEV(ReportesListPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 520,
                  columnNumber: 84
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 520,
                  columnNumber: 31
                }, this) },
                // 2. El "Runner" dinámico (Ejecución de un reporte específico)
                // La URL será /reportes/1, /reportes/2, etc.
                { path: ":id", element: /* @__PURE__ */ jsxDEV(PermissionRoute, { action: "view", baseRoute: "/reportes", children: /* @__PURE__ */ jsxDEV(ReportesRunnerPage, {}, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 524,
                  columnNumber: 84
                }, this) }, void 0, false, {
                  fileName: "/app/src/routes/AppRouter.tsx",
                  lineNumber: 524,
                  columnNumber: 31
                }, this) }
              ]
            },
            {
              path: "",
              element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard" }, void 0, false, {
                fileName: "/app/src/routes/AppRouter.tsx",
                lineNumber: 530,
                columnNumber: 16
              }, this)
            }
          ]
        }
      ]
    }
  ]
);
export const AppRouter = () => {
  return /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
    fileName: "/app/src/routes/AppRouter.tsx",
    lineNumber: 540,
    columnNumber: 10
  }, this);
};
_c = AppRouter;
var _c;
$RefreshReg$(_c, "AppRouter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/routes/AppRouter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/routes/AppRouter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0lpQjs7Ozs7Ozs7Ozs7Ozs7OztBQXZJakIsU0FBU0Esd0JBQXdCO0FBQ2pDLFNBQVNDLHFCQUFxQkMsVUFBVUMsUUFBUUMsc0JBQXNCO0FBQ3RFLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLGlDQUFpQztBQUMxQyxTQUFTQyxtQ0FBbUM7QUFDNUMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxvQ0FBb0M7QUFDN0MsU0FBU0Msc0NBQXNDO0FBQy9DLFNBQVNDLHNDQUFzQztBQUMvQyxTQUFTQyxvQ0FBb0M7QUFDN0MsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MsbUNBQW1DO0FBQzVDLFNBQVNDLG9DQUFvQztBQUM3QyxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsaUNBQWlDO0FBQzFDLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQyxnQ0FBZ0M7QUFDekMsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLGtDQUFrQztBQUMzQyxTQUFTQyxrQ0FBa0M7QUFDM0MsU0FBU0Msa0NBQWtDO0FBQzNDLFNBQVNDLG9DQUFvQztBQUM3QyxTQUFTQyxzQ0FBc0M7QUFDL0MsU0FBU0Msc0NBQXNDO0FBQy9DLFNBQVNDLHdDQUF3QztBQUNqRCxTQUFTQyx5Q0FBeUM7QUFDbEQsU0FBU0MseUNBQXlDO0FBQ2xELFNBQVNDLDJDQUEyQztBQUNwRCxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQywwQkFBMEI7QUFZbkMsTUFBTUMsU0FBUzNIO0FBQUFBLEVBQW9CO0FBQUEsSUFDL0I7QUFBQSxNQUNJNEgsTUFBTTtBQUFBLE1BQ05DLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxJQUN2QjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxNQUFNO0FBQUEsTUFDTkMsU0FBUyx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CO0FBQUEsSUFDaEM7QUFBQSxJQUNBO0FBQUEsTUFDSUQsTUFBTTtBQUFBLE1BQ05DLFNBQVMsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDeEJDLFVBQVU7QUFBQSxRQUNOO0FBQUEsVUFDSUQsU0FBUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDcEJDLFVBQVU7QUFBQSxZQUNOO0FBQUEsY0FDSUYsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYztBQUFBLFlBQzNCO0FBQUE7QUFBQSxZQUVBO0FBQUEsY0FDSUQsTUFBTTtBQUFBO0FBQUEsY0FFTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsYUFBWSxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxFQUFtQjtBQUFBLGdCQUNwSCxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLGFBQVksaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEUsRUFBbUI7QUFBQSxnQkFDekgsRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxhQUFZLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBFLEVBQW1CO0FBQUEsZ0JBQ3JILEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsYUFBWSxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVuSTtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsY0FBYSxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRSxFQUFtQjtBQUFBLGdCQUN0SCxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLGNBQWEsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsS0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEUsRUFBbUI7QUFBQSxnQkFDM0gsRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxjQUFhLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRFLEVBQW1CO0FBQUEsZ0JBQ3ZILEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsY0FBYSxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQixLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVySTtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsK0JBQThCLGlDQUFDLHVDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRHLEVBQW1CO0FBQUEsZ0JBQ3ZKLEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsK0JBQThCLGlDQUFDLHVDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThHLEVBQW1CO0FBQUEsZ0JBQzNKLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsK0JBQThCLGlDQUFDLHlDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThHLEVBQW1CO0FBQUEsZ0JBQ3pKLEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsK0JBQThCLGlDQUFDLHVDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRHLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRXZLO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxVQUFTLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWMsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUUsRUFBbUI7QUFBQSxnQkFDOUcsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxVQUFTLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFLEVBQW1CO0FBQUEsZ0JBQ3BILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsVUFBUyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRSxFQUFtQjtBQUFBLGdCQUNoSCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFVBQVMsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYyxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUU5SDtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsZ0JBQWUsaUNBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0IsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0UsRUFBbUI7QUFBQSxnQkFDMUgsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxnQkFBZSxpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRixFQUFtQjtBQUFBLGdCQUM5SCxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGdCQUFlLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFLEVBQW1CO0FBQUEsZ0JBQzFILEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsZ0JBQWUsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkUsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFeEk7QUFBQSxZQUVBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGdCQUFlLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFLEVBQW1CO0FBQUEsZ0JBQzFILEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsZ0JBQWUsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUYsRUFBbUI7QUFBQSxnQkFDaEksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxnQkFBZSxpQ0FBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRixFQUFtQjtBQUFBLGdCQUM1SCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGdCQUFlLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRTFJO0FBQUE7QUFBQSxZQUdBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGVBQWMsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkUsRUFBbUI7QUFBQSxnQkFDeEgsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxlQUFjLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFCLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlGLEVBQW1CO0FBQUEsZ0JBQzlILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsZUFBYyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRSxFQUFtQjtBQUFBLGdCQUMxSCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGVBQWMsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkUsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFeEk7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGdCQUFlLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFLEVBQW1CO0FBQUEsZ0JBQzFILEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsZ0JBQWUsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUYsRUFBbUI7QUFBQSxnQkFDaEksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxnQkFBZSxpQ0FBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRixFQUFtQjtBQUFBLGdCQUM1SCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGdCQUFlLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRTFJO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUYsRUFBbUI7QUFBQSxnQkFDbEksRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxzQkFBcUIsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUYsRUFBbUI7QUFBQSxnQkFDdEksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsNkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUYsRUFBbUI7QUFBQSxnQkFDcEksRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUYsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFbEo7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGtCQUFpQixpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRixFQUFtQjtBQUFBO0FBQUEsZ0JBQzdILEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsa0JBQWlCLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFCLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9GLEVBQW1CO0FBQUE7QUFBQSxnQkFDakksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxrQkFBaUIsaUNBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUIsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0YsRUFBbUI7QUFBQTtBQUFBLGdCQUMvSCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGtCQUFpQixpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRixFQUFtQjtBQUFBO0FBQUEsY0FBRztBQUFBLFlBRS9JO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsOEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUIsS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEYsRUFBbUI7QUFBQSxnQkFDckksRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxzQkFBcUIsaUNBQUMsOEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUIsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEYsRUFBbUI7QUFBQSxnQkFDekksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsZ0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkIsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEYsRUFBbUI7QUFBQSxnQkFDdkksRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxzQkFBcUIsaUNBQUMsOEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUIsS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEYsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFcko7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFlBQVcsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0IsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUUsRUFBbUI7QUFBQSxnQkFDbEgsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxZQUFXLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFLEVBQW1CO0FBQUEsZ0JBQ3RILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxFQUFtQjtBQUFBLGdCQUNwSCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFlBQVcsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0IsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUUsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFbEk7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGNBQWEsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkUsRUFBbUI7QUFBQSxnQkFDdEgsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxjQUFhLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFLEVBQW1CO0FBQUEsZ0JBQzFILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsY0FBYSxpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RSxFQUFtQjtBQUFBLGdCQUN4SCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGNBQWEsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkUsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFdEk7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHFCQUFvQixpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGdCQUNoSSxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLHFCQUFvQixpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RixFQUFtQjtBQUFBLGdCQUNwSSxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHFCQUFvQixpQ0FBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RixFQUFtQjtBQUFBLGdCQUNsSSxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHFCQUFvQixpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVoSjtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUseUJBQXdCLGlDQUFDLGlDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdHLEVBQW1CO0FBQUEsZ0JBQzNJLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0Isb0JBQW1CLG9DQUFtQyxpQ0FBQyxrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QixLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RyxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUUzSjtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FBV0MsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNqQ0MsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RSxFQUFtQjtBQUFBLGdCQUNsSCxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLFlBQVcsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0IsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUUsRUFBbUI7QUFBQSxnQkFDdEgsRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxZQUFXLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFLEVBQW1CO0FBQUEsZ0JBQ3pILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUc3SDtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FBbUJDLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDekNDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRixFQUFtQjtBQUFBLGdCQUM5SCxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLG9CQUFtQixpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGdCQUNsSSxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQixLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRixFQUFtQjtBQUFBLGdCQUNySSxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUd6STtBQUFBLFlBRUE7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUseUJBQXdCLGlDQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStGLEVBQW1CO0FBQUEsZ0JBQzFJLEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUseUJBQXdCLGlDQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlHLEVBQW1CO0FBQUEsZ0JBQzlJLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUseUJBQXdCLGlDQUFDLGtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlHLEVBQW1CO0FBQUEsZ0JBQzVJLEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUseUJBQXdCLGlDQUFDLGdDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStGLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRTFKO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw2QkFBNEIsaUNBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0IsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUcsRUFBbUI7QUFBQSxnQkFDbEosRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSw2QkFBNEIsaUNBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0IsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUcsRUFBbUI7QUFBQSxnQkFDdEosRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw2QkFBNEIsaUNBQUMsc0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUMsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUcsRUFBbUI7QUFBQSxnQkFDcEosRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw2QkFBNEIsaUNBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0IsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUcsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFbEs7QUFBQSxZQUVBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGdCQUNoSSxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLG9CQUFtQixpQ0FBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QixLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RixFQUFtQjtBQUFBLGdCQUN0SSxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RixFQUFtQjtBQUFBLGdCQUNsSSxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLG9CQUFtQixpQ0FBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRixFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVoSjtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsV0FBVSxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFLEVBQW1CO0FBQUEsZ0JBQ2hILEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsV0FBVSxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxFQUFtQjtBQUFBLGdCQUN0SCxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFdBQVUsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUIsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUUsRUFBbUI7QUFBQSxnQkFDbEgsRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxXQUFVLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWUsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUUsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFaEk7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFVBQVMsaUNBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUIsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0UsRUFBbUI7QUFBQSxnQkFDbkgsRUFBRUQsTUFBTSxRQUFRQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxVQUFTLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWMsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUUsRUFBbUI7QUFBQSxnQkFDakgsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSxVQUFTLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFLEVBQW1CO0FBQUEsZ0JBQ3BILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsVUFBUyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRSxFQUFtQjtBQUFBLGdCQUNoSCxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLFVBQVMsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYyxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUU5SDtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsdUJBQXNCLGlDQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRGLEVBQW1CO0FBQUEsZ0JBQ3ZJLEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsdUJBQXNCLGlDQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThGLEVBQW1CO0FBQUEsZ0JBQzNJLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsdUJBQXNCLGlDQUFDLGlDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThGLEVBQW1CO0FBQUEsZ0JBQ3pJLEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsdUJBQXNCLGlDQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRGLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRXZKO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxZQUFXLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFLEVBQW1CO0FBQUEsZ0JBQ2xILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUU3SDtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RSxFQUFtQjtBQUFBLGdCQUNsSCxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLFlBQVcsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkUsRUFBbUI7QUFBQSxnQkFDeEgsRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSxZQUFXLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFLEVBQW1CO0FBQUEsZ0JBQ3BILEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsWUFBVyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVsSTtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGLEVBQW1CO0FBQUEsZ0JBQzdILEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsc0JBQXFCLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGLEVBQW1CO0FBQUEsZ0JBQ25JLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9GLEVBQW1CO0FBQUEsZ0JBQy9ILEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRTdJO0FBQUEsWUFFQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSwyQkFBMEIsaUNBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0IsS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEYsRUFBbUI7QUFBQSxnQkFDckksRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSwyQkFBMEIsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEYsRUFBbUI7QUFBQSxnQkFDM0ksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSwyQkFBMEIsaUNBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEYsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFaEo7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLDJCQUEwQixpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RixFQUFtQjtBQUFBLGdCQUNsSSxFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLDJCQUEwQixpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRixFQUFtQjtBQUFBLGdCQUN2SSxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLDJCQUEwQixpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RixFQUFtQjtBQUFBLGdCQUNuSSxFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLDJCQUEwQixpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQixLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRixFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUVqSjtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsMkJBQTBCLGlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVGLEVBQW1CO0FBQUEsZ0JBQ2xJLEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsMkJBQTBCLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGLEVBQW1CO0FBQUEsZ0JBQ3ZJLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsMkJBQTBCLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGLEVBQW1CO0FBQUEsZ0JBQ2pJLEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsMkJBQTBCLGlDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRWpKO0FBQUEsWUFFQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUEsZ0JBQ04sRUFBRUMsT0FBTyxNQUFNRixTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw0QkFBMkIsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUYsRUFBbUI7QUFBQSxnQkFDcEksRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFVBQVMsV0FBVSw0QkFBMkIsaUNBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkYsRUFBbUI7QUFBQSxnQkFDMUksRUFBRUQsTUFBTSxPQUFPQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw0QkFBMkIsaUNBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0IsS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkYsRUFBbUI7QUFBQSxnQkFDdEksRUFBRUQsTUFBTSxjQUFjQyxTQUFTLHVCQUFDLG1CQUFnQixRQUFPLFFBQU8sV0FBVSw0QkFBMkIsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUYsRUFBbUI7QUFBQSxjQUFDO0FBQUEsWUFFcEo7QUFBQSxZQUNBO0FBQUEsY0FDSUQsTUFBTTtBQUFBLGNBQ05DLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDaEJDLFVBQVU7QUFBQSxnQkFDTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHdDQUF1QyxpQ0FBQyxrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QixLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSCxFQUFtQjtBQUFBLGdCQUMzSixFQUFFRCxNQUFNLFNBQVNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sVUFBUyxXQUFVLHdDQUF1QyxpQ0FBQyxvQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQixLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvSCxFQUFtQjtBQUFBLGdCQUNqSyxFQUFFRCxNQUFNLE9BQU9DLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHdDQUF1QyxpQ0FBQyxvQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQixLQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrSCxFQUFtQjtBQUFBLGdCQUM3SixFQUFFRCxNQUFNLGNBQWNDLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLHdDQUF1QyxpQ0FBQyxrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QixLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSCxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUUzSztBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FDSSx1QkFBQyxtQkFBZ0Isb0JBQW1CLHNCQUNoQyxpQ0FBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QixLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFFUjtBQUFBLFlBQ0E7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FDSSx1QkFBQyxtQkFBZ0Isb0JBQW1CLHNCQUNoQyxpQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFFUjtBQUFBLFlBRUE7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUNoQkMsVUFBVTtBQUFBLGdCQUNOLEVBQUVDLE9BQU8sTUFBTUYsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlGLEVBQW1CO0FBQUEsZ0JBQ3BJLEVBQUVELE1BQU0sU0FBU0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxVQUFTLFdBQVUsc0JBQXFCLGlDQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGLEVBQW1CO0FBQUEsZ0JBQ3hJLEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGLEVBQW1CO0FBQUEsZ0JBQ3RJLEVBQUVELE1BQU0sY0FBY0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsc0JBQXFCLGlDQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlGLEVBQW1CO0FBQUEsY0FBQztBQUFBLFlBRXBKO0FBQUEsWUFDQTtBQUFBLGNBQ0lELE1BQU07QUFBQSxjQUNOQyxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBTztBQUFBLGNBQ2hCQyxVQUFVO0FBQUE7QUFBQSxnQkFFTixFQUFFQyxPQUFPLE1BQU1GLFNBQVMsdUJBQUMsbUJBQWdCLFFBQU8sUUFBTyxXQUFVLGFBQVksaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUIsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUUsRUFBbUI7QUFBQTtBQUFBO0FBQUEsZ0JBSXBILEVBQUVELE1BQU0sT0FBT0MsU0FBUyx1QkFBQyxtQkFBZ0IsUUFBTyxRQUFPLFdBQVUsYUFBWSxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQixLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRSxFQUFtQjtBQUFBLGNBQUM7QUFBQSxZQUUvSDtBQUFBLFlBRUE7QUFBQSxjQUNJRCxNQUFNO0FBQUEsY0FDTkMsU0FBUyx1QkFBQyxZQUFTLElBQUcsZ0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQSxZQUN0QztBQUFBLFVBQUM7QUFBQSxRQUVUO0FBQUEsTUFBQztBQUFBLElBRVQ7QUFBQSxFQUFDO0FBQ0o7QUFHTSxhQUFNRyxZQUFZQSxNQUFNO0FBQzNCLFNBQU8sdUJBQUMsa0JBQWUsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErQjtBQUMxQztBQUFFQyxLQUZXRDtBQUFTLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDbGllbnRlc0xpc3RQYWdlIiwiY3JlYXRlQnJvd3NlclJvdXRlciIsIk5hdmlnYXRlIiwiT3V0bGV0IiwiUm91dGVyUHJvdmlkZXIiLCJQcm90ZWN0ZWRSb3V0ZSIsIlBlcm1pc3Npb25Sb3V0ZSIsIk1haW5MYXlvdXQiLCJEYXNoYm9hcmRQYWdlIiwiQ2xpZW50ZURldGFpbFBhZ2UiLCJDbGllbnRlRWRpdFBhZ2UiLCJBcnRpY3Vsb3NMaXN0UGFnZSIsIkFydGljdWxvRGV0YWlsUGFnZSIsIkFydGljdWxvRWRpdFBhZ2UiLCJQcm92ZWVkb3Jlc0xpc3RQYWdlIiwiUHJvdmVlZG9yRGV0YWlsUGFnZSIsIlByb3ZlZWRvckVkaXRQYWdlIiwiTG9naW5QYWdlIiwiQ2xpZW50ZUNyZWF0ZVBhZ2UiLCJBcnRpY3Vsb0NyZWF0ZVBhZ2UiLCJQcm92ZWVkb3JDcmVhdGVQYWdlIiwiVXN1YXJpb3NMaXN0UGFnZSIsIlVzdWFyaW9EZXRhaWxQYWdlIiwiVXN1YXJpb0VkaXRQYWdlIiwiVXN1YXJpb0NyZWF0ZVBhZ2UiLCJGb3Jnb3RQYXNzd29yZFBhZ2UiLCJQcm9maWxlc0xpc3RQYWdlIiwiUHJvZmlsZUVkaXRQYWdlIiwiUHJvZmlsZUNyZWF0ZVBhZ2UiLCJQbGFuRGVDdWVudGFzTGlzdFBhZ2UiLCJQbGFuRGVDdWVudGFzQ3JlYXRlUGFnZSIsIlBsYW5EZUN1ZW50YXNEZXRhaWxQYWdlIiwiUGxhbkRlQ3VlbnRhc0VkaXRQYWdlIiwiQ2hlcXVlc0xpc3RQYWdlIiwiQ2hlcXVlc0RldGFpbFBhZ2UiLCJCYW5jb3NMaXN0UGFnZSIsIkJhbmNvc0NyZWF0ZVBhZ2UiLCJCYW5jb3NEZXRhaWxQYWdlIiwiQmFuY29zRWRpdFBhZ2UiLCJDYWphc0xpc3RQYWdlIiwiQ2FqYXNDcmVhdGVQYWdlIiwiQ2FqYXNEZXRhaWxQYWdlIiwiQ2FqYXNFZGl0UGFnZSIsIk1vdmltaWVudG9zQmFuY29zTGlzdFBhZ2UiLCJNb3ZpbWllbnRvc0JhbmNvc0Zvcm1QYWdlIiwiTW92aW1pZW50b3NCYW5jb3NEZXRhaWxQYWdlIiwiTW92U3RvY2tMaXN0UGFnZSIsIk1vdlN0b2NrQ3JlYXRlUGFnZSIsIk1vdlN0b2NrRGV0YWlsUGFnZSIsIk1vdlN0b2NrRWRpdFBhZ2UiLCJGcmFjdGlvbmluZ0NyZWF0ZVBhZ2UiLCJGcmFjdGlvbmluZ0xpc3RQYWdlIiwiRnJhY3Rpb25pbmdEZXRhaWxQYWdlIiwiQ29tcHJhc0xpc3RQYWdlIiwiQ29tcHJhc0Zvcm1QYWdlIiwiQ29tcHJhc0RldGFpbFBhZ2UiLCJPcmRlbmVzUGFnb0xpc3RQYWdlIiwiT3JkZW5lc1BhZ29EZXRhaWxQYWdlIiwiT3JkZW5lc1BhZ29Gb3JtUGFnZSIsIkltcHVlc3Rvc0xpc3RQYWdlIiwiSW1wdWVzdG9zQ3JlYXRlUGFnZSIsIkltcHVlc3Rvc0RldGFpbFBhZ2UiLCJJbXB1ZXN0b3NFZGl0UGFnZSIsIkNvbWlzaW9uZXNWZW5kZWRvcmVzTGlzdFBhZ2UiLCJDb21pc2lvbmVzVmVuZGVkb3Jlc0NyZWF0ZVBhZ2UiLCJDb21pc2lvbmVzVmVuZGVkb3Jlc0RldGFpbFBhZ2UiLCJDb21pc2lvbmVzVmVuZGVkb3Jlc0VkaXRQYWdlIiwiT3JnYW5pemF0aW9uRGV0YWlsc1BhZ2UiLCJUYWJsYXNBY2Nlc29yaWFzUGFnZSIsIlRyYW5zcG9ydGVzTGlzdFBhZ2UiLCJUcmFuc3BvcnRlc0NyZWF0ZVBhZ2UiLCJUcmFuc3BvcnRlc0RldGFpbFBhZ2UiLCJUcmFuc3BvcnRlc0VkaXRQYWdlIiwiTW9uZWRhc0xpc3RQYWdlIiwiTW9uZWRhc0NyZWF0ZVBhZ2UiLCJNb25lZGFzRGV0YWlsUGFnZSIsIk1vbmVkYXNFZGl0UGFnZSIsIlZlbmRlZG9yZXNMaXN0UGFnZSIsIlZlbmRlZG9yZXNDcmVhdGVQYWdlIiwiVmVuZGVkb3Jlc0RldGFpbFBhZ2UiLCJWZW5kZWRvcmVzRWRpdFBhZ2UiLCJDb21wcmFkb3Jlc0xpc3RQYWdlIiwiQ29tcHJhZG9yZXNDcmVhdGVQYWdlIiwiQ29tcHJhZG9yZXNEZXRhaWxQYWdlIiwiQ29tcHJhZG9yZXNFZGl0UGFnZSIsIlBlZGlkb3NWZW50YUxpc3RQYWdlIiwiUGVkaWRvc1ZlbnRhRm9ybVBhZ2UiLCJQZWRpZG9zVmVudGFEZXRhaWxQYWdlIiwiQXV0b3JpemFjaW9uUGVkaWRvc0xpc3RQYWdlIiwiQXV0b3JpemFjaW9uUGVkaWRvRGV0YWlsUGFnZSIsIkZhY3R1cmFzVmVudGFMaXN0UGFnZSIsIkZhY3R1cmFzVmVudGFGb3JtUGFnZSIsIkZhY3R1cmFzVmVudGFEZXRhaWxQYWdlIiwiQ29icmFuemFzTGlzdFBhZ2UiLCJDb2JyYW56YXNGb3JtUGFnZSIsIkNvYnJhbnphc0RldGFpbFBhZ2UiLCJMaXN0YXNEZVByZWNpb3NMaXN0UGFnZSIsIkxpc3Rhc0RlUHJlY2lvc0RldGFpbFBhZ2UiLCJMaXN0YXNEZVByZWNpb3NGb3JtUGFnZSIsIlJlbWl0b3NMaXN0UGFnZSIsIlJlbWl0b3NGb3JtUGFnZSIsIlJlbWl0b3NEZXRhaWxQYWdlIiwiTm90YXNDcmVkaXRvTGlzdFBhZ2UiLCJOb3Rhc0NyZWRpdG9Gb3JtUGFnZSIsIk5vdGFzQ3JlZGl0b0RldGFpbFBhZ2UiLCJOb3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UiLCJOb3Rhc0ZpbmFuY2llcmFzRm9ybVBhZ2UiLCJOb3Rhc0ZpbmFuY2llcmFzRGV0YWlsUGFnZSIsIk5vdGFzQ3JlZGl0b0NvbXByYUxpc3RQYWdlIiwiTm90YXNDcmVkaXRvQ29tcHJhRm9ybVBhZ2UiLCJOb3Rhc0NyZWRpdG9Db21wcmFEZXRhaWxQYWdlIiwiTm90YXNGaW5hbmNpZXJhc0NvbXByYUxpc3RQYWdlIiwiTm90YXNGaW5hbmNpZXJhc0NvbXByYUZvcm1QYWdlIiwiTm90YXNGaW5hbmNpZXJhc0NvbXByYURldGFpbFBhZ2UiLCJNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzTGlzdFBhZ2UiLCJNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzRm9ybVBhZ2UiLCJNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzRGV0YWlsUGFnZSIsIlJlcG9ydGVzTGlzdFBhZ2UiLCJSZXBvcnRlc1J1bm5lclBhZ2UiLCJMZWFkc0xpc3RQYWdlIiwiTGVhZHNEZXRhaWxQYWdlIiwiTGVhZHNDcmVhdGVQYWdlIiwiTGVhZHNFZGl0UGFnZSIsIkNhamFzU3RhdGVtZW50UGFnZSIsInJvdXRlciIsInBhdGgiLCJlbGVtZW50IiwiY2hpbGRyZW4iLCJpbmRleCIsIkFwcFJvdXRlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcFJvdXRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL3JvdXRlcy9BcHBSb3V0ZXIudHN4XG5pbXBvcnQgeyBDbGllbnRlc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY2xpZW50ZXMvcGFnZXMvQ2xpZW50ZXNMaXN0UGFnZSc7IC8vIMKhSW1wb3J0YW1vcyBudWVzdHJhIG51ZXZhIHDDoWdpbmEhXG5pbXBvcnQgeyBjcmVhdGVCcm93c2VyUm91dGVyLCBOYXZpZ2F0ZSwgT3V0bGV0LCBSb3V0ZXJQcm92aWRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgUHJvdGVjdGVkUm91dGUgfSBmcm9tICcuL1Byb3RlY3RlZFJvdXRlJztcbmltcG9ydCB7IFBlcm1pc3Npb25Sb3V0ZSB9IGZyb20gJy4vUGVybWlzc2lvblJvdXRlJztcbmltcG9ydCB7IE1haW5MYXlvdXQgfSBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dHMvTWFpbkxheW91dCc7XG5pbXBvcnQgeyBEYXNoYm9hcmRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvZGFzaGJvYXJkcy9wYWdlcy9EYXNoYm9hcmRQYWdlJztcbmltcG9ydCB7IENsaWVudGVEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY2xpZW50ZXMvcGFnZXMvQ2xpZW50ZXNEZXRhaWxQYWdlJztcbmltcG9ydCB7IENsaWVudGVFZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NsaWVudGVzL3BhZ2VzL0NsaWVudGVzRWRpdFBhZ2UnO1xuaW1wb3J0IHsgQXJ0aWN1bG9zTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hcnRpY3Vsb3MvcGFnZXMvQXJ0aWN1bG9zTGlzdFBhZ2UnO1xuaW1wb3J0IHsgQXJ0aWN1bG9EZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXJ0aWN1bG9zL3BhZ2VzL0FydGljdWxvc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgQXJ0aWN1bG9FZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2FydGljdWxvcy9wYWdlcy9BcnRpY3Vsb3NFZGl0UGFnZSc7XG5pbXBvcnQgeyBQcm92ZWVkb3Jlc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNMaXN0UGFnZSc7XG5pbXBvcnQgeyBQcm92ZWVkb3JEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNEZXRhaWxQYWdlJztcbmltcG9ydCB7IFByb3ZlZWRvckVkaXRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNFZGl0UGFnZSc7XG5pbXBvcnQgeyBMb2dpblBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hdXRoL3BhZ2VzL0xvZ2luUGFnZSc7XG5pbXBvcnQgeyBDbGllbnRlQ3JlYXRlUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NsaWVudGVzL3BhZ2VzL0NsaWVudGVzQ3JlYXRlUGFnZSc7XG5pbXBvcnQgeyBBcnRpY3Vsb0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hcnRpY3Vsb3MvcGFnZXMvQXJ0aWN1bG9zQ3JlYXRlUGFnZSc7XG5pbXBvcnQgeyBQcm92ZWVkb3JDcmVhdGVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNDcmVhdGVQYWdlJztcbmltcG9ydCB7IFVzdWFyaW9zTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3Vhcmlvc0xpc3RQYWdlJztcbmltcG9ydCB7IFVzdWFyaW9EZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvdXN1YXJpb3MvcGFnZXMvVXN1YXJpb3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IFVzdWFyaW9FZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3VzdWFyaW9zL3BhZ2VzL1VzdWFyaW9zRWRpdFBhZ2UnO1xuaW1wb3J0IHsgVXN1YXJpb0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3Vhcmlvc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgRm9yZ290UGFzc3dvcmRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXV0aC9wYWdlcy9Gb3Jnb3RQYXNzd29yZFBhZ2UnO1xuaW1wb3J0IHsgUHJvZmlsZXNMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3Byb2ZpbGVzL3BhZ2VzL1Byb2ZpbGVzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgUHJvZmlsZUVkaXRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvZmlsZXMvcGFnZXMvUHJvZmlsZUVkaXRQYWdlJztcbmltcG9ydCB7IFByb2ZpbGVDcmVhdGVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcHJvZmlsZXMvcGFnZXMvUHJvZmlsZUNyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgUGxhbkRlQ3VlbnRhc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcGxhbl9kZV9jdWVudGFzL3BhZ2VzL1BsYW5EZUN1ZW50YXNMaXN0UGFnZSc7XG5pbXBvcnQgeyBQbGFuRGVDdWVudGFzQ3JlYXRlUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3BsYW5fZGVfY3VlbnRhcy9wYWdlcy9QbGFuRGVDdWVudGFzQ3JlYXRlUGFnZSc7XG5pbXBvcnQgeyBQbGFuRGVDdWVudGFzRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3BsYW5fZGVfY3VlbnRhcy9wYWdlcy9QbGFuRGVDdWVudGFzRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBQbGFuRGVDdWVudGFzRWRpdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9wbGFuX2RlX2N1ZW50YXMvcGFnZXMvUGxhbkRlQ3VlbnRhc0VkaXRQYWdlJztcbmltcG9ydCB7IENoZXF1ZXNMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NoZXF1ZXMvcGFnZXMvQ2hlcXVlc0xpc3RQYWdlJztcbmltcG9ydCB7IENoZXF1ZXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY2hlcXVlcy9wYWdlcy9DaGVxdWVzRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBCYW5jb3NMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2JhbmNvcy9wYWdlcy9CYW5jb3NMaXN0UGFnZSc7XG5pbXBvcnQgeyBCYW5jb3NDcmVhdGVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvYmFuY29zL3BhZ2VzL0JhbmNvc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgQmFuY29zRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2JhbmNvcy9wYWdlcy9CYW5jb3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IEJhbmNvc0VkaXRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvYmFuY29zL3BhZ2VzL0JhbmNvc0VkaXRQYWdlJztcbmltcG9ydCB7IENhamFzTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jYWphcy9wYWdlcy9DYWphc0xpc3RQYWdlJztcbmltcG9ydCB7IENhamFzQ3JlYXRlUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzQ3JlYXRlUGFnZSc7XG5pbXBvcnQgeyBDYWphc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jYWphcy9wYWdlcy9DYWphc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgQ2FqYXNFZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzRWRpdFBhZ2UnO1xuaW1wb3J0IHsgTW92aW1pZW50b3NCYW5jb3NMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL21vdmltaWVudG9zX2JhbmNvcy9wYWdlcy9Nb3ZpbWllbnRvc0JhbmNvc0xpc3RQYWdlJztcbmltcG9ydCB7IE1vdmltaWVudG9zQmFuY29zRm9ybVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9tb3ZpbWllbnRvc19iYW5jb3MvcGFnZXMvTW92aW1pZW50b3NCYW5jb3NGb3JtUGFnZSc7XG5pbXBvcnQgeyBNb3ZpbWllbnRvc0JhbmNvc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9tb3ZpbWllbnRvc19iYW5jb3MvcGFnZXMvTW92aW1pZW50b3NCYW5jb3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IE1vdlN0b2NrTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9tb3Zfc3RvY2svcGFnZXMvTW92U3RvY2tMaXN0UGFnZSc7XG5pbXBvcnQgeyBNb3ZTdG9ja0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9tb3Zfc3RvY2svcGFnZXMvTW92U3RvY2tDcmVhdGVQYWdlJztcbmltcG9ydCB7IE1vdlN0b2NrRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL21vdl9zdG9jay9wYWdlcy9Nb3ZTdG9ja0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgTW92U3RvY2tFZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL21vdl9zdG9jay9wYWdlcy9Nb3ZTdG9ja0VkaXRQYWdlJztcbmltcG9ydCB7IEZyYWN0aW9uaW5nQ3JlYXRlUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ZyYWN0aW9uaW5ncy9wYWdlcy9GcmFjdGlvbmluZ0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgRnJhY3Rpb25pbmdMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ZyYWN0aW9uaW5ncy9wYWdlcy9GcmFjdGlvbmluZ0xpc3RQYWdlJztcbmltcG9ydCB7IEZyYWN0aW9uaW5nRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ZyYWN0aW9uaW5ncy9wYWdlcy9GcmFjdGlvbmluZ0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgQ29tcHJhc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29tcHJhcy9wYWdlcy9Db21wcmFzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgQ29tcHJhc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29tcHJhcy9wYWdlcy9Db21wcmFzRm9ybVBhZ2UnO1xuaW1wb3J0IHsgQ29tcHJhc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb21wcmFzL3BhZ2VzL0NvbXByYXNEZXRhaWxQYWdlJztcbmltcG9ydCB7IE9yZGVuZXNQYWdvTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9vcmRlbmVzX3BhZ28vcGFnZXMvT3JkZW5lc1BhZ29MaXN0UGFnZSc7XG5pbXBvcnQgeyBPcmRlbmVzUGFnb0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9vcmRlbmVzX3BhZ28vcGFnZXMvT3JkZW5lc1BhZ29EZXRhaWxQYWdlJztcbmltcG9ydCB7IE9yZGVuZXNQYWdvRm9ybVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9vcmRlbmVzX3BhZ28vcGFnZXMvT3JkZW5lc1BhZ29Gb3JtUGFnZSc7XG5pbXBvcnQgeyBJbXB1ZXN0b3NMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ltcHVlc3Rvcy9wYWdlcy9JbXB1ZXN0b3NMaXN0UGFnZSc7XG5pbXBvcnQgeyBJbXB1ZXN0b3NDcmVhdGVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvaW1wdWVzdG9zL3BhZ2VzL0ltcHVlc3Rvc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgSW1wdWVzdG9zRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ltcHVlc3Rvcy9wYWdlcy9JbXB1ZXN0b3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IEltcHVlc3Rvc0VkaXRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvaW1wdWVzdG9zL3BhZ2VzL0ltcHVlc3Rvc0VkaXRQYWdlJztcbmltcG9ydCB7IENvbWlzaW9uZXNWZW5kZWRvcmVzTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb21pc2lvbmVzX3ZlbmRlZG9yZXMvcGFnZXMvQ29taXNpb25lc1ZlbmRlZG9yZXNMaXN0UGFnZSc7XG5pbXBvcnQgeyBDb21pc2lvbmVzVmVuZGVkb3Jlc0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb21pc2lvbmVzX3ZlbmRlZG9yZXMvcGFnZXMvQ29taXNpb25lc1ZlbmRlZG9yZXNDcmVhdGVQYWdlJztcbmltcG9ydCB7IENvbWlzaW9uZXNWZW5kZWRvcmVzRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvbWlzaW9uZXNfdmVuZGVkb3Jlcy9wYWdlcy9Db21pc2lvbmVzVmVuZGVkb3Jlc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgQ29taXNpb25lc1ZlbmRlZG9yZXNFZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvbWlzaW9uZXNfdmVuZGVkb3Jlcy9wYWdlcy9Db21pc2lvbmVzVmVuZGVkb3Jlc0VkaXRQYWdlJztcbmltcG9ydCB7IE9yZ2FuaXphdGlvbkRldGFpbHNQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvb3JnYW5pemF0aW9uX2RldGFpbHMvcGFnZXMvT3JnYW5pemF0aW9uRGV0YWlsc1BhZ2UnO1xuaW1wb3J0IHsgVGFibGFzQWNjZXNvcmlhc1BhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy90YWJsYXNfYWNjZXNvcmlhcy9wYWdlcy9UYWJsYXNBY2Nlc29yaWFzUGFnZSc7XG5pbXBvcnQgeyBUcmFuc3BvcnRlc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvdHJhbnNwb3J0ZXMvcGFnZXMvVHJhbnNwb3J0ZXNMaXN0UGFnZSc7XG5pbXBvcnQgeyBUcmFuc3BvcnRlc0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy90cmFuc3BvcnRlcy9wYWdlcy9UcmFuc3BvcnRlc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgVHJhbnNwb3J0ZXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvdHJhbnNwb3J0ZXMvcGFnZXMvVHJhbnNwb3J0ZXNEZXRhaWxQYWdlJztcbmltcG9ydCB7IFRyYW5zcG9ydGVzRWRpdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy90cmFuc3BvcnRlcy9wYWdlcy9UcmFuc3BvcnRlc0VkaXRQYWdlJztcbmltcG9ydCB7IE1vbmVkYXNMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL21vbmVkYXMvcGFnZXMvTW9uZWRhc0xpc3RQYWdlJztcbmltcG9ydCB7IE1vbmVkYXNDcmVhdGVQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbW9uZWRhcy9wYWdlcy9Nb25lZGFzQ3JlYXRlUGFnZSc7XG5pbXBvcnQgeyBNb25lZGFzRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL21vbmVkYXMvcGFnZXMvTW9uZWRhc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgTW9uZWRhc0VkaXRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbW9uZWRhcy9wYWdlcy9Nb25lZGFzRWRpdFBhZ2UnO1xuaW1wb3J0IHsgVmVuZGVkb3Jlc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvdmVuZGVkb3Jlcy9wYWdlcy9WZW5kZWRvcmVzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgVmVuZGVkb3Jlc0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy92ZW5kZWRvcmVzL3BhZ2VzL1ZlbmRlZG9yZXNDcmVhdGVQYWdlJztcbmltcG9ydCB7IFZlbmRlZG9yZXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvdmVuZGVkb3Jlcy9wYWdlcy9WZW5kZWRvcmVzRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBWZW5kZWRvcmVzRWRpdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy92ZW5kZWRvcmVzL3BhZ2VzL1ZlbmRlZG9yZXNFZGl0UGFnZSc7XG5pbXBvcnQgeyBDb21wcmFkb3Jlc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29tcHJhZG9yZXMvcGFnZXMvQ29tcHJhZG9yZXNMaXN0UGFnZSc7XG5pbXBvcnQgeyBDb21wcmFkb3Jlc0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb21wcmFkb3Jlcy9wYWdlcy9Db21wcmFkb3Jlc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgQ29tcHJhZG9yZXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29tcHJhZG9yZXMvcGFnZXMvQ29tcHJhZG9yZXNEZXRhaWxQYWdlJztcbmltcG9ydCB7IENvbXByYWRvcmVzRWRpdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb21wcmFkb3Jlcy9wYWdlcy9Db21wcmFkb3Jlc0VkaXRQYWdlJztcbmltcG9ydCB7IFBlZGlkb3NWZW50YUxpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcGVkaWRvc192ZW50YS9wYWdlcy9QZWRpZG9zVmVudGFMaXN0UGFnZSc7XG5pbXBvcnQgeyBQZWRpZG9zVmVudGFGb3JtUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3BlZGlkb3NfdmVudGEvcGFnZXMvUGVkaWRvc1ZlbnRhRm9ybVBhZ2UnO1xuaW1wb3J0IHsgUGVkaWRvc1ZlbnRhRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3BlZGlkb3NfdmVudGEvcGFnZXMvUGVkaWRvc1ZlbnRhRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBBdXRvcml6YWNpb25QZWRpZG9zTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9hdXRvcml6YWNpb25fcGVkaWRvcy9wYWdlcy9BdXRvcml6YWNpb25QZWRpZG9zTGlzdFBhZ2UnO1xuaW1wb3J0IHsgQXV0b3JpemFjaW9uUGVkaWRvRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dG9yaXphY2lvbl9wZWRpZG9zL3BhZ2VzL0F1dG9yaXphY2lvblBlZGlkb0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgRmFjdHVyYXNWZW50YUxpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvZmFjdHVyYXNfdmVudGEvcGFnZXMvRmFjdHVyYXNWZW50YUxpc3RQYWdlJztcbmltcG9ydCB7IEZhY3R1cmFzVmVudGFGb3JtUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ZhY3R1cmFzX3ZlbnRhL3BhZ2VzL0ZhY3R1cmFzVmVudGFGb3JtUGFnZSc7XG5pbXBvcnQgeyBGYWN0dXJhc1ZlbnRhRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2ZhY3R1cmFzX3ZlbnRhL3BhZ2VzL0ZhY3R1cmFzVmVudGFEZXRhaWxQYWdlJztcbmltcG9ydCB7IENvYnJhbnphc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29icmFuemFzL3BhZ2VzL0NvYnJhbnphc0xpc3RQYWdlJztcbmltcG9ydCB7IENvYnJhbnphc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY29icmFuemFzL3BhZ2VzL0NvYnJhbnphc0Zvcm1QYWdlJztcbmltcG9ydCB7IENvYnJhbnphc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9jb2JyYW56YXMvcGFnZXMvQ29icmFuemFzRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBMaXN0YXNEZVByZWNpb3NMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2xpc3RhX3ByZWNpb3MvcGFnZXMvTGlzdGFzUHJlY2lvc0xpc3RQYWdlJztcbmltcG9ydCB7IExpc3Rhc0RlUHJlY2lvc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9saXN0YV9wcmVjaW9zL3BhZ2VzL0xpc3Rhc1ByZWNpb3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IExpc3Rhc0RlUHJlY2lvc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbGlzdGFfcHJlY2lvcy9wYWdlcy9MaXN0YXNQcmVjaW9zRm9ybVBhZ2UnO1xuaW1wb3J0IHsgUmVtaXRvc0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcmVtaXRvcy9wYWdlcy9SZW1pdG9zTGlzdFBhZ2UnO1xuaW1wb3J0IHsgUmVtaXRvc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcmVtaXRvcy9wYWdlcy9SZW1pdG9zRm9ybVBhZ2UnO1xuaW1wb3J0IHsgUmVtaXRvc0RldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9yZW1pdG9zL3BhZ2VzL1JlbWl0b3NEZXRhaWxQYWdlJztcbmltcG9ydCB7IE5vdGFzQ3JlZGl0b0xpc3RQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbm90YXNfY3JlZGl0by9wYWdlcy9Ob3Rhc0NyZWRpdG9MaXN0UGFnZSc7XG5pbXBvcnQgeyBOb3Rhc0NyZWRpdG9Gb3JtUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG8vcGFnZXMvTm90YXNDcmVkaXRvRm9ybVBhZ2UnO1xuaW1wb3J0IHsgTm90YXNDcmVkaXRvRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG8vcGFnZXMvTm90YXNDcmVkaXRvRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBOb3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9ub3Rhc19maW5hbmNpZXJhcy9wYWdlcy9Ob3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgTm90YXNGaW5hbmNpZXJhc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXMvcGFnZXMvTm90YXNGaW5hbmNpZXJhc0Zvcm1QYWdlJztcbmltcG9ydCB7IE5vdGFzRmluYW5jaWVyYXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXMvcGFnZXMvTm90YXNGaW5hbmNpZXJhc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgTm90YXNDcmVkaXRvQ29tcHJhTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9ub3Rhc19jcmVkaXRvX2NvbXByYS9wYWdlcy9Ob3Rhc0NyZWRpdG9Db21wcmFMaXN0UGFnZSc7XG5pbXBvcnQgeyBOb3Rhc0NyZWRpdG9Db21wcmFGb3JtUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG9fY29tcHJhL3BhZ2VzL05vdGFzQ3JlZGl0b0NvbXByYUZvcm1QYWdlJztcbmltcG9ydCB7IE5vdGFzQ3JlZGl0b0NvbXByYURldGFpbFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9ub3Rhc19jcmVkaXRvX2NvbXByYS9wYWdlcy9Ob3Rhc0NyZWRpdG9Db21wcmFEZXRhaWxQYWdlJztcbmltcG9ydCB7IE5vdGFzRmluYW5jaWVyYXNDb21wcmFMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL25vdGFzX2ZpbmFuY2llcmFzX2NvbXByYS9wYWdlcy9Ob3Rhc0ZpbmFuY2llcmFzQ29tcHJhTGlzdFBhZ2UnO1xuaW1wb3J0IHsgTm90YXNGaW5hbmNpZXJhc0NvbXByYUZvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXNfY29tcHJhL3BhZ2VzL05vdGFzRmluYW5jaWVyYXNDb21wcmFGb3JtUGFnZSc7XG5pbXBvcnQgeyBOb3Rhc0ZpbmFuY2llcmFzQ29tcHJhRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL25vdGFzX2ZpbmFuY2llcmFzX2NvbXByYS9wYWdlcy9Ob3Rhc0ZpbmFuY2llcmFzQ29tcHJhRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9tZXJjYWRvbGlicmVfcHVibGljYWNpb25lcy9wYWdlcy9NZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbWVyY2Fkb2xpYnJlX3B1YmxpY2FjaW9uZXMvcGFnZXMvTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlJztcbmltcG9ydCB7IE1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvbWVyY2Fkb2xpYnJlX3B1YmxpY2FjaW9uZXMvcGFnZXMvTWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgUmVwb3J0ZXNMaXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL3JlcG9ydGVzL3BhZ2VzL1JlcG9ydGVzTGlzdFBhZ2UnO1xuaW1wb3J0IHsgUmVwb3J0ZXNSdW5uZXJQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvcmVwb3J0ZXMvcGFnZXMvUmVwb3J0ZXNSdW5uZXJQYWdlJztcbmltcG9ydCB7IExlYWRzTGlzdFBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9sZWFkcy9wYWdlcy9MZWFkc0xpc3RQYWdlJztcbmltcG9ydCB7IExlYWRzRGV0YWlsUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2xlYWRzL3BhZ2VzL0xlYWRzRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBMZWFkc0NyZWF0ZVBhZ2UgfSBmcm9tICcuLi9mZWF0dXJlcy9sZWFkcy9wYWdlcy9MZWFkc0NyZWF0ZVBhZ2UnO1xuaW1wb3J0IHsgTGVhZHNFZGl0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2xlYWRzL3BhZ2VzL0xlYWRzRWRpdFBhZ2UnO1xuaW1wb3J0IHsgQ2FqYXNTdGF0ZW1lbnRQYWdlIH0gZnJvbSAnLi4vZmVhdHVyZXMvY2FqYXMvcGFnZXMvQ2FqYXNTdGF0ZW1lbnRQYWdlJztcblxuLy8gQ29tcG9uZW50ZSBwbGFjZWhvbGRlciBwYXJhIGxhcyBydXRhcyBxdWUgYcO6biBubyBleGlzdGVuXG4vKlxuY29uc3QgUGxhY2Vob2xkZXJQYWdlID0gKHsgdGl0bGUgfTogeyB0aXRsZTogc3RyaW5nIH0pID0+IChcbiAgICA8ZGl2PlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkXCI+e3RpdGxlfTwvaDE+XG4gICAgICAgIDxwPlDDoWdpbmEgZW4gY29uc3RydWNjacOzbi48L3A+XG4gICAgPC9kaXY+XG4pO1xuKi9cblxuY29uc3Qgcm91dGVyID0gY3JlYXRlQnJvd3NlclJvdXRlcihbXG4gICAge1xuICAgICAgICBwYXRoOiAnL2xvZ2luJyxcbiAgICAgICAgZWxlbWVudDogPExvZ2luUGFnZSAvPixcbiAgICB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogJy9yZWN1cGVyYXItcGFzc3dvcmQnLFxuICAgICAgICBlbGVtZW50OiA8Rm9yZ290UGFzc3dvcmRQYWdlIC8+LFxuICAgIH0sXG4gICAge1xuICAgICAgICBwYXRoOiAnLycsXG4gICAgICAgIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSAvPixcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50OiA8TWFpbkxheW91dCAvPixcbiAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnZGFzaGJvYXJkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxEYXNoYm9hcmRQYWdlIC8+LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAvLyBBw5FBRElNT1MgTEEgUlVUQSBQQVJBIENMSUVOVEVTXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjbGllbnRlcycsXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBFc3RlIE91dGxldCBlcyBvcGNpb25hbCwgcGVybyBwZXJtaXRlIGNyZWFyIHVuIGxheW91dCBlc3BlY8OtZmljbyBwYXJhIGNsaWVudGVzIHNpIHNlIG5lY2VzaXRhXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY2xpZW50ZXNcIj48Q2xpZW50ZXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY2xpZW50ZXNcIj48Q2xpZW50ZUNyZWF0ZVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY2xpZW50ZXNcIj48Q2xpZW50ZURldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL2NsaWVudGVzXCI+PENsaWVudGVFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnYXJ0aWN1bG9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9hcnRpY3Vsb3NcIj48QXJ0aWN1bG9zTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL2FydGljdWxvc1wiPjxBcnRpY3Vsb0NyZWF0ZVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvYXJ0aWN1bG9zXCI+PEFydGljdWxvRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvYXJ0aWN1bG9zXCI+PEFydGljdWxvRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ21lcmNhZG9saWJyZS1wdWJsaWNhY2lvbmVzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9tZXJjYWRvbGlicmUtcHVibGljYWNpb25lc1wiPjxNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL21lcmNhZG9saWJyZS1wdWJsaWNhY2lvbmVzXCI+PE1lcmNhZG9MaWJyZVB1YmxpY2FjaW9uZXNGb3JtUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9tZXJjYWRvbGlicmUtcHVibGljYWNpb25lc1wiPjxNZXJjYWRvTGlicmVQdWJsaWNhY2lvbmVzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvbWVyY2Fkb2xpYnJlLXB1YmxpY2FjaW9uZXNcIj48TWVyY2Fkb0xpYnJlUHVibGljYWNpb25lc0Zvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdsZWFkcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvbGVhZHNcIj48TGVhZHNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvbGVhZHNcIj48TGVhZHNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2xlYWRzXCI+PExlYWRzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvbGVhZHNcIj48TGVhZHNFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncHJvdmVlZG9yZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3Byb3ZlZWRvcmVzXCI+PFByb3ZlZWRvcmVzTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL3Byb3ZlZWRvcmVzXCI+PFByb3ZlZWRvckNyZWF0ZVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvcHJvdmVlZG9yZXNcIj48UHJvdmVlZG9yRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvcHJvdmVlZG9yZXNcIj48UHJvdmVlZG9yRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAndHJhbnNwb3J0ZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3RyYW5zcG9ydGVzXCI+PFRyYW5zcG9ydGVzTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL3RyYW5zcG9ydGVzXCI+PFRyYW5zcG9ydGVzQ3JlYXRlUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi90cmFuc3BvcnRlc1wiPjxUcmFuc3BvcnRlc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL3RyYW5zcG9ydGVzXCI+PFRyYW5zcG9ydGVzRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgLy8gQcORQURJTU9TIFJVVEFTIFBMQUNFSE9MREVSIFBBUkEgUVVFIExPUyBMSU5LUyBOTyBST01QQU4gTEEgQVBQXG5cbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3ZlbmRlZG9yZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3ZlbmRlZG9yZXNcIj48VmVuZGVkb3Jlc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnbnVldm8nLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImNyZWF0ZVwiIGJhc2VSb3V0ZT1cIi92ZW5kZWRvcmVzXCI+PFZlbmRlZG9yZXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3ZlbmRlZG9yZXNcIj48VmVuZGVkb3Jlc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL3ZlbmRlZG9yZXNcIj48VmVuZGVkb3Jlc0VkaXRQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb21wcmFkb3JlcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29tcHJhZG9yZXNcIj48Q29tcHJhZG9yZXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY29tcHJhZG9yZXNcIj48Q29tcHJhZG9yZXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NvbXByYWRvcmVzXCI+PENvbXByYWRvcmVzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvY29tcHJhZG9yZXNcIj48Q29tcHJhZG9yZXNFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnZmFjdHVyYXMtZGUtdmVudGEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2ZhY3R1cmFzLWRlLXZlbnRhXCI+PEZhY3R1cmFzVmVudGFMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvZmFjdHVyYXMtZGUtdmVudGFcIj48RmFjdHVyYXNWZW50YUZvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2ZhY3R1cmFzLWRlLXZlbnRhXCI+PEZhY3R1cmFzVmVudGFEZXRhaWxQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkL2VkaXRhcicsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiZWRpdFwiIGJhc2VSb3V0ZT1cIi9mYWN0dXJhcy1kZS12ZW50YVwiPjxGYWN0dXJhc1ZlbnRhRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ25vdGFzLWNyZWRpdG8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG9cIj48Tm90YXNDcmVkaXRvTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSwgLy8gTGlzdGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG9cIj48Tm90YXNDcmVkaXRvRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSwgLy8gQ3JlYXIgKEZvcm11bGFyaW8gdmFjw61vKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9ub3Rhcy1jcmVkaXRvXCI+PE5vdGFzQ3JlZGl0b0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSwgLy8gVmVyIERldGFsbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG9cIj48Tm90YXNDcmVkaXRvRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSwgLy8gRWRpdGFyIChGb3JtdWxhcmlvIGNvbiBkYXRvcylcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ25vdGFzLWZpbmFuY2llcmFzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9ub3Rhcy1maW5hbmNpZXJhc1wiPjxOb3Rhc0ZpbmFuY2llcmFzTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL25vdGFzLWZpbmFuY2llcmFzXCI+PE5vdGFzRmluYW5jaWVyYXNGb3JtUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9ub3Rhcy1maW5hbmNpZXJhc1wiPjxOb3Rhc0ZpbmFuY2llcmFzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvbm90YXMtZmluYW5jaWVyYXNcIj48Tm90YXNGaW5hbmNpZXJhc0Zvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdyZW1pdG9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9yZW1pdG9zXCI+PFJlbWl0b3NMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvcmVtaXRvc1wiPjxSZW1pdG9zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvcmVtaXRvc1wiPjxSZW1pdG9zRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvcmVtaXRvc1wiPjxSZW1pdG9zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvYnJhbnphcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29icmFuemFzXCI+PENvYnJhbnphc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnbnVldm8nLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImNyZWF0ZVwiIGJhc2VSb3V0ZT1cIi9jb2JyYW56YXNcIj48Q29icmFuemFzRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29icmFuemFzXCI+PENvYnJhbnphc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL2NvYnJhbnphc1wiPjxDb2JyYW56YXNGb3JtUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGVkaWRvcy1kZS12ZW50YScsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvcGVkaWRvcy1kZS12ZW50YVwiPjxQZWRpZG9zVmVudGFMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvcGVkaWRvcy1kZS12ZW50YVwiPjxQZWRpZG9zVmVudGFGb3JtUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9wZWRpZG9zLWRlLXZlbnRhXCI+PFBlZGlkb3NWZW50YURldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL3BlZGlkb3MtZGUtdmVudGFcIj48UGVkaWRvc1ZlbnRhRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2F1dG9yaXphY2lvbi1wZWRpZG9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9hdXRvcml6YWNpb24tcGVkaWRvc1wiPjxBdXRvcml6YWNpb25QZWRpZG9zTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIHJlcXVpcmVkUGVybWlzc2lvbj1cInNhbGVzX29yZGVyX2F1dGhvcml6YXRpb24uZGV0YWlsXCI+PEF1dG9yaXphY2lvblBlZGlkb0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvbXByYXMnLCBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29tcHJhc1wiPjxDb21wcmFzTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL2NvbXByYXNcIj48Q29tcHJhc0Zvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkL2VkaXRhcicsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiZWRpdFwiIGJhc2VSb3V0ZT1cIi9jb21wcmFzXCI+PENvbXByYXNGb3JtUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9jb21wcmFzXCI+PENvbXByYXNEZXRhaWxQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ29yZGVuZXMtZGUtcGFnbycsIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9vcmRlbmVzLWRlLXBhZ29cIj48T3JkZW5lc1BhZ29MaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvb3JkZW5lcy1kZS1wYWdvXCI+PE9yZGVuZXNQYWdvRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL29yZGVuZXMtZGUtcGFnb1wiPjxPcmRlbmVzUGFnb0Zvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL29yZGVuZXMtZGUtcGFnb1wiPjxPcmRlbmVzUGFnb0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcblxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdub3Rhcy1jcmVkaXRvLWNvbXByYScsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvbm90YXMtY3JlZGl0by1jb21wcmFcIj48Tm90YXNDcmVkaXRvQ29tcHJhTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG8tY29tcHJhXCI+PE5vdGFzQ3JlZGl0b0NvbXByYUZvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG8tY29tcHJhXCI+PE5vdGFzQ3JlZGl0b0NvbXByYURldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL25vdGFzLWNyZWRpdG8tY29tcHJhXCI+PE5vdGFzQ3JlZGl0b0NvbXByYUZvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdub3Rhcy1maW5hbmNpZXJhcy1jb21wcmEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL25vdGFzLWZpbmFuY2llcmFzLWNvbXByYVwiPjxOb3Rhc0ZpbmFuY2llcmFzQ29tcHJhTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL25vdGFzLWZpbmFuY2llcmFzLWNvbXByYVwiPjxOb3Rhc0ZpbmFuY2llcmFzQ29tcHJhRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvbm90YXMtZmluYW5jaWVyYXMtY29tcHJhXCI+PE5vdGFzRmluYW5jaWVyYXNDb21wcmFEZXRhaWxQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkL2VkaXRhcicsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiZWRpdFwiIGJhc2VSb3V0ZT1cIi9ub3Rhcy1maW5hbmNpZXJhcy1jb21wcmFcIj48Tm90YXNGaW5hbmNpZXJhc0NvbXByYUZvcm1QYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BsYW4tZGUtY3VlbnRhcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvcGxhbi1kZS1jdWVudGFzXCI+PFBsYW5EZUN1ZW50YXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvcGxhbi1kZS1jdWVudGFzXCI+PFBsYW5EZUN1ZW50YXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3BsYW4tZGUtY3VlbnRhc1wiPjxQbGFuRGVDdWVudGFzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvcGxhbi1kZS1jdWVudGFzXCI+PFBsYW5EZUN1ZW50YXNFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnYmFuY29zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9iYW5jb3NcIj48QmFuY29zTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL2JhbmNvc1wiPjxCYW5jb3NDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2JhbmNvc1wiPjxCYW5jb3NEZXRhaWxQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkL2VkaXRhcicsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiZWRpdFwiIGJhc2VSb3V0ZT1cIi9iYW5jb3NcIj48QmFuY29zRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NhamFzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9jYWphc1wiPjxDYWphc1N0YXRlbWVudFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdsaXN0JywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY2FqYXNcIj48Q2FqYXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY2FqYXNcIj48Q2FqYXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NhamFzXCI+PENhamFzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvY2FqYXNcIj48Q2FqYXNFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnbW92aW1pZW50b3MtYmFuY29zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9tb3ZpbWllbnRvcy1iYW5jb3NcIj48TW92aW1pZW50b3NCYW5jb3NMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvbW92aW1pZW50b3MtYmFuY29zXCI+PE1vdmltaWVudG9zQmFuY29zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvbW92aW1pZW50b3MtYmFuY29zXCI+PE1vdmltaWVudG9zQmFuY29zRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvbW92aW1pZW50b3MtYmFuY29zXCI+PE1vdmltaWVudG9zQmFuY29zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NoZXF1ZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NoZXF1ZXNcIj48Q2hlcXVlc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NoZXF1ZXNcIj48Q2hlcXVlc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ21vbmVkYXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL21vbmVkYXNcIj48TW9uZWRhc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnbnVldm8nLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImNyZWF0ZVwiIGJhc2VSb3V0ZT1cIi9tb25lZGFzXCI+PE1vbmVkYXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL21vbmVkYXNcIj48TW9uZWRhc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL21vbmVkYXNcIj48TW9uZWRhc0VkaXRQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdzdG9jay9tb3ZpbWllbnRvcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvc3RvY2svbW92aW1pZW50b3NcIj48TW92U3RvY2tMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvc3RvY2svbW92aW1pZW50b3NcIj48TW92U3RvY2tDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3N0b2NrL21vdmltaWVudG9zXCI+PE1vdlN0b2NrRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvc3RvY2svbW92aW1pZW50b3NcIj48TW92U3RvY2tFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdzdG9jay9mcmFjY2lvbmFtaWVudG9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9zdG9jay9mcmFjY2lvbmFtaWVudG9zXCI+PEZyYWN0aW9uaW5nTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL3N0b2NrL2ZyYWNjaW9uYW1pZW50b3NcIj48RnJhY3Rpb25pbmdDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL3N0b2NrL2ZyYWNjaW9uYW1pZW50b3NcIj48RnJhY3Rpb25pbmdEZXRhaWxQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb25maWd1cmFjaW9uL3VzdWFyaW9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9jb25maWd1cmFjaW9uL3VzdWFyaW9zXCI+PFVzdWFyaW9zTGlzdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICdudWV2bycsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwiY3JlYXRlXCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vdXN1YXJpb3NcIj48VXN1YXJpb0NyZWF0ZVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi91c3Vhcmlvc1wiPjxVc3VhcmlvRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi91c3Vhcmlvc1wiPjxVc3VhcmlvRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2NvbmZpZ3VyYWNpb24vcHJvZmlsZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vcHJvZmlsZXNcIj48UHJvZmlsZXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi9wcm9maWxlc1wiPjxQcm9maWxlQ3JlYXRlUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZCcsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9jb25maWd1cmFjaW9uL3Byb2ZpbGVzXCI+PFByb2ZpbGVFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi9wcm9maWxlc1wiPjxQcm9maWxlRWRpdFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY29uZmlndXJhY2lvbi9pbXB1ZXN0b3MnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudDogPE91dGxldCAvPixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpbmRleDogdHJ1ZSwgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vaW1wdWVzdG9zXCI+PEltcHVlc3Rvc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnbnVldm8nLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImNyZWF0ZVwiIGJhc2VSb3V0ZT1cIi9jb25maWd1cmFjaW9uL2ltcHVlc3Rvc1wiPjxJbXB1ZXN0b3NDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vaW1wdWVzdG9zXCI+PEltcHVlc3Rvc0RldGFpbFBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQvZWRpdGFyJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJlZGl0XCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vaW1wdWVzdG9zXCI+PEltcHVlc3Rvc0VkaXRQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb25maWd1cmFjaW9uL2NvbWlzaW9uZXMtdmVuZGVkb3JlcycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8T3V0bGV0IC8+LFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi9jb21pc2lvbmVzLXZlbmRlZG9yZXNcIj48Q29taXNpb25lc1ZlbmRlZG9yZXNMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi9jb21pc2lvbmVzLXZlbmRlZG9yZXNcIj48Q29taXNpb25lc1ZlbmRlZG9yZXNDcmVhdGVQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXRoOiAnOmlkJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJ2aWV3XCIgYmFzZVJvdXRlPVwiL2NvbmZpZ3VyYWNpb24vY29taXNpb25lcy12ZW5kZWRvcmVzXCI+PENvbWlzaW9uZXNWZW5kZWRvcmVzRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvY29uZmlndXJhY2lvbi9jb21pc2lvbmVzLXZlbmRlZG9yZXNcIj48Q29taXNpb25lc1ZlbmRlZG9yZXNFZGl0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnY29uZmlndXJhY2lvbi9zaXN0ZW1hJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVybWlzc2lvblJvdXRlIHJlcXVpcmVkUGVybWlzc2lvbj1cImNvbmZpZ3VyYWNpb24uZWRpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3JnYW5pemF0aW9uRGV0YWlsc1BhZ2UgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Blcm1pc3Npb25Sb3V0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdjb25maWd1cmFjaW9uL3RhYmxhcy1hY2Nlc29yaWFzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVybWlzc2lvblJvdXRlIHJlcXVpcmVkUGVybWlzc2lvbj1cImNvbmZpZ3VyYWNpb24uZWRpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFibGFzQWNjZXNvcmlhc1BhZ2UgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Blcm1pc3Npb25Sb3V0ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2xpc3Rhcy1kZS1wcmVjaW9zJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9saXN0YXMtZGUtcHJlY2lvc1wiPjxMaXN0YXNEZVByZWNpb3NMaXN0UGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJ251ZXZvJywgZWxlbWVudDogPFBlcm1pc3Npb25Sb3V0ZSBhY3Rpb249XCJjcmVhdGVcIiBiYXNlUm91dGU9XCIvbGlzdGFzLWRlLXByZWNpb3NcIj48TGlzdGFzRGVQcmVjaW9zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvbGlzdGFzLWRlLXByZWNpb3NcIj48TGlzdGFzRGVQcmVjaW9zRGV0YWlsUGFnZSAvPjwvUGVybWlzc2lvblJvdXRlPiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgcGF0aDogJzppZC9lZGl0YXInLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cImVkaXRcIiBiYXNlUm91dGU9XCIvbGlzdGFzLWRlLXByZWNpb3NcIj48TGlzdGFzRGVQcmVjaW9zRm9ybVBhZ2UgLz48L1Blcm1pc3Npb25Sb3V0ZT4gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3JlcG9ydGVzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ6IDxPdXRsZXQgLz4sXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDEuIExpc3RhIGRlIHJlcG9ydGVzIGRpc3BvbmlibGVzIChMYSBlbnRyYWRhIGRlbCBtw7NkdWxvKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaW5kZXg6IHRydWUsIGVsZW1lbnQ6IDxQZXJtaXNzaW9uUm91dGUgYWN0aW9uPVwidmlld1wiIGJhc2VSb3V0ZT1cIi9yZXBvcnRlc1wiPjxSZXBvcnRlc0xpc3RQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAyLiBFbCBcIlJ1bm5lclwiIGRpbsOhbWljbyAoRWplY3VjacOzbiBkZSB1biByZXBvcnRlIGVzcGVjw61maWNvKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIExhIFVSTCBzZXLDoSAvcmVwb3J0ZXMvMSwgL3JlcG9ydGVzLzIsIGV0Yy5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHBhdGg6ICc6aWQnLCBlbGVtZW50OiA8UGVybWlzc2lvblJvdXRlIGFjdGlvbj1cInZpZXdcIiBiYXNlUm91dGU9XCIvcmVwb3J0ZXNcIj48UmVwb3J0ZXNSdW5uZXJQYWdlIC8+PC9QZXJtaXNzaW9uUm91dGU+IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50OiA8TmF2aWdhdGUgdG89XCIvZGFzaGJvYXJkXCIgLz4sXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuXSk7XG5cbi8vIC4uLiByZXN0byBkZWwgYXJjaGl2b1xuZXhwb3J0IGNvbnN0IEFwcFJvdXRlciA9ICgpID0+IHtcbiAgICByZXR1cm4gPFJvdXRlclByb3ZpZGVyIHJvdXRlcj17cm91dGVyfSAvPjtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9yb3V0ZXMvQXBwUm91dGVyLnRzeCJ9