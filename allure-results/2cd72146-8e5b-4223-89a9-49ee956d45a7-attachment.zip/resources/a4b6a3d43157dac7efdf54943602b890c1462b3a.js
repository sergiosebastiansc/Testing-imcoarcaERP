import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/reportes/pages/ReportesRunnerPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/reportes/pages/ReportesRunnerPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { IoArrowBack, IoPlay, IoSearch, IoDocumentText, IoChevronBack, IoChevronForward } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaFilter, FaTable, FaFilePdf, FaFileAlt, FaFileExcel } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getAll, getFileBlobWithMeta, searchByField } from "/src/services/apiService.ts";
import { downloadBlob } from "/src/utils/blobHelper.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { parseMovementCodePrefix, renderSignedStockQuantity } from "/src/utils/stockMovementQuantity.tsx";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { reportesModuleConfig } from "/src/features/reportes/reportes.config.tsx";
import { hasRenderableFooter } from "/src/features/reportes/reportFooter.types.ts";
import { ReportFooterSection } from "/src/features/reportes/ReportFooterSection.tsx";
import { MultiSelectDropdown } from "/src/components/common/MultiSelectDropdown.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
const getNestedValue = (obj, path) => {
  if (!obj || !path) return null;
  return path.split(".").reduce((acc, part) => acc && acc[part], obj);
};
const parseOptions = (options) => {
  try {
    if (!options) return null;
    if (typeof options === "string") return JSON.parse(options);
    return options;
  } catch (e) {
    console.error("Error parsing options", e);
    return null;
  }
};
const getValueLabelSelectOptions = (options) => {
  const parsed = parseOptions(options);
  if (!parsed) return [];
  const items = Array.isArray(parsed) ? parsed : Object.values(parsed);
  return items.filter(
    (opt) => opt !== null && typeof opt === "object" && "value" in opt && "label" in opt
  ).map((opt) => ({
    value: String(opt.value),
    label: String(opt.label)
  }));
};
const isSingleSelectFilter = (options) => {
  const parsed = parseOptions(options);
  return parsed?.mode === "group_by" || parsed?.single === true;
};
const inferRelationshipOptions = (field) => {
  const mapping = {
    "client_id": "clients",
    "customer_id": "clients",
    "salesperson_id": "salespeople",
    "vendor_id": "vendors",
    "supplier_id": "suppliers",
    "transport_id": "transports",
    "currency_id": "currencies",
    "display_currency_id": "currencies",
    "product_id": "products",
    "article_id": "products",
    "buyer_id": "buyers"
  };
  const resource = mapping[field];
  if (resource) {
    const isProduct = field === "product_id" || field === "article_id";
    return {
      resource,
      label_field: "name",
      value_field: "id",
      code_field: isProduct ? "sku" : void 0,
      // ✅ Agregar code_field para productos
      placeholder: `Buscar...`,
      api_endpoint: isProduct ? "products" : `/${resource}`
      // ✅ Para productos, usar 'products' sin barra inicial
    };
  }
  return null;
};
function getReportFilterKey(filter) {
  if (filter.operator === "date_from" || filter.operator === "date_to") {
    return `${filter.field}_${filter.operator}`;
  }
  return `${filter.field}__${filter.id}`;
}
const RPT_CUSTOMER_ACCOUNT = "RPT_CUSTOMER_ACCOUNT";
function getSelectFilterValues(currentValue) {
  if (Array.isArray(currentValue)) {
    return currentValue.map(String);
  }
  if (currentValue === "" || currentValue === null || currentValue === void 0) {
    return [];
  }
  return [String(currentValue)];
}
function filterValueIsPresent(value) {
  if (value === "" || value === null || value === void 0) {
    return false;
  }
  if (Array.isArray(value)) {
    return value.some((v) => v !== "" && v !== null && v !== void 0);
  }
  return true;
}
function filterOptionsRequireSelection(options) {
  const parsed = parseOptions(options);
  return parsed?.required === true;
}
function validateRequiredReportFilters(def, filterVals) {
  if (!def?.filters?.length) {
    return null;
  }
  for (const filter of def.filters) {
    if (filter.type !== "select" || !filterOptionsRequireSelection(filter.options)) {
      continue;
    }
    const uniqueKey = getReportFilterKey(filter);
    const selected = getSelectFilterValues(filterVals[uniqueKey]);
    if (selected.length === 0) {
      return `Seleccione al menos un valor para "${filter.label}".`;
    }
  }
  return null;
}
function buildReportQueryString(payload) {
  const parts = [];
  for (const [key, value] of Object.entries(payload)) {
    if (!filterValueIsPresent(value)) {
      continue;
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item !== "" && item !== null && item !== void 0) {
          parts.push(`${encodeURIComponent(key)}[]=${encodeURIComponent(String(item))}`);
        }
      }
    } else if (typeof value === "boolean") {
      parts.push(`${encodeURIComponent(key)}=${value ? "1" : "0"}`);
    } else {
      parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    }
  }
  return parts.join("&");
}
function getOpeningBalanceDateFromFilters(def, filterVals) {
  if (!def?.filters?.length) return "";
  for (const f of def.filters) {
    if (f.type === "date" && f.operator === "date_from") {
      const v = filterVals[getReportFilterKey(f)];
      if (v !== "" && v !== null && v !== void 0) {
        const s = String(v);
        return s.includes("T") ? s.split("T")[0] : s;
      }
      break;
    }
  }
  return "";
}
export const ReportesRunnerPage = () => {
  _s();
  const { id } = useParams();
  const reportIdFromRoute = id;
  const navigate = useNavigate();
  const { item: initialDef, loading: loadingDef, error: errorDef } = useCrudItem(reportesModuleConfig, id);
  const [filterValues, setFilterValues] = useState({});
  const [relationalLabels, setRelationalLabels] = useState({});
  const [relationalCodes, setRelationalCodes] = useState({});
  const [results, setResults] = useState([]);
  const [paginationMeta, setPaginationMeta] = useState(null);
  const [dynamicMeta, setDynamicMeta] = useState(null);
  const [statementInitialBalance, setStatementInitialBalance] = useState(void 0);
  const [isRunning, setIsRunning] = useState(false);
  const [isExporting, setIsExporting] = useState(null);
  const [executionError, setExecutionError] = useState(null);
  const [hasRun, setHasRun] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [activeSearchFilter, setActiveSearchFilter] = useState(null);
  const handleFilterChange = (key, value) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
  };
  useEffect(() => {
    if (!initialDef?.filters?.length || reportIdFromRoute == null || String(initialDef.code) !== String(reportIdFromRoute)) {
      return;
    }
    const { startDate, endDate } = getDefaultListDateRange();
    setFilterValues((prev) => {
      const patch = {};
      for (const f of initialDef.filters) {
        if (f.type !== "date") continue;
        const uniqueKey = getReportFilterKey(f);
        const cur = prev[uniqueKey];
        const isEmpty = cur === "" || cur === null || cur === void 0;
        if (!isEmpty) continue;
        if (f.operator === "date_from") patch[uniqueKey] = startDate;
        else if (f.operator === "date_to") patch[uniqueKey] = endDate;
      }
      if (Object.keys(patch).length === 0) return prev;
      return { ...prev, ...patch };
    });
  }, [initialDef, reportIdFromRoute]);
  useEffect(() => {
    setStatementInitialBalance(void 0);
  }, [reportIdFromRoute]);
  const handleOpenSearch = (filterKey, options) => {
    setActiveSearchFilter({ key: filterKey, config: options });
    setIsSearchModalOpen(true);
  };
  const handleSelectFromModal = (item) => {
    if (!activeSearchFilter) return;
    const { key, config } = activeSearchFilter;
    const selectedRow = item;
    const valField = config.value_field || "id";
    const labField = config.label_field || "name";
    const codField = config.code_field || config.value_field || "id";
    handleFilterChange(key, selectedRow[valField]);
    setRelationalLabels((prev) => ({
      ...prev,
      [key]: selectedRow[labField]
    }));
    setRelationalCodes((prev) => ({
      ...prev,
      [key]: selectedRow[codField]
    }));
    setIsSearchModalOpen(false);
    setActiveSearchFilter(null);
  };
  const handleRelationalInputChange = (key, newValue) => {
    setRelationalCodes((prev) => ({ ...prev, [key]: newValue }));
  };
  const handleAutocompleteSelect = (key, item, config) => {
    const valField = config.value_field || "id";
    const labField = config.label_field || "name";
    const codField = config.code_field || config.value_field || "id";
    handleFilterChange(key, item[valField]);
    setRelationalLabels((prev) => ({
      ...prev,
      [key]: item[labField]
    }));
    setRelationalCodes((prev) => ({
      ...prev,
      [key]: item[codField]
    }));
  };
  const handleCodeSubmit = async (filterKey, code, options) => {
    if (!code) {
      handleFilterChange(filterKey, "");
      setRelationalLabels((prev) => ({ ...prev, [filterKey]: "" }));
      setRelationalCodes((prev) => ({ ...prev, [filterKey]: "" }));
      return;
    }
    try {
      const endpointUrl = options.api_endpoint?.split("?")[0] || `/${options.resource}`;
      const searchField = options.code_field || options.value_field || "id";
      const result = await searchByField(endpointUrl, [{ fieldName: searchField, value: code }]);
      if (result) {
        const valField = options.value_field || "id";
        const labField = options.label_field || "name";
        const codField = options.code_field || options.value_field || "id";
        const foundItem = result;
        handleFilterChange(filterKey, foundItem[valField]);
        setRelationalLabels((prev) => ({ ...prev, [filterKey]: foundItem[labField] }));
        setRelationalCodes((prev) => ({ ...prev, [filterKey]: foundItem[codField] }));
      } else {
        toast.warn("No encontrado");
        handleFilterChange(filterKey, "");
        setRelationalLabels((prev) => ({ ...prev, [filterKey]: "" }));
      }
    } catch (error) {
      console.error(error);
      toast.error("Error al buscar");
    }
  };
  const buildFilterPayload = () => {
    if (!initialDef) return {};
    const payload = {};
    initialDef.filters.forEach((filter) => {
      const uniqueKey = getReportFilterKey(filter);
      const value = filterValues[uniqueKey];
      if (filter.type === "checkbox") {
        if (value === true) {
          payload[filter.field] = true;
        }
        return;
      }
      if (filter.type === "select") {
        if (isSingleSelectFilter(filter.options)) {
          const scalar = typeof value === "string" ? value : Array.isArray(value) ? value[0] ?? "" : "";
          if (scalar !== "") {
            payload[filter.field] = scalar;
          }
          return;
        }
        const selected = getSelectFilterValues(value);
        if (selected.length > 0) {
          payload[filter.field] = selected;
        }
        return;
      }
      if (filterValueIsPresent(value)) {
        if (filter.operator === "date_from") payload[`${filter.field}_from`] = value;
        else if (filter.operator === "date_to") payload[`${filter.field}_to`] = value;
        else
          payload[filter.field] = value;
      }
    });
    return payload;
  };
  const handleRunReport = async (pageNumber = 1) => {
    if (!initialDef) return;
    const validationError = validateRequiredReportFilters(initialDef, filterValues);
    if (validationError) {
      toast.warn(validationError);
      return;
    }
    setIsRunning(true);
    setExecutionError(null);
    setHasRun(true);
    if (pageNumber === 1) {
      setResults([]);
      setDynamicMeta(null);
      setPaginationMeta(null);
      setStatementInitialBalance(void 0);
    }
    try {
      const endpoint = `${reportesModuleConfig.endpoint}/${id}/run`;
      const payload = {
        ...buildFilterPayload(),
        page: pageNumber
      };
      const response = await getAll(endpoint, payload);
      const rawResponse = response;
      let rows = [];
      if (rawResponse.data && Array.isArray(rawResponse.data.data)) {
        const pager = rawResponse.data;
        rows = pager.data;
        setPaginationMeta({
          current_page: pager.current_page,
          last_page: pager.last_page,
          total: pager.total,
          from: pager.from,
          to: pager.to,
          per_page: pager.per_page
        });
        if (String(reportIdFromRoute) === RPT_CUSTOMER_ACCOUNT && "initial_balance" in pager && pager.initial_balance !== null && pager.initial_balance !== void 0) {
          const n = Number(pager.initial_balance);
          if (!Number.isNaN(n)) setStatementInitialBalance(n);
        }
      } else if (Array.isArray(rawResponse.data)) {
        rows = rawResponse.data;
        setPaginationMeta(null);
      } else if (Array.isArray(rawResponse)) {
        rows = rawResponse;
        setPaginationMeta(null);
      }
      if (rawResponse.meta) {
        setDynamicMeta(rawResponse.meta);
      }
      setResults(rows);
      const hasOpeningBalanceUi = String(reportIdFromRoute) === RPT_CUSTOMER_ACCOUNT && pageNumber === 1 && rawResponse.data && typeof rawResponse.data === "object" && !Array.isArray(rawResponse.data) && "initial_balance" in rawResponse.data && rawResponse.data.initial_balance !== null && rawResponse.data.initial_balance !== void 0 && !Number.isNaN(Number(rawResponse.data.initial_balance));
      if (rows.length === 0 && pageNumber === 1 && !hasOpeningBalanceUi) {
        toast.info("El reporte no arrojó resultados.");
      } else if (pageNumber === 1) {
        toast.success("Reporte generado con éxito.");
      }
    } catch (err) {
      console.error(err);
      setExecutionError("Error al ejecutar el reporte.");
      toast.error("Error al ejecutar reporte");
    } finally {
      setIsRunning(false);
    }
  };
  const handleInitialRun = () => handleRunReport(1);
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && (!paginationMeta || newPage <= paginationMeta.last_page)) {
      handleRunReport(newPage);
    }
  };
  const handleExport = async (format) => {
    if (!initialDef) return;
    const validationError = validateRequiredReportFilters(initialDef, filterValues);
    if (validationError) {
      toast.warn(validationError);
      return;
    }
    setIsExporting(format);
    try {
      const payload = buildFilterPayload();
      const queryString = buildReportQueryString(payload);
      const endpoint = `${reportesModuleConfig.endpoint}/${id}/run/${format}?${queryString}`;
      const { blob, filename } = await getFileBlobWithMeta(endpoint);
      const fallbackName = `${initialDef.code}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.${format}`;
      downloadBlob(blob, filename === "documento.pdf" ? fallbackName : filename);
      toast.success(`Archivo ${format.toUpperCase()} generado.`);
    } catch (error) {
      console.error(`Error ${format}:`, error);
      toast.error(`Error al exportar ${format.toUpperCase()}.`);
    } finally {
      setIsExporting(null);
    }
  };
  const renderExportButtons = () => {
    if (!hasRun) return null;
    const formats = dynamicMeta?.available_formats || initialDef?.available_formats || ["pdf"];
    return /* @__PURE__ */ jsxDEV("div", { className: "flex space-x-2", children: [
      formats.includes("pdf") && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleExport("pdf"), disabled: !!isExporting, className: "flex items-center px-3 py-1.5 text-sm font-medium text-white bg-red-600 rounded shadow hover:bg-red-700 disabled:opacity-50", children: [
        isExporting === "pdf" ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 567,
          columnNumber: 50
        }, this) : /* @__PURE__ */ jsxDEV(FaFilePdf, { className: "mr-2" }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 567,
          columnNumber: 96
        }, this),
        " PDF"
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 566,
        columnNumber: 9
      }, this),
      formats.includes("xlsx") && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => handleExport("xlsx"),
          disabled: !!isExporting,
          className: "flex items-center px-3 py-1.5 text-sm font-medium text-white bg-green-600 rounded shadow hover:bg-green-700 disabled:opacity-50",
          children: [
            isExporting === "xlsx" ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 577,
              columnNumber: 51
            }, this) : /* @__PURE__ */ jsxDEV(FaFileExcel, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 577,
              columnNumber: 97
            }, this),
            "Excel"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 572,
          columnNumber: 9
        },
        this
      ),
      formats.includes("txt") && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleExport("txt"), disabled: !!isExporting, className: "flex items-center px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded shadow hover:bg-gray-50 disabled:opacity-50", children: [
        isExporting === "txt" ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 583,
          columnNumber: 50
        }, this) : /* @__PURE__ */ jsxDEV(FaFileAlt, { className: "mr-2 text-gray-500" }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 583,
          columnNumber: 96
        }, this),
        " TXT"
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 582,
        columnNumber: 9
      }, this),
      formats.filter((f) => !["pdf", "txt", "xlsx", "json"].includes(f)).map(
        (f) => /* @__PURE__ */ jsxDEV("button", { onClick: () => handleExport(f), disabled: !!isExporting, className: "flex items-center px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded shadow hover:bg-gray-50 uppercase", children: [
          /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "mr-2" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 588,
            columnNumber: 25
          }, this),
          " ",
          f
        ] }, f, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 587,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 564,
      columnNumber: 7
    }, this);
  };
  const renderPagination = () => {
    if (!paginationMeta || paginationMeta.last_page <= 1) return null;
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-3 bg-white border-t border-gray-200 sm:px-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between flex-1 sm:hidden", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handlePageChange(paginationMeta.current_page - 1),
            disabled: paginationMeta.current_page === 1,
            className: "relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50",
            children: "Anterior"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 601,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handlePageChange(paginationMeta.current_page + 1),
            disabled: paginationMeta.current_page === paginationMeta.last_page,
            className: "relative ml-3 inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50",
            children: "Siguiente"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 608,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 600,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:flex sm:flex-1 sm:items-center sm:justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: [
          "Mostrando ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: paginationMeta.from }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 619,
            columnNumber: 39
          }, this),
          " a ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: paginationMeta.to }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 619,
            columnNumber: 100
          }, this),
          " de ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: paginationMeta.total }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 619,
            columnNumber: 160
          }, this),
          " resultados"
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 618,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 617,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("nav", { className: "inline-flex -space-x-px rounded-md shadow-sm", "aria-label": "Pagination", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePageChange(paginationMeta.current_page - 1),
              disabled: paginationMeta.current_page === 1,
              className: "relative inline-flex items-center px-2 py-2 text-gray-400 rounded-l-md border border-gray-300 bg-white hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Anterior" }, void 0, false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 629,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(IoChevronBack, { className: "h-5 w-5", "aria-hidden": "true" }, void 0, false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 630,
                  columnNumber: 33
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 624,
              columnNumber: 29
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 focus:outline-offset-0", children: [
            "Página ",
            paginationMeta.current_page,
            " de ",
            paginationMeta.last_page
          ] }, void 0, true, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 632,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePageChange(paginationMeta.current_page + 1),
              disabled: paginationMeta.current_page === paginationMeta.last_page,
              className: "relative inline-flex items-center px-2 py-2 text-gray-400 rounded-r-md border border-gray-300 bg-white hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Siguiente" }, void 0, false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 640,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(IoChevronForward, { className: "h-5 w-5", "aria-hidden": "true" }, void 0, false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 641,
                  columnNumber: 33
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 635,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 623,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 622,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 616,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 599,
      columnNumber: 7
    }, this);
  };
  const renderFilterInput = (filter) => {
    const commonClasses = "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm py-2 px-3 border";
    const uniqueKey = getReportFilterKey(filter);
    const rawValue = filterValues[uniqueKey];
    const currentValue = rawValue ?? "";
    if (filter.type === "relationship") {
      let relConfig = filter.options ? parseOptions(filter.options) : null;
      if (!relConfig) relConfig = inferRelationshipOptions(filter.field);
      if (relConfig) {
        const isProductFilter = relConfig.resource === "products";
        return /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: relationalCodes[uniqueKey] || "",
            nameValue: relationalLabels[uniqueKey] || "",
            onCodeChange: (val) => handleRelationalInputChange(uniqueKey, val),
            onCodeSubmit: () => handleCodeSubmit(uniqueKey, relationalCodes[uniqueKey], relConfig),
            onSearchClick: () => handleOpenSearch(uniqueKey, relConfig),
            onClearClick: () => {
              handleFilterChange(uniqueKey, "");
              setRelationalLabels((prev) => ({ ...prev, [uniqueKey]: "" }));
              setRelationalCodes((prev) => ({ ...prev, [uniqueKey]: "" }));
            },
            mask: isProductFilter ? "sku" : void 0,
            enableAutocomplete: isProductFilter,
            autocompleteConfig: isProductFilter ? {
              endpoint: articulosModuleConfig.endpoint,
              codeField: "sku",
              nameField: "name",
              onSelect: (item) => handleAutocompleteSelect(uniqueKey, item, relConfig)
            } : void 0
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 665,
            columnNumber: 11
          },
          this
        );
      }
    }
    switch (filter.type) {
      case "date":
        return /* @__PURE__ */ jsxDEV("input", { type: "date", autoComplete: "off", className: commonClasses, value: currentValue, onChange: (e) => handleFilterChange(uniqueKey, e.target.value) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 693,
          columnNumber: 16
        }, this);
      case "select": {
        const valueLabelOptions = getValueLabelSelectOptions(filter.options);
        if (isSingleSelectFilter(filter.options)) {
          const scalarValue = typeof currentValue === "string" ? currentValue : Array.isArray(currentValue) ? currentValue[0] ?? "" : "";
          return /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: commonClasses,
              value: scalarValue,
              onChange: (e) => handleFilterChange(uniqueKey, e.target.value),
              children: valueLabelOptions.map(
                (opt) => /* @__PURE__ */ jsxDEV("option", { value: opt.value, children: opt.label }, opt.value || "__empty__", false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 708,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 702,
              columnNumber: 15
            },
            this
          );
        }
        const optionsArray = parseOptions(filter.options) || [];
        const selected = getSelectFilterValues(rawValue);
        const dropdownOptions = Array.isArray(optionsArray) ? optionsArray.filter((opt) => opt !== null && typeof opt === "object" && "value" in opt && "label" in opt).map((opt) => ({
          value: String(opt.value),
          label: opt.label
        })) : valueLabelOptions;
        return /* @__PURE__ */ jsxDEV(
          MultiSelectDropdown,
          {
            options: dropdownOptions,
            selected,
            onChange: (values) => handleFilterChange(uniqueKey, values),
            placeholder: "Todos"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 727,
            columnNumber: 13
          },
          this
        );
      }
      case "number":
        return /* @__PURE__ */ jsxDEV(
          DecimalInput,
          {
            className: commonClasses,
            placeholder: filter.label,
            value: currentValue === "" || currentValue == null ? null : Number(currentValue) || 0,
            nullable: true,
            whenEmpty: null,
            onChange: (num) => handleFilterChange(uniqueKey, num ?? "")
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 737,
            columnNumber: 11
          },
          this
        );
      // ✅ CASE CHECKBOX
      case "checkbox":
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center h-10 mt-1", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: `filter-${uniqueKey}`,
              type: "checkbox",
              autoComplete: "off",
              className: "h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded cursor-pointer",
              checked: !!currentValue,
              onChange: (e) => handleFilterChange(uniqueKey, e.target.checked)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 751,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("label", { htmlFor: `filter-${uniqueKey}`, className: "ml-2 block text-sm text-gray-700 cursor-pointer select-none" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 758,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 750,
          columnNumber: 11
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV("div", { className: "relative rounded-md shadow-sm", children: /* @__PURE__ */ jsxDEV("input", { type: "text", autoComplete: "off", className: commonClasses, placeholder: "Buscar...", value: currentValue, onChange: (e) => handleFilterChange(uniqueKey, e.target.value) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 765,
          columnNumber: 63
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 765,
          columnNumber: 16
        }, this);
    }
  };
  const moneySymbol = dynamicMeta?.display_currency_symbol ?? (dynamicMeta?.display_currency_code === "01" || !dynamicMeta?.display_currency_code ? "$" : "USD");
  const renderCell = (row, colConfig) => {
    const rawValue = getNestedValue(row, colConfig.key);
    if (rawValue === null || rawValue === void 0) return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-300 text-xs", children: "-" }, void 0, false, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 774,
      columnNumber: 61
    }, this);
    if (reportIdFromRoute === "RPT_STOCK_MOVEMENTS" && colConfig.key === "quantity") {
      const codeForStyle = parseMovementCodePrefix(getNestedValue(row, "movement_code"));
      return renderSignedStockQuantity(codeForStyle ?? void 0, rawValue);
    }
    switch (colConfig.type) {
      case "money": {
        const num = Number(rawValue);
        const isNegative = !Number.isNaN(num) && num < 0;
        return /* @__PURE__ */ jsxDEV("span", { className: `font-mono ${isNegative ? "text-red-600" : "text-gray-700"}`, children: formatValue(rawValue, "currency", { moneySymbol }) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 786,
          columnNumber: 13
        }, this);
      }
      case "date":
        return /* @__PURE__ */ jsxDEV("span", { children: formatValue(rawValue, "date") }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 791,
          columnNumber: 26
        }, this);
      case "number":
        return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 tabular-nums", children: formatValue(rawValue, "number") }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 792,
          columnNumber: 28
        }, this);
      case "badge":
        return /* @__PURE__ */ jsxDEV("span", { className: "px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 uppercase", children: String(rawValue) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 793,
          columnNumber: 27
        }, this);
      case "link": {
        const linkId = colConfig.link_id_key ? getNestedValue(row, colConfig.link_id_key) : null;
        const label = String(rawValue);
        if (!linkId || !colConfig.link_path) {
          return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: label }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 798,
            columnNumber: 20
          }, this);
        }
        const path = colConfig.link_path.replace(":id", String(linkId));
        return /* @__PURE__ */ jsxDEV(Link, { to: path, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: label }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 802,
          columnNumber: 13
        }, this);
      }
      default:
        return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: String(rawValue) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 807,
          columnNumber: 22
        }, this);
    }
  };
  const tableRows = useMemo(() => {
    if (String(reportIdFromRoute) !== RPT_CUSTOMER_ACCOUNT) return results;
    const pageOne = paginationMeta == null || paginationMeta.current_page === 1;
    const ibOk = statementInitialBalance !== void 0 && Number.isFinite(statementInitialBalance);
    if (!pageOne || !ibOk) return results;
    const dateFrom = getOpeningBalanceDateFromFilters(initialDef ?? null, filterValues);
    const synthetic = {
      transaction_date: dateFrom ? dateFrom : null,
      document_type: "Saldo inicial",
      document_number: "",
      debit: 0,
      credit: 0,
      balance: statementInitialBalance,
      __isOpeningBalanceRow: true
    };
    return [synthetic, ...results];
  }, [reportIdFromRoute, results, paginationMeta, statementInitialBalance, filterValues, initialDef]);
  if (loadingDef) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
    lineNumber: 833,
    columnNumber: 26
  }, this);
  if (errorDef || !initialDef) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500 p-6 bg-red-50 border border-red-200 rounded m-4", children: "Error cargando definición." }, void 0, false, {
    fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
    lineNumber: 834,
    columnNumber: 39
  }, this);
  const columnsToRender = dynamicMeta?.columns || initialDef.columns_config;
  const titleToRender = dynamicMeta?.title || initialDef.name;
  const descriptionToRender = dynamicMeta?.description || initialDef.description;
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6 min-h-screen relative", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(reportesModuleConfig.baseRoute), className: "p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 845,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 844,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-900 flex items-center gap-2", children: titleToRender }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 848,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 max-w-2xl", children: descriptionToRender }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 849,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 847,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 843,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 842,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-5 rounded-lg border border-gray-200 shadow-sm", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-4 text-sm font-bold text-gray-700 uppercase tracking-wide border-b border-gray-200 pb-2", children: [
        /* @__PURE__ */ jsxDEV(FaFilter, { className: "mr-2 text-indigo-500" }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 856,
          columnNumber: 21
        }, this),
        " Configuración de Filtros"
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 855,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        initialDef.filters && initialDef.filters.length > 0 ? initialDef.filters.sort((a, b) => a.order - b.order).map(
          (filter) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1 ml-1", children: filter.label }, void 0, false, {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 863,
              columnNumber: 33
            }, this),
            renderFilterInput(filter)
          ] }, filter.id, true, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 862,
            columnNumber: 11
          }, this)
        ) : /* @__PURE__ */ jsxDEV("div", { className: "col-span-full text-sm text-gray-400 italic", children: "Sin filtros configurables." }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 868,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end lg:col-start-4", children: /* @__PURE__ */ jsxDEV("button", { onClick: handleInitialRun, disabled: isRunning || !!isExporting, className: "w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-wait transition-all", children: [
          isRunning ? /* @__PURE__ */ jsxDEV(IoSearch, { className: "animate-spin mr-2" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 873,
            columnNumber: 42
          }, this) : /* @__PURE__ */ jsxDEV(IoPlay, { className: "mr-2" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 873,
            columnNumber: 87
          }, this),
          isRunning ? "Procesando..." : "Ejecutar Reporte"
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 872,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 871,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 859,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 854,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-gray-900 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FaTable, { className: "text-gray-400" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 883,
            columnNumber: 25
          }, this),
          "Resultados ",
          hasRun && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs font-normal border border-gray-200", children: [
            paginationMeta?.total || results.length,
            " registros"
          ] }, void 0, true, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 884,
            columnNumber: 47
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 882,
          columnNumber: 21
        }, this),
        renderExportButtons()
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 881,
        columnNumber: 17
      }, this),
      executionError && /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-red-50 text-red-700 border border-red-200 rounded-md mb-4 text-sm", children: executionError }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 889,
        columnNumber: 36
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 min-w-0", children: /* @__PURE__ */ jsxDEV("div", { className: "min-w-full overflow-x-auto border border-gray-200 rounded-t-lg shadow-sm bg-white", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider w-10", children: "#" }, void 0, false, {
            fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
            lineNumber: 896,
            columnNumber: 37
          }, this),
          columnsToRender.map(
            (col, idx) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap", children: col.label }, idx, false, {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 898,
              columnNumber: 19
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 895,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 894,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: !hasRun ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: columnsToRender.length + 1, className: "px-6 py-16 text-center text-gray-500", children: "Esperando ejecución..." }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 904,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 904,
          columnNumber: 17
        }, this) : tableRows.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: columnsToRender.length + 1, className: "px-6 py-12 text-center text-gray-500 bg-gray-50 italic", children: "No se encontraron datos." }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 906,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 906,
          columnNumber: 17
        }, this) : tableRows.map((row, rIdx) => {
          const openingFirstRow = !!(tableRows[0] && tableRows[0].__isOpeningBalanceRow);
          const ordinal = row.__isOpeningBalanceRow ? null : paginationMeta !== null && paginationMeta !== void 0 ? (paginationMeta.current_page - 1) * paginationMeta.per_page + rIdx + (openingFirstRow ? 0 : 1) : rIdx + (openingFirstRow ? 0 : 1);
          return /* @__PURE__ */ jsxDEV(
            "tr",
            {
              className: `hover:bg-blue-50 transition-colors ${row.__isOpeningBalanceRow ? "bg-slate-50" : ""}`,
              children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-4 whitespace-nowrap text-xs text-gray-400 font-mono", children: ordinal != null ? ordinal : "—" }, void 0, false, {
                  fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                  lineNumber: 921,
                  columnNumber: 49
                }, this),
                columnsToRender.map(
                  (col, cIdx) => /* @__PURE__ */ jsxDEV(
                    "td",
                    {
                      className: `px-6 py-4 whitespace-nowrap text-sm border-gray-100 ${reportIdFromRoute === "RPT_STOCK_MOVEMENTS" && col.key === "quantity" ? "text-right" : ""}`,
                      children: renderCell(row, col)
                    },
                    cIdx,
                    false,
                    {
                      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
                      lineNumber: 925,
                      columnNumber: 23
                    },
                    this
                  )
                )
              ]
            },
            row.__isOpeningBalanceRow ? `opening-${reportIdFromRoute}` : `${paginationMeta?.current_page ?? "np"}-${rIdx}-${String(row.transaction_date ?? row.id ?? rIdx)}`,
            true,
            {
              fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
              lineNumber: 917,
              columnNumber: 21
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
          lineNumber: 902,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 893,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 892,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 891,
        columnNumber: 17
      }, this),
      renderPagination(),
      hasRenderableFooter(dynamicMeta) && /* @__PURE__ */ jsxDEV(ReportFooterSection, { footer: dynamicMeta.footer, moneySymbol }, void 0, false, {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 944,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
      lineNumber: 880,
      columnNumber: 13
    }, this),
    isSearchModalOpen && activeSearchFilter && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: true,
        onClose: () => setIsSearchModalOpen(false),
        onSelect: handleSelectFromModal,
        config: (
          // ✅ Para productos, usar articulosModuleConfig directamente (tiene codeField: 'sku' configurado)
          activeSearchFilter.config.resource === "products" ? articulosModuleConfig : {
            endpoint: activeSearchFilter.config.api_endpoint?.split("?")[0] || activeSearchFilter.config.resource,
            moduleName: activeSearchFilter.config.resource,
            moduleNamePlural: activeSearchFilter.config.resource,
            baseRoute: "",
            list: {
              columns: [
                { header: "ID / Código", accessor: activeSearchFilter.config.code_field || activeSearchFilter.config.value_field || "id" },
                { header: "Nombre", accessor: activeSearchFilter.config.label_field || "name" }
              ]
            },
            detail: { displayNameKey: activeSearchFilter.config.label_field || "name" },
            relationalFields: {
              idField: activeSearchFilter.config.value_field || "id",
              nameField: activeSearchFilter.config.label_field || "name",
              codeField: activeSearchFilter.config.code_field || activeSearchFilter.config.value_field || "id"
            },
            form: { block: [] }
          }
        )
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
        lineNumber: 950,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/reportes/pages/ReportesRunnerPage.tsx",
    lineNumber: 841,
    columnNumber: 5
  }, this);
};
_s(ReportesRunnerPage, "flPQw++GbkiAhMSN0UKaCIq2EnA=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ReportesRunnerPage;
var _c;
$RefreshReg$(_c, "ReportesRunnerPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/reportes/pages/ReportesRunnerPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/reportes/pages/ReportesRunnerPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWlCaUQ7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbGlCakQsU0FBU0EsVUFBVUMsV0FBV0MsZUFBZTtBQUM3QyxTQUFTQyxXQUFXQyxhQUFhQyxZQUFZO0FBQzdDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYUMsUUFBUUMsVUFBVUMsZ0JBQWdCQyxlQUFlQyx3QkFBd0I7QUFDL0YsU0FBU0MsVUFBVUMsU0FBU0MsV0FBV0MsV0FBV0MsbUJBQW1CO0FBRXJFLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxRQUFRQyxxQkFBcUJDLHFCQUFxQjtBQUMzRCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QkMsaUNBQWlDO0FBQ25FLFNBQVNDLCtCQUErQjtBQUN4QyxTQUFTQyw0QkFBNEU7QUFDckYsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLDZCQUE2QjtBQUd0QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUFtQjtBQVc1QixNQUFNQyxpQkFBaUJBLENBQUNDLEtBQVVDLFNBQWlCO0FBQy9DLE1BQUksQ0FBQ0QsT0FBTyxDQUFDQyxLQUFNLFFBQU87QUFDMUIsU0FBT0EsS0FBS0MsTUFBTSxHQUFHLEVBQUVDLE9BQU8sQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBT0EsSUFBSUMsSUFBSSxHQUFHTCxHQUFHO0FBQ3RFO0FBR0EsTUFBTU0sZUFBZUEsQ0FBQ0MsWUFBaUI7QUFDbkMsTUFBSTtBQUNBLFFBQUksQ0FBQ0EsUUFBUyxRQUFPO0FBQ3JCLFFBQUksT0FBT0EsWUFBWSxTQUFVLFFBQU9DLEtBQUtDLE1BQU1GLE9BQU87QUFDMUQsV0FBT0E7QUFBQUEsRUFDWCxTQUFTRyxHQUFHO0FBQ1JDLFlBQVFDLE1BQU0seUJBQXlCRixDQUFDO0FBQ3hDLFdBQU87QUFBQSxFQUNYO0FBQ0o7QUFFQSxNQUFNRyw2QkFBNkJBLENBQUNOLFlBQXlEO0FBQ3pGLFFBQU1PLFNBQVNSLGFBQWFDLE9BQU87QUFDbkMsTUFBSSxDQUFDTyxPQUFRLFFBQU87QUFDcEIsUUFBTUMsUUFBUUMsTUFBTUMsUUFBUUgsTUFBTSxJQUFJQSxTQUFTSSxPQUFPQyxPQUFPTCxNQUFNO0FBQ25FLFNBQU9DLE1BQ0ZLO0FBQUFBLElBQ0csQ0FBQ0MsUUFDR0EsUUFBUSxRQUNSLE9BQU9BLFFBQVEsWUFDZixXQUFXQSxPQUNYLFdBQVdBO0FBQUFBLEVBQ25CLEVBQ0NDLElBQUksQ0FBQ0QsU0FBUztBQUFBLElBQ1hFLE9BQU9DLE9BQU9ILElBQUlFLEtBQUs7QUFBQSxJQUN2QkUsT0FBT0QsT0FBT0gsSUFBSUksS0FBSztBQUFBLEVBQzNCLEVBQUU7QUFDVjtBQUVBLE1BQU1DLHVCQUF1QkEsQ0FBQ25CLFlBQThCO0FBQ3hELFFBQU1PLFNBQVNSLGFBQWFDLE9BQU87QUFDbkMsU0FBT08sUUFBUWEsU0FBUyxjQUFjYixRQUFRYyxXQUFXO0FBQzdEO0FBRUEsTUFBTUMsMkJBQTJCQSxDQUFDQyxVQUE4QztBQUM1RSxRQUFNQyxVQUFrQztBQUFBLElBQ3BDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxJQUNmLHVCQUF1QjtBQUFBLElBQ3ZCLGNBQWM7QUFBQSxJQUNkLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLFdBQVdELFFBQVFELEtBQUs7QUFFOUIsTUFBSUUsVUFBVTtBQUVWLFVBQU1DLFlBQVlILFVBQVUsZ0JBQWdCQSxVQUFVO0FBRXRELFdBQU87QUFBQSxNQUNIRTtBQUFBQSxNQUNBRSxhQUFhO0FBQUEsTUFDYkMsYUFBYTtBQUFBLE1BQ2JDLFlBQVlILFlBQVksUUFBUUk7QUFBQUE7QUFBQUEsTUFDaENDLGFBQWE7QUFBQSxNQUNiQyxjQUFjTixZQUFZLGFBQWEsSUFBSUQsUUFBUTtBQUFBO0FBQUEsSUFDdkQ7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNYO0FBR0EsU0FBU1EsbUJBQW1CcEIsUUFBb0M7QUFDNUQsTUFBSUEsT0FBT3FCLGFBQWEsZUFBZXJCLE9BQU9xQixhQUFhLFdBQVc7QUFDbEUsV0FBTyxHQUFHckIsT0FBT1UsS0FBSyxJQUFJVixPQUFPcUIsUUFBUTtBQUFBLEVBQzdDO0FBQ0EsU0FBTyxHQUFHckIsT0FBT1UsS0FBSyxLQUFLVixPQUFPc0IsRUFBRTtBQUN4QztBQUVBLE1BQU1DLHVCQUF1QjtBQUU3QixTQUFTQyxzQkFBc0JDLGNBQWlDO0FBQzVELE1BQUk3QixNQUFNQyxRQUFRNEIsWUFBWSxHQUFHO0FBQzdCLFdBQU9BLGFBQWF2QixJQUFJRSxNQUFNO0FBQUEsRUFDbEM7QUFDQSxNQUFJcUIsaUJBQWlCLE1BQU1BLGlCQUFpQixRQUFRQSxpQkFBaUJSLFFBQVc7QUFDNUUsV0FBTztBQUFBLEVBQ1g7QUFDQSxTQUFPLENBQUNiLE9BQU9xQixZQUFZLENBQUM7QUFDaEM7QUFFQSxTQUFTQyxxQkFBcUJ2QixPQUF5QjtBQUNuRCxNQUFJQSxVQUFVLE1BQU1BLFVBQVUsUUFBUUEsVUFBVWMsUUFBVztBQUN2RCxXQUFPO0FBQUEsRUFDWDtBQUNBLE1BQUlyQixNQUFNQyxRQUFRTSxLQUFLLEdBQUc7QUFDdEIsV0FBT0EsTUFBTXdCLEtBQUssQ0FBQUMsTUFBS0EsTUFBTSxNQUFNQSxNQUFNLFFBQVFBLE1BQU1YLE1BQVM7QUFBQSxFQUNwRTtBQUNBLFNBQU87QUFDWDtBQUVBLFNBQVNZLDhCQUE4QjFDLFNBQTJCO0FBQzlELFFBQU1PLFNBQVNSLGFBQWFDLE9BQU87QUFDbkMsU0FBT08sUUFBUW9DLGFBQWE7QUFDaEM7QUFFQSxTQUFTQyw4QkFDTEMsS0FDQUMsWUFDYTtBQUNiLE1BQUksQ0FBQ0QsS0FBS0UsU0FBU0MsUUFBUTtBQUN2QixXQUFPO0FBQUEsRUFDWDtBQUVBLGFBQVduQyxVQUFVZ0MsSUFBSUUsU0FBUztBQUM5QixRQUFJbEMsT0FBT29DLFNBQVMsWUFBWSxDQUFDUCw4QkFBOEI3QixPQUFPYixPQUFPLEdBQUc7QUFDNUU7QUFBQSxJQUNKO0FBRUEsVUFBTWtELFlBQVlqQixtQkFBbUJwQixNQUFNO0FBQzNDLFVBQU1zQyxXQUFXZCxzQkFBc0JTLFdBQVdJLFNBQVMsQ0FBQztBQUM1RCxRQUFJQyxTQUFTSCxXQUFXLEdBQUc7QUFDdkIsYUFBTyxzQ0FBc0NuQyxPQUFPSyxLQUFLO0FBQUEsSUFDN0Q7QUFBQSxFQUNKO0FBRUEsU0FBTztBQUNYO0FBR0EsU0FBU2tDLHVCQUF1QkMsU0FBMEM7QUFDdEUsUUFBTUMsUUFBa0I7QUFDeEIsYUFBVyxDQUFDQyxLQUFLdkMsS0FBSyxLQUFLTCxPQUFPNkMsUUFBUUgsT0FBTyxHQUFHO0FBQ2hELFFBQUksQ0FBQ2QscUJBQXFCdkIsS0FBSyxHQUFHO0FBQzlCO0FBQUEsSUFDSjtBQUNBLFFBQUlQLE1BQU1DLFFBQVFNLEtBQUssR0FBRztBQUN0QixpQkFBV3lDLFFBQVF6QyxPQUFPO0FBQ3RCLFlBQUl5QyxTQUFTLE1BQU1BLFNBQVMsUUFBUUEsU0FBUzNCLFFBQVc7QUFDcER3QixnQkFBTUksS0FBSyxHQUFHQyxtQkFBbUJKLEdBQUcsQ0FBQyxNQUFNSSxtQkFBbUIxQyxPQUFPd0MsSUFBSSxDQUFDLENBQUMsRUFBRTtBQUFBLFFBQ2pGO0FBQUEsTUFDSjtBQUFBLElBQ0osV0FBVyxPQUFPekMsVUFBVSxXQUFXO0FBQ25Dc0MsWUFBTUksS0FBSyxHQUFHQyxtQkFBbUJKLEdBQUcsQ0FBQyxJQUFJdkMsUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ2hFLE9BQU87QUFDSHNDLFlBQU1JLEtBQUssR0FBR0MsbUJBQW1CSixHQUFHLENBQUMsSUFBSUksbUJBQW1CMUMsT0FBT0QsS0FBSyxDQUFDLENBQUMsRUFBRTtBQUFBLElBQ2hGO0FBQUEsRUFDSjtBQUNBLFNBQU9zQyxNQUFNTSxLQUFLLEdBQUc7QUFDekI7QUFHQSxTQUFTQyxpQ0FBaUNoQixLQUEwQ0MsWUFBeUM7QUFDekgsTUFBSSxDQUFDRCxLQUFLRSxTQUFTQyxPQUFRLFFBQU87QUFDbEMsYUFBV2MsS0FBS2pCLElBQUlFLFNBQVM7QUFDekIsUUFBSWUsRUFBRWIsU0FBUyxVQUFVYSxFQUFFNUIsYUFBYSxhQUFhO0FBQ2pELFlBQU1PLElBQUlLLFdBQVdiLG1CQUFtQjZCLENBQUMsQ0FBQztBQUMxQyxVQUFJckIsTUFBTSxNQUFNQSxNQUFNLFFBQVFBLE1BQU1YLFFBQVc7QUFDM0MsY0FBTWlDLElBQUk5QyxPQUFPd0IsQ0FBQztBQUNsQixlQUFPc0IsRUFBRUMsU0FBUyxHQUFHLElBQUlELEVBQUVwRSxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUlvRTtBQUFBQSxNQUMvQztBQUNBO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1g7QUFFTyxhQUFNRSxxQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUNwQyxRQUFNLEVBQUUvQixHQUFHLElBQUk1RSxVQUEwQjtBQUV6QyxRQUFNNEcsb0JBQW9CaEM7QUFDMUIsUUFBTWlDLFdBQVc1RyxZQUFZO0FBRTdCLFFBQU0sRUFBRWlHLE1BQU1ZLFlBQVlDLFNBQVNDLFlBQVlsRSxPQUFPbUUsU0FBUyxJQUFJbEcsWUFBOEJTLHNCQUFzQm9ELEVBQUU7QUFHekgsUUFBTSxDQUFDc0MsY0FBY0MsZUFBZSxJQUFJdEgsU0FBOEIsQ0FBQyxDQUFDO0FBQ3hFLFFBQU0sQ0FBQ3VILGtCQUFrQkMsbUJBQW1CLElBQUl4SCxTQUFpQyxDQUFDLENBQUM7QUFDbkYsUUFBTSxDQUFDeUgsaUJBQWlCQyxrQkFBa0IsSUFBSTFILFNBQWlDLENBQUMsQ0FBQztBQUVqRixRQUFNLENBQUMySCxTQUFTQyxVQUFVLElBQUk1SCxTQUFnQixFQUFFO0FBR2hELFFBQU0sQ0FBQzZILGdCQUFnQkMsaUJBQWlCLElBQUk5SCxTQU9sQyxJQUFJO0FBRWQsUUFBTSxDQUFDK0gsYUFBYUMsY0FBYyxJQUFJaEksU0FBYyxJQUFJO0FBRXhELFFBQU0sQ0FBQ2lJLHlCQUF5QkMsMEJBQTBCLElBQUlsSSxTQUE2QjBFLE1BQVM7QUFDcEcsUUFBTSxDQUFDeUQsV0FBV0MsWUFBWSxJQUFJcEksU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3FJLGFBQWFDLGNBQWMsSUFBSXRJLFNBQXdCLElBQUk7QUFDbEUsUUFBTSxDQUFDdUksZ0JBQWdCQyxpQkFBaUIsSUFBSXhJLFNBQXdCLElBQUk7QUFDeEUsUUFBTSxDQUFDeUksUUFBUUMsU0FBUyxJQUFJMUksU0FBUyxLQUFLO0FBRzFDLFFBQU0sQ0FBQzJJLG1CQUFtQkMsb0JBQW9CLElBQUk1SSxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDNkksb0JBQW9CQyxxQkFBcUIsSUFBSTlJLFNBRzFDLElBQUk7QUFFZCxRQUFNK0kscUJBQXFCQSxDQUFDNUMsS0FBYXZDLFVBQWU7QUFDcEQwRCxvQkFBZ0IsQ0FBQTBCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUM3QyxHQUFHLEdBQUd2QyxNQUFNLEVBQUU7QUFBQSxFQUN2RDtBQUdBM0QsWUFBVSxNQUFNO0FBQ1osUUFDSSxDQUFDZ0gsWUFBWXRCLFNBQVNDLFVBQ3RCbUIscUJBQXFCLFFBQ3JCbEQsT0FBT29ELFdBQVdnQyxJQUFJLE1BQU1wRixPQUFPa0QsaUJBQWlCLEdBQ3REO0FBQ0U7QUFBQSxJQUNKO0FBQ0EsVUFBTSxFQUFFbUMsV0FBV0MsUUFBUSxJQUFJekgsd0JBQXdCO0FBQ3ZENEYsb0JBQWdCLENBQUEwQixTQUFRO0FBQ3BCLFlBQU1JLFFBQWdDLENBQUM7QUFDdkMsaUJBQVcxQyxLQUFLTyxXQUFXdEIsU0FBUztBQUNoQyxZQUFJZSxFQUFFYixTQUFTLE9BQVE7QUFDdkIsY0FBTUMsWUFBWWpCLG1CQUFtQjZCLENBQUM7QUFDdEMsY0FBTTJDLE1BQU1MLEtBQUtsRCxTQUFTO0FBQzFCLGNBQU13RCxVQUFVRCxRQUFRLE1BQU1BLFFBQVEsUUFBUUEsUUFBUTNFO0FBQ3RELFlBQUksQ0FBQzRFLFFBQVM7QUFDZCxZQUFJNUMsRUFBRTVCLGFBQWEsWUFBYXNFLE9BQU10RCxTQUFTLElBQUlvRDtBQUFBQSxpQkFDMUN4QyxFQUFFNUIsYUFBYSxVQUFXc0UsT0FBTXRELFNBQVMsSUFBSXFEO0FBQUFBLE1BQzFEO0FBQ0EsVUFBSTVGLE9BQU9nRyxLQUFLSCxLQUFLLEVBQUV4RCxXQUFXLEVBQUcsUUFBT29EO0FBQzVDLGFBQU8sRUFBRSxHQUFHQSxNQUFNLEdBQUdJLE1BQU07QUFBQSxJQUMvQixDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUNuQyxZQUFZRixpQkFBaUIsQ0FBQztBQUVsQzlHLFlBQVUsTUFBTTtBQUNaaUksK0JBQTJCeEQsTUFBUztBQUFBLEVBQ3hDLEdBQUcsQ0FBQ3FDLGlCQUFpQixDQUFDO0FBR3RCLFFBQU15QyxtQkFBbUJBLENBQUNDLFdBQW1CN0csWUFBaUM7QUFDMUVrRywwQkFBc0IsRUFBRTNDLEtBQUtzRCxXQUFXQyxRQUFROUcsUUFBUSxDQUFDO0FBQ3pEZ0cseUJBQXFCLElBQUk7QUFBQSxFQUM3QjtBQUVBLFFBQU1lLHdCQUF3QkEsQ0FBQ3RELFNBQWM7QUFDekMsUUFBSSxDQUFDd0MsbUJBQW9CO0FBRXpCLFVBQU0sRUFBRTFDLEtBQUt1RCxPQUFPLElBQUliO0FBRXhCLFVBQU1lLGNBQWN2RDtBQUNwQixVQUFNd0QsV0FBV0gsT0FBT2xGLGVBQWU7QUFDdkMsVUFBTXNGLFdBQVdKLE9BQU9uRixlQUFlO0FBQ3ZDLFVBQU13RixXQUFXTCxPQUFPakYsY0FBY2lGLE9BQU9sRixlQUFlO0FBRTVEdUUsdUJBQW1CNUMsS0FBS3lELFlBQVlDLFFBQVEsQ0FBQztBQUU3Q3JDLHdCQUFvQixDQUFBd0IsVUFBUztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzdDLEdBQUcsR0FBR3lELFlBQVlFLFFBQVE7QUFBQSxJQUMvQixFQUFFO0FBRUZwQyx1QkFBbUIsQ0FBQXNCLFVBQVM7QUFBQSxNQUN4QixHQUFHQTtBQUFBQSxNQUNILENBQUM3QyxHQUFHLEdBQUd5RCxZQUFZRyxRQUFRO0FBQUEsSUFDL0IsRUFBRTtBQUVGbkIseUJBQXFCLEtBQUs7QUFDMUJFLDBCQUFzQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNa0IsOEJBQThCQSxDQUFDN0QsS0FBYThELGFBQXFCO0FBQ25FdkMsdUJBQW1CLENBQUFzQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDN0MsR0FBRyxHQUFHOEQsU0FBUyxFQUFFO0FBQUEsRUFDN0Q7QUFHQSxRQUFNQywyQkFBMkJBLENBQUMvRCxLQUFhRSxNQUFXcUQsV0FBZ0M7QUFFdEYsVUFBTUcsV0FBV0gsT0FBT2xGLGVBQWU7QUFDdkMsVUFBTXNGLFdBQVdKLE9BQU9uRixlQUFlO0FBQ3ZDLFVBQU13RixXQUFXTCxPQUFPakYsY0FBY2lGLE9BQU9sRixlQUFlO0FBRTVEdUUsdUJBQW1CNUMsS0FBS0UsS0FBS3dELFFBQVEsQ0FBQztBQUV0Q3JDLHdCQUFvQixDQUFBd0IsVUFBUztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzdDLEdBQUcsR0FBR0UsS0FBS3lELFFBQVE7QUFBQSxJQUN4QixFQUFFO0FBRUZwQyx1QkFBbUIsQ0FBQXNCLFVBQVM7QUFBQSxNQUN4QixHQUFHQTtBQUFBQSxNQUNILENBQUM3QyxHQUFHLEdBQUdFLEtBQUswRCxRQUFRO0FBQUEsSUFDeEIsRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNSSxtQkFBbUIsT0FBT1YsV0FBbUJSLE1BQWNyRyxZQUFpQztBQUM5RixRQUFJLENBQUNxRyxNQUFNO0FBQ1BGLHlCQUFtQlUsV0FBVyxFQUFFO0FBQ2hDakMsMEJBQW9CLENBQUF3QixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDUyxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQzFEL0IseUJBQW1CLENBQUFzQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDUyxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQ3pEO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFDQSxZQUFNVyxjQUFjeEgsUUFBUWdDLGNBQWNyQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUssSUFBSUssUUFBUXlCLFFBQVE7QUFDL0UsWUFBTWdHLGNBQWN6SCxRQUFRNkIsY0FBYzdCLFFBQVE0QixlQUFlO0FBRWpFLFlBQU04RixTQUFTLE1BQU1qSixjQUFjK0ksYUFBYSxDQUFDLEVBQUVHLFdBQVdGLGFBQWF6RyxPQUFPcUYsS0FBSyxDQUFDLENBQUM7QUFFekYsVUFBSXFCLFFBQVE7QUFDUixjQUFNVCxXQUFXakgsUUFBUTRCLGVBQWU7QUFDeEMsY0FBTXNGLFdBQVdsSCxRQUFRMkIsZUFBZTtBQUN4QyxjQUFNd0YsV0FBV25ILFFBQVE2QixjQUFjN0IsUUFBUTRCLGVBQWU7QUFFOUQsY0FBTWdHLFlBQVlGO0FBRWxCdkIsMkJBQW1CVSxXQUFXZSxVQUFVWCxRQUFRLENBQUM7QUFDakRyQyw0QkFBb0IsQ0FBQXdCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNTLFNBQVMsR0FBR2UsVUFBVVYsUUFBUSxFQUFFLEVBQUU7QUFDM0VwQywyQkFBbUIsQ0FBQXNCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNTLFNBQVMsR0FBR2UsVUFBVVQsUUFBUSxFQUFFLEVBQUU7QUFBQSxNQUM5RSxPQUFPO0FBQ0h6SixjQUFNbUssS0FBSyxlQUFlO0FBQzFCMUIsMkJBQW1CVSxXQUFXLEVBQUU7QUFDaENqQyw0QkFBb0IsQ0FBQXdCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNTLFNBQVMsR0FBRyxHQUFHLEVBQUU7QUFBQSxNQUM5RDtBQUFBLElBQ0osU0FBU3hHLE9BQU87QUFDWkQsY0FBUUMsTUFBTUEsS0FBSztBQUNuQjNDLFlBQU0yQyxNQUFNLGlCQUFpQjtBQUFBLElBQ2pDO0FBQUEsRUFDSjtBQUdBLFFBQU15SCxxQkFBcUJBLE1BQU07QUFDN0IsUUFBSSxDQUFDekQsV0FBWSxRQUFPLENBQUM7QUFDekIsVUFBTWhCLFVBQStCLENBQUM7QUFFdENnQixlQUFXdEIsUUFBUWdGLFFBQVEsQ0FBQWxILFdBQVU7QUFDakMsWUFBTXFDLFlBQVlqQixtQkFBbUJwQixNQUFNO0FBQzNDLFlBQU1HLFFBQVF5RCxhQUFhdkIsU0FBUztBQUdwQyxVQUFJckMsT0FBT29DLFNBQVMsWUFBWTtBQUM1QixZQUFJakMsVUFBVSxNQUFNO0FBQ2hCcUMsa0JBQVF4QyxPQUFPVSxLQUFLLElBQUk7QUFBQSxRQUM1QjtBQUNBO0FBQUEsTUFDSjtBQUVBLFVBQUlWLE9BQU9vQyxTQUFTLFVBQVU7QUFDMUIsWUFBSTlCLHFCQUFxQk4sT0FBT2IsT0FBTyxHQUFHO0FBQ3RDLGdCQUFNZ0ksU0FBUyxPQUFPaEgsVUFBVSxXQUMxQkEsUUFDQ1AsTUFBTUMsUUFBUU0sS0FBSyxJQUFLQSxNQUFNLENBQUMsS0FBSyxLQUFNO0FBQ2pELGNBQUlnSCxXQUFXLElBQUk7QUFDZjNFLG9CQUFReEMsT0FBT1UsS0FBSyxJQUFJeUc7QUFBQUEsVUFDNUI7QUFDQTtBQUFBLFFBQ0o7QUFFQSxjQUFNN0UsV0FBV2Qsc0JBQXNCckIsS0FBSztBQUM1QyxZQUFJbUMsU0FBU0gsU0FBUyxHQUFHO0FBQ3JCSyxrQkFBUXhDLE9BQU9VLEtBQUssSUFBSTRCO0FBQUFBLFFBQzVCO0FBQ0E7QUFBQSxNQUNKO0FBR0EsVUFBSVoscUJBQXFCdkIsS0FBSyxHQUFHO0FBQzdCLFlBQUlILE9BQU9xQixhQUFhLFlBQWFtQixTQUFRLEdBQUd4QyxPQUFPVSxLQUFLLE9BQU8sSUFBSVA7QUFBQUEsaUJBQzlESCxPQUFPcUIsYUFBYSxVQUFXbUIsU0FBUSxHQUFHeEMsT0FBT1UsS0FBSyxLQUFLLElBQUlQO0FBQUFBO0FBQ25FcUMsa0JBQVF4QyxPQUFPVSxLQUFLLElBQUlQO0FBQUFBLE1BQ2pDO0FBQUEsSUFDSixDQUFDO0FBQ0QsV0FBT3FDO0FBQUFBLEVBQ1g7QUFHQSxRQUFNNEUsa0JBQWtCLE9BQU9DLGFBQWEsTUFBTTtBQUM5QyxRQUFJLENBQUM3RCxXQUFZO0FBRWpCLFVBQU04RCxrQkFBa0J2Riw4QkFBOEJ5QixZQUFZSSxZQUFZO0FBQzlFLFFBQUkwRCxpQkFBaUI7QUFDakJ6SyxZQUFNbUssS0FBS00sZUFBZTtBQUMxQjtBQUFBLElBQ0o7QUFFQTNDLGlCQUFhLElBQUk7QUFDakJJLHNCQUFrQixJQUFJO0FBQ3RCRSxjQUFVLElBQUk7QUFFZCxRQUFJb0MsZUFBZSxHQUFHO0FBQ2xCbEQsaUJBQVcsRUFBRTtBQUNiSSxxQkFBZSxJQUFJO0FBQ25CRix3QkFBa0IsSUFBSTtBQUN0QkksaUNBQTJCeEQsTUFBUztBQUFBLElBQ3hDO0FBRUEsUUFBSTtBQUNBLFlBQU1zRyxXQUFXLEdBQUdySixxQkFBcUJxSixRQUFRLElBQUlqRyxFQUFFO0FBRXZELFlBQU1rQixVQUFVO0FBQUEsUUFDWixHQUFHeUUsbUJBQW1CO0FBQUEsUUFDdEJPLE1BQU1IO0FBQUFBLE1BQ1Y7QUFFQSxZQUFNSSxXQUFXLE1BQU0vSixPQUFZNkosVUFBVS9FLE9BQU87QUFDcEQsWUFBTWtGLGNBQWNEO0FBRXBCLFVBQUlFLE9BQWM7QUFFbEIsVUFBSUQsWUFBWUUsUUFBUWhJLE1BQU1DLFFBQVE2SCxZQUFZRSxLQUFLQSxJQUFJLEdBQUc7QUFDMUQsY0FBTUMsUUFBUUgsWUFBWUU7QUFDMUJELGVBQU9FLE1BQU1EO0FBQ2J2RCwwQkFBa0I7QUFBQSxVQUNkeUQsY0FBY0QsTUFBTUM7QUFBQUEsVUFDcEJDLFdBQVdGLE1BQU1FO0FBQUFBLFVBQ2pCQyxPQUFPSCxNQUFNRztBQUFBQSxVQUNiQyxNQUFNSixNQUFNSTtBQUFBQSxVQUNaQyxJQUFJTCxNQUFNSztBQUFBQSxVQUNWQyxVQUFVTixNQUFNTTtBQUFBQSxRQUNwQixDQUFDO0FBQ0QsWUFBSS9ILE9BQU9rRCxpQkFBaUIsTUFBTS9CLHdCQUF3QixxQkFBcUJzRyxTQUFTQSxNQUFNTyxvQkFBb0IsUUFBUVAsTUFBTU8sb0JBQW9CbkgsUUFBVztBQUMzSixnQkFBTW9ILElBQUlDLE9BQU9ULE1BQU1PLGVBQWU7QUFDdEMsY0FBSSxDQUFDRSxPQUFPQyxNQUFNRixDQUFDLEVBQUc1RCw0QkFBMkI0RCxDQUFDO0FBQUEsUUFDdEQ7QUFBQSxNQUNKLFdBQVd6SSxNQUFNQyxRQUFRNkgsWUFBWUUsSUFBSSxHQUFHO0FBQ3hDRCxlQUFPRCxZQUFZRTtBQUNuQnZELDBCQUFrQixJQUFJO0FBQUEsTUFDMUIsV0FBV3pFLE1BQU1DLFFBQVE2SCxXQUFXLEdBQUc7QUFDbkNDLGVBQU9EO0FBQ1ByRCwwQkFBa0IsSUFBSTtBQUFBLE1BQzFCO0FBRUEsVUFBSXFELFlBQVljLE1BQU07QUFDbEJqRSx1QkFBZW1ELFlBQVljLElBQUk7QUFBQSxNQUNuQztBQUVBckUsaUJBQVd3RCxJQUFJO0FBRWYsWUFBTWMsc0JBQ0ZySSxPQUFPa0QsaUJBQWlCLE1BQU0vQix3QkFDOUI4RixlQUFlLEtBQ2ZLLFlBQVlFLFFBQ1osT0FBT0YsWUFBWUUsU0FBUyxZQUM1QixDQUFDaEksTUFBTUMsUUFBUTZILFlBQVlFLElBQUksS0FDL0IscUJBQXFCRixZQUFZRSxRQUNqQ0YsWUFBWUUsS0FBS1Esb0JBQW9CLFFBQ3JDVixZQUFZRSxLQUFLUSxvQkFBb0JuSCxVQUNyQyxDQUFDcUgsT0FBT0MsTUFBTUQsT0FBT1osWUFBWUUsS0FBS1EsZUFBZSxDQUFDO0FBRTFELFVBQUlULEtBQUt4RixXQUFXLEtBQUtrRixlQUFlLEtBQUssQ0FBQ29CLHFCQUFxQjtBQUMvRDVMLGNBQU02TCxLQUFLLGtDQUFrQztBQUFBLE1BQ2pELFdBQVdyQixlQUFlLEdBQUc7QUFDekJ4SyxjQUFNOEwsUUFBUSw2QkFBNkI7QUFBQSxNQUMvQztBQUFBLElBRUosU0FBU0MsS0FBVTtBQUNmckosY0FBUUMsTUFBTW9KLEdBQUc7QUFDakI3RCx3QkFBa0IsK0JBQStCO0FBQ2pEbEksWUFBTTJDLE1BQU0sMkJBQTJCO0FBQUEsSUFDM0MsVUFBQztBQUNHbUYsbUJBQWEsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDSjtBQUVBLFFBQU1rRSxtQkFBbUJBLE1BQU16QixnQkFBZ0IsQ0FBQztBQUVoRCxRQUFNMEIsbUJBQW1CQSxDQUFDQyxZQUFvQjtBQUMxQyxRQUFJQSxXQUFXLE1BQU0sQ0FBQzNFLGtCQUFrQjJFLFdBQVczRSxlQUFlMkQsWUFBWTtBQUMxRVgsc0JBQWdCMkIsT0FBTztBQUFBLElBQzNCO0FBQUEsRUFDSjtBQUdBLFFBQU1DLGVBQWUsT0FBT0MsV0FBbUI7QUFDM0MsUUFBSSxDQUFDekYsV0FBWTtBQUVqQixVQUFNOEQsa0JBQWtCdkYsOEJBQThCeUIsWUFBWUksWUFBWTtBQUM5RSxRQUFJMEQsaUJBQWlCO0FBQ2pCekssWUFBTW1LLEtBQUtNLGVBQWU7QUFDMUI7QUFBQSxJQUNKO0FBRUF6QyxtQkFBZW9FLE1BQU07QUFDckIsUUFBSTtBQUNBLFlBQU16RyxVQUFVeUUsbUJBQW1CO0FBQ25DLFlBQU1pQyxjQUFjM0csdUJBQXVCQyxPQUFPO0FBQ2xELFlBQU0rRSxXQUFXLEdBQUdySixxQkFBcUJxSixRQUFRLElBQUlqRyxFQUFFLFFBQVEySCxNQUFNLElBQUlDLFdBQVc7QUFFcEYsWUFBTSxFQUFFQyxNQUFNQyxTQUFTLElBQUksTUFBTXpMLG9CQUFvQjRKLFFBQVE7QUFDN0QsWUFBTThCLGVBQWUsR0FBRzdGLFdBQVdnQyxJQUFJLEtBQUksb0JBQUk4RCxLQUFLLEdBQUVDLFlBQVksRUFBRXpLLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJbUssTUFBTTtBQUMzRnBMLG1CQUFhc0wsTUFBTUMsYUFBYSxrQkFBa0JDLGVBQWVELFFBQVE7QUFDekV2TSxZQUFNOEwsUUFBUSxXQUFXTSxPQUFPTyxZQUFZLENBQUMsWUFBWTtBQUFBLElBQzdELFNBQVNoSyxPQUFPO0FBQ1pELGNBQVFDLE1BQU0sU0FBU3lKLE1BQU0sS0FBS3pKLEtBQUs7QUFDdkMzQyxZQUFNMkMsTUFBTSxxQkFBcUJ5SixPQUFPTyxZQUFZLENBQUMsR0FBRztBQUFBLElBQzVELFVBQUM7QUFDRzNFLHFCQUFlLElBQUk7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFJQSxRQUFNNEUsc0JBQXNCQSxNQUFNO0FBQzlCLFFBQUksQ0FBQ3pFLE9BQVEsUUFBTztBQUNwQixVQUFNMEUsVUFBb0JwRixhQUFhcUYscUJBQXFCbkcsWUFBWW1HLHFCQUFxQixDQUFDLEtBQUs7QUFDbkcsV0FDSSx1QkFBQyxTQUFJLFdBQVUsa0JBQ1ZEO0FBQUFBLGNBQVF2RyxTQUFTLEtBQUssS0FDbkIsdUJBQUMsWUFBTyxTQUFTLE1BQU02RixhQUFhLEtBQUssR0FBRyxVQUFVLENBQUMsQ0FBQ3BFLGFBQWEsV0FBVSwrSEFDMUVBO0FBQUFBLHdCQUFnQixRQUFRLHVCQUFDLGtCQUFlLFdBQVUsa0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0MsSUFBTSx1QkFBQyxhQUFVLFdBQVUsVUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFFBQUk7QUFBQSxXQUQxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdIOEUsUUFBUXZHLFNBQVMsTUFBTSxLQUNwQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csU0FBUyxNQUFNNkYsYUFBYSxNQUFNO0FBQUEsVUFDbEMsVUFBVSxDQUFDLENBQUNwRTtBQUFBQSxVQUNaLFdBQVU7QUFBQSxVQUVUQTtBQUFBQSw0QkFBZ0IsU0FBUyx1QkFBQyxrQkFBZSxXQUFVLGtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QyxJQUFNLHVCQUFDLGVBQVksV0FBVSxVQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFMNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUVIOEUsUUFBUXZHLFNBQVMsS0FBSyxLQUNuQix1QkFBQyxZQUFPLFNBQVMsTUFBTTZGLGFBQWEsS0FBSyxHQUFHLFVBQVUsQ0FBQyxDQUFDcEUsYUFBYSxXQUFVLHVKQUMxRUE7QUFBQUEsd0JBQWdCLFFBQVEsdUJBQUMsa0JBQWUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QyxJQUFNLHVCQUFDLGFBQVUsV0FBVSx3QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQUk7QUFBQSxXQUR4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVIOEUsUUFBUTFKLE9BQU8sQ0FBQWlELE1BQUssQ0FBQyxDQUFDLE9BQU8sT0FBTyxRQUFRLE1BQU0sRUFBRUUsU0FBU0YsQ0FBQyxDQUFDLEVBQUUvQztBQUFBQSxRQUFJLENBQUErQyxNQUNsRSx1QkFBQyxZQUFlLFNBQVMsTUFBTStGLGFBQWEvRixDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMyQixhQUFhLFdBQVUsNklBQy9FO0FBQUEsaUNBQUMsa0JBQWUsV0FBVSxVQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUc7QUFBQSxVQUFFM0I7QUFBQUEsYUFENUJBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFDSDtBQUFBLFNBMUJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxFQUVSO0FBRUEsUUFBTTJHLG1CQUFtQkEsTUFBTTtBQUMzQixRQUFJLENBQUN4RixrQkFBa0JBLGVBQWUyRCxhQUFhLEVBQUcsUUFBTztBQUU3RCxXQUNJLHVCQUFDLFNBQUksV0FBVSx5RkFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxTQUFTLE1BQU1lLGlCQUFpQjFFLGVBQWUwRCxlQUFlLENBQUM7QUFBQSxZQUMvRCxVQUFVMUQsZUFBZTBELGlCQUFpQjtBQUFBLFlBQzFDLFdBQVU7QUFBQSxZQUErSjtBQUFBO0FBQUEsVUFIN0s7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxTQUFTLE1BQU1nQixpQkFBaUIxRSxlQUFlMEQsZUFBZSxDQUFDO0FBQUEsWUFDL0QsVUFBVTFELGVBQWUwRCxpQkFBaUIxRCxlQUFlMkQ7QUFBQUEsWUFDekQsV0FBVTtBQUFBLFlBQW9LO0FBQUE7QUFBQSxVQUhsTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ1g7QUFBQSwrQkFBQyxTQUNHLGlDQUFDLE9BQUUsV0FBVSx5QkFBdUI7QUFBQTtBQUFBLFVBQ3RCLHVCQUFDLFVBQUssV0FBVSxlQUFlM0QseUJBQWU2RCxRQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQU87QUFBQSxVQUFHLHVCQUFDLFVBQUssV0FBVSxlQUFlN0QseUJBQWU4RCxNQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQU87QUFBQSxVQUFJLHVCQUFDLFVBQUssV0FBVSxlQUFlOUQseUJBQWU0RCxTQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQU87QUFBQSxhQURsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0csaUNBQUMsU0FBSSxXQUFVLGdEQUErQyxjQUFXLGNBQ3JFO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFNBQVMsTUFBTWMsaUJBQWlCMUUsZUFBZTBELGVBQWUsQ0FBQztBQUFBLGNBQy9ELFVBQVUxRCxlQUFlMEQsaUJBQWlCO0FBQUEsY0FDMUMsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDbEMsdUJBQUMsaUJBQWMsV0FBVSxXQUFVLGVBQVksVUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQTtBQUFBO0FBQUEsWUFOekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSwwSUFBd0k7QUFBQTtBQUFBLFlBQzVJMUQsZUFBZTBEO0FBQUFBLFlBQWE7QUFBQSxZQUFLMUQsZUFBZTJEO0FBQUFBLGVBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFTLE1BQU1lLGlCQUFpQjFFLGVBQWUwRCxlQUFlLENBQUM7QUFBQSxjQUMvRCxVQUFVMUQsZUFBZTBELGlCQUFpQjFELGVBQWUyRDtBQUFBQSxjQUN6RCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBVSxXQUFVLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyxvQkFBaUIsV0FBVSxXQUFVLGVBQVksVUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQTtBQUFBO0FBQUEsWUFONUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBLEtBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsU0E5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStDQTtBQUFBLEVBRVI7QUFFQSxRQUFNOEIsb0JBQW9CQSxDQUFDN0osV0FBK0I7QUFDdEQsVUFBTThKLGdCQUFnQjtBQUN0QixVQUFNekgsWUFBWWpCLG1CQUFtQnBCLE1BQU07QUFDM0MsVUFBTStKLFdBQVduRyxhQUFhdkIsU0FBUztBQUN2QyxVQUFNWixlQUFlc0ksWUFBWTtBQUVqQyxRQUFJL0osT0FBT29DLFNBQVMsZ0JBQWdCO0FBQ2hDLFVBQUk0SCxZQUFZaEssT0FBT2IsVUFBVUQsYUFBYWMsT0FBT2IsT0FBTyxJQUFJO0FBQ2hFLFVBQUksQ0FBQzZLLFVBQVdBLGFBQVl2Six5QkFBeUJULE9BQU9VLEtBQUs7QUFFakUsVUFBSXNKLFdBQVc7QUFFWCxjQUFNQyxrQkFBa0JELFVBQVVwSixhQUFhO0FBRS9DLGVBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVdvRCxnQkFBZ0IzQixTQUFTLEtBQUs7QUFBQSxZQUN6QyxXQUFXeUIsaUJBQWlCekIsU0FBUyxLQUFLO0FBQUEsWUFDMUMsY0FBYyxDQUFDNkgsUUFBUTNELDRCQUE0QmxFLFdBQVc2SCxHQUFHO0FBQUEsWUFDakUsY0FBYyxNQUFNeEQsaUJBQWlCckUsV0FBVzJCLGdCQUFnQjNCLFNBQVMsR0FBRzJILFNBQVU7QUFBQSxZQUN0RixlQUFlLE1BQU1qRSxpQkFBaUIxRCxXQUFXMkgsU0FBVTtBQUFBLFlBQzNELGNBQWMsTUFBTTtBQUNoQjFFLGlDQUFtQmpELFdBQVcsRUFBRTtBQUNoQzBCLGtDQUFvQixDQUFBd0IsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2xELFNBQVMsR0FBRyxHQUFHLEVBQUU7QUFDMUQ0QixpQ0FBbUIsQ0FBQXNCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNsRCxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQUEsWUFDN0Q7QUFBQSxZQUdBLE1BQU00SCxrQkFBa0IsUUFBUWhKO0FBQUFBLFlBQ2hDLG9CQUFvQmdKO0FBQUFBLFlBQ3BCLG9CQUFvQkEsa0JBQWtCO0FBQUEsY0FDbEMxQyxVQUFVaEosc0JBQXNCZ0o7QUFBQUEsY0FDaEM0QyxXQUFXO0FBQUEsY0FDWEMsV0FBVztBQUFBLGNBQ1hDLFVBQVVBLENBQUN6SCxTQUFTNkQseUJBQXlCcEUsV0FBV08sTUFBTW9ILFNBQVU7QUFBQSxZQUM1RSxJQUFJL0k7QUFBQUE7QUFBQUEsVUFwQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JrQjtBQUFBLE1BRzFCO0FBQUEsSUFDSjtBQUVBLFlBQVFqQixPQUFPb0MsTUFBSTtBQUFBLE1BQ2YsS0FBSztBQUNELGVBQU8sdUJBQUMsV0FBTSxNQUFLLFFBQU8sY0FBYSxPQUFNLFdBQVcwSCxlQUFlLE9BQU9ySSxjQUFjLFVBQVUsQ0FBQ25DLE1BQU1nRyxtQkFBbUJqRCxXQUFXL0MsRUFBRWdMLE9BQU9uSyxLQUFLLEtBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0o7QUFBQSxNQUMvSixLQUFLLFVBQVU7QUFDWCxjQUFNb0ssb0JBQW9COUssMkJBQTJCTyxPQUFPYixPQUFPO0FBRW5FLFlBQUltQixxQkFBcUJOLE9BQU9iLE9BQU8sR0FBRztBQUN0QyxnQkFBTXFMLGNBQWMsT0FBTy9JLGlCQUFpQixXQUN0Q0EsZUFDQzdCLE1BQU1DLFFBQVE0QixZQUFZLElBQUtBLGFBQWEsQ0FBQyxLQUFLLEtBQU07QUFDL0QsaUJBQ0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVdxSTtBQUFBQSxjQUNYLE9BQU9VO0FBQUFBLGNBQ1AsVUFBVSxDQUFDbEwsTUFBTWdHLG1CQUFtQmpELFdBQVcvQyxFQUFFZ0wsT0FBT25LLEtBQUs7QUFBQSxjQUU1RG9LLDRCQUFrQnJLO0FBQUFBLGdCQUFJLENBQUNELFFBQ3BCLHVCQUFDLFlBQXNDLE9BQU9BLElBQUlFLE9BQzdDRixjQUFJSSxTQURJSixJQUFJRSxTQUFTLGFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQSxZQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsUUFFUjtBQUVBLGNBQU1zSyxlQUFldkwsYUFBYWMsT0FBT2IsT0FBTyxLQUFLO0FBQ3JELGNBQU1tRCxXQUFXZCxzQkFBc0J1SSxRQUFRO0FBQy9DLGNBQU1XLGtCQUFrQjlLLE1BQU1DLFFBQVE0SyxZQUFZLElBQzVDQSxhQUNHekssT0FBTyxDQUFDQyxRQUFpQkEsUUFBUSxRQUFRLE9BQU9BLFFBQVEsWUFBWSxXQUFZQSxPQUFrQixXQUFZQSxHQUFjLEVBQzVIQyxJQUFJLENBQUNELFNBQW9EO0FBQUEsVUFDdERFLE9BQU9DLE9BQU9ILElBQUlFLEtBQUs7QUFBQSxVQUN2QkUsT0FBT0osSUFBSUk7QUFBQUEsUUFDZixFQUFFLElBQ0prSztBQUNOLGVBQ0k7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFNBQVNHO0FBQUFBLFlBQ1Q7QUFBQSxZQUNBLFVBQVUsQ0FBQzNLLFdBQVd1RixtQkFBbUJqRCxXQUFXdEMsTUFBTTtBQUFBLFlBQzFELGFBQVk7QUFBQTtBQUFBLFVBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl1QjtBQUFBLE1BRy9CO0FBQUEsTUFDQSxLQUFLO0FBQ0QsZUFDSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBVytKO0FBQUFBLFlBQ1gsYUFBYTlKLE9BQU9LO0FBQUFBLFlBQ3BCLE9BQU9vQixpQkFBaUIsTUFBTUEsZ0JBQWdCLE9BQU8sT0FBTzZHLE9BQU83RyxZQUFZLEtBQUs7QUFBQSxZQUNwRjtBQUFBLFlBQ0EsV0FBVztBQUFBLFlBQ1gsVUFBVSxDQUFBa0osUUFBT3JGLG1CQUFtQmpELFdBQVdzSSxPQUFPLEVBQUU7QUFBQTtBQUFBLFVBTjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU04RDtBQUFBO0FBQUEsTUFLdEUsS0FBSztBQUNELGVBQ0ksdUJBQUMsU0FBSSxXQUFVLCtCQUNYO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLElBQUksVUFBVXRJLFNBQVM7QUFBQSxjQUN2QixNQUFLO0FBQUEsY0FDTCxjQUFhO0FBQUEsY0FBTSxXQUFVO0FBQUEsY0FDN0IsU0FBUyxDQUFDLENBQUNaO0FBQUFBLGNBQ1gsVUFBVSxDQUFDbkMsTUFBTWdHLG1CQUFtQmpELFdBQVcvQyxFQUFFZ0wsT0FBT00sT0FBTztBQUFBO0FBQUEsWUFMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FFO0FBQUEsVUFFckUsdUJBQUMsV0FBTSxTQUFTLFVBQVV2SSxTQUFTLElBQUksV0FBVSxpRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsTUFHUjtBQUNJLGVBQU8sdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxpQ0FBQyxXQUFNLE1BQUssUUFBTyxjQUFhLE9BQU0sV0FBV3lILGVBQWUsYUFBWSxhQUFZLE9BQU9ySSxjQUFjLFVBQVUsQ0FBQ25DLE1BQU1nRyxtQkFBbUJqRCxXQUFXL0MsRUFBRWdMLE9BQU9uSyxLQUFLLEtBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEssS0FBM047QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4TjtBQUFBLElBQzdPO0FBQUEsRUFDSjtBQUVBLFFBQU0wSyxjQUFldkcsYUFBYXdHLDRCQUMxQnhHLGFBQWF5RywwQkFBMEIsUUFBUSxDQUFDekcsYUFBYXlHLHdCQUF3QixNQUFNO0FBRW5HLFFBQU1DLGFBQWFBLENBQUNDLEtBQVVDLGNBQW1CO0FBQzdDLFVBQU1uQixXQUFXcEwsZUFBZXNNLEtBQUtDLFVBQVV4SSxHQUFHO0FBQ2xELFFBQUlxSCxhQUFhLFFBQVFBLGFBQWE5SSxPQUFXLFFBQU8sdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixpQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUVqRyxRQUFJcUMsc0JBQXNCLHlCQUF5QjRILFVBQVV4SSxRQUFRLFlBQVk7QUFDN0UsWUFBTXlJLGVBQWVwTix3QkFBd0JZLGVBQWVzTSxLQUFLLGVBQWUsQ0FBQztBQUNqRixhQUFPak4sMEJBQTBCbU4sZ0JBQWdCbEssUUFBVzhJLFFBQVE7QUFBQSxJQUN4RTtBQUVBLFlBQVFtQixVQUFVOUksTUFBSTtBQUFBLE1BQ2xCLEtBQUssU0FBUztBQUNWLGNBQU11SSxNQUFNckMsT0FBT3lCLFFBQVE7QUFDM0IsY0FBTXFCLGFBQWEsQ0FBQzlDLE9BQU9DLE1BQU1vQyxHQUFHLEtBQUtBLE1BQU07QUFDL0MsZUFDSSx1QkFBQyxVQUFLLFdBQVcsYUFBYVMsYUFBYSxpQkFBaUIsZUFBZSxJQUN0RXROLHNCQUFZaU0sVUFBVSxZQUFZLEVBQUVjLFlBQVksQ0FBQyxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVSO0FBQUEsTUFDQSxLQUFLO0FBQVEsZUFBTyx1QkFBQyxVQUFNL00sc0JBQVlpTSxVQUFVLE1BQU0sS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLE1BQ3pELEtBQUs7QUFBVSxlQUFPLHVCQUFDLFVBQUssV0FBVSw4QkFBOEJqTSxzQkFBWWlNLFVBQVUsUUFBUSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsTUFDcEcsS0FBSztBQUFTLGVBQU8sdUJBQUMsVUFBSyxXQUFVLHFHQUFxRzNKLGlCQUFPMkosUUFBUSxLQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNJO0FBQUEsTUFDM0osS0FBSyxRQUFRO0FBQ1QsY0FBTXNCLFNBQVNILFVBQVVJLGNBQWMzTSxlQUFlc00sS0FBS0MsVUFBVUksV0FBVyxJQUFJO0FBQ3BGLGNBQU1qTCxRQUFRRCxPQUFPMkosUUFBUTtBQUM3QixZQUFJLENBQUNzQixVQUFVLENBQUNILFVBQVVLLFdBQVc7QUFDakMsaUJBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmxMLG1CQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFFBQ2xEO0FBQ0EsY0FBTXhCLE9BQU9xTSxVQUFVSyxVQUFVQyxRQUFRLE9BQU9wTCxPQUFPaUwsTUFBTSxDQUFDO0FBQzlELGVBQ0ksdUJBQUMsUUFBSyxJQUFJeE0sTUFBTSxXQUFVLHlEQUNyQndCLG1CQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRVI7QUFBQSxNQUNBO0FBQVMsZUFBTyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCRCxpQkFBTzJKLFFBQVEsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLElBQ3RFO0FBQUEsRUFDSjtBQUdBLFFBQU0wQixZQUFZaFAsUUFBUSxNQUFhO0FBQ25DLFFBQUkyRCxPQUFPa0QsaUJBQWlCLE1BQU0vQixxQkFBc0IsUUFBTzJDO0FBRS9ELFVBQU13SCxVQUFVdEgsa0JBQWtCLFFBQVFBLGVBQWUwRCxpQkFBaUI7QUFDMUUsVUFBTTZELE9BQU9uSCw0QkFBNEJ2RCxVQUFhcUgsT0FBT3NELFNBQVNwSCx1QkFBdUI7QUFDN0YsUUFBSSxDQUFDa0gsV0FBVyxDQUFDQyxLQUFNLFFBQU96SDtBQUU5QixVQUFNMkgsV0FBVzdJLGlDQUFpQ1EsY0FBYyxNQUFNSSxZQUFZO0FBQ2xGLFVBQU1rSSxZQUFZO0FBQUEsTUFDZEMsa0JBQWtCRixXQUFXQSxXQUFXO0FBQUEsTUFDeENHLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxNQUNSQyxTQUFTNUg7QUFBQUEsTUFDVDZILHVCQUF1QjtBQUFBLElBQzNCO0FBRUEsV0FBTyxDQUFDUCxXQUFXLEdBQUc1SCxPQUFPO0FBQUEsRUFDakMsR0FBRyxDQUFDWixtQkFBbUJZLFNBQVNFLGdCQUFnQkkseUJBQXlCWixjQUFjSixVQUFVLENBQUM7QUFFbEcsTUFBSUUsV0FBWSxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUN0QyxNQUFJQyxZQUFZLENBQUNILFdBQVksUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0VBQStELDBDQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdHO0FBRTVJLFFBQU04SSxrQkFBa0JoSSxhQUFhaUksV0FBVy9JLFdBQVdnSjtBQUMzRCxRQUFNQyxnQkFBZ0JuSSxhQUFhb0ksU0FBU2xKLFdBQVdtSjtBQUN2RCxRQUFNQyxzQkFBc0J0SSxhQUFhdUksZUFBZXJKLFdBQVdxSjtBQUVuRSxTQUNJLHVCQUFDLFNBQUksV0FBVSw0RUFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRkFDWCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSw2QkFBQyxZQUFPLFNBQVMsTUFBTXRKLFNBQVNyRixxQkFBcUI0TyxTQUFTLEdBQUcsV0FBVSxzRUFDdkUsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDREQUE0REwsMkJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxRQUN4Rix1QkFBQyxPQUFFLFdBQVUsbUNBQW1DRyxpQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0hBQ1g7QUFBQSwrQkFBQyxZQUFTLFdBQVUsMEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUFHO0FBQUEsV0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1ZwSjtBQUFBQSxtQkFBV3RCLFdBQVdzQixXQUFXdEIsUUFBUUMsU0FBUyxJQUMvQ3FCLFdBQVd0QixRQUFRNkssS0FBSyxDQUFDQyxHQUFHQyxNQUFNRCxFQUFFRSxRQUFRRCxFQUFFQyxLQUFLLEVBQUVoTjtBQUFBQSxVQUFJLENBQUFGLFdBQ3JELHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNkRBQTZEQSxpQkFBT0ssU0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkY7QUFBQSxZQUMxRndKLGtCQUFrQjdKLE1BQU07QUFBQSxlQUZuQkEsT0FBT3NCLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxRQUNILElBRUQsdUJBQUMsU0FBSSxXQUFVLDhDQUE2QywwQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRjtBQUFBLFFBRzFGLHVCQUFDLFNBQUksV0FBVSxpQ0FDWCxpQ0FBQyxZQUFPLFNBQVN1SCxrQkFBa0IsVUFBVW5FLGFBQWEsQ0FBQyxDQUFDRSxhQUFhLFdBQVUsNk5BQzlFRjtBQUFBQSxzQkFBWSx1QkFBQyxZQUFTLFdBQVUsdUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDLElBQU0sdUJBQUMsVUFBTyxXQUFVLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFDakZBLFlBQVksa0JBQWtCO0FBQUEsYUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLFNBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDJEQUNWO0FBQUEsaUNBQUMsV0FBUSxXQUFVLG1CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBO0FBQUEsVUFDdEJNLFVBQVUsdUJBQUMsVUFBSyxXQUFVLHNHQUFzR1o7QUFBQUEsNEJBQWdCNEQsU0FBUzlELFFBQVEvQjtBQUFBQSxZQUFPO0FBQUEsZUFBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0s7QUFBQSxhQUZsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDc0gsb0JBQW9CO0FBQUEsV0FMekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQzNFLGtCQUFrQix1QkFBQyxTQUFJLFdBQVUsNEVBQTRFQSw0QkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRztBQUFBLE1BRTdILHVCQUFDLFNBQUksV0FBVSw0QkFDWCxpQ0FBQyxTQUFJLFdBQVUscUZBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsT0FBTSxPQUFNLFdBQVUsdUZBQXNGLGlCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpSDtBQUFBLFVBQ2hId0gsZ0JBQWdCcE07QUFBQUEsWUFBSSxDQUFDaU4sS0FBVUMsUUFDNUIsdUJBQUMsUUFBYSxPQUFNLE9BQU0sV0FBVSxrR0FBa0dELGNBQUk5TSxTQUFqSStNLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0o7QUFBQSxVQUNuSjtBQUFBLGFBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1osV0FBQ3BJLFNBQ0UsdUJBQUMsUUFBRyxpQ0FBQyxRQUFHLFNBQVNzSCxnQkFBZ0JuSyxTQUFTLEdBQUcsV0FBVSx3Q0FBdUMsc0NBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0gsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SCxJQUN6SHNKLFVBQVV0SixXQUFXLElBQ3JCLHVCQUFDLFFBQUcsaUNBQUMsUUFBRyxTQUFTbUssZ0JBQWdCbkssU0FBUyxHQUFHLFdBQVUsMERBQXlELHdDQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9JLEtBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkksSUFFN0lzSixVQUFVdkwsSUFBSSxDQUFDK0ssS0FBVW9DLFNBQWlCO0FBQ3RDLGdCQUFNQyxrQkFBa0IsQ0FBQyxFQUFFN0IsVUFBVSxDQUFDLEtBQUtBLFVBQVUsQ0FBQyxFQUFFWTtBQUN4RCxnQkFBTWtCLFVBQVV0QyxJQUFJb0Isd0JBQ2QsT0FDQWpJLG1CQUFtQixRQUFRQSxtQkFBbUJuRCxVQUN6Q21ELGVBQWUwRCxlQUFlLEtBQUsxRCxlQUFlK0QsV0FBV2tGLFFBQVFDLGtCQUFrQixJQUFJLEtBQzVGRCxRQUFRQyxrQkFBa0IsSUFBSTtBQUV4QyxpQkFDSTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsV0FBVyxzQ0FBc0NyQyxJQUFJb0Isd0JBQXdCLGdCQUFnQixFQUFFO0FBQUEsY0FFL0Y7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0RBQ1RrQixxQkFBVyxPQUFPQSxVQUFVLE9BRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ2pCLGdCQUFnQnBNO0FBQUFBLGtCQUFJLENBQUNpTixLQUFVSyxTQUM1QjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFRyxXQUFXLHVEQUF1RGxLLHNCQUFzQix5QkFBeUI2SixJQUFJekssUUFBUSxhQUFhLGVBQWUsRUFBRTtBQUFBLHNCQUUxSnNJLHFCQUFXQyxLQUFLa0MsR0FBRztBQUFBO0FBQUEsb0JBSGZLO0FBQUFBLG9CQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFDSDtBQUFBO0FBQUE7QUFBQSxZQWJJdkMsSUFBSW9CLHdCQUF3QixXQUFXL0ksaUJBQWlCLEtBQUssR0FBR2MsZ0JBQWdCMEQsZ0JBQWdCLElBQUksSUFBSXVGLElBQUksSUFBSWpOLE9BQU82SyxJQUFJYyxvQkFBb0JkLElBQUkzSixNQUFNK0wsSUFBSSxDQUFDO0FBQUEsWUFEdks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWVBO0FBQUEsUUFFUixDQUFDLEtBaENUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxXQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBLEtBN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0EsS0EvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdEQTtBQUFBLE1BRUN6RCxpQkFBaUI7QUFBQSxNQUVqQnpMLG9CQUFvQm1HLFdBQVcsS0FDNUIsdUJBQUMsdUJBQW9CLFFBQVFBLFlBQVltSixRQUFRLGVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEU7QUFBQSxTQWhFbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1FQTtBQUFBLElBRUN2SSxxQkFBcUJFLHNCQUNsQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUTtBQUFBLFFBQ1IsU0FBUyxNQUFNRCxxQkFBcUIsS0FBSztBQUFBLFFBQ3pDLFVBQVVlO0FBQUFBLFFBQ1Y7QUFBQTtBQUFBLFVBRUlkLG1CQUFtQmEsT0FBT3JGLGFBQWEsYUFDakNyQyx3QkFDQztBQUFBLFlBQ0NnSixVQUFVbkMsbUJBQW1CYSxPQUFPOUUsY0FBY3JDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBS3NHLG1CQUFtQmEsT0FBT3JGO0FBQUFBLFlBQzdGOE0sWUFBWXRJLG1CQUFtQmEsT0FBT3JGO0FBQUFBLFlBQ3RDK00sa0JBQWtCdkksbUJBQW1CYSxPQUFPckY7QUFBQUEsWUFDNUNrTSxXQUFXO0FBQUEsWUFDWGMsTUFBTTtBQUFBLGNBQ0ZyQixTQUFTO0FBQUEsZ0JBQ0wsRUFBRXNCLFFBQVEsZUFBZUMsVUFBVTFJLG1CQUFtQmEsT0FBT2pGLGNBQWNvRSxtQkFBbUJhLE9BQU9sRixlQUFlLEtBQUs7QUFBQSxnQkFDekgsRUFBRThNLFFBQVEsVUFBVUMsVUFBVTFJLG1CQUFtQmEsT0FBT25GLGVBQWUsT0FBTztBQUFBLGNBQUM7QUFBQSxZQUV2RjtBQUFBLFlBQ0FpTixRQUFRLEVBQUVDLGdCQUFnQjVJLG1CQUFtQmEsT0FBT25GLGVBQWUsT0FBTztBQUFBLFlBQzFFbU4sa0JBQWtCO0FBQUEsY0FDZEMsU0FBUzlJLG1CQUFtQmEsT0FBT2xGLGVBQWU7QUFBQSxjQUNsRHFKLFdBQVdoRixtQkFBbUJhLE9BQU9uRixlQUFlO0FBQUEsY0FDcERxSixXQUFXL0UsbUJBQW1CYSxPQUFPakYsY0FBY29FLG1CQUFtQmEsT0FBT2xGLGVBQWU7QUFBQSxZQUNoRztBQUFBLFlBQ0FvTixNQUFNLEVBQUVDLE9BQU8sR0FBRztBQUFBLFVBQ3RCO0FBQUE7QUFBQTtBQUFBLE1BMUJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTJCSztBQUFBLE9BeEliO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EySUE7QUFFUjtBQUFFL0ssR0F2dkJXRCxvQkFBa0I7QUFBQSxVQUNaMUcsV0FHRUMsYUFFa0RjLFdBQVc7QUFBQTtBQUFBNFEsS0FOckVqTDtBQUFrQixJQUFBaUw7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiTGluayIsInRvYXN0IiwiSW9BcnJvd0JhY2siLCJJb1BsYXkiLCJJb1NlYXJjaCIsIklvRG9jdW1lbnRUZXh0IiwiSW9DaGV2cm9uQmFjayIsIklvQ2hldnJvbkZvcndhcmQiLCJGYUZpbHRlciIsIkZhVGFibGUiLCJGYUZpbGVQZGYiLCJGYUZpbGVBbHQiLCJGYUZpbGVFeGNlbCIsInVzZUNydWRJdGVtIiwiZ2V0QWxsIiwiZ2V0RmlsZUJsb2JXaXRoTWV0YSIsInNlYXJjaEJ5RmllbGQiLCJkb3dubG9hZEJsb2IiLCJmb3JtYXRWYWx1ZSIsInBhcnNlTW92ZW1lbnRDb2RlUHJlZml4IiwicmVuZGVyU2lnbmVkU3RvY2tRdWFudGl0eSIsImdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIiwicmVwb3J0ZXNNb2R1bGVDb25maWciLCJoYXNSZW5kZXJhYmxlRm9vdGVyIiwiUmVwb3J0Rm9vdGVyU2VjdGlvbiIsIk11bHRpU2VsZWN0RHJvcGRvd24iLCJMb2FkaW5nU3Bpbm5lciIsImFydGljdWxvc01vZHVsZUNvbmZpZyIsIlJlbGF0aW9uYWxJbnB1dCIsIkRlY2ltYWxJbnB1dCIsIlNlYXJjaE1vZGFsIiwiZ2V0TmVzdGVkVmFsdWUiLCJvYmoiLCJwYXRoIiwic3BsaXQiLCJyZWR1Y2UiLCJhY2MiLCJwYXJ0IiwicGFyc2VPcHRpb25zIiwib3B0aW9ucyIsIkpTT04iLCJwYXJzZSIsImUiLCJjb25zb2xlIiwiZXJyb3IiLCJnZXRWYWx1ZUxhYmVsU2VsZWN0T3B0aW9ucyIsInBhcnNlZCIsIml0ZW1zIiwiQXJyYXkiLCJpc0FycmF5IiwiT2JqZWN0IiwidmFsdWVzIiwiZmlsdGVyIiwib3B0IiwibWFwIiwidmFsdWUiLCJTdHJpbmciLCJsYWJlbCIsImlzU2luZ2xlU2VsZWN0RmlsdGVyIiwibW9kZSIsInNpbmdsZSIsImluZmVyUmVsYXRpb25zaGlwT3B0aW9ucyIsImZpZWxkIiwibWFwcGluZyIsInJlc291cmNlIiwiaXNQcm9kdWN0IiwibGFiZWxfZmllbGQiLCJ2YWx1ZV9maWVsZCIsImNvZGVfZmllbGQiLCJ1bmRlZmluZWQiLCJwbGFjZWhvbGRlciIsImFwaV9lbmRwb2ludCIsImdldFJlcG9ydEZpbHRlcktleSIsIm9wZXJhdG9yIiwiaWQiLCJSUFRfQ1VTVE9NRVJfQUNDT1VOVCIsImdldFNlbGVjdEZpbHRlclZhbHVlcyIsImN1cnJlbnRWYWx1ZSIsImZpbHRlclZhbHVlSXNQcmVzZW50Iiwic29tZSIsInYiLCJmaWx0ZXJPcHRpb25zUmVxdWlyZVNlbGVjdGlvbiIsInJlcXVpcmVkIiwidmFsaWRhdGVSZXF1aXJlZFJlcG9ydEZpbHRlcnMiLCJkZWYiLCJmaWx0ZXJWYWxzIiwiZmlsdGVycyIsImxlbmd0aCIsInR5cGUiLCJ1bmlxdWVLZXkiLCJzZWxlY3RlZCIsImJ1aWxkUmVwb3J0UXVlcnlTdHJpbmciLCJwYXlsb2FkIiwicGFydHMiLCJrZXkiLCJlbnRyaWVzIiwiaXRlbSIsInB1c2giLCJlbmNvZGVVUklDb21wb25lbnQiLCJqb2luIiwiZ2V0T3BlbmluZ0JhbGFuY2VEYXRlRnJvbUZpbHRlcnMiLCJmIiwicyIsImluY2x1ZGVzIiwiUmVwb3J0ZXNSdW5uZXJQYWdlIiwiX3MiLCJyZXBvcnRJZEZyb21Sb3V0ZSIsIm5hdmlnYXRlIiwiaW5pdGlhbERlZiIsImxvYWRpbmciLCJsb2FkaW5nRGVmIiwiZXJyb3JEZWYiLCJmaWx0ZXJWYWx1ZXMiLCJzZXRGaWx0ZXJWYWx1ZXMiLCJyZWxhdGlvbmFsTGFiZWxzIiwic2V0UmVsYXRpb25hbExhYmVscyIsInJlbGF0aW9uYWxDb2RlcyIsInNldFJlbGF0aW9uYWxDb2RlcyIsInJlc3VsdHMiLCJzZXRSZXN1bHRzIiwicGFnaW5hdGlvbk1ldGEiLCJzZXRQYWdpbmF0aW9uTWV0YSIsImR5bmFtaWNNZXRhIiwic2V0RHluYW1pY01ldGEiLCJzdGF0ZW1lbnRJbml0aWFsQmFsYW5jZSIsInNldFN0YXRlbWVudEluaXRpYWxCYWxhbmNlIiwiaXNSdW5uaW5nIiwic2V0SXNSdW5uaW5nIiwiaXNFeHBvcnRpbmciLCJzZXRJc0V4cG9ydGluZyIsImV4ZWN1dGlvbkVycm9yIiwic2V0RXhlY3V0aW9uRXJyb3IiLCJoYXNSdW4iLCJzZXRIYXNSdW4iLCJpc1NlYXJjaE1vZGFsT3BlbiIsInNldElzU2VhcmNoTW9kYWxPcGVuIiwiYWN0aXZlU2VhcmNoRmlsdGVyIiwic2V0QWN0aXZlU2VhcmNoRmlsdGVyIiwiaGFuZGxlRmlsdGVyQ2hhbmdlIiwicHJldiIsImNvZGUiLCJzdGFydERhdGUiLCJlbmREYXRlIiwicGF0Y2giLCJjdXIiLCJpc0VtcHR5Iiwia2V5cyIsImhhbmRsZU9wZW5TZWFyY2giLCJmaWx0ZXJLZXkiLCJjb25maWciLCJoYW5kbGVTZWxlY3RGcm9tTW9kYWwiLCJzZWxlY3RlZFJvdyIsInZhbEZpZWxkIiwibGFiRmllbGQiLCJjb2RGaWVsZCIsImhhbmRsZVJlbGF0aW9uYWxJbnB1dENoYW5nZSIsIm5ld1ZhbHVlIiwiaGFuZGxlQXV0b2NvbXBsZXRlU2VsZWN0IiwiaGFuZGxlQ29kZVN1Ym1pdCIsImVuZHBvaW50VXJsIiwic2VhcmNoRmllbGQiLCJyZXN1bHQiLCJmaWVsZE5hbWUiLCJmb3VuZEl0ZW0iLCJ3YXJuIiwiYnVpbGRGaWx0ZXJQYXlsb2FkIiwiZm9yRWFjaCIsInNjYWxhciIsImhhbmRsZVJ1blJlcG9ydCIsInBhZ2VOdW1iZXIiLCJ2YWxpZGF0aW9uRXJyb3IiLCJlbmRwb2ludCIsInBhZ2UiLCJyZXNwb25zZSIsInJhd1Jlc3BvbnNlIiwicm93cyIsImRhdGEiLCJwYWdlciIsImN1cnJlbnRfcGFnZSIsImxhc3RfcGFnZSIsInRvdGFsIiwiZnJvbSIsInRvIiwicGVyX3BhZ2UiLCJpbml0aWFsX2JhbGFuY2UiLCJuIiwiTnVtYmVyIiwiaXNOYU4iLCJtZXRhIiwiaGFzT3BlbmluZ0JhbGFuY2VVaSIsImluZm8iLCJzdWNjZXNzIiwiZXJyIiwiaGFuZGxlSW5pdGlhbFJ1biIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJuZXdQYWdlIiwiaGFuZGxlRXhwb3J0IiwiZm9ybWF0IiwicXVlcnlTdHJpbmciLCJibG9iIiwiZmlsZW5hbWUiLCJmYWxsYmFja05hbWUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJ0b1VwcGVyQ2FzZSIsInJlbmRlckV4cG9ydEJ1dHRvbnMiLCJmb3JtYXRzIiwiYXZhaWxhYmxlX2Zvcm1hdHMiLCJyZW5kZXJQYWdpbmF0aW9uIiwicmVuZGVyRmlsdGVySW5wdXQiLCJjb21tb25DbGFzc2VzIiwicmF3VmFsdWUiLCJyZWxDb25maWciLCJpc1Byb2R1Y3RGaWx0ZXIiLCJ2YWwiLCJjb2RlRmllbGQiLCJuYW1lRmllbGQiLCJvblNlbGVjdCIsInRhcmdldCIsInZhbHVlTGFiZWxPcHRpb25zIiwic2NhbGFyVmFsdWUiLCJvcHRpb25zQXJyYXkiLCJkcm9wZG93bk9wdGlvbnMiLCJudW0iLCJjaGVja2VkIiwibW9uZXlTeW1ib2wiLCJkaXNwbGF5X2N1cnJlbmN5X3N5bWJvbCIsImRpc3BsYXlfY3VycmVuY3lfY29kZSIsInJlbmRlckNlbGwiLCJyb3ciLCJjb2xDb25maWciLCJjb2RlRm9yU3R5bGUiLCJpc05lZ2F0aXZlIiwibGlua0lkIiwibGlua19pZF9rZXkiLCJsaW5rX3BhdGgiLCJyZXBsYWNlIiwidGFibGVSb3dzIiwicGFnZU9uZSIsImliT2siLCJpc0Zpbml0ZSIsImRhdGVGcm9tIiwic3ludGhldGljIiwidHJhbnNhY3Rpb25fZGF0ZSIsImRvY3VtZW50X3R5cGUiLCJkb2N1bWVudF9udW1iZXIiLCJkZWJpdCIsImNyZWRpdCIsImJhbGFuY2UiLCJfX2lzT3BlbmluZ0JhbGFuY2VSb3ciLCJjb2x1bW5zVG9SZW5kZXIiLCJjb2x1bW5zIiwiY29sdW1uc19jb25maWciLCJ0aXRsZVRvUmVuZGVyIiwidGl0bGUiLCJuYW1lIiwiZGVzY3JpcHRpb25Ub1JlbmRlciIsImRlc2NyaXB0aW9uIiwiYmFzZVJvdXRlIiwic29ydCIsImEiLCJiIiwib3JkZXIiLCJjb2wiLCJpZHgiLCJySWR4Iiwib3BlbmluZ0ZpcnN0Um93Iiwib3JkaW5hbCIsImNJZHgiLCJmb290ZXIiLCJtb2R1bGVOYW1lIiwibW9kdWxlTmFtZVBsdXJhbCIsImxpc3QiLCJoZWFkZXIiLCJhY2Nlc3NvciIsImRldGFpbCIsImRpc3BsYXlOYW1lS2V5IiwicmVsYXRpb25hbEZpZWxkcyIsImlkRmllbGQiLCJmb3JtIiwiYmxvY2siLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZXBvcnRlc1J1bm5lclBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IElvQXJyb3dCYWNrLCBJb1BsYXksIElvU2VhcmNoLCBJb0RvY3VtZW50VGV4dCwgSW9DaGV2cm9uQmFjaywgSW9DaGV2cm9uRm9yd2FyZCB9IGZyb20gJ3JlYWN0LWljb25zL2lvNSc7XG5pbXBvcnQgeyBGYUZpbHRlciwgRmFUYWJsZSwgRmFGaWxlUGRmLCBGYUZpbGVBbHQsIEZhRmlsZUV4Y2VsIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuXG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEFsbCwgZ2V0RmlsZUJsb2JXaXRoTWV0YSwgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHsgZG93bmxvYWRCbG9iIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvYmxvYkhlbHBlcic7XG5pbXBvcnQgeyBmb3JtYXRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgcGFyc2VNb3ZlbWVudENvZGVQcmVmaXgsIHJlbmRlclNpZ25lZFN0b2NrUXVhbnRpdHkgfSBmcm9tICcuLi8uLi8uLi91dGlscy9zdG9ja01vdmVtZW50UXVhbnRpdHknO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0RGF0ZVJhbmdlJztcbmltcG9ydCB7IHJlcG9ydGVzTW9kdWxlQ29uZmlnLCB0eXBlIFJlcG9ydERlZmluaXRpb24sIHR5cGUgUmVwb3J0RmlsdGVyQ29uZmlnIH0gZnJvbSAnLi4vcmVwb3J0ZXMuY29uZmlnJztcbmltcG9ydCB7IGhhc1JlbmRlcmFibGVGb290ZXIgfSBmcm9tICcuLi9yZXBvcnRGb290ZXIudHlwZXMnO1xuaW1wb3J0IHsgUmVwb3J0Rm9vdGVyU2VjdGlvbiB9IGZyb20gJy4uL1JlcG9ydEZvb3RlclNlY3Rpb24nO1xuaW1wb3J0IHsgTXVsdGlTZWxlY3REcm9wZG93biB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL011bHRpU2VsZWN0RHJvcGRvd24nO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IGFydGljdWxvc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL2FydGljdWxvcy9hcnRpY3Vsb3MuY29uZmlnJzsgLy8g4pyFIEFncmVnYXIgaW1wb3J0XG5cbi8vIENvbXBvbmVudGVzIFJlbGFjaW9uYWxlc1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcblxuaW50ZXJmYWNlIFJlbGF0aW9uc2hpcE9wdGlvbnMge1xuICAgIHJlc291cmNlOiBzdHJpbmc7XG4gICAgbGFiZWxfZmllbGQ6IHN0cmluZztcbiAgICB2YWx1ZV9maWVsZDogc3RyaW5nO1xuICAgIGNvZGVfZmllbGQ/OiBzdHJpbmc7XG4gICAgcGxhY2Vob2xkZXI/OiBzdHJpbmc7XG4gICAgYXBpX2VuZHBvaW50Pzogc3RyaW5nO1xufVxuXG5jb25zdCBnZXROZXN0ZWRWYWx1ZSA9IChvYmo6IGFueSwgcGF0aDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFvYmogfHwgIXBhdGgpIHJldHVybiBudWxsO1xuICAgIHJldHVybiBwYXRoLnNwbGl0KCcuJykucmVkdWNlKChhY2MsIHBhcnQpID0+IGFjYyAmJiBhY2NbcGFydF0sIG9iaik7XG59O1xuXG4vLyBIZWxwZXIgc2VndXJvIHBhcmEgcGFyc2VhciBvcGNpb25lcyBKU09OXG5jb25zdCBwYXJzZU9wdGlvbnMgPSAob3B0aW9uczogYW55KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgaWYgKCFvcHRpb25zKSByZXR1cm4gbnVsbDtcbiAgICAgICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnc3RyaW5nJykgcmV0dXJuIEpTT04ucGFyc2Uob3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBvcHRpb25zO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHBhcnNpbmcgb3B0aW9uc1wiLCBlKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufTtcblxuY29uc3QgZ2V0VmFsdWVMYWJlbFNlbGVjdE9wdGlvbnMgPSAob3B0aW9uczogdW5rbm93bik6IHsgdmFsdWU6IHN0cmluZzsgbGFiZWw6IHN0cmluZyB9W10gPT4ge1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlT3B0aW9ucyhvcHRpb25zKTtcbiAgICBpZiAoIXBhcnNlZCkgcmV0dXJuIFtdO1xuICAgIGNvbnN0IGl0ZW1zID0gQXJyYXkuaXNBcnJheShwYXJzZWQpID8gcGFyc2VkIDogT2JqZWN0LnZhbHVlcyhwYXJzZWQpO1xuICAgIHJldHVybiBpdGVtc1xuICAgICAgICAuZmlsdGVyKFxuICAgICAgICAgICAgKG9wdCk6IG9wdCBpcyB7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7IGxhYmVsOiBzdHJpbmcgfSA9PlxuICAgICAgICAgICAgICAgIG9wdCAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBvcHQgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAgICAgJ3ZhbHVlJyBpbiBvcHQgJiZcbiAgICAgICAgICAgICAgICAnbGFiZWwnIGluIG9wdFxuICAgICAgICApXG4gICAgICAgIC5tYXAoKG9wdCkgPT4gKHtcbiAgICAgICAgICAgIHZhbHVlOiBTdHJpbmcob3B0LnZhbHVlKSxcbiAgICAgICAgICAgIGxhYmVsOiBTdHJpbmcob3B0LmxhYmVsKSxcbiAgICAgICAgfSkpO1xufTtcblxuY29uc3QgaXNTaW5nbGVTZWxlY3RGaWx0ZXIgPSAob3B0aW9uczogdW5rbm93bik6IGJvb2xlYW4gPT4ge1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlT3B0aW9ucyhvcHRpb25zKTtcbiAgICByZXR1cm4gcGFyc2VkPy5tb2RlID09PSAnZ3JvdXBfYnknIHx8IHBhcnNlZD8uc2luZ2xlID09PSB0cnVlO1xufTtcblxuY29uc3QgaW5mZXJSZWxhdGlvbnNoaXBPcHRpb25zID0gKGZpZWxkOiBzdHJpbmcpOiBSZWxhdGlvbnNoaXBPcHRpb25zIHwgbnVsbCA9PiB7XG4gICAgY29uc3QgbWFwcGluZzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICAgICAgJ2NsaWVudF9pZCc6ICdjbGllbnRzJyxcbiAgICAgICAgJ2N1c3RvbWVyX2lkJzogJ2NsaWVudHMnLFxuICAgICAgICAnc2FsZXNwZXJzb25faWQnOiAnc2FsZXNwZW9wbGUnLFxuICAgICAgICAndmVuZG9yX2lkJzogJ3ZlbmRvcnMnLFxuICAgICAgICAnc3VwcGxpZXJfaWQnOiAnc3VwcGxpZXJzJyxcbiAgICAgICAgJ3RyYW5zcG9ydF9pZCc6ICd0cmFuc3BvcnRzJyxcbiAgICAgICAgJ2N1cnJlbmN5X2lkJzogJ2N1cnJlbmNpZXMnLFxuICAgICAgICAnZGlzcGxheV9jdXJyZW5jeV9pZCc6ICdjdXJyZW5jaWVzJyxcbiAgICAgICAgJ3Byb2R1Y3RfaWQnOiAncHJvZHVjdHMnLFxuICAgICAgICAnYXJ0aWNsZV9pZCc6ICdwcm9kdWN0cycsXG4gICAgICAgICdidXllcl9pZCc6ICdidXllcnMnLFxuICAgIH07XG5cbiAgICBjb25zdCByZXNvdXJjZSA9IG1hcHBpbmdbZmllbGRdO1xuXG4gICAgaWYgKHJlc291cmNlKSB7XG4gICAgICAgIC8vIOKchSBDb25maWd1cmFjacOzbiBlc3BlY2lhbCBwYXJhIHByb2R1Y3RvcyAodXNhciAnc2t1JyBjb21vIGNvZGVfZmllbGQpXG4gICAgICAgIGNvbnN0IGlzUHJvZHVjdCA9IGZpZWxkID09PSAncHJvZHVjdF9pZCcgfHwgZmllbGQgPT09ICdhcnRpY2xlX2lkJztcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzb3VyY2U6IHJlc291cmNlLFxuICAgICAgICAgICAgbGFiZWxfZmllbGQ6ICduYW1lJyxcbiAgICAgICAgICAgIHZhbHVlX2ZpZWxkOiAnaWQnLFxuICAgICAgICAgICAgY29kZV9maWVsZDogaXNQcm9kdWN0ID8gJ3NrdScgOiB1bmRlZmluZWQsIC8vIOKchSBBZ3JlZ2FyIGNvZGVfZmllbGQgcGFyYSBwcm9kdWN0b3NcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBgQnVzY2FyLi4uYCxcbiAgICAgICAgICAgIGFwaV9lbmRwb2ludDogaXNQcm9kdWN0ID8gJ3Byb2R1Y3RzJyA6IGAvJHtyZXNvdXJjZX1gIC8vIOKchSBQYXJhIHByb2R1Y3RvcywgdXNhciAncHJvZHVjdHMnIHNpbiBiYXJyYSBpbmljaWFsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufTtcblxuLyoqIENsYXZlIGVzdGFibGUgcGFyYSBjYWRhIGZpbHRybyBkZSByZXBvcnRlIChtaXNtYSByZWdsYSBlbiBlZmVjdG9zIHkgcmVuZGVyKS4gKi9cbmZ1bmN0aW9uIGdldFJlcG9ydEZpbHRlcktleShmaWx0ZXI6IFJlcG9ydEZpbHRlckNvbmZpZyk6IHN0cmluZyB7XG4gICAgaWYgKGZpbHRlci5vcGVyYXRvciA9PT0gJ2RhdGVfZnJvbScgfHwgZmlsdGVyLm9wZXJhdG9yID09PSAnZGF0ZV90bycpIHtcbiAgICAgICAgcmV0dXJuIGAke2ZpbHRlci5maWVsZH1fJHtmaWx0ZXIub3BlcmF0b3J9YDtcbiAgICB9XG4gICAgcmV0dXJuIGAke2ZpbHRlci5maWVsZH1fXyR7ZmlsdGVyLmlkfWA7XG59XG5cbmNvbnN0IFJQVF9DVVNUT01FUl9BQ0NPVU5UID0gJ1JQVF9DVVNUT01FUl9BQ0NPVU5UJztcblxuZnVuY3Rpb24gZ2V0U2VsZWN0RmlsdGVyVmFsdWVzKGN1cnJlbnRWYWx1ZTogdW5rbm93bik6IHN0cmluZ1tdIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBjdXJyZW50VmFsdWUubWFwKFN0cmluZyk7XG4gICAgfVxuICAgIGlmIChjdXJyZW50VmFsdWUgPT09ICcnIHx8IGN1cnJlbnRWYWx1ZSA9PT0gbnVsbCB8fCBjdXJyZW50VmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIHJldHVybiBbU3RyaW5nKGN1cnJlbnRWYWx1ZSldO1xufVxuXG5mdW5jdGlvbiBmaWx0ZXJWYWx1ZUlzUHJlc2VudCh2YWx1ZTogdW5rbm93bik6IGJvb2xlYW4ge1xuICAgIGlmICh2YWx1ZSA9PT0gJycgfHwgdmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdmFsdWUuc29tZSh2ID0+IHYgIT09ICcnICYmIHYgIT09IG51bGwgJiYgdiAhPT0gdW5kZWZpbmVkKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59XG5cbmZ1bmN0aW9uIGZpbHRlck9wdGlvbnNSZXF1aXJlU2VsZWN0aW9uKG9wdGlvbnM6IHVua25vd24pOiBib29sZWFuIHtcbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZU9wdGlvbnMob3B0aW9ucyk7XG4gICAgcmV0dXJuIHBhcnNlZD8ucmVxdWlyZWQgPT09IHRydWU7XG59XG5cbmZ1bmN0aW9uIHZhbGlkYXRlUmVxdWlyZWRSZXBvcnRGaWx0ZXJzKFxuICAgIGRlZjogUmVwb3J0RGVmaW5pdGlvbiB8IG51bGwgfCB1bmRlZmluZWQsXG4gICAgZmlsdGVyVmFsczogUmVjb3JkPHN0cmluZywgYW55PlxuKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgaWYgKCFkZWY/LmZpbHRlcnM/Lmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBkZWYuZmlsdGVycykge1xuICAgICAgICBpZiAoZmlsdGVyLnR5cGUgIT09ICdzZWxlY3QnIHx8ICFmaWx0ZXJPcHRpb25zUmVxdWlyZVNlbGVjdGlvbihmaWx0ZXIub3B0aW9ucykpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdW5pcXVlS2V5ID0gZ2V0UmVwb3J0RmlsdGVyS2V5KGZpbHRlcik7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkID0gZ2V0U2VsZWN0RmlsdGVyVmFsdWVzKGZpbHRlclZhbHNbdW5pcXVlS2V5XSk7XG4gICAgICAgIGlmIChzZWxlY3RlZC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBgU2VsZWNjaW9uZSBhbCBtZW5vcyB1biB2YWxvciBwYXJhIFwiJHtmaWx0ZXIubGFiZWx9XCIuYDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xufVxuXG4vKiogU2VyaWFsaXphIHF1ZXJ5IHBhcmFtcyBjb24gc29wb3J0ZSBkZSBhcnJheXMgKHAuIGVqLiBsaW5lW109MSZsaW5lW109MikgcGFyYSBleHBvcnRhY2lvbmVzLiAqL1xuZnVuY3Rpb24gYnVpbGRSZXBvcnRRdWVyeVN0cmluZyhwYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZyB7XG4gICAgY29uc3QgcGFydHM6IHN0cmluZ1tdID0gW107XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMocGF5bG9hZCkpIHtcbiAgICAgICAgaWYgKCFmaWx0ZXJWYWx1ZUlzUHJlc2VudCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZW0gIT09ICcnICYmIGl0ZW0gIT09IG51bGwgJiYgaXRlbSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHBhcnRzLnB1c2goYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9W109JHtlbmNvZGVVUklDb21wb25lbnQoU3RyaW5nKGl0ZW0pKX1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgIHBhcnRzLnB1c2goYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PSR7dmFsdWUgPyAnMScgOiAnMCd9YCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwYXJ0cy5wdXNoKGAke2VuY29kZVVSSUNvbXBvbmVudChrZXkpfT0ke2VuY29kZVVSSUNvbXBvbmVudChTdHJpbmcodmFsdWUpKX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcGFydHMuam9pbignJicpO1xufVxuXG4vKiogRmVjaGEgXCJkZXNkZVwiIGVmZWN0aXZhIGNvbW8gZW4gY3VlbnRhIGNvcnJpZW50ZSAocGFyaWRhZCBjb24gRXhjZWwgLyBiYWNrZW5kKS4gKi9cbmZ1bmN0aW9uIGdldE9wZW5pbmdCYWxhbmNlRGF0ZUZyb21GaWx0ZXJzKGRlZjogUmVwb3J0RGVmaW5pdGlvbiB8IG51bGwgfCB1bmRlZmluZWQsIGZpbHRlclZhbHM6IFJlY29yZDxzdHJpbmcsIGFueT4pOiBzdHJpbmcge1xuICAgIGlmICghZGVmPy5maWx0ZXJzPy5sZW5ndGgpIHJldHVybiAnJztcbiAgICBmb3IgKGNvbnN0IGYgb2YgZGVmLmZpbHRlcnMpIHtcbiAgICAgICAgaWYgKGYudHlwZSA9PT0gJ2RhdGUnICYmIGYub3BlcmF0b3IgPT09ICdkYXRlX2Zyb20nKSB7XG4gICAgICAgICAgICBjb25zdCB2ID0gZmlsdGVyVmFsc1tnZXRSZXBvcnRGaWx0ZXJLZXkoZildO1xuICAgICAgICAgICAgaWYgKHYgIT09ICcnICYmIHYgIT09IG51bGwgJiYgdiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcyA9IFN0cmluZyh2KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcy5pbmNsdWRlcygnVCcpID8gcy5zcGxpdCgnVCcpWzBdIDogcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAnJztcbn1cblxuZXhwb3J0IGNvbnN0IFJlcG9ydGVzUnVubmVyUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgLyoqIE1pc21vIHZhbG9yIHF1ZSBgaWRgOiBhbGlhcyBwb3Igc2kgZWwgYXJyYXkgZGUgZGVwZW5kZW5jaWFzIHUgSE1SIGHDum4gdXNhbiBlc3RlIG5vbWJyZSAobGEgcnV0YSBlcyBlbCBgY29kZWAgZGVsIHJlcG9ydGUsIG5vIHVuIGlkIG51bcOpcmljbykuICovXG4gICAgY29uc3QgcmVwb3J0SWRGcm9tUm91dGUgPSBpZDtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICBjb25zdCB7IGl0ZW06IGluaXRpYWxEZWYsIGxvYWRpbmc6IGxvYWRpbmdEZWYsIGVycm9yOiBlcnJvckRlZiB9ID0gdXNlQ3J1ZEl0ZW08UmVwb3J0RGVmaW5pdGlvbj4ocmVwb3J0ZXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIC8vIEVzdGFkb3NcbiAgICBjb25zdCBbZmlsdGVyVmFsdWVzLCBzZXRGaWx0ZXJWYWx1ZXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgYW55Pj4oe30pO1xuICAgIGNvbnN0IFtyZWxhdGlvbmFsTGFiZWxzLCBzZXRSZWxhdGlvbmFsTGFiZWxzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcbiAgICBjb25zdCBbcmVsYXRpb25hbENvZGVzLCBzZXRSZWxhdGlvbmFsQ29kZXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xuXG4gICAgY29uc3QgW3Jlc3VsdHMsIHNldFJlc3VsdHNdID0gdXNlU3RhdGU8YW55W10+KFtdKTtcblxuICAgIC8vIE1ldGFkYXRhIGRlIFBhZ2luYWNpw7NuXG4gICAgY29uc3QgW3BhZ2luYXRpb25NZXRhLCBzZXRQYWdpbmF0aW9uTWV0YV0gPSB1c2VTdGF0ZTx7XG4gICAgICAgIGN1cnJlbnRfcGFnZTogbnVtYmVyO1xuICAgICAgICBsYXN0X3BhZ2U6IG51bWJlcjtcbiAgICAgICAgdG90YWw6IG51bWJlcjtcbiAgICAgICAgZnJvbTogbnVtYmVyO1xuICAgICAgICB0bzogbnVtYmVyO1xuICAgICAgICBwZXJfcGFnZTogbnVtYmVyO1xuICAgIH0gfCBudWxsPihudWxsKTtcblxuICAgIGNvbnN0IFtkeW5hbWljTWV0YSwgc2V0RHluYW1pY01ldGFdID0gdXNlU3RhdGU8YW55PihudWxsKTtcbiAgICAvKiogU2FsZG8gaW5pY2lhbCBkZWwgZW5kcG9pbnQgcGFnaW5hZG8gKGN1ZW50YSBjbGllbnRlKTsgc8OzbG8gcMOhZ2luYSAxIFVJLiAqL1xuICAgIGNvbnN0IFtzdGF0ZW1lbnRJbml0aWFsQmFsYW5jZSwgc2V0U3RhdGVtZW50SW5pdGlhbEJhbGFuY2VdID0gdXNlU3RhdGU8bnVtYmVyIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuICAgIGNvbnN0IFtpc1J1bm5pbmcsIHNldElzUnVubmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzRXhwb3J0aW5nLCBzZXRJc0V4cG9ydGluZ10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZXhlY3V0aW9uRXJyb3IsIHNldEV4ZWN1dGlvbkVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtoYXNSdW4sIHNldEhhc1J1bl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBFc3RhZG9zIE1vZGFsIELDunNxdWVkYVxuICAgIGNvbnN0IFtpc1NlYXJjaE1vZGFsT3Blbiwgc2V0SXNTZWFyY2hNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFthY3RpdmVTZWFyY2hGaWx0ZXIsIHNldEFjdGl2ZVNlYXJjaEZpbHRlcl0gPSB1c2VTdGF0ZTx7XG4gICAgICAgIGtleTogc3RyaW5nO1xuICAgICAgICBjb25maWc6IFJlbGF0aW9uc2hpcE9wdGlvbnM7XG4gICAgfSB8IG51bGw+KG51bGwpO1xuXG4gICAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKGtleTogc3RyaW5nLCB2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgIHNldEZpbHRlclZhbHVlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtrZXldOiB2YWx1ZSB9KSk7XG4gICAgfTtcblxuICAgIC8qKiBSYW5nbyBtZXMgYWN0dWFsIChsaXN0YXMpOiByZWxsZW5hIHNvbG8gZGF0ZV9mcm9tIC8gZGF0ZV90byB2YWPDrW9zIGFsIGNhcmdhciBlbCByZXBvcnRlIChsYSBydXRhIHVzYSBgY29kZWAsIG5vIGlkIG51bcOpcmljbykuICovXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgIWluaXRpYWxEZWY/LmZpbHRlcnM/Lmxlbmd0aCB8fFxuICAgICAgICAgICAgcmVwb3J0SWRGcm9tUm91dGUgPT0gbnVsbCB8fFxuICAgICAgICAgICAgU3RyaW5nKGluaXRpYWxEZWYuY29kZSkgIT09IFN0cmluZyhyZXBvcnRJZEZyb21Sb3V0ZSlcbiAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBzdGFydERhdGUsIGVuZERhdGUgfSA9IGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCk7XG4gICAgICAgIHNldEZpbHRlclZhbHVlcyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBhdGNoOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGYgb2YgaW5pdGlhbERlZi5maWx0ZXJzKSB7XG4gICAgICAgICAgICAgICAgaWYgKGYudHlwZSAhPT0gJ2RhdGUnKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjb25zdCB1bmlxdWVLZXkgPSBnZXRSZXBvcnRGaWx0ZXJLZXkoZik7XG4gICAgICAgICAgICAgICAgY29uc3QgY3VyID0gcHJldlt1bmlxdWVLZXldO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzRW1wdHkgPSBjdXIgPT09ICcnIHx8IGN1ciA9PT0gbnVsbCB8fCBjdXIgPT09IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICBpZiAoIWlzRW1wdHkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGlmIChmLm9wZXJhdG9yID09PSAnZGF0ZV9mcm9tJykgcGF0Y2hbdW5pcXVlS2V5XSA9IHN0YXJ0RGF0ZTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChmLm9wZXJhdG9yID09PSAnZGF0ZV90bycpIHBhdGNoW3VuaXF1ZUtleV0gPSBlbmREYXRlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHBhdGNoKS5sZW5ndGggPT09IDApIHJldHVybiBwcmV2O1xuICAgICAgICAgICAgcmV0dXJuIHsgLi4ucHJldiwgLi4ucGF0Y2ggfTtcbiAgICAgICAgfSk7XG4gICAgfSwgW2luaXRpYWxEZWYsIHJlcG9ydElkRnJvbVJvdXRlXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBzZXRTdGF0ZW1lbnRJbml0aWFsQmFsYW5jZSh1bmRlZmluZWQpO1xuICAgIH0sIFtyZXBvcnRJZEZyb21Sb3V0ZV0pO1xuXG4gICAgLy8gLS0tIEzDk0dJQ0EgUkVMQUNJT05BTCAtLS1cbiAgICBjb25zdCBoYW5kbGVPcGVuU2VhcmNoID0gKGZpbHRlcktleTogc3RyaW5nLCBvcHRpb25zOiBSZWxhdGlvbnNoaXBPcHRpb25zKSA9PiB7XG4gICAgICAgIHNldEFjdGl2ZVNlYXJjaEZpbHRlcih7IGtleTogZmlsdGVyS2V5LCBjb25maWc6IG9wdGlvbnMgfSk7XG4gICAgICAgIHNldElzU2VhcmNoTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVTZWxlY3RGcm9tTW9kYWwgPSAoaXRlbTogYW55KSA9PiB7XG4gICAgICAgIGlmICghYWN0aXZlU2VhcmNoRmlsdGVyKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgeyBrZXksIGNvbmZpZyB9ID0gYWN0aXZlU2VhcmNoRmlsdGVyO1xuXG4gICAgICAgIGNvbnN0IHNlbGVjdGVkUm93ID0gaXRlbSBhcyBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuICAgICAgICBjb25zdCB2YWxGaWVsZCA9IGNvbmZpZy52YWx1ZV9maWVsZCB8fCAnaWQnO1xuICAgICAgICBjb25zdCBsYWJGaWVsZCA9IGNvbmZpZy5sYWJlbF9maWVsZCB8fCAnbmFtZSc7XG4gICAgICAgIGNvbnN0IGNvZEZpZWxkID0gY29uZmlnLmNvZGVfZmllbGQgfHwgY29uZmlnLnZhbHVlX2ZpZWxkIHx8ICdpZCc7XG5cbiAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKGtleSwgc2VsZWN0ZWRSb3dbdmFsRmllbGRdKTtcblxuICAgICAgICBzZXRSZWxhdGlvbmFsTGFiZWxzKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBba2V5XTogc2VsZWN0ZWRSb3dbbGFiRmllbGRdXG4gICAgICAgIH0pKTtcblxuICAgICAgICBzZXRSZWxhdGlvbmFsQ29kZXMocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtrZXldOiBzZWxlY3RlZFJvd1tjb2RGaWVsZF1cbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHNldElzU2VhcmNoTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgc2V0QWN0aXZlU2VhcmNoRmlsdGVyKG51bGwpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZWxhdGlvbmFsSW5wdXRDaGFuZ2UgPSAoa2V5OiBzdHJpbmcsIG5ld1ZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0UmVsYXRpb25hbENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW2tleV06IG5ld1ZhbHVlIH0pKTtcbiAgICB9O1xuXG4gICAgLy8g4pyFIE5VRVZPIEhBTkRMRVIgUEFSQSBBVVRPQ09NUExFVEFET1xuICAgIGNvbnN0IGhhbmRsZUF1dG9jb21wbGV0ZVNlbGVjdCA9IChrZXk6IHN0cmluZywgaXRlbTogYW55LCBjb25maWc6IFJlbGF0aW9uc2hpcE9wdGlvbnMpID0+IHtcbiAgICAgICAgLy8gTWlzbWEgbMOzZ2ljYSBxdWUgaGFuZGxlU2VsZWN0RnJvbU1vZGFsIHBlcm8gZGlyZWN0YVxuICAgICAgICBjb25zdCB2YWxGaWVsZCA9IGNvbmZpZy52YWx1ZV9maWVsZCB8fCAnaWQnO1xuICAgICAgICBjb25zdCBsYWJGaWVsZCA9IGNvbmZpZy5sYWJlbF9maWVsZCB8fCAnbmFtZSc7XG4gICAgICAgIGNvbnN0IGNvZEZpZWxkID0gY29uZmlnLmNvZGVfZmllbGQgfHwgY29uZmlnLnZhbHVlX2ZpZWxkIHx8ICdpZCc7XG5cbiAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKGtleSwgaXRlbVt2YWxGaWVsZF0pO1xuXG4gICAgICAgIHNldFJlbGF0aW9uYWxMYWJlbHMocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtrZXldOiBpdGVtW2xhYkZpZWxkXVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgc2V0UmVsYXRpb25hbENvZGVzKHByZXYgPT4gKHtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICBba2V5XTogaXRlbVtjb2RGaWVsZF1cbiAgICAgICAgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDb2RlU3VibWl0ID0gYXN5bmMgKGZpbHRlcktleTogc3RyaW5nLCBjb2RlOiBzdHJpbmcsIG9wdGlvbnM6IFJlbGF0aW9uc2hpcE9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKCFjb2RlKSB7XG4gICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoZmlsdGVyS2V5LCAnJyk7XG4gICAgICAgICAgICBzZXRSZWxhdGlvbmFsTGFiZWxzKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpbHRlcktleV06ICcnIH0pKTtcbiAgICAgICAgICAgIHNldFJlbGF0aW9uYWxDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtmaWx0ZXJLZXldOiAnJyB9KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZW5kcG9pbnRVcmwgPSBvcHRpb25zLmFwaV9lbmRwb2ludD8uc3BsaXQoJz8nKVswXSB8fCBgLyR7b3B0aW9ucy5yZXNvdXJjZX1gO1xuICAgICAgICAgICAgY29uc3Qgc2VhcmNoRmllbGQgPSBvcHRpb25zLmNvZGVfZmllbGQgfHwgb3B0aW9ucy52YWx1ZV9maWVsZCB8fCAnaWQnO1xuXG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzZWFyY2hCeUZpZWxkKGVuZHBvaW50VXJsLCBbeyBmaWVsZE5hbWU6IHNlYXJjaEZpZWxkLCB2YWx1ZTogY29kZSB9XSk7XG5cbiAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWxGaWVsZCA9IG9wdGlvbnMudmFsdWVfZmllbGQgfHwgJ2lkJztcbiAgICAgICAgICAgICAgICBjb25zdCBsYWJGaWVsZCA9IG9wdGlvbnMubGFiZWxfZmllbGQgfHwgJ25hbWUnO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvZEZpZWxkID0gb3B0aW9ucy5jb2RlX2ZpZWxkIHx8IG9wdGlvbnMudmFsdWVfZmllbGQgfHwgJ2lkJztcblxuICAgICAgICAgICAgICAgIGNvbnN0IGZvdW5kSXRlbSA9IHJlc3VsdCBhcyBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuXG4gICAgICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKGZpbHRlcktleSwgZm91bmRJdGVtW3ZhbEZpZWxkXSk7XG4gICAgICAgICAgICAgICAgc2V0UmVsYXRpb25hbExhYmVscyhwcmV2ID0+ICh7IC4uLnByZXYsIFtmaWx0ZXJLZXldOiBmb3VuZEl0ZW1bbGFiRmllbGRdIH0pKTtcbiAgICAgICAgICAgICAgICBzZXRSZWxhdGlvbmFsQ29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbZmlsdGVyS2V5XTogZm91bmRJdGVtW2NvZEZpZWxkXSB9KSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oXCJObyBlbmNvbnRyYWRvXCIpO1xuICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShmaWx0ZXJLZXksICcnKTtcbiAgICAgICAgICAgICAgICBzZXRSZWxhdGlvbmFsTGFiZWxzKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpbHRlcktleV06ICcnIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXJcIik7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gLS0tIFBBWUxPQUQgLS0tXG4gICAgY29uc3QgYnVpbGRGaWx0ZXJQYXlsb2FkID0gKCkgPT4ge1xuICAgICAgICBpZiAoIWluaXRpYWxEZWYpIHJldHVybiB7fTtcbiAgICAgICAgY29uc3QgcGF5bG9hZDogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuXG4gICAgICAgIGluaXRpYWxEZWYuZmlsdGVycy5mb3JFYWNoKGZpbHRlciA9PiB7XG4gICAgICAgICAgICBjb25zdCB1bmlxdWVLZXkgPSBnZXRSZXBvcnRGaWx0ZXJLZXkoZmlsdGVyKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZmlsdGVyVmFsdWVzW3VuaXF1ZUtleV07XG5cbiAgICAgICAgICAgIC8vIOKchSBMw5NHSUNBIENIRUNLQk9YIFNJTVBMSUZJQ0FEQVxuICAgICAgICAgICAgaWYgKGZpbHRlci50eXBlID09PSAnY2hlY2tib3gnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHBheWxvYWRbZmlsdGVyLmZpZWxkXSA9IHRydWU7IC8vIFNpbXBsZW1lbnRlIGVudmlhbW9zIHRydWVcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuOyAvLyBTaSBlcyBmYWxzZSwgbm8gZW52aWFtb3MgbmFkYVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZmlsdGVyLnR5cGUgPT09ICdzZWxlY3QnKSB7XG4gICAgICAgICAgICAgICAgaWYgKGlzU2luZ2xlU2VsZWN0RmlsdGVyKGZpbHRlci5vcHRpb25zKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzY2FsYXIgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IChBcnJheS5pc0FycmF5KHZhbHVlKSA/ICh2YWx1ZVswXSA/PyAnJykgOiAnJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzY2FsYXIgIT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXlsb2FkW2ZpbHRlci5maWVsZF0gPSBzY2FsYXI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkID0gZ2V0U2VsZWN0RmlsdGVyVmFsdWVzKHZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBwYXlsb2FkW2ZpbHRlci5maWVsZF0gPSBzZWxlY3RlZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBMw5NHSUNBIEVTVMOBTkRBUlxuICAgICAgICAgICAgaWYgKGZpbHRlclZhbHVlSXNQcmVzZW50KHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGlmIChmaWx0ZXIub3BlcmF0b3IgPT09ICdkYXRlX2Zyb20nKSBwYXlsb2FkW2Ake2ZpbHRlci5maWVsZH1fZnJvbWBdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZmlsdGVyLm9wZXJhdG9yID09PSAnZGF0ZV90bycpIHBheWxvYWRbYCR7ZmlsdGVyLmZpZWxkfV90b2BdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgZWxzZSBwYXlsb2FkW2ZpbHRlci5maWVsZF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwYXlsb2FkO1xuICAgIH07XG5cbiAgICAvLyAtLS0gRUpFQ1VDScOTTiAtLS1cbiAgICBjb25zdCBoYW5kbGVSdW5SZXBvcnQgPSBhc3luYyAocGFnZU51bWJlciA9IDEpID0+IHtcbiAgICAgICAgaWYgKCFpbml0aWFsRGVmKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9yID0gdmFsaWRhdGVSZXF1aXJlZFJlcG9ydEZpbHRlcnMoaW5pdGlhbERlZiwgZmlsdGVyVmFsdWVzKTtcbiAgICAgICAgaWYgKHZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAgICAgdG9hc3Qud2Fybih2YWxpZGF0aW9uRXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNSdW5uaW5nKHRydWUpO1xuICAgICAgICBzZXRFeGVjdXRpb25FcnJvcihudWxsKTtcbiAgICAgICAgc2V0SGFzUnVuKHRydWUpO1xuXG4gICAgICAgIGlmIChwYWdlTnVtYmVyID09PSAxKSB7XG4gICAgICAgICAgICBzZXRSZXN1bHRzKFtdKTtcbiAgICAgICAgICAgIHNldER5bmFtaWNNZXRhKG51bGwpO1xuICAgICAgICAgICAgc2V0UGFnaW5hdGlvbk1ldGEobnVsbCk7XG4gICAgICAgICAgICBzZXRTdGF0ZW1lbnRJbml0aWFsQmFsYW5jZSh1bmRlZmluZWQpO1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYCR7cmVwb3J0ZXNNb2R1bGVDb25maWcuZW5kcG9pbnR9LyR7aWR9L3J1bmA7XG5cbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgICAgICAgICAgLi4uYnVpbGRGaWx0ZXJQYXlsb2FkKCksXG4gICAgICAgICAgICAgICAgcGFnZTogcGFnZU51bWJlclxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBnZXRBbGw8YW55PihlbmRwb2ludCwgcGF5bG9hZCk7XG4gICAgICAgICAgICBjb25zdCByYXdSZXNwb25zZSA9IHJlc3BvbnNlIGFzIGFueTtcblxuICAgICAgICAgICAgbGV0IHJvd3M6IGFueVtdID0gW107XG5cbiAgICAgICAgICAgIGlmIChyYXdSZXNwb25zZS5kYXRhICYmIEFycmF5LmlzQXJyYXkocmF3UmVzcG9uc2UuZGF0YS5kYXRhKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhZ2VyID0gcmF3UmVzcG9uc2UuZGF0YTtcbiAgICAgICAgICAgICAgICByb3dzID0gcGFnZXIuZGF0YTtcbiAgICAgICAgICAgICAgICBzZXRQYWdpbmF0aW9uTWV0YSh7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRfcGFnZTogcGFnZXIuY3VycmVudF9wYWdlLFxuICAgICAgICAgICAgICAgICAgICBsYXN0X3BhZ2U6IHBhZ2VyLmxhc3RfcGFnZSxcbiAgICAgICAgICAgICAgICAgICAgdG90YWw6IHBhZ2VyLnRvdGFsLFxuICAgICAgICAgICAgICAgICAgICBmcm9tOiBwYWdlci5mcm9tLFxuICAgICAgICAgICAgICAgICAgICB0bzogcGFnZXIudG8sXG4gICAgICAgICAgICAgICAgICAgIHBlcl9wYWdlOiBwYWdlci5wZXJfcGFnZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChTdHJpbmcocmVwb3J0SWRGcm9tUm91dGUpID09PSBSUFRfQ1VTVE9NRVJfQUNDT1VOVCAmJiAnaW5pdGlhbF9iYWxhbmNlJyBpbiBwYWdlciAmJiBwYWdlci5pbml0aWFsX2JhbGFuY2UgIT09IG51bGwgJiYgcGFnZXIuaW5pdGlhbF9iYWxhbmNlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbiA9IE51bWJlcihwYWdlci5pbml0aWFsX2JhbGFuY2UpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIU51bWJlci5pc05hTihuKSkgc2V0U3RhdGVtZW50SW5pdGlhbEJhbGFuY2Uobik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHJhd1Jlc3BvbnNlLmRhdGEpKSB7XG4gICAgICAgICAgICAgICAgcm93cyA9IHJhd1Jlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICAgICAgc2V0UGFnaW5hdGlvbk1ldGEobnVsbCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocmF3UmVzcG9uc2UpKSB7XG4gICAgICAgICAgICAgICAgcm93cyA9IHJhd1Jlc3BvbnNlO1xuICAgICAgICAgICAgICAgIHNldFBhZ2luYXRpb25NZXRhKG51bGwpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAocmF3UmVzcG9uc2UubWV0YSkge1xuICAgICAgICAgICAgICAgIHNldER5bmFtaWNNZXRhKHJhd1Jlc3BvbnNlLm1ldGEpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzZXRSZXN1bHRzKHJvd3MpO1xuXG4gICAgICAgICAgICBjb25zdCBoYXNPcGVuaW5nQmFsYW5jZVVpID1cbiAgICAgICAgICAgICAgICBTdHJpbmcocmVwb3J0SWRGcm9tUm91dGUpID09PSBSUFRfQ1VTVE9NRVJfQUNDT1VOVCAmJlxuICAgICAgICAgICAgICAgIHBhZ2VOdW1iZXIgPT09IDEgJiZcbiAgICAgICAgICAgICAgICByYXdSZXNwb25zZS5kYXRhICYmXG4gICAgICAgICAgICAgICAgdHlwZW9mIHJhd1Jlc3BvbnNlLmRhdGEgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAgICAgIUFycmF5LmlzQXJyYXkocmF3UmVzcG9uc2UuZGF0YSkgJiZcbiAgICAgICAgICAgICAgICAnaW5pdGlhbF9iYWxhbmNlJyBpbiByYXdSZXNwb25zZS5kYXRhICYmXG4gICAgICAgICAgICAgICAgcmF3UmVzcG9uc2UuZGF0YS5pbml0aWFsX2JhbGFuY2UgIT09IG51bGwgJiZcbiAgICAgICAgICAgICAgICByYXdSZXNwb25zZS5kYXRhLmluaXRpYWxfYmFsYW5jZSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgICAgIU51bWJlci5pc05hTihOdW1iZXIocmF3UmVzcG9uc2UuZGF0YS5pbml0aWFsX2JhbGFuY2UpKTtcblxuICAgICAgICAgICAgaWYgKHJvd3MubGVuZ3RoID09PSAwICYmIHBhZ2VOdW1iZXIgPT09IDEgJiYgIWhhc09wZW5pbmdCYWxhbmNlVWkpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5pbmZvKFwiRWwgcmVwb3J0ZSBubyBhcnJvasOzIHJlc3VsdGFkb3MuXCIpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChwYWdlTnVtYmVyID09PSAxKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIlJlcG9ydGUgZ2VuZXJhZG8gY29uIMOpeGl0by5cIik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIHNldEV4ZWN1dGlvbkVycm9yKFwiRXJyb3IgYWwgZWplY3V0YXIgZWwgcmVwb3J0ZS5cIik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGVqZWN1dGFyIHJlcG9ydGVcIik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1J1bm5pbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUluaXRpYWxSdW4gPSAoKSA9PiBoYW5kbGVSdW5SZXBvcnQoMSk7XG5cbiAgICBjb25zdCBoYW5kbGVQYWdlQ2hhbmdlID0gKG5ld1BhZ2U6IG51bWJlcikgPT4ge1xuICAgICAgICBpZiAobmV3UGFnZSA+PSAxICYmICghcGFnaW5hdGlvbk1ldGEgfHwgbmV3UGFnZSA8PSBwYWdpbmF0aW9uTWV0YS5sYXN0X3BhZ2UpKSB7XG4gICAgICAgICAgICBoYW5kbGVSdW5SZXBvcnQobmV3UGFnZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gLS0tIEVYUE9SVCAtLS1cbiAgICBjb25zdCBoYW5kbGVFeHBvcnQgPSBhc3luYyAoZm9ybWF0OiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKCFpbml0aWFsRGVmKSByZXR1cm47XG5cbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbkVycm9yID0gdmFsaWRhdGVSZXF1aXJlZFJlcG9ydEZpbHRlcnMoaW5pdGlhbERlZiwgZmlsdGVyVmFsdWVzKTtcbiAgICAgICAgaWYgKHZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAgICAgdG9hc3Qud2Fybih2YWxpZGF0aW9uRXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNFeHBvcnRpbmcoZm9ybWF0KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBidWlsZEZpbHRlclBheWxvYWQoKTtcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gYnVpbGRSZXBvcnRRdWVyeVN0cmluZyhwYXlsb2FkKTtcbiAgICAgICAgICAgIGNvbnN0IGVuZHBvaW50ID0gYCR7cmVwb3J0ZXNNb2R1bGVDb25maWcuZW5kcG9pbnR9LyR7aWR9L3J1bi8ke2Zvcm1hdH0/JHtxdWVyeVN0cmluZ31gO1xuXG4gICAgICAgICAgICBjb25zdCB7IGJsb2IsIGZpbGVuYW1lIH0gPSBhd2FpdCBnZXRGaWxlQmxvYldpdGhNZXRhKGVuZHBvaW50KTtcbiAgICAgICAgICAgIGNvbnN0IGZhbGxiYWNrTmFtZSA9IGAke2luaXRpYWxEZWYuY29kZX1fJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX0uJHtmb3JtYXR9YDtcbiAgICAgICAgICAgIGRvd25sb2FkQmxvYihibG9iLCBmaWxlbmFtZSA9PT0gJ2RvY3VtZW50by5wZGYnID8gZmFsbGJhY2tOYW1lIDogZmlsZW5hbWUpO1xuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhgQXJjaGl2byAke2Zvcm1hdC50b1VwcGVyQ2FzZSgpfSBnZW5lcmFkby5gKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yICR7Zm9ybWF0fTpgLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihgRXJyb3IgYWwgZXhwb3J0YXIgJHtmb3JtYXQudG9VcHBlckNhc2UoKX0uYCk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc0V4cG9ydGluZyhudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyAtLS0gUkVOREVSSVpBRE8gVUkgLS0tXG5cbiAgICBjb25zdCByZW5kZXJFeHBvcnRCdXR0b25zID0gKCkgPT4ge1xuICAgICAgICBpZiAoIWhhc1J1bikgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGZvcm1hdHM6IHN0cmluZ1tdID0gZHluYW1pY01ldGE/LmF2YWlsYWJsZV9mb3JtYXRzIHx8IGluaXRpYWxEZWY/LmF2YWlsYWJsZV9mb3JtYXRzIHx8IFsncGRmJ107XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdHMuaW5jbHVkZXMoJ3BkZicpICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFeHBvcnQoJ3BkZicpfSBkaXNhYmxlZD17ISFpc0V4cG9ydGluZ30gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXJlZC02MDAgcm91bmRlZCBzaGFkb3cgaG92ZXI6YmctcmVkLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBvcnRpbmcgPT09ICdwZGYnID8gPExvYWRpbmdTcGlubmVyIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IDogPEZhRmlsZVBkZiBjbGFzc05hbWU9XCJtci0yXCIgLz59IFBERlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHsvKiDinIUgTlVFVk86IEVYQ0VMIChWZXJkZSkgKi99XG4gICAgICAgICAgICAgICAge2Zvcm1hdHMuaW5jbHVkZXMoJ3hsc3gnKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUV4cG9ydCgneGxzeCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyEhaXNFeHBvcnRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctZ3JlZW4tNjAwIHJvdW5kZWQgc2hhZG93IGhvdmVyOmJnLWdyZWVuLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwb3J0aW5nID09PSAneGxzeCcgPyA8TG9hZGluZ1NwaW5uZXIgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gOiA8RmFGaWxlRXhjZWwgY2xhc3NOYW1lPVwibXItMlwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgRXhjZWxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7Zm9ybWF0cy5pbmNsdWRlcygndHh0JykgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZUV4cG9ydCgndHh0Jyl9IGRpc2FibGVkPXshIWlzRXhwb3J0aW5nfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHNoYWRvdyBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cG9ydGluZyA9PT0gJ3R4dCcgPyA8TG9hZGluZ1NwaW5uZXIgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gOiA8RmFGaWxlQWx0IGNsYXNzTmFtZT1cIm1yLTIgdGV4dC1ncmF5LTUwMFwiIC8+fSBUWFRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7Zm9ybWF0cy5maWx0ZXIoZiA9PiAhWydwZGYnLCAndHh0JywgJ3hsc3gnLCAnanNvbiddLmluY2x1ZGVzKGYpKS5tYXAoZiA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24ga2V5PXtmfSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFeHBvcnQoZil9IGRpc2FibGVkPXshIWlzRXhwb3J0aW5nfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHNoYWRvdyBob3ZlcjpiZy1ncmF5LTUwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvRG9jdW1lbnRUZXh0IGNsYXNzTmFtZT1cIm1yLTJcIiAvPiB7Zn1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVuZGVyUGFnaW5hdGlvbiA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFwYWdpbmF0aW9uTWV0YSB8fCBwYWdpbmF0aW9uTWV0YS5sYXN0X3BhZ2UgPD0gMSkgcmV0dXJuIG51bGw7XG5cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyBiZy13aGl0ZSBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgc206cHgtNlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gZmxleC0xIHNtOmhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQYWdlQ2hhbmdlKHBhZ2luYXRpb25NZXRhLmN1cnJlbnRfcGFnZSAtIDEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2luYXRpb25NZXRhLmN1cnJlbnRfcGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBBbnRlcmlvclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUGFnZUNoYW5nZShwYWdpbmF0aW9uTWV0YS5jdXJyZW50X3BhZ2UgKyAxKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdpbmF0aW9uTWV0YS5jdXJyZW50X3BhZ2UgPT09IHBhZ2luYXRpb25NZXRhLmxhc3RfcGFnZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1sLTMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIFNpZ3VpZW50ZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IHNtOmZsZXgtMSBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNb3N0cmFuZG8gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57cGFnaW5hdGlvbk1ldGEuZnJvbX08L3NwYW4+IGEgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57cGFnaW5hdGlvbk1ldGEudG99PC9zcGFuPiBkZSA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntwYWdpbmF0aW9uTWV0YS50b3RhbH08L3NwYW4+IHJlc3VsdGFkb3NcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IC1zcGFjZS14LXB4IHJvdW5kZWQtbWQgc2hhZG93LXNtXCIgYXJpYS1sYWJlbD1cIlBhZ2luYXRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBhZ2VDaGFuZ2UocGFnaW5hdGlvbk1ldGEuY3VycmVudF9wYWdlIC0gMSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdpbmF0aW9uTWV0YS5jdXJyZW50X3BhZ2UgPT09IDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTIgdGV4dC1ncmF5LTQwMCByb3VuZGVkLWwtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBob3ZlcjpiZy1ncmF5LTUwIGZvY3VzOnotMjAgZm9jdXM6b3V0bGluZS1vZmZzZXQtMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5BbnRlcmlvcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvQ2hldnJvbkJhY2sgY2xhc3NOYW1lPVwiaC01IHctNVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktMzAwIGZvY3VzOm91dGxpbmUtb2Zmc2V0LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUMOhZ2luYSB7cGFnaW5hdGlvbk1ldGEuY3VycmVudF9wYWdlfSBkZSB7cGFnaW5hdGlvbk1ldGEubGFzdF9wYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBhZ2VDaGFuZ2UocGFnaW5hdGlvbk1ldGEuY3VycmVudF9wYWdlICsgMSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdpbmF0aW9uTWV0YS5jdXJyZW50X3BhZ2UgPT09IHBhZ2luYXRpb25NZXRhLmxhc3RfcGFnZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMiB0ZXh0LWdyYXktNDAwIHJvdW5kZWQtci1tZCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIGhvdmVyOmJnLWdyYXktNTAgZm9jdXM6ei0yMCBmb2N1czpvdXRsaW5lLW9mZnNldC0wIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPlNpZ3VpZW50ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvQ2hldnJvbkZvcndhcmQgY2xhc3NOYW1lPVwiaC01IHctNVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L25hdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgY29uc3QgcmVuZGVyRmlsdGVySW5wdXQgPSAoZmlsdGVyOiBSZXBvcnRGaWx0ZXJDb25maWcpID0+IHtcbiAgICAgICAgY29uc3QgY29tbW9uQ2xhc3NlcyA9IFwibXQtMSBibG9jayB3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXItZ3JheS0zMDAgc2hhZG93LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBzbTp0ZXh0LXNtIHB5LTIgcHgtMyBib3JkZXJcIjtcbiAgICAgICAgY29uc3QgdW5pcXVlS2V5ID0gZ2V0UmVwb3J0RmlsdGVyS2V5KGZpbHRlcik7XG4gICAgICAgIGNvbnN0IHJhd1ZhbHVlID0gZmlsdGVyVmFsdWVzW3VuaXF1ZUtleV07XG4gICAgICAgIGNvbnN0IGN1cnJlbnRWYWx1ZSA9IHJhd1ZhbHVlID8/ICcnO1xuXG4gICAgICAgIGlmIChmaWx0ZXIudHlwZSA9PT0gJ3JlbGF0aW9uc2hpcCcpIHtcbiAgICAgICAgICAgIGxldCByZWxDb25maWcgPSBmaWx0ZXIub3B0aW9ucyA/IHBhcnNlT3B0aW9ucyhmaWx0ZXIub3B0aW9ucykgOiBudWxsO1xuICAgICAgICAgICAgaWYgKCFyZWxDb25maWcpIHJlbENvbmZpZyA9IGluZmVyUmVsYXRpb25zaGlwT3B0aW9ucyhmaWx0ZXIuZmllbGQpO1xuXG4gICAgICAgICAgICBpZiAocmVsQ29uZmlnKSB7XG4gICAgICAgICAgICAgICAgLy8g4pyFIERldGVjdGFtb3Mgc2kgZXMgUHJvZHVjdG8gcGFyIGFjdGl2YXIgYXV0b2NvbXBsZXRlXG4gICAgICAgICAgICAgICAgY29uc3QgaXNQcm9kdWN0RmlsdGVyID0gcmVsQ29uZmlnLnJlc291cmNlID09PSAncHJvZHVjdHMnO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtyZWxhdGlvbmFsQ29kZXNbdW5pcXVlS2V5XSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17cmVsYXRpb25hbExhYmVsc1t1bmlxdWVLZXldIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVSZWxhdGlvbmFsSW5wdXRDaGFuZ2UodW5pcXVlS2V5LCB2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVDb2RlU3VibWl0KHVuaXF1ZUtleSwgcmVsYXRpb25hbENvZGVzW3VuaXF1ZUtleV0sIHJlbENvbmZpZyEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3BlblNlYXJjaCh1bmlxdWVLZXksIHJlbENvbmZpZyEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKHVuaXF1ZUtleSwgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlbGF0aW9uYWxMYWJlbHMocHJldiA9PiAoeyAuLi5wcmV2LCBbdW5pcXVlS2V5XTogJycgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlbGF0aW9uYWxDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFt1bmlxdWVLZXldOiAnJyB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyDinIUgUHJvcHMgZGUgQXV0b2NvbXBsZXRlIChTb2xvIHBhcmEgcHJvZHVjdG9zKVxuICAgICAgICAgICAgICAgICAgICAgICAgbWFzaz17aXNQcm9kdWN0RmlsdGVyID8gJ3NrdScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbmFibGVBdXRvY29tcGxldGU9e2lzUHJvZHVjdEZpbHRlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9jb21wbGV0ZUNvbmZpZz17aXNQcm9kdWN0RmlsdGVyID8ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZHBvaW50OiBhcnRpY3Vsb3NNb2R1bGVDb25maWcuZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZUZpZWxkOiAnc2t1JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lRmllbGQ6ICduYW1lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdDogKGl0ZW0pID0+IGhhbmRsZUF1dG9jb21wbGV0ZVNlbGVjdCh1bmlxdWVLZXksIGl0ZW0sIHJlbENvbmZpZyEpXG4gICAgICAgICAgICAgICAgICAgICAgICB9IDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBzd2l0Y2ggKGZpbHRlci50eXBlKSB7XG4gICAgICAgICAgICBjYXNlICdkYXRlJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gPGlucHV0IHR5cGU9XCJkYXRlXCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPXtjb21tb25DbGFzc2VzfSB2YWx1ZT17Y3VycmVudFZhbHVlfSBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZSh1bmlxdWVLZXksIGUudGFyZ2V0LnZhbHVlKX0gLz47XG4gICAgICAgICAgICBjYXNlICdzZWxlY3QnOiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWVMYWJlbE9wdGlvbnMgPSBnZXRWYWx1ZUxhYmVsU2VsZWN0T3B0aW9ucyhmaWx0ZXIub3B0aW9ucyk7XG5cbiAgICAgICAgICAgICAgICBpZiAoaXNTaW5nbGVTZWxlY3RGaWx0ZXIoZmlsdGVyLm9wdGlvbnMpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNjYWxhclZhbHVlID0gdHlwZW9mIGN1cnJlbnRWYWx1ZSA9PT0gJ3N0cmluZydcbiAgICAgICAgICAgICAgICAgICAgICAgID8gY3VycmVudFZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IChBcnJheS5pc0FycmF5KGN1cnJlbnRWYWx1ZSkgPyAoY3VycmVudFZhbHVlWzBdID8/ICcnKSA6ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbkNsYXNzZXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NjYWxhclZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKHVuaXF1ZUtleSwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2YWx1ZUxhYmVsT3B0aW9ucy5tYXAoKG9wdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17b3B0LnZhbHVlIHx8ICdfX2VtcHR5X18nfSB2YWx1ZT17b3B0LnZhbHVlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3Qgb3B0aW9uc0FycmF5ID0gcGFyc2VPcHRpb25zKGZpbHRlci5vcHRpb25zKSB8fCBbXTtcbiAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGdldFNlbGVjdEZpbHRlclZhbHVlcyhyYXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZHJvcGRvd25PcHRpb25zID0gQXJyYXkuaXNBcnJheShvcHRpb25zQXJyYXkpXG4gICAgICAgICAgICAgICAgICAgID8gb3B0aW9uc0FycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChvcHQ6IHVua25vd24pID0+IG9wdCAhPT0gbnVsbCAmJiB0eXBlb2Ygb3B0ID09PSAnb2JqZWN0JyAmJiAndmFsdWUnIGluIChvcHQgYXMgb2JqZWN0KSAmJiAnbGFiZWwnIGluIChvcHQgYXMgb2JqZWN0KSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKG9wdDogeyB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyOyBsYWJlbDogc3RyaW5nIH0pID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IFN0cmluZyhvcHQudmFsdWUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBvcHQubGFiZWwsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgOiB2YWx1ZUxhYmVsT3B0aW9ucztcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8TXVsdGlTZWxlY3REcm9wZG93blxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17ZHJvcGRvd25PcHRpb25zfVxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWQ9e3NlbGVjdGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZUZpbHRlckNoYW5nZSh1bmlxdWVLZXksIHZhbHVlcyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRvZG9zXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbkNsYXNzZXN9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17ZmlsdGVyLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRWYWx1ZSA9PT0gJycgfHwgY3VycmVudFZhbHVlID09IG51bGwgPyBudWxsIDogTnVtYmVyKGN1cnJlbnRWYWx1ZSkgfHwgMH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG51bGxhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICB3aGVuRW1wdHk9e251bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZUZpbHRlckNoYW5nZSh1bmlxdWVLZXksIG51bSA/PyAnJyl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgLy8g4pyFIENBU0UgQ0hFQ0tCT1hcbiAgICAgICAgICAgIGNhc2UgJ2NoZWNrYm94JzpcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGgtMTAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BmaWx0ZXItJHt1bmlxdWVLZXl9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1pbmRpZ28tNjAwIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ISFjdXJyZW50VmFsdWV9IC8vIEZvcnphbW9zIGJvb2xlYW5vIHBhcmEgZWwgaW5wdXQgdmlzdWFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UodW5pcXVlS2V5LCBlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YGZpbHRlci0ke3VuaXF1ZUtleX1gfSBjbGFzc05hbWU9XCJtbC0yIGJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTcwMCBjdXJzb3ItcG9pbnRlciBzZWxlY3Qtbm9uZVwiPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHJvdW5kZWQtbWQgc2hhZG93LXNtXCI+PGlucHV0IHR5cGU9XCJ0ZXh0XCIgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPXtjb21tb25DbGFzc2VzfSBwbGFjZWhvbGRlcj1cIkJ1c2Nhci4uLlwiIHZhbHVlPXtjdXJyZW50VmFsdWV9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKHVuaXF1ZUtleSwgZS50YXJnZXQudmFsdWUpfSAvPjwvZGl2PjtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBtb25leVN5bWJvbCA9IChkeW5hbWljTWV0YT8uZGlzcGxheV9jdXJyZW5jeV9zeW1ib2xcbiAgICAgICAgPz8gKGR5bmFtaWNNZXRhPy5kaXNwbGF5X2N1cnJlbmN5X2NvZGUgPT09ICcwMScgfHwgIWR5bmFtaWNNZXRhPy5kaXNwbGF5X2N1cnJlbmN5X2NvZGUgPyAnJCcgOiAnVVNEJykpIGFzICckJyB8ICdVU0QnO1xuXG4gICAgY29uc3QgcmVuZGVyQ2VsbCA9IChyb3c6IGFueSwgY29sQ29uZmlnOiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgcmF3VmFsdWUgPSBnZXROZXN0ZWRWYWx1ZShyb3csIGNvbENvbmZpZy5rZXkpO1xuICAgICAgICBpZiAocmF3VmFsdWUgPT09IG51bGwgfHwgcmF3VmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS0zMDAgdGV4dC14c1wiPi08L3NwYW4+O1xuXG4gICAgICAgIGlmIChyZXBvcnRJZEZyb21Sb3V0ZSA9PT0gJ1JQVF9TVE9DS19NT1ZFTUVOVFMnICYmIGNvbENvbmZpZy5rZXkgPT09ICdxdWFudGl0eScpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGVGb3JTdHlsZSA9IHBhcnNlTW92ZW1lbnRDb2RlUHJlZml4KGdldE5lc3RlZFZhbHVlKHJvdywgJ21vdmVtZW50X2NvZGUnKSk7XG4gICAgICAgICAgICByZXR1cm4gcmVuZGVyU2lnbmVkU3RvY2tRdWFudGl0eShjb2RlRm9yU3R5bGUgPz8gdW5kZWZpbmVkLCByYXdWYWx1ZSk7XG4gICAgICAgIH1cblxuICAgICAgICBzd2l0Y2ggKGNvbENvbmZpZy50eXBlKSB7XG4gICAgICAgICAgICBjYXNlICdtb25leSc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBudW0gPSBOdW1iZXIocmF3VmFsdWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzTmVnYXRpdmUgPSAhTnVtYmVyLmlzTmFOKG51bSkgJiYgbnVtIDwgMDtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LW1vbm8gJHtpc05lZ2F0aXZlID8gJ3RleHQtcmVkLTYwMCcgOiAndGV4dC1ncmF5LTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VmFsdWUocmF3VmFsdWUsICdjdXJyZW5jeScsIHsgbW9uZXlTeW1ib2wgfSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnZGF0ZSc6IHJldHVybiA8c3Bhbj57Zm9ybWF0VmFsdWUocmF3VmFsdWUsICdkYXRlJyl9PC9zcGFuPjtcbiAgICAgICAgICAgIGNhc2UgJ251bWJlcic6IHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRhYnVsYXItbnVtc1wiPntmb3JtYXRWYWx1ZShyYXdWYWx1ZSwgJ251bWJlcicpfTwvc3Bhbj47XG4gICAgICAgICAgICBjYXNlICdiYWRnZSc6IHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJweC0yIGlubGluZS1mbGV4IHRleHQteHMgbGVhZGluZy01IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAgdXBwZXJjYXNlXCI+e1N0cmluZyhyYXdWYWx1ZSl9PC9zcGFuPjtcbiAgICAgICAgICAgIGNhc2UgJ2xpbmsnOiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbGlua0lkID0gY29sQ29uZmlnLmxpbmtfaWRfa2V5ID8gZ2V0TmVzdGVkVmFsdWUocm93LCBjb2xDb25maWcubGlua19pZF9rZXkpIDogbnVsbDtcbiAgICAgICAgICAgICAgICBjb25zdCBsYWJlbCA9IFN0cmluZyhyYXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFsaW5rSWQgfHwgIWNvbENvbmZpZy5saW5rX3BhdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDBcIj57bGFiZWx9PC9zcGFuPjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgcGF0aCA9IGNvbENvbmZpZy5saW5rX3BhdGgucmVwbGFjZSgnOmlkJywgU3RyaW5nKGxpbmtJZCkpO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtwYXRofSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+e1N0cmluZyhyYXdWYWx1ZSl9PC9zcGFuPjtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvKiogSW5jbHV5ZSBmaWxhIHNpbnTDqXRpY2EgXCJTYWxkbyBpbmljaWFsXCIgcGFyYSBSUFRfQ1VTVE9NRVJfQUNDT1VOVCBww6FnaW5hIDEuICovXG4gICAgY29uc3QgdGFibGVSb3dzID0gdXNlTWVtbygoKTogYW55W10gPT4ge1xuICAgICAgICBpZiAoU3RyaW5nKHJlcG9ydElkRnJvbVJvdXRlKSAhPT0gUlBUX0NVU1RPTUVSX0FDQ09VTlQpIHJldHVybiByZXN1bHRzO1xuXG4gICAgICAgIGNvbnN0IHBhZ2VPbmUgPSBwYWdpbmF0aW9uTWV0YSA9PSBudWxsIHx8IHBhZ2luYXRpb25NZXRhLmN1cnJlbnRfcGFnZSA9PT0gMTtcbiAgICAgICAgY29uc3QgaWJPayA9IHN0YXRlbWVudEluaXRpYWxCYWxhbmNlICE9PSB1bmRlZmluZWQgJiYgTnVtYmVyLmlzRmluaXRlKHN0YXRlbWVudEluaXRpYWxCYWxhbmNlKTtcbiAgICAgICAgaWYgKCFwYWdlT25lIHx8ICFpYk9rKSByZXR1cm4gcmVzdWx0cztcblxuICAgICAgICBjb25zdCBkYXRlRnJvbSA9IGdldE9wZW5pbmdCYWxhbmNlRGF0ZUZyb21GaWx0ZXJzKGluaXRpYWxEZWYgPz8gbnVsbCwgZmlsdGVyVmFsdWVzKTtcbiAgICAgICAgY29uc3Qgc3ludGhldGljID0ge1xuICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZGF0ZUZyb20gPyBkYXRlRnJvbSA6IG51bGwsXG4gICAgICAgICAgICBkb2N1bWVudF90eXBlOiAnU2FsZG8gaW5pY2lhbCcsXG4gICAgICAgICAgICBkb2N1bWVudF9udW1iZXI6ICcnLFxuICAgICAgICAgICAgZGViaXQ6IDAsXG4gICAgICAgICAgICBjcmVkaXQ6IDAsXG4gICAgICAgICAgICBiYWxhbmNlOiBzdGF0ZW1lbnRJbml0aWFsQmFsYW5jZSBhcyBudW1iZXIsXG4gICAgICAgICAgICBfX2lzT3BlbmluZ0JhbGFuY2VSb3c6IHRydWUsXG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIFtzeW50aGV0aWMsIC4uLnJlc3VsdHNdO1xuICAgIH0sIFtyZXBvcnRJZEZyb21Sb3V0ZSwgcmVzdWx0cywgcGFnaW5hdGlvbk1ldGEsIHN0YXRlbWVudEluaXRpYWxCYWxhbmNlLCBmaWx0ZXJWYWx1ZXMsIGluaXRpYWxEZWZdKTtcblxuICAgIGlmIChsb2FkaW5nRGVmKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvckRlZiB8fCAhaW5pdGlhbERlZikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHAtNiBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWQgbS00XCI+RXJyb3IgY2FyZ2FuZG8gZGVmaW5pY2nDs24uPC9kaXY+O1xuXG4gICAgY29uc3QgY29sdW1uc1RvUmVuZGVyID0gZHluYW1pY01ldGE/LmNvbHVtbnMgfHwgaW5pdGlhbERlZi5jb2x1bW5zX2NvbmZpZztcbiAgICBjb25zdCB0aXRsZVRvUmVuZGVyID0gZHluYW1pY01ldGE/LnRpdGxlIHx8IGluaXRpYWxEZWYubmFtZTtcbiAgICBjb25zdCBkZXNjcmlwdGlvblRvUmVuZGVyID0gZHluYW1pY01ldGE/LmRlc2NyaXB0aW9uIHx8IGluaXRpYWxEZWYuZGVzY3JpcHRpb247XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS02IG1pbi1oLXNjcmVlbiByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi00IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUocmVwb3J0ZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKX0gY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLWdyYXktMTAwIHJvdW5kZWQtZnVsbCB0ZXh0LWdyYXktNTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9BcnJvd0JhY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+e3RpdGxlVG9SZW5kZXJ9PC9oMT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtYXgtdy0yeGxcIj57ZGVzY3JpcHRpb25Ub1JlbmRlcn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbWItNCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxGYUZpbHRlciBjbGFzc05hbWU9XCJtci0yIHRleHQtaW5kaWdvLTUwMFwiIC8+IENvbmZpZ3VyYWNpw7NuIGRlIEZpbHRyb3NcbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICB7aW5pdGlhbERlZi5maWx0ZXJzICYmIGluaXRpYWxEZWYuZmlsdGVycy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbERlZi5maWx0ZXJzLnNvcnQoKGEsIGIpID0+IGEub3JkZXIgLSBiLm9yZGVyKS5tYXAoZmlsdGVyID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZmlsdGVyLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTEgbWwtMVwiPntmaWx0ZXIubGFiZWx9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckZpbHRlcklucHV0KGZpbHRlcil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsIHRleHQtc20gdGV4dC1ncmF5LTQwMCBpdGFsaWNcIj5TaW4gZmlsdHJvcyBjb25maWd1cmFibGVzLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQgbGc6Y29sLXN0YXJ0LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlSW5pdGlhbFJ1bn0gZGlzYWJsZWQ9e2lzUnVubmluZyB8fCAhIWlzRXhwb3J0aW5nfSBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci13YWl0IHRyYW5zaXRpb24tYWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzUnVubmluZyA/IDxJb1NlYXJjaCBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gbXItMlwiIC8+IDogPElvUGxheSBjbGFzc05hbWU9XCJtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzUnVubmluZyA/ICdQcm9jZXNhbmRvLi4uJyA6ICdFamVjdXRhciBSZXBvcnRlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFUYWJsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJlc3VsdGFkb3Mge2hhc1J1biAmJiA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHB4LTIgcHktMC41IGJnLWdyYXktMTAwIHRleHQtZ3JheS02MDAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ub3JtYWwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPntwYWdpbmF0aW9uTWV0YT8udG90YWwgfHwgcmVzdWx0cy5sZW5ndGh9IHJlZ2lzdHJvczwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgIHtyZW5kZXJFeHBvcnRCdXR0b25zKCl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7ZXhlY3V0aW9uRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcmVkLTUwIHRleHQtcmVkLTcwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgcm91bmRlZC1tZCBtYi00IHRleHQtc21cIj57ZXhlY3V0aW9uRXJyb3J9PC9kaXY+fVxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIG92ZXJmbG93LXgtYXV0byBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtdC1sZyBzaGFkb3ctc20gYmctd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB3LTEwXCI+IzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29sdW1uc1RvUmVuZGVyLm1hcCgoY29sOiBhbnksIGlkeDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17aWR4fSBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgd2hpdGVzcGFjZS1ub3dyYXBcIj57Y29sLmxhYmVsfTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFoYXNSdW4gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+PHRkIGNvbFNwYW49e2NvbHVtbnNUb1JlbmRlci5sZW5ndGggKyAxfSBjbGFzc05hbWU9XCJweC02IHB5LTE2IHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5Fc3BlcmFuZG8gZWplY3VjacOzbi4uLjwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IHRhYmxlUm93cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+PHRkIGNvbFNwYW49e2NvbHVtbnNUb1JlbmRlci5sZW5ndGggKyAxfSBjbGFzc05hbWU9XCJweC02IHB5LTEyIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDAgYmctZ3JheS01MCBpdGFsaWNcIj5ObyBzZSBlbmNvbnRyYXJvbiBkYXRvcy48L3RkPjwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZVJvd3MubWFwKChyb3c6IGFueSwgcklkeDogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3BlbmluZ0ZpcnN0Um93ID0gISEodGFibGVSb3dzWzBdICYmIHRhYmxlUm93c1swXS5fX2lzT3BlbmluZ0JhbGFuY2VSb3cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9yZGluYWwgPSByb3cuX19pc09wZW5pbmdCYWxhbmNlUm93XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHBhZ2luYXRpb25NZXRhICE9PSBudWxsICYmIHBhZ2luYXRpb25NZXRhICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gKHBhZ2luYXRpb25NZXRhLmN1cnJlbnRfcGFnZSAtIDEpICogcGFnaW5hdGlvbk1ldGEucGVyX3BhZ2UgKyBySWR4ICsgKG9wZW5pbmdGaXJzdFJvdyA/IDAgOiAxKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBySWR4ICsgKG9wZW5pbmdGaXJzdFJvdyA/IDAgOiAxKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtyb3cuX19pc09wZW5pbmdCYWxhbmNlUm93ID8gYG9wZW5pbmctJHtyZXBvcnRJZEZyb21Sb3V0ZX1gIDogYCR7cGFnaW5hdGlvbk1ldGE/LmN1cnJlbnRfcGFnZSA/PyAnbnAnfS0ke3JJZHh9LSR7U3RyaW5nKHJvdy50cmFuc2FjdGlvbl9kYXRlID8/IHJvdy5pZCA/PyBySWR4KX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaG92ZXI6YmctYmx1ZS01MCB0cmFuc2l0aW9uLWNvbG9ycyAke3Jvdy5fX2lzT3BlbmluZ0JhbGFuY2VSb3cgPyAnYmctc2xhdGUtNTAnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXhzIHRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29yZGluYWwgIT0gbnVsbCA/IG9yZGluYWwgOiAnXFx1MjAxNCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbHVtbnNUb1JlbmRlci5tYXAoKGNvbDogYW55LCBjSWR4OiBudW1iZXIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjSWR4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSBib3JkZXItZ3JheS0xMDAgJHtyZXBvcnRJZEZyb21Sb3V0ZSA9PT0gJ1JQVF9TVE9DS19NT1ZFTUVOVFMnICYmIGNvbC5rZXkgPT09ICdxdWFudGl0eScgPyAndGV4dC1yaWdodCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckNlbGwocm93LCBjb2wpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7cmVuZGVyUGFnaW5hdGlvbigpfVxuXG4gICAgICAgICAgICAgICAge2hhc1JlbmRlcmFibGVGb290ZXIoZHluYW1pY01ldGEpICYmIChcbiAgICAgICAgICAgICAgICAgICAgPFJlcG9ydEZvb3RlclNlY3Rpb24gZm9vdGVyPXtkeW5hbWljTWV0YS5mb290ZXJ9IG1vbmV5U3ltYm9sPXttb25leVN5bWJvbH0gLz5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2lzU2VhcmNoTW9kYWxPcGVuICYmIGFjdGl2ZVNlYXJjaEZpbHRlciAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17dHJ1ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNTZWFyY2hNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17aGFuZGxlU2VsZWN0RnJvbU1vZGFsfVxuICAgICAgICAgICAgICAgICAgICBjb25maWc9e1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8g4pyFIFBhcmEgcHJvZHVjdG9zLCB1c2FyIGFydGljdWxvc01vZHVsZUNvbmZpZyBkaXJlY3RhbWVudGUgKHRpZW5lIGNvZGVGaWVsZDogJ3NrdScgY29uZmlndXJhZG8pXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLnJlc291cmNlID09PSAncHJvZHVjdHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBhcnRpY3Vsb3NNb2R1bGVDb25maWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZHBvaW50OiBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLmFwaV9lbmRwb2ludD8uc3BsaXQoJz8nKVswXSB8fCBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLnJlc291cmNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVOYW1lOiBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLnJlc291cmNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2R1bGVOYW1lUGx1cmFsOiBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLnJlc291cmNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlUm91dGU6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaXN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBoZWFkZXI6ICdJRCAvIEPDs2RpZ28nLCBhY2Nlc3NvcjogYWN0aXZlU2VhcmNoRmlsdGVyLmNvbmZpZy5jb2RlX2ZpZWxkIHx8IGFjdGl2ZVNlYXJjaEZpbHRlci5jb25maWcudmFsdWVfZmllbGQgfHwgJ2lkJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaGVhZGVyOiAnTm9tYnJlJywgYWNjZXNzb3I6IGFjdGl2ZVNlYXJjaEZpbHRlci5jb25maWcubGFiZWxfZmllbGQgfHwgJ25hbWUnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldGFpbDogeyBkaXNwbGF5TmFtZUtleTogYWN0aXZlU2VhcmNoRmlsdGVyLmNvbmZpZy5sYWJlbF9maWVsZCB8fCAnbmFtZScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsYXRpb25hbEZpZWxkczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWRGaWVsZDogYWN0aXZlU2VhcmNoRmlsdGVyLmNvbmZpZy52YWx1ZV9maWVsZCB8fCAnaWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZUZpZWxkOiBhY3RpdmVTZWFyY2hGaWx0ZXIuY29uZmlnLmxhYmVsX2ZpZWxkIHx8ICduYW1lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVGaWVsZDogYWN0aXZlU2VhcmNoRmlsdGVyLmNvbmZpZy5jb2RlX2ZpZWxkIHx8IGFjdGl2ZVNlYXJjaEZpbHRlci5jb25maWcudmFsdWVfZmllbGQgfHwgJ2lkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtOiB7IGJsb2NrOiBbXSB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBhcyBhbnkpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3JlcG9ydGVzL3BhZ2VzL1JlcG9ydGVzUnVubmVyUGFnZS50c3gifQ==