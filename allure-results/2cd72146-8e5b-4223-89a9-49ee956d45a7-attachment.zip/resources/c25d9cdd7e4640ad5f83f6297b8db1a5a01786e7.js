import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GenericCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/GenericCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { FaPencilAlt, FaRegTrashAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const GenericCard = ({
  item,
  columns,
  baseRoute,
  onDelete,
  disableEdit,
  onRowClick,
  canEdit = true,
  canDelete = true,
  enableRowSelection = false,
  selected = false,
  onToggleSelect
}) => {
  _s();
  const navigate = useNavigate();
  const canEditItem = typeof canEdit === "function" ? canEdit(item) : canEdit;
  const canDeleteItem = typeof canDelete === "function" ? canDelete(item) : canDelete;
  const handleCardClick = () => {
    if (onRowClick) {
      onRowClick(item);
    } else {
      navigate(`${baseRoute}/${item.id}`);
    }
  };
  const handleEdit = (e, id) => {
    e.stopPropagation();
    navigate(`${baseRoute}/${id}/editar`);
  };
  const handleDelete = (e, id) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete(id);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { onClick: handleCardClick, className: "p-4 bg-white border rounded-lg shadow-sm cursor-pointer hover:shadow-md", children: [
    enableRowSelection && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", onClick: (e) => e.stopPropagation(), children: /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "checkbox",
        checked: selected,
        onChange: () => onToggleSelect?.(),
        "aria-label": `Seleccionar ${item.id}`,
        className: "w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500",
        autoComplete: "off"
      },
      void 0,
      false,
      {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 84,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/common/GenericCard.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: columns.map(
      (col) => /* @__PURE__ */ jsxDEV("div", { className: "text-sm", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: [
          col.header,
          ": "
        ] }, void 0, true, {
          fileName: "/app/src/components/common/GenericCard.tsx",
          lineNumber: 95,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: col.render ? col.render(item) : item[col.accessor] }, void 0, false, {
          fileName: "/app/src/components/common/GenericCard.tsx",
          lineNumber: 96,
          columnNumber: 25
        }, this)
      ] }, String(col.accessor), true, {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/app/src/components/common/GenericCard.tsx",
      lineNumber: 92,
      columnNumber: 13
    }, this),
    (canEditItem || canDeleteItem) && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end pt-3 mt-3 border-t", children: [
      !disableEdit && canEditItem && /* @__PURE__ */ jsxDEV("button", { onClick: (e) => handleEdit(e, item.id), className: "text-indigo-600 hover:text-indigo-900", children: /* @__PURE__ */ jsxDEV(FaPencilAlt, {}, void 0, false, {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 107,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this),
      canDeleteItem && /* @__PURE__ */ jsxDEV("button", { onClick: (e) => handleDelete(e, item.id), className: `${canEditItem ? "ml-4" : ""} text-red-600 hover:text-red-900`, children: /* @__PURE__ */ jsxDEV(FaRegTrashAlt, {}, void 0, false, {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 112,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "/app/src/components/common/GenericCard.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/common/GenericCard.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/common/GenericCard.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
};
_s(GenericCard, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = GenericCard;
var _c;
$RefreshReg$(_c, "GenericCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/GenericCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/GenericCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5RHBCLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWFDLHFCQUFxQjtBQWlCcEMsYUFBTUMsY0FBYyxDQUF3QjtBQUFBLEVBQy9DQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUFBLEVBQ1pDLHFCQUFxQjtBQUFBLEVBQ3JCQyxXQUFXO0FBQUEsRUFDWEM7QUFDaUIsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU1DLFdBQVdoQixZQUFZO0FBRzdCLFFBQU1pQixjQUFjLE9BQU9QLFlBQVksYUFBYUEsUUFBUU4sSUFBSSxJQUFJTTtBQUNwRSxRQUFNUSxnQkFBZ0IsT0FBT1AsY0FBYyxhQUFhQSxVQUFVUCxJQUFJLElBQUlPO0FBRTFFLFFBQU1RLGtCQUFrQkEsTUFBTTtBQUMxQixRQUFJVixZQUFZO0FBQ1pBLGlCQUFXTCxJQUFJO0FBQUEsSUFDbkIsT0FBTztBQUNIWSxlQUFTLEdBQUdWLFNBQVMsSUFBSUYsS0FBS2dCLEVBQUUsRUFBRTtBQUFBLElBQ3RDO0FBQUEsRUFDSjtBQUVBLFFBQU1DLGFBQWFBLENBQUNDLEdBQXFCRixPQUFZO0FBQ2pERSxNQUFFQyxnQkFBZ0I7QUFDbEJQLGFBQVMsR0FBR1YsU0FBUyxJQUFJYyxFQUFFLFNBQVM7QUFBQSxFQUN4QztBQUVBLFFBQU1JLGVBQWVBLENBQUNGLEdBQXFCRixPQUFZO0FBQ25ERSxNQUFFQyxnQkFBZ0I7QUFDbEIsUUFBSWhCLFVBQVU7QUFDVkEsZUFBU2EsRUFBRTtBQUFBLElBQ2Y7QUFBQSxFQUNKO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFNBQVNELGlCQUFpQixXQUFVLDJFQUNwQ1A7QUFBQUEsMEJBQ0csdUJBQUMsU0FBSSxXQUFVLFFBQU8sU0FBUyxDQUFBVSxNQUFLQSxFQUFFQyxnQkFBZ0IsR0FDbEQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFNBQVNWO0FBQUFBLFFBQ1QsVUFBVSxNQUFNQyxpQkFBaUI7QUFBQSxRQUNqQyxjQUFZLGVBQWVWLEtBQUtnQixFQUFFO0FBQUEsUUFDbEMsV0FBVTtBQUFBLFFBQXdFLGNBQWE7QUFBQTtBQUFBLE1BTG5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt3RyxLQU41RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVKLHVCQUFDLFNBQUksV0FBVSxhQUNWZixrQkFBUW9CO0FBQUFBLE1BQUksQ0FBQ0MsUUFDVix1QkFBQyxTQUErQixXQUFVLFdBQ3RDO0FBQUEsK0JBQUMsVUFBSyxXQUFVLCtCQUErQkE7QUFBQUEsY0FBSUM7QUFBQUEsVUFBTztBQUFBLGFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUM1RCx1QkFBQyxVQUFLLFdBQVUsaUJBQ1hELGNBQUlFLFNBQVNGLElBQUlFLE9BQU94QixJQUFJLElBQUtBLEtBQUtzQixJQUFJRyxRQUFRLEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSk1DLE9BQU9KLElBQUlHLFFBQVEsR0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsSUFDSCxLQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLEtBRUVaLGVBQWVDLGtCQUNiLHVCQUFDLFNBQUksV0FBVSxvREFDVjtBQUFBLE9BQUNWLGVBQWVTLGVBQ2IsdUJBQUMsWUFBTyxTQUFTLENBQUNLLE1BQU1ELFdBQVdDLEdBQUdsQixLQUFLZ0IsRUFBRSxHQUFHLFdBQVUseUNBQ3RELGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVIRixpQkFDRyx1QkFBQyxZQUFPLFNBQVMsQ0FBQ0ksTUFBTUUsYUFBYUYsR0FBR2xCLEtBQUtnQixFQUFFLEdBQUcsV0FBVyxHQUFHSCxjQUFjLFNBQVMsRUFBRSxvQ0FDckYsaUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FsQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQTtBQUVSO0FBQUVGLEdBOUVXWixhQUFXO0FBQUEsVUFhSEgsV0FBVztBQUFBO0FBQUErQixLQWJuQjVCO0FBQVcsSUFBQTRCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZU5hdmlnYXRlIiwiRmFQZW5jaWxBbHQiLCJGYVJlZ1RyYXNoQWx0IiwiR2VuZXJpY0NhcmQiLCJpdGVtIiwiY29sdW1ucyIsImJhc2VSb3V0ZSIsIm9uRGVsZXRlIiwiZGlzYWJsZUVkaXQiLCJvblJvd0NsaWNrIiwiY2FuRWRpdCIsImNhbkRlbGV0ZSIsImVuYWJsZVJvd1NlbGVjdGlvbiIsInNlbGVjdGVkIiwib25Ub2dnbGVTZWxlY3QiLCJfcyIsIm5hdmlnYXRlIiwiY2FuRWRpdEl0ZW0iLCJjYW5EZWxldGVJdGVtIiwiaGFuZGxlQ2FyZENsaWNrIiwiaWQiLCJoYW5kbGVFZGl0IiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsImhhbmRsZURlbGV0ZSIsIm1hcCIsImNvbCIsImhlYWRlciIsInJlbmRlciIsImFjY2Vzc29yIiwiU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2VuZXJpY0NhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbi8vIHNyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljQ2FyZC50c3hcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgRmFQZW5jaWxBbHQsIEZhUmVnVHJhc2hBbHQgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgdHlwZSB7IENvbHVtbkRlZmluaXRpb24gfSBmcm9tICcuL0dlbmVyaWNMaXN0UGFnZSc7XG5cbmludGVyZmFjZSBHZW5lcmljQ2FyZFByb3BzPFQgZXh0ZW5kcyB7IGlkOiBhbnkgfT4ge1xuICAgIGl0ZW06IFQ7XG4gICAgY29sdW1uczogQ29sdW1uRGVmaW5pdGlvbjxUPltdO1xuICAgIGJhc2VSb3V0ZTogc3RyaW5nO1xuICAgIG9uRGVsZXRlPzogKGlkOiBudW1iZXIgfCBzdHJpbmcpID0+IHZvaWQ7XG4gICAgZGlzYWJsZUVkaXQ/OiBib29sZWFuO1xuICAgIG9uUm93Q2xpY2s/OiAoaXRlbTogYW55KSA9PiB2b2lkO1xuICAgIGNhbkVkaXQ/OiBib29sZWFuIHwgKChpdGVtOiBUKSA9PiBib29sZWFuKTsgLy8g4pyFIFBlcm1pc28gcGFyYSBlZGl0YXIgKHB1ZWRlIHNlciBmdW5jacOzbilcbiAgICBjYW5EZWxldGU/OiBib29sZWFuIHwgKChpdGVtOiBUKSA9PiBib29sZWFuKTsgLy8g4pyFIFBlcm1pc28gcGFyYSBlbGltaW5hciAocHVlZGUgc2VyIGZ1bmNpw7NuKVxuICAgIGVuYWJsZVJvd1NlbGVjdGlvbj86IGJvb2xlYW47XG4gICAgc2VsZWN0ZWQ/OiBib29sZWFuO1xuICAgIG9uVG9nZ2xlU2VsZWN0PzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEdlbmVyaWNDYXJkID0gPFQgZXh0ZW5kcyB7IGlkOiBhbnkgfT4oe1xuICAgIGl0ZW0sXG4gICAgY29sdW1ucyxcbiAgICBiYXNlUm91dGUsXG4gICAgb25EZWxldGUsXG4gICAgZGlzYWJsZUVkaXQsXG4gICAgb25Sb3dDbGljayxcbiAgICBjYW5FZGl0ID0gdHJ1ZSxcbiAgICBjYW5EZWxldGUgPSB0cnVlLFxuICAgIGVuYWJsZVJvd1NlbGVjdGlvbiA9IGZhbHNlLFxuICAgIHNlbGVjdGVkID0gZmFsc2UsXG4gICAgb25Ub2dnbGVTZWxlY3QsXG59OiBHZW5lcmljQ2FyZFByb3BzPFQ+KSA9PiB7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gICAgLy8g4pyFIE5VRVZPOiBIZWxwZXJzIHBhcmEgZXZhbHVhciBjYW5FZGl0L2NhbkRlbGV0ZSAocHVlZGVuIHNlciBmdW5jaW9uZXMgbyBib29sZWFub3MpXG4gICAgY29uc3QgY2FuRWRpdEl0ZW0gPSB0eXBlb2YgY2FuRWRpdCA9PT0gJ2Z1bmN0aW9uJyA/IGNhbkVkaXQoaXRlbSkgOiBjYW5FZGl0O1xuICAgIGNvbnN0IGNhbkRlbGV0ZUl0ZW0gPSB0eXBlb2YgY2FuRGVsZXRlID09PSAnZnVuY3Rpb24nID8gY2FuRGVsZXRlKGl0ZW0pIDogY2FuRGVsZXRlO1xuXG4gICAgY29uc3QgaGFuZGxlQ2FyZENsaWNrID0gKCkgPT4ge1xuICAgICAgICBpZiAob25Sb3dDbGljaykge1xuICAgICAgICAgICAgb25Sb3dDbGljayhpdGVtKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5hdmlnYXRlKGAke2Jhc2VSb3V0ZX0vJHtpdGVtLmlkfWApO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUVkaXQgPSAoZTogUmVhY3QuTW91c2VFdmVudCwgaWQ6IGFueSkgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpOyAvLyBFdml0YSBxdWUgZWwgY2xpYyBzZSBwcm9wYWd1ZSBhbCA8dHI+XG4gICAgICAgIG5hdmlnYXRlKGAke2Jhc2VSb3V0ZX0vJHtpZH0vZWRpdGFyYCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZSA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50LCBpZDogYW55KSA9PiB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGlmIChvbkRlbGV0ZSkgeyAvLyA8LS0gVVNBUiBQUk9QXG4gICAgICAgICAgICBvbkRlbGV0ZShpZCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBvbkNsaWNrPXtoYW5kbGVDYXJkQ2xpY2t9IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSBib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctc20gY3Vyc29yLXBvaW50ZXIgaG92ZXI6c2hhZG93LW1kXCI+XG4gICAgICAgICAgICB7ZW5hYmxlUm93U2VsZWN0aW9uICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIiBvbkNsaWNrPXtlID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBvblRvZ2dsZVNlbGVjdD8uKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgU2VsZWNjaW9uYXIgJHtpdGVtLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTYwMCBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpyaW5nLWluZGlnby01MDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAge2NvbHVtbnMubWFwKChjb2wpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e1N0cmluZyhjb2wuYWNjZXNzb3IpfSBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57Y29sLmhlYWRlcn06IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29sLnJlbmRlciA/IGNvbC5yZW5kZXIoaXRlbSkgOiAoaXRlbVtjb2wuYWNjZXNzb3JdIGFzIFJlYWN0LlJlYWN0Tm9kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7LyogRm9vdGVyIGRlIGxhIHRhcmpldGEgY29uIGxhcyBhY2Npb25lcyAqL31cbiAgICAgICAgICAgIHsoY2FuRWRpdEl0ZW0gfHwgY2FuRGVsZXRlSXRlbSkgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHQtMyBtdC0zIGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgICAgIHshZGlzYWJsZUVkaXQgJiYgY2FuRWRpdEl0ZW0gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlRWRpdChlLCBpdGVtLmlkKX0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVBlbmNpbEFsdCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHtjYW5EZWxldGVJdGVtICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KGUpID0+IGhhbmRsZURlbGV0ZShlLCBpdGVtLmlkKX0gY2xhc3NOYW1lPXtgJHtjYW5FZGl0SXRlbSA/ICdtbC00JyA6ICcnfSB0ZXh0LXJlZC02MDAgaG92ZXI6dGV4dC1yZWQtOTAwYH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUmVnVHJhc2hBbHQgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljQ2FyZC50c3gifQ==