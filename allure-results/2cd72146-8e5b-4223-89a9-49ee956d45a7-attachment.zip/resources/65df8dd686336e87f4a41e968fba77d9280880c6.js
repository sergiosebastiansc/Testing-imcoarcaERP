import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { notasCreditoCompraModuleConfig } from "/src/features/notas_credito_compra/notas_credito_compra.config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getModuleBasePermission, getRequiredPermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const NotasCreditoCompraListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(notasCreditoCompraModuleConfig, getDefaultListDateRange());
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(notasCreditoCompraModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const hasEditPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const hasDeletePermission = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEdit = (_note) => hasEditPermission;
  const canDelete = (_note) => hasDeletePermission;
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: notasCreditoCompraModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit,
      canDelete
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx",
      lineNumber: 45,
      columnNumber: 5
    },
    this
  );
};
_s(NotasCreditoCompraListPage, "yjB/rutd0ICjbFA72BDSbAuQTHI=", false, function() {
  return [useCrud, usePermissions];
});
_c = NotasCreditoCompraListPage;
var _c;
$RefreshReg$(_c, "NotasCreditoCompraListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito_compra/pages/NotasCreditoCompraListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHNDQUErRDtBQUN4RSxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCQyw2QkFBNkI7QUFDL0QsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLDZCQUE2QkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJbkIsUUFBNEJDLGdDQUFnQ0ksd0JBQXdCLENBQUM7QUFFekYsUUFBTSxFQUFFZSxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTW1CLG1CQUFtQmpCLHNCQUFzQkgsK0JBQStCcUIsU0FBUztBQUN2RixRQUFNQyxhQUFhRixtQkFBbUJsQix3QkFBd0JrQixnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxvQkFBb0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFDakYsUUFBTUUsc0JBQXNCRixhQUFhSCxvQkFBb0JHLFlBQVksUUFBUSxJQUFJO0FBRXJGLFFBQU1HLFVBQVVBLENBQUNDLFVBQThCSDtBQUMvQyxRQUFNSSxZQUFZQSxDQUFDRCxVQUE4QkY7QUFFakQsTUFBSWQsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRXZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFWO0FBQUFBLE1BQ1Isb0JBQW9CTztBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFVLFFBQVE7QUFBQSxNQUNqQyxpQkFBaUJWLGFBQWFXLGFBQWE7QUFBQSxNQUMzQyxlQUFlWCxhQUFhWSxXQUFXO0FBQUEsTUFDdkMsdUJBQXVCO0FBQUEsTUFDdkI7QUFBQSxNQUNBO0FBQUE7QUFBQSxJQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQnlCO0FBR2pDO0FBQUV4QixHQXRDV0QsNEJBQTBCO0FBQUEsVUFJL0JOLFNBRTRCRSxjQUFjO0FBQUE7QUFBQThCLEtBTnJDMUI7QUFBMEIsSUFBQTBCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwibm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnIiwidXNlUGVybWlzc2lvbnMiLCJnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImdldERlZmF1bHRMaXN0RGF0ZVJhbmdlIiwiTm90YXNDcmVkaXRvQ29tcHJhTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJoYXNFZGl0UGVybWlzc2lvbiIsImhhc0RlbGV0ZVBlcm1pc3Npb24iLCJjYW5FZGl0IiwiX25vdGUiLCJjYW5EZWxldGUiLCJ0ZXJtIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGFzQ3JlZGl0b0NvbXByYUxpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgbm90YXNDcmVkaXRvQ29tcHJhTW9kdWxlQ29uZmlnLCB0eXBlIFB1cmNoYXNlQ3JlZGl0Tm90ZSB9IGZyb20gJy4uL25vdGFzX2NyZWRpdG9fY29tcHJhLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uLCBnZXRSZXF1aXJlZFBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuXG5leHBvcnQgY29uc3QgTm90YXNDcmVkaXRvQ29tcHJhTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxQdXJjaGFzZUNyZWRpdE5vdGU+KG5vdGFzQ3JlZGl0b0NvbXByYU1vZHVsZUNvbmZpZywgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UoKSk7XG5cbiAgICBjb25zdCB7IGhhc01vZHVsZVBlcm1pc3Npb24gfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gICAgY29uc3QgbW9kdWxlUGVybWlzc2lvbiA9IGdldFJlcXVpcmVkUGVybWlzc2lvbihub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBoYXNFZGl0UGVybWlzc2lvbiA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdlZGl0JykgOiB0cnVlO1xuICAgIGNvbnN0IGhhc0RlbGV0ZVBlcm1pc3Npb24gPSBtb2R1bGVCYXNlID8gaGFzTW9kdWxlUGVybWlzc2lvbihtb2R1bGVCYXNlLCAnZGVsZXRlJykgOiB0cnVlO1xuXG4gICAgY29uc3QgY2FuRWRpdCA9IChfbm90ZTogUHVyY2hhc2VDcmVkaXROb3RlKSA9PiBoYXNFZGl0UGVybWlzc2lvbjtcbiAgICBjb25zdCBjYW5EZWxldGUgPSAoX25vdGU6IFB1cmNoYXNlQ3JlZGl0Tm90ZSkgPT4gaGFzRGVsZXRlUGVybWlzc2lvbjtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8UHVyY2hhc2VDcmVkaXROb3RlPlxuICAgICAgICAgICAgY29uZmlnPXtub3Rhc0NyZWRpdG9Db21wcmFNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfVxuICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgc2VhcmNoVGVybT17c2VhcmNoUGFyYW1zLnRlcm0gPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyU3RhcnQ9e3NlYXJjaFBhcmFtcy5zdGFydERhdGUgPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyRW5kPXtzZWFyY2hQYXJhbXMuZW5kRGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlcj17dHJ1ZX1cbiAgICAgICAgICAgIGNhbkVkaXQ9e2NhbkVkaXR9XG4gICAgICAgICAgICBjYW5EZWxldGU9e2NhbkRlbGV0ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbm90YXNfY3JlZGl0b19jb21wcmEvcGFnZXMvTm90YXNDcmVkaXRvQ29tcHJhTGlzdFBhZ2UudHN4In0=