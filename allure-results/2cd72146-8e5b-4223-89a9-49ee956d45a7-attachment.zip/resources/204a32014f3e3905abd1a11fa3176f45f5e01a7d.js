import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/usuarios/pages/UsuariosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/usuarios/pages/UsuariosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { usuariosModuleConfig } from "/src/features/usuarios/usuarios.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
export const UsuariosListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(usuariosModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/usuarios/pages/UsuariosListPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return (
    // ✅ Se pasan todas las props nuevas a GenericListPage
    /* @__PURE__ */ jsxDEV(
      GenericListPage,
      {
        config: usuariosModuleConfig,
        paginationResponse: response,
        loading,
        isAppending,
        onDelete: deleteItem,
        onSort: handleSort,
        sortBy,
        sortDirection,
        onPageChange: handlePageChange,
        onLoadMore: handleLoadMore,
        onSearch: handleSearch,
        searchTerm: searchParams.term ?? ""
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/usuarios/pages/UsuariosListPage.tsx",
        lineNumber: 46,
        columnNumber: 5
      },
      this
    )
  );
};
_s(UsuariosListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = UsuariosListPage;
var _c;
$RefreshReg$(_c, "UsuariosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/usuarios/pages/UsuariosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/usuarios/pages/UsuariosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyw0QkFBMEM7QUFDbkQsU0FBU0MsZUFBZTtBQUVqQixhQUFNQyxtQkFBbUJBLE1BQU07QUFBQUMsS0FBQTtBQUVsQyxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZCxRQUFpQkQsb0JBQW9CO0FBRXpDLE1BQUlPLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RDtBQUFBO0FBQUEsSUFFSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUVA7QUFBQUEsUUFDUixvQkFBb0JJO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVUk7QUFBQUEsUUFDVixRQUFRQztBQUFBQSxRQUNSO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBY0c7QUFBQUEsUUFDZCxZQUFZQztBQUFBQSxRQUNaLFVBQVVDO0FBQUFBLFFBQ1YsWUFBWUMsYUFBYUMsUUFBUTtBQUFBO0FBQUEsTUFackM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWXdDO0FBQUE7QUFHaEQ7QUFBRWIsR0FwQ1dELGtCQUFnQjtBQUFBLFVBZXJCRCxPQUFPO0FBQUE7QUFBQWdCLEtBZkZmO0FBQWdCLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c3Vhcmlvc01vZHVsZUNvbmZpZyIsInVzZUNydWQiLCJVc3Vhcmlvc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVzdWFyaW9zTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3Vhcmlvc0xpc3RQYWdlLnRzeFxuaW1wb3J0IHsgR2VuZXJpY0xpc3RQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0xpc3RQYWdlJztcbmltcG9ydCB7IHVzdWFyaW9zTW9kdWxlQ29uZmlnLCB0eXBlIFVzdWFyaW8gfSBmcm9tICcuLi91c3Vhcmlvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuXG5leHBvcnQgY29uc3QgVXN1YXJpb3NMaXN0UGFnZSA9ICgpID0+IHtcbiAgICAvLyDinIUgU2UgZGVzZXN0cnVjdHVyYSBsYSBudWV2YSBpbnRlcmZheiBjb21wbGV0YSBkZWwgaG9vayB1c2VDcnVkXG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxVc3VhcmlvPih1c3Vhcmlvc01vZHVsZUNvbmZpZyk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAvLyDinIUgU2UgcGFzYW4gdG9kYXMgbGFzIHByb3BzIG51ZXZhcyBhIEdlbmVyaWNMaXN0UGFnZVxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPFVzdWFyaW8+XG4gICAgICAgICAgICBjb25maWc9e3VzdWFyaW9zTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy91c3Vhcmlvcy9wYWdlcy9Vc3Vhcmlvc0xpc3RQYWdlLnRzeCJ9