import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const PlanDeCuentasDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: planDeCuentas, loading, error } = useCrudItem(planDeCuentasModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle de la cuenta..." }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx",
    lineNumber: 29,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 21
  }, this);
  if (!planDeCuentas) return /* @__PURE__ */ jsxDEV("div", { children: "Cuenta no encontrada." }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 30
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: planDeCuentasModuleConfig, item: planDeCuentas }, void 0, false, {
    fileName: "/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(PlanDeCuentasDetailPage, "cEfas7LKZ+mC31c8hdWFcwA5s7M=", false, function() {
  return [useParams, useCrudItem];
});
_c = PlanDeCuentasDetailPage;
var _c;
$RefreshReg$(_c, "PlanDeCuentasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/plan_de_cuentas/pages/PlanDeCuentasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGlDQUFxRDtBQUM5RCxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsMEJBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsZUFBZUMsU0FBU0MsTUFBTSxJQUFJUCxZQUEyQkQsMkJBQTJCSSxFQUFFO0FBRXhHLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGdEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDekQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsY0FBZSxRQUFPLHVCQUFDLFNBQUkscUNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQjtBQUVyRCxTQUFPLHVCQUFDLHFCQUFrQixRQUFRTiwyQkFBMkIsTUFBTU0saUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEU7QUFDckY7QUFBRUgsR0FUV0QseUJBQXVCO0FBQUEsVUFDakJKLFdBQ2lDRyxXQUFXO0FBQUE7QUFBQVEsS0FGbERQO0FBQXVCLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJHZW5lcmljRGV0YWlsUGFnZSIsInBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIlBsYW5EZUN1ZW50YXNEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJwbGFuRGVDdWVudGFzIiwibG9hZGluZyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGxhbkRlQ3VlbnRhc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLCB0eXBlIFBsYW5EZUN1ZW50YXMgfSBmcm9tICcuLi9wbGFuX2RlX2N1ZW50YXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuXG5leHBvcnQgY29uc3QgUGxhbkRlQ3VlbnRhc0RldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbTogcGxhbkRlQ3VlbnRhcywgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFBsYW5EZUN1ZW50YXM+KHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkZXRhbGxlIGRlIGxhIGN1ZW50YS4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFwbGFuRGVDdWVudGFzKSByZXR1cm4gPGRpdj5DdWVudGEgbm8gZW5jb250cmFkYS48L2Rpdj47XG5cbiAgICByZXR1cm4gPEdlbmVyaWNEZXRhaWxQYWdlIGNvbmZpZz17cGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZ30gaXRlbT17cGxhbkRlQ3VlbnRhc30gLz47XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wbGFuX2RlX2N1ZW50YXMvcGFnZXMvUGxhbkRlQ3VlbnRhc0RldGFpbFBhZ2UudHN4In0=