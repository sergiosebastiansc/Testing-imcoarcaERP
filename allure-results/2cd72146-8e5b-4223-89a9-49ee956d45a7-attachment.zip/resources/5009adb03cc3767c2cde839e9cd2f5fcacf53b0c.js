import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { comisionesVendedoresConfig } from "/src/features/comisiones_vendedores/comisiones_vendedores.config.tsx";
import { create, getAll } from "/src/services/apiService.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
function unwrapResource(body) {
  if (body && typeof body === "object" && "data" in body) {
    return body.data;
  }
  return body;
}
const initial = {
  id: 0,
  margin_from: 0,
  margin_to: "",
  commission_rate: 0,
  is_active: true
};
export const ComisionesVendedoresCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const handleSave = async (data) => {
    const marginToRaw = data.margin_to;
    const margin_to = marginToRaw === null || marginToRaw === void 0 || typeof marginToRaw === "string" && marginToRaw.trim() === "" ? null : Number(marginToRaw);
    if (margin_to !== null && (Number.isNaN(margin_to) || margin_to < 0)) {
      toast.error('El margen "hasta" no es un número válido.');
      return;
    }
    const margin_from = Number(data.margin_from);
    if (Number.isNaN(margin_from) || margin_from < 0) {
      toast.error('El margen "desde" no es válido.');
      return;
    }
    if (margin_to !== null && margin_to < margin_from) {
      toast.error('El margen "hasta" debe ser mayor o igual al "desde".');
      return;
    }
    let sort_order;
    try {
      const listRes = await getAll(comisionesVendedoresConfig.endpoint);
      const rows = listRes.data ?? [];
      sort_order = rows.length === 0 ? 0 : Math.max(...rows.map((r) => r.sort_order), 0) + 1;
    } catch (e) {
      console.error(e);
      toast.error("No se pudo calcular el orden del tramo. Intenta de nuevo.");
      return;
    }
    const payload = {
      margin_from,
      margin_to,
      commission_rate: Number(data.commission_rate),
      sort_order,
      is_active: Boolean(data.is_active)
    };
    try {
      const res = await create(comisionesVendedoresConfig.endpoint, payload);
      const created = unwrapResource(res);
      if (created && created.id != null) {
        toast.info("Tramo creado correctamente.");
        navigate(getListReturnPath(comisionesVendedoresConfig.baseRoute));
      }
    } catch (e) {
      console.error(e);
      const msg = e?.response?.data?.message;
      if (typeof msg === "string") toast.error(msg);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: comisionesVendedoresConfig,
      initialData: initial,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx",
      lineNumber: 110,
      columnNumber: 5
    },
    this
  );
};
_s(ComisionesVendedoresCreatePage, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = ComisionesVendedoresCreatePage;
var _c;
$RefreshReg$(_c, "ComisionesVendedoresCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/comisiones_vendedores/pages/ComisionesVendedoresCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFGUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGtDQUE2RDtBQUN0RSxTQUFTQyxRQUFRQyxjQUFjO0FBQy9CLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBRWxDLFNBQVNDLGVBQWtCQyxNQUFrQjtBQUN6QyxNQUFJQSxRQUFRLE9BQU9BLFNBQVMsWUFBWSxVQUFXQSxNQUFpQjtBQUNoRSxXQUFRQSxLQUFxQkM7QUFBQUEsRUFDakM7QUFDQSxTQUFPRDtBQUNYO0FBR0EsTUFBTUUsVUFBVTtBQUFBLEVBQ1pDLElBQUk7QUFBQSxFQUNKQyxhQUFhO0FBQUEsRUFDYkMsV0FBVztBQUFBLEVBQ1hDLGlCQUFpQjtBQUFBLEVBQ2pCQyxXQUFXO0FBQ2Y7QUFFTyxhQUFNQyxpQ0FBaUNBLE1BQU07QUFBQUMsS0FBQTtBQUNoRCxRQUFNQyxXQUFXbEIsWUFBWTtBQUU3QixRQUFNbUIsYUFBYSxPQUFPVixTQUErQjtBQUdyRCxVQUFNVyxjQUFlWCxLQUFhSTtBQUNsQyxVQUFNQSxZQUNGTyxnQkFBZ0IsUUFDaEJBLGdCQUFnQkMsVUFDZixPQUFPRCxnQkFBZ0IsWUFBWUEsWUFBWUUsS0FBSyxNQUFNLEtBQ3JELE9BQ0FDLE9BQU9ILFdBQVc7QUFFNUIsUUFBSVAsY0FBYyxTQUFTVSxPQUFPQyxNQUFNWCxTQUFTLEtBQUtBLFlBQVksSUFBSTtBQUNsRVIsWUFBTW9CLE1BQU0sMkNBQTJDO0FBQ3ZEO0FBQUEsSUFDSjtBQUVBLFVBQU1iLGNBQWNXLE9BQU9kLEtBQUtHLFdBQVc7QUFDM0MsUUFBSVcsT0FBT0MsTUFBTVosV0FBVyxLQUFLQSxjQUFjLEdBQUc7QUFDOUNQLFlBQU1vQixNQUFNLGlDQUFpQztBQUM3QztBQUFBLElBQ0o7QUFFQSxRQUFJWixjQUFjLFFBQVFBLFlBQVlELGFBQWE7QUFDL0NQLFlBQU1vQixNQUFNLHNEQUFzRDtBQUNsRTtBQUFBLElBQ0o7QUFFQSxRQUFJQztBQUNKLFFBQUk7QUFDQSxZQUFNQyxVQUFVLE1BQU12QixPQUE2QkYsMkJBQTJCMEIsUUFBUTtBQUN0RixZQUFNQyxPQUFPRixRQUFRbEIsUUFBUTtBQUM3QmlCLG1CQUFhRyxLQUFLQyxXQUFXLElBQUksSUFBSUMsS0FBS0MsSUFBSSxHQUFHSCxLQUFLSSxJQUFJLENBQUNDLE1BQU1BLEVBQUVSLFVBQVUsR0FBRyxDQUFDLElBQUk7QUFBQSxJQUN6RixTQUFTUyxHQUFHO0FBQ1JDLGNBQVFYLE1BQU1VLENBQUM7QUFDZjlCLFlBQU1vQixNQUFNLDJEQUEyRDtBQUN2RTtBQUFBLElBQ0o7QUFFQSxVQUFNWSxVQUFVO0FBQUEsTUFDWnpCO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDLGlCQUFpQlMsT0FBT2QsS0FBS0ssZUFBZTtBQUFBLE1BQzVDWTtBQUFBQSxNQUNBWCxXQUFXdUIsUUFBUTdCLEtBQUtNLFNBQVM7QUFBQSxJQUNyQztBQUVBLFFBQUk7QUFFQSxZQUFNd0IsTUFBTSxNQUFNcEMsT0FBWUQsMkJBQTJCMEIsVUFBVVMsT0FBTztBQUMxRSxZQUFNRyxVQUFVakMsZUFBcUNnQyxHQUFHO0FBQ3hELFVBQUlDLFdBQVdBLFFBQVE3QixNQUFNLE1BQU07QUFDL0JOLGNBQU1vQyxLQUFLLDZCQUE2QjtBQUN4Q3ZCLGlCQUFTWixrQkFBa0JKLDJCQUEyQndDLFNBQVMsQ0FBQztBQUFBLE1BQ3BFO0FBQUEsSUFDSixTQUFTUCxHQUFHO0FBQ1JDLGNBQVFYLE1BQU1VLENBQUM7QUFHZixZQUFNUSxNQUFPUixHQUFXUyxVQUFVbkMsTUFBTW9DO0FBQ3hDLFVBQUksT0FBT0YsUUFBUSxTQUFVdEMsT0FBTW9CLE1BQU1rQixHQUFHO0FBQUEsSUFDaEQ7QUFBQSxFQUNKO0FBRUEsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUXpDO0FBQUFBLE1BQ1IsYUFBYVE7QUFBQUEsTUFDYixRQUFRUztBQUFBQSxNQUNSLE1BQUs7QUFBQTtBQUFBLElBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWlCO0FBR3pCO0FBQUVGLEdBMUVXRCxnQ0FBOEI7QUFBQSxVQUN0QmhCLFdBQVc7QUFBQTtBQUFBOEMsS0FEbkI5QjtBQUE4QixJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiR2VuZXJpY0Zvcm1QYWdlIiwiY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWciLCJjcmVhdGUiLCJnZXRBbGwiLCJ0b2FzdCIsImdldExpc3RSZXR1cm5QYXRoIiwidW53cmFwUmVzb3VyY2UiLCJib2R5IiwiZGF0YSIsImluaXRpYWwiLCJpZCIsIm1hcmdpbl9mcm9tIiwibWFyZ2luX3RvIiwiY29tbWlzc2lvbl9yYXRlIiwiaXNfYWN0aXZlIiwiQ29taXNpb25lc1ZlbmRlZG9yZXNDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsImhhbmRsZVNhdmUiLCJtYXJnaW5Ub1JhdyIsInVuZGVmaW5lZCIsInRyaW0iLCJOdW1iZXIiLCJpc05hTiIsImVycm9yIiwic29ydF9vcmRlciIsImxpc3RSZXMiLCJlbmRwb2ludCIsInJvd3MiLCJsZW5ndGgiLCJNYXRoIiwibWF4IiwibWFwIiwiciIsImUiLCJjb25zb2xlIiwicGF5bG9hZCIsIkJvb2xlYW4iLCJyZXMiLCJjcmVhdGVkIiwiaW5mbyIsImJhc2VSb3V0ZSIsIm1zZyIsInJlc3BvbnNlIiwibWVzc2FnZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbWlzaW9uZXNWZW5kZWRvcmVzQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyBjb21pc2lvbmVzVmVuZGVkb3Jlc0NvbmZpZywgdHlwZSBDb21taXNzaW9uTWFyZ2luVGllciB9IGZyb20gJy4uL2NvbWlzaW9uZXNfdmVuZGVkb3Jlcy5jb25maWcnO1xuaW1wb3J0IHsgY3JlYXRlLCBnZXRBbGwgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmZ1bmN0aW9uIHVud3JhcFJlc291cmNlPFQ+KGJvZHk6IHVua25vd24pOiBUIHtcbiAgICBpZiAoYm9keSAmJiB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgJ2RhdGEnIGluIChib2R5IGFzIG9iamVjdCkpIHtcbiAgICAgICAgcmV0dXJuIChib2R5IGFzIHsgZGF0YTogVCB9KS5kYXRhO1xuICAgIH1cbiAgICByZXR1cm4gYm9keSBhcyBUO1xufVxuXG4vKiogVmFsb3JlcyBpbmljaWFsZXMgZGVsIGZvcm11bGFyaW86IGBtYXJnaW5fdG9gIHZhY8OtbyBzZSBlbnbDrWEgY29tbyBudWxsICh0ZXh0byBlbiBlbCBmb3JtKS4gKi9cbmNvbnN0IGluaXRpYWwgPSB7XG4gICAgaWQ6IDAsXG4gICAgbWFyZ2luX2Zyb206IDAsXG4gICAgbWFyZ2luX3RvOiAnJyxcbiAgICBjb21taXNzaW9uX3JhdGU6IDAsXG4gICAgaXNfYWN0aXZlOiB0cnVlLFxufSBhcyB1bmtub3duIGFzIENvbW1pc3Npb25NYXJnaW5UaWVyO1xuXG5leHBvcnQgY29uc3QgQ29taXNpb25lc1ZlbmRlZG9yZXNDcmVhdGVQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogQ29tbWlzc2lvbk1hcmdpblRpZXIpID0+IHtcbiAgICAgICAgLy8gRWwgY2FtcG8gXCJoYXN0YVwiIHNlIGNhcHR1cmEgY29tbyB0ZXh0byAodmFjw61vID0gc2luIHRvcGUpXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIGNvbnN0IG1hcmdpblRvUmF3ID0gKGRhdGEgYXMgYW55KS5tYXJnaW5fdG8gYXMgc3RyaW5nIHwgbnVtYmVyIHwgbnVsbCB8IHVuZGVmaW5lZDtcbiAgICAgICAgY29uc3QgbWFyZ2luX3RvID1cbiAgICAgICAgICAgIG1hcmdpblRvUmF3ID09PSBudWxsIHx8XG4gICAgICAgICAgICBtYXJnaW5Ub1JhdyA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgICAgICAodHlwZW9mIG1hcmdpblRvUmF3ID09PSAnc3RyaW5nJyAmJiBtYXJnaW5Ub1Jhdy50cmltKCkgPT09ICcnKVxuICAgICAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgICAgIDogTnVtYmVyKG1hcmdpblRvUmF3KTtcblxuICAgICAgICBpZiAobWFyZ2luX3RvICE9PSBudWxsICYmIChOdW1iZXIuaXNOYU4obWFyZ2luX3RvKSB8fCBtYXJnaW5fdG8gPCAwKSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIG1hcmdlbiBcImhhc3RhXCIgbm8gZXMgdW4gbsO6bWVybyB2w6FsaWRvLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbWFyZ2luX2Zyb20gPSBOdW1iZXIoZGF0YS5tYXJnaW5fZnJvbSk7XG4gICAgICAgIGlmIChOdW1iZXIuaXNOYU4obWFyZ2luX2Zyb20pIHx8IG1hcmdpbl9mcm9tIDwgMCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIG1hcmdlbiBcImRlc2RlXCIgbm8gZXMgdsOhbGlkby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChtYXJnaW5fdG8gIT09IG51bGwgJiYgbWFyZ2luX3RvIDwgbWFyZ2luX2Zyb20pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFbCBtYXJnZW4gXCJoYXN0YVwiIGRlYmUgc2VyIG1heW9yIG8gaWd1YWwgYWwgXCJkZXNkZVwiLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHNvcnRfb3JkZXI6IG51bWJlcjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGxpc3RSZXMgPSBhd2FpdCBnZXRBbGw8Q29tbWlzc2lvbk1hcmdpblRpZXI+KGNvbWlzaW9uZXNWZW5kZWRvcmVzQ29uZmlnLmVuZHBvaW50KTtcbiAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBsaXN0UmVzLmRhdGEgPz8gW107XG4gICAgICAgICAgICBzb3J0X29yZGVyID0gcm93cy5sZW5ndGggPT09IDAgPyAwIDogTWF0aC5tYXgoLi4ucm93cy5tYXAoKHIpID0+IHIuc29ydF9vcmRlciksIDApICsgMTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRvIGNhbGN1bGFyIGVsIG9yZGVuIGRlbCB0cmFtby4gSW50ZW50YSBkZSBudWV2by4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgICAgICBtYXJnaW5fZnJvbSxcbiAgICAgICAgICAgIG1hcmdpbl90byxcbiAgICAgICAgICAgIGNvbW1pc3Npb25fcmF0ZTogTnVtYmVyKGRhdGEuY29tbWlzc2lvbl9yYXRlKSxcbiAgICAgICAgICAgIHNvcnRfb3JkZXIsXG4gICAgICAgICAgICBpc19hY3RpdmU6IEJvb2xlYW4oZGF0YS5pc19hY3RpdmUpLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY3JlYXRlPGFueT4oY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcuZW5kcG9pbnQsIHBheWxvYWQpO1xuICAgICAgICAgICAgY29uc3QgY3JlYXRlZCA9IHVud3JhcFJlc291cmNlPENvbW1pc3Npb25NYXJnaW5UaWVyPihyZXMpO1xuICAgICAgICAgICAgaWYgKGNyZWF0ZWQgJiYgY3JlYXRlZC5pZCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuaW5mbygnVHJhbW8gY3JlYWRvIGNvcnJlY3RhbWVudGUuJyk7XG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgoY29taXNpb25lc1ZlbmRlZG9yZXNDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICAvLyBFcnJvcmVzIGRlIHZhbGlkYWNpw7NuOiBheGlvcyBsb3MgbGFuemE7IG1vc3RyYXIgbWVuc2FqZSBnZW7DqXJpY28gc2kgYXBsaWNhXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgY29uc3QgbXNnID0gKGUgYXMgYW55KT8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2U7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1zZyA9PT0gJ3N0cmluZycpIHRvYXN0LmVycm9yKG1zZyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNGb3JtUGFnZTxDb21taXNzaW9uTWFyZ2luVGllcj5cbiAgICAgICAgICAgIGNvbmZpZz17Y29taXNpb25lc1ZlbmRlZG9yZXNDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbH1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJjcmVhdGVcIlxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jb21pc2lvbmVzX3ZlbmRlZG9yZXMvcGFnZXMvQ29taXNpb25lc1ZlbmRlZG9yZXNDcmVhdGVQYWdlLnRzeCJ9