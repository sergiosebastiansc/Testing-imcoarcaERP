import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/impuestos/pages/ImpuestosEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/impuestos/pages/ImpuestosEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { taxesModuleConfig } from "/src/features/impuestos/impuestos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const ImpuestosEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error, saveItem } = useCrudItem(taxesModuleConfig, id);
  const handleSave = async (data) => {
    const saved = await saveItem(data);
    if (saved) {
      toast.info(`Impuesto actualizado con éxito!`);
      navigate(getListReturnPath(taxesModuleConfig.baseRoute));
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del impuesto..." }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosEditPage.tsx",
    lineNumber: 40,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosEditPage.tsx",
    lineNumber: 41,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Impuesto no encontrado." }, void 0, false, {
    fileName: "/app/src/features/impuestos/pages/ImpuestosEditPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: taxesModuleConfig,
      initialData: item,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/impuestos/pages/ImpuestosEditPage.tsx",
      lineNumber: 45,
      columnNumber: 5
    },
    this
  );
};
_s(ImpuestosEditPage, "G8hjKIGDzF+QHmsnD2By/ug4KkU=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = ImpuestosEditPage;
var _c;
$RefreshReg$(_c, "ImpuestosEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/impuestos/pages/ImpuestosEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/impuestos/pages/ImpuestosEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0J3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MseUJBQW1DO0FBQzVDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLEVBQUVDLEdBQUcsSUFBSVQsVUFBMEI7QUFDekMsUUFBTVUsV0FBV1QsWUFBWTtBQUM3QixRQUFNLEVBQUVVLE1BQU1DLFNBQVNDLE9BQU9DLFNBQVMsSUFBSVYsWUFBaUJELG1CQUFtQk0sRUFBRTtBQUVqRixRQUFNTSxhQUFhLE9BQU9DLFNBQWM7QUFDcEMsVUFBTUMsUUFBUSxNQUFNSCxTQUFTRSxJQUFJO0FBQ2pDLFFBQUlDLE9BQU87QUFDUFosWUFBTWEsS0FBSyxpQ0FBaUM7QUFDNUNSLGVBQVNKLGtCQUFrQkgsa0JBQWtCZ0IsU0FBUyxDQUFDO0FBQUEsSUFDM0Q7QUFBQSxFQUNKO0FBRUEsTUFBSVAsUUFBUyxRQUFPLHVCQUFDLFNBQUksOENBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtQztBQUN2RCxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFDdkQsTUFBSSxDQUFDRixLQUFNLFFBQU8sdUJBQUMsU0FBSSx1Q0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRCO0FBRTlDLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFSO0FBQUFBLE1BQ1IsYUFBYVE7QUFBQUEsTUFDYixRQUFRSTtBQUFBQSxNQUNSLE1BQUs7QUFBQTtBQUFBLElBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWU7QUFHdkI7QUFBRVAsR0F6QldELG1CQUFpQjtBQUFBLFVBQ1hQLFdBQ0VDLGFBQzBCRyxXQUFXO0FBQUE7QUFBQWdCLEtBSDdDYjtBQUFpQixJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJ0YXhlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJnZXRMaXN0UmV0dXJuUGF0aCIsIkltcHVlc3Rvc0VkaXRQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiaXRlbSIsImxvYWRpbmciLCJlcnJvciIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJzYXZlZCIsImluZm8iLCJiYXNlUm91dGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJbXB1ZXN0b3NFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IHRheGVzTW9kdWxlQ29uZmlnLCB0eXBlIFRheCB9IGZyb20gJy4uL2ltcHVlc3Rvcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5leHBvcnQgY29uc3QgSW1wdWVzdG9zRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW0sIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08VGF4Pih0YXhlc01vZHVsZUNvbmZpZywgaWQpO1xuXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBUYXgpID0+IHtcbiAgICAgICAgY29uc3Qgc2F2ZWQgPSBhd2FpdCBzYXZlSXRlbShkYXRhKTtcbiAgICAgICAgaWYgKHNhdmVkKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKGBJbXB1ZXN0byBhY3R1YWxpemFkbyBjb24gw6l4aXRvIWApO1xuICAgICAgICAgICAgbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgodGF4ZXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2PkNhcmdhbmRvIGRhdG9zIGRlbCBpbXB1ZXN0by4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFpdGVtKSByZXR1cm4gPGRpdj5JbXB1ZXN0byBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17dGF4ZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aXRlbX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2ltcHVlc3Rvcy9wYWdlcy9JbXB1ZXN0b3NFZGl0UGFnZS50c3gifQ==