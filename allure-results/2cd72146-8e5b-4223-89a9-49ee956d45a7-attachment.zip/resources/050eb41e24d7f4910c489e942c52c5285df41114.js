import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ArrayStringInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/ArrayStringInput.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { FaPlus, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
export const ArrayStringInput = ({ values = [], onChange, placeholder, disabled }) => {
  const handleChange = (index, newValue) => {
    const newValues = [...values];
    newValues[index] = newValue;
    onChange(newValues);
  };
  const handleAdd = () => {
    onChange([...values, ""]);
  };
  const handleRemove = (index) => {
    const newValues = values.filter((_, i) => i !== index);
    onChange(newValues);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
    values.map(
      (value, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value,
            onChange: (e) => handleChange(index, e.target.value),
            placeholder: placeholder || "Ingrese valor...",
            disabled,
            autoComplete: "off",
            className: "block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/ArrayStringInput.tsx",
            lineNumber: 52,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleRemove(index),
            disabled,
            className: "p-2 text-red-600 bg-white border border-gray-300 rounded-md hover:bg-red-50 focus:outline-none",
            title: "Eliminar fila",
            children: /* @__PURE__ */ jsxDEV(FaTrash, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/app/src/components/common/ArrayStringInput.tsx",
              lineNumber: 68,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/components/common/ArrayStringInput.tsx",
            lineNumber: 61,
            columnNumber: 21
          },
          this
        )
      ] }, index, true, {
        fileName: "/app/src/components/common/ArrayStringInput.tsx",
        lineNumber: 51,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: handleAdd,
        disabled,
        className: "inline-flex items-center px-3 py-1.5 text-xs font-medium text-indigo-700 bg-indigo-100 border border-transparent rounded-md hover:bg-indigo-200 focus:outline-none",
        children: [
          /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-3 h-3 mr-1" }, void 0, false, {
            fileName: "/app/src/components/common/ArrayStringInput.tsx",
            lineNumber: 78,
            columnNumber: 17
          }, this),
          " Agregar Dirección"
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/common/ArrayStringInput.tsx",
        lineNumber: 72,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/components/common/ArrayStringInput.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_c = ArrayStringInput;
var _c;
$RefreshReg$(_c, "ArrayStringInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/ArrayStringInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/ArrayStringInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NvQjs7Ozs7Ozs7Ozs7Ozs7OztBQS9CcEIsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxRQUFRQyxlQUFlO0FBU3pCLGFBQU1DLG1CQUFvREEsQ0FBQyxFQUFFQyxTQUFTLElBQUlDLFVBQVVDLGFBQWFDLFNBQVMsTUFBTTtBQUVuSCxRQUFNQyxlQUFlQSxDQUFDQyxPQUFlQyxhQUFxQjtBQUN0RCxVQUFNQyxZQUFZLENBQUMsR0FBR1AsTUFBTTtBQUM1Qk8sY0FBVUYsS0FBSyxJQUFJQztBQUNuQkwsYUFBU00sU0FBUztBQUFBLEVBQ3RCO0FBRUEsUUFBTUMsWUFBWUEsTUFBTTtBQUNwQlAsYUFBUyxDQUFDLEdBQUdELFFBQVEsRUFBRSxDQUFDO0FBQUEsRUFDNUI7QUFFQSxRQUFNUyxlQUFlQSxDQUFDSixVQUFrQjtBQUNwQyxVQUFNRSxZQUFZUCxPQUFPVSxPQUFPLENBQUNDLEdBQUdDLE1BQU1BLE1BQU1QLEtBQUs7QUFDckRKLGFBQVNNLFNBQVM7QUFBQSxFQUN0QjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGFBQ1ZQO0FBQUFBLFdBQU9hO0FBQUFBLE1BQUksQ0FBQ0MsT0FBT1QsVUFDaEIsdUJBQUMsU0FBZ0IsV0FBVSwrQkFDdkI7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0w7QUFBQSxZQUNBLFVBQVUsQ0FBQ1UsTUFBTVgsYUFBYUMsT0FBT1UsRUFBRUMsT0FBT0YsS0FBSztBQUFBLFlBQ25ELGFBQWFaLGVBQWU7QUFBQSxZQUM1QjtBQUFBLFlBQ0EsY0FBYTtBQUFBLFlBQ2IsV0FBVTtBQUFBO0FBQUEsVUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPOEo7QUFBQSxRQUU5SjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNTyxhQUFhSixLQUFLO0FBQUEsWUFDakM7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUNWLE9BQU07QUFBQSxZQUVOLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBO0FBQUEsVUFQaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQWxCTUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsSUFDSDtBQUFBLElBQ0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFNBQVNHO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUc7QUFBQTtBQUFBO0FBQUEsTUFOdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0JBO0FBRVI7QUFBRVMsS0FuRFdsQjtBQUFpRCxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiRmFQbHVzIiwiRmFUcmFzaCIsIkFycmF5U3RyaW5nSW5wdXQiLCJ2YWx1ZXMiLCJvbkNoYW5nZSIsInBsYWNlaG9sZGVyIiwiZGlzYWJsZWQiLCJoYW5kbGVDaGFuZ2UiLCJpbmRleCIsIm5ld1ZhbHVlIiwibmV3VmFsdWVzIiwiaGFuZGxlQWRkIiwiaGFuZGxlUmVtb3ZlIiwiZmlsdGVyIiwiXyIsImkiLCJtYXAiLCJ2YWx1ZSIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcnJheVN0cmluZ0lucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvY29tcG9uZW50cy9jb21tb24vQXJyYXlTdHJpbmdJbnB1dC50c3hcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGYVBsdXMsIEZhVHJhc2ggfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5cbmludGVyZmFjZSBBcnJheVN0cmluZ0lucHV0UHJvcHMge1xuICAgIHZhbHVlczogc3RyaW5nW107XG4gICAgb25DaGFuZ2U6IChuZXdWYWx1ZXM6IHN0cmluZ1tdKSA9PiB2b2lkO1xuICAgIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xuICAgIGRpc2FibGVkPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNvbnN0IEFycmF5U3RyaW5nSW5wdXQ6IFJlYWN0LkZDPEFycmF5U3RyaW5nSW5wdXRQcm9wcz4gPSAoeyB2YWx1ZXMgPSBbXSwgb25DaGFuZ2UsIHBsYWNlaG9sZGVyLCBkaXNhYmxlZCB9KSA9PiB7XG5cbiAgICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoaW5kZXg6IG51bWJlciwgbmV3VmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICBjb25zdCBuZXdWYWx1ZXMgPSBbLi4udmFsdWVzXTtcbiAgICAgICAgbmV3VmFsdWVzW2luZGV4XSA9IG5ld1ZhbHVlO1xuICAgICAgICBvbkNoYW5nZShuZXdWYWx1ZXMpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBZGQgPSAoKSA9PiB7XG4gICAgICAgIG9uQ2hhbmdlKFsuLi52YWx1ZXMsICcnXSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZSA9IChpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgIGNvbnN0IG5ld1ZhbHVlcyA9IHZhbHVlcy5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KTtcbiAgICAgICAgb25DaGFuZ2UobmV3VmFsdWVzKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIHt2YWx1ZXMubWFwKCh2YWx1ZSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKGluZGV4LCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cGxhY2Vob2xkZXIgfHwgXCJJbmdyZXNlIHZhbG9yLi4uXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvZmZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJlZC02MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGhvdmVyOmJnLXJlZC01MCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFbGltaW5hciBmaWxhXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhVHJhc2ggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWluZGlnby03MDAgYmctaW5kaWdvLTEwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgaG92ZXI6YmctaW5kaWdvLTIwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxGYVBsdXMgY2xhc3NOYW1lPVwidy0zIGgtMyBtci0xXCIgLz4gQWdyZWdhciBEaXJlY2Npw7NuXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9BcnJheVN0cmluZ0lucHV0LnRzeCJ9