import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/leads/pages/LeadsCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/leads/pages/LeadsCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { LeadsFormPage } from "/src/features/leads/pages/LeadsFormPage.tsx";
import {} from "/src/features/leads/leads.config.tsx";
import { create } from "/src/services/apiService.ts";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { leadsModuleConfig } from "/src/features/leads/leads.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialLeadValues = {
  customer_name: "",
  cuit: "",
  email: "",
  whatsapp: "",
  product_id: void 0,
  product_name: void 0,
  product_sku: void 0,
  industry_type: ""
};
export const LeadsCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const handleSave = async (data) => {
    try {
      await create(leadsModuleConfig.endpoint, data);
      toast.success("Lead creado con éxito");
      navigate(getListReturnPath(leadsModuleConfig.baseRoute));
    } catch (error) {
      toast.error("Error al crear el lead");
      console.error(error);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    LeadsFormPage,
    {
      mode: "create",
      initialData: initialLeadValues,
      onSave: handleSave
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/leads/pages/LeadsCreatePage.tsx",
      lineNumber: 55,
      columnNumber: 5
    },
    this
  );
};
_s(LeadsCreatePage, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = LeadsCreatePage;
var _c;
$RefreshReg$(_c, "LeadsCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/leads/pages/LeadsCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/leads/pages/LeadsCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxDUixTQUFTQSxxQkFBcUI7QUFDOUIsZUFBMEI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLG9CQUFtQztBQUFBLEVBQ3JDQyxlQUFlO0FBQUEsRUFDZkMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsWUFBWUM7QUFBQUEsRUFDWkMsY0FBY0Q7QUFBQUEsRUFDZEUsYUFBYUY7QUFBQUEsRUFDYkcsZUFBZTtBQUNuQjtBQUVPLGFBQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2pDLFFBQU1DLFdBQVdoQixZQUFZO0FBRTdCLFFBQU1pQixhQUFhLE9BQU9DLFNBQWU7QUFDckMsUUFBSTtBQUNBLFlBQU1uQixPQUFhRyxrQkFBa0JpQixVQUFVRCxJQUFJO0FBQ25EakIsWUFBTW1CLFFBQVEsdUJBQXVCO0FBQ3JDSixlQUFTYixrQkFBa0JELGtCQUFrQm1CLFNBQVMsQ0FBQztBQUFBLElBQzNELFNBQVNDLE9BQU87QUFDWnJCLFlBQU1xQixNQUFNLHdCQUF3QjtBQUNwQ0MsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUVBLFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLE1BQUs7QUFBQSxNQUNMLGFBQWFsQjtBQUFBQSxNQUNiLFFBQVFhO0FBQUFBO0FBQUFBLElBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR3VCO0FBRy9CO0FBQUVGLEdBckJXRCxpQkFBZTtBQUFBLFVBQ1BkLFdBQVc7QUFBQTtBQUFBd0IsS0FEbkJWO0FBQWUsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxlYWRzRm9ybVBhZ2UiLCJjcmVhdGUiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwibGVhZHNNb2R1bGVDb25maWciLCJnZXRMaXN0UmV0dXJuUGF0aCIsImluaXRpYWxMZWFkVmFsdWVzIiwiY3VzdG9tZXJfbmFtZSIsImN1aXQiLCJlbWFpbCIsIndoYXRzYXBwIiwicHJvZHVjdF9pZCIsInVuZGVmaW5lZCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3Rfc2t1IiwiaW5kdXN0cnlfdHlwZSIsIkxlYWRzQ3JlYXRlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJoYW5kbGVTYXZlIiwiZGF0YSIsImVuZHBvaW50Iiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsImVycm9yIiwiY29uc29sZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxlYWRzQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyBMZWFkc0Zvcm1QYWdlIH0gZnJvbSAnLi9MZWFkc0Zvcm1QYWdlJztcbmltcG9ydCB7IHR5cGUgTGVhZCB9IGZyb20gJy4uL2xlYWRzLmNvbmZpZyc7XG5pbXBvcnQgeyBjcmVhdGUgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IGxlYWRzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vbGVhZHMuY29uZmlnJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG5jb25zdCBpbml0aWFsTGVhZFZhbHVlczogUGFydGlhbDxMZWFkPiA9IHtcbiAgICBjdXN0b21lcl9uYW1lOiAnJyxcbiAgICBjdWl0OiAnJyxcbiAgICBlbWFpbDogJycsXG4gICAgd2hhdHNhcHA6ICcnLFxuICAgIHByb2R1Y3RfaWQ6IHVuZGVmaW5lZCxcbiAgICBwcm9kdWN0X25hbWU6IHVuZGVmaW5lZCxcbiAgICBwcm9kdWN0X3NrdTogdW5kZWZpbmVkLFxuICAgIGluZHVzdHJ5X3R5cGU6ICcnLFxufTtcblxuZXhwb3J0IGNvbnN0IExlYWRzQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IExlYWQpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGNyZWF0ZTxMZWFkPihsZWFkc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgZGF0YSk7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKCdMZWFkIGNyZWFkbyBjb24gw6l4aXRvJyk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChsZWFkc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjcmVhciBlbCBsZWFkJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8TGVhZHNGb3JtUGFnZVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbExlYWRWYWx1ZXMgYXMgTGVhZH1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbGVhZHMvcGFnZXMvTGVhZHNDcmVhdGVQYWdlLnRzeCJ9