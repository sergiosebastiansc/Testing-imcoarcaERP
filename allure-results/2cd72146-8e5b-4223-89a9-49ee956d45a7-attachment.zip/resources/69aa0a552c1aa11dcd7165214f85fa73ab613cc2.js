import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/NoAccessMessage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/NoAccessMessage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { IoLockClosed, IoArrowBack } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
export const NoAccessMessage = ({ message = "No tienes permisos para acceder a esta sección." }) => {
  _s();
  const navigate = useNavigate();
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md w-full space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV(IoLockClosed, { className: "mx-auto h-16 w-16 text-red-500" }, void 0, false, {
        fileName: "/app/src/components/ui/NoAccessMessage.tsx",
        lineNumber: 30,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "mt-6 text-3xl font-extrabold text-gray-900", children: "Acceso Denegado" }, void 0, false, {
        fileName: "/app/src/components/ui/NoAccessMessage.tsx",
        lineNumber: 31,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600", children: message }, void 0, false, {
        fileName: "/app/src/components/ui/NoAccessMessage.tsx",
        lineNumber: 34,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/components/ui/NoAccessMessage.tsx",
      lineNumber: 29,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-8 flex justify-center", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => navigate("/dashboard"),
        className: "inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
        children: [
          /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "mr-2 h-5 w-5" }, void 0, false, {
            fileName: "/app/src/components/ui/NoAccessMessage.tsx",
            lineNumber: 43,
            columnNumber: 25
          }, this),
          "Volver al Dashboard"
        ]
      },
      void 0,
      true,
      {
        fileName: "/app/src/components/ui/NoAccessMessage.tsx",
        lineNumber: 39,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "/app/src/components/ui/NoAccessMessage.tsx",
      lineNumber: 38,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/components/ui/NoAccessMessage.tsx",
    lineNumber: 28,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/app/src/components/ui/NoAccessMessage.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
};
_s(NoAccessMessage, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = NoAccessMessage;
var _c;
$RefreshReg$(_c, "NoAccessMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/NoAccessMessage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/NoAccessMessage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVW9COzs7Ozs7Ozs7Ozs7Ozs7OztBQVZwQixTQUFTQSxjQUFjQyxtQkFBbUI7QUFDMUMsU0FBU0MsbUJBQW1CO0FBRXJCLGFBQU1DLGtCQUFrQkEsQ0FBQyxFQUFFQyxVQUFVLGtEQUF3RSxNQUFNO0FBQUFDLEtBQUE7QUFDdEgsUUFBTUMsV0FBV0osWUFBWTtBQUU3QixTQUNJLHVCQUFDLFNBQUksV0FBVSx1RkFDWCxpQ0FBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZUFDWDtBQUFBLDZCQUFDLGdCQUFhLFdBQVUsb0NBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxNQUN4RCx1QkFBQyxRQUFHLFdBQVUsOENBQTRDLCtCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDUkUscUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csU0FBUyxNQUFNRSxTQUFTLFlBQVk7QUFBQSxRQUNwQyxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLGVBQVksV0FBVSxrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQTtBQUVSO0FBQUVELEdBM0JXRixpQkFBZTtBQUFBLFVBQ1BELFdBQVc7QUFBQTtBQUFBSyxLQURuQko7QUFBZSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiSW9Mb2NrQ2xvc2VkIiwiSW9BcnJvd0JhY2siLCJ1c2VOYXZpZ2F0ZSIsIk5vQWNjZXNzTWVzc2FnZSIsIm1lc3NhZ2UiLCJfcyIsIm5hdmlnYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm9BY2Nlc3NNZXNzYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJb0xvY2tDbG9zZWQsIElvQXJyb3dCYWNrIH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmV4cG9ydCBjb25zdCBOb0FjY2Vzc01lc3NhZ2UgPSAoeyBtZXNzYWdlID0gJ05vIHRpZW5lcyBwZXJtaXNvcyBwYXJhIGFjY2VkZXIgYSBlc3RhIHNlY2Npw7NuLicgfTogeyBtZXNzYWdlPzogc3RyaW5nIH0pID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTUwIHB5LTEyIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIHctZnVsbCBzcGFjZS15LThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxJb0xvY2tDbG9zZWQgY2xhc3NOYW1lPVwibXgtYXV0byBoLTE2IHctMTYgdGV4dC1yZWQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTYgdGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWNjZXNvIERlbmVnYWRvXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvZGFzaGJvYXJkJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLW1kIHNoYWRvdy1zbSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctb2Zmc2V0LTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvQXJyb3dCYWNrIGNsYXNzTmFtZT1cIm1yLTIgaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBWb2x2ZXIgYWwgRGFzaGJvYXJkXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL3VpL05vQWNjZXNzTWVzc2FnZS50c3gifQ==