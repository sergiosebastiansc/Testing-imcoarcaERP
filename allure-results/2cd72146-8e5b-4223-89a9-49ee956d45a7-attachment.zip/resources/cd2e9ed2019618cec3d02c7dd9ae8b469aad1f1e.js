import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { ToastContainer } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { AppRouter } from "/src/routes/AppRouter.tsx";
function App() {
  _s();
  useEffect(() => {
    const preventStepperKeys = (e) => {
      const target = e.target;
      if (target instanceof HTMLInputElement && target.type === "number" && (e.key === "ArrowUp" || e.key === "ArrowDown")) {
        e.preventDefault();
      }
    };
    const preventStepperWheel = (e) => {
      const target = e.target;
      if (target instanceof HTMLInputElement && target.type === "number") {
        e.preventDefault();
      }
    };
    document.addEventListener("keydown", preventStepperKeys, true);
    document.addEventListener("wheel", preventStepperWheel, { passive: false });
    return () => {
      document.removeEventListener("keydown", preventStepperKeys, true);
      document.removeEventListener("wheel", preventStepperWheel);
    };
  }, []);
  return (
    // Usamos un Fragment (<>) para poder tener dos componentes hermanos
    /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(AppRouter, {}, void 0, false, {
        fileName: "/app/src/App.tsx",
        lineNumber: 50,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        ToastContainer,
        {
          position: "top-right",
          autoClose: 5e3,
          hideProgressBar: false,
          newestOnTop: false,
          closeOnClick: true,
          rtl: false,
          pauseOnFocusLoss: true,
          draggable: true,
          pauseOnHover: true,
          theme: "colored"
        },
        void 0,
        false,
        {
          fileName: "/app/src/App.tsx",
          lineNumber: 52,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/App.tsx",
      lineNumber: 49,
      columnNumber: 5
    }, this)
  );
}
_s(App, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNUJKLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsaUJBQWlCO0FBRTFCLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUNiSixZQUFVLE1BQU07QUFDZCxVQUFNSyxxQkFBcUJBLENBQUNDLE1BQXFCO0FBQy9DLFlBQU1DLFNBQVNELEVBQUVDO0FBQ2pCLFVBQUlBLGtCQUFrQkMsb0JBQW9CRCxPQUFPRSxTQUFTLGFBQWFILEVBQUVJLFFBQVEsYUFBYUosRUFBRUksUUFBUSxjQUFjO0FBQ3BISixVQUFFSyxlQUFlO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0EsVUFBTUMsc0JBQXNCQSxDQUFDTixNQUFrQjtBQUM3QyxZQUFNQyxTQUFTRCxFQUFFQztBQUNqQixVQUFJQSxrQkFBa0JDLG9CQUFvQkQsT0FBT0UsU0FBUyxVQUFVO0FBQ2xFSCxVQUFFSyxlQUFlO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0FFLGFBQVNDLGlCQUFpQixXQUFXVCxvQkFBb0IsSUFBSTtBQUM3RFEsYUFBU0MsaUJBQWlCLFNBQVNGLHFCQUFxQixFQUFFRyxTQUFTLE1BQU0sQ0FBQztBQUMxRSxXQUFPLE1BQU07QUFDWEYsZUFBU0csb0JBQW9CLFdBQVdYLG9CQUFvQixJQUFJO0FBQ2hFUSxlQUFTRyxvQkFBb0IsU0FBU0osbUJBQW1CO0FBQUEsSUFDM0Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMO0FBQUE7QUFBQSxJQUVFLG1DQUNFO0FBQUEsNkJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUVWO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFTO0FBQUEsVUFDVCxXQUFXO0FBQUEsVUFDWCxpQkFBaUI7QUFBQSxVQUNqQixhQUFhO0FBQUEsVUFDYjtBQUFBLFVBQ0EsS0FBSztBQUFBLFVBQ0w7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsT0FBTTtBQUFBO0FBQUEsUUFWUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVNEI7QUFBQSxTQWI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQTtBQUVKO0FBQUNSLEdBekNRRCxLQUFHO0FBQUFjLEtBQUhkO0FBMkNULGVBQWVBO0FBQUksSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIlRvYXN0Q29udGFpbmVyIiwiQXBwUm91dGVyIiwiQXBwIiwiX3MiLCJwcmV2ZW50U3RlcHBlcktleXMiLCJlIiwidGFyZ2V0IiwiSFRNTElucHV0RWxlbWVudCIsInR5cGUiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsInByZXZlbnRTdGVwcGVyV2hlZWwiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJwYXNzaXZlIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL0FwcC50c3hcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgQXBwUm91dGVyIH0gZnJvbSAnLi9yb3V0ZXMvQXBwUm91dGVyJztcblxuZnVuY3Rpb24gQXBwKCkge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHByZXZlbnRTdGVwcGVyS2V5cyA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIHRhcmdldC50eXBlID09PSAnbnVtYmVyJyAmJiAoZS5rZXkgPT09ICdBcnJvd1VwJyB8fCBlLmtleSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHByZXZlbnRTdGVwcGVyV2hlZWwgPSAoZTogV2hlZWxFdmVudCkgPT4ge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQ7XG4gICAgICBpZiAodGFyZ2V0IGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiB0YXJnZXQudHlwZSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHByZXZlbnRTdGVwcGVyS2V5cywgdHJ1ZSk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBwcmV2ZW50U3RlcHBlcldoZWVsLCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgcHJldmVudFN0ZXBwZXJLZXlzLCB0cnVlKTtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3doZWVsJywgcHJldmVudFN0ZXBwZXJXaGVlbCk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgLy8gVXNhbW9zIHVuIEZyYWdtZW50ICg8PikgcGFyYSBwb2RlciB0ZW5lciBkb3MgY29tcG9uZW50ZXMgaGVybWFub3NcbiAgICA8PlxuICAgICAgPEFwcFJvdXRlciAvPlxuXG4gICAgICA8VG9hc3RDb250YWluZXJcbiAgICAgICAgcG9zaXRpb249XCJ0b3AtcmlnaHRcIiAgICAgIC8vIFBvc2ljacOzbiBlbiBsYSBwYW50YWxsYVxuICAgICAgICBhdXRvQ2xvc2U9ezUwMDB9ICAgICAgICAgIC8vIFNlIGNpZXJyYSBhdXRvbcOhdGljYW1lbnRlIGRlc3B1w6lzIGRlIDUgc2VndW5kb3NcbiAgICAgICAgaGlkZVByb2dyZXNzQmFyPXtmYWxzZX1cbiAgICAgICAgbmV3ZXN0T25Ub3A9e2ZhbHNlfVxuICAgICAgICBjbG9zZU9uQ2xpY2tcbiAgICAgICAgcnRsPXtmYWxzZX1cbiAgICAgICAgcGF1c2VPbkZvY3VzTG9zc1xuICAgICAgICBkcmFnZ2FibGVcbiAgICAgICAgcGF1c2VPbkhvdmVyXG4gICAgICAgIHRoZW1lPVwiY29sb3JlZFwiICAgICAgICAgICAvLyBUZW1hIHZpc3VhbCBkZSBsYXMgbm90aWZpY2FjaW9uZXNcbiAgICAgIC8+XG4gICAgPC8+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDsiXSwiZmlsZSI6Ii9hcHAvc3JjL0FwcC50c3gifQ==