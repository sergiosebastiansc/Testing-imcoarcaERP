import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/facturas_venta/pages/FacturasVentaListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/facturas_venta/pages/FacturasVentaListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const FacturasVentaListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(salesInvoicesModuleConfig, getDefaultListDateRange());
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission(salesInvoicesModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const hasEditPermission = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  const hasDeletePermission = moduleBase ? hasModulePermission(moduleBase, "delete") : true;
  const canEditInvoice = (invoice) => {
    return hasEditPermission && invoice.status !== "ISSUED";
  };
  const canDeleteInvoice = (invoice) => {
    return hasDeletePermission && invoice.status !== "ISSUED";
  };
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaListPage.tsx",
    lineNumber: 51,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: salesInvoicesModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true,
      canEdit: canEditInvoice,
      canDelete: canDeleteInvoice
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaListPage.tsx",
      lineNumber: 54,
      columnNumber: 5
    },
    this
  );
};
_s(FacturasVentaListPage, "yjB/rutd0ICjbFA72BDSbAuQTHI=", false, function() {
  return [useCrud, usePermissions];
});
_c = FacturasVentaListPage;
var _c;
$RefreshReg$(_c, "FacturasVentaListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/facturas_venta/pages/FacturasVentaListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/facturas_venta/pages/FacturasVentaListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlDQUFvRDtBQUM3RCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCQywrQkFBK0I7QUFDL0QsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJbkIsUUFBc0JDLDJCQUEyQkksd0JBQXdCLENBQUM7QUFHOUUsUUFBTSxFQUFFZSxvQkFBb0IsSUFBSWxCLGVBQWU7QUFDL0MsUUFBTW1CLG1CQUFtQmxCLHNCQUFzQkYsMEJBQTBCcUIsU0FBUztBQUNsRixRQUFNQyxhQUFhRixtQkFBbUJqQix3QkFBd0JpQixnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRyxvQkFBb0JELGFBQWFILG9CQUFvQkcsWUFBWSxNQUFNLElBQUk7QUFDakYsUUFBTUUsc0JBQXNCRixhQUFhSCxvQkFBb0JHLFlBQVksUUFBUSxJQUFJO0FBR3JGLFFBQU1HLGlCQUFpQkEsQ0FBQ0MsWUFBbUM7QUFFdkQsV0FBT0gscUJBQXFCRyxRQUFRQyxXQUFXO0FBQUEsRUFDbkQ7QUFFQSxRQUFNQyxtQkFBbUJBLENBQUNGLFlBQW1DO0FBRXpELFdBQU9GLHVCQUF1QkUsUUFBUUMsV0FBVztBQUFBLEVBQ3JEO0FBRUEsTUFBSWpCLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRVjtBQUFBQSxNQUNSLG9CQUFvQk87QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhVyxRQUFRO0FBQUEsTUFDakMsaUJBQWlCWCxhQUFhWSxhQUFhO0FBQUEsTUFDM0MsZUFBZVosYUFBYWEsV0FBVztBQUFBLE1BQ3ZDLHVCQUF1QjtBQUFBLE1BRXZCLFNBQVNOO0FBQUFBLE1BQ1QsV0FBV0c7QUFBQUE7QUFBQUEsSUFsQmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0JnQztBQUd4QztBQUFFdEIsR0FoRFdELHVCQUFxQjtBQUFBLFVBSTFCTixTQUc0QkUsY0FBYztBQUFBO0FBQUErQixLQVByQzNCO0FBQXFCLElBQUEyQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwidXNlQ3J1ZCIsInNhbGVzSW52b2ljZXNNb2R1bGVDb25maWciLCJ1c2VQZXJtaXNzaW9ucyIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJGYWN0dXJhc1ZlbnRhTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJoYXNNb2R1bGVQZXJtaXNzaW9uIiwibW9kdWxlUGVybWlzc2lvbiIsImJhc2VSb3V0ZSIsIm1vZHVsZUJhc2UiLCJoYXNFZGl0UGVybWlzc2lvbiIsImhhc0RlbGV0ZVBlcm1pc3Npb24iLCJjYW5FZGl0SW52b2ljZSIsImludm9pY2UiLCJzdGF0dXMiLCJjYW5EZWxldGVJbnZvaWNlIiwidGVybSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGYWN0dXJhc1ZlbnRhTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLCB0eXBlIFNhbGVzSW52b2ljZSB9IGZyb20gJy4uL2ZhY3R1cmFzX3ZlbnRhLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuXG5leHBvcnQgY29uc3QgRmFjdHVyYXNWZW50YUxpc3RQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsIGxvYWRpbmcsIGlzQXBwZW5kaW5nLCBlcnJvciwgZGVsZXRlSXRlbSwgaGFuZGxlU29ydCwgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLCBoYW5kbGVQYWdlQ2hhbmdlLCBoYW5kbGVMb2FkTW9yZSwgaGFuZGxlU2VhcmNoLCBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8U2FsZXNJbnZvaWNlPihzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLCBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSgpKTtcblxuICAgIC8vIOKchSBPYnRlbmVyIHBlcm1pc29zIGRlbCBtw7NkdWxvXG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IG1vZHVsZVBlcm1pc3Npb24gPSBnZXRSZXF1aXJlZFBlcm1pc3Npb24oc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGhhc0VkaXRQZXJtaXNzaW9uID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG4gICAgY29uc3QgaGFzRGVsZXRlUGVybWlzc2lvbiA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdkZWxldGUnKSA6IHRydWU7XG5cbiAgICAvLyDinIUgRnVuY2lvbmVzIHF1ZSBjb21iaW5hbiBwZXJtaXNvcyArIHZhbGlkYWNpw7NuIGRlIHN0YXR1c1xuICAgIGNvbnN0IGNhbkVkaXRJbnZvaWNlID0gKGludm9pY2U6IFNhbGVzSW52b2ljZSk6IGJvb2xlYW4gPT4ge1xuICAgICAgICAvLyBEZWJlIHRlbmVyIHBlcm1pc28gWSBubyBlc3RhciBlbnZpYWRhIGEgQVJDQVxuICAgICAgICByZXR1cm4gaGFzRWRpdFBlcm1pc3Npb24gJiYgaW52b2ljZS5zdGF0dXMgIT09ICdJU1NVRUQnO1xuICAgIH07XG5cbiAgICBjb25zdCBjYW5EZWxldGVJbnZvaWNlID0gKGludm9pY2U6IFNhbGVzSW52b2ljZSk6IGJvb2xlYW4gPT4ge1xuICAgICAgICAvLyBEZWJlIHRlbmVyIHBlcm1pc28gWSBubyBlc3RhciBlbnZpYWRhIGEgQVJDQVxuICAgICAgICByZXR1cm4gaGFzRGVsZXRlUGVybWlzc2lvbiAmJiBpbnZvaWNlLnN0YXR1cyAhPT0gJ0lTU1VFRCc7XG4gICAgfTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8U2FsZXNJbnZvaWNlPlxuICAgICAgICAgICAgY29uZmlnPXtzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlclN0YXJ0PXtzZWFyY2hQYXJhbXMuc3RhcnREYXRlID8/ICcnfVxuICAgICAgICAgICAgZGF0ZUZpbHRlckVuZD17c2VhcmNoUGFyYW1zLmVuZERhdGUgPz8gJyd9XG4gICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgICAgICAvLyDinIUgUGFzYXIgbGFzIGZ1bmNpb25lcyBxdWUgY29tYmluYW4gcGVybWlzb3MgKyB2YWxpZGFjacOzbiBkZSBzdGF0dXNcbiAgICAgICAgICAgIGNhbkVkaXQ9e2NhbkVkaXRJbnZvaWNlfVxuICAgICAgICAgICAgY2FuRGVsZXRlPXtjYW5EZWxldGVJbnZvaWNlfVxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvZmFjdHVyYXNfdmVudGEvcGFnZXMvRmFjdHVyYXNWZW50YUxpc3RQYWdlLnRzeCJ9