import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSpinner, FaMoneyCheckAlt, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getAll } from "/src/services/apiService.ts";
import { formatValue } from "/src/utils/formatters.ts";
import { Pagination } from "/src/components/common/Pagination.tsx";
import { movimientosBancosModuleConfig } from "/src/features/movimientos_bancos/movimientos_bancos.config.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialBankMovementValues = {
  bank_id: 0,
  movement_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  movement_type: "ENTRADA",
  amount: 0,
  value_type: "DEPOSITO",
  client_id: null,
  vendor_id: null,
  observations: null
};
export const MovimientosBancosFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { item: loadedItem, loading, error, saveItem } = useCrudItem(movimientosBancosModuleConfig, id);
  const [initialData, setInitialData] = useState(mode === "create" ? { ...initialBankMovementValues } : null);
  const [selectedChequesToDeposit, setSelectedChequesToDeposit] = useState([]);
  const [depositChecksModalOpen, setDepositChecksModalOpen] = useState(false);
  const [toDepositChecksList, setToDepositChecksList] = useState([]);
  const [toDepositChecksMeta, setToDepositChecksMeta] = useState(null);
  const [loadingToDepositChecks, setLoadingToDepositChecks] = useState(false);
  const [modalSelectedIds, setModalSelectedIds] = useState(/* @__PURE__ */ new Set());
  const isOriginatedFromCollectionOrPayment = (item) => {
    if (!item || !item.source_type || item.source_id == null) return false;
    return item.source_type.includes("Collection") || item.source_type.includes("PaymentOrder");
  };
  const isReadOnlyOrigin = isOriginatedFromCollectionOrPayment(loadedItem ?? initialData ?? null);
  useEffect(() => {
    if (mode === "create") {
      setInitialData({ ...initialBankMovementValues });
      return;
    }
    if (loadedItem) {
      const hydrated = { ...loadedItem };
      if (loadedItem.movement_type === "ENTRADA" && loadedItem.client_name) {
        hydrated.name = loadedItem.client_name;
      }
      if (loadedItem.movement_type === "SALIDA" && loadedItem.vendor_name) {
        hydrated.name = loadedItem.vendor_name;
      }
      if (loadedItem.bank_name) hydrated.bank_name = loadedItem.bank_name;
      if (loadedItem.bank_code) hydrated.bank_code = loadedItem.bank_code;
      setInitialData(hydrated);
      if (loadedItem.deposited_check_ids?.length) {
        setSelectedChequesToDeposit(loadedItem.deposited_check_ids.map((id2) => ({
          id: id2,
          payment_method_code: "CHE",
          value: "0",
          bank_id: null,
          bank_name: null,
          check_number: `#${id2}`,
          check_date: "",
          check_due_date: "",
          check_holder: null,
          reference_number: null,
          is_deposited: false
        })));
      }
    }
  }, [mode, loadedItem]);
  const loadToDepositChecks = useCallback((pageUrl) => {
    setLoadingToDepositChecks(true);
    const req = pageUrl ? getAll(pageUrl) : getAll("collections/to-deposit-checks");
    req.then((res) => {
      setToDepositChecksList(res.data || []);
      setToDepositChecksMeta(res.meta ?? null);
    }).catch(() => {
      toast.error("Error al cargar cheques a depositar.");
      setToDepositChecksList([]);
      setToDepositChecksMeta(null);
    }).finally(() => setLoadingToDepositChecks(false));
  }, []);
  useEffect(() => {
    if (!depositChecksModalOpen) return;
    loadToDepositChecks();
  }, [depositChecksModalOpen, loadToDepositChecks]);
  const handleOpenDepositChecksModal = () => {
    setModalSelectedIds(/* @__PURE__ */ new Set());
    setDepositChecksModalOpen(true);
  };
  const handleToggleModalCheck = (id2) => {
    setModalSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id2)) next.delete(id2);
      else
        next.add(id2);
      return next;
    });
  };
  const handleAddSelectedDepositChecks = () => {
    const toAdd = toDepositChecksList.filter((c) => modalSelectedIds.has(c.id));
    const existingIds = new Set(selectedChequesToDeposit.map((c) => c.id));
    const newOnes = toAdd.filter((c) => !existingIds.has(c.id));
    if (newOnes.length) setSelectedChequesToDeposit((prev) => [...prev, ...newOnes]);
    setDepositChecksModalOpen(false);
    setModalSelectedIds(/* @__PURE__ */ new Set());
  };
  const handleRemoveDepositCheck = (id2) => {
    setSelectedChequesToDeposit((prev) => prev.filter((c) => c.id !== id2));
  };
  const handleSave = async (data) => {
    if (isReadOnlyOrigin) {
      toast.error("No es posible editar movimientos de banco generados automáticamente desde cobranzas u órdenes de pago.");
      return;
    }
    if (!data.bank_id || !data.movement_date || data.amount == null) {
      toast.error("Banco, fecha e importe son obligatorios.");
      return;
    }
    const amountNum = Number(data.amount);
    if (!Number.isFinite(amountNum) || amountNum <= 0) {
      toast.error("El importe debe ser mayor que 0.");
      return;
    }
    if (data.value_type === "DEPOSITO" && data.movement_type !== "ENTRADA") {
      toast.error("Para un Depósito el tipo de movimiento debe ser ENTRADA.");
      return;
    }
    if (data.value_type === "RETIRO" && data.movement_type !== "SALIDA") {
      toast.error("Para un Retiro el tipo de movimiento debe ser SALIDA.");
      return;
    }
    const payload = {
      bank_id: data.bank_id,
      movement_date: data.movement_date,
      movement_type: data.movement_type,
      amount: Number(data.amount),
      value_type: data.value_type,
      observations: data.observations || null
    };
    if (data.movement_type === "ENTRADA") {
      payload.client_id = data.client_id ?? null;
      payload.vendor_id = null;
    } else {
      payload.vendor_id = data.vendor_id ?? null;
      payload.client_id = null;
    }
    if (selectedChequesToDeposit.length > 0) {
      payload.deposited_check_ids = selectedChequesToDeposit.map((c) => c.id);
    }
    const toSend = { ...payload };
    delete toSend.bank_name;
    delete toSend.bank_code;
    delete toSend.client_name;
    delete toSend.vendor_name;
    delete toSend.customer_code;
    delete toSend.vendor_code;
    delete toSend.name;
    try {
      await saveItem(toSend);
      toast.success(mode === "create" ? "Movimiento creado con éxito." : "Movimiento actualizado con éxito.");
      navigate(getListReturnPath(movimientosBancosModuleConfig.baseRoute));
    } catch {
      toast.error("Error al guardar el movimiento.");
    }
  };
  if (mode === "edit") {
    if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del movimiento..." }, void 0, false, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 230,
      columnNumber: 25
    }, this);
    if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 231,
      columnNumber: 23
    }, this);
    if (!initialData) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento de banco no encontrado." }, void 0, false, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 232,
      columnNumber: 30
    }, this);
  }
  if (mode === "create" && !initialData) return null;
  const renderExtraContent = (formData) => {
    if (formData.value_type !== "DEPOSITO") return null;
    return /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-3", children: "Cheques a depositar" }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 241,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleOpenDepositChecksModal,
          className: "inline-flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
          children: [
            /* @__PURE__ */ jsxDEV(FaMoneyCheckAlt, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 247,
              columnNumber: 21
            }, this),
            " Seleccionar cheques"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 242,
          columnNumber: 17
        },
        this
      ),
      selectedChequesToDeposit.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Nº Cheque" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 254,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Valor" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 255,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Banco" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 256,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Ref." }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 257,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 w-16" }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 258,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 253,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 252,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: selectedChequesToDeposit.map(
          (c) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.check_number }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 264,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-right", children: formatValue(Number(c.value), "currency") }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 265,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.bank_name ?? "-" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 266,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.reference_number ?? "-" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 267,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveDepositCheck(c.id), className: "text-red-500 hover:text-red-700", title: "Quitar", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 269,
              columnNumber: 173
            }, this) }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 269,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 268,
              columnNumber: 41
            }, this)
          ] }, c.id, true, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 263,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 261,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 251,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 250,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 240,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      GenericFormPage,
      {
        config: movimientosBancosModuleConfig,
        initialData,
        onSave: handleSave,
        mode,
        renderExtraContent,
        readOnly: isReadOnlyOrigin
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 283,
        columnNumber: 13
      },
      this
    ),
    depositChecksModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[80vh] flex flex-col", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Seleccionar cheques a depositar" }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 295,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
          setDepositChecksModalOpen(false);
          setModalSelectedIds(/* @__PURE__ */ new Set());
          setToDepositChecksMeta(null);
        }, className: "text-gray-400 hover:text-gray-600", children: "×" }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 296,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 294,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 overflow-auto flex-1", children: loadingToDepositChecks ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-8 h-8 text-indigo-600 animate-spin" }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 300,
        columnNumber: 68
      }, this) }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 300,
        columnNumber: 13
      }, this) : toDepositChecksList.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 py-4", children: "No hay cheques disponibles para depositar." }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 302,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded", children: [
        /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 w-10" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 308,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Nº Cheque" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 309,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Titular" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 310,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase", children: "Valor" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 311,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Banco" }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 312,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Ref." }, void 0, false, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 313,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 307,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 306,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: toDepositChecksList.map(
            (c) => /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: modalSelectedIds.has(c.id),
                  onChange: () => handleToggleModalCheck(c.id),
                  className: "rounded border-gray-300",
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                  lineNumber: 320,
                  columnNumber: 57
                },
                this
              ) }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 319,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.check_number }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 326,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.check_holder ?? "-" }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 327,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm text-right", children: formatValue(Number(c.value), "currency") }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 328,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.bank_name ?? "-" }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 329,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-sm", children: c.reference_number ?? "-" }, void 0, false, {
                fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
                lineNumber: 330,
                columnNumber: 53
              }, this)
            ] }, c.id, true, {
              fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
              lineNumber: 318,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
            lineNumber: 316,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 305,
          columnNumber: 37
        }, this),
        toDepositChecksMeta && /* @__PURE__ */ jsxDEV(Pagination, { meta: toDepositChecksMeta, onPageChange: (u) => loadToDepositChecks(u) }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 336,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 304,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 298,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-t flex justify-end gap-2", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
          setDepositChecksModalOpen(false);
          setModalSelectedIds(/* @__PURE__ */ new Set());
          setToDepositChecksMeta(null);
        }, className: "px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 342,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddSelectedDepositChecks, className: "px-3 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700", children: "Añadir seleccionados" }, void 0, false, {
          fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
          lineNumber: 343,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
        lineNumber: 341,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 293,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
      lineNumber: 292,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx",
    lineNumber: 282,
    columnNumber: 5
  }, this);
};
_s(MovimientosBancosFormPage, "H/C9rGUoWImc9QZ2oepEOlQFFZ0=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = MovimientosBancosFormPage;
var _c;
$RefreshReg$(_c, "MovimientosBancosFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/movimientos_bancos/pages/MovimientosBancosFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa040QixTQW9EcEIsVUFwRG9COzs7Ozs7Ozs7Ozs7Ozs7OztBQWpONUIsU0FBU0EsVUFBVUMsV0FBV0MsbUJBQW1CO0FBQ2pELFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFdBQVdDLGlCQUFpQkMsZUFBZTtBQUNwRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxxQ0FBd0Q7QUFDakUsU0FBU0MseUJBQXlCO0FBaUJsQyxNQUFNQyw0QkFBbUQ7QUFBQSxFQUNyREMsU0FBUztBQUFBLEVBQ1RDLGdCQUFlLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BEQyxlQUFlO0FBQUEsRUFDZkMsUUFBUTtBQUFBLEVBQ1JDLFlBQVk7QUFBQSxFQUNaQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUFBLEVBQ1hDLGNBQWM7QUFDbEI7QUFFTyxhQUFNQyw0QkFBNEJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQyxRQUFNLEVBQUVDLEdBQUcsSUFBSTFCLFVBQTBCO0FBQ3pDLFFBQU0yQixXQUFXNUIsWUFBWTtBQUM3QixRQUFNNkIsT0FBT0YsS0FBSyxTQUFTO0FBRTNCLFFBQU0sRUFBRUcsTUFBTUMsWUFBWUMsU0FBU0MsT0FBT0MsU0FBUyxJQUFJM0IsWUFBMEJJLCtCQUErQmdCLEVBQUU7QUFDbEgsUUFBTSxDQUFDUSxhQUFhQyxjQUFjLElBQUl2QyxTQUE4QmdDLFNBQVMsV0FBVyxFQUFFLEdBQUdoQiwwQkFBMEIsSUFBb0IsSUFBSTtBQUUvSSxRQUFNLENBQUN3QiwwQkFBMEJDLDJCQUEyQixJQUFJekMsU0FBK0IsRUFBRTtBQUNqRyxRQUFNLENBQUMwQyx3QkFBd0JDLHlCQUF5QixJQUFJM0MsU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQzRDLHFCQUFxQkMsc0JBQXNCLElBQUk3QyxTQUErQixFQUFFO0FBQ3ZGLFFBQU0sQ0FBQzhDLHFCQUFxQkMsc0JBQXNCLElBQUkvQyxTQUErRCxJQUFJO0FBQ3pILFFBQU0sQ0FBQ2dELHdCQUF3QkMseUJBQXlCLElBQUlqRCxTQUFTLEtBQUs7QUFDMUUsUUFBTSxDQUFDa0Qsa0JBQWtCQyxtQkFBbUIsSUFBSW5ELFNBQXNCLG9CQUFJb0QsSUFBSSxDQUFDO0FBRS9FLFFBQU1DLHNDQUFzQ0EsQ0FBQ3BCLFNBQXVDO0FBQ2hGLFFBQUksQ0FBQ0EsUUFBUSxDQUFDQSxLQUFLcUIsZUFBZXJCLEtBQUtzQixhQUFhLEtBQU0sUUFBTztBQUNqRSxXQUFPdEIsS0FBS3FCLFlBQVlFLFNBQVMsWUFBWSxLQUFLdkIsS0FBS3FCLFlBQVlFLFNBQVMsY0FBYztBQUFBLEVBQzlGO0FBRUEsUUFBTUMsbUJBQW1CSixvQ0FBb0NuQixjQUFjSSxlQUFlLElBQUk7QUFFOUZyQyxZQUFVLE1BQU07QUFDWixRQUFJK0IsU0FBUyxVQUFVO0FBQ25CTyxxQkFBZSxFQUFFLEdBQUd2QiwwQkFBMEIsQ0FBaUI7QUFDL0Q7QUFBQSxJQUNKO0FBQ0EsUUFBSWtCLFlBQVk7QUFDWixZQUFNd0IsV0FBeUIsRUFBRSxHQUFHeEIsV0FBVztBQUMvQyxVQUFJQSxXQUFXWixrQkFBa0IsYUFBYVksV0FBV3lCLGFBQWE7QUFDbEVELGlCQUFTRSxPQUFPMUIsV0FBV3lCO0FBQUFBLE1BQy9CO0FBQ0EsVUFBSXpCLFdBQVdaLGtCQUFrQixZQUFZWSxXQUFXMkIsYUFBYTtBQUNqRUgsaUJBQVNFLE9BQU8xQixXQUFXMkI7QUFBQUEsTUFDL0I7QUFDQSxVQUFJM0IsV0FBVzRCLFVBQVdKLFVBQVNJLFlBQVk1QixXQUFXNEI7QUFDMUQsVUFBSTVCLFdBQVc2QixVQUFXTCxVQUFTSyxZQUFZN0IsV0FBVzZCO0FBQzFEeEIscUJBQWVtQixRQUFRO0FBQ3ZCLFVBQUl4QixXQUFXOEIscUJBQXFCQyxRQUFRO0FBQ3hDeEIsb0NBQTRCUCxXQUFXOEIsb0JBQW9CRSxJQUFJLENBQUFwQyxTQUFPO0FBQUEsVUFDbEVBO0FBQUFBLFVBQ0FxQyxxQkFBcUI7QUFBQSxVQUNyQkMsT0FBTztBQUFBLFVBQ1BuRCxTQUFTO0FBQUEsVUFDVDZDLFdBQVc7QUFBQSxVQUNYTyxjQUFjLElBQUl2QyxHQUFFO0FBQUEsVUFDcEJ3QyxZQUFZO0FBQUEsVUFDWkMsZ0JBQWdCO0FBQUEsVUFDaEJDLGNBQWM7QUFBQSxVQUNkQyxrQkFBa0I7QUFBQSxVQUNsQkMsY0FBYztBQUFBLFFBQ2xCLEVBQUUsQ0FBQztBQUFBLE1BQ1A7QUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUMxQyxNQUFNRSxVQUFVLENBQUM7QUFFckIsUUFBTXlDLHNCQUFzQnpFLFlBQVksQ0FBQzBFLFlBQXFCO0FBQzFEM0IsOEJBQTBCLElBQUk7QUFDOUIsVUFBTTRCLE1BQU1ELFVBQ05qRSxPQUEyQmlFLE9BQU8sSUFDbENqRSxPQUEyQiwrQkFBK0I7QUFDaEVrRSxRQUNLQyxLQUFLLENBQUFDLFFBQU87QUFDVGxDLDZCQUF1QmtDLElBQUlDLFFBQVEsRUFBRTtBQUNyQ2pDLDZCQUF1QmdDLElBQUlFLFFBQVEsSUFBSTtBQUFBLElBQzNDLENBQUMsRUFDQUMsTUFBTSxNQUFNO0FBQ1Q3RSxZQUFNK0IsTUFBTSxzQ0FBc0M7QUFDbERTLDZCQUF1QixFQUFFO0FBQ3pCRSw2QkFBdUIsSUFBSTtBQUFBLElBQy9CLENBQUMsRUFDQW9DLFFBQVEsTUFBTWxDLDBCQUEwQixLQUFLLENBQUM7QUFBQSxFQUN2RCxHQUFHLEVBQUU7QUFFTGhELFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ3lDLHVCQUF3QjtBQUM3QmlDLHdCQUFvQjtBQUFBLEVBQ3hCLEdBQUcsQ0FBQ2pDLHdCQUF3QmlDLG1CQUFtQixDQUFDO0FBRWhELFFBQU1TLCtCQUErQkEsTUFBTTtBQUN2Q2pDLHdCQUFvQixvQkFBSUMsSUFBSSxDQUFDO0FBQzdCVCw4QkFBMEIsSUFBSTtBQUFBLEVBQ2xDO0FBRUEsUUFBTTBDLHlCQUF5QkEsQ0FBQ3ZELFFBQWU7QUFDM0NxQix3QkFBb0IsQ0FBQW1DLFNBQVE7QUFDeEIsWUFBTUMsT0FBTyxJQUFJbkMsSUFBSWtDLElBQUk7QUFDekIsVUFBSUMsS0FBS0MsSUFBSTFELEdBQUUsRUFBR3lELE1BQUtFLE9BQU8zRCxHQUFFO0FBQUE7QUFDM0J5RCxhQUFLRyxJQUFJNUQsR0FBRTtBQUNoQixhQUFPeUQ7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1JLGlDQUFpQ0EsTUFBTTtBQUN6QyxVQUFNQyxRQUFRaEQsb0JBQW9CaUQsT0FBTyxDQUFBQyxNQUFLNUMsaUJBQWlCc0MsSUFBSU0sRUFBRWhFLEVBQUUsQ0FBQztBQUN4RSxVQUFNaUUsY0FBYyxJQUFJM0MsSUFBSVoseUJBQXlCMEIsSUFBSSxDQUFBNEIsTUFBS0EsRUFBRWhFLEVBQUUsQ0FBQztBQUNuRSxVQUFNa0UsVUFBVUosTUFBTUMsT0FBTyxDQUFBQyxNQUFLLENBQUNDLFlBQVlQLElBQUlNLEVBQUVoRSxFQUFFLENBQUM7QUFDeEQsUUFBSWtFLFFBQVEvQixPQUFReEIsNkJBQTRCLENBQUE2QyxTQUFRLENBQUMsR0FBR0EsTUFBTSxHQUFHVSxPQUFPLENBQUM7QUFDN0VyRCw4QkFBMEIsS0FBSztBQUMvQlEsd0JBQW9CLG9CQUFJQyxJQUFJLENBQUM7QUFBQSxFQUNqQztBQUVBLFFBQU02QywyQkFBMkJBLENBQUNuRSxRQUFlO0FBQzdDVyxnQ0FBNEIsQ0FBQTZDLFNBQVFBLEtBQUtPLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRWhFLE9BQU9BLEdBQUUsQ0FBQztBQUFBLEVBQ3JFO0FBRUEsUUFBTW9FLGFBQWEsT0FBT2xCLFNBQXVCO0FBQzdDLFFBQUl2QixrQkFBa0I7QUFDbEJwRCxZQUFNK0IsTUFBTSx3R0FBd0c7QUFDcEg7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDNEMsS0FBSy9ELFdBQVcsQ0FBQytELEtBQUs5RCxpQkFBaUI4RCxLQUFLekQsVUFBVSxNQUFNO0FBQzdEbEIsWUFBTStCLE1BQU0sMENBQTBDO0FBQ3REO0FBQUEsSUFDSjtBQUNBLFVBQU0rRCxZQUFZQyxPQUFPcEIsS0FBS3pELE1BQU07QUFDcEMsUUFBSSxDQUFDNkUsT0FBT0MsU0FBU0YsU0FBUyxLQUFLQSxhQUFhLEdBQUc7QUFDL0M5RixZQUFNK0IsTUFBTSxrQ0FBa0M7QUFDOUM7QUFBQSxJQUNKO0FBRUEsUUFBSTRDLEtBQUt4RCxlQUFlLGNBQWN3RCxLQUFLMUQsa0JBQWtCLFdBQVc7QUFDcEVqQixZQUFNK0IsTUFBTSwwREFBMEQ7QUFDdEU7QUFBQSxJQUNKO0FBRUEsUUFBSTRDLEtBQUt4RCxlQUFlLFlBQVl3RCxLQUFLMUQsa0JBQWtCLFVBQVU7QUFDakVqQixZQUFNK0IsTUFBTSx1REFBdUQ7QUFDbkU7QUFBQSxJQUNKO0FBRUEsVUFBTWtFLFVBQWlDO0FBQUEsTUFDbkNyRixTQUFTK0QsS0FBSy9EO0FBQUFBLE1BQ2RDLGVBQWU4RCxLQUFLOUQ7QUFBQUEsTUFDcEJJLGVBQWUwRCxLQUFLMUQ7QUFBQUEsTUFDcEJDLFFBQVE2RSxPQUFPcEIsS0FBS3pELE1BQU07QUFBQSxNQUMxQkMsWUFBWXdELEtBQUt4RDtBQUFBQSxNQUNqQkcsY0FBY3FELEtBQUtyRCxnQkFBZ0I7QUFBQSxJQUN2QztBQUNBLFFBQUlxRCxLQUFLMUQsa0JBQWtCLFdBQVc7QUFDbENnRixjQUFRN0UsWUFBWXVELEtBQUt2RCxhQUFhO0FBQ3RDNkUsY0FBUTVFLFlBQVk7QUFBQSxJQUN4QixPQUFPO0FBQ0g0RSxjQUFRNUUsWUFBWXNELEtBQUt0RCxhQUFhO0FBQ3RDNEUsY0FBUTdFLFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUllLHlCQUF5QnlCLFNBQVMsR0FBRztBQUNyQ3FDLGNBQVF0QyxzQkFBc0J4Qix5QkFBeUIwQixJQUFJLENBQUE0QixNQUFLQSxFQUFFaEUsRUFBRTtBQUFBLElBQ3hFO0FBRUEsVUFBTXlFLFNBQVMsRUFBRSxHQUFHRCxRQUFRO0FBQzVCLFdBQVFDLE9BQWV6QztBQUN2QixXQUFReUMsT0FBZXhDO0FBQ3ZCLFdBQVF3QyxPQUFlNUM7QUFDdkIsV0FBUTRDLE9BQWUxQztBQUN2QixXQUFRMEMsT0FBZUM7QUFDdkIsV0FBUUQsT0FBZUU7QUFDdkIsV0FBUUYsT0FBZTNDO0FBRXZCLFFBQUk7QUFDQSxZQUFNdkIsU0FBU2tFLE1BQStCO0FBQzlDbEcsWUFBTXFHLFFBQVExRSxTQUFTLFdBQVcsaUNBQWlDLG1DQUFtQztBQUN0R0QsZUFBU2hCLGtCQUFrQkQsOEJBQThCNkYsU0FBUyxDQUFDO0FBQUEsSUFDdkUsUUFBUTtBQUNKdEcsWUFBTStCLE1BQU0saUNBQWlDO0FBQUEsSUFDakQ7QUFBQSxFQUNKO0FBRUEsTUFBSUosU0FBUyxRQUFRO0FBQ2pCLFFBQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGdEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFDekQsUUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQ3ZELFFBQUksQ0FBQ0UsWUFBYSxRQUFPLHVCQUFDLFNBQUksa0RBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLEVBQ3BFO0FBRUEsTUFBSU4sU0FBUyxZQUFZLENBQUNNLFlBQWEsUUFBTztBQUU5QyxRQUFNc0UscUJBQXFCQSxDQUFDQyxhQUEyQjtBQUNuRCxRQUFJQSxTQUFTckYsZUFBZSxXQUFZLFFBQU87QUFDL0MsV0FDSSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMENBQXlDLG1DQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDMUU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVM0RDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsbUJBQWdCLFdBQVUsa0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQUxoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BQ0M1Qyx5QkFBeUJ5QixTQUFTLEtBQy9CLHVCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1FQUFrRSx5QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxVQUN6Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0UscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSxvQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRix1QkFBQyxRQUFHLFdBQVUsb0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQSxhQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWnpCLG1DQUF5QjBCO0FBQUFBLFVBQUksQ0FBQzRCLE1BQzNCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUscUJBQXFCQSxZQUFFekIsZ0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ3pELHNCQUFZd0YsT0FBT04sRUFBRTFCLEtBQUssR0FBRyxVQUFVLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdkYsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQjBCLFlBQUVoQyxhQUFhLE9BQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQmdDLFlBQUVyQixvQkFBb0IsT0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUM3RCx1QkFBQyxRQUFHLFdBQVUsYUFDVixpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU13Qix5QkFBeUJILEVBQUVoRSxFQUFFLEdBQUcsV0FBVSxtQ0FBa0MsT0FBTSxVQUFTLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUSxLQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySSxLQUQvSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQS2dFLEVBQUVoRSxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxRQUNILEtBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQSxLQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsU0FuQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLEVBRVI7QUFFQSxTQUNJLG1DQUNJO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVFoQjtBQUFBQSxRQUNSO0FBQUEsUUFDQSxRQUFRb0Y7QUFBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVV6QztBQUFBQTtBQUFBQSxNQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU0rQjtBQUFBLElBRTlCZiwwQkFDRyx1QkFBQyxTQUFJLFdBQVUsdUVBQ1gsaUNBQUMsU0FBSSxXQUFVLDZFQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQywrQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFQyxvQ0FBMEIsS0FBSztBQUFHUSw4QkFBb0Isb0JBQUlDLElBQUksQ0FBQztBQUFHTCxpQ0FBdUIsSUFBSTtBQUFBLFFBQUcsR0FBRyxXQUFVLHFDQUFvQyxpQkFBeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5TDtBQUFBLFdBRjdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNWQyxtQ0FDRyx1QkFBQyxTQUFJLFdBQVUseUNBQXdDLGlDQUFDLGFBQVUsV0FBVSwwQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRCxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFILElBQ3JISixvQkFBb0JxQixXQUFXLElBQy9CLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMERBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0YsSUFFcEYsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxvQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQy9CLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0UseUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlGO0FBQUEsWUFDekYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSx1QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUN2Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0UscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsWUFDckYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSxvQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQU54RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNackIsOEJBQW9Cc0I7QUFBQUEsWUFBSSxDQUFDNEIsTUFDdEIsdUJBQUMsUUFDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSxhQUNWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTNUMsaUJBQWlCc0MsSUFBSU0sRUFBRWhFLEVBQUU7QUFBQSxrQkFDbEMsVUFBVSxNQUFNdUQsdUJBQXVCUyxFQUFFaEUsRUFBRTtBQUFBLGtCQUMzQyxXQUFVO0FBQUEsa0JBQTBCLGNBQWE7QUFBQTtBQUFBLGdCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJMEQsS0FMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQmdFLFlBQUV6QixnQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQSxjQUNsRCx1QkFBQyxRQUFHLFdBQVUscUJBQXFCeUIsWUFBRXRCLGdCQUFnQixPQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pELHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0M1RCxzQkFBWXdGLE9BQU9OLEVBQUUxQixLQUFLLEdBQUcsVUFBVSxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RjtBQUFBLGNBQ3ZGLHVCQUFDLFFBQUcsV0FBVSxxQkFBcUIwQixZQUFFaEMsYUFBYSxPQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGNBQ3RELHVCQUFDLFFBQUcsV0FBVSxxQkFBcUJnQyxZQUFFckIsb0JBQW9CLE9BQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsaUJBWnhEcUIsRUFBRWhFLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFVBQ0gsS0FoQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsUUFDQ2dCLHVCQUNHLHVCQUFDLGNBQVcsTUFBTUEscUJBQXFCLGNBQWMsQ0FBQ2dFLE1BQU1uQyxvQkFBb0JtQyxDQUFDLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxXQWhDM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQSxLQXhDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ1g7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU07QUFBRW5FLG9DQUEwQixLQUFLO0FBQUdRLDhCQUFvQixvQkFBSUMsSUFBSSxDQUFDO0FBQUdMLGlDQUF1QixJQUFJO0FBQUEsUUFBRyxHQUFHLFdBQVUsMkdBQTBHLHdCQUE5UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNRO0FBQUEsUUFDdFEsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUzRDLGdDQUFnQyxXQUFVLG1IQUFrSCxvQ0FBM0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErTTtBQUFBLFdBRm5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBbkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREEsS0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLE9BaEVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRUE7QUFFUjtBQUFFOUQsR0FsU1dELDJCQUF5QjtBQUFBLFVBQ25CeEIsV0FDRUQsYUFHc0NPLFdBQVc7QUFBQTtBQUFBcUcsS0FMekRuRjtBQUF5QixJQUFBbUY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJ1c2VOYXZpZ2F0ZSIsInVzZVBhcmFtcyIsInRvYXN0IiwiRmFTcGlubmVyIiwiRmFNb25leUNoZWNrQWx0IiwiRmFUcmFzaCIsIkdlbmVyaWNGb3JtUGFnZSIsInVzZUNydWRJdGVtIiwiZ2V0QWxsIiwiZm9ybWF0VmFsdWUiLCJQYWdpbmF0aW9uIiwibW92aW1pZW50b3NCYW5jb3NNb2R1bGVDb25maWciLCJnZXRMaXN0UmV0dXJuUGF0aCIsImluaXRpYWxCYW5rTW92ZW1lbnRWYWx1ZXMiLCJiYW5rX2lkIiwibW92ZW1lbnRfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwibW92ZW1lbnRfdHlwZSIsImFtb3VudCIsInZhbHVlX3R5cGUiLCJjbGllbnRfaWQiLCJ2ZW5kb3JfaWQiLCJvYnNlcnZhdGlvbnMiLCJNb3ZpbWllbnRvc0JhbmNvc0Zvcm1QYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwibW9kZSIsIml0ZW0iLCJsb2FkZWRJdGVtIiwibG9hZGluZyIsImVycm9yIiwic2F2ZUl0ZW0iLCJpbml0aWFsRGF0YSIsInNldEluaXRpYWxEYXRhIiwic2VsZWN0ZWRDaGVxdWVzVG9EZXBvc2l0Iiwic2V0U2VsZWN0ZWRDaGVxdWVzVG9EZXBvc2l0IiwiZGVwb3NpdENoZWNrc01vZGFsT3BlbiIsInNldERlcG9zaXRDaGVja3NNb2RhbE9wZW4iLCJ0b0RlcG9zaXRDaGVja3NMaXN0Iiwic2V0VG9EZXBvc2l0Q2hlY2tzTGlzdCIsInRvRGVwb3NpdENoZWNrc01ldGEiLCJzZXRUb0RlcG9zaXRDaGVja3NNZXRhIiwibG9hZGluZ1RvRGVwb3NpdENoZWNrcyIsInNldExvYWRpbmdUb0RlcG9zaXRDaGVja3MiLCJtb2RhbFNlbGVjdGVkSWRzIiwic2V0TW9kYWxTZWxlY3RlZElkcyIsIlNldCIsImlzT3JpZ2luYXRlZEZyb21Db2xsZWN0aW9uT3JQYXltZW50Iiwic291cmNlX3R5cGUiLCJzb3VyY2VfaWQiLCJpbmNsdWRlcyIsImlzUmVhZE9ubHlPcmlnaW4iLCJoeWRyYXRlZCIsImNsaWVudF9uYW1lIiwibmFtZSIsInZlbmRvcl9uYW1lIiwiYmFua19uYW1lIiwiYmFua19jb2RlIiwiZGVwb3NpdGVkX2NoZWNrX2lkcyIsImxlbmd0aCIsIm1hcCIsInBheW1lbnRfbWV0aG9kX2NvZGUiLCJ2YWx1ZSIsImNoZWNrX251bWJlciIsImNoZWNrX2RhdGUiLCJjaGVja19kdWVfZGF0ZSIsImNoZWNrX2hvbGRlciIsInJlZmVyZW5jZV9udW1iZXIiLCJpc19kZXBvc2l0ZWQiLCJsb2FkVG9EZXBvc2l0Q2hlY2tzIiwicGFnZVVybCIsInJlcSIsInRoZW4iLCJyZXMiLCJkYXRhIiwibWV0YSIsImNhdGNoIiwiZmluYWxseSIsImhhbmRsZU9wZW5EZXBvc2l0Q2hlY2tzTW9kYWwiLCJoYW5kbGVUb2dnbGVNb2RhbENoZWNrIiwicHJldiIsIm5leHQiLCJoYXMiLCJkZWxldGUiLCJhZGQiLCJoYW5kbGVBZGRTZWxlY3RlZERlcG9zaXRDaGVja3MiLCJ0b0FkZCIsImZpbHRlciIsImMiLCJleGlzdGluZ0lkcyIsIm5ld09uZXMiLCJoYW5kbGVSZW1vdmVEZXBvc2l0Q2hlY2siLCJoYW5kbGVTYXZlIiwiYW1vdW50TnVtIiwiTnVtYmVyIiwiaXNGaW5pdGUiLCJwYXlsb2FkIiwidG9TZW5kIiwiY3VzdG9tZXJfY29kZSIsInZlbmRvcl9jb2RlIiwic3VjY2VzcyIsImJhc2VSb3V0ZSIsInJlbmRlckV4dHJhQ29udGVudCIsImZvcm1EYXRhIiwidSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vdmltaWVudG9zQmFuY29zRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNwaW5uZXIsIEZhTW9uZXlDaGVja0FsdCwgRmFUcmFzaCB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IEdlbmVyaWNGb3JtUGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNGb3JtUGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEFsbCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuaW1wb3J0IHR5cGUgeyBQYWdpbmF0ZWRSZXNwb25zZSB9IGZyb20gJy4uLy4uLy4uL2ludGVyZmFjZXMvQXBpJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5pbXBvcnQgeyBQYWdpbmF0aW9uIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUGFnaW5hdGlvbic7XG5pbXBvcnQgeyBtb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZywgdHlwZSBCYW5rTW92ZW1lbnQgfSBmcm9tICcuLi9tb3ZpbWllbnRvc19iYW5jb3MuY29uZmlnJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG4vKiogw410ZW0gZGUgY2hlcXVlIGEgZGVwb3NpdGFyIChHRVQgY29sbGVjdGlvbnMvdG8tZGVwb3NpdC1jaGVja3MpICovXG5leHBvcnQgaW50ZXJmYWNlIFRvRGVwb3NpdENoZWNrSXRlbSB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBwYXltZW50X21ldGhvZF9jb2RlOiBzdHJpbmc7XG4gICAgdmFsdWU6IHN0cmluZztcbiAgICBiYW5rX2lkOiBudW1iZXIgfCBudWxsO1xuICAgIGJhbmtfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBjaGVja19udW1iZXI6IHN0cmluZztcbiAgICBjaGVja19kYXRlOiBzdHJpbmc7XG4gICAgY2hlY2tfZHVlX2RhdGU6IHN0cmluZztcbiAgICBjaGVja19ob2xkZXI6IHN0cmluZyB8IG51bGw7XG4gICAgcmVmZXJlbmNlX251bWJlcjogc3RyaW5nIHwgbnVsbDtcbiAgICBpc19kZXBvc2l0ZWQ6IGJvb2xlYW47XG59XG5cbmNvbnN0IGluaXRpYWxCYW5rTW92ZW1lbnRWYWx1ZXM6IFBhcnRpYWw8QmFua01vdmVtZW50PiA9IHtcbiAgICBiYW5rX2lkOiAwLFxuICAgIG1vdmVtZW50X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgIG1vdmVtZW50X3R5cGU6ICdFTlRSQURBJyxcbiAgICBhbW91bnQ6IDAsXG4gICAgdmFsdWVfdHlwZTogJ0RFUE9TSVRPJyxcbiAgICBjbGllbnRfaWQ6IG51bGwsXG4gICAgdmVuZG9yX2lkOiBudWxsLFxuICAgIG9ic2VydmF0aW9uczogbnVsbCxcbn07XG5cbmV4cG9ydCBjb25zdCBNb3ZpbWllbnRvc0JhbmNvc0Zvcm1QYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCB7IGl0ZW06IGxvYWRlZEl0ZW0sIGxvYWRpbmcsIGVycm9yLCBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08QmFua01vdmVtZW50Pihtb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IFtpbml0aWFsRGF0YSwgc2V0SW5pdGlhbERhdGFdID0gdXNlU3RhdGU8QmFua01vdmVtZW50IHwgbnVsbD4obW9kZSA9PT0gJ2NyZWF0ZScgPyB7IC4uLmluaXRpYWxCYW5rTW92ZW1lbnRWYWx1ZXMgfSBhcyBCYW5rTW92ZW1lbnQgOiBudWxsKTtcblxuICAgIGNvbnN0IFtzZWxlY3RlZENoZXF1ZXNUb0RlcG9zaXQsIHNldFNlbGVjdGVkQ2hlcXVlc1RvRGVwb3NpdF0gPSB1c2VTdGF0ZTxUb0RlcG9zaXRDaGVja0l0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFtkZXBvc2l0Q2hlY2tzTW9kYWxPcGVuLCBzZXREZXBvc2l0Q2hlY2tzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdG9EZXBvc2l0Q2hlY2tzTGlzdCwgc2V0VG9EZXBvc2l0Q2hlY2tzTGlzdF0gPSB1c2VTdGF0ZTxUb0RlcG9zaXRDaGVja0l0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFt0b0RlcG9zaXRDaGVja3NNZXRhLCBzZXRUb0RlcG9zaXRDaGVja3NNZXRhXSA9IHVzZVN0YXRlPFBhZ2luYXRlZFJlc3BvbnNlPFRvRGVwb3NpdENoZWNrSXRlbT5bJ21ldGEnXSB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtsb2FkaW5nVG9EZXBvc2l0Q2hlY2tzLCBzZXRMb2FkaW5nVG9EZXBvc2l0Q2hlY2tzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbbW9kYWxTZWxlY3RlZElkcywgc2V0TW9kYWxTZWxlY3RlZElkc10gPSB1c2VTdGF0ZTxTZXQ8bnVtYmVyPj4obmV3IFNldCgpKTtcblxuICAgIGNvbnN0IGlzT3JpZ2luYXRlZEZyb21Db2xsZWN0aW9uT3JQYXltZW50ID0gKGl0ZW06IEJhbmtNb3ZlbWVudCB8IG51bGwpOiBib29sZWFuID0+IHtcbiAgICAgICAgaWYgKCFpdGVtIHx8ICFpdGVtLnNvdXJjZV90eXBlIHx8IGl0ZW0uc291cmNlX2lkID09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICAgICAgcmV0dXJuIGl0ZW0uc291cmNlX3R5cGUuaW5jbHVkZXMoJ0NvbGxlY3Rpb24nKSB8fCBpdGVtLnNvdXJjZV90eXBlLmluY2x1ZGVzKCdQYXltZW50T3JkZXInKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaXNSZWFkT25seU9yaWdpbiA9IGlzT3JpZ2luYXRlZEZyb21Db2xsZWN0aW9uT3JQYXltZW50KGxvYWRlZEl0ZW0gPz8gaW5pdGlhbERhdGEgPz8gbnVsbCk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAobW9kZSA9PT0gJ2NyZWF0ZScpIHtcbiAgICAgICAgICAgIHNldEluaXRpYWxEYXRhKHsgLi4uaW5pdGlhbEJhbmtNb3ZlbWVudFZhbHVlcyB9IGFzIEJhbmtNb3ZlbWVudCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxvYWRlZEl0ZW0pIHtcbiAgICAgICAgICAgIGNvbnN0IGh5ZHJhdGVkOiBCYW5rTW92ZW1lbnQgPSB7IC4uLmxvYWRlZEl0ZW0gfTtcbiAgICAgICAgICAgIGlmIChsb2FkZWRJdGVtLm1vdmVtZW50X3R5cGUgPT09ICdFTlRSQURBJyAmJiBsb2FkZWRJdGVtLmNsaWVudF9uYW1lKSB7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWQubmFtZSA9IGxvYWRlZEl0ZW0uY2xpZW50X25hbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9hZGVkSXRlbS5tb3ZlbWVudF90eXBlID09PSAnU0FMSURBJyAmJiBsb2FkZWRJdGVtLnZlbmRvcl9uYW1lKSB7XG4gICAgICAgICAgICAgICAgaHlkcmF0ZWQubmFtZSA9IGxvYWRlZEl0ZW0udmVuZG9yX25hbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9hZGVkSXRlbS5iYW5rX25hbWUpIGh5ZHJhdGVkLmJhbmtfbmFtZSA9IGxvYWRlZEl0ZW0uYmFua19uYW1lO1xuICAgICAgICAgICAgaWYgKGxvYWRlZEl0ZW0uYmFua19jb2RlKSBoeWRyYXRlZC5iYW5rX2NvZGUgPSBsb2FkZWRJdGVtLmJhbmtfY29kZTtcbiAgICAgICAgICAgIHNldEluaXRpYWxEYXRhKGh5ZHJhdGVkKTtcbiAgICAgICAgICAgIGlmIChsb2FkZWRJdGVtLmRlcG9zaXRlZF9jaGVja19pZHM/Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2hlcXVlc1RvRGVwb3NpdChsb2FkZWRJdGVtLmRlcG9zaXRlZF9jaGVja19pZHMubWFwKGlkID0+ICh7XG4gICAgICAgICAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgICAgICAgICBwYXltZW50X21ldGhvZF9jb2RlOiAnQ0hFJyxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICcwJyxcbiAgICAgICAgICAgICAgICAgICAgYmFua19pZDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgYmFua19uYW1lOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBjaGVja19udW1iZXI6IGAjJHtpZH1gLFxuICAgICAgICAgICAgICAgICAgICBjaGVja19kYXRlOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tfZHVlX2RhdGU6ICcnLFxuICAgICAgICAgICAgICAgICAgICBjaGVja19ob2xkZXI6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIHJlZmVyZW5jZV9udW1iZXI6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgIGlzX2RlcG9zaXRlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgfSkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFttb2RlLCBsb2FkZWRJdGVtXSk7XG5cbiAgICBjb25zdCBsb2FkVG9EZXBvc2l0Q2hlY2tzID0gdXNlQ2FsbGJhY2soKHBhZ2VVcmw/OiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZ1RvRGVwb3NpdENoZWNrcyh0cnVlKTtcbiAgICAgICAgY29uc3QgcmVxID0gcGFnZVVybFxuICAgICAgICAgICAgPyBnZXRBbGw8VG9EZXBvc2l0Q2hlY2tJdGVtPihwYWdlVXJsKVxuICAgICAgICAgICAgOiBnZXRBbGw8VG9EZXBvc2l0Q2hlY2tJdGVtPignY29sbGVjdGlvbnMvdG8tZGVwb3NpdC1jaGVja3MnKTtcbiAgICAgICAgcmVxXG4gICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgIHNldFRvRGVwb3NpdENoZWNrc0xpc3QocmVzLmRhdGEgfHwgW10pO1xuICAgICAgICAgICAgICAgIHNldFRvRGVwb3NpdENoZWNrc01ldGEocmVzLm1ldGEgPz8gbnVsbCk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIGNoZXF1ZXMgYSBkZXBvc2l0YXIuJyk7XG4gICAgICAgICAgICAgICAgc2V0VG9EZXBvc2l0Q2hlY2tzTGlzdChbXSk7XG4gICAgICAgICAgICAgICAgc2V0VG9EZXBvc2l0Q2hlY2tzTWV0YShudWxsKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nVG9EZXBvc2l0Q2hlY2tzKGZhbHNlKSk7XG4gICAgfSwgW10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFkZXBvc2l0Q2hlY2tzTW9kYWxPcGVuKSByZXR1cm47XG4gICAgICAgIGxvYWRUb0RlcG9zaXRDaGVja3MoKTtcbiAgICB9LCBbZGVwb3NpdENoZWNrc01vZGFsT3BlbiwgbG9hZFRvRGVwb3NpdENoZWNrc10pO1xuXG4gICAgY29uc3QgaGFuZGxlT3BlbkRlcG9zaXRDaGVja3NNb2RhbCA9ICgpID0+IHtcbiAgICAgICAgc2V0TW9kYWxTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgICAgICBzZXREZXBvc2l0Q2hlY2tzTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUb2dnbGVNb2RhbENoZWNrID0gKGlkOiBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0TW9kYWxTZWxlY3RlZElkcyhwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBuZXcgU2V0KHByZXYpO1xuICAgICAgICAgICAgaWYgKG5leHQuaGFzKGlkKSkgbmV4dC5kZWxldGUoaWQpO1xuICAgICAgICAgICAgZWxzZSBuZXh0LmFkZChpZCk7XG4gICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUFkZFNlbGVjdGVkRGVwb3NpdENoZWNrcyA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgdG9BZGQgPSB0b0RlcG9zaXRDaGVja3NMaXN0LmZpbHRlcihjID0+IG1vZGFsU2VsZWN0ZWRJZHMuaGFzKGMuaWQpKTtcbiAgICAgICAgY29uc3QgZXhpc3RpbmdJZHMgPSBuZXcgU2V0KHNlbGVjdGVkQ2hlcXVlc1RvRGVwb3NpdC5tYXAoYyA9PiBjLmlkKSk7XG4gICAgICAgIGNvbnN0IG5ld09uZXMgPSB0b0FkZC5maWx0ZXIoYyA9PiAhZXhpc3RpbmdJZHMuaGFzKGMuaWQpKTtcbiAgICAgICAgaWYgKG5ld09uZXMubGVuZ3RoKSBzZXRTZWxlY3RlZENoZXF1ZXNUb0RlcG9zaXQocHJldiA9PiBbLi4ucHJldiwgLi4ubmV3T25lc10pO1xuICAgICAgICBzZXREZXBvc2l0Q2hlY2tzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgc2V0TW9kYWxTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVSZW1vdmVEZXBvc2l0Q2hlY2sgPSAoaWQ6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRTZWxlY3RlZENoZXF1ZXNUb0RlcG9zaXQocHJldiA9PiBwcmV2LmZpbHRlcihjID0+IGMuaWQgIT09IGlkKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogQmFua01vdmVtZW50KSA9PiB7XG4gICAgICAgIGlmIChpc1JlYWRPbmx5T3JpZ2luKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gZXMgcG9zaWJsZSBlZGl0YXIgbW92aW1pZW50b3MgZGUgYmFuY28gZ2VuZXJhZG9zIGF1dG9tw6F0aWNhbWVudGUgZGVzZGUgY29icmFuemFzIHUgw7NyZGVuZXMgZGUgcGFnby4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRhdGEuYmFua19pZCB8fCAhZGF0YS5tb3ZlbWVudF9kYXRlIHx8IGRhdGEuYW1vdW50ID09IG51bGwpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdCYW5jbywgZmVjaGEgZSBpbXBvcnRlIHNvbiBvYmxpZ2F0b3Jpb3MuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYW1vdW50TnVtID0gTnVtYmVyKGRhdGEuYW1vdW50KTtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoYW1vdW50TnVtKSB8fCBhbW91bnROdW0gPD0gMCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0VsIGltcG9ydGUgZGViZSBzZXIgbWF5b3IgcXVlIDAuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZGF0YS52YWx1ZV90eXBlID09PSAnREVQT1NJVE8nICYmIGRhdGEubW92ZW1lbnRfdHlwZSAhPT0gJ0VOVFJBREEnKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGFyYSB1biBEZXDDs3NpdG8gZWwgdGlwbyBkZSBtb3ZpbWllbnRvIGRlYmUgc2VyIEVOVFJBREEuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZGF0YS52YWx1ZV90eXBlID09PSAnUkVUSVJPJyAmJiBkYXRhLm1vdmVtZW50X3R5cGUgIT09ICdTQUxJREEnKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignUGFyYSB1biBSZXRpcm8gZWwgdGlwbyBkZSBtb3ZpbWllbnRvIGRlYmUgc2VyIFNBTElEQS4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IFBhcnRpYWw8QmFua01vdmVtZW50PiA9IHtcbiAgICAgICAgICAgIGJhbmtfaWQ6IGRhdGEuYmFua19pZCxcbiAgICAgICAgICAgIG1vdmVtZW50X2RhdGU6IGRhdGEubW92ZW1lbnRfZGF0ZSxcbiAgICAgICAgICAgIG1vdmVtZW50X3R5cGU6IGRhdGEubW92ZW1lbnRfdHlwZSxcbiAgICAgICAgICAgIGFtb3VudDogTnVtYmVyKGRhdGEuYW1vdW50KSxcbiAgICAgICAgICAgIHZhbHVlX3R5cGU6IGRhdGEudmFsdWVfdHlwZSxcbiAgICAgICAgICAgIG9ic2VydmF0aW9uczogZGF0YS5vYnNlcnZhdGlvbnMgfHwgbnVsbCxcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGRhdGEubW92ZW1lbnRfdHlwZSA9PT0gJ0VOVFJBREEnKSB7XG4gICAgICAgICAgICBwYXlsb2FkLmNsaWVudF9pZCA9IGRhdGEuY2xpZW50X2lkID8/IG51bGw7XG4gICAgICAgICAgICBwYXlsb2FkLnZlbmRvcl9pZCA9IG51bGw7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwYXlsb2FkLnZlbmRvcl9pZCA9IGRhdGEudmVuZG9yX2lkID8/IG51bGw7XG4gICAgICAgICAgICBwYXlsb2FkLmNsaWVudF9pZCA9IG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc2VsZWN0ZWRDaGVxdWVzVG9EZXBvc2l0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHBheWxvYWQuZGVwb3NpdGVkX2NoZWNrX2lkcyA9IHNlbGVjdGVkQ2hlcXVlc1RvRGVwb3NpdC5tYXAoYyA9PiBjLmlkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHRvU2VuZCA9IHsgLi4ucGF5bG9hZCB9O1xuICAgICAgICBkZWxldGUgKHRvU2VuZCBhcyBhbnkpLmJhbmtfbmFtZTtcbiAgICAgICAgZGVsZXRlICh0b1NlbmQgYXMgYW55KS5iYW5rX2NvZGU7XG4gICAgICAgIGRlbGV0ZSAodG9TZW5kIGFzIGFueSkuY2xpZW50X25hbWU7XG4gICAgICAgIGRlbGV0ZSAodG9TZW5kIGFzIGFueSkudmVuZG9yX25hbWU7XG4gICAgICAgIGRlbGV0ZSAodG9TZW5kIGFzIGFueSkuY3VzdG9tZXJfY29kZTtcbiAgICAgICAgZGVsZXRlICh0b1NlbmQgYXMgYW55KS52ZW5kb3JfY29kZTtcbiAgICAgICAgZGVsZXRlICh0b1NlbmQgYXMgYW55KS5uYW1lO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBzYXZlSXRlbSh0b1NlbmQgYXMgUGFydGlhbDxCYW5rTW92ZW1lbnQ+KTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MobW9kZSA9PT0gJ2NyZWF0ZScgPyAnTW92aW1pZW50byBjcmVhZG8gY29uIMOpeGl0by4nIDogJ01vdmltaWVudG8gYWN0dWFsaXphZG8gY29uIMOpeGl0by4nKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG1vdmltaWVudG9zQmFuY29zTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBndWFyZGFyIGVsIG1vdmltaWVudG8uJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKG1vZGUgPT09ICdlZGl0Jykge1xuICAgICAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGF0b3MgZGVsIG1vdmltaWVudG8uLi48L2Rpdj47XG4gICAgICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICAgICAgaWYgKCFpbml0aWFsRGF0YSkgcmV0dXJuIDxkaXY+TW92aW1pZW50byBkZSBiYW5jbyBubyBlbmNvbnRyYWRvLjwvZGl2PjtcbiAgICB9XG5cbiAgICBpZiAobW9kZSA9PT0gJ2NyZWF0ZScgJiYgIWluaXRpYWxEYXRhKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHJlbmRlckV4dHJhQ29udGVudCA9IChmb3JtRGF0YTogQmFua01vdmVtZW50KSA9PiB7XG4gICAgICAgIGlmIChmb3JtRGF0YS52YWx1ZV90eXBlICE9PSAnREVQT1NJVE8nKSByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItM1wiPkNoZXF1ZXMgYSBkZXBvc2l0YXI8L2gzPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5EZXBvc2l0Q2hlY2tzTW9kYWx9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGYU1vbmV5Q2hlY2tBbHQgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz4gU2VsZWNjaW9uYXIgY2hlcXVlc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZENoZXF1ZXNUb0RlcG9zaXQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBvdmVyZmxvdy14LWF1dG8gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5OwrogQ2hlcXVlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+VmFsb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkJhbmNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5SZWYuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdy0xNlwiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENoZXF1ZXNUb0RlcG9zaXQubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtjLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj57Yy5jaGVja19udW1iZXJ9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZShOdW1iZXIoYy52YWx1ZSksICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtXCI+e2MuYmFua19uYW1lID8/ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbVwiPntjLnJlZmVyZW5jZV9udW1iZXIgPz8gJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVEZXBvc2l0Q2hlY2soYy5pZCl9IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDBcIiB0aXRsZT1cIlF1aXRhclwiPjxGYVRyYXNoIC8+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8R2VuZXJpY0Zvcm1QYWdlXG4gICAgICAgICAgICAgICAgY29uZmlnPXttb3ZpbWllbnRvc0JhbmNvc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbERhdGEhfVxuICAgICAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICAgICAgICAgIHJlbmRlckV4dHJhQ29udGVudD17cmVuZGVyRXh0cmFDb250ZW50fVxuICAgICAgICAgICAgICAgIHJlYWRPbmx5PXtpc1JlYWRPbmx5T3JpZ2lufVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtkZXBvc2l0Q2hlY2tzTW9kYWxPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay81MCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy14bCBtYXgtdy0zeGwgdy1mdWxsIG1heC1oLVs4MHZoXSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMyBib3JkZXItYiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U2VsZWNjaW9uYXIgY2hlcXVlcyBhIGRlcG9zaXRhcjwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXREZXBvc2l0Q2hlY2tzTW9kYWxPcGVuKGZhbHNlKTsgc2V0TW9kYWxTZWxlY3RlZElkcyhuZXcgU2V0KCkpOyBzZXRUb0RlcG9zaXRDaGVja3NNZXRhKG51bGwpOyB9fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIj7DlzwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBvdmVyZmxvdy1hdXRvIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nVG9EZXBvc2l0Q2hlY2tzID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LThcIj48RmFTcGlubmVyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1pbmRpZ28tNjAwIGFuaW1hdGUtc3BpblwiIC8+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IHRvRGVwb3NpdENoZWNrc0xpc3QubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgcHktNFwiPk5vIGhheSBjaGVxdWVzIGRpc3BvbmlibGVzIHBhcmEgZGVwb3NpdGFyLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB3LTEwXCI+PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5OwrogQ2hlcXVlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5UaXR1bGFyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+VmFsb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkJhbmNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5SZWYuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RvRGVwb3NpdENoZWNrc0xpc3QubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtjLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e21vZGFsU2VsZWN0ZWRJZHMuaGFzKGMuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVRvZ2dsZU1vZGFsQ2hlY2soYy5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1ncmF5LTMwMFwiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj57Yy5jaGVja19udW1iZXJ9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj57Yy5jaGVja19ob2xkZXIgPz8gJy0nfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtIHRleHQtcmlnaHRcIj57Zm9ybWF0VmFsdWUoTnVtYmVyKGMudmFsdWUpLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1zbVwiPntjLmJhbmtfbmFtZSA/PyAnLSd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc21cIj57Yy5yZWZlcmVuY2VfbnVtYmVyID8/ICctJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG9EZXBvc2l0Q2hlY2tzTWV0YSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2luYXRpb24gbWV0YT17dG9EZXBvc2l0Q2hlY2tzTWV0YX0gb25QYWdlQ2hhbmdlPXsodSkgPT4gbG9hZFRvRGVwb3NpdENoZWNrcyh1KX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJvcmRlci10IGZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldERlcG9zaXRDaGVja3NNb2RhbE9wZW4oZmFsc2UpOyBzZXRNb2RhbFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7IHNldFRvRGVwb3NpdENoZWNrc01ldGEobnVsbCk7IH19IGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWdyYXktNTBcIj5DYW5jZWxhcjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFkZFNlbGVjdGVkRGVwb3NpdENoZWNrc30gY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBob3ZlcjpiZy1pbmRpZ28tNzAwXCI+QcOxYWRpciBzZWxlY2Npb25hZG9zPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICA8Lz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbW92aW1pZW50b3NfYmFuY29zL3BhZ2VzL01vdmltaWVudG9zQmFuY29zRm9ybVBhZ2UudHN4In0=