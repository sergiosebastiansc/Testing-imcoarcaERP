import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaShippingFast, FaSpinner, FaWhatsapp, FaEnvelope } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue, formatSalesInvoiceNumber, formatDocumentVoucherRemito } from "/src/utils/formatters.ts";
import { isClientLeyExportacionTdfExempt } from "/src/utils/clientTaxExemption.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) return 0;
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const FacturasVentaDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: invoice, loading, error } = useCrudItem(salesInvoicesModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const invoiceDisplayNumber = useMemo(() => {
    if (!invoice) return "";
    return formatSalesInvoiceNumber(invoice.series, invoice.afip_pos, invoice.invoice_number);
  }, [invoice]);
  const isClientTaxExempt = useMemo(
    () => isClientLeyExportacionTdfExempt(invoice?.client),
    [invoice?.client]
  );
  const calculatedTotals = useMemo(() => {
    if (!invoice) return { subtotal: 0, totalItemDiscounts: 0, globalDiscountAmount: 0, taxBase: 0, totalTaxes: 0 };
    const items = invoice.items || [];
    const subtotal = items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unit_price), 0);
    const totalItemDiscounts = items.reduce((sum, item) => sum + (Number(item.discount_amount) || 0), 0);
    const globalDiscountAmount = Number(invoice.discount_amount) || 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (invoice.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => sum + getItemTaxTotal(item), 0);
      } else {
        totalTaxes = (invoice.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes };
  }, [invoice, isClientTaxExempt]);
  const emailLink = useMemo(() => {
    const email = invoice?.client?.email;
    if (!email) return void 0;
    const total = invoice ? formatValue(invoice.total_amount, "currency") : "$0";
    const params = new URLSearchParams();
    params.append("subject", `Factura ${invoiceDisplayNumber} - ${invoice.client?.name}`);
    params.append("body", `Estimado cliente, adjuntamos el detalle de su factura ${invoiceDisplayNumber} por un total de ${total}.`);
    const queryString = params.toString().replace(/\+/g, "%20");
    return `mailto:${email}?${queryString}`;
  }, [invoice, invoiceDisplayNumber]);
  const whatsappLink = useMemo(() => {
    const phone = invoice?.client?.phone;
    if (!phone) return "#";
    const cleanPhone = phone.replace(/[^0-9]/g, "");
    const message = `Hola ${invoice.client?.name}, le enviamos los detalles de su factura ${invoiceDisplayNumber}. Total: ${formatValue(invoice.total_amount, "currency")}`;
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  }, [invoice, invoiceDisplayNumber]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
    lineNumber: 104,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la factura: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
    lineNumber: 105,
    columnNumber: 21
  }, this);
  if (!invoice) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró la factura." }, void 0, false, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
    lineNumber: 106,
    columnNumber: 24
  }, this);
  const getStatusText = (status) => {
    switch (status) {
      case "1":
        return "Pendiente";
      case "2":
        return "Cobrada";
      case "0":
        return "Anulada";
      case "CANCELED":
        return "Anulada (ARCA)";
      // ✅ Nuevo estado
      case "ISSUED":
        return "Enviada (ARCA)";
      // ✅ Nuevo estado
      default:
        return "Desconocido";
    }
  };
  const getStatusClassName = (status) => {
    switch (status) {
      case "1":
        return "bg-yellow-100 text-yellow-800";
      case "2":
        return "bg-green-100 text-green-800";
      case "0":
        return "bg-red-100 text-red-800";
      case "CANCELED":
        return "bg-red-100 text-red-800";
      case "ISSUED":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  const handleCreateRemito = () => {
    navigate(`/remitos/nuevo?invoiceId=${invoice.id}`);
  };
  const handlePrint = async () => {
    if (!invoice) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/sales-invoices/${invoice.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  const handleLinkClick = (e, type) => {
    const data = type === "email" ? invoice?.client?.email : invoice?.client?.phone;
    if (!data) {
      e.preventDefault();
      toast.warn(`El cliente no tiene ${type === "email" ? "email" : "teléfono"} registrado.`);
    }
  };
  const isCancelled = invoice.status === "0" || invoice.status === "CANCELED";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(salesInvoicesModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 179,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 178,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "Factura: ",
            invoiceDisplayNumber
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 182,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClassName(invoice.status)}`, children: getStatusText(invoice.status) }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 186,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 181,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 177,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4 flex flex-wrap gap-2", children: [
        invoice.client && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: emailLink,
              onClick: (e) => handleLinkClick(e, "email"),
              className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 cursor-pointer",
              title: "Enviar por Email",
              children: /* @__PURE__ */ jsxDEV(FaEnvelope, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 204,
                columnNumber: 33
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 197,
              columnNumber: 29
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: whatsappLink,
              onClick: (e) => handleLinkClick(e, "whatsapp"),
              target: "_blank",
              rel: "noopener noreferrer",
              className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 cursor-pointer",
              title: "Enviar por WhatsApp",
              children: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 214,
                columnNumber: 33
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 206,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 196,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 226,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 228,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 219,
            columnNumber: 21
          },
          this
        ),
        !isCancelled && /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleCreateRemito, className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-orange-600 border border-transparent rounded-md shadow-sm hover:bg-orange-700", children: [
          /* @__PURE__ */ jsxDEV(FaShippingFast, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 234,
            columnNumber: 29
          }, this),
          "Crear Remito"
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 233,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 193,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
      lineNumber: 176,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      invoice.cae_number && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "CAE Autorizado" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 247,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-xl font-mono font-bold text-green-900 tracking-wider", children: invoice.cae_number }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 248,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 246,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "Vencimiento CAE" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 251,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-lg font-medium text-green-900", children: formatValue(invoice.cae_due_date, "date") }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 252,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 250,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 245,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 257,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/clientes/${invoice.client?.id}`,
            className: "text-indigo-600 hover:text-indigo-800 hover:underline",
            children: invoice.client?.name || invoice.client_name || "N/A"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 259,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 258,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 256,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Factura" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 268,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatValue(invoice.invoice_date, "date") }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 269,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 267,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Serie" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 272,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.series }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 273,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 271,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Remito" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 276,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatDocumentVoucherRemito(invoice.document_voucher) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 277,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 275,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Pedido Origen" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 280,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.sales_order?.order_number || invoice.sales_order_number || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 281,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 279,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 284,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.salesperson?.name || invoice.salesperson_name || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 285,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 283,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Comprador" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 288,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.buyer?.name || invoice.buyer_name || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 289,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 287,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 292,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.currency?.name || invoice.currency_name || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 293,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 291,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de Cambio" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 296,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.exchange_rate ? Number(invoice.exchange_rate).toFixed(2) : "1.00" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 297,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 295,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Mostrar valor en dolares" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 300,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 flex items-center gap-2 text-base text-gray-900", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: !!invoice.show_currency_equivalence,
              disabled: true,
              "aria-label": `Mostrar valor en dolares: ${invoice.show_currency_equivalence ? "Sí" : "No"}`,
              autoComplete: "off",
              className: "h-4 w-4 shrink-0 rounded border-gray-300 text-indigo-600 cursor-default opacity-70"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 302,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: invoice.show_currency_equivalence ? "Sí" : "No" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 309,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 301,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 299,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Entrega" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 313,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.delivery_date ? formatValue(invoice.delivery_date, "date") : "N/A" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 314,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 312,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Transporte" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 317,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.transport?.name || invoice.transport_name || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 318,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 316,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Nº O. Compra Cliente" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 321,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.purchase_order_number || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 322,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 320,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Dirección de Entrega" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 325,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: invoice.delivery_address || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 326,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 324,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
      lineNumber: 243,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Items de la Factura" }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 333,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 338,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 339,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 340,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900 hidden", children: "Desc. (Monto)" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 341,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 342,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && invoice.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 343,
            columnNumber: 88
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 344,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 337,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 336,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: invoice.items.map((item, index) => {
          const subtotal = Number(item.quantity) * Number(item.unit_price);
          const discount = Number(item.discount_amount) || 0;
          const lineSubtotal = subtotal - discount;
          const itemTax = !isClientTaxExempt && invoice.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSubtotal + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: item.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${item.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 359,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 360,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 358,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 364,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
                lineNumber: 365,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 363,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 356,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 369,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 370,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500 hidden", children: formatValue(discount, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 371,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 372,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && invoice.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(itemTax, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 373,
              columnNumber: 96
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 374,
              columnNumber: 41
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 355,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 347,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 335,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 334,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
      lineNumber: 332,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-4", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 387,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900 whitespace-pre-wrap", children: invoice.notes || "-" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 388,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 386,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 385,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !invoice.has_item_level_taxes && invoice.taxes && invoice.taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 396,
          columnNumber: 29
        }, this),
        invoice.taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle.replace("text-gray-600", "text-gray-700"), children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%)"
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 399,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 400,
              columnNumber: 37
            }, this)
          ] }, tax.tax_id || index, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 398,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 395,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 393,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 409,
            columnNumber: 72
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 409,
            columnNumber: 130
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 409,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center hidden", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Items):" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 410,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.totalItemDiscounts, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 410,
            columnNumber: 134
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 410,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center hidden", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. (Global):" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 411,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.globalDiscountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 411,
            columnNumber: 135
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 411,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 414,
              columnNumber: 99
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-base")} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 414,
              columnNumber: 174
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 414,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: invoice.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 415,
              columnNumber: 80
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
              lineNumber: 415,
              columnNumber: 198
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 415,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 413,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 418,
            columnNumber: 91
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-lg")} font-bold text-indigo-600`, children: formatValue(invoice.total_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
            lineNumber: 418,
            columnNumber: 171
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
          lineNumber: 418,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
        lineNumber: 408,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
      lineNumber: 384,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx",
    lineNumber: 173,
    columnNumber: 5
  }, this);
};
_s(FacturasVentaDetailPage, "Q6nm4YlrPb1U2sp1K2pxqGTrqyE=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = FacturasVentaDetailPage;
var _c;
$RefreshReg$(_c, "FacturasVentaDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/facturas_venta/pages/FacturasVentaDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0Z3QixTQTRGQSxVQTVGQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuRnhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxpQ0FBMkU7QUFDcEYsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLGVBQWU7QUFDckMsU0FBU0MsZ0JBQWdCQyxXQUFXQyxZQUFZQyxrQkFBa0I7QUFDbEUsU0FBU0MsYUFBYUMsMEJBQTBCQyxtQ0FBbUM7QUFDbkYsU0FBU0MsdUNBQXVDO0FBQ2hELFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBQ2xELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBR2xDLE1BQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBMkI7QUFDaEQsTUFBSSxDQUFDQSxLQUFLQyxTQUFTRCxLQUFLQyxNQUFNQyxXQUFXLEVBQUcsUUFBTztBQUNuRCxTQUFPRixLQUFLQyxNQUFNRSxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU1FLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQ3RFO0FBRU8sYUFBTUMsMEJBQTBCQSxNQUFNO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFQyxHQUFHLElBQUlqQyxVQUEwQjtBQUN6QyxRQUFNa0MsV0FBV2pDLFlBQVk7QUFDN0IsUUFBTSxFQUFFc0IsTUFBTVksU0FBU0MsU0FBU0MsTUFBTSxJQUFJaEMsWUFBMEJDLDJCQUEyQjJCLEVBQUU7QUFDakcsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUluQyxTQUFTLEtBQUs7QUFHbEQsUUFBTW9DLHVCQUF1QnJDLFFBQVEsTUFBTTtBQUN2QyxRQUFJLENBQUNnQyxRQUFTLFFBQU87QUFDckIsV0FBT3BCLHlCQUF5Qm9CLFFBQVFNLFFBQVFOLFFBQVFPLFVBQVVQLFFBQVFRLGNBQWM7QUFBQSxFQUM1RixHQUFHLENBQUNSLE9BQU8sQ0FBQztBQUVaLFFBQU1TLG9CQUFvQnpDO0FBQUFBLElBQ3RCLE1BQU1jLGdDQUFnQ2tCLFNBQVNVLE1BQU07QUFBQSxJQUNyRCxDQUFDVixTQUFTVSxNQUFNO0FBQUEsRUFDcEI7QUFFQSxRQUFNQyxtQkFBbUIzQyxRQUFRLE1BQU07QUFDbkMsUUFBSSxDQUFDZ0MsUUFBUyxRQUFPLEVBQUVZLFVBQVUsR0FBR0Msb0JBQW9CLEdBQUdDLHNCQUFzQixHQUFHQyxTQUFTLEdBQUdDLFlBQVksRUFBRTtBQUM5RyxVQUFNQyxRQUFRakIsUUFBUWlCLFNBQVM7QUFDL0IsVUFBTUwsV0FBV0ssTUFBTTFCLE9BQU8sQ0FBQ0MsS0FBS0osU0FBU0ksTUFBT0UsT0FBT04sS0FBSzhCLFFBQVEsSUFBSXhCLE9BQU9OLEtBQUsrQixVQUFVLEdBQUksQ0FBQztBQUN2RyxVQUFNTixxQkFBcUJJLE1BQU0xQixPQUFPLENBQUNDLEtBQUtKLFNBQVNJLE9BQU9FLE9BQU9OLEtBQUtnQyxlQUFlLEtBQUssSUFBSSxDQUFDO0FBQ25HLFVBQU1OLHVCQUF1QnBCLE9BQU9NLFFBQVFvQixlQUFlLEtBQUs7QUFDaEUsVUFBTUwsVUFBVUgsV0FBV0MscUJBQXFCQztBQUNoRCxRQUFJRSxhQUFhO0FBQ2pCLFFBQUksQ0FBQ1AsbUJBQW1CO0FBQ3BCLFVBQUlULFFBQVFxQixzQkFBc0I7QUFDOUJMLHFCQUFhQyxNQUFNMUIsT0FBTyxDQUFDQyxLQUFLSixTQUFTSSxNQUFNTCxnQkFBZ0JDLElBQUksR0FBRyxDQUFDO0FBQUEsTUFDM0UsT0FBTztBQUNINEIsc0JBQWNoQixRQUFRWCxTQUFTLElBQUlFLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFBQSxNQUN2RjtBQUFBLElBQ0o7QUFDQSxXQUFPLEVBQUVpQixVQUFVQyxvQkFBb0JDLHNCQUFzQkMsU0FBU0MsV0FBVztBQUFBLEVBQ3JGLEdBQUcsQ0FBQ2hCLFNBQVNTLGlCQUFpQixDQUFDO0FBRS9CLFFBQU1hLFlBQVl0RCxRQUFRLE1BQU07QUFDNUIsVUFBTXVELFFBQVF2QixTQUFTVSxRQUFRYTtBQUMvQixRQUFJLENBQUNBLE1BQU8sUUFBT0M7QUFFbkIsVUFBTUMsUUFBUXpCLFVBQVVyQixZQUFZcUIsUUFBUTBCLGNBQWMsVUFBVSxJQUFJO0FBR3hFLFVBQU1DLFNBQVMsSUFBSUMsZ0JBQWdCO0FBQ25DRCxXQUFPRSxPQUFPLFdBQVcsV0FBV3hCLG9CQUFvQixNQUFNTCxRQUFRVSxRQUFRb0IsSUFBSSxFQUFFO0FBQ3BGSCxXQUFPRSxPQUFPLFFBQVEseURBQXlEeEIsb0JBQW9CLG9CQUFvQm9CLEtBQUssR0FBRztBQUkvSCxVQUFNTSxjQUFjSixPQUFPSyxTQUFTLEVBQUVDLFFBQVEsT0FBTyxLQUFLO0FBRTFELFdBQU8sVUFBVVYsS0FBSyxJQUFJUSxXQUFXO0FBQUEsRUFDekMsR0FBRyxDQUFDL0IsU0FBU0ssb0JBQW9CLENBQUM7QUFFbEMsUUFBTTZCLGVBQWVsRSxRQUFRLE1BQU07QUFDL0IsVUFBTW1FLFFBQVFuQyxTQUFTVSxRQUFReUI7QUFDL0IsUUFBSSxDQUFDQSxNQUFPLFFBQU87QUFFbkIsVUFBTUMsYUFBYUQsTUFBTUYsUUFBUSxXQUFXLEVBQUU7QUFDOUMsVUFBTUksVUFBVSxRQUFRckMsUUFBUVUsUUFBUW9CLElBQUksNENBQTRDekIsb0JBQW9CLFlBQVkxQixZQUFZcUIsUUFBUTBCLGNBQWMsVUFBVSxDQUFDO0FBRXJLLFdBQU8saUJBQWlCVSxVQUFVLFNBQVNFLG1CQUFtQkQsT0FBTyxDQUFDO0FBQUEsRUFDMUUsR0FBRyxDQUFDckMsU0FBU0ssb0JBQW9CLENBQUM7QUFFbEMsTUFBSUosUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUE2QkE7QUFBQUEsT0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyRTtBQUM3RixNQUFJLENBQUNGLFFBQVMsUUFBTyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLDBDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFFO0FBRzFGLFFBQU11QyxnQkFBZ0JBLENBQUNDLFdBQW1CO0FBQ3RDLFlBQVFBLFFBQU07QUFBQSxNQUNWLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBWSxlQUFPO0FBQUE7QUFBQSxNQUN4QixLQUFLO0FBQVUsZUFBTztBQUFBO0FBQUEsTUFDdEI7QUFBUyxlQUFPO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQ0EsUUFBTUMscUJBQXFCQSxDQUFDRCxXQUFtQjtBQUMzQyxZQUFRQSxRQUFNO0FBQUEsTUFDVixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQVksZUFBTztBQUFBLE1BQ3hCLEtBQUs7QUFBVSxlQUFPO0FBQUEsTUFDdEI7QUFBUyxlQUFPO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBSUEsUUFBTUUsa0JBQWtCO0FBQ3hCLFFBQU1DLGtCQUFrQjtBQUV4QixRQUFNQyxxQkFBcUJBLE1BQU07QUFDN0I3QyxhQUFTLDRCQUE0QkMsUUFBUUYsRUFBRSxFQUFFO0FBQUEsRUFDckQ7QUFFQSxRQUFNK0MsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQzdDLFFBQVM7QUFFZCxVQUFNOEMsVUFBVS9ELGdCQUFnQjtBQUNoQyxRQUFJLENBQUMrRCxTQUFTO0FBQ1Y3RCxZQUFNaUIsTUFBTSw4Q0FBOEM7QUFDMUQ7QUFBQSxJQUNKO0FBRUFFLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNBLFlBQU1wQixpQkFBaUI4RCxTQUFTLG1CQUFtQjlDLFFBQVFGLEVBQUUsTUFBTTtBQUFBLElBQ3ZFLFNBQVNJLFFBQU87QUFDWixVQUFJLENBQUM0QyxRQUFRQyxPQUFPQyxPQUFRRixTQUFRQyxPQUFPRSxNQUFNO0FBQ2pEQyxjQUFRaEQsTUFBTSw0QkFBNEJBLE1BQUs7QUFDL0NqQixZQUFNaUIsTUFBTSx3Q0FBd0M7QUFBQSxJQUN4RCxVQUFDO0FBQ0dFLG9CQUFjLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFLQSxRQUFNK0Msa0JBQWtCQSxDQUFDQyxHQUFxQkMsU0FBK0I7QUFDekUsVUFBTUMsT0FBT0QsU0FBUyxVQUFVckQsU0FBU1UsUUFBUWEsUUFBUXZCLFNBQVNVLFFBQVF5QjtBQUMxRSxRQUFJLENBQUNtQixNQUFNO0FBQ1BGLFFBQUVHLGVBQWU7QUFDakJ0RSxZQUFNdUUsS0FBSyx1QkFBdUJILFNBQVMsVUFBVSxVQUFVLFVBQVUsY0FBYztBQUFBLElBQzNGO0FBQUEsRUFDSjtBQUVBLFFBQU1JLGNBQWN6RCxRQUFRd0MsV0FBVyxPQUFPeEMsUUFBUXdDLFdBQVc7QUFDakUsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBR1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUVBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTXpDLFNBQVNiLGtCQUFrQmYsMEJBQTBCdUYsU0FBUyxDQUFDLEdBQUcsV0FBVSxvREFDL0YsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlEQUErQztBQUFBO0FBQUEsWUFDL0NyRDtBQUFBQSxlQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFVBQUssV0FBVyx1REFBdURvQyxtQkFBbUJ6QyxRQUFRd0MsTUFBTSxDQUFDLElBQ3JHRCx3QkFBY3ZDLFFBQVF3QyxNQUFNLEtBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNkNBRVZ4QztBQUFBQSxnQkFBUVUsVUFDTCxtQ0FDSTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNWTtBQUFBQSxjQUNOLFNBQVMsQ0FBQzhCLE1BQU1ELGdCQUFnQkMsR0FBRyxPQUFPO0FBQUEsY0FDMUMsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBR04saUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBO0FBQUEsWUFQakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNbEI7QUFBQUEsY0FDTixTQUFTLENBQUNrQixNQUFNRCxnQkFBZ0JDLEdBQUcsVUFBVTtBQUFBLGNBQzdDLFFBQU87QUFBQSxjQUNQLEtBQUk7QUFBQSxjQUNKLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQTtBQUFBLFlBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBR0o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNQO0FBQUFBLFlBQ1QsVUFBVTFDO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLHVCQUNHLHVCQUFDLGFBQVUsV0FBVSwwQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsSUFFM0MsdUJBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUE7QUFBQSxVQVRwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBRUMsQ0FBQ3NELGVBQ0UsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU2Isb0JBQW9CLFdBQVUsc0pBQ3pEO0FBQUEsaUNBQUMsa0JBQWUsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQTtBQUFBLGFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBM0NSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxTQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0VBO0FBQUEsSUFHQSx1QkFBQyxRQUFHLFdBQVUsa0VBQ1Q1QztBQUFBQSxjQUFRMkQsY0FDTCxtQ0FDSTtBQUFBLCtCQUFDLFNBQUksV0FBVSxvRUFDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSw0REFBMkQsOEJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsUUFBRyxXQUFVLGtFQUFrRTNELGtCQUFRMkQsY0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxvRUFDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSw0REFBMkQsK0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsUUFBRyxXQUFVLDJDQUEyQ2hGLHNCQUFZcUIsUUFBUTRELGNBQWMsTUFBTSxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBRnZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFSix1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdsQixpQkFBaUIsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUN2Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLElBQUksYUFBYTFDLFFBQVFVLFFBQVFaLEVBQUU7QUFBQSxZQUNuQyxXQUFVO0FBQUEsWUFFVEUsa0JBQVFVLFFBQVFvQixRQUFROUIsUUFBUTZELGVBQWU7QUFBQTtBQUFBLFVBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV25CLGlCQUFpQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQzdDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0MvRCxzQkFBWXFCLFFBQVE4RCxjQUFjLE1BQU0sS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFdBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXcEIsaUJBQWlCLHFCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQzFDLGtCQUFRTSxVQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsV0FGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdvQyxpQkFBaUIsc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDN0Qsc0NBQTRCbUIsUUFBUStELGdCQUFnQixLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsV0FGeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdyQixpQkFBaUIsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDMUMsa0JBQVFnRSxhQUFhQyxnQkFBZ0JqRSxRQUFRa0Usc0JBQXNCLE9BQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUg7QUFBQSxXQUZ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV3hCLGlCQUFpQix3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFFBQ3hDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0MxQyxrQkFBUW1FLGFBQWFyQyxRQUFROUIsUUFBUW9FLG9CQUFvQixPQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJHO0FBQUEsV0FGL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVcxQixpQkFBaUIseUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDMUMsa0JBQVFxRSxPQUFPdkMsUUFBUTlCLFFBQVFzRSxjQUFjLE9BQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Y7QUFBQSxXQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVzVCLGlCQUFpQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0MxQyxrQkFBUXVFLFVBQVV6QyxRQUFROUIsUUFBUXdFLGlCQUFpQixPQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsV0FGekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVc5QixpQkFBaUIsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDMUMsa0JBQVF5RSxnQkFBZ0IvRSxPQUFPTSxRQUFReUUsYUFBYSxFQUFFQyxRQUFRLENBQUMsSUFBSSxVQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdIO0FBQUEsV0FGNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdoQyxpQkFBaUIsd0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQSxRQUN4RCx1QkFBQyxRQUFHLFdBQVUsd0RBQ1Y7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsU0FBUyxDQUFDLENBQUMxQyxRQUFRMkU7QUFBQUEsY0FDbkI7QUFBQSxjQUNBLGNBQVksNkJBQTZCM0UsUUFBUTJFLDRCQUE0QixPQUFPLElBQUk7QUFBQSxjQUN4RixjQUFhO0FBQUEsY0FBTSxXQUFVO0FBQUE7QUFBQSxZQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLcUg7QUFBQSxVQUVySCx1QkFBQyxVQUFNM0Usa0JBQVEyRSw0QkFBNEIsT0FBTyxRQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBUjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdqQyxpQkFBaUIsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDMUMsa0JBQVE0RSxnQkFBZ0JqRyxZQUFZcUIsUUFBUTRFLGVBQWUsTUFBTSxJQUFJLFNBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUg7QUFBQSxXQUY3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2xDLGlCQUFpQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0MxQyxrQkFBUTZFLFdBQVcvQyxRQUFROUIsUUFBUThFLGtCQUFrQixPQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsV0FGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdwQyxpQkFBaUIsb0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxRQUNwRCx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDMUMsa0JBQVErRSx5QkFBeUIsT0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFdBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXckMsaUJBQWlCLG9DQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFDcEQsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQzFDLGtCQUFRZ0Ysb0JBQW9CLE9BQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxXQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXBGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUZBO0FBQUEsSUFJQSx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtDQUE4QyxtQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLE1BQy9FLHVCQUFDLFNBQUksV0FBVSwyRUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsUUFBRyxXQUFVLHFFQUFvRSw2QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ2xGLENBQUN2RSxxQkFBcUJULFFBQVFxQix3QkFBd0IsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx5QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUMzSSx1QkFBQyxRQUFHLFdBQVUsMkVBQTBFLDJCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBUHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNackIsa0JBQVFpQixNQUFNZ0UsSUFBSSxDQUFDN0YsTUFBTThGLFVBQVU7QUFDaEMsZ0JBQU10RSxXQUFXbEIsT0FBT04sS0FBSzhCLFFBQVEsSUFBSXhCLE9BQU9OLEtBQUsrQixVQUFVO0FBQy9ELGdCQUFNZ0UsV0FBV3pGLE9BQU9OLEtBQUtnQyxlQUFlLEtBQUs7QUFDakQsZ0JBQU1nRSxlQUFleEUsV0FBV3VFO0FBQ2hDLGdCQUFNRSxVQUFVLENBQUM1RSxxQkFBcUJULFFBQVFxQix1QkFBdUJsQyxnQkFBZ0JDLElBQUksSUFBSTtBQUM3RixnQkFBTWtHLFlBQVlGLGVBQWVDO0FBQ2pDLGlCQUNJLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsa0NBQ1RqRyxlQUFLbUcsYUFDRix1QkFBQyxRQUFLLElBQUksY0FBY25HLEtBQUttRyxVQUFVLElBQUksV0FBVSx5REFDakQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQTZCbkcsZUFBS29HLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGdCQUFFcEcsS0FBS3FHO0FBQUFBLGdCQUFhO0FBQUEsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsaUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FDSTtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFBNkJyRyxlQUFLb0csZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FDOUQsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsZ0JBQUVwRyxLQUFLcUc7QUFBQUEsZ0JBQWE7QUFBQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEMvRixpQkFBT04sS0FBSzhCLFFBQVEsRUFBRXdELFFBQVEsQ0FBQyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzdGLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEMvRixzQkFBWVMsS0FBSytCLFlBQVksVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFFBQUcsV0FBVSxxREFBcUR4QyxzQkFBWXdHLFVBQVUsVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFFBQUcsV0FBVSw4Q0FBOEN4RyxzQkFBWXlHLGNBQWMsVUFBVSxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2pHLENBQUMzRSxxQkFBcUJULFFBQVFxQix3QkFBd0IsdUJBQUMsUUFBRyxXQUFVLDhDQUE4QzFDLHNCQUFZMEcsU0FBUyxVQUFVLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDcEosdUJBQUMsUUFBRyxXQUFVLHVFQUF1RTFHLHNCQUFZMkcsV0FBVyxVQUFVLEtBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdIO0FBQUEsZUFuQm5IbEcsS0FBS1UsTUFBTW9GLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsUUFFUixDQUFDLEtBOUJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBLEtBN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxTQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1gsaUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXeEMsaUJBQWlCLHFCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRDFDLGtCQUFRMEYsU0FBUyxPQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1YsV0FBQ2pGLHFCQUFxQixDQUFDVCxRQUFRcUIsd0JBQXdCckIsUUFBUVgsU0FBU1csUUFBUVgsTUFBTUMsU0FBUyxLQUM1Rix1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNENBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM3RVUsUUFBUVgsTUFBTTRGO0FBQUFBLFVBQUksQ0FBQ3hGLEtBQUt5RixVQUNyQix1QkFBQyxTQUE4QixXQUFVLHFDQUNyQztBQUFBLG1DQUFDLFVBQUssV0FBV3hDLGdCQUFnQlQsUUFBUSxpQkFBaUIsZUFBZSxHQUFJeEM7QUFBQUEsa0JBQUlrRztBQUFBQSxjQUFTO0FBQUEsY0FBR2xHLElBQUltRztBQUFBQSxjQUFLO0FBQUEsaUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsVUFBSyxXQUFXakQsaUJBQWtCaEUsc0JBQVljLElBQUlFLFFBQVEsVUFBVSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmpFRixJQUFJb0csVUFBVVgsT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0g7QUFBQSxXQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLGlDQUFDLFVBQUssV0FBV3hDLGlCQUFpQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBV0MsaUJBQWtCaEUsc0JBQVlnQyxpQkFBaUJDLFVBQVUsVUFBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLGFBQW5NO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBME07QUFBQSxRQUMxTSx1QkFBQyxTQUFJLFdBQVUsNENBQTJDO0FBQUEsaUNBQUMsVUFBSyxXQUFXOEIsaUJBQWlCLDhCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQU8sdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUdoRSxZQUFZZ0MsaUJBQWlCRSxvQkFBb0IsVUFBVTtBQUFBLGVBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsYUFBbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwTjtBQUFBLFFBQzFOLHVCQUFDLFNBQUksV0FBVSw0Q0FBMkM7QUFBQSxpQ0FBQyxVQUFLLFdBQVc2QixpQkFBaUIsK0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFBTyx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsWUFBR2hFLFlBQVlnQyxpQkFBaUJHLHNCQUFzQixVQUFVO0FBQUEsZUFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxhQUF0TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZOO0FBQUEsUUFDNU4sQ0FBQ0wscUJBQ0UsbUNBQ0k7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0RBQXVEO0FBQUEsbUNBQUMsVUFBSyxXQUFXLEdBQUdpQyxlQUFlLGtCQUFrQiwrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBVyxHQUFHQyxnQkFBZ0JWLFFBQVEsV0FBVyxXQUFXLENBQUMsa0JBQW1CdEQsc0JBQVlnQyxpQkFBaUJJLFNBQVMsVUFBVSxLQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3STtBQUFBLGVBQXpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdTO0FBQUEsVUFDaFMsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLG1DQUFDLFVBQUssV0FBVzJCLGlCQUFrQjFDLGtCQUFRcUIsdUJBQXVCLHVCQUF1Qix5QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0c7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBV3NCLGlCQUFpQjtBQUFBO0FBQUEsY0FBR2hFLFlBQVlnQyxpQkFBaUJLLFlBQVksVUFBVTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBQW5RO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBRO0FBQUEsYUFGOVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFSix1QkFBQyxTQUFJLFdBQVUsd0RBQXVEO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUcwQixlQUFlLDBCQUEwQiw0QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBVyxHQUFHQyxnQkFBZ0JWLFFBQVEsV0FBVyxTQUFTLENBQUMsOEJBQStCdEQsc0JBQVlxQixRQUFRMEIsY0FBYyxVQUFVLEtBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThJO0FBQUEsYUFBcFM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyUztBQUFBLFdBVi9TO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQXZQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1BBO0FBRVI7QUFBRTdCLEdBOVhXRCx5QkFBdUI7QUFBQSxVQUNqQi9CLFdBQ0VDLGFBQ3lCSSxXQUFXO0FBQUE7QUFBQTRILEtBSDVDbEc7QUFBdUIsSUFBQWtHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VDcnVkSXRlbSIsInNhbGVzSW52b2ljZXNNb2R1bGVDb25maWciLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QcmludCIsIkZhU2hpcHBpbmdGYXN0IiwiRmFTcGlubmVyIiwiRmFXaGF0c2FwcCIsIkZhRW52ZWxvcGUiLCJmb3JtYXRWYWx1ZSIsImZvcm1hdFNhbGVzSW52b2ljZU51bWJlciIsImZvcm1hdERvY3VtZW50Vm91Y2hlclJlbWl0byIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJiZWdpblBkZlByZXZpZXciLCJmaW5pc2hQZGZQcmV2aWV3IiwidG9hc3QiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImdldEl0ZW1UYXhUb3RhbCIsIml0ZW0iLCJ0YXhlcyIsImxlbmd0aCIsInJlZHVjZSIsInN1bSIsInRheCIsIk51bWJlciIsImFtb3VudCIsIkZhY3R1cmFzVmVudGFEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwiaW52b2ljZSIsImxvYWRpbmciLCJlcnJvciIsImlzUHJpbnRpbmciLCJzZXRJc1ByaW50aW5nIiwiaW52b2ljZURpc3BsYXlOdW1iZXIiLCJzZXJpZXMiLCJhZmlwX3BvcyIsImludm9pY2VfbnVtYmVyIiwiaXNDbGllbnRUYXhFeGVtcHQiLCJjbGllbnQiLCJjYWxjdWxhdGVkVG90YWxzIiwic3VidG90YWwiLCJ0b3RhbEl0ZW1EaXNjb3VudHMiLCJnbG9iYWxEaXNjb3VudEFtb3VudCIsInRheEJhc2UiLCJ0b3RhbFRheGVzIiwiaXRlbXMiLCJxdWFudGl0eSIsInVuaXRfcHJpY2UiLCJkaXNjb3VudF9hbW91bnQiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsImVtYWlsTGluayIsImVtYWlsIiwidW5kZWZpbmVkIiwidG90YWwiLCJ0b3RhbF9hbW91bnQiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJuYW1lIiwicXVlcnlTdHJpbmciLCJ0b1N0cmluZyIsInJlcGxhY2UiLCJ3aGF0c2FwcExpbmsiLCJwaG9uZSIsImNsZWFuUGhvbmUiLCJtZXNzYWdlIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZ2V0U3RhdHVzVGV4dCIsInN0YXR1cyIsImdldFN0YXR1c0NsYXNzTmFtZSIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsImhhbmRsZUNyZWF0ZVJlbWl0byIsImhhbmRsZVByaW50Iiwic2Vzc2lvbiIsIndpbmRvdyIsImNsb3NlZCIsImNsb3NlIiwiY29uc29sZSIsImhhbmRsZUxpbmtDbGljayIsImUiLCJ0eXBlIiwiZGF0YSIsInByZXZlbnREZWZhdWx0Iiwid2FybiIsImlzQ2FuY2VsbGVkIiwiYmFzZVJvdXRlIiwiY2FlX251bWJlciIsImNhZV9kdWVfZGF0ZSIsImNsaWVudF9uYW1lIiwiaW52b2ljZV9kYXRlIiwiZG9jdW1lbnRfdm91Y2hlciIsInNhbGVzX29yZGVyIiwib3JkZXJfbnVtYmVyIiwic2FsZXNfb3JkZXJfbnVtYmVyIiwic2FsZXNwZXJzb24iLCJzYWxlc3BlcnNvbl9uYW1lIiwiYnV5ZXIiLCJidXllcl9uYW1lIiwiY3VycmVuY3kiLCJjdXJyZW5jeV9uYW1lIiwiZXhjaGFuZ2VfcmF0ZSIsInRvRml4ZWQiLCJzaG93X2N1cnJlbmN5X2VxdWl2YWxlbmNlIiwiZGVsaXZlcnlfZGF0ZSIsInRyYW5zcG9ydCIsInRyYW5zcG9ydF9uYW1lIiwicHVyY2hhc2Vfb3JkZXJfbnVtYmVyIiwiZGVsaXZlcnlfYWRkcmVzcyIsIm1hcCIsImluZGV4IiwiZGlzY291bnQiLCJsaW5lU3VidG90YWwiLCJpdGVtVGF4IiwibGluZVRvdGFsIiwicHJvZHVjdF9pZCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3RfY29kZSIsIm5vdGVzIiwidGF4X25hbWUiLCJyYXRlIiwidGF4X2lkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmFjdHVyYXNWZW50YURldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9tb2R1bGVzL2ZhY3R1cmFzX3ZlbnRhL0ZhY3R1cmFzVmVudGFEZXRhaWxQYWdlLnRzeFxuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbi8vIFVzYW1vcyBjb25maWcgeSB0aXBvIGRlIEZhY3R1cmEsIHkgZWwgdGlwbyBkZSBJdGVtIGRlIEZhY3R1cmFcbmltcG9ydCB7IHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcsIHR5cGUgU2FsZXNJbnZvaWNlLCB0eXBlIFNhbGVzSW52b2ljZUl0ZW0gfSBmcm9tICcuLi9mYWN0dXJhc192ZW50YS5jb25maWcnXG5pbXBvcnQgeyBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvTG9hZGluZ1NwaW5uZXInO1xuaW1wb3J0IHsgSW9BcnJvd0JhY2ssIElvUHJpbnQgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgRmFTaGlwcGluZ0Zhc3QsIEZhU3Bpbm5lciwgRmFXaGF0c2FwcCwgRmFFbnZlbG9wZSB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlLCBmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIsIGZvcm1hdERvY3VtZW50Vm91Y2hlclJlbWl0byB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuaW1wb3J0IHsgaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2NsaWVudFRheEV4ZW1wdGlvbic7XG5pbXBvcnQgeyBiZWdpblBkZlByZXZpZXcsIGZpbmlzaFBkZlByZXZpZXcgfSBmcm9tICcuLi8uLi8uLi91dGlscy9ibG9iSGVscGVyJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbi8vIEhlbHBlciBwYXJhIGNhbGN1bGFyIGltcHVlc3RvcyBkZSB1biDDrXRlbVxuY29uc3QgZ2V0SXRlbVRheFRvdGFsID0gKGl0ZW06IFNhbGVzSW52b2ljZUl0ZW0pID0+IHtcbiAgICBpZiAoIWl0ZW0udGF4ZXMgfHwgaXRlbS50YXhlcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICAgIHJldHVybiBpdGVtLnRheGVzLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG59O1xuXG5leHBvcnQgY29uc3QgRmFjdHVyYXNWZW50YURldGFpbFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgICBjb25zdCB7IGl0ZW06IGludm9pY2UsIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxTYWxlc0ludm9pY2U+KHNhbGVzSW52b2ljZXNNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCBbaXNQcmludGluZywgc2V0SXNQcmludGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBMw7NnaWNhIGRlIGPDoWxjdWxvIGNvbXBsZXRhLCBpZ3VhbCBhbCBmb3JtdWxhcmlvXG4gICAgY29uc3QgaW52b2ljZURpc3BsYXlOdW1iZXIgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKCFpbnZvaWNlKSByZXR1cm4gJyc7XG4gICAgICAgIHJldHVybiBmb3JtYXRTYWxlc0ludm9pY2VOdW1iZXIoaW52b2ljZS5zZXJpZXMsIGludm9pY2UuYWZpcF9wb3MsIGludm9pY2UuaW52b2ljZV9udW1iZXIpO1xuICAgIH0sIFtpbnZvaWNlXSk7XG5cbiAgICBjb25zdCBpc0NsaWVudFRheEV4ZW1wdCA9IHVzZU1lbW8oXG4gICAgICAgICgpID0+IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQoaW52b2ljZT8uY2xpZW50KSxcbiAgICAgICAgW2ludm9pY2U/LmNsaWVudF1cbiAgICApO1xuXG4gICAgY29uc3QgY2FsY3VsYXRlZFRvdGFscyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIWludm9pY2UpIHJldHVybiB7IHN1YnRvdGFsOiAwLCB0b3RhbEl0ZW1EaXNjb3VudHM6IDAsIGdsb2JhbERpc2NvdW50QW1vdW50OiAwLCB0YXhCYXNlOiAwLCB0b3RhbFRheGVzOiAwIH07XG4gICAgICAgIGNvbnN0IGl0ZW1zID0gaW52b2ljZS5pdGVtcyB8fCBbXTtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgKE51bWJlcihpdGVtLnF1YW50aXR5KSAqIE51bWJlcihpdGVtLnVuaXRfcHJpY2UpKSwgMCk7XG4gICAgICAgIGNvbnN0IHRvdGFsSXRlbURpc2NvdW50cyA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyAoTnVtYmVyKGl0ZW0uZGlzY291bnRfYW1vdW50KSB8fCAwKSwgMCk7XG4gICAgICAgIGNvbnN0IGdsb2JhbERpc2NvdW50QW1vdW50ID0gTnVtYmVyKGludm9pY2UuZGlzY291bnRfYW1vdW50KSB8fCAwO1xuICAgICAgICBjb25zdCB0YXhCYXNlID0gc3VidG90YWwgLSB0b3RhbEl0ZW1EaXNjb3VudHMgLSBnbG9iYWxEaXNjb3VudEFtb3VudDtcbiAgICAgICAgbGV0IHRvdGFsVGF4ZXMgPSAwO1xuICAgICAgICBpZiAoIWlzQ2xpZW50VGF4RXhlbXB0KSB7XG4gICAgICAgICAgICBpZiAoaW52b2ljZS5oYXNfaXRlbV9sZXZlbF90YXhlcykge1xuICAgICAgICAgICAgICAgIHRvdGFsVGF4ZXMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgZ2V0SXRlbVRheFRvdGFsKGl0ZW0pLCAwKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG90YWxUYXhlcyA9IChpbnZvaWNlLnRheGVzIHx8IFtdKS5yZWR1Y2UoKHN1bSwgdGF4KSA9PiBzdW0gKyBOdW1iZXIodGF4LmFtb3VudCksIDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IHN1YnRvdGFsLCB0b3RhbEl0ZW1EaXNjb3VudHMsIGdsb2JhbERpc2NvdW50QW1vdW50LCB0YXhCYXNlLCB0b3RhbFRheGVzIH07XG4gICAgfSwgW2ludm9pY2UsIGlzQ2xpZW50VGF4RXhlbXB0XSk7XG5cbiAgICBjb25zdCBlbWFpbExpbmsgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3QgZW1haWwgPSBpbnZvaWNlPy5jbGllbnQ/LmVtYWlsO1xuICAgICAgICBpZiAoIWVtYWlsKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgICAgIGNvbnN0IHRvdGFsID0gaW52b2ljZSA/IGZvcm1hdFZhbHVlKGludm9pY2UudG90YWxfYW1vdW50LCAnY3VycmVuY3knKSA6ICckMCc7XG5cbiAgICAgICAgLy8gVXNhbW9zIFVSTFNlYXJjaFBhcmFtcyBwYXJhIGNvZGlmaWNhciBjb3JyZWN0YW1lbnRlIHN1YmplY3QgeSBib2R5XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcbiAgICAgICAgcGFyYW1zLmFwcGVuZCgnc3ViamVjdCcsIGBGYWN0dXJhICR7aW52b2ljZURpc3BsYXlOdW1iZXJ9IC0gJHtpbnZvaWNlLmNsaWVudD8ubmFtZX1gKTtcbiAgICAgICAgcGFyYW1zLmFwcGVuZCgnYm9keScsIGBFc3RpbWFkbyBjbGllbnRlLCBhZGp1bnRhbW9zIGVsIGRldGFsbGUgZGUgc3UgZmFjdHVyYSAke2ludm9pY2VEaXNwbGF5TnVtYmVyfSBwb3IgdW4gdG90YWwgZGUgJHt0b3RhbH0uYCk7XG5cbiAgICAgICAgLy8gVHJ1Y28gUHJvOiBVUkxTZWFyY2hQYXJhbXMgdXNhICcrJyBwYXJhIGVzcGFjaW9zLCBwZXJvIGFsZ3Vub3MgY2xpZW50ZXMgZGUgY29ycmVvXG4gICAgICAgIC8vIGFudGlndW9zIHByZWZpZXJlbiAnJTIwJy4gSGFjZW1vcyBlbCByZWVtcGxhem8gcGFyYSBtw6F4aW1hIGNvbXBhdGliaWxpZGFkLlxuICAgICAgICBjb25zdCBxdWVyeVN0cmluZyA9IHBhcmFtcy50b1N0cmluZygpLnJlcGxhY2UoL1xcKy9nLCAnJTIwJyk7XG5cbiAgICAgICAgcmV0dXJuIGBtYWlsdG86JHtlbWFpbH0/JHtxdWVyeVN0cmluZ31gO1xuICAgIH0sIFtpbnZvaWNlLCBpbnZvaWNlRGlzcGxheU51bWJlcl0pO1xuXG4gICAgY29uc3Qgd2hhdHNhcHBMaW5rID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHBob25lID0gaW52b2ljZT8uY2xpZW50Py5waG9uZTtcbiAgICAgICAgaWYgKCFwaG9uZSkgcmV0dXJuICcjJzsgLy8gRmFsbGJhY2tcblxuICAgICAgICBjb25zdCBjbGVhblBob25lID0gcGhvbmUucmVwbGFjZSgvW14wLTldL2csICcnKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGBIb2xhICR7aW52b2ljZS5jbGllbnQ/Lm5hbWV9LCBsZSBlbnZpYW1vcyBsb3MgZGV0YWxsZXMgZGUgc3UgZmFjdHVyYSAke2ludm9pY2VEaXNwbGF5TnVtYmVyfS4gVG90YWw6ICR7Zm9ybWF0VmFsdWUoaW52b2ljZS50b3RhbF9hbW91bnQsICdjdXJyZW5jeScpfWA7XG5cbiAgICAgICAgcmV0dXJuIGBodHRwczovL3dhLm1lLyR7Y2xlYW5QaG9uZX0/dGV4dD0ke2VuY29kZVVSSUNvbXBvbmVudChtZXNzYWdlKX1gO1xuICAgIH0sIFtpbnZvaWNlLCBpbnZvaWNlRGlzcGxheU51bWJlcl0pO1xuXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBhbCBjYXJnYXIgbGEgZmFjdHVyYToge2Vycm9yIGFzIHN0cmluZ308L2Rpdj47XG4gICAgaWYgKCFpbnZvaWNlKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+Tm8gc2UgZW5jb250csOzIGxhIGZhY3R1cmEuPC9kaXY+O1xuXG4gICAgLy8gLS0tIEzDk0dJQ0EgREUgRVNUQURPIChJTVBMRU1FTlRBREEpIC0tLVxuICAgIGNvbnN0IGdldFN0YXR1c1RleHQgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgICAgICAgIGNhc2UgJzEnOiByZXR1cm4gJ1BlbmRpZW50ZSc7XG4gICAgICAgICAgICBjYXNlICcyJzogcmV0dXJuICdDb2JyYWRhJztcbiAgICAgICAgICAgIGNhc2UgJzAnOiByZXR1cm4gJ0FudWxhZGEnO1xuICAgICAgICAgICAgY2FzZSAnQ0FOQ0VMRUQnOiByZXR1cm4gJ0FudWxhZGEgKEFSQ0EpJzsgLy8g4pyFIE51ZXZvIGVzdGFkb1xuICAgICAgICAgICAgY2FzZSAnSVNTVUVEJzogcmV0dXJuICdFbnZpYWRhIChBUkNBKSc7IC8vIOKchSBOdWV2byBlc3RhZG9cbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiAnRGVzY29ub2NpZG8nO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBnZXRTdGF0dXNDbGFzc05hbWUgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgICAgICAgIGNhc2UgJzEnOiByZXR1cm4gJ2JnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwJztcbiAgICAgICAgICAgIGNhc2UgJzInOiByZXR1cm4gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCc7XG4gICAgICAgICAgICBjYXNlICcwJzogcmV0dXJuICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCc7XG4gICAgICAgICAgICBjYXNlICdDQU5DRUxFRCc6IHJldHVybiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnO1xuICAgICAgICAgICAgY2FzZSAnSVNTVUVEJzogcmV0dXJuICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnO1xuICAgICAgICAgICAgZGVmYXVsdDogcmV0dXJuICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJztcbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gLS0tIEZJTiBMw5NHSUNBIERFIEVTVEFETyAtLS1cblxuICAgIC8vIEVzdGlsb3MgcGFyYSBsb3MgdG90YWxlc1xuICAgIGNvbnN0IHRvdGFsTGFiZWxTdHlsZSA9IFwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI7XG4gICAgY29uc3QgdG90YWxWYWx1ZVN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0ZXh0LXJpZ2h0XCI7XG5cbiAgICBjb25zdCBoYW5kbGVDcmVhdGVSZW1pdG8gPSAoKSA9PiB7XG4gICAgICAgIG5hdmlnYXRlKGAvcmVtaXRvcy9udWV2bz9pbnZvaWNlSWQ9JHtpbnZvaWNlLmlkfWApO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFpbnZvaWNlKSByZXR1cm47XG5cbiAgICAgICAgY29uc3Qgc2Vzc2lvbiA9IGJlZ2luUGRmUHJldmlldygpO1xuICAgICAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdQZXJtaXTDrSB2ZW50YW5hcyBlbWVyZ2VudGVzIHBhcmEgdmVyIGVsIFBERi4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldElzUHJpbnRpbmcodHJ1ZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBmaW5pc2hQZGZQcmV2aWV3KHNlc3Npb24sIGAvc2FsZXMtaW52b2ljZXMvJHtpbnZvaWNlLmlkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGdlbmVyYXIgZWwgUERGOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBnZW5lcmFyIGVsIGNvbXByb2JhbnRlIFBERi4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzUHJpbnRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuXG5cbiAgICAvLyBGdW5jacOzbiBhdXhpbGlhciBwYXJhIG1hbmVqYXIgZWwgY2xpYyBzaSBubyBoYXkgZGF0b3MgKFVYKVxuICAgIGNvbnN0IGhhbmRsZUxpbmtDbGljayA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50LCB0eXBlOiAnZW1haWwnIHwgJ3doYXRzYXBwJykgPT4ge1xuICAgICAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gJ2VtYWlsJyA/IGludm9pY2U/LmNsaWVudD8uZW1haWwgOiBpbnZvaWNlPy5jbGllbnQ/LnBob25lO1xuICAgICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTsgLy8gRXZpdGEgbmF2ZWdhciBhICcjJ1xuICAgICAgICAgICAgdG9hc3Qud2FybihgRWwgY2xpZW50ZSBubyB0aWVuZSAke3R5cGUgPT09ICdlbWFpbCcgPyAnZW1haWwnIDogJ3RlbMOpZm9ubyd9IHJlZ2lzdHJhZG8uYCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaXNDYW5jZWxsZWQgPSBpbnZvaWNlLnN0YXR1cyA9PT0gJzAnIHx8IGludm9pY2Uuc3RhdHVzID09PSAnQ0FOQ0VMRUQnO1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LThcIj5cblxuICAgICAgICAgICAgey8qIC0tLSBFTkNBQkVaQURPIChDT01QTEVUTykgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IG1iLTQgYm9yZGVyLWIgc206ZmxleCBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1ncmF5LTUwMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRmFjdHVyYToge2ludm9pY2VEaXNwbGF5TnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gQkFER0UgREUgRVNUQURPIChJTVBMRU1FTlRBRE8pIC0tLSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG10LTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSAke2dldFN0YXR1c0NsYXNzTmFtZShpbnZvaWNlLnN0YXR1cyl9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c1RleHQoaW52b2ljZS5zdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBCT1RPTkVSQSBERSBBQ0NJT05FUyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc206bXQtMCBzbTptbC00IGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG5cbiAgICAgICAgICAgICAgICAgICAge2ludm9pY2UuY2xpZW50ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17ZW1haWxMaW5rfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlTGlua0NsaWNrKGUsICdlbWFpbCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVudmlhciBwb3IgRW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5vIHVzYW1vcyB0YXJnZXQ9XCJfYmxhbmtcIiBlbiBtYWlsdG8gcGFyYSBldml0YXIgcGVzdGHDsWFzIGVuIGJsYW5jbyB2YWPDrWFzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFFbnZlbG9wZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXt3aGF0c2FwcExpbmt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVMaW5rQ2xpY2soZSwgJ3doYXRzYXBwJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVudmlhciBwb3IgV2hhdHNBcHBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyZWVuLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1ByaW50aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQcmludGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUHJpbnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2FuY2VsbGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZVJlbWl0b30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctb3JhbmdlLTYwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLW9yYW5nZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTaGlwcGluZ0Zhc3QgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yIC1tbC0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDcmVhciBSZW1pdG9cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBERVRBTExFUyBERSBDQUJFQ0VSQSAoQ09NUExFVE9TKSAtLS0gKi99XG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAteC00IGdhcC15LTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICB7aW52b2ljZS5jYWVfbnVtYmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMSBiZy1ncmVlbi01MCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPkNBRSBBdXRvcml6YWRvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhsIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ncmVlbi05MDAgdHJhY2tpbmctd2lkZXJcIj57aW52b2ljZS5jYWVfbnVtYmVyfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMSBiZy1ncmVlbi01MCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlZlbmNpbWllbnRvIENBRTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTkwMFwiPntmb3JtYXRWYWx1ZShpbnZvaWNlLmNhZV9kdWVfZGF0ZSwgJ2RhdGUnKX08L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q2xpZW50ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL2NsaWVudGVzLyR7aW52b2ljZS5jbGllbnQ/LmlkfWB9IC8vIEFzdW1vIHJ1dGEgL3Byb3ZlZWRvcmVzLzppZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW52b2ljZS5jbGllbnQ/Lm5hbWUgfHwgaW52b2ljZS5jbGllbnRfbmFtZSB8fCAnTi9BJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5GZWNoYSBGYWN0dXJhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUoaW52b2ljZS5pbnZvaWNlX2RhdGUsICdkYXRlJyl9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TZXJpZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e2ludm9pY2Uuc2VyaWVzfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+UmVtaXRvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0RG9jdW1lbnRWb3VjaGVyUmVtaXRvKGludm9pY2UuZG9jdW1lbnRfdm91Y2hlcil9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5QZWRpZG8gT3JpZ2VuPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57aW52b2ljZS5zYWxlc19vcmRlcj8ub3JkZXJfbnVtYmVyIHx8IGludm9pY2Uuc2FsZXNfb3JkZXJfbnVtYmVyIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlZlbmRlZG9yPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57aW52b2ljZS5zYWxlc3BlcnNvbj8ubmFtZSB8fCBpbnZvaWNlLnNhbGVzcGVyc29uX25hbWUgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q29tcHJhZG9yPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57aW52b2ljZS5idXllcj8ubmFtZSB8fCBpbnZvaWNlLmJ1eWVyX25hbWUgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+TW9uZWRhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57aW52b2ljZS5jdXJyZW5jeT8ubmFtZSB8fCBpbnZvaWNlLmN1cnJlbmN5X25hbWUgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VGlwbyBkZSBDYW1iaW88L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntpbnZvaWNlLmV4Y2hhbmdlX3JhdGUgPyBOdW1iZXIoaW52b2ljZS5leGNoYW5nZV9yYXRlKS50b0ZpeGVkKDIpIDogJzEuMDAnfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+TW9zdHJhciB2YWxvciBlbiBkb2xhcmVzPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ISFpbnZvaWNlLnNob3dfY3VycmVuY3lfZXF1aXZhbGVuY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgTW9zdHJhciB2YWxvciBlbiBkb2xhcmVzOiAke2ludm9pY2Uuc2hvd19jdXJyZW5jeV9lcXVpdmFsZW5jZSA/ICdTw60nIDogJ05vJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTAgcm91bmRlZCBib3JkZXItZ3JheS0zMDAgdGV4dC1pbmRpZ28tNjAwIGN1cnNvci1kZWZhdWx0IG9wYWNpdHktNzBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpbnZvaWNlLnNob3dfY3VycmVuY3lfZXF1aXZhbGVuY2UgPyAnU8OtJyA6ICdObyd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIEVudHJlZ2E8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntpbnZvaWNlLmRlbGl2ZXJ5X2RhdGUgPyBmb3JtYXRWYWx1ZShpbnZvaWNlLmRlbGl2ZXJ5X2RhdGUsICdkYXRlJykgOiAnTi9BJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlRyYW5zcG9ydGU8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntpbnZvaWNlLnRyYW5zcG9ydD8ubmFtZSB8fCBpbnZvaWNlLnRyYW5zcG9ydF9uYW1lIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9Pk7CuiBPLiBDb21wcmEgQ2xpZW50ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e2ludm9pY2UucHVyY2hhc2Vfb3JkZXJfbnVtYmVyIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRpcmVjY2nDs24gZGUgRW50cmVnYTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e2ludm9pY2UuZGVsaXZlcnlfYWRkcmVzcyB8fCAnLSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGw+XG5cblxuICAgICAgICAgICAgey8qIC0tLSBUYWJsYSBJdGVtcyAoQWN0dWFsaXphZGEpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbGVhZGluZy02IHRleHQtZ3JheS05MDBcIj5JdGVtcyBkZSBsYSBGYWN0dXJhPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc206bXgtMCBzbTpyb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcGwtNCBwci0zIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzbTpwbC02XCI+QXJ0w61jdWxvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DYW50LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+UC4gVW5pdC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBoaWRkZW5cIj5EZXNjLiAoTW9udG8pPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5TdWJ0b3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgaW52b2ljZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkltcHVlc3RvczwvdGg+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnByLTZcIj5Ub3RhbCBMw61uZWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnZvaWNlLml0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VidG90YWwgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzY291bnQgPSBOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWJ0b3RhbCA9IHN1YnRvdGFsIC0gZGlzY291bnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXggPSAhaXNDbGllbnRUYXhFeGVtcHQgJiYgaW52b2ljZS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IGdldEl0ZW1UYXhUb3RhbChpdGVtKSA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2R1Y3RfaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9hcnRpY3Vsb3MvJHtpdGVtLnByb2R1Y3RfaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+KHtpdGVtLnByb2R1Y3RfY29kZX0pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntpdGVtLnByb2R1Y3RfbmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntOdW1iZXIoaXRlbS5xdWFudGl0eSkudG9GaXhlZCgyKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUoaXRlbS51bml0X3ByaWNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDAgaGlkZGVuXCI+e2Zvcm1hdFZhbHVlKGRpc2NvdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUobGluZVN1YnRvdGFsLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgaW52b2ljZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGl0ZW1UYXgsICdjdXJyZW5jeScpfTwvdGQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBzbTpwci02XCI+e2Zvcm1hdFZhbHVlKGxpbmVUb3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgVE9UQUxFUyAoQWN0dWFsaXphZGEpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Ob3RhczwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+e2ludm9pY2Uubm90ZXMgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEltcHVlc3RvcyBHbG9iYWxlcyAoQ29uZGljaW9uYWwpICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmICFpbnZvaWNlLmhhc19pdGVtX2xldmVsX3RheGVzICYmIGludm9pY2UudGF4ZXMgJiYgaW52b2ljZS50YXhlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkltcHVlc3RvcyBHbG9iYWxlcyBBcGxpY2Fkb3M8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnZvaWNlLnRheGVzLm1hcCgodGF4LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dGF4LnRheF9pZCB8fCBpbmRleH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZS5yZXBsYWNlKCd0ZXh0LWdyYXktNjAwJywgJ3RleHQtZ3JheS03MDAnKX0+e3RheC50YXhfbmFtZX0gKHt0YXgucmF0ZX0lKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUodGF4LmFtb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFJlc3VtZW4gRmluYWwgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHAtNCBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlN1YnRvdGFsIChJdGVtcyk6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy5zdWJ0b3RhbCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBoaWRkZW5cIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+RGVzYy4gKEl0ZW1zKTo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxJdGVtRGlzY291bnRzLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGhpZGRlblwiPjxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5EZXNjLiAoR2xvYmFsKTo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuZ2xvYmFsRGlzY291bnRBbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTIgYm9yZGVyLXQgbXQtMlwiPjxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSBmb250LXNlbWlib2xkYH0+QmFzZSBJbXBvbmlibGU6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1iYXNlJyl9IGZvbnQtc2VtaWJvbGRgfT57Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50YXhCYXNlLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+e2ludm9pY2UuaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgPyBcIkltcHVlc3RvcyAoSXRlbXMpOlwiIDogXCJJbXB1ZXN0b3MgKEdsb2JhbCk6XCJ9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT4rIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRvdGFsVGF4ZXMsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj48c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsTGFiZWxTdHlsZX0gdGV4dC1sZyBmb250LXNlbWlib2xkYH0+VG90YWwgRmluYWw6PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlLnJlcGxhY2UoJ3RleHQtc20nLCAndGV4dC1sZycpfSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwYH0+e2Zvcm1hdFZhbHVlKGludm9pY2UudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2ZhY3R1cmFzX3ZlbnRhL3BhZ2VzL0ZhY3R1cmFzVmVudGFEZXRhaWxQYWdlLnRzeCJ9