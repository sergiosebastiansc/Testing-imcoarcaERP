import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/impuestos/pages/ImpuestosCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/impuestos/pages/ImpuestosCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { taxesModuleConfig } from "/src/features/impuestos/impuestos.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const initialTaxValues = {
  name: "",
  rate: 0,
  type: 1
};
export const ImpuestosCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(taxesModuleConfig);
  const handleSave = async (data) => {
    const newItem = await saveItem(data);
    if (newItem) {
      toast.info(`Impuesto creado con éxito!`);
      navigate(getListReturnPath(taxesModuleConfig.baseRoute));
    }
  };
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: taxesModuleConfig,
      initialData: initialTaxValues,
      onSave: handleSave,
      mode: "create"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/impuestos/pages/ImpuestosCreatePage.tsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
};
_s(ImpuestosCreatePage, "uwSXhbozRQ+CcAglXSYw0FupfqU=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = ImpuestosCreatePage;
var _c;
$RefreshReg$(_c, "ImpuestosCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/impuestos/pages/ImpuestosCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/impuestos/pages/ImpuestosCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHlCQUFtQztBQUM1QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsbUJBQWlDO0FBQUEsRUFDbkNDLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUNWO0FBRU8sYUFBTUMsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTUMsV0FBV1osWUFBWTtBQUM3QixRQUFNLEVBQUVhLFNBQVMsSUFBSVYsWUFBaUJELGlCQUFpQjtBQUV2RCxRQUFNWSxhQUFhLE9BQU9DLFNBQWM7QUFDcEMsVUFBTUMsVUFBVSxNQUFNSCxTQUFTRSxJQUFJO0FBQ25DLFFBQUlDLFNBQVM7QUFDVFosWUFBTWEsS0FBSyw0QkFBNEI7QUFDdkNMLGVBQVNQLGtCQUFrQkgsa0JBQWtCZ0IsU0FBUyxDQUFDO0FBQUEsSUFDM0Q7QUFBQSxFQUNKO0FBRUEsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUWhCO0FBQUFBLE1BQ1IsYUFBYUk7QUFBQUEsTUFDYixRQUFRUTtBQUFBQSxNQUNSLE1BQUs7QUFBQTtBQUFBLElBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWlCO0FBR3pCO0FBQUVILEdBcEJXRCxxQkFBbUI7QUFBQSxVQUNYVixhQUNJRyxXQUFXO0FBQUE7QUFBQWdCLEtBRnZCVDtBQUFtQixJQUFBUztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJ0YXhlc01vZHVsZUNvbmZpZyIsInVzZUNydWRJdGVtIiwidG9hc3QiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImluaXRpYWxUYXhWYWx1ZXMiLCJuYW1lIiwicmF0ZSIsInR5cGUiLCJJbXB1ZXN0b3NDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNhdmVJdGVtIiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJuZXdJdGVtIiwiaW5mbyIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkltcHVlc3Rvc0NyZWF0ZVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBHZW5lcmljRm9ybVBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVBhZ2UnO1xuaW1wb3J0IHsgdGF4ZXNNb2R1bGVDb25maWcsIHR5cGUgVGF4IH0gZnJvbSAnLi4vaW1wdWVzdG9zLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgZ2V0TGlzdFJldHVyblBhdGggfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0UmV0dXJuTmF2aWdhdGlvbic7XG5cbmNvbnN0IGluaXRpYWxUYXhWYWx1ZXM6IFBhcnRpYWw8VGF4PiA9IHtcbiAgICBuYW1lOiAnJyxcbiAgICByYXRlOiAwLFxuICAgIHR5cGU6IDEsXG59O1xuXG5leHBvcnQgY29uc3QgSW1wdWVzdG9zQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08VGF4Pih0YXhlc01vZHVsZUNvbmZpZyk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGRhdGE6IFRheCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdJdGVtID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YSk7XG4gICAgICAgIGlmIChuZXdJdGVtKSB7XG4gICAgICAgICAgICB0b2FzdC5pbmZvKGBJbXB1ZXN0byBjcmVhZG8gY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHRheGVzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17dGF4ZXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpbml0aWFsRGF0YT17aW5pdGlhbFRheFZhbHVlcyBhcyBUYXh9XG4gICAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICBtb2RlPVwiY3JlYXRlXCJcbiAgICAgICAgLz5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2ltcHVlc3Rvcy9wYWdlcy9JbXB1ZXN0b3NDcmVhdGVQYWdlLnRzeCJ9