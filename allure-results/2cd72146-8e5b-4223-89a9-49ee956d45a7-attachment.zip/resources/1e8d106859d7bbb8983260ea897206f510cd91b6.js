import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mov_stock/pages/MovStockCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mov_stock/pages/MovStockCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { stockMovementsModuleConfig } from "/src/features/mov_stock/movStock.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { MovStockFormPage } from "/src/features/mov_stock/pages/MovStockFormPage.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const MovStockCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const { saveItem } = useCrudItem(stockMovementsModuleConfig);
  const [loading, setLoading] = useState(false);
  const handleSave = async (formData) => {
    setLoading(true);
    const promises = formData.products.map((p) => {
      const payload = {
        ...formData.commonData,
        product_id: p.product.id,
        quantity: p.quantity
      };
      delete payload.client_name;
      delete payload.vendor_name;
      return saveItem(payload);
    });
    try {
      await Promise.all(promises);
      toast.success(`${formData.products.length} movimiento(s) creados con éxito!`);
      navigate(getListReturnPath(stockMovementsModuleConfig.baseRoute));
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    MovStockFormPage,
    {
      mode: "create",
      onSubmit: handleSave,
      loading
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/mov_stock/pages/MovStockCreatePage.tsx",
      lineNumber: 63,
      columnNumber: 5
    },
    this
  );
};
_s(MovStockCreatePage, "YBzmU8Uz45bQWoiG1CED8+pToHw=", false, function() {
  return [useNavigate, useCrudItem];
});
_c = MovStockCreatePage;
var _c;
$RefreshReg$(_c, "MovStockCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mov_stock/pages/MovStockCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mov_stock/pages/MovStockCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFDUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msa0NBQWlEO0FBQzFELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyx3QkFBK0M7QUFDeEQsU0FBU0MseUJBQXlCO0FBRTNCLGFBQU1DLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU1DLFdBQVdSLFlBQVk7QUFDN0IsUUFBTSxFQUFFUyxTQUFTLElBQUlOLFlBQXNCRCwwQkFBMEI7QUFDckUsUUFBTSxDQUFDUSxTQUFTQyxVQUFVLElBQUlaLFNBQVMsS0FBSztBQUU1QyxRQUFNYSxhQUFhLE9BQU9DLGFBQStCO0FBQ3JERixlQUFXLElBQUk7QUFFZixVQUFNRyxXQUFXRCxTQUFTRSxTQUFTQyxJQUFJLENBQUFDLE1BQUs7QUFDeEMsWUFBTUMsVUFBNkI7QUFBQSxRQUMvQixHQUFHTCxTQUFTTTtBQUFBQSxRQUNaQyxZQUFZSCxFQUFFSSxRQUFTQztBQUFBQSxRQUN2QkMsVUFBVU4sRUFBRU07QUFBQUEsTUFDaEI7QUFFQSxhQUFRTCxRQUFnQk07QUFDeEIsYUFBUU4sUUFBZ0JPO0FBRXhCLGFBQU9oQixTQUFTUyxPQUFtQjtBQUFBLElBQ3ZDLENBQUM7QUFFRCxRQUFJO0FBQ0EsWUFBTVEsUUFBUUMsSUFBSWIsUUFBUTtBQUMxQmIsWUFBTTJCLFFBQVEsR0FBR2YsU0FBU0UsU0FBU2MsTUFBTSxtQ0FBbUM7QUFDNUVyQixlQUFTSCxrQkFBa0JILDJCQUEyQjRCLFNBQVMsQ0FBQztBQUFBLElBQ3BFLFNBQVNDLE9BQU87QUFDWkMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBRXZCLFVBQUM7QUFDR3BCLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxNQUFLO0FBQUEsTUFDTCxVQUFVQztBQUFBQSxNQUNWO0FBQUE7QUFBQSxJQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdxQjtBQUc3QjtBQUFFTCxHQXhDV0Qsb0JBQWtCO0FBQUEsVUFDVk4sYUFDSUcsV0FBVztBQUFBO0FBQUE4QixLQUZ2QjNCO0FBQWtCLElBQUEyQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0Iiwic3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIk1vdlN0b2NrRm9ybVBhZ2UiLCJnZXRMaXN0UmV0dXJuUGF0aCIsIk1vdlN0b2NrQ3JlYXRlUGFnZSIsIl9zIiwibmF2aWdhdGUiLCJzYXZlSXRlbSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaGFuZGxlU2F2ZSIsImZvcm1EYXRhIiwicHJvbWlzZXMiLCJwcm9kdWN0cyIsIm1hcCIsInAiLCJwYXlsb2FkIiwiY29tbW9uRGF0YSIsInByb2R1Y3RfaWQiLCJwcm9kdWN0IiwiaWQiLCJxdWFudGl0eSIsImNsaWVudF9uYW1lIiwidmVuZG9yX25hbWUiLCJQcm9taXNlIiwiYWxsIiwic3VjY2VzcyIsImxlbmd0aCIsImJhc2VSb3V0ZSIsImVycm9yIiwiY29uc29sZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vdlN0b2NrQ3JlYXRlUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBzdG9ja01vdmVtZW50c01vZHVsZUNvbmZpZywgdHlwZSBNb3ZTdG9jayB9IGZyb20gJy4uL21vdlN0b2NrLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IE1vdlN0b2NrRm9ybVBhZ2UsIHR5cGUgTW92U3RvY2tGb3JtRGF0YSB9IGZyb20gJy4vTW92U3RvY2tGb3JtUGFnZSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IE1vdlN0b2NrQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBzYXZlSXRlbSB9ID0gdXNlQ3J1ZEl0ZW08TW92U3RvY2s+KHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnKTtcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKGZvcm1EYXRhOiBNb3ZTdG9ja0Zvcm1EYXRhKSA9PiB7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIC8vIEzDs2dpY2EgZGUgTE9URTogVW4gbW92aW1pZW50byBwb3IgY2FkYSBwcm9kdWN0byBlbiBsYSBncmlsbGFcbiAgICAgICAgY29uc3QgcHJvbWlzZXMgPSBmb3JtRGF0YS5wcm9kdWN0cy5tYXAocCA9PiB7XG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkOiBQYXJ0aWFsPE1vdlN0b2NrPiA9IHtcbiAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5jb21tb25EYXRhLFxuICAgICAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHAucHJvZHVjdCEuaWQsXG4gICAgICAgICAgICAgICAgcXVhbnRpdHk6IHAucXVhbnRpdHksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgLy8gTGltcGllemFcbiAgICAgICAgICAgIGRlbGV0ZSAocGF5bG9hZCBhcyBhbnkpLmNsaWVudF9uYW1lO1xuICAgICAgICAgICAgZGVsZXRlIChwYXlsb2FkIGFzIGFueSkudmVuZG9yX25hbWU7XG5cbiAgICAgICAgICAgIHJldHVybiBzYXZlSXRlbShwYXlsb2FkIGFzIE1vdlN0b2NrKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHByb21pc2VzKTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCR7Zm9ybURhdGEucHJvZHVjdHMubGVuZ3RofSBtb3ZpbWllbnRvKHMpIGNyZWFkb3MgY29uIMOpeGl0byFgKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHN0b2NrTW92ZW1lbnRzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICAvLyBFbCB0b2FzdCBkZSBlcnJvciB5YSBsbyBtYW5lamEgdXNlQ3J1ZEl0ZW0gbyBlbCBmb3JtXG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8TW92U3RvY2tGb3JtUGFnZVxuICAgICAgICAgICAgbW9kZT1cImNyZWF0ZVwiXG4gICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9tb3Zfc3RvY2svcGFnZXMvTW92U3RvY2tDcmVhdGVQYWdlLnRzeCJ9