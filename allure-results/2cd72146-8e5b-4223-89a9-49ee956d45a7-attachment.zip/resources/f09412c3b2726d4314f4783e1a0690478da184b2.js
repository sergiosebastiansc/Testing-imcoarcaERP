import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cajas/pages/CajasStatementPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cajas/pages/CajasStatementPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { CashStatementTab } from "/src/components/common/CashStatementTab.tsx";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
export const CajasStatementPage = () => {
  _s();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const modulePermission = getRequiredPermission("/cajas");
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canCreate = moduleBase ? hasModulePermission(moduleBase, "create") : true;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:flex-auto", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: "Estado de cuenta - Cajas" }, void 0, false, {
        fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
        lineNumber: 36,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
        lineNumber: 35,
        columnNumber: 17
      }, this),
      canCreate && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4 sm:flex-none", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate("/cajas/list"),
            className: "inline-flex items-center justify-center px-4 mx-2 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:w-auto",
            children: "Historico de movimientos"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
            lineNumber: 40,
            columnNumber: 25
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate("/cajas/nuevo"),
            className: "inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:w-auto",
            children: "Crear movimiento de caja"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
            lineNumber: 48,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
      lineNumber: 34,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(CashStatementTab, {}, void 0, false, {
      fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
      lineNumber: 58,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/cajas/pages/CajasStatementPage.tsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
};
_s(CajasStatementPage, "TwRThkIw7ZpS7ZY3xXGb+42vAjs=", false, function() {
  return [useNavigate, usePermissions];
});
_c = CajasStatementPage;
var _c;
$RefreshReg$(_c, "CajasStatementPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cajas/pages/CajasStatementPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cajas/pages/CajasStatementPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoQnBCLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBRXhELGFBQU1DLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU1DLFdBQVdQLFlBQVk7QUFDN0IsUUFBTSxFQUFFUSxvQkFBb0IsSUFBSU4sZUFBZTtBQUMvQyxRQUFNTyxtQkFBbUJOLHNCQUFzQixRQUFRO0FBQ3ZELFFBQU1PLGFBQWFELG1CQUFtQkwsd0JBQXdCSyxnQkFBZ0IsSUFBSTtBQUNsRixRQUFNRSxZQUFZRCxhQUFhRixvQkFBb0JFLFlBQVksUUFBUSxJQUFJO0FBRTNFLFNBQ0ksdUJBQUMsU0FDRztBQUFBLDJCQUFDLFNBQUksV0FBVSw4Q0FDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDWCxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFLEtBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NDLGFBQ0csdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUosU0FBUyxhQUFhO0FBQUEsWUFDckMsV0FBVTtBQUFBLFlBQXlQO0FBQUE7QUFBQSxVQUh2UTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUEsU0FBUyxjQUFjO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBQXVQO0FBQUE7QUFBQSxVQUhyUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBckJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUNBLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUI7QUFBQSxPQXpCckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQTtBQUVSO0FBQUVELEdBcENXRCxvQkFBa0I7QUFBQSxVQUNWTCxhQUNlRSxjQUFjO0FBQUE7QUFBQVUsS0FGckNQO0FBQWtCLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VOYXZpZ2F0ZSIsIkNhc2hTdGF0ZW1lbnRUYWIiLCJ1c2VQZXJtaXNzaW9ucyIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIiwiQ2FqYXNTdGF0ZW1lbnRQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJtb2R1bGVQZXJtaXNzaW9uIiwibW9kdWxlQmFzZSIsImNhbkNyZWF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhamFzU3RhdGVtZW50UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IENhc2hTdGF0ZW1lbnRUYWIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9DYXNoU3RhdGVtZW50VGFiJztcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlUGVybWlzc2lvbnMnO1xuaW1wb3J0IHsgZ2V0UmVxdWlyZWRQZXJtaXNzaW9uLCBnZXRNb2R1bGVCYXNlUGVybWlzc2lvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3Blcm1pc3Npb25zJztcblxuZXhwb3J0IGNvbnN0IENhamFzU3RhdGVtZW50UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IG1vZHVsZVBlcm1pc3Npb24gPSBnZXRSZXF1aXJlZFBlcm1pc3Npb24oJy9jYWphcycpO1xuICAgIGNvbnN0IG1vZHVsZUJhc2UgPSBtb2R1bGVQZXJtaXNzaW9uID8gZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24obW9kdWxlUGVybWlzc2lvbikgOiBudWxsO1xuICAgIGNvbnN0IGNhbkNyZWF0ZSA9IG1vZHVsZUJhc2UgPyBoYXNNb2R1bGVQZXJtaXNzaW9uKG1vZHVsZUJhc2UsICdjcmVhdGUnKSA6IHRydWU7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+RXN0YWRvIGRlIGN1ZW50YSAtIENhamFzPC9oMT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7Y2FuQ3JlYXRlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNtOm10LTAgc206bWwtNCBzbTpmbGV4LW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2NhamFzL2xpc3QnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtNCBteC0yIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXJlZC02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgc206dy1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBIaXN0b3JpY28gZGUgbW92aW1pZW50b3NcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9jYWphcy9udWV2bycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1pbmRpZ28tNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgc206dy1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDcmVhciBtb3ZpbWllbnRvIGRlIGNhamFcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Q2FzaFN0YXRlbWVudFRhYiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY2FqYXMvcGFnZXMvQ2FqYXNTdGF0ZW1lbnRQYWdlLnRzeCJ9