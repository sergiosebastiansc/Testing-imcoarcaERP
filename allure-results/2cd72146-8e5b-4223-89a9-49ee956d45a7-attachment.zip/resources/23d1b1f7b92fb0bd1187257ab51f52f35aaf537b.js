import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transportes/pages/TransportesDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/transportes/pages/TransportesDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
export const TransportesDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item, loading, error } = useCrudItem(transportesModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Transporte no encontrado." }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(GenericDetailPage, { config: transportesModuleConfig, item }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(TransportesDetailPage, "6YQMcrxNTGjd60HB6xOhIbiA4BI=", false, function() {
  return [useParams, useCrudItem];
});
_c = TransportesDetailPage;
var _c;
$RefreshReg$(_c, "TransportesDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/transportes/pages/TransportesDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/transportes/pages/TransportesDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVZ4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLCtCQUFnRDtBQUN6RCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBRXhCLGFBQU1DLHdCQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsR0FBRyxJQUFJUCxVQUEwQjtBQUN6QyxRQUFNLEVBQUVRLE1BQU1DLFNBQVNDLE1BQU0sSUFBSVAsWUFBd0JELHlCQUF5QkssRUFBRTtBQUVwRixNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHlDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFFaEQsU0FBTyx1QkFBQyxxQkFBa0IsUUFBUU4seUJBQXlCLFFBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0Q7QUFDMUU7QUFBRUksR0FUV0QsdUJBQXFCO0FBQUEsVUFDZkwsV0FDa0JHLFdBQVc7QUFBQTtBQUFBUSxLQUZuQ047QUFBcUIsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsIkdlbmVyaWNEZXRhaWxQYWdlIiwidHJhbnNwb3J0ZXNNb2R1bGVDb25maWciLCJ1c2VDcnVkSXRlbSIsIkxvYWRpbmdTcGlubmVyIiwiVHJhbnNwb3J0ZXNEZXRhaWxQYWdlIiwiX3MiLCJpZCIsIml0ZW0iLCJsb2FkaW5nIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUcmFuc3BvcnRlc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0RldGFpbFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRGV0YWlsUGFnZSc7XG5pbXBvcnQgeyB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZywgdHlwZSBUcmFuc3BvcnRlIH0gZnJvbSAnLi4vdHJhbnNwb3J0ZXMuY29uZmlnJztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcblxuZXhwb3J0IGNvbnN0IFRyYW5zcG9ydGVzRGV0YWlsUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgeyBpdGVtLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08VHJhbnNwb3J0ZT4odHJhbnNwb3J0ZXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWl0ZW0pIHJldHVybiA8ZGl2PlRyYW5zcG9ydGUgbm8gZW5jb250cmFkby48L2Rpdj47XG5cbiAgICByZXR1cm4gPEdlbmVyaWNEZXRhaWxQYWdlIGNvbmZpZz17dHJhbnNwb3J0ZXNNb2R1bGVDb25maWd9IGl0ZW09e2l0ZW19IC8+O1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3RyYW5zcG9ydGVzL3BhZ2VzL1RyYW5zcG9ydGVzRGV0YWlsUGFnZS50c3gifQ==