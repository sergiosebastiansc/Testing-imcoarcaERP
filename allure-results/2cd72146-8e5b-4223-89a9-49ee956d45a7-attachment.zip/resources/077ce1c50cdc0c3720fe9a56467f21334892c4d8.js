import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/components/BulkAdjustSalePriceModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { clampPercentClientInput } from "/src/features/articulos/utils/bulkAdjustSalePricePayload.ts";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useState = __vite__cjsImport6_react["useState"];
export function BulkAdjustSalePriceModal({
  isOpen,
  loading = false,
  selectionSummary,
  selectionCount,
  onClose,
  onApply
}) {
  _s();
  const [percentInput, setPercentInput] = useState("");
  useEffect(() => {
    if (isOpen) setPercentInput("");
  }, [isOpen]);
  if (!isOpen) return null;
  const handleSubmit = async (e) => {
    e.preventDefault();
    const raw = parseFloat(String(percentInput).replace(",", "."));
    if (Number.isNaN(raw)) {
      toast.error("Ingrese un porcentaje numérico.");
      return;
    }
    const clamped = clampPercentClientInput(raw);
    await onApply(clamped);
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4",
      "aria-modal": "true",
      role: "dialog",
      "aria-labelledby": "bulk-adjust-sale-price-title",
      children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md rounded-lg bg-white p-6 shadow-xl", children: [
        /* @__PURE__ */ jsxDEV("h2", { id: "bulk-adjust-sale-price-title", className: "text-lg font-semibold text-gray-900", children: "Actualización de precios" }, void 0, false, {
          fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
          lineNumber: 69,
          columnNumber: 17
        }, this),
        selectionSummary ? /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600", children: selectionSummary }, void 0, false, {
          fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
          lineNumber: 73,
          columnNumber: 9
        }, this) : selectionCount > 0 ? /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600", children: [
          selectionCount,
          " producto",
          selectionCount === 1 ? "" : "s",
          " seleccionado",
          selectionCount === 1 ? "" : "s"
        ] }, void 0, true, {
          fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
          lineNumber: 75,
          columnNumber: 9
        }, this) : null,
        /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => void handleSubmit(e), className: "mt-4 space-y-4", autoComplete: "off", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: "bulk-adjust-percent", className: "block text-sm font-medium text-gray-700", children: "Incremento (%)" }, void 0, false, {
              fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
              lineNumber: 82,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                inputMode: "decimal",
                id: "bulk-adjust-percent",
                value: percentInput,
                onChange: (e) => setPercentInput(e.target.value),
                disabled: loading,
                placeholder: "Ej: 5 o -2,50",
                className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm disabled:opacity-50",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
                lineNumber: 85,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
            lineNumber: 81,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap justify-end gap-2 pt-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onClose,
                disabled: loading,
                className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50",
                children: "Cancelar"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
                lineNumber: 97,
                columnNumber: 25
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                disabled: loading || percentInput.trim() === "",
                className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed",
                children: loading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin mr-2 h-4 w-4", "aria-hidden": true }, void 0, false, {
                    fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
                    lineNumber: 112,
                    columnNumber: 37
                  }, this),
                  "Aplicando..."
                ] }, void 0, true, {
                  fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
                  lineNumber: 111,
                  columnNumber: 15
                }, this) : "Aplicar"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
                lineNumber: 105,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
            lineNumber: 96,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
          lineNumber: 80,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
        lineNumber: 68,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx",
      lineNumber: 62,
      columnNumber: 5
    },
    this
  );
}
_s(BulkAdjustSalePriceModal, "gwxWrLDgKh3/DimqzlokFb4LvRU=");
_c = BulkAdjustSalePriceModal;
var _c;
$RefreshReg$(_c, "BulkAdjustSalePriceModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/components/BulkAdjustSalePriceModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURnQixTQTBDZ0IsVUExQ2hCOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpEaEIsU0FBU0EsYUFBYTtBQUN0QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsK0JBQStCO0FBQ3hDLFNBQVNDLFdBQVdDLGdCQUFnQjtBQVc3QixnQkFBU0MseUJBQXlCO0FBQUEsRUFDckNDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUMyQixHQUFHO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlWLFNBQVMsRUFBRTtBQUVuREQsWUFBVSxNQUFNO0FBQ1osUUFBSUcsT0FBUVEsaUJBQWdCLEVBQUU7QUFBQSxFQUNsQyxHQUFHLENBQUNSLE1BQU0sQ0FBQztBQUVYLE1BQUksQ0FBQ0EsT0FBUSxRQUFPO0FBRXBCLFFBQU1TLGVBQWUsT0FBT0MsTUFBdUI7QUFDL0NBLE1BQUVDLGVBQWU7QUFDakIsVUFBTUMsTUFBTUMsV0FBV0MsT0FBT1AsWUFBWSxFQUFFUSxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQzdELFFBQUlDLE9BQU9DLE1BQU1MLEdBQUcsR0FBRztBQUNuQmxCLFlBQU13QixNQUFNLGlDQUFpQztBQUM3QztBQUFBLElBQ0o7QUFDQSxVQUFNQyxVQUFVdkIsd0JBQXdCZ0IsR0FBRztBQUMzQyxVQUFNUCxRQUFRYyxPQUFPO0FBQUEsRUFDekI7QUFFQSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxXQUFVO0FBQUEsTUFDVixjQUFXO0FBQUEsTUFDWCxNQUFLO0FBQUEsTUFDTCxtQkFBZ0I7QUFBQSxNQUVoQixpQ0FBQyxTQUFJLFdBQVUscURBQ1g7QUFBQSwrQkFBQyxRQUFHLElBQUcsZ0NBQStCLFdBQVUsdUNBQXFDLHdDQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDakIsbUJBQ0csdUJBQUMsT0FBRSxXQUFVLDhCQUE4QkEsOEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQsSUFDNURDLGlCQUFpQixJQUNqQix1QkFBQyxPQUFFLFdBQVUsOEJBQ1JBO0FBQUFBO0FBQUFBLFVBQWU7QUFBQSxVQUFVQSxtQkFBbUIsSUFBSSxLQUFLO0FBQUEsVUFBSTtBQUFBLFVBQ3pEQSxtQkFBbUIsSUFBSSxLQUFLO0FBQUEsYUFGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBQ0E7QUFBQSxRQUNKLHVCQUFDLFVBQUssVUFBVSxDQUFBTyxNQUFLLEtBQUtELGFBQWFDLENBQUMsR0FBRyxXQUFVLGtCQUFpQixjQUFhLE9BQy9FO0FBQUEsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sU0FBUSx1QkFBc0IsV0FBVSwyQ0FBeUMsOEJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsT0FBT0g7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBRyxNQUFLRixnQkFBZ0JFLEVBQUVVLE9BQU9DLEtBQUs7QUFBQSxnQkFDN0MsVUFBVXBCO0FBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQXVKLGNBQWE7QUFBQTtBQUFBLGNBUmxMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVF1TDtBQUFBLGVBWjNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFNBQVNHO0FBQUFBLGdCQUNULFVBQVVIO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFBNkg7QUFBQTtBQUFBLGNBSjNJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxVQUFVQSxXQUFXTSxhQUFhZSxLQUFLLE1BQU07QUFBQSxnQkFDN0MsV0FBVTtBQUFBLGdCQUVUckIsb0JBQ0csbUNBQ0k7QUFBQSx5Q0FBQyxhQUFVLFdBQVUsNkJBQTRCLGVBQVcsUUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQTtBQUFBLHFCQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLElBRUE7QUFBQTtBQUFBLGNBWFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxlQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQSxXQXBESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcURBO0FBQUE7QUFBQSxJQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE0REE7QUFFUjtBQUFDSyxHQTFGZVAsMEJBQXdCO0FBQUF3QixLQUF4QnhCO0FBQXdCLElBQUF3QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidG9hc3QiLCJGYVNwaW5uZXIiLCJjbGFtcFBlcmNlbnRDbGllbnRJbnB1dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQnVsa0FkanVzdFNhbGVQcmljZU1vZGFsIiwiaXNPcGVuIiwibG9hZGluZyIsInNlbGVjdGlvblN1bW1hcnkiLCJzZWxlY3Rpb25Db3VudCIsIm9uQ2xvc2UiLCJvbkFwcGx5IiwiX3MiLCJwZXJjZW50SW5wdXQiLCJzZXRQZXJjZW50SW5wdXQiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJyYXciLCJwYXJzZUZsb2F0IiwiU3RyaW5nIiwicmVwbGFjZSIsIk51bWJlciIsImlzTmFOIiwiZXJyb3IiLCJjbGFtcGVkIiwidGFyZ2V0IiwidmFsdWUiLCJ0cmltIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnVsa0FkanVzdFNhbGVQcmljZU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU3Bpbm5lciB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGNsYW1wUGVyY2VudENsaWVudElucHV0IH0gZnJvbSAnLi4vdXRpbHMvYnVsa0FkanVzdFNhbGVQcmljZVBheWxvYWQnO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuaW50ZXJmYWNlIEJ1bGtBZGp1c3RTYWxlUHJpY2VNb2RhbFByb3BzIHtcbiAgICBpc09wZW46IGJvb2xlYW47XG4gICAgbG9hZGluZz86IGJvb2xlYW47XG4gICAgc2VsZWN0aW9uU3VtbWFyeTogc3RyaW5nO1xuICAgIHNlbGVjdGlvbkNvdW50OiBudW1iZXI7XG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgICBvbkFwcGx5OiAocGVyY2VudDogbnVtYmVyKSA9PiBQcm9taXNlPHZvaWQ+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQnVsa0FkanVzdFNhbGVQcmljZU1vZGFsKHtcbiAgICBpc09wZW4sXG4gICAgbG9hZGluZyA9IGZhbHNlLFxuICAgIHNlbGVjdGlvblN1bW1hcnksXG4gICAgc2VsZWN0aW9uQ291bnQsXG4gICAgb25DbG9zZSxcbiAgICBvbkFwcGx5LFxufTogQnVsa0FkanVzdFNhbGVQcmljZU1vZGFsUHJvcHMpIHtcbiAgICBjb25zdCBbcGVyY2VudElucHV0LCBzZXRQZXJjZW50SW5wdXRdID0gdXNlU3RhdGUoJycpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGlzT3Blbikgc2V0UGVyY2VudElucHV0KCcnKTtcbiAgICB9LCBbaXNPcGVuXSk7XG5cbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgY29uc3QgcmF3ID0gcGFyc2VGbG9hdChTdHJpbmcocGVyY2VudElucHV0KS5yZXBsYWNlKCcsJywgJy4nKSk7XG4gICAgICAgIGlmIChOdW1iZXIuaXNOYU4ocmF3KSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0luZ3Jlc2UgdW4gcG9yY2VudGFqZSBudW3DqXJpY28uJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2xhbXBlZCA9IGNsYW1wUGVyY2VudENsaWVudElucHV0KHJhdyk7XG4gICAgICAgIGF3YWl0IG9uQXBwbHkoY2xhbXBlZCk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay81MCBwLTRcIlxuICAgICAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJidWxrLWFkanVzdC1zYWxlLXByaWNlLXRpdGxlXCJcbiAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgcm91bmRlZC1sZyBiZy13aGl0ZSBwLTYgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICAgICAgPGgyIGlkPVwiYnVsay1hZGp1c3Qtc2FsZS1wcmljZS10aXRsZVwiIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEFjdHVhbGl6YWNpw7NuIGRlIHByZWNpb3NcbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIHtzZWxlY3Rpb25TdW1tYXJ5ID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPntzZWxlY3Rpb25TdW1tYXJ5fTwvcD5cbiAgICAgICAgICAgICAgICApIDogc2VsZWN0aW9uQ291bnQgPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGlvbkNvdW50fSBwcm9kdWN0b3tzZWxlY3Rpb25Db3VudCA9PT0gMSA/ICcnIDogJ3MnfSBzZWxlY2Npb25hZG9cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3Rpb25Db3VudCA9PT0gMSA/ICcnIDogJ3MnfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2UgPT4gdm9pZCBoYW5kbGVTdWJtaXQoZSl9IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCIgYXV0b0NvbXBsZXRlPVwib2ZmXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImJ1bGstYWRqdXN0LXBlcmNlbnRcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbmNyZW1lbnRvICglKVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJkZWNpbWFsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImJ1bGstYWRqdXN0LXBlcmNlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZXJjZW50SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UGVyY2VudElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiA1IG8gLTIsNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtIGRpc2FibGVkOm9wYWNpdHktNTBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktZW5kIGdhcC0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IHBlcmNlbnRJbnB1dC50cmltKCkgPT09ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIGhvdmVyOmJnLWluZGlnby03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gbXItMiBoLTQgdy00XCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFwbGljYW5kby4uLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnQXBsaWNhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufVxuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9hcnRpY3Vsb3MvY29tcG9uZW50cy9CdWxrQWRqdXN0U2FsZVByaWNlTW9kYWwudHN4In0=