import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
export const useDebounce = (value, delay = 300) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZURlYm91bmNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBjb25zdCB1c2VEZWJvdW5jZSA9IDxUPih2YWx1ZTogVCwgZGVsYXk6IG51bWJlciA9IDMwMCk6IFQgPT4ge1xuICAgIGNvbnN0IFtkZWJvdW5jZWRWYWx1ZSwgc2V0RGVib3VuY2VkVmFsdWVdID0gdXNlU3RhdGU8VD4odmFsdWUpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaGFuZGxlciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgc2V0RGVib3VuY2VkVmFsdWUodmFsdWUpO1xuICAgICAgICB9LCBkZWxheSk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcbiAgICAgICAgfTtcbiAgICB9LCBbdmFsdWUsIGRlbGF5XSk7XG5cbiAgICByZXR1cm4gZGVib3VuY2VkVmFsdWU7XG59O1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFVBQVUsaUJBQWlCO0FBRTdCLGFBQU0sY0FBYyxDQUFJLE9BQVUsUUFBZ0IsUUFBVztBQUNoRSxRQUFNLENBQUMsZ0JBQWdCLGlCQUFpQixJQUFJLFNBQVksS0FBSztBQUU3RCxZQUFVLE1BQU07QUFDWixVQUFNLFVBQVUsV0FBVyxNQUFNO0FBQzdCLHdCQUFrQixLQUFLO0FBQUEsSUFDM0IsR0FBRyxLQUFLO0FBRVIsV0FBTyxNQUFNO0FBQ1QsbUJBQWEsT0FBTztBQUFBLElBQ3hCO0FBQUEsRUFDSixHQUFHLENBQUMsT0FBTyxLQUFLLENBQUM7QUFFakIsU0FBTztBQUNYOyIsIm5hbWVzIjpbXX0=