import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/OrganizationLogo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/common/OrganizationLogo.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useOrganization } from "/src/hooks/useOrganization.ts";
import fallbackLogo from "/src/assets/header-logo.svg?import";
export const OrganizationLogo = ({
  className = "h-9",
  alt = "Logo"
}) => {
  _s();
  const { branding } = useOrganization();
  const [failed, setFailed] = useState(false);
  const remoteUrl = branding?.logo_url?.trim() || null;
  useEffect(() => {
    setFailed(false);
  }, [remoteUrl]);
  const src = !failed && remoteUrl ? remoteUrl : fallbackLogo;
  return /* @__PURE__ */ jsxDEV(
    "img",
    {
      src,
      alt,
      className,
      onError: () => {
        if (remoteUrl && !failed) {
          setFailed(true);
        }
      }
    },
    void 0,
    false,
    {
      fileName: "/app/src/components/common/OrganizationLogo.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
};
_s(OrganizationLogo, "Le9VfCtXN5tmEqMHiQxXlSFqEzg=", false, function() {
  return [useOrganization];
});
_c = OrganizationLogo;
var _c;
$RefreshReg$(_c, "OrganizationLogo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/common/OrganizationLogo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/common/OrganizationLogo.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsdUJBQXVCO0FBQ2hDLE9BQU9DLGtCQUFrQjtBQU9sQixhQUFNQyxtQkFBbUJBLENBQUM7QUFBQSxFQUM3QkMsWUFBWTtBQUFBLEVBQ1pDLE1BQU07QUFDYSxNQUFNO0FBQUFDLEtBQUE7QUFDekIsUUFBTSxFQUFFQyxTQUFTLElBQUlOLGdCQUFnQjtBQUNyQyxRQUFNLENBQUNPLFFBQVFDLFNBQVMsSUFBSVQsU0FBUyxLQUFLO0FBQzFDLFFBQU1VLFlBQVlILFVBQVVJLFVBQVVDLEtBQUssS0FBSztBQUVoRGIsWUFBVSxNQUFNO0FBQ1pVLGNBQVUsS0FBSztBQUFBLEVBQ25CLEdBQUcsQ0FBQ0MsU0FBUyxDQUFDO0FBRWQsUUFBTUcsTUFBTSxDQUFDTCxVQUFVRSxZQUFZQSxZQUFZUjtBQUUvQyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTLE1BQU07QUFDWCxZQUFJUSxhQUFhLENBQUNGLFFBQVE7QUFDdEJDLG9CQUFVLElBQUk7QUFBQSxRQUNsQjtBQUFBLE1BQ0o7QUFBQTtBQUFBLElBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUU07QUFHZDtBQUFFSCxHQTFCV0gsa0JBQWdCO0FBQUEsVUFJSkYsZUFBZTtBQUFBO0FBQUFhLEtBSjNCWDtBQUFnQixJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VPcmdhbml6YXRpb24iLCJmYWxsYmFja0xvZ28iLCJPcmdhbml6YXRpb25Mb2dvIiwiY2xhc3NOYW1lIiwiYWx0IiwiX3MiLCJicmFuZGluZyIsImZhaWxlZCIsInNldEZhaWxlZCIsInJlbW90ZVVybCIsImxvZ29fdXJsIiwidHJpbSIsInNyYyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk9yZ2FuaXphdGlvbkxvZ28udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VPcmdhbml6YXRpb24gfSBmcm9tICcuLi8uLi9ob29rcy91c2VPcmdhbml6YXRpb24nO1xuaW1wb3J0IGZhbGxiYWNrTG9nbyBmcm9tICcuLi8uLi9hc3NldHMvaGVhZGVyLWxvZ28uc3ZnJztcblxuaW50ZXJmYWNlIE9yZ2FuaXphdGlvbkxvZ29Qcm9wcyB7XG4gICAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICAgIGFsdD86IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IE9yZ2FuaXphdGlvbkxvZ28gPSAoe1xuICAgIGNsYXNzTmFtZSA9ICdoLTknLFxuICAgIGFsdCA9ICdMb2dvJyxcbn06IE9yZ2FuaXphdGlvbkxvZ29Qcm9wcykgPT4ge1xuICAgIGNvbnN0IHsgYnJhbmRpbmcgfSA9IHVzZU9yZ2FuaXphdGlvbigpO1xuICAgIGNvbnN0IFtmYWlsZWQsIHNldEZhaWxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgcmVtb3RlVXJsID0gYnJhbmRpbmc/LmxvZ29fdXJsPy50cmltKCkgfHwgbnVsbDtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldEZhaWxlZChmYWxzZSk7XG4gICAgfSwgW3JlbW90ZVVybF0pO1xuXG4gICAgY29uc3Qgc3JjID0gIWZhaWxlZCAmJiByZW1vdGVVcmwgPyByZW1vdGVVcmwgOiBmYWxsYmFja0xvZ287XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8aW1nXG4gICAgICAgICAgICBzcmM9e3NyY31cbiAgICAgICAgICAgIGFsdD17YWx0fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XG4gICAgICAgICAgICBvbkVycm9yPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlbW90ZVVybCAmJiAhZmFpbGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEZhaWxlZCh0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9jb21wb25lbnRzL2NvbW1vbi9Pcmdhbml6YXRpb25Mb2dvLnRzeCJ9