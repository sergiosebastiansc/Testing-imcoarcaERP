import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/remitos/pages/RemitosDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/remitos/pages/RemitosDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { remitosModuleConfig, formatRemitoOriginInvoice } from "/src/features/remitos/remitos.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoPencil, IoPrint } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { formatValue } from "/src/utils/formatters.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSpinner } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { getRequiredPermission, getModuleBasePermission } from "/src/utils/permissions.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const RemitosDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasModulePermission } = usePermissions();
  const { item: remito, loading, error } = useCrudItem(remitosModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const modulePermission = getRequiredPermission(remitosModuleConfig.baseRoute);
  const moduleBase = modulePermission ? getModuleBasePermission(modulePermission) : null;
  const canEdit = moduleBase ? hasModulePermission(moduleBase, "edit") : true;
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
    lineNumber: 48,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar el remito: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
    lineNumber: 49,
    columnNumber: 21
  }, this);
  if (!remito) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el remito." }, void 0, false, {
    fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
    lineNumber: 50,
    columnNumber: 23
  }, this);
  const getStatusText = (status) => {
    switch (status) {
      case "Draft":
        return "Borrador";
      case "Delivered":
        return "Entregado";
      case "Cancelled":
        return "Anulado";
      default:
        return "Desconocido";
    }
  };
  const getStatusClassName = (status) => {
    switch (status) {
      case "Draft":
        return "bg-yellow-100 text-yellow-800";
      case "Delivered":
        return "bg-green-100 text-green-800";
      case "Cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const labelStyle = "text-sm font-medium text-gray-600";
  const valueStyle = "mt-1 text-base text-gray-900";
  const handlePrint = async () => {
    if (!remito) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/remitos/${remito.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF del Remito.");
    } finally {
      setIsPrinting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(remitosModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 104,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 103,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "Remito: ",
            remito.remito_number
          ] }, void 0, true, {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 107,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClassName(remito.status)}`, children: getStatusText(remito.status) }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 110,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 106,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 102,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4 flex space-x-3", children: [
        canEdit && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate(`${remitosModuleConfig.baseRoute}/${id}/editar`),
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700",
            children: [
              /* @__PURE__ */ jsxDEV(IoPencil, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
                lineNumber: 122,
                columnNumber: 29
              }, this),
              "Editar"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 117,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: [
              isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 -ml-1 animate-spin" }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
                lineNumber: 133,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
                lineNumber: 135,
                columnNumber: 13
              }, this),
              "Imprimir"
            ]
          },
          void 0,
          true,
          {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 126,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 115,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
      lineNumber: 101,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 145,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle, children: /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/clientes/${remito.client?.id}`,
            className: "text-indigo-600 hover:text-indigo-800 hover:underline",
            children: remito.client?.name || "N/A"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 147,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 146,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 144,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Fecha Remito" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 156,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle, children: formatValue(remito.delivery_date, "date") }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 157,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 155,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Factura Origen" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 160,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle, children: remito.sales_invoice?.id || remito.invoice_number ? remito.sales_invoice?.id ? /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/facturas-de-venta/${remito.sales_invoice.id}`,
            className: "text-indigo-600 hover:text-indigo-800 hover:underline",
            children: formatRemitoOriginInvoice(remito)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 164,
            columnNumber: 13
          },
          this
        ) : formatRemitoOriginInvoice(remito) : "-" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 161,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 159,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Transporte" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 179,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle, children: remito.transport?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 180,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 178,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Dirección de Entrega" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 183,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle, children: remito.delivery_address || "-" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 184,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 182,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: labelStyle, children: "Observaciones" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 187,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: valueStyle + " whitespace-pre-wrap", children: remito.observations || "-" }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 188,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 186,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
      lineNumber: 143,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900 mt-6", children: "Productos Entregados" }, void 0, false, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 195,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 200,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant. Entregada" }, void 0, false, {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 201,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 199,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 198,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: remito.items.map(
          (item, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
                lineNumber: 208,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_sku,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
                lineNumber: 209,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
              lineNumber: 207,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-800 font-semibold", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
              lineNumber: 211,
              columnNumber: 37
            }, this)
          ] }, item.product_id || index, true, {
            fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
            lineNumber: 206,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
          lineNumber: 204,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 197,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
        lineNumber: 196,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
      lineNumber: 194,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/remitos/pages/RemitosDetailPage.tsx",
    lineNumber: 98,
    columnNumber: 5
  }, this);
};
_s(RemitosDetailPage, "ZOXLb0xZ73z3iY9iFrUIzei95hg=", false, function() {
  return [useParams, useNavigate, usePermissions, useCrudItem];
});
_c = RemitosDetailPage;
var _c;
$RefreshReg$(_c, "RemitosDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/remitos/pages/RemitosDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/remitos/pages/RemitosDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzQnhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxxQkFBcUJDLGlDQUE4QztBQUM1RSxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYUMsVUFBVUMsZUFBZTtBQUMvQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFDbEQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QkMsK0JBQStCO0FBQy9ELFNBQVNDLHlCQUF5QjtBQUUzQixhQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLEVBQUVDLEdBQUcsSUFBSXRCLFVBQTBCO0FBQ3pDLFFBQU11QixXQUFXdEIsWUFBWTtBQUM3QixRQUFNLEVBQUV1QixvQkFBb0IsSUFBSVIsZUFBZTtBQUMvQyxRQUFNLEVBQUVTLE1BQU1DLFFBQVFDLFNBQVNDLE1BQU0sSUFBSXhCLFlBQW9CQyxxQkFBcUJpQixFQUFFO0FBQ3BGLFFBQU0sQ0FBQ08sWUFBWUMsYUFBYSxJQUFJM0IsU0FBUyxLQUFLO0FBR2xELFFBQU00QixtQkFBbUJkLHNCQUFzQlosb0JBQW9CMkIsU0FBUztBQUM1RSxRQUFNQyxhQUFhRixtQkFBbUJiLHdCQUF3QmEsZ0JBQWdCLElBQUk7QUFDbEYsUUFBTUcsVUFBVUQsYUFBYVQsb0JBQW9CUyxZQUFZLE1BQU0sSUFBSTtBQUV2RSxNQUFJTixRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLElBQTRCQTtBQUFBQSxPQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBFO0FBQzVGLE1BQUksQ0FBQ0YsT0FBUSxRQUFPLHVCQUFDLFNBQUksV0FBVSw2QkFBNEIseUNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0U7QUFHeEYsUUFBTVMsZ0JBQWdCQSxDQUFDQyxXQUFtQjtBQUN0QyxZQUFRQSxRQUFNO0FBQUEsTUFDVixLQUFLO0FBQVMsZUFBTztBQUFBLE1BQ3JCLEtBQUs7QUFBYSxlQUFPO0FBQUEsTUFDekIsS0FBSztBQUFhLGVBQU87QUFBQSxNQUN6QjtBQUFTLGVBQU87QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFDQSxRQUFNQyxxQkFBcUJBLENBQUNELFdBQW1CO0FBQzNDLFlBQVFBLFFBQU07QUFBQSxNQUNWLEtBQUs7QUFBUyxlQUFPO0FBQUEsTUFDckIsS0FBSztBQUFhLGVBQU87QUFBQSxNQUN6QixLQUFLO0FBQWEsZUFBTztBQUFBLE1BQ3pCO0FBQVMsZUFBTztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUdBLFFBQU1FLGFBQWE7QUFDbkIsUUFBTUMsYUFBYTtBQUduQixRQUFNQyxjQUFjLFlBQVk7QUFDNUIsUUFBSSxDQUFDZCxPQUFRO0FBRWIsVUFBTWUsVUFBVTdCLGdCQUFnQjtBQUNoQyxRQUFJLENBQUM2QixTQUFTO0FBQ1YzQixZQUFNYyxNQUFNLDhDQUE4QztBQUMxRDtBQUFBLElBQ0o7QUFFQUUsa0JBQWMsSUFBSTtBQUNsQixRQUFJO0FBQ0EsWUFBTWpCLGlCQUFpQjRCLFNBQVMsWUFBWWYsT0FBT0osRUFBRSxNQUFNO0FBQUEsSUFDL0QsU0FBU00sUUFBTztBQUNaLFVBQUksQ0FBQ2EsUUFBUUMsT0FBT0MsT0FBUUYsU0FBUUMsT0FBT0UsTUFBTTtBQUNqREMsY0FBUWpCLE1BQU0sNEJBQTRCQSxNQUFLO0FBQy9DZCxZQUFNYyxNQUFNLG1EQUFtRDtBQUFBLElBQ25FLFVBQUM7QUFDR0Usb0JBQWMsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUdBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHNEQUdYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlFQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtCQUNYO0FBQUEsK0JBQUMsWUFBTyxTQUFTLE1BQU1QLFNBQVNKLGtCQUFrQmQsb0JBQW9CMkIsU0FBUyxDQUFDLEdBQUcsV0FBVSxvREFDekYsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlEQUErQztBQUFBO0FBQUEsWUFDaEROLE9BQU9vQjtBQUFBQSxlQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVcsdURBQXVEVCxtQkFBbUJYLE9BQU9VLE1BQU0sQ0FBQyxJQUNwR0Qsd0JBQWNULE9BQU9VLE1BQU0sS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDVkY7QUFBQUEsbUJBQ0c7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTVgsU0FBUyxHQUFHbEIsb0JBQW9CMkIsU0FBUyxJQUFJVixFQUFFLFNBQVM7QUFBQSxZQUN2RSxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFlBQVMsV0FBVSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUw1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBRUo7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNrQjtBQUFBQSxZQUNULFVBQVVYO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBO0FBQUFBLDJCQUNHLHVCQUFDLGFBQVUsV0FBVSxxQ0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0QsSUFFdEQsdUJBQUMsV0FBUSxXQUFVLHdCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQzFDO0FBQUE7QUFBQTtBQUFBLFVBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxXQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0F0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLElBR0EsdUJBQUMsUUFBRyxXQUFVLGtFQUNWO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXUyxZQUFZLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsUUFBRyxXQUFXQyxZQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFJLGFBQWFiLE9BQU9xQixRQUFRekIsRUFBRTtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVUSSxpQkFBT3FCLFFBQVFDLFFBQVE7QUFBQTtBQUFBLFVBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV1YsWUFBWSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBV0MsWUFBYTVCLHNCQUFZZSxPQUFPdUIsZUFBZSxNQUFNLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxXQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV1gsWUFBWSw4QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQ3pDLHVCQUFDLFFBQUcsV0FBV0MsWUFDVmIsaUJBQU93QixlQUFlNUIsTUFBTUksT0FBT3lCLGlCQUNoQ3pCLE9BQU93QixlQUFlNUIsS0FDbEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLElBQUksc0JBQXNCSSxPQUFPd0IsY0FBYzVCLEVBQUU7QUFBQSxZQUNqRCxXQUFVO0FBQUEsWUFFVGhCLG9DQUEwQm9CLE1BQU07QUFBQTtBQUFBLFVBSnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLElBRUFwQiwwQkFBMEJvQixNQUFNLElBR3BDLE9BYlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXWSxZQUFZLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsUUFBRyxXQUFXQyxZQUFhYixpQkFBTzBCLFdBQVdKLFFBQVEsT0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFdBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXVixZQUFZLG9DQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsUUFBRyxXQUFXQyxZQUFhYixpQkFBTzJCLG9CQUFvQixPQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsV0FGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdmLFlBQVksNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxRQUFHLFdBQVdDLGFBQWEsd0JBQXlCYixpQkFBTzRCLGdCQUFnQixPQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsV0FGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0E5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStDQTtBQUFBLElBSUEsdUJBQUMsU0FDRztBQUFBLDZCQUFDLFFBQUcsV0FBVSxvREFBbUQsb0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNyRix1QkFBQyxTQUFJLFdBQVUsMkVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSwwRUFBeUUsd0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCwrQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxhQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWjVCLGlCQUFPNkIsTUFBTUM7QUFBQUEsVUFBSSxDQUFDL0IsTUFBTWdDLFVBQ3JCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsa0NBQ1Y7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQTZCaEMsZUFBS2lDLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RDtBQUFBLGNBQzlELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLGdCQUFFakMsS0FBS2tDO0FBQUFBLGdCQUFZO0FBQUEsbUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSw0REFDVEMsaUJBQU9uQyxLQUFLb0MsUUFBUSxFQUFFQyxRQUFRLENBQUMsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEtyQyxLQUFLc0MsY0FBY04sT0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBQ0gsS0FYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBLEtBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxTQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsT0F6SEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBIQTtBQUVSO0FBQUVwQyxHQTFMV0QsbUJBQWlCO0FBQUEsVUFDWHBCLFdBQ0VDLGFBQ2VlLGdCQUNTWixXQUFXO0FBQUE7QUFBQTRELEtBSjNDNUM7QUFBaUIsSUFBQTRDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VTdGF0ZSIsInVzZUNydWRJdGVtIiwicmVtaXRvc01vZHVsZUNvbmZpZyIsImZvcm1hdFJlbWl0b09yaWdpbkludm9pY2UiLCJMb2FkaW5nU3Bpbm5lciIsIklvQXJyb3dCYWNrIiwiSW9QZW5jaWwiLCJJb1ByaW50IiwiZm9ybWF0VmFsdWUiLCJiZWdpblBkZlByZXZpZXciLCJmaW5pc2hQZGZQcmV2aWV3IiwidG9hc3QiLCJGYVNwaW5uZXIiLCJ1c2VQZXJtaXNzaW9ucyIsImdldFJlcXVpcmVkUGVybWlzc2lvbiIsImdldE1vZHVsZUJhc2VQZXJtaXNzaW9uIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJSZW1pdG9zRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsImhhc01vZHVsZVBlcm1pc3Npb24iLCJpdGVtIiwicmVtaXRvIiwibG9hZGluZyIsImVycm9yIiwiaXNQcmludGluZyIsInNldElzUHJpbnRpbmciLCJtb2R1bGVQZXJtaXNzaW9uIiwiYmFzZVJvdXRlIiwibW9kdWxlQmFzZSIsImNhbkVkaXQiLCJnZXRTdGF0dXNUZXh0Iiwic3RhdHVzIiwiZ2V0U3RhdHVzQ2xhc3NOYW1lIiwibGFiZWxTdHlsZSIsInZhbHVlU3R5bGUiLCJoYW5kbGVQcmludCIsInNlc3Npb24iLCJ3aW5kb3ciLCJjbG9zZWQiLCJjbG9zZSIsImNvbnNvbGUiLCJyZW1pdG9fbnVtYmVyIiwiY2xpZW50IiwibmFtZSIsImRlbGl2ZXJ5X2RhdGUiLCJzYWxlc19pbnZvaWNlIiwiaW52b2ljZV9udW1iZXIiLCJ0cmFuc3BvcnQiLCJkZWxpdmVyeV9hZGRyZXNzIiwib2JzZXJ2YXRpb25zIiwiaXRlbXMiLCJtYXAiLCJpbmRleCIsInByb2R1Y3RfbmFtZSIsInByb2R1Y3Rfc2t1IiwiTnVtYmVyIiwicXVhbnRpdHkiLCJ0b0ZpeGVkIiwicHJvZHVjdF9pZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlbWl0b3NEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUNydWRJdGVtIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZEl0ZW0nO1xuLy8gVXNhbW9zIGNvbmZpZyB5IHRpcG8gZGUgUmVtaXRvXG5pbXBvcnQgeyByZW1pdG9zTW9kdWxlQ29uZmlnLCBmb3JtYXRSZW1pdG9PcmlnaW5JbnZvaWNlLCB0eXBlIFJlbWl0byB9IGZyb20gJy4uL3JlbWl0b3MuY29uZmlnJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9QZW5jaWwsIElvUHJpbnQgfSBmcm9tICdyZWFjdC1pY29ucy9pbzUnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IGJlZ2luUGRmUHJldmlldywgZmluaXNoUGRmUHJldmlldyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBGYVNwaW5uZXIgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VQZXJtaXNzaW9ucyB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVBlcm1pc3Npb25zJztcbmltcG9ydCB7IGdldFJlcXVpcmVkUGVybWlzc2lvbiwgZ2V0TW9kdWxlQmFzZVBlcm1pc3Npb24gfSBmcm9tICcuLi8uLi8uLi91dGlscy9wZXJtaXNzaW9ucyc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IFJlbWl0b3NEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgeyBoYXNNb2R1bGVQZXJtaXNzaW9uIH0gPSB1c2VQZXJtaXNzaW9ucygpO1xuICAgIGNvbnN0IHsgaXRlbTogcmVtaXRvLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08UmVtaXRvPihyZW1pdG9zTW9kdWxlQ29uZmlnLCBpZCk7XG4gICAgY29uc3QgW2lzUHJpbnRpbmcsIHNldElzUHJpbnRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgLy8g4pyFIFZhbGlkYXIgcGVybWlzb3MgcGFyYSBlZGl0YXJcbiAgICBjb25zdCBtb2R1bGVQZXJtaXNzaW9uID0gZ2V0UmVxdWlyZWRQZXJtaXNzaW9uKHJlbWl0b3NNb2R1bGVDb25maWcuYmFzZVJvdXRlKTtcbiAgICBjb25zdCBtb2R1bGVCYXNlID0gbW9kdWxlUGVybWlzc2lvbiA/IGdldE1vZHVsZUJhc2VQZXJtaXNzaW9uKG1vZHVsZVBlcm1pc3Npb24pIDogbnVsbDtcbiAgICBjb25zdCBjYW5FZGl0ID0gbW9kdWxlQmFzZSA/IGhhc01vZHVsZVBlcm1pc3Npb24obW9kdWxlQmFzZSwgJ2VkaXQnKSA6IHRydWU7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPkVycm9yIGFsIGNhcmdhciBlbCByZW1pdG86IHtlcnJvciBhcyBzdHJpbmd9PC9kaXY+O1xuICAgIGlmICghcmVtaXRvKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+Tm8gc2UgZW5jb250csOzIGVsIHJlbWl0by48L2Rpdj47XG5cbiAgICAvLyAtLS0gTMOTR0lDQSBERSBFU1RBRE8gLS0tXG4gICAgY29uc3QgZ2V0U3RhdHVzVGV4dCA9IChzdGF0dXM6IHN0cmluZykgPT4ge1xuICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICAgICAgY2FzZSAnRHJhZnQnOiByZXR1cm4gJ0JvcnJhZG9yJztcbiAgICAgICAgICAgIGNhc2UgJ0RlbGl2ZXJlZCc6IHJldHVybiAnRW50cmVnYWRvJztcbiAgICAgICAgICAgIGNhc2UgJ0NhbmNlbGxlZCc6IHJldHVybiAnQW51bGFkbyc7XG4gICAgICAgICAgICBkZWZhdWx0OiByZXR1cm4gJ0Rlc2Nvbm9jaWRvJztcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgZ2V0U3RhdHVzQ2xhc3NOYW1lID0gKHN0YXR1czogc3RyaW5nKSA9PiB7XG4gICAgICAgIHN3aXRjaCAoc3RhdHVzKSB7XG4gICAgICAgICAgICBjYXNlICdEcmFmdCc6IHJldHVybiAnYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDAnO1xuICAgICAgICAgICAgY2FzZSAnRGVsaXZlcmVkJzogcmV0dXJuICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnO1xuICAgICAgICAgICAgY2FzZSAnQ2FuY2VsbGVkJzogcmV0dXJuICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCc7XG4gICAgICAgICAgICBkZWZhdWx0OiByZXR1cm4gJ2JnLWdyYXktMTAwIHRleHQtZ3JheS04MDAnO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyAtLS0gRklOIEzDk0dJQ0EgREUgRVNUQURPIC0tLVxuXG4gICAgY29uc3QgbGFiZWxTdHlsZSA9IFwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI7XG4gICAgY29uc3QgdmFsdWVTdHlsZSA9IFwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiO1xuXG5cbiAgICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFyZW1pdG8pIHJldHVybjtcblxuICAgICAgICBjb25zdCBzZXNzaW9uID0gYmVnaW5QZGZQcmV2aWV3KCk7XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1Blcm1pdMOtIHZlbnRhbmFzIGVtZXJnZW50ZXMgcGFyYSB2ZXIgZWwgUERGLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNQcmludGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9yZW1pdG9zLyR7cmVtaXRvLmlkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGdlbmVyYXIgZWwgUERGOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBnZW5lcmFyIGVsIGNvbXByb2JhbnRlIFBERiBkZWwgUmVtaXRvLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0SXNQcmludGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS04XCI+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gRU5DQUJFWkFETyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTQgbWItNCBib3JkZXItYiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKHJlbWl0b3NNb2R1bGVDb25maWcuYmFzZVJvdXRlKSl9IGNsYXNzTmFtZT1cInAtMiB0ZXh0LWdyYXktNTAwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElvQXJyb3dCYWNrIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbGVhZGluZy02IHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW1pdG86IHtyZW1pdG8ucmVtaXRvX251bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BtdC0xIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtnZXRTdGF0dXNDbGFzc05hbWUocmVtaXRvLnN0YXR1cyl9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c1RleHQocmVtaXRvLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzbTptdC0wIHNtOm1sLTQgZmxleCBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgICAge2NhbkVkaXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAke3JlbWl0b3NNb2R1bGVDb25maWcuYmFzZVJvdXRlfS8ke2lkfS9lZGl0YXJgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctaW5kaWdvLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVuY2lsIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdGFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1ByaW50aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQcmludGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctNSBoLTUgbXItMiAtbWwtMSBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9QcmludCBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgLW1sLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIEltcHJpbWlyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gREVUQUxMRVMgREUgQ0FCRUNFUkEgLS0tICovfVxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLXgtNCBnYXAteS02IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e2xhYmVsU3R5bGV9PkNsaWVudGU8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPXt2YWx1ZVN0eWxlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvY2xpZW50ZXMvJHtyZW1pdG8uY2xpZW50Py5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtaXRvLmNsaWVudD8ubmFtZSB8fCAnTi9BJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17bGFiZWxTdHlsZX0+RmVjaGEgUmVtaXRvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT17dmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKHJlbWl0by5kZWxpdmVyeV9kYXRlLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e2xhYmVsU3R5bGV9PkZhY3R1cmEgT3JpZ2VuPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT17dmFsdWVTdHlsZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVtaXRvLnNhbGVzX2ludm9pY2U/LmlkIHx8IHJlbWl0by5pbnZvaWNlX251bWJlciA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1pdG8uc2FsZXNfaW52b2ljZT8uaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YC9mYWN0dXJhcy1kZS12ZW50YS8ke3JlbWl0by5zYWxlc19pbnZvaWNlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRSZW1pdG9PcmlnaW5JbnZvaWNlKHJlbWl0byl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXRSZW1pdG9PcmlnaW5JbnZvaWNlKHJlbWl0bylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICctJ1xuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17bGFiZWxTdHlsZX0+VHJhbnNwb3J0ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9e3ZhbHVlU3R5bGV9PntyZW1pdG8udHJhbnNwb3J0Py5uYW1lIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXtsYWJlbFN0eWxlfT5EaXJlY2Npw7NuIGRlIEVudHJlZ2E8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPXt2YWx1ZVN0eWxlfT57cmVtaXRvLmRlbGl2ZXJ5X2FkZHJlc3MgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e2xhYmVsU3R5bGV9Pk9ic2VydmFjaW9uZXM8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPXt2YWx1ZVN0eWxlICsgXCIgd2hpdGVzcGFjZS1wcmUtd3JhcFwifT57cmVtaXRvLm9ic2VydmF0aW9ucyB8fCAnLSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGw+XG5cblxuICAgICAgICAgICAgey8qIC0tLSBUYWJsYSBJdGVtcyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwIG10LTZcIj5Qcm9kdWN0b3MgRW50cmVnYWRvczwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNlwiPkFydMOtY3VsbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q2FudC4gRW50cmVnYWRhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtaXRvLml0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbS5wcm9kdWN0X2lkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTQgcHItMyB0ZXh0LXNtIHNtOnBsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+KHtpdGVtLnByb2R1Y3Rfc2t1fSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKGl0ZW0ucXVhbnRpdHkpLnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL3JlbWl0b3MvcGFnZXMvUmVtaXRvc0RldGFpbFBhZ2UudHN4In0=