import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cobranzas/pages/CobranzasFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cobranzas/pages/CobranzasFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaPlus, FaTrash, FaFillDrip } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, getAll, search, searchByField } from "/src/services/apiService.ts";
import {
  cobranzasModuleConfig
} from "/src/features/cobranzas/cobranzas.config.tsx";
import {
  buildAppliedCreditNotesForSave,
  buildAppliedInvoicesForSave,
  buildAppliedSalesFinancialNotesForSave,
  computeCollectionGrossAmount,
  isAdjustmentOnlyCollection,
  sumAppliedAmountsRecord
} from "/src/features/cobranzas/buildAppliedCollectionPayload.ts";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import {} from "/src/features/facturas_venta/facturas_venta.config.tsx";
import {} from "/src/features/notas_credito/notas_credito.config.tsx";
import {} from "/src/features/notas_financieras/notas_financieras.config.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import {
  PendingSignedDocumentsTable
} from "/src/components/common/PendingSignedDocumentsTable.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { formatValue, formatDateForInput } from "/src/utils/formatters.ts";
import { useModal } from "/src/context/ModalContext.tsx";
import { bancosModuleConfig } from "/src/features/bancos/bancos.config.tsx";
import { applyMask, validateMask, getMask } from "/src/utils/masks.ts";
import { taxesModuleConfig } from "/src/features/impuestos/impuestos.config.tsx";
import {
  clampAppliedToSignedBalance,
  signedCreditNoteBalance,
  signedCreditNoteTotal,
  signedTypedBalance,
  signedTypedTotal
} from "/src/utils/appliedSignedDocuments.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const CobranzasFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const {
    item: originalData,
    loading: loadingData,
    error,
    saveItem
  } = useCrudItem(cobranzasModuleConfig, id);
  const { showConfirmationModal } = useModal();
  const [header, setHeader] = useState({
    collection_date: formatDateForInput(/* @__PURE__ */ new Date()),
    discount_amount: 0
  });
  const [clientCodeInput, setClientCodeInput] = useState("");
  const [paymentItems, setPaymentItems] = useState([]);
  const [clientTaxes, setClientTaxes] = useState([]);
  const [clientAdvanceBalance, setClientAdvanceBalance] = useState(0);
  const [outstandingInvoices, setOutstandingInvoices] = useState([]);
  const [pendingCreditNotes, setPendingCreditNotes] = useState([]);
  const [pendingFinancialNotes, setPendingFinancialNotes] = useState([]);
  const [loadingClientDocuments, setLoadingClientDocuments] = useState(false);
  const [appliedAmounts, setAppliedAmounts] = useState({});
  const [appliedCreditNoteAmounts, setAppliedCreditNoteAmounts] = useState({});
  const [appliedFinancialNoteAmounts, setAppliedFinancialNoteAmounts] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [modalConfig, setModalConfig] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [retentionTaxes, setRetentionTaxes] = useState([]);
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await getAll(taxesModuleConfig.endpoint, { type: 3, per_page: 500 });
        if (!cancelled) setRetentionTaxes(res.data ?? []);
      } catch (e) {
        console.error(e);
        if (!cancelled) toast.error("No se pudieron cargar los impuestos de retención.");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  useEffect(() => {
    if (originalData && mode === "edit") {
      setHeader({
        ...originalData,
        collection_date: formatDateForInput(new Date(originalData.collection_date)),
        discount_amount: Number(originalData.discount_amount) || 0
        // Poblar descuento
      });
      if (originalData.client) {
        setClientCodeInput(originalData.client.cuit || String(originalData.client.id));
      }
      const formattedItems = originalData.items.map((item) => ({
        ...item,
        tempId: `item-${item.id}`,
        value: Number(item.value) || 0,
        check_due_date: item.check_due_date ?? null,
        check_holder: item.check_holder ?? null,
        issuer_cuit: item.issuer_cuit ?? null,
        is_to_order: Boolean(item.is_to_order),
        reference_number: item.reference_number ?? null,
        is_third_party_check: Boolean(item.issuer_cuit?.trim()),
        ui_account_code: item.chart_account?.code || "",
        ui_bank_code: item.bank_id ? String(item.bank_id) : ""
      }));
      setPaymentItems(formattedItems);
      const applied = (originalData.applied_invoices ?? []).reduce((acc, app) => {
        acc[app.sales_invoice.id] = Number(app.amount_applied) || 0;
        return acc;
      }, {});
      setAppliedAmounts(applied);
      if (originalData.applied_credit_notes) {
        const creditApplied = originalData.applied_credit_notes.reduce((acc, app) => {
          acc[app.credit_note.id] = Number(app.amount_applied) || 0;
          return acc;
        }, {});
        setAppliedCreditNoteAmounts(creditApplied);
      }
      if (originalData.applied_financial_notes) {
        const financialApplied = originalData.applied_financial_notes.reduce((acc, app) => {
          acc[app.financial_note.id] = Number(app.amount_applied) || 0;
          return acc;
        }, {});
        setAppliedFinancialNoteAmounts(financialApplied);
      }
      const loadEditData = async (clientId) => {
        setLoadingClientDocuments(true);
        try {
          const fullClient = await getById(clientesModuleConfig.endpoint, clientId);
          setClientTaxes(fullClient.taxes || []);
          setClientAdvanceBalance((Number(fullClient.advance_balance) || 0) * -1);
          const params = new URLSearchParams({
            client_id: clientId.toString(),
            has_balance: "true"
          });
          const appliedCreditIds = originalData.applied_credit_notes?.map((an) => an.credit_note.id) || [];
          const appliedFinancialIds = originalData.applied_financial_notes?.map((an) => an.financial_note.id) || [];
          const appliedCreditPromises = appliedCreditIds.map((noteId) => getById("credit-notes", noteId));
          const appliedFinancialPromises = appliedFinancialIds.map(
            (noteId) => getById("financial-notes", noteId)
          );
          const [invoicesResponse, creditNotesResponse, financialNotesResponse, ...fetchedApplied] = await Promise.all(
            [
              search(`sales-invoices?${params.toString()}`),
              search(`credit-notes?${params.toString()}`),
              search(`financial-notes?${params.toString()}`),
              ...appliedCreditPromises,
              ...appliedFinancialPromises
            ]
          );
          const fetchedAppliedCreditNotes = fetchedApplied.slice(0, appliedCreditPromises.length);
          const fetchedAppliedFinancialNotes = fetchedApplied.slice(appliedCreditPromises.length);
          const allInvoicesMap = new Map(
            invoicesResponse.data.map((inv) => [inv.id, inv])
          );
          (originalData.applied_invoices ?? []).forEach((app) => {
            const appliedInvoice = app.sales_invoice;
            const originalBalance = (Number(appliedInvoice.balance) || 0) + (Number(app.amount_applied) || 0);
            allInvoicesMap.set(appliedInvoice.id, {
              ...appliedInvoice,
              balance: originalBalance
            });
          });
          setOutstandingInvoices(Array.from(allInvoicesMap.values()));
          const allCreditNotesMap = /* @__PURE__ */ new Map();
          fetchedAppliedCreditNotes.forEach((n) => {
            if (n) allCreditNotesMap.set(n.id, n);
          });
          creditNotesResponse.data.forEach((n) => {
            if (!allCreditNotesMap.has(n.id)) allCreditNotesMap.set(n.id, n);
          });
          const finalCreditNotes = Array.from(allCreditNotesMap.values()).map((n) => {
            const appliedDetail = originalData.applied_credit_notes?.find((an) => an.credit_note.id === n.id);
            if (appliedDetail) {
              const currentBalance = signedCreditNoteBalance(n.balance);
              return { ...n, balance: currentBalance + (Number(appliedDetail.amount_applied) || 0) };
            }
            return n;
          });
          setPendingCreditNotes(finalCreditNotes);
          const allFinancialNotesMap = /* @__PURE__ */ new Map();
          fetchedAppliedFinancialNotes.forEach((n) => {
            if (n) allFinancialNotesMap.set(n.id, n);
          });
          financialNotesResponse.data.forEach((n) => {
            if (!allFinancialNotesMap.has(n.id)) allFinancialNotesMap.set(n.id, n);
          });
          const finalFinancialNotes = Array.from(allFinancialNotesMap.values()).map((n) => {
            const appliedDetail = originalData.applied_financial_notes?.find((an) => an.financial_note.id === n.id);
            if (appliedDetail) {
              const currentBalance = signedTypedBalance(n.type, n.balance);
              return { ...n, balance: currentBalance + (Number(appliedDetail.amount_applied) || 0) };
            }
            return n;
          });
          setPendingFinancialNotes(finalFinancialNotes);
        } catch (err) {
          console.error("Error al cargar datos de edición:", err);
          toast.error("Error al cargar datos relacionados para la edición.");
        } finally {
          setLoadingClientDocuments(false);
        }
      };
      loadEditData(originalData.client_id);
    }
  }, [originalData, mode]);
  const applyClientSelection = async (selectedClient) => {
    setHeader((prev) => ({ ...prev, client_id: selectedClient.id, client: selectedClient }));
    setClientCodeInput(selectedClient.customer_code || String(selectedClient.id));
    setOutstandingInvoices([]);
    setPendingCreditNotes([]);
    setPendingFinancialNotes([]);
    setAppliedAmounts({});
    setAppliedCreditNoteAmounts({});
    setAppliedFinancialNoteAmounts({});
    setClientTaxes([]);
    setClientAdvanceBalance(0);
    setLoadingClientDocuments(true);
    try {
      const fullClient = await getById(clientesModuleConfig.endpoint, selectedClient.id);
      if (fullClient.taxes) {
        setClientTaxes(fullClient.taxes);
      }
      setClientAdvanceBalance((Number(fullClient.advance_balance) || 0) * -1);
      const params = new URLSearchParams({
        client_id: selectedClient.id.toString(),
        has_balance: "true"
      });
      const [invoicesResponse, creditNotesResponse, financialNotesResponse] = await Promise.all(
        [
          search(`sales-invoices?${params.toString()}`),
          search(`credit-notes?${params.toString()}`),
          search(`financial-notes?${params.toString()}`)
        ]
      );
      setOutstandingInvoices(invoicesResponse.data);
      setPendingCreditNotes(creditNotesResponse.data);
      setPendingFinancialNotes(financialNotesResponse.data);
    } catch (err) {
      console.error("Error al cargar datos del cliente:", err);
      toast.error("Error al cargar datos del cliente o sus documentos pendientes.");
    } finally {
      setLoadingClientDocuments(false);
    }
  };
  const handleClientCodeSubmit = async () => {
    if (!clientCodeInput.trim()) return;
    if (header.client && (header.client.cuit === clientCodeInput || String(header.client.id) === clientCodeInput)) {
      return;
    }
    try {
      const foundItem = await searchByField(
        clientesModuleConfig.endpoint,
        [{ fieldName: "customer_code", value: clientCodeInput }]
      );
      if (foundItem) {
        applyClientSelection(foundItem);
        toast.success(`Cliente encontrado: ${foundItem.name}`);
      } else {
        toast.warning("Cliente no encontrado con ese código.");
        setHeader((prev) => ({ ...prev, client_id: void 0, client: void 0 }));
        setOutstandingInvoices([]);
        setPendingCreditNotes([]);
        setPendingFinancialNotes([]);
        setAppliedAmounts({});
        setAppliedCreditNoteAmounts({});
        setAppliedFinancialNoteAmounts({});
        setClientTaxes([]);
        setClientAdvanceBalance(0);
      }
    } catch (error2) {
      console.error(error2);
      toast.error("Error al buscar cliente.");
    }
  };
  const openModal = (target, config) => {
    setEditingTarget(target);
    setModalConfig(config);
    setIsModalOpen(true);
  };
  const handleSelectModal = (selectedItem) => {
    if (!editingTarget) return;
    if (editingTarget === "client") {
      applyClientSelection(selectedItem);
    } else if (typeof editingTarget === "object" && editingTarget.type === "itemAccount") {
      handleItemChange(editingTarget.index, "chart_account", selectedItem);
      handleItemChange(editingTarget.index, "ui_account_code", selectedItem.code);
    } else if (typeof editingTarget === "object" && editingTarget.type === "itemBank") {
      handleItemChange(editingTarget.index, "bank_id", selectedItem.id);
      handleItemChange(editingTarget.index, "bank_name", selectedItem.name);
      handleItemChange(editingTarget.index, "ui_bank_code", String(selectedItem.id));
    }
    setIsModalOpen(false);
    setEditingTarget(null);
  };
  const handleItemChange = (index, field, value) => {
    setPaymentItems((prev) => {
      const sumOtherSal = prev.filter((it, i) => i !== index && it.payment_method_code === "SAL").reduce((s, it) => s + (Number(it.value) || 0), 0);
      const maxAdvanceForItem = Math.max(0, (clientAdvanceBalance || 0) - sumOtherSal);
      return prev.map((item, i) => {
        if (i !== index) return item;
        const updatedItem = { ...item, [field]: value };
        if (field === "payment_method_code") {
          updatedItem.bank_id = null;
          updatedItem.bank_name = null;
          updatedItem.check_number = null;
          updatedItem.check_date = null;
          updatedItem.ui_bank_code = "";
          if (value !== "CHE") {
            updatedItem.check_due_date = null;
            updatedItem.check_holder = null;
            updatedItem.issuer_cuit = null;
            updatedItem.reference_number = null;
            updatedItem.is_third_party_check = false;
          }
          if (value === "SAL") {
            const grossAmount = computeCollectionGrossAmount(
              appliedAmounts,
              appliedCreditNoteAmounts,
              appliedFinancialNoteAmounts
            );
            const discount = Number(header.discount_amount) || 0;
            const totalTaxes = (clientTaxes || []).reduce((sum, tax) => sum + discount * ((tax.rate || 0) / 100), 0);
            const netAmountToPay = grossAmount - discount - totalTaxes;
            updatedItem.value = Math.max(0, Math.min(netAmountToPay, maxAdvanceForItem));
          }
        }
        if (field === "value" && item.payment_method_code === "SAL") {
          const numVal = Number(value) || 0;
          if (numVal > maxAdvanceForItem) {
            toast.warn(`El monto no puede superar el saldo anticipado disponible (${formatValue(maxAdvanceForItem, "currency")}).`);
            updatedItem.value = maxAdvanceForItem;
          }
        }
        return updatedItem;
      });
    });
  };
  const handleItemCodeSubmit = async (index, type) => {
    const item = paymentItems[index];
    const codeToSearch = type === "account" ? item.ui_account_code : item.ui_bank_code;
    if (!codeToSearch) return;
    try {
      if (type === "account") {
        const found = await searchByField(
          planDeCuentasModuleConfig.endpoint,
          [{ fieldName: "code", value: codeToSearch }]
        );
        if (found) {
          handleItemChange(index, "chart_account", found);
          handleItemChange(index, "ui_account_code", found.code);
        } else {
          toast.warn("Cuenta contable no encontrada");
          handleItemChange(index, "chart_account", null);
        }
      } else if (type === "bank") {
        const found = await searchByField(
          bancosModuleConfig.endpoint,
          // ⚠️ OJO: Si tus usuarios escriben el ID en vez del código, cambia 'code' por 'id'
          [{ fieldName: "code", value: codeToSearch }]
        );
        if (found) {
          handleItemChange(index, "bank_id", found.id);
          handleItemChange(index, "bank_name", found.name);
          handleItemChange(index, "ui_bank_code", found.code || String(found.id));
        } else {
          toast.warn("Banco no encontrado");
          handleItemChange(index, "bank_id", null);
          handleItemChange(index, "bank_name", null);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };
  const addNewItem = () => {
    setPaymentItems(
      (prev) => [
        ...prev,
        {
          tempId: `new-${Date.now()}`,
          payment_method_code: "EFE",
          bank_id: null,
          bank_name: null,
          check_number: null,
          check_date: null,
          check_due_date: null,
          check_holder: null,
          issuer_cuit: null,
          is_to_order: false,
          reference_number: null,
          is_third_party_check: false,
          value: 0,
          check_key: null,
          chart_account: null,
          ui_account_code: "",
          ui_bank_code: ""
        }
      ]
    );
  };
  const removeItem = (index) => {
    setPaymentItems((prev) => prev.filter((_, i) => i !== index));
  };
  const handleApplyAmount = (invoiceId, amount) => {
    const numericAmount = Number(amount) || 0;
    setAppliedAmounts((prev) => ({
      ...prev,
      [invoiceId]: numericAmount
    }));
  };
  const handleSignedDocumentAmountChange = (noteId, balance, value, setter) => {
    const clamped = clampAppliedToSignedBalance(value, balance);
    const numericValue = Number(value) || 0;
    if (clamped !== numericValue) {
      toast.warn(`El monto no puede superar el saldo (${formatValue(balance, "currency")})`);
    }
    setter((prev) => ({ ...prev, [noteId]: clamped }));
  };
  const handleCreditNoteAmountChange = (noteId, value) => {
    const note = pendingCreditNotes.find((n) => n.id === noteId);
    if (!note) return;
    handleSignedDocumentAmountChange(
      noteId,
      signedCreditNoteBalance(note.balance),
      value,
      setAppliedCreditNoteAmounts
    );
  };
  const handleFinancialNoteAmountChange = (noteId, value) => {
    const note = pendingFinancialNotes.find((n) => n.id === noteId);
    if (!note) return;
    handleSignedDocumentAmountChange(
      noteId,
      signedTypedBalance(note.type, note.balance),
      value,
      setAppliedFinancialNoteAmounts
    );
  };
  const creditNoteRows = useMemo(() => {
    return pendingCreditNotes.map((note) => {
      const balance = signedCreditNoteBalance(note.balance);
      const total = signedCreditNoteTotal(note.total_amount);
      const docNumber = note.sales_invoice?.invoice_number || note.voucher_number || "-";
      return {
        id: note.id,
        docLabel: docNumber,
        balance,
        date: formatValue(note.issue_date, "date"),
        docNumber,
        total,
        balanceDisplay: balance
      };
    });
  }, [pendingCreditNotes]);
  const financialNoteRows = useMemo(() => {
    return pendingFinancialNotes.map((note) => {
      const balance = signedTypedBalance(note.type, note.balance);
      const total = signedTypedTotal(note.type, note.total_amount);
      const docNumber = note.sales_invoice?.invoice_number || note.voucher_number || "-";
      return {
        id: note.id,
        docLabel: docNumber,
        balance,
        date: formatValue(note.issue_date, "date"),
        docNumber,
        total,
        balanceDisplay: balance,
        type: note.type
      };
    });
  }, [pendingFinancialNotes]);
  const totals = useMemo(() => {
    const invoicesGrossAmount = sumAppliedAmountsRecord(appliedAmounts);
    const creditNotesGrossAmount = sumAppliedAmountsRecord(appliedCreditNoteAmounts);
    const financialNotesGrossAmount = sumAppliedAmountsRecord(appliedFinancialNoteAmounts);
    const grossAmount = computeCollectionGrossAmount(
      appliedAmounts,
      appliedCreditNoteAmounts,
      appliedFinancialNoteAmounts
    );
    const discount = Number(header.discount_amount) || 0;
    const taxableBase = discount;
    const appliedTaxes = clientTaxes.map((tax) => {
      const taxAmount = taxableBase * (tax.rate / 100);
      return {
        tax_id: tax.id,
        tax_name: tax.name,
        rate: tax.rate,
        amount: taxAmount,
        chart_account_id: tax.chart_account_id
      };
    });
    const totalTaxes = appliedTaxes.reduce((sum, tax) => sum + tax.amount, 0);
    const netAmountToPay = grossAmount - discount - totalTaxes;
    const totalPaid = paymentItems.reduce(
      (sum, item) => sum + (Number(item.value) || 0),
      0
    );
    const remainingToPay = Math.round((netAmountToPay - totalPaid) * 100) / 100;
    return {
      grossAmount,
      invoicesGrossAmount,
      creditNotesGrossAmount,
      financialNotesGrossAmount,
      discount,
      appliedTaxes,
      totalTaxes,
      netAmountToPay,
      totalPaid,
      remainingToPay
    };
  }, [appliedAmounts, appliedCreditNoteAmounts, appliedFinancialNoteAmounts, clientTaxes, header.discount_amount, paymentItems]);
  const fillPaymentLineFromAppliedTotal = (index) => {
    const totalAplicado = totals.grossAmount;
    const sumOtros = paymentItems.reduce(
      (s, it, i) => i === index ? s : s + (Number(it.value) || 0),
      0
    );
    let monto = Math.round((totalAplicado - sumOtros) * 100) / 100;
    if (monto < 0) {
      toast.warn(
        "El total aplicado es menor que la suma de los demás medios de pago; se usará 0 en esta línea."
      );
      monto = 0;
    }
    handleItemChange(index, "value", monto);
  };
  const performSaveCobranza = useCallback(
    async () => {
      const itemsToSave = paymentItems.map((item) => {
        const base = {
          id: item.id || void 0,
          payment_method_code: item.payment_method_code,
          bank_id: item.bank_id,
          check_number: item.check_number ?? null,
          check_date: item.check_date ?? null,
          value: Number(item.value) || 0,
          chart_account_id: item.chart_account?.id || null
        };
        if (item.payment_method_code === "CHE") {
          base.check_due_date = item.check_due_date ?? null;
          base.check_holder = item.check_holder ?? null;
          base.issuer_cuit = item.issuer_cuit ?? null;
          base.is_to_order = Boolean(item.is_to_order);
          base.reference_number = item.reference_number ?? null;
        }
        if (item.payment_method_code === "RET") {
          const ref = item.reference_number != null ? String(item.reference_number).trim() : "";
          base.reference_number = ref !== "" ? ref : null;
        }
        return base;
      });
      const appliedInvoicesToSave = buildAppliedInvoicesForSave(appliedAmounts);
      const applied_credit_notes = buildAppliedCreditNotesForSave(appliedCreditNoteAmounts);
      const applied_financial_notes = buildAppliedSalesFinancialNotesForSave(appliedFinancialNoteAmounts);
      const taxesToSave = totals.appliedTaxes.filter((tax) => tax.amount > 0);
      const dataToSave = {
        ...header,
        client_id: header.client_id,
        payment_date: header.collection_date,
        gross_amount: totals.grossAmount,
        discount: totals.discount,
        total_amount: totals.totalPaid,
        taxes: taxesToSave,
        items: itemsToSave,
        applied_invoices: appliedInvoicesToSave,
        applied_credit_notes,
        applied_financial_notes,
        currency_id: 1
      };
      delete dataToSave.client;
      delete dataToSave.chart_account;
      setIsSaving(true);
      try {
        await saveItem(dataToSave);
        const saveError = useCrudItem.error;
        if (!saveError) {
          toast.success("Cobranza guardada con éxito!");
          navigate(getListReturnPath(cobranzasModuleConfig.baseRoute));
        }
      } catch (saveError) {
        console.error("Error al guardar:", saveError);
      } finally {
        setIsSaving(false);
      }
    },
    [
      paymentItems,
      appliedAmounts,
      appliedCreditNoteAmounts,
      appliedFinancialNoteAmounts,
      totals.appliedTaxes,
      totals.grossAmount,
      totals.discount,
      totals.totalPaid,
      header,
      saveItem,
      navigate
    ]
  );
  const handleSave = async () => {
    if (!header.client_id) {
      toast.error("Debe seleccionar un cliente.");
      return;
    }
    for (const item of paymentItems) {
      if (item.payment_method_code === "TRA" && !item.bank_id) {
        toast.error("Para transferencias debe seleccionar un banco.");
        return;
      }
      if (item.payment_method_code === "RET" && Number(item.value) > 0) {
        const ref = item.reference_number != null ? String(item.reference_number).trim() : "";
        if (!ref) {
          toast.error("Para retención debe seleccionar el tipo de retención (impuesto).");
          return;
        }
      }
      if (item.payment_method_code === "CHE" && Number(item.value) > 0) {
        const emission = item.check_date != null ? String(item.check_date).trim() : "";
        if (!emission) {
          toast.error("Para cheques debe ingresar la fecha de emisión.");
          return;
        }
      }
      if (item.payment_method_code !== "CHE" || item.is_third_party_check !== true) continue;
      const cuitVal = (item.issuer_cuit || "").trim();
      if (!cuitVal) {
        toast.error("Si el cheque es de tercero, debe ingresar el CUIT del emisor.");
        return;
      }
      if (!validateMask("cuit", cuitVal)) {
        const mask = getMask("cuit");
        toast.error(mask?.errorMessage ?? "CUIT del emisor inválido. Revise el formato (XX-XXXXXXXX-X).");
        return;
      }
    }
    const hasAppliedInvoices = buildAppliedInvoicesForSave(appliedAmounts).length > 0;
    const skipBalanceCheck = isAdjustmentOnlyCollection(paymentItems) && !hasAppliedInvoices;
    const remaining = totals.remainingToPay;
    if (!skipBalanceCheck) {
      if (remaining > 0.01) {
        toast.error(`Falta cobrar ${formatValue(remaining, "currency")}. El total cobrado (${formatValue(totals.totalPaid, "currency")}) es menor que el neto a cobrar (${formatValue(totals.netAmountToPay, "currency")}).`);
        return;
      }
      if (remaining < -0.01) {
        const advanceAmount = Math.abs(remaining);
        showConfirmationModal({
          title: "Saldo a favor del cliente",
          message: `El neto a cobrar es menor que el total de medios de pago. Se generará un saldo a favor (anticipo) del cliente por ${formatValue(advanceAmount, "currency")}. ¿Desea continuar?`,
          onConfirm: () => {
            void performSaveCobranza();
          }
        });
        return;
      }
    }
    await performSaveCobranza();
  };
  if (loadingData && mode === "edit") return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
    lineNumber: 802,
    columnNumber: 46
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar datos: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
    lineNumber: 803,
    columnNumber: 21
  }, this);
  const inputStyle = "w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4", children: [
      mode === "create" ? "Crear" : "Editar",
      " ",
      cobranzasModuleConfig.moduleName
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 811,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 p-4 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 818,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          RelationalInput,
          {
            codeValue: clientCodeInput,
            nameValue: header.client?.name || null,
            onCodeChange: setClientCodeInput,
            onCodeSubmit: handleClientCodeSubmit,
            onSearchClick: () => openModal("client", clientesModuleConfig),
            onClearClick: () => {
              setHeader((prev) => ({ ...prev, client_id: void 0, client: void 0 }));
              setClientCodeInput("");
              setOutstandingInvoices([]);
              setPendingCreditNotes([]);
              setPendingFinancialNotes([]);
              setAppliedAmounts({});
              setAppliedCreditNoteAmounts({});
              setAppliedFinancialNoteAmounts({});
              setClientTaxes([]);
              setClientAdvanceBalance(0);
            },
            disabled: mode === "edit"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 819,
            columnNumber: 21
          },
          this
        ),
        clientAdvanceBalance > 0 && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: [
          "Saldo anticipado disponible: ",
          formatValue(clientAdvanceBalance, "currency")
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 841,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 817,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(
          "label",
          {
            htmlFor: "collection_date",
            className: "block text-sm font-medium text-gray-700",
            children: "Fecha de Cobro"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 845,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "collection_date",
            type: "date",
            value: header.collection_date,
            onChange: (e) => setHeader((prev) => ({ ...prev, collection_date: e.target.value })),
            className: inputStyle,
            autoComplete: "off"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 848,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 844,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 816,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-4 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-2", children: "Facturas Pendientes de Cobro" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 859,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-96", children: loadingClientDocuments ? /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 861,
        columnNumber: 47
      }, this) : /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500", children: "Factura" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 865,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500", children: "Fecha" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 866,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500", children: "Total" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 867,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500", children: "Saldo" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 868,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-right text-xs font-medium text-gray-500 w-40", children: "Monto a Aplicar" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 869,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 864,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 863,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: outstandingInvoices.length > 0 ? outstandingInvoices.map(
          (inv) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm", children: inv.invoice_number }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 875,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm", children: formatValue(inv.invoice_date, "date") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 876,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-right", children: formatValue(inv.total_amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 877,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-right font-medium", children: formatValue(inv.balance, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 878,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: appliedAmounts[inv.id],
                  onChange: (num) => handleApplyAmount(inv.id, num),
                  onBlur: () => {
                    const enteredAmount = Number(appliedAmounts[inv.id]) || 0;
                    const balance = Number(inv.balance) || 0;
                    if (enteredAmount > balance) {
                      toast.warn(`El monto aplicado (${formatValue(enteredAmount, "currency")}) no puede superar el saldo (${formatValue(balance, "currency")})`);
                      handleApplyAmount(inv.id, balance);
                    }
                  },
                  placeholder: "0.00",
                  className: "flex-1 min-w-0 text-right px-2 py-1 border border-gray-300 rounded-md shadow-sm sm:text-sm"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 881,
                  columnNumber: 49
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => handleApplyAmount(inv.id, Number(inv.balance) || 0),
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors",
                  title: "Llenar con saldo pendiente",
                  "aria-label": `Aplicar saldo completo (${formatValue(inv.balance, "currency")}) para factura ${inv.invoice_number}`,
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 903,
                    columnNumber: 53
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 896,
                  columnNumber: 49
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 880,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 879,
              columnNumber: 41
            }, this)
          ] }, inv.id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 874,
            columnNumber: 15
          }, this)
        ) : /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "px-4 py-4 text-center text-sm text-gray-500", children: header.client_id ? "Este cliente no tiene facturas pendientes." : "Seleccione un cliente para ver sus facturas." }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 910,
          columnNumber: 41
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 909,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 872,
          columnNumber: 29
        }, this),
        outstandingInvoices.length > 0 && /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { colSpan: 4, className: "px-4 py-2 text-right text-sm font-semibold", children: "Total Aplicado:" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 920,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-right text-sm font-bold", children: formatValue(totals.invoicesGrossAmount, "currency") }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 921,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 919,
          columnNumber: 37
        }, this) }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 918,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 862,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 860,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 858,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      PendingSignedDocumentsTable,
      {
        title: "Notas de Crédito Pendientes",
        rows: creditNoteRows,
        appliedAmounts: appliedCreditNoteAmounts,
        footerTotal: totals.creditNotesGrossAmount,
        onAmountChange: handleCreditNoteAmountChange,
        onFillBalance: (noteId, balance) => handleCreditNoteAmountChange(noteId, balance)
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 930,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      PendingSignedDocumentsTable,
      {
        title: "Notas Financieras Pendientes",
        rows: financialNoteRows,
        appliedAmounts: appliedFinancialNoteAmounts,
        footerTotal: totals.financialNotesGrossAmount,
        showTypeColumn: true,
        onAmountChange: handleFinancialNoteAmountChange,
        onFillBalance: (noteId, balance) => handleFinancialNoteAmountChange(noteId, balance)
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 939,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-4 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-2", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium", children: "Medios de Pago" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 952,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: addNewItem, className: "inline-flex items-center px-3 py-1 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700", children: [
          /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-1" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 954,
            columnNumber: 25
          }, this),
          " Añadir Medio"
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 953,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 951,
        columnNumber: 17
      }, this),
      paymentItems.map(
        (item, index) => item.payment_method_code === "RET" ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-12 gap-x-4 gap-y-2 p-2 border-b items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-1", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: `payment_method_ret_${index}`, className: "text-xs font-medium text-gray-600", children: "Medio" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 961,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                id: `payment_method_ret_${index}`,
                value: item.payment_method_code,
                onChange: (e) => handleItemChange(index, "payment_method_code", e.target.value),
                className: inputStyle,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "EFE", children: "Efectivo" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 968,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CHE", children: "Cheque" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 969,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "TRA", children: "Transferencia" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 970,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "DOC", children: "Documento" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 971,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "RET", children: "Retención" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 972,
                    columnNumber: 37
                  }, this),
                  clientAdvanceBalance > 0 && /* @__PURE__ */ jsxDEV("option", { value: "SAL", children: [
                    "Saldo Anticipado (",
                    formatValue(clientAdvanceBalance, "currency"),
                    ")"
                  ] }, void 0, true, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 974,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 962,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 960,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-gray-600", children: "Cuenta" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 979,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.ui_account_code,
                nameValue: item.chart_account?.name || null,
                onCodeChange: (val) => handleItemChange(index, "ui_account_code", val),
                onCodeSubmit: () => handleItemCodeSubmit(index, "account"),
                onSearchClick: () => openModal({ type: "itemAccount", index }, planDeCuentasModuleConfig),
                onClearClick: () => {
                  handleItemChange(index, "chart_account", null);
                  handleItemChange(index, "ui_account_code", "");
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 980,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 978,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-3", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: `retention_tax_${index}`, className: "text-xs font-medium text-gray-600", children: "Tipo de retención" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 993,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                id: `retention_tax_${index}`,
                value: item.reference_number != null ? String(item.reference_number) : "",
                onChange: (e) => handleItemChange(
                  index,
                  "reference_number",
                  e.target.value === "" ? null : e.target.value
                ),
                className: inputStyle,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Seleccione…" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1006,
                    columnNumber: 37
                  }, this),
                  retentionTaxes.map(
                    (tax) => /* @__PURE__ */ jsxDEV("option", { value: String(tax.id), children: tax.name }, tax.id, false, {
                      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                      lineNumber: 1008,
                      columnNumber: 15
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 994,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 992,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { htmlFor: `ret_cert_${index}`, className: "text-xs font-medium text-gray-600", children: "Nº certificado" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1015,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: `ret_cert_${index}`,
                type: "text",
                value: item.check_number || "",
                onChange: (e) => handleItemChange(index, "check_number", e.target.value),
                className: inputStyle,
                maxLength: 255,
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1016,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1014,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-gray-600", children: "Valor" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1025,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: item.value,
                  onChange: (num) => handleItemChange(index, "value", num),
                  placeholder: "0.00",
                  className: `${inputStyle} text-right flex-1 min-w-0`
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1027,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => fillPaymentLineFromAppliedTotal(index),
                  disabled: totals.grossAmount <= 0,
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors disabled:opacity-40 disabled:pointer-events-none",
                  title: "Completar con el faltante respecto al total aplicado (excluye esta línea)",
                  "aria-label": "Completar valor con el faltante respecto al total aplicado",
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1042,
                    columnNumber: 41
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1034,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "aria-label": "Eliminar ítem",
                  type: "button",
                  onClick: () => removeItem(index),
                  className: "text-red-500 hover:text-red-700 p-1 shrink-0",
                  children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1050,
                    columnNumber: 41
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1044,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1026,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1024,
            columnNumber: 29
          }, this)
        ] }, item.tempId, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 959,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-12 gap-x-4 gap-y-2 p-2 border-b items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-1", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: `payment_method_${index}`,
                className: "text-xs font-medium text-gray-600",
                children: "Medio"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1059,
                columnNumber: 33
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: item.payment_method_code,
                onChange: (e) => handleItemChange(index, "payment_method_code", e.target.value),
                className: inputStyle,
                id: `payment_method_${index}`,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "EFE", children: "Efectivo" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1068,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CHE", children: "Cheque" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1069,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "TRA", children: "Transferencia" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1070,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "DOC", children: "Documento" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1071,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "RET", children: "Retención" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1072,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "AJU", children: "Ajuste" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1073,
                    columnNumber: 37
                  }, this),
                  clientAdvanceBalance > 0 && /* @__PURE__ */ jsxDEV("option", { value: "SAL", children: [
                    "Saldo Anticipado (",
                    formatValue(clientAdvanceBalance, "currency"),
                    ")"
                  ] }, void 0, true, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1075,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1062,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1058,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-gray-600", children: "Cuenta" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1081,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.ui_account_code,
                nameValue: item.chart_account?.name || null,
                onCodeChange: (val) => handleItemChange(index, "ui_account_code", val),
                onCodeSubmit: () => handleItemCodeSubmit(index, "account"),
                onSearchClick: () => openModal({ type: "itemAccount", index }, planDeCuentasModuleConfig),
                onClearClick: () => {
                  handleItemChange(index, "chart_account", null);
                  handleItemChange(index, "ui_account_code", "");
                }
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1082,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1080,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 md:col-span-2", children: /* @__PURE__ */ jsxDEV("div", { className: item.payment_method_code === "EFE" ? "invisible" : "", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-gray-600", children: "Banco" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1097,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: item.ui_bank_code,
                nameValue: item.bank_name || null,
                onCodeChange: (val) => handleItemChange(index, "ui_bank_code", val),
                onCodeSubmit: () => handleItemCodeSubmit(index, "bank"),
                onSearchClick: () => openModal({ type: "itemBank", index }, bancosModuleConfig),
                onClearClick: () => {
                  handleItemChange(index, "bank_id", null);
                  handleItemChange(index, "bank_name", null);
                  handleItemChange(index, "ui_bank_code", "");
                },
                disabled: item.payment_method_code === "SAL"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1098,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1096,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1095,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: /* @__PURE__ */ jsxDEV("div", { className: item.payment_method_code === "EFE" ? "invisible" : "", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: `check_number_${index}`,
                className: "text-xs font-medium text-gray-600",
                children: item.payment_method_code === "CHE" ? "Nº Cheque" : "Referencia"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1116,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: `check_number_${index}`,
                type: "text",
                value: item.check_number || "",
                onChange: (e) => handleItemChange(index, "check_number", e.target.value),
                className: inputStyle,
                disabled: item.payment_method_code === "SAL",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1119,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1115,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1114,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: /* @__PURE__ */ jsxDEV("div", { className: item.payment_method_code === "EFE" ? "invisible" : "", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: `check_date_${index}`,
                className: "text-xs font-medium text-gray-600",
                children: item.payment_method_code === "CHE" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  "Fecha emisión ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1136,
                    columnNumber: 63
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1135,
                  columnNumber: 17
                }, this) : "Fecha"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1131,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                id: `check_date_${index}`,
                value: item.check_date ? formatDateForInput(new Date(item.check_date)) : "",
                onChange: (e) => handleItemChange(index, "check_date", e.target.value),
                className: inputStyle,
                disabled: item.payment_method_code === "SAL",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1142,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1130,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1129,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-10 md:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-medium text-gray-600", children: "Valor" }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1153,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2 md:col-span-1 flex justify-center items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(
                DecimalInput,
                {
                  step: "0.01",
                  value: item.value,
                  onChange: (num) => handleItemChange(index, "value", num),
                  placeholder: "0.00",
                  className: `${inputStyle} text-right flex-1 min-w-0`
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1155,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => fillPaymentLineFromAppliedTotal(index),
                  disabled: totals.grossAmount <= 0,
                  className: "flex-shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded border border-gray-200 hover:border-indigo-300 transition-colors disabled:opacity-40 disabled:pointer-events-none",
                  title: "Completar con el faltante respecto al total aplicado (excluye esta línea)",
                  "aria-label": "Completar valor con el faltante respecto al total aplicado",
                  children: /* @__PURE__ */ jsxDEV(FaFillDrip, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1170,
                    columnNumber: 41
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1162,
                  columnNumber: 37
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  "aria-label": "Eliminar ítem",
                  type: "button",
                  onClick: () => removeItem(index),
                  className: "text-red-500 hover:text-red-700 p-1 shrink-0",
                  children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1175,
                    columnNumber: 41
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1172,
                  columnNumber: 37
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1154,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1152,
            columnNumber: 29
          }, this),
          item.payment_method_code === "CHE" && /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 grid grid-cols-12 gap-x-4 gap-y-2 pt-2 border-t border-gray-100 mt-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { htmlFor: `check_due_date_${index}`, className: "text-xs font-medium text-gray-600", children: "Fecha de pago/cobro" }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1184,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  id: `check_due_date_${index}`,
                  value: item.check_due_date ? formatDateForInput(new Date(item.check_due_date)) : "",
                  onChange: (e) => handleItemChange(index, "check_due_date", e.target.value),
                  className: inputStyle,
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1185,
                  columnNumber: 41
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1183,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { htmlFor: `reference_number_${index}`, className: "text-xs font-medium text-gray-600", children: "Referencia" }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1193,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  id: `reference_number_${index}`,
                  value: item.reference_number || "",
                  onChange: (e) => handleItemChange(index, "reference_number", e.target.value),
                  className: inputStyle,
                  maxLength: 255,
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1194,
                  columnNumber: 41
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1192,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2 flex items-end", children: /* @__PURE__ */ jsxDEV("label", { className: "inline-flex items-center gap-2 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: Boolean(item.is_to_order),
                  onChange: (e) => handleItemChange(index, "is_to_order", e.target.checked),
                  className: "rounded border-gray-300",
                  autoComplete: "off"
                },
                void 0,
                false,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1204,
                  columnNumber: 45
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-600", children: "A la orden" }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1209,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1203,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1202,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { htmlFor: `third_party_${index}`, className: "text-xs font-medium text-gray-600", children: "Cheque de tercero" }, void 0, false, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1213,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  id: `third_party_${index}`,
                  value: item.is_third_party_check === true ? "yes" : "no",
                  onChange: (e) => {
                    const isYes = e.target.value === "yes";
                    handleItemChange(index, "is_third_party_check", isYes);
                    if (!isYes) {
                      handleItemChange(index, "issuer_cuit", null);
                      handleItemChange(index, "check_holder", null);
                    }
                  },
                  className: inputStyle,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "no", children: "No" }, void 0, false, {
                      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                      lineNumber: 1227,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "yes", children: "Sí" }, void 0, false, {
                      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                      lineNumber: 1228,
                      columnNumber: 45
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1214,
                  columnNumber: 41
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1212,
              columnNumber: 37
            }, this),
            item.is_third_party_check === true && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: [
                /* @__PURE__ */ jsxDEV("label", { htmlFor: `check_holder_${index}`, className: "text-xs font-medium text-gray-600", children: "Emisor del cheque" }, void 0, false, {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1234,
                  columnNumber: 49
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    id: `check_holder_${index}`,
                    value: item.check_holder || "",
                    onChange: (e) => handleItemChange(index, "check_holder", e.target.value),
                    className: inputStyle,
                    maxLength: 255,
                    autoComplete: "off"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1235,
                    columnNumber: 49
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1233,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "col-span-6 md:col-span-2", children: [
                /* @__PURE__ */ jsxDEV("label", { htmlFor: `issuer_cuit_${index}`, className: "text-xs font-medium text-gray-600", children: "CUIT emisor (tercero)" }, void 0, false, {
                  fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                  lineNumber: 1244,
                  columnNumber: 49
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    id: `issuer_cuit_${index}`,
                    value: item.issuer_cuit || "",
                    onChange: (e) => handleItemChange(index, "issuer_cuit", applyMask("cuit", e.target.value)),
                    onBlur: (e) => {
                      const val = (e.target.value || "").trim();
                      if (val && !validateMask("cuit", val)) {
                        const mask = getMask("cuit");
                        toast.warn(mask?.errorMessage ?? "CUIT inválido");
                      }
                    },
                    className: inputStyle,
                    placeholder: "Ej: 30-12345678-9",
                    maxLength: getMask("cuit")?.maxLength ?? 13,
                    autoComplete: "off"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                    lineNumber: 1245,
                    columnNumber: 49
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
                lineNumber: 1243,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1232,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1182,
            columnNumber: 11
          }, this)
        ] }, item.tempId, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1056,
          columnNumber: 9
        }, this)
      ),
      paymentItems.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-2 pt-2 border-t", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold mr-2", children: "Total Medios de Pago:" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1272,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold", children: formatValue(totals.totalPaid, "currency") }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1273,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1271,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 950,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-8 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2 p-4 border rounded-lg space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Descuentos y Retenciones" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1283,
          columnNumber: 21
        }, this),
        totals.appliedTaxes.length > 0 ? totals.appliedTaxes.map(
          (tax) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-medium text-gray-700 col-span-2", children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%)"
            ] }, void 0, true, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1301,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "w-full px-2 py-1 text-right text-gray-800 bg-gray-100 rounded-md", children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
              lineNumber: 1303,
              columnNumber: 33
            }, this)
          ] }, tax.tax_id, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1300,
            columnNumber: 11
          }, this)
        ) : /* @__PURE__ */ jsxDEV("p", { className: "pt-2 text-sm text-gray-500", children: header.client_id ? "El cliente no tiene retenciones configuradas o aplicables." : "Seleccione un cliente para ver sus retenciones." }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1309,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1282,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-1 p-4 bg-gray-50 border rounded-lg space-y-2 flex flex-col justify-center h-fit", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800 mb-4", children: "Resumen" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1317,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Importe Bruto:" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1318,
            columnNumber: 67
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.grossAmount, "currency") }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1318,
            columnNumber: 95
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1318,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-red-600", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Retenciones:" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1322,
            columnNumber: 80
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: [
            "- ",
            formatValue(totals.totalTaxes, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1322,
            columnNumber: 106
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1322,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Neto a Cobrar:" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1323,
            columnNumber: 69
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.remainingToPay, "currency") }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1323,
            columnNumber: 97
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1323,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between font-bold text-lg border-t pt-2 mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "TOTAL COBRADO:" }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1324,
            columnNumber: 96
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("span", { children: formatValue(totals.totalPaid, "currency") }, void 0, false, {
            fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
            lineNumber: 1324,
            columnNumber: 124
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1324,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1316,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 1280,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(getListReturnPath(cobranzasModuleConfig.baseRoute)), className: "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1330,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: isSaving || loadingClientDocuments, className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:opacity-50", children: [
        isSaving ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1332,
          columnNumber: 33
        }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
          lineNumber: 1332,
          columnNumber: 87
        }, this),
        "Guardar Cobranza"
      ] }, void 0, true, {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1331,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
      lineNumber: 1329,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: () => setIsModalOpen(false),
        onSelect: handleSelectModal,
        config: modalConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
        lineNumber: 1339,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/cobranzas/pages/CobranzasFormPage.tsx",
    lineNumber: 810,
    columnNumber: 5
  }, this);
};
_s(CobranzasFormPage, "x5JgzkdvdodixT3ELwMFMYE1l8E=", false, function() {
  return [useParams, useNavigate, useCrudItem, useModal];
});
_c = CobranzasFormPage;
var _c;
$RefreshReg$(_c, "CobranzasFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cobranzas/pages/CobranzasFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cobranzas/pages/CobranzasFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOHdCK0MsU0E2VUgsVUE3VUc7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBN3dCL0MsU0FBU0EsVUFBVUMsV0FBV0MsU0FBU0MsbUJBQXVEO0FBQzlGLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFFBQVFDLFdBQVdDLFFBQVFDLFNBQVNDLGtCQUFrQjtBQUMvRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBU0MsUUFBUUMsUUFBUUMscUJBQXFCO0FBQ3ZEO0FBQUEsRUFDSUM7QUFBQUEsT0FHRztBQUNQO0FBQUEsRUFDSUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDRztBQUNQLFNBQXVCQyw0QkFBNEI7QUFDbkQsZUFBa0M7QUFDbEMsZUFBZ0M7QUFDaEMsZUFBbUM7QUFDbkMsU0FBU0MsaUNBQXFEO0FBQzlELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0I7QUFBQSxFQUNJQztBQUFBQSxPQUVHO0FBQ1AsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxhQUFhQywwQkFBMEI7QUFDaEQsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxXQUFXQyxjQUFjQyxlQUFlO0FBRWpELFNBQVNDLHlCQUFtQztBQUM1QztBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0c7QUFDUCxTQUFTQyx5QkFBeUI7QUFtQjNCLGFBQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsR0FBRyxJQUFJMUMsVUFBMEI7QUFDekMsUUFBTTJDLFdBQVc1QyxZQUFZO0FBQzdCLFFBQU02QyxPQUFPRixLQUFLLFNBQVM7QUFFM0IsUUFBTTtBQUFBLElBQ0ZHLE1BQU1DO0FBQUFBLElBQ05DLFNBQVNDO0FBQUFBLElBQ1RDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0osSUFBSTNDLFlBQTZCSyx1QkFBdUI4QixFQUFFO0FBQzFELFFBQU0sRUFBRVMsc0JBQXNCLElBQUl2QixTQUFTO0FBRzNDLFFBQU0sQ0FBQ3dCLFFBQVFDLFNBQVMsSUFBSTFELFNBQW1DO0FBQUEsSUFDM0QyRCxpQkFBaUIzQixtQkFBbUIsb0JBQUk0QixLQUFLLENBQUM7QUFBQSxJQUM5Q0MsaUJBQWlCO0FBQUEsRUFDckIsQ0FBQztBQUdELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSS9ELFNBQVMsRUFBRTtBQUd6RCxRQUFNLENBQUNnRSxjQUFjQyxlQUFlLElBQUlqRSxTQUFvQyxFQUFFO0FBQzlFLFFBQU0sQ0FBQ2tFLGFBQWFDLGNBQWMsSUFBSW5FLFNBQXVCLEVBQUU7QUFDL0QsUUFBTSxDQUFDb0Usc0JBQXNCQyx1QkFBdUIsSUFBSXJFLFNBQVMsQ0FBQztBQUdsRSxRQUFNLENBQUNzRSxxQkFBcUJDLHNCQUFzQixJQUFJdkUsU0FBeUIsRUFBRTtBQUNqRixRQUFNLENBQUN3RSxvQkFBb0JDLHFCQUFxQixJQUFJekUsU0FBdUIsRUFBRTtBQUM3RSxRQUFNLENBQUMwRSx1QkFBdUJDLHdCQUF3QixJQUFJM0UsU0FBMEIsRUFBRTtBQUN0RixRQUFNLENBQUM0RSx3QkFBd0JDLHlCQUF5QixJQUFJN0UsU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQzhFLGdCQUFnQkMsaUJBQWlCLElBQUkvRSxTQUEwQyxDQUFDLENBQUM7QUFDeEYsUUFBTSxDQUFDZ0YsMEJBQTBCQywyQkFBMkIsSUFBSWpGLFNBQTBDLENBQUMsQ0FBQztBQUM1RyxRQUFNLENBQUNrRiw2QkFBNkJDLDhCQUE4QixJQUFJbkYsU0FBMEMsQ0FBQyxDQUFDO0FBR2xILFFBQU0sQ0FBQ29GLGFBQWFDLGNBQWMsSUFBSXJGLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNzRixlQUFlQyxnQkFBZ0IsSUFBSXZGLFNBQStCLElBQUk7QUFDN0UsUUFBTSxDQUFDd0YsYUFBYUMsY0FBYyxJQUFJekYsU0FBYyxJQUFJO0FBQ3hELFFBQU0sQ0FBQzBGLFVBQVVDLFdBQVcsSUFBSTNGLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUM0RixnQkFBZ0JDLGlCQUFpQixJQUFJN0YsU0FBZ0IsRUFBRTtBQUU5REMsWUFBVSxNQUFNO0FBQ1osUUFBSTZGLFlBQVk7QUFDaEIsVUFBTSxZQUFZO0FBQ2QsVUFBSTtBQUNBLGNBQU1DLE1BQU0sTUFBTWpGLE9BQVl3QixrQkFBa0IwRCxVQUFVLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxJQUFJLENBQUM7QUFDcEYsWUFBSSxDQUFDSixVQUFXRCxtQkFBa0JFLElBQUlJLFFBQVEsRUFBRTtBQUFBLE1BQ3BELFNBQVNDLEdBQUc7QUFDUkMsZ0JBQVEvQyxNQUFNOEMsQ0FBQztBQUNmLFlBQUksQ0FBQ04sVUFBV3hGLE9BQU1nRCxNQUFNLG1EQUFtRDtBQUFBLE1BQ25GO0FBQUEsSUFDSixHQUFHO0FBQ0gsV0FBTyxNQUFNO0FBQ1R3QyxrQkFBWTtBQUFBLElBQ2hCO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFHTDdGLFlBQVUsTUFBTTtBQUVaLFFBQUlrRCxnQkFBZ0JGLFNBQVMsUUFBUTtBQUdqQ1MsZ0JBQVU7QUFBQSxRQUNOLEdBQUdQO0FBQUFBLFFBQ0hRLGlCQUFpQjNCLG1CQUFtQixJQUFJNEIsS0FBS1QsYUFBYVEsZUFBZSxDQUFDO0FBQUEsUUFDMUVFLGlCQUFpQnlDLE9BQU9uRCxhQUFhVSxlQUFlLEtBQUs7QUFBQTtBQUFBLE1BQzdELENBQUM7QUFHRCxVQUFJVixhQUFhb0QsUUFBUTtBQUNyQnhDLDJCQUFtQlosYUFBYW9ELE9BQU9DLFFBQVFDLE9BQU90RCxhQUFhb0QsT0FBT3hELEVBQUUsQ0FBQztBQUFBLE1BQ2pGO0FBRUEsWUFBTTJELGlCQUFpQnZELGFBQWF3RCxNQUFNQyxJQUFJLENBQUExRCxVQUFTO0FBQUEsUUFDbkQsR0FBR0E7QUFBQUEsUUFDSDJELFFBQVEsUUFBUTNELEtBQUtILEVBQUU7QUFBQSxRQUN2QitELE9BQU9SLE9BQU9wRCxLQUFLNEQsS0FBSyxLQUFLO0FBQUEsUUFDN0JDLGdCQUFnQjdELEtBQUs2RCxrQkFBa0I7QUFBQSxRQUN2Q0MsY0FBYzlELEtBQUs4RCxnQkFBZ0I7QUFBQSxRQUNuQ0MsYUFBYS9ELEtBQUsrRCxlQUFlO0FBQUEsUUFDakNDLGFBQWFDLFFBQVFqRSxLQUFLZ0UsV0FBVztBQUFBLFFBQ3JDRSxrQkFBa0JsRSxLQUFLa0Usb0JBQW9CO0FBQUEsUUFDM0NDLHNCQUFzQkYsUUFBUWpFLEtBQUsrRCxhQUFhSyxLQUFLLENBQUM7QUFBQSxRQUN0REMsaUJBQWlCckUsS0FBS3NFLGVBQWVDLFFBQVE7QUFBQSxRQUM3Q0MsY0FBY3hFLEtBQUt5RSxVQUFVbEIsT0FBT3ZELEtBQUt5RSxPQUFPLElBQUk7QUFBQSxNQUN4RCxFQUFFO0FBQ0YxRCxzQkFBZ0J5QyxjQUFjO0FBRzlCLFlBQU1rQixXQUFXekUsYUFBYTBFLG9CQUFvQixJQUFJQyxPQUFPLENBQUNDLEtBQUtDLFFBQVE7QUFFdkVELFlBQUlDLElBQUlDLGNBQWNsRixFQUFFLElBQUl1RCxPQUFPMEIsSUFBSUUsY0FBYyxLQUFLO0FBQzFELGVBQU9IO0FBQUFBLE1BQ1gsR0FBRyxDQUFDLENBQTJCO0FBQy9CaEQsd0JBQWtCNkMsT0FBTztBQUV6QixVQUFJekUsYUFBYWdGLHNCQUFzQjtBQUNuQyxjQUFNQyxnQkFBZ0JqRixhQUFhZ0YscUJBQXFCTCxPQUFPLENBQUNDLEtBQUtDLFFBQVE7QUFDekVELGNBQUlDLElBQUlLLFlBQVl0RixFQUFFLElBQUl1RCxPQUFPMEIsSUFBSUUsY0FBYyxLQUFLO0FBQ3hELGlCQUFPSDtBQUFBQSxRQUNYLEdBQUcsQ0FBQyxDQUEyQjtBQUMvQjlDLG9DQUE0Qm1ELGFBQWE7QUFBQSxNQUM3QztBQUVBLFVBQUlqRixhQUFhbUYseUJBQXlCO0FBQ3RDLGNBQU1DLG1CQUFtQnBGLGFBQWFtRix3QkFBd0JSLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUTtBQUMvRUQsY0FBSUMsSUFBSVEsZUFBZXpGLEVBQUUsSUFBSXVELE9BQU8wQixJQUFJRSxjQUFjLEtBQUs7QUFDM0QsaUJBQU9IO0FBQUFBLFFBQ1gsR0FBRyxDQUFDLENBQTJCO0FBQy9CNUMsdUNBQStCb0QsZ0JBQWdCO0FBQUEsTUFDbkQ7QUFHQSxZQUFNRSxlQUFlLE9BQU9DLGFBQXFCO0FBQzdDN0Qsa0NBQTBCLElBQUk7QUFDOUIsWUFBSTtBQUNBLGdCQUFNOEQsYUFBYSxNQUFNOUgsUUFBeUJXLHFCQUFxQndFLFVBQVUwQyxRQUFRO0FBQ3pGdkUseUJBQWV3RSxXQUFXQyxTQUFTLEVBQUU7QUFDckN2RSxtQ0FBeUJpQyxPQUFPcUMsV0FBV0UsZUFBZSxLQUFLLEtBQUssRUFBRTtBQUV0RSxnQkFBTUMsU0FBUyxJQUFJQyxnQkFBZ0I7QUFBQSxZQUMvQkMsV0FBV04sU0FBU08sU0FBUztBQUFBLFlBQzdCQyxhQUFhO0FBQUEsVUFDakIsQ0FBQztBQUNELGdCQUFNQyxtQkFBbUJoRyxhQUFhZ0Ysc0JBQXNCdkIsSUFBSSxDQUFBd0MsT0FBTUEsR0FBR2YsWUFBWXRGLEVBQUUsS0FBSztBQUM1RixnQkFBTXNHLHNCQUFzQmxHLGFBQWFtRix5QkFBeUIxQixJQUFJLENBQUF3QyxPQUFNQSxHQUFHWixlQUFlekYsRUFBRSxLQUFLO0FBQ3JHLGdCQUFNdUcsd0JBQXdCSCxpQkFBaUJ2QyxJQUFJLENBQUEyQyxXQUFVMUksUUFBb0IsZ0JBQWdCMEksTUFBTSxDQUFDO0FBQ3hHLGdCQUFNQywyQkFBMkJILG9CQUFvQnpDO0FBQUFBLFlBQUksQ0FBQTJDLFdBQ3JEMUksUUFBdUIsbUJBQW1CMEksTUFBTTtBQUFBLFVBQ3BEO0FBRUEsZ0JBQU0sQ0FBQ0Usa0JBQWtCQyxxQkFBcUJDLHdCQUF3QixHQUFHQyxjQUFjLElBQ25GLE1BQU1DLFFBQVFDO0FBQUFBLFlBQUk7QUFBQSxjQUNkL0ksT0FBcUIsa0JBQWtCK0gsT0FBT0csU0FBUyxDQUFDLEVBQUU7QUFBQSxjQUMxRGxJLE9BQW1CLGdCQUFnQitILE9BQU9HLFNBQVMsQ0FBQyxFQUFFO0FBQUEsY0FDdERsSSxPQUFzQixtQkFBbUIrSCxPQUFPRyxTQUFTLENBQUMsRUFBRTtBQUFBLGNBQzVELEdBQUdLO0FBQUFBLGNBQ0gsR0FBR0U7QUFBQUEsWUFBd0I7QUFBQSxVQUM5QjtBQUVMLGdCQUFNTyw0QkFBNEJILGVBQWVJLE1BQU0sR0FBR1Ysc0JBQXNCVyxNQUFNO0FBQ3RGLGdCQUFNQywrQkFBK0JOLGVBQWVJLE1BQU1WLHNCQUFzQlcsTUFBTTtBQUV0RixnQkFBTUUsaUJBQWlCLElBQUlDO0FBQUFBLFlBQ3ZCWCxpQkFBaUJ0RCxLQUFLUyxJQUFJLENBQUF5RCxRQUFPLENBQUNBLElBQUl0SCxJQUFJc0gsR0FBRyxDQUFDO0FBQUEsVUFDbEQ7QUFDQSxXQUFDbEgsYUFBYTBFLG9CQUFvQixJQUFJeUMsUUFBUSxDQUFBdEMsUUFBTztBQUNqRCxrQkFBTXVDLGlCQUFpQnZDLElBQUlDO0FBQzNCLGtCQUFNdUMsbUJBQW1CbEUsT0FBT2lFLGVBQWVFLE9BQU8sS0FBSyxNQUFNbkUsT0FBTzBCLElBQUlFLGNBQWMsS0FBSztBQUMvRmlDLDJCQUFlTyxJQUFJSCxlQUFleEgsSUFBSTtBQUFBLGNBQ2xDLEdBQUl3SDtBQUFBQSxjQUNKRSxTQUFTRDtBQUFBQSxZQUNiLENBQUM7QUFBQSxVQUNMLENBQUM7QUFDRGpHLGlDQUF1Qm9HLE1BQU1DLEtBQUtULGVBQWVVLE9BQU8sQ0FBQyxDQUFDO0FBRTFELGdCQUFNQyxvQkFBb0Isb0JBQUlWLElBQXdCO0FBQ3RETCxvQ0FBMEJPLFFBQVEsQ0FBQVMsTUFBSztBQUFFLGdCQUFJQSxFQUFHRCxtQkFBa0JKLElBQUlLLEVBQUVoSSxJQUFJZ0ksQ0FBQztBQUFBLFVBQUcsQ0FBQztBQUNqRnJCLDhCQUFvQnZELEtBQUttRSxRQUFRLENBQUFTLE1BQUs7QUFBRSxnQkFBSSxDQUFDRCxrQkFBa0JFLElBQUlELEVBQUVoSSxFQUFFLEVBQUcrSCxtQkFBa0JKLElBQUlLLEVBQUVoSSxJQUFJZ0ksQ0FBQztBQUFBLFVBQUcsQ0FBQztBQUMzRyxnQkFBTUUsbUJBQW1CTixNQUFNQyxLQUFLRSxrQkFBa0JELE9BQU8sQ0FBQyxFQUFFakUsSUFBSSxDQUFBbUUsTUFBSztBQUNyRSxrQkFBTUcsZ0JBQWdCL0gsYUFBYWdGLHNCQUFzQmdELEtBQUssQ0FBQS9CLE9BQU1BLEdBQUdmLFlBQVl0RixPQUFPZ0ksRUFBRWhJLEVBQUU7QUFDOUYsZ0JBQUltSSxlQUFlO0FBQ2Ysb0JBQU1FLGlCQUFpQjVJLHdCQUF3QnVJLEVBQUVOLE9BQU87QUFDeEQscUJBQU8sRUFBRSxHQUFHTSxHQUFHTixTQUFTVyxrQkFBa0I5RSxPQUFPNEUsY0FBY2hELGNBQWMsS0FBSyxHQUFHO0FBQUEsWUFDekY7QUFDQSxtQkFBTzZDO0FBQUFBLFVBQ1gsQ0FBQztBQUNEdEcsZ0NBQXNCd0csZ0JBQWdCO0FBRXRDLGdCQUFNSSx1QkFBdUIsb0JBQUlqQixJQUEyQjtBQUM1REYsdUNBQTZCSSxRQUFRLENBQUFTLE1BQUs7QUFBRSxnQkFBSUEsRUFBR00sc0JBQXFCWCxJQUFJSyxFQUFFaEksSUFBSWdJLENBQUM7QUFBQSxVQUFHLENBQUM7QUFDdkZwQixpQ0FBdUJ4RCxLQUFLbUUsUUFBUSxDQUFBUyxNQUFLO0FBQUUsZ0JBQUksQ0FBQ00scUJBQXFCTCxJQUFJRCxFQUFFaEksRUFBRSxFQUFHc0ksc0JBQXFCWCxJQUFJSyxFQUFFaEksSUFBSWdJLENBQUM7QUFBQSxVQUFHLENBQUM7QUFDcEgsZ0JBQU1PLHNCQUFzQlgsTUFBTUMsS0FBS1MscUJBQXFCUixPQUFPLENBQUMsRUFBRWpFLElBQUksQ0FBQW1FLE1BQUs7QUFDM0Usa0JBQU1HLGdCQUFnQi9ILGFBQWFtRix5QkFBeUI2QyxLQUFLLENBQUEvQixPQUFNQSxHQUFHWixlQUFlekYsT0FBT2dJLEVBQUVoSSxFQUFFO0FBQ3BHLGdCQUFJbUksZUFBZTtBQUNmLG9CQUFNRSxpQkFBaUIxSSxtQkFBbUJxSSxFQUFFOUUsTUFBTThFLEVBQUVOLE9BQU87QUFDM0QscUJBQU8sRUFBRSxHQUFHTSxHQUFHTixTQUFTVyxrQkFBa0I5RSxPQUFPNEUsY0FBY2hELGNBQWMsS0FBSyxHQUFHO0FBQUEsWUFDekY7QUFDQSxtQkFBTzZDO0FBQUFBLFVBQ1gsQ0FBQztBQUNEcEcsbUNBQXlCMkcsbUJBQW1CO0FBQUEsUUFDaEQsU0FBU0MsS0FBYztBQUNuQmxGLGtCQUFRL0MsTUFBTSxxQ0FBcUNpSSxHQUFHO0FBQ3REakwsZ0JBQU1nRCxNQUFNLHFEQUFxRDtBQUFBLFFBQ3JFLFVBQUM7QUFDR3VCLG9DQUEwQixLQUFLO0FBQUEsUUFDbkM7QUFBQSxNQUNKO0FBR0E0RCxtQkFBYXRGLGFBQWE2RixTQUFTO0FBQUEsSUFDdkM7QUFBQSxFQUNKLEdBQUcsQ0FBQzdGLGNBQWNGLElBQUksQ0FBQztBQUl2QixRQUFNdUksdUJBQXVCLE9BQU9DLG1CQUE0QjtBQUM1RC9ILGNBQVUsQ0FBQWdJLFVBQVMsRUFBRSxHQUFHQSxNQUFNMUMsV0FBV3lDLGVBQWUxSSxJQUFJd0QsUUFBUWtGLGVBQWUsRUFBRTtBQUNyRjFILHVCQUFtQjBILGVBQWVFLGlCQUFpQmxGLE9BQU9nRixlQUFlMUksRUFBRSxDQUFDO0FBQzVFd0IsMkJBQXVCLEVBQUU7QUFDekJFLDBCQUFzQixFQUFFO0FBQ3hCRSw2QkFBeUIsRUFBRTtBQUMzQkksc0JBQWtCLENBQUMsQ0FBQztBQUNwQkUsZ0NBQTRCLENBQUMsQ0FBQztBQUM5QkUsbUNBQStCLENBQUMsQ0FBQztBQUNqQ2hCLG1CQUFlLEVBQUU7QUFDakJFLDRCQUF3QixDQUFDO0FBQ3pCUSw4QkFBMEIsSUFBSTtBQUU5QixRQUFJO0FBQ0EsWUFBTThELGFBQWEsTUFBTTlILFFBQXlCVyxxQkFBcUJ3RSxVQUFVeUYsZUFBZTFJLEVBQUU7QUFDbEcsVUFBSTRGLFdBQVdDLE9BQU87QUFDbEJ6RSx1QkFBZXdFLFdBQVdDLEtBQUs7QUFBQSxNQUNuQztBQUNBdkUsK0JBQXlCaUMsT0FBT3FDLFdBQVdFLGVBQWUsS0FBSyxLQUFLLEVBQUU7QUFFdEUsWUFBTUMsU0FBUyxJQUFJQyxnQkFBZ0I7QUFBQSxRQUMvQkMsV0FBV3lDLGVBQWUxSSxHQUFHa0csU0FBUztBQUFBLFFBQ3RDQyxhQUFhO0FBQUEsTUFDakIsQ0FBQztBQUNELFlBQU0sQ0FBQ08sa0JBQWtCQyxxQkFBcUJDLHNCQUFzQixJQUFJLE1BQU1FLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUN0Ri9JLE9BQXFCLGtCQUFrQitILE9BQU9HLFNBQVMsQ0FBQyxFQUFFO0FBQUEsVUFDMURsSSxPQUFtQixnQkFBZ0IrSCxPQUFPRyxTQUFTLENBQUMsRUFBRTtBQUFBLFVBQ3REbEksT0FBc0IsbUJBQW1CK0gsT0FBT0csU0FBUyxDQUFDLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFDaEU7QUFFRDFFLDZCQUF1QmtGLGlCQUFpQnRELElBQUk7QUFDNUMxQiw0QkFBc0JpRixvQkFBb0J2RCxJQUFJO0FBQzlDeEIsK0JBQXlCZ0YsdUJBQXVCeEQsSUFBSTtBQUFBLElBQ3hELFNBQVNvRixLQUFjO0FBQ25CbEYsY0FBUS9DLE1BQU0sc0NBQXNDaUksR0FBRztBQUN2RGpMLFlBQU1nRCxNQUFNLGdFQUFnRTtBQUFBLElBQ2hGLFVBQUM7QUFDR3VCLGdDQUEwQixLQUFLO0FBQUEsSUFDbkM7QUFBQSxFQUNKO0FBR0EsUUFBTStHLHlCQUF5QixZQUFZO0FBQ3ZDLFFBQUksQ0FBQzlILGdCQUFnQndELEtBQUssRUFBRztBQUc3QixRQUFJN0QsT0FBTzhDLFdBQVc5QyxPQUFPOEMsT0FBT0MsU0FBUzFDLG1CQUFtQjJDLE9BQU9oRCxPQUFPOEMsT0FBT3hELEVBQUUsTUFBTWUsa0JBQWtCO0FBQzNHO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFFQSxZQUFNK0gsWUFBWSxNQUFNN0s7QUFBQUEsUUFDcEJRLHFCQUFxQndFO0FBQUFBLFFBQ3JCLENBQUMsRUFBRThGLFdBQVcsaUJBQWlCaEYsT0FBT2hELGdCQUFnQixDQUFDO0FBQUEsTUFDM0Q7QUFFQSxVQUFJK0gsV0FBVztBQUNYTCw2QkFBcUJLLFNBQVM7QUFDOUJ2TCxjQUFNeUwsUUFBUSx1QkFBdUJGLFVBQVVHLElBQUksRUFBRTtBQUFBLE1BQ3pELE9BQU87QUFDSDFMLGNBQU0yTCxRQUFRLHVDQUF1QztBQUNyRHZJLGtCQUFVLENBQUFnSSxVQUFTLEVBQUUsR0FBR0EsTUFBTTFDLFdBQVdrRCxRQUFXM0YsUUFBUTJGLE9BQVUsRUFBRTtBQUN4RTNILCtCQUF1QixFQUFFO0FBQ3pCRSw4QkFBc0IsRUFBRTtBQUN4QkUsaUNBQXlCLEVBQUU7QUFDM0JJLDBCQUFrQixDQUFDLENBQUM7QUFDcEJFLG9DQUE0QixDQUFDLENBQUM7QUFDOUJFLHVDQUErQixDQUFDLENBQUM7QUFDakNoQix1QkFBZSxFQUFFO0FBQ2pCRSxnQ0FBd0IsQ0FBQztBQUFBLE1BQzdCO0FBQUEsSUFDSixTQUFTZixRQUFPO0FBQ1orQyxjQUFRL0MsTUFBTUEsTUFBSztBQUNuQmhELFlBQU1nRCxNQUFNLDBCQUEwQjtBQUFBLElBQzFDO0FBQUEsRUFDSjtBQUlBLFFBQU02SSxZQUFZQSxDQUFDQyxRQUF1QkMsV0FBZ0I7QUFDdEQ5RyxxQkFBaUI2RyxNQUFNO0FBQ3ZCM0csbUJBQWU0RyxNQUFNO0FBQ3JCaEgsbUJBQWUsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTWlILG9CQUFvQkEsQ0FBQ0MsaUJBQXNCO0FBQzdDLFFBQUksQ0FBQ2pILGNBQWU7QUFFcEIsUUFBSUEsa0JBQWtCLFVBQVU7QUFDNUJrRywyQkFBcUJlLFlBQXVCO0FBQUEsSUFDaEQsV0FBVyxPQUFPakgsa0JBQWtCLFlBQVlBLGNBQWNXLFNBQVMsZUFBZTtBQUNsRnVHLHVCQUFpQmxILGNBQWNtSCxPQUFPLGlCQUFpQkYsWUFBNkI7QUFDcEZDLHVCQUFpQmxILGNBQWNtSCxPQUFPLG1CQUFtQkYsYUFBYTlFLElBQUk7QUFBQSxJQUM5RSxXQUFXLE9BQU9uQyxrQkFBa0IsWUFBWUEsY0FBY1csU0FBUyxZQUFZO0FBQy9FdUcsdUJBQWlCbEgsY0FBY21ILE9BQU8sV0FBV0YsYUFBYXhKLEVBQUU7QUFDaEV5Six1QkFBaUJsSCxjQUFjbUgsT0FBTyxhQUFhRixhQUFhUCxJQUFJO0FBQ3BFUSx1QkFBaUJsSCxjQUFjbUgsT0FBTyxnQkFBZ0JoRyxPQUFPOEYsYUFBYXhKLEVBQUUsQ0FBQztBQUFBLElBQ2pGO0FBQ0FzQyxtQkFBZSxLQUFLO0FBQ3BCRSxxQkFBaUIsSUFBSTtBQUFBLEVBQ3pCO0FBR0EsUUFBTWlILG1CQUFtQkEsQ0FBQ0MsT0FBZUMsT0FBc0M1RixVQUFlO0FBQzFGN0Msb0JBQWdCLENBQUF5SCxTQUFRO0FBQ3BCLFlBQU1pQixjQUFjakIsS0FDZmtCLE9BQU8sQ0FBQ0MsSUFBSUMsTUFBTUEsTUFBTUwsU0FBU0ksR0FBR0Usd0JBQXdCLEtBQUssRUFDakVqRixPQUFPLENBQUNrRixHQUFHSCxPQUFPRyxLQUFLMUcsT0FBT3VHLEdBQUcvRixLQUFLLEtBQUssSUFBSSxDQUFDO0FBQ3JELFlBQU1tRyxvQkFBb0JDLEtBQUtDLElBQUksSUFBSS9JLHdCQUF3QixLQUFLdUksV0FBVztBQUUvRSxhQUFPakIsS0FBSzlFLElBQUksQ0FBQzFELE1BQU00SixNQUFNO0FBQ3pCLFlBQUlBLE1BQU1MLE1BQU8sUUFBT3ZKO0FBQ3hCLGNBQU1rSyxjQUFjLEVBQUUsR0FBR2xLLE1BQU0sQ0FBQ3dKLEtBQUssR0FBRzVGLE1BQU07QUFFOUMsWUFBSTRGLFVBQVUsdUJBQXVCO0FBQ2pDVSxzQkFBWXpGLFVBQVU7QUFDdEJ5RixzQkFBWUMsWUFBWTtBQUN4QkQsc0JBQVlFLGVBQWU7QUFDM0JGLHNCQUFZRyxhQUFhO0FBQ3pCSCxzQkFBWTFGLGVBQWU7QUFDM0IsY0FBSVosVUFBVSxPQUFPO0FBQ2pCc0csd0JBQVlyRyxpQkFBaUI7QUFDN0JxRyx3QkFBWXBHLGVBQWU7QUFDM0JvRyx3QkFBWW5HLGNBQWM7QUFDMUJtRyx3QkFBWWhHLG1CQUFtQjtBQUMvQmdHLHdCQUFZL0YsdUJBQXVCO0FBQUEsVUFDdkM7QUFDQSxjQUFJUCxVQUFVLE9BQU87QUFDakIsa0JBQU0wRyxjQUFjbk07QUFBQUEsY0FDaEJ5RDtBQUFBQSxjQUNBRTtBQUFBQSxjQUNBRTtBQUFBQSxZQUNKO0FBQ0Esa0JBQU11SSxXQUFXbkgsT0FBTzdDLE9BQU9JLGVBQWUsS0FBSztBQUNuRCxrQkFBTTZKLGNBQWN4SixlQUFlLElBQUk0RCxPQUFPLENBQUM2RixLQUFLQyxRQUFRRCxNQUFNRixhQUFhRyxJQUFJQyxRQUFRLEtBQUssTUFBTSxDQUFDO0FBQ3ZHLGtCQUFNQyxpQkFBaUJOLGNBQWNDLFdBQVdDO0FBQ2hETix3QkFBWXRHLFFBQVFvRyxLQUFLQyxJQUFJLEdBQUdELEtBQUthLElBQUlELGdCQUFnQmIsaUJBQWlCLENBQUM7QUFBQSxVQUMvRTtBQUFBLFFBQ0o7QUFDQSxZQUFJUCxVQUFVLFdBQVd4SixLQUFLNkosd0JBQXdCLE9BQU87QUFDekQsZ0JBQU1pQixTQUFTMUgsT0FBT1EsS0FBSyxLQUFLO0FBQ2hDLGNBQUlrSCxTQUFTZixtQkFBbUI7QUFDNUIzTSxrQkFBTTJOLEtBQUssNkRBQTZEbE0sWUFBWWtMLG1CQUFtQixVQUFVLENBQUMsSUFBSTtBQUN0SEcsd0JBQVl0RyxRQUFRbUc7QUFBQUEsVUFDeEI7QUFBQSxRQUNKO0FBQ0EsZUFBT0c7QUFBQUEsTUFDWCxDQUFDO0FBQUEsSUFDTCxDQUFDO0FBQUEsRUFDTDtBQUdBLFFBQU1jLHVCQUF1QixPQUFPekIsT0FBZXhHLFNBQTZCO0FBQzVFLFVBQU0vQyxPQUFPYyxhQUFheUksS0FBSztBQUMvQixVQUFNMEIsZUFBZWxJLFNBQVMsWUFBWS9DLEtBQUtxRSxrQkFBa0JyRSxLQUFLd0U7QUFFdEUsUUFBSSxDQUFDeUcsYUFBYztBQUVuQixRQUFJO0FBQ0EsVUFBSWxJLFNBQVMsV0FBVztBQUNwQixjQUFNbUksUUFBUSxNQUFNcE47QUFBQUEsVUFDaEJTLDBCQUEwQnVFO0FBQUFBLFVBQzFCLENBQUMsRUFBRThGLFdBQVcsUUFBUWhGLE9BQU9xSCxhQUFhLENBQUM7QUFBQSxRQUMvQztBQUNBLFlBQUlDLE9BQU87QUFDUDVCLDJCQUFpQkMsT0FBTyxpQkFBaUIyQixLQUFLO0FBRTlDNUIsMkJBQWlCQyxPQUFPLG1CQUFtQjJCLE1BQU0zRyxJQUFJO0FBQUEsUUFDekQsT0FBTztBQUNIbkgsZ0JBQU0yTixLQUFLLCtCQUErQjtBQUMxQ3pCLDJCQUFpQkMsT0FBTyxpQkFBaUIsSUFBSTtBQUFBLFFBQ2pEO0FBQUEsTUFDSixXQUNTeEcsU0FBUyxRQUFRO0FBRXRCLGNBQU1tSSxRQUFRLE1BQU1wTjtBQUFBQSxVQUNoQmtCLG1CQUFtQjhEO0FBQUFBO0FBQUFBLFVBRW5CLENBQUMsRUFBRThGLFdBQVcsUUFBUWhGLE9BQU9xSCxhQUFhLENBQUM7QUFBQSxRQUMvQztBQUVBLFlBQUlDLE9BQU87QUFDUDVCLDJCQUFpQkMsT0FBTyxXQUFXMkIsTUFBTXJMLEVBQUU7QUFDM0N5SiwyQkFBaUJDLE9BQU8sYUFBYTJCLE1BQU1wQyxJQUFJO0FBRS9DUSwyQkFBaUJDLE9BQU8sZ0JBQWdCMkIsTUFBTTNHLFFBQVFoQixPQUFPMkgsTUFBTXJMLEVBQUUsQ0FBQztBQUFBLFFBQzFFLE9BQU87QUFDSHpDLGdCQUFNMk4sS0FBSyxxQkFBcUI7QUFDaEN6QiwyQkFBaUJDLE9BQU8sV0FBVyxJQUFJO0FBQ3ZDRCwyQkFBaUJDLE9BQU8sYUFBYSxJQUFJO0FBQUEsUUFDN0M7QUFBQSxNQUNKO0FBQUEsSUFFSixTQUFTckcsR0FBRztBQUNSQyxjQUFRL0MsTUFBTThDLENBQUM7QUFBQSxJQUNuQjtBQUFBLEVBQ0o7QUFHQSxRQUFNaUksYUFBYUEsTUFBTTtBQUNyQnBLO0FBQUFBLE1BQWdCLENBQUF5SCxTQUFRO0FBQUEsUUFDcEIsR0FBR0E7QUFBQUEsUUFDSDtBQUFBLFVBQ0k3RSxRQUFRLE9BQU9qRCxLQUFLMEssSUFBSSxDQUFDO0FBQUEsVUFDekJ2QixxQkFBcUI7QUFBQSxVQUNyQnBGLFNBQVM7QUFBQSxVQUNUMEYsV0FBVztBQUFBLFVBQ1hDLGNBQWM7QUFBQSxVQUNkQyxZQUFZO0FBQUEsVUFDWnhHLGdCQUFnQjtBQUFBLFVBQ2hCQyxjQUFjO0FBQUEsVUFDZEMsYUFBYTtBQUFBLFVBQ2JDLGFBQWE7QUFBQSxVQUNiRSxrQkFBa0I7QUFBQSxVQUNsQkMsc0JBQXNCO0FBQUEsVUFDdEJQLE9BQU87QUFBQSxVQUNQeUgsV0FBVztBQUFBLFVBQ1gvRyxlQUFlO0FBQUEsVUFDZkQsaUJBQWlCO0FBQUEsVUFDakJHLGNBQWM7QUFBQSxRQUNsQjtBQUFBLE1BQUM7QUFBQSxJQUNKO0FBQUEsRUFDTDtBQUVBLFFBQU04RyxhQUFhQSxDQUFDL0IsVUFBa0I7QUFDbEN4SSxvQkFBZ0IsQ0FBQXlILFNBQVFBLEtBQUtrQixPQUFPLENBQUM2QixHQUFHM0IsTUFBTUEsTUFBTUwsS0FBSyxDQUFDO0FBQUEsRUFDOUQ7QUFFQSxRQUFNaUMsb0JBQW9CQSxDQUFDQyxXQUFtQkMsV0FBNEI7QUFDdEUsVUFBTUMsZ0JBQWdCdkksT0FBT3NJLE1BQU0sS0FBSztBQUN4QzdKLHNCQUFrQixDQUFBMkcsVUFBUztBQUFBLE1BQ3ZCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2lELFNBQVMsR0FBR0U7QUFBQUEsSUFDakIsRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNQyxtQ0FBbUNBLENBQ3JDdkYsUUFDQWtCLFNBQ0EzRCxPQUNBaUksV0FDQztBQUNELFVBQU1DLFVBQVV6TSw0QkFBNEJ1RSxPQUFPMkQsT0FBTztBQUMxRCxVQUFNd0UsZUFBZTNJLE9BQU9RLEtBQUssS0FBSztBQUN0QyxRQUFJa0ksWUFBWUMsY0FBYztBQUMxQjNPLFlBQU0yTixLQUFLLHVDQUF1Q2xNLFlBQVkwSSxTQUFTLFVBQVUsQ0FBQyxHQUFHO0FBQUEsSUFDekY7QUFDQXNFLFdBQU8sQ0FBQXJELFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNuQyxNQUFNLEdBQUd5RixRQUFRLEVBQUU7QUFBQSxFQUNuRDtBQUVBLFFBQU1FLCtCQUErQkEsQ0FBQzNGLFFBQWdCekMsVUFBMkI7QUFDN0UsVUFBTXFJLE9BQU8zSyxtQkFBbUIyRyxLQUFLLENBQUFKLE1BQUtBLEVBQUVoSSxPQUFPd0csTUFBTTtBQUN6RCxRQUFJLENBQUM0RixLQUFNO0FBQ1hMO0FBQUFBLE1BQ0l2RjtBQUFBQSxNQUNBL0csd0JBQXdCMk0sS0FBSzFFLE9BQU87QUFBQSxNQUNwQzNEO0FBQUFBLE1BQ0E3QjtBQUFBQSxJQUNKO0FBQUEsRUFDSjtBQUVBLFFBQU1tSyxrQ0FBa0NBLENBQUM3RixRQUFnQnpDLFVBQTJCO0FBQ2hGLFVBQU1xSSxPQUFPekssc0JBQXNCeUcsS0FBSyxDQUFBSixNQUFLQSxFQUFFaEksT0FBT3dHLE1BQU07QUFDNUQsUUFBSSxDQUFDNEYsS0FBTTtBQUNYTDtBQUFBQSxNQUNJdkY7QUFBQUEsTUFDQTdHLG1CQUFtQnlNLEtBQUtsSixNQUFNa0osS0FBSzFFLE9BQU87QUFBQSxNQUMxQzNEO0FBQUFBLE1BQ0EzQjtBQUFBQSxJQUNKO0FBQUEsRUFDSjtBQUVBLFFBQU1rSyxpQkFBaUJuUCxRQUFRLE1BQWtDO0FBQzdELFdBQU9zRSxtQkFBbUJvQyxJQUFJLENBQUF1SSxTQUFRO0FBQ2xDLFlBQU0xRSxVQUFVakksd0JBQXdCMk0sS0FBSzFFLE9BQU87QUFDcEQsWUFBTTZFLFFBQVE3TSxzQkFBc0IwTSxLQUFLSSxZQUFZO0FBQ3JELFlBQU1DLFlBQVlMLEtBQUtsSCxlQUFld0gsa0JBQWtCTixLQUFLTyxrQkFBa0I7QUFDL0UsYUFBTztBQUFBLFFBQ0gzTSxJQUFJb00sS0FBS3BNO0FBQUFBLFFBQ1Q0TSxVQUFVSDtBQUFBQSxRQUNWL0U7QUFBQUEsUUFDQW1GLE1BQU03TixZQUFZb04sS0FBS1UsWUFBWSxNQUFNO0FBQUEsUUFDekNMO0FBQUFBLFFBQ0FGO0FBQUFBLFFBQ0FRLGdCQUFnQnJGO0FBQUFBLE1BQ3BCO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTCxHQUFHLENBQUNqRyxrQkFBa0IsQ0FBQztBQUV2QixRQUFNdUwsb0JBQW9CN1AsUUFBUSxNQUFrQztBQUNoRSxXQUFPd0Usc0JBQXNCa0MsSUFBSSxDQUFBdUksU0FBUTtBQUNyQyxZQUFNMUUsVUFBVS9ILG1CQUFtQnlNLEtBQUtsSixNQUFNa0osS0FBSzFFLE9BQU87QUFDMUQsWUFBTTZFLFFBQVEzTSxpQkFBaUJ3TSxLQUFLbEosTUFBTWtKLEtBQUtJLFlBQVk7QUFDM0QsWUFBTUMsWUFBWUwsS0FBS2xILGVBQWV3SCxrQkFBa0JOLEtBQUtPLGtCQUFrQjtBQUMvRSxhQUFPO0FBQUEsUUFDSDNNLElBQUlvTSxLQUFLcE07QUFBQUEsUUFDVDRNLFVBQVVIO0FBQUFBLFFBQ1YvRTtBQUFBQSxRQUNBbUYsTUFBTTdOLFlBQVlvTixLQUFLVSxZQUFZLE1BQU07QUFBQSxRQUN6Q0w7QUFBQUEsUUFDQUY7QUFBQUEsUUFDQVEsZ0JBQWdCckY7QUFBQUEsUUFDaEJ4RSxNQUFNa0osS0FBS2xKO0FBQUFBLE1BQ2Y7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMLEdBQUcsQ0FBQ3ZCLHFCQUFxQixDQUFDO0FBRzFCLFFBQU1zTCxTQUFTOVAsUUFBUSxNQUFNO0FBQ3pCLFVBQU0rUCxzQkFBc0IxTyx3QkFBd0J1RCxjQUFjO0FBQ2xFLFVBQU1vTCx5QkFBeUIzTyx3QkFBd0J5RCx3QkFBd0I7QUFDL0UsVUFBTW1MLDRCQUE0QjVPLHdCQUF3QjJELDJCQUEyQjtBQUNyRixVQUFNc0ksY0FBY25NO0FBQUFBLE1BQ2hCeUQ7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFDSjtBQUdBLFVBQU11SSxXQUFXbkgsT0FBTzdDLE9BQU9JLGVBQWUsS0FBSztBQUVuRCxVQUFNdU0sY0FBYzNDO0FBR3BCLFVBQU00QyxlQUE2Qm5NLFlBQVkwQyxJQUFJLENBQUFnSCxRQUFPO0FBQ3RELFlBQU0wQyxZQUFhRixlQUFleEMsSUFBSUMsT0FBTztBQUM3QyxhQUFPO0FBQUEsUUFDSDBDLFFBQVEzQyxJQUFJN0s7QUFBQUEsUUFDWnlOLFVBQVU1QyxJQUFJNUI7QUFBQUEsUUFDZDZCLE1BQU1ELElBQUlDO0FBQUFBLFFBQ1ZlLFFBQVEwQjtBQUFBQSxRQUNSRyxrQkFBa0I3QyxJQUFJNkM7QUFBQUEsTUFDMUI7QUFBQSxJQUNKLENBQUM7QUFDRCxVQUFNL0MsYUFBYTJDLGFBQWF2SSxPQUFPLENBQUM2RixLQUFLQyxRQUFRRCxNQUFNQyxJQUFJZ0IsUUFBUSxDQUFDO0FBR3hFLFVBQU1kLGlCQUFpQk4sY0FBY0MsV0FBV0M7QUFHaEQsVUFBTWdELFlBQVkxTSxhQUFhOEQ7QUFBQUEsTUFDM0IsQ0FBQzZGLEtBQWF6SyxTQUFrQ3lLLE9BQU9ySCxPQUFPcEQsS0FBSzRELEtBQUssS0FBSztBQUFBLE1BQUk7QUFBQSxJQUNyRjtBQUVBLFVBQU02SixpQkFBaUJ6RCxLQUFLMEQsT0FBTzlDLGlCQUFpQjRDLGFBQWEsR0FBRyxJQUFJO0FBRXhFLFdBQU87QUFBQSxNQUNIbEQ7QUFBQUEsTUFDQXlDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0ExQztBQUFBQSxNQUNBNEM7QUFBQUEsTUFDQTNDO0FBQUFBLE1BQ0FJO0FBQUFBLE1BQ0E0QztBQUFBQSxNQUNBQztBQUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUM3TCxnQkFBZ0JFLDBCQUEwQkUsNkJBQTZCaEIsYUFBYVQsT0FBT0ksaUJBQWlCRyxZQUFZLENBQUM7QUFHN0gsUUFBTTZNLGtDQUFrQ0EsQ0FBQ3BFLFVBQWtCO0FBQ3ZELFVBQU1xRSxnQkFBZ0JkLE9BQU94QztBQUM3QixVQUFNdUQsV0FBVy9NLGFBQWE4RDtBQUFBQSxNQUMxQixDQUFDa0YsR0FBR0gsSUFBSUMsTUFBT0EsTUFBTUwsUUFBUU8sSUFBSUEsS0FBSzFHLE9BQU91RyxHQUFHL0YsS0FBSyxLQUFLO0FBQUEsTUFDMUQ7QUFBQSxJQUNKO0FBQ0EsUUFBSWtLLFFBQVE5RCxLQUFLMEQsT0FBT0UsZ0JBQWdCQyxZQUFZLEdBQUcsSUFBSTtBQUMzRCxRQUFJQyxRQUFRLEdBQUc7QUFDWDFRLFlBQU0yTjtBQUFBQSxRQUNGO0FBQUEsTUFDSjtBQUNBK0MsY0FBUTtBQUFBLElBQ1o7QUFDQXhFLHFCQUFpQkMsT0FBTyxTQUFTdUUsS0FBSztBQUFBLEVBQzFDO0FBRUEsUUFBTUMsc0JBQXNCOVE7QUFBQUEsSUFBWSxZQUFZO0FBQ2hELFlBQU0rUSxjQUFjbE4sYUFBYTRDLElBQUksQ0FBQTFELFNBQVE7QUFDekMsY0FBTWlPLE9BQWdDO0FBQUEsVUFDbENwTyxJQUFLRyxLQUFhSCxNQUFNbUo7QUFBQUEsVUFDeEJhLHFCQUFxQjdKLEtBQUs2SjtBQUFBQSxVQUMxQnBGLFNBQVN6RSxLQUFLeUU7QUFBQUEsVUFDZDJGLGNBQWNwSyxLQUFLb0ssZ0JBQWdCO0FBQUEsVUFDbkNDLFlBQVlySyxLQUFLcUssY0FBYztBQUFBLFVBQy9CekcsT0FBT1IsT0FBT3BELEtBQUs0RCxLQUFLLEtBQUs7QUFBQSxVQUM3QjJKLGtCQUFrQnZOLEtBQUtzRSxlQUFlekUsTUFBTTtBQUFBLFFBQ2hEO0FBQ0EsWUFBSUcsS0FBSzZKLHdCQUF3QixPQUFPO0FBQ3BDb0UsZUFBS3BLLGlCQUFpQjdELEtBQUs2RCxrQkFBa0I7QUFDN0NvSyxlQUFLbkssZUFBZTlELEtBQUs4RCxnQkFBZ0I7QUFDekNtSyxlQUFLbEssY0FBYy9ELEtBQUsrRCxlQUFlO0FBQ3ZDa0ssZUFBS2pLLGNBQWNDLFFBQVFqRSxLQUFLZ0UsV0FBVztBQUMzQ2lLLGVBQUsvSixtQkFBbUJsRSxLQUFLa0Usb0JBQW9CO0FBQUEsUUFDckQ7QUFDQSxZQUFJbEUsS0FBSzZKLHdCQUF3QixPQUFPO0FBQ3BDLGdCQUFNcUUsTUFBTWxPLEtBQUtrRSxvQkFBb0IsT0FBT1gsT0FBT3ZELEtBQUtrRSxnQkFBZ0IsRUFBRUUsS0FBSyxJQUFJO0FBQ25GNkosZUFBSy9KLG1CQUFtQmdLLFFBQVEsS0FBS0EsTUFBTTtBQUFBLFFBQy9DO0FBQ0EsZUFBT0Q7QUFBQUEsTUFDWCxDQUFDO0FBRUQsWUFBTUUsd0JBQXdCbFEsNEJBQTRCMkQsY0FBYztBQUN4RSxZQUFNcUQsdUJBQXVCakgsK0JBQStCOEQsd0JBQXdCO0FBQ3BGLFlBQU1zRCwwQkFBMEJsSCx1Q0FBdUM4RCwyQkFBMkI7QUFFbEcsWUFBTW9NLGNBQWN0QixPQUFPSyxhQUFhekQsT0FBTyxDQUFBZ0IsUUFBT0EsSUFBSWdCLFNBQVMsQ0FBQztBQUVwRSxZQUFNMkMsYUFBYTtBQUFBLFFBQ2YsR0FBRzlOO0FBQUFBLFFBQ0h1RixXQUFXdkYsT0FBT3VGO0FBQUFBLFFBQ2xCd0ksY0FBYy9OLE9BQU9FO0FBQUFBLFFBQ3JCOE4sY0FBY3pCLE9BQU94QztBQUFBQSxRQUNyQkMsVUFBVXVDLE9BQU92QztBQUFBQSxRQUNqQjhCLGNBQWNTLE9BQU9VO0FBQUFBLFFBQ3JCOUgsT0FBTzBJO0FBQUFBLFFBQ1AzSyxPQUFPdUs7QUFBQUEsUUFDUHJKLGtCQUFrQndKO0FBQUFBLFFBQ2xCbEo7QUFBQUEsUUFDQUc7QUFBQUEsUUFDQW9KLGFBQWE7QUFBQSxNQUNqQjtBQUVBLGFBQU9ILFdBQVdoTDtBQUNsQixhQUFPZ0wsV0FBVy9KO0FBRWxCN0Isa0JBQVksSUFBSTtBQUNoQixVQUFJO0FBQ0EsY0FBTXBDLFNBQVNnTyxVQUFpRDtBQUNoRSxjQUFNSSxZQUFhL1EsWUFBb0IwQztBQUN2QyxZQUFJLENBQUNxTyxXQUFXO0FBQ1pyUixnQkFBTXlMLFFBQVEsOEJBQThCO0FBQzVDL0ksbUJBQVNKLGtCQUFrQjNCLHNCQUFzQjJRLFNBQVMsQ0FBQztBQUFBLFFBQy9EO0FBQUEsTUFDSixTQUFTRCxXQUFvQjtBQUN6QnRMLGdCQUFRL0MsTUFBTSxxQkFBcUJxTyxTQUFTO0FBQUEsTUFDaEQsVUFBQztBQUNHaE0sb0JBQVksS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDSjtBQUFBLElBQUc7QUFBQSxNQUNDM0I7QUFBQUEsTUFDQWM7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQThLLE9BQU9LO0FBQUFBLE1BQ1BMLE9BQU94QztBQUFBQSxNQUNQd0MsT0FBT3ZDO0FBQUFBLE1BQ1B1QyxPQUFPVTtBQUFBQSxNQUNQak47QUFBQUEsTUFDQUY7QUFBQUEsTUFDQVA7QUFBQUEsSUFBUTtBQUFBLEVBQ1g7QUFHRCxRQUFNNk8sYUFBYSxZQUFZO0FBQzNCLFFBQUksQ0FBQ3BPLE9BQU91RixXQUFXO0FBQ25CMUksWUFBTWdELE1BQU0sOEJBQThCO0FBQzFDO0FBQUEsSUFDSjtBQUVBLGVBQVdKLFFBQVFjLGNBQWM7QUFDN0IsVUFBSWQsS0FBSzZKLHdCQUF3QixTQUFTLENBQUM3SixLQUFLeUUsU0FBUztBQUNyRHJILGNBQU1nRCxNQUFNLGdEQUFnRDtBQUM1RDtBQUFBLE1BQ0o7QUFDQSxVQUFJSixLQUFLNkosd0JBQXdCLFNBQVN6RyxPQUFPcEQsS0FBSzRELEtBQUssSUFBSSxHQUFHO0FBQzlELGNBQU1zSyxNQUFNbE8sS0FBS2tFLG9CQUFvQixPQUFPWCxPQUFPdkQsS0FBS2tFLGdCQUFnQixFQUFFRSxLQUFLLElBQUk7QUFDbkYsWUFBSSxDQUFDOEosS0FBSztBQUNOOVEsZ0JBQU1nRCxNQUFNLGtFQUFrRTtBQUM5RTtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQ0EsVUFBSUosS0FBSzZKLHdCQUF3QixTQUFTekcsT0FBT3BELEtBQUs0RCxLQUFLLElBQUksR0FBRztBQUM5RCxjQUFNZ0wsV0FBVzVPLEtBQUtxSyxjQUFjLE9BQU85RyxPQUFPdkQsS0FBS3FLLFVBQVUsRUFBRWpHLEtBQUssSUFBSTtBQUM1RSxZQUFJLENBQUN3SyxVQUFVO0FBQ1h4UixnQkFBTWdELE1BQU0saURBQWlEO0FBQzdEO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxVQUFJSixLQUFLNkosd0JBQXdCLFNBQVM3SixLQUFLbUUseUJBQXlCLEtBQU07QUFDOUUsWUFBTTBLLFdBQVc3TyxLQUFLK0QsZUFBZSxJQUFJSyxLQUFLO0FBQzlDLFVBQUksQ0FBQ3lLLFNBQVM7QUFDVnpSLGNBQU1nRCxNQUFNLCtEQUErRDtBQUMzRTtBQUFBLE1BQ0o7QUFDQSxVQUFJLENBQUNsQixhQUFhLFFBQVEyUCxPQUFPLEdBQUc7QUFDaEMsY0FBTUMsT0FBTzNQLFFBQVEsTUFBTTtBQUMzQi9CLGNBQU1nRCxNQUFNME8sTUFBTUMsZ0JBQWdCLDhEQUE4RDtBQUNoRztBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBRUEsVUFBTUMscUJBQXFCL1EsNEJBQTRCMkQsY0FBYyxFQUFFbUYsU0FBUztBQUNoRixVQUFNa0ksbUJBQW1CN1EsMkJBQTJCMEMsWUFBWSxLQUFLLENBQUNrTztBQUN0RSxVQUFNRSxZQUFZcEMsT0FBT1c7QUFDekIsUUFBSSxDQUFDd0Isa0JBQWtCO0FBQ25CLFVBQUlDLFlBQVksTUFBTTtBQUNsQjlSLGNBQU1nRCxNQUFNLGdCQUFnQnZCLFlBQVlxUSxXQUFXLFVBQVUsQ0FBQyx1QkFBdUJyUSxZQUFZaU8sT0FBT1UsV0FBVyxVQUFVLENBQUMsb0NBQW9DM08sWUFBWWlPLE9BQU9sQyxnQkFBZ0IsVUFBVSxDQUFDLElBQUk7QUFDcE47QUFBQSxNQUNKO0FBQ0EsVUFBSXNFLFlBQVksT0FBTztBQUNuQixjQUFNQyxnQkFBZ0JuRixLQUFLb0YsSUFBSUYsU0FBUztBQUN4QzVPLDhCQUFzQjtBQUFBLFVBQ2xCK08sT0FBTztBQUFBLFVBQ1BDLFNBQ0kscUhBQXFIelEsWUFBWXNRLGVBQWUsVUFBVSxDQUFDO0FBQUEsVUFDL0pJLFdBQVdBLE1BQU07QUFDYixpQkFBS3hCLG9CQUFvQjtBQUFBLFVBQzdCO0FBQUEsUUFDSixDQUFDO0FBQ0Q7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUVBLFVBQU1BLG9CQUFvQjtBQUFBLEVBQzlCO0FBRUEsTUFBSTVOLGVBQWVKLFNBQVMsT0FBUSxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUMxRCxNQUFJSyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUF3QkE7QUFBQUEsT0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0RDtBQUc5RSxRQUFNb1AsYUFBYTtBQUduQixTQUNJLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLDJCQUFDLFFBQUcsV0FBVSw4QkFDVHpQO0FBQUFBLGVBQVMsV0FBVyxVQUFVO0FBQUEsTUFBUztBQUFBLE1BQUVoQyxzQkFBc0IwUjtBQUFBQSxTQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxvRUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNsRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBVzdPO0FBQUFBLFlBQ1gsV0FBV0wsT0FBTzhDLFFBQVF5RixRQUFRO0FBQUEsWUFDbEMsY0FBY2pJO0FBQUFBLFlBQ2QsY0FBYzZIO0FBQUFBLFlBQ2QsZUFBZSxNQUFNTyxVQUFVLFVBQVUzSyxvQkFBb0I7QUFBQSxZQUM3RCxjQUFjLE1BQU07QUFDaEJrQyx3QkFBVSxDQUFBZ0ksVUFBUyxFQUFFLEdBQUdBLE1BQU0xQyxXQUFXa0QsUUFBVzNGLFFBQVEyRixPQUFVLEVBQUU7QUFDeEVuSSxpQ0FBbUIsRUFBRTtBQUNyQlEscUNBQXVCLEVBQUU7QUFDekJFLG9DQUFzQixFQUFFO0FBQ3hCRSx1Q0FBeUIsRUFBRTtBQUMzQkksZ0NBQWtCLENBQUMsQ0FBQztBQUNwQkUsMENBQTRCLENBQUMsQ0FBQztBQUM5QkUsNkNBQStCLENBQUMsQ0FBQztBQUNqQ2hCLDZCQUFlLEVBQUU7QUFDakJFLHNDQUF3QixDQUFDO0FBQUEsWUFDN0I7QUFBQSxZQUNBLFVBQVVwQixTQUFTO0FBQUE7QUFBQSxVQWxCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0I4QjtBQUFBLFFBRzdCbUIsdUJBQXVCLEtBQ3BCLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFVBQThCckMsWUFBWXFDLHNCQUFzQixVQUFVO0FBQUEsYUFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFdBeEI5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFDQSx1QkFBQyxTQUNHO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFNBQVE7QUFBQSxZQUNSLFdBQVU7QUFBQSxZQUEwQztBQUFBO0FBQUEsVUFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRXNFO0FBQUEsUUFDdEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLE9BQU9YLE9BQU9FO0FBQUFBLFlBQ2QsVUFBVSxDQUFBeUMsTUFBSzFDLFVBQVUsQ0FBQWdJLFVBQVMsRUFBRSxHQUFHQSxNQUFNL0gsaUJBQWlCeUMsRUFBRWdHLE9BQU90RixNQUFNLEVBQUU7QUFBQSxZQUMvRSxXQUFXNEw7QUFBQUEsWUFBWSxjQUFhO0FBQUE7QUFBQSxVQUx4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLNkM7QUFBQSxXQVRqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsNEJBQTJCLDRDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsU0FBSSxXQUFVLDRCQUNWOU4sbUNBQXlCLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxJQUNyQyx1QkFBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHlEQUF3RCx1QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkU7QUFBQSxVQUM3RSx1QkFBQyxRQUFHLFdBQVUseURBQXdELHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLFVBQzNFLHVCQUFDLFFBQUcsV0FBVSwwREFBeUQscUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxxQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RSx1QkFBQyxRQUFHLFdBQVUsK0RBQThELCtCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLGFBTC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNaTiw4QkFBb0IyRixTQUFTLElBQUkzRixvQkFBb0JzQztBQUFBQSxVQUFJLENBQUF5RCxRQUN0RCx1QkFBQyxRQUNHO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFCQUFxQkEsY0FBSW9GLGtCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFFBQUcsV0FBVSxxQkFBcUIxTixzQkFBWXNJLElBQUl1SSxjQUFjLE1BQU0sS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDN1Esc0JBQVlzSSxJQUFJa0YsY0FBYyxVQUFVLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsUUFBRyxXQUFVLDRDQUE0Q3hOLHNCQUFZc0ksSUFBSUksU0FBUyxVQUFVLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsWUFDL0YsdUJBQUMsUUFBRyxXQUFVLGFBQ1YsaUNBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLE9BQU8zRixlQUFldUYsSUFBSXRILEVBQUU7QUFBQSxrQkFDNUIsVUFBVSxDQUFBOFAsUUFBT25FLGtCQUFrQnJFLElBQUl0SCxJQUFJOFAsR0FBRztBQUFBLGtCQUM5QyxRQUFRLE1BQU07QUFDViwwQkFBTUMsZ0JBQWdCeE0sT0FBT3hCLGVBQWV1RixJQUFJdEgsRUFBRSxDQUFDLEtBQUs7QUFDeEQsMEJBQU0wSCxVQUFVbkUsT0FBTytELElBQUlJLE9BQU8sS0FBSztBQUN2Qyx3QkFBSXFJLGdCQUFnQnJJLFNBQVM7QUFDekJuSyw0QkFBTTJOLEtBQUssc0JBQXNCbE0sWUFBWStRLGVBQWUsVUFBVSxDQUFDLGdDQUFnQy9RLFlBQVkwSSxTQUFTLFVBQVUsQ0FBQyxHQUFHO0FBQzFJaUUsd0NBQWtCckUsSUFBSXRILElBQUkwSCxPQUFPO0FBQUEsb0JBQ3JDO0FBQUEsa0JBQ0o7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBO0FBQUEsZ0JBYmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYTBHO0FBQUEsY0FFMUc7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTWlFLGtCQUFrQnJFLElBQUl0SCxJQUFJdUQsT0FBTytELElBQUlJLE9BQU8sS0FBSyxDQUFDO0FBQUEsa0JBQ2pFLFdBQVU7QUFBQSxrQkFDVixPQUFNO0FBQUEsa0JBQ04sY0FBWSwyQkFBMkIxSSxZQUFZc0ksSUFBSUksU0FBUyxVQUFVLENBQUMsa0JBQWtCSixJQUFJb0YsY0FBYztBQUFBLGtCQUUvRyxpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQSxLQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLGVBaENLcEYsSUFBSXRILElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxRQUNILElBQ0csdUJBQUMsUUFDRyxpQ0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLCtDQUNyQlUsaUJBQU91RixZQUFZLCtDQUErQyxrREFEdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBekNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQSxRQUVDMUUsb0JBQW9CMkYsU0FBUyxLQUMxQix1QkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSw4Q0FBNkMsK0JBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFDdEYsdUJBQUMsUUFBRyxXQUFVLDBDQUEwQ2xJLHNCQUFZaU8sT0FBT0MscUJBQXFCLFVBQVUsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxhQUZoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQTdEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0RBLEtBakVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtRUE7QUFBQSxTQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csT0FBTTtBQUFBLFFBQ04sTUFBTVo7QUFBQUEsUUFDTixnQkFBZ0JySztBQUFBQSxRQUNoQixhQUFhZ0wsT0FBT0U7QUFBQUEsUUFDcEIsZ0JBQWdCaEI7QUFBQUEsUUFDaEIsZUFBZSxDQUFDM0YsUUFBUWtCLFlBQVl5RSw2QkFBNkIzRixRQUFRa0IsT0FBTztBQUFBO0FBQUEsTUFOcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTXNGO0FBQUEsSUFHdEY7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE9BQU07QUFBQSxRQUNOLE1BQU1zRjtBQUFBQSxRQUNOLGdCQUFnQjdLO0FBQUFBLFFBQ2hCLGFBQWE4SyxPQUFPRztBQUFBQSxRQUNwQjtBQUFBLFFBQ0EsZ0JBQWdCZjtBQUFBQSxRQUNoQixlQUFlLENBQUM3RixRQUFRa0IsWUFBWTJFLGdDQUFnQzdGLFFBQVFrQixPQUFPO0FBQUE7QUFBQSxNQVB2RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPeUY7QUFBQSxJQUl6Rix1QkFBQyxTQUFJLFdBQVUsOEJBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUJBQXNCLDhCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUzRELFlBQVksV0FBVSxrSEFDakQ7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBRztBQUFBLGFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQ3JLLGFBQWE0QztBQUFBQSxRQUFJLENBQUMxRCxNQUFNdUosVUFDckJ2SixLQUFLNkosd0JBQXdCLFFBQ3pCLHVCQUFDLFNBQXNCLFdBQVUsNERBQzdCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsbUNBQUMsV0FBTSxTQUFTLHNCQUFzQk4sS0FBSyxJQUFJLFdBQVUscUNBQW9DLHFCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2xHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csSUFBSSxzQkFBc0JBLEtBQUs7QUFBQSxnQkFDL0IsT0FBT3ZKLEtBQUs2SjtBQUFBQSxnQkFDWixVQUFVLENBQUEzRyxNQUFLb0csaUJBQWlCQyxPQUFPLHVCQUF1QnJHLEVBQUVnRyxPQUFPdEYsS0FBSztBQUFBLGdCQUM1RSxXQUFXNEw7QUFBQUEsZ0JBRVg7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sT0FBTSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEI7QUFBQSxrQkFDNUIsdUJBQUMsWUFBTyxPQUFNLE9BQU0sc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBCO0FBQUEsa0JBQzFCLHVCQUFDLFlBQU8sT0FBTSxPQUFNLDZCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUNqQyx1QkFBQyxZQUFPLE9BQU0sT0FBTSx5QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDN0IsdUJBQUMsWUFBTyxPQUFNLE9BQU0seUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUEsa0JBQzVCdE8sdUJBQXVCLEtBQ3BCLHVCQUFDLFlBQU8sT0FBTSxPQUFNO0FBQUE7QUFBQSxvQkFBbUJyQyxZQUFZcUMsc0JBQXNCLFVBQVU7QUFBQSxvQkFBRTtBQUFBLHVCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBO0FBQUE7QUFBQSxjQVo5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHNCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV2xCLEtBQUtxRTtBQUFBQSxnQkFDaEIsV0FBV3JFLEtBQUtzRSxlQUFld0UsUUFBUTtBQUFBLGdCQUN2QyxjQUFjLENBQUMrRyxRQUFRdkcsaUJBQWlCQyxPQUFPLG1CQUFtQnNHLEdBQUc7QUFBQSxnQkFDckUsY0FBYyxNQUFNN0UscUJBQXFCekIsT0FBTyxTQUFTO0FBQUEsZ0JBQ3pELGVBQWUsTUFBTU4sVUFBVSxFQUFFbEcsTUFBTSxlQUFld0csTUFBTSxHQUFHaEwseUJBQXlCO0FBQUEsZ0JBQ3hGLGNBQWMsTUFBTTtBQUNoQitLLG1DQUFpQkMsT0FBTyxpQkFBaUIsSUFBSTtBQUM3Q0QsbUNBQWlCQyxPQUFPLG1CQUFtQixFQUFFO0FBQUEsZ0JBQ2pEO0FBQUE7QUFBQSxjQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNNO0FBQUEsZUFYVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxXQUFNLFNBQVMsaUJBQWlCQSxLQUFLLElBQUksV0FBVSxxQ0FBb0MsaUNBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsWUFDekc7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxJQUFJLGlCQUFpQkEsS0FBSztBQUFBLGdCQUMxQixPQUFPdkosS0FBS2tFLG9CQUFvQixPQUFPWCxPQUFPdkQsS0FBS2tFLGdCQUFnQixJQUFJO0FBQUEsZ0JBQ3ZFLFVBQVUsQ0FBQWhCLE1BQ05vRztBQUFBQSxrQkFDSUM7QUFBQUEsa0JBQ0E7QUFBQSxrQkFDQXJHLEVBQUVnRyxPQUFPdEYsVUFBVSxLQUFLLE9BQU9WLEVBQUVnRyxPQUFPdEY7QUFBQUEsZ0JBQzVDO0FBQUEsZ0JBRUosV0FBVzRMO0FBQUFBLGdCQUVYO0FBQUEseUNBQUMsWUFBTyxPQUFNLElBQUcsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRCO0FBQUEsa0JBQzNCOU0sZUFBZWdCO0FBQUFBLG9CQUFJLENBQUFnSCxRQUNoQix1QkFBQyxZQUFvQixPQUFPbkgsT0FBT21ILElBQUk3SyxFQUFFLEdBQ3BDNkssY0FBSTVCLFFBREk0QixJQUFJN0ssSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNIO0FBQUE7QUFBQTtBQUFBLGNBakJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtCQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxXQUFNLFNBQVMsWUFBWTBKLEtBQUssSUFBSSxXQUFVLHFDQUFvQyw4QkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUc7QUFBQSxZQUNqRztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLElBQUksWUFBWUEsS0FBSztBQUFBLGdCQUNyQixNQUFLO0FBQUEsZ0JBQ0wsT0FBT3ZKLEtBQUtvSyxnQkFBZ0I7QUFBQSxnQkFDNUIsVUFBVSxDQUFBbEgsTUFBS29HLGlCQUFpQkMsT0FBTyxnQkFBZ0JyRyxFQUFFZ0csT0FBT3RGLEtBQUs7QUFBQSxnQkFDckUsV0FBVzRMO0FBQUFBLGdCQUNYLFdBQVc7QUFBQSxnQkFBSyxjQUFhO0FBQUE7QUFBQSxjQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNc0M7QUFBQSxlQVIxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHFCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxPQUFPeFAsS0FBSzREO0FBQUFBLGtCQUNaLFVBQVUsQ0FBQStMLFFBQU9yRyxpQkFBaUJDLE9BQU8sU0FBU29HLEdBQUc7QUFBQSxrQkFDckQsYUFBWTtBQUFBLGtCQUNaLFdBQVcsR0FBR0gsVUFBVTtBQUFBO0FBQUEsZ0JBTDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUt5RDtBQUFBLGNBRXpEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU03QixnQ0FBZ0NwRSxLQUFLO0FBQUEsa0JBQ3BELFVBQVV1RCxPQUFPeEMsZUFBZTtBQUFBLGtCQUNoQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUNOLGNBQVc7QUFBQSxrQkFFWCxpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csY0FBVztBQUFBLGtCQUNYLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU1nQixXQUFXL0IsS0FBSztBQUFBLGtCQUMvQixXQUFVO0FBQUEsa0JBRVYsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFRO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLGVBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsYUE5Rk12SixLQUFLMkQsUUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0ZBLElBRUEsdUJBQUMsU0FBc0IsV0FBVSw0REFFN0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFNBQVMsa0JBQWtCNEYsS0FBSztBQUFBLGdCQUNoQyxXQUFVO0FBQUEsZ0JBQW9DO0FBQUE7QUFBQSxjQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFdUQ7QUFBQSxZQUN2RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE9BQU92SixLQUFLNko7QUFBQUEsZ0JBQ1osVUFBVSxDQUFBM0csTUFBS29HLGlCQUFpQkMsT0FBTyx1QkFBdUJyRyxFQUFFZ0csT0FBT3RGLEtBQUs7QUFBQSxnQkFDNUUsV0FBVzRMO0FBQUFBLGdCQUNYLElBQUksa0JBQWtCakcsS0FBSztBQUFBLGdCQUUzQjtBQUFBLHlDQUFDLFlBQU8sT0FBTSxPQUFNLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLGtCQUM1Qix1QkFBQyxZQUFPLE9BQU0sT0FBTSxzQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQSxrQkFDMUIsdUJBQUMsWUFBTyxPQUFNLE9BQU0sNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQ2pDLHVCQUFDLFlBQU8sT0FBTSxPQUFNLHlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxZQUFPLE9BQU0sT0FBTSx5QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDN0IsdUJBQUMsWUFBTyxPQUFNLE9BQU0sc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBCO0FBQUEsa0JBQ3pCckksdUJBQXVCLEtBQ3BCLHVCQUFDLFlBQU8sT0FBTSxPQUFNO0FBQUE7QUFBQSxvQkFBbUJyQyxZQUFZcUMsc0JBQXNCLFVBQVU7QUFBQSxvQkFBRTtBQUFBLHVCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBO0FBQUE7QUFBQSxjQWI5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFlQTtBQUFBLGVBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHNCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBV2xCLEtBQUtxRTtBQUFBQSxnQkFDaEIsV0FBV3JFLEtBQUtzRSxlQUFld0UsUUFBUTtBQUFBLGdCQUN2QyxjQUFjLENBQUMrRyxRQUFRdkcsaUJBQWlCQyxPQUFPLG1CQUFtQnNHLEdBQUc7QUFBQSxnQkFDckUsY0FBYyxNQUFNN0UscUJBQXFCekIsT0FBTyxTQUFTO0FBQUEsZ0JBQ3pELGVBQWUsTUFBTU4sVUFBVSxFQUFFbEcsTUFBTSxlQUFld0csTUFBTSxHQUFHaEwseUJBQXlCO0FBQUEsZ0JBQ3hGLGNBQWMsTUFBTTtBQUNoQitLLG1DQUFpQkMsT0FBTyxpQkFBaUIsSUFBSTtBQUM3Q0QsbUNBQWlCQyxPQUFPLG1CQUFtQixFQUFFO0FBQUEsZ0JBQ2pEO0FBQUE7QUFBQSxjQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNNO0FBQUEsZUFYVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1gsaUNBQUMsU0FBSSxXQUFXdkosS0FBSzZKLHdCQUF3QixRQUFRLGNBQWMsSUFDL0Q7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHFCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBVzdKLEtBQUt3RTtBQUFBQSxnQkFDaEIsV0FBV3hFLEtBQUttSyxhQUFhO0FBQUEsZ0JBQzdCLGNBQWMsQ0FBQzBGLFFBQVF2RyxpQkFBaUJDLE9BQU8sZ0JBQWdCc0csR0FBRztBQUFBLGdCQUNsRSxjQUFjLE1BQU03RSxxQkFBcUJ6QixPQUFPLE1BQU07QUFBQSxnQkFDdEQsZUFBZSxNQUFNTixVQUFVLEVBQUVsRyxNQUFNLFlBQVl3RyxNQUFNLEdBQUd2SyxrQkFBa0I7QUFBQSxnQkFDOUUsY0FBYyxNQUFNO0FBQ2hCc0ssbUNBQWlCQyxPQUFPLFdBQVcsSUFBSTtBQUN2Q0QsbUNBQWlCQyxPQUFPLGFBQWEsSUFBSTtBQUN6Q0QsbUNBQWlCQyxPQUFPLGdCQUFnQixFQUFFO0FBQUEsZ0JBQzlDO0FBQUEsZ0JBQ0EsVUFBVXZKLEtBQUs2Six3QkFBd0I7QUFBQTtBQUFBLGNBWDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdpRDtBQUFBLGVBYnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDWCxpQ0FBQyxTQUFJLFdBQVc3SixLQUFLNkosd0JBQXdCLFFBQVEsY0FBYyxJQUMvRDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csU0FBUyxnQkFBZ0JOLEtBQUs7QUFBQSxnQkFDOUIsV0FBVTtBQUFBLGdCQUFxQ3ZKLGVBQUs2Six3QkFBd0IsUUFBUSxjQUFjO0FBQUE7QUFBQSxjQUZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFbUg7QUFBQSxZQUNuSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLElBQUksZ0JBQWdCTixLQUFLO0FBQUEsZ0JBQ3pCLE1BQUs7QUFBQSxnQkFDTCxPQUFPdkosS0FBS29LLGdCQUFnQjtBQUFBLGdCQUM1QixVQUFVLENBQUFsSCxNQUFLb0csaUJBQWlCQyxPQUFPLGdCQUFnQnJHLEVBQUVnRyxPQUFPdEYsS0FBSztBQUFBLGdCQUNyRSxXQUFXNEw7QUFBQUEsZ0JBQ1gsVUFBVXhQLEtBQUs2Six3QkFBd0I7QUFBQSxnQkFBTyxjQUFhO0FBQUE7QUFBQSxjQU4vRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNb0U7QUFBQSxlQVZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBLEtBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDRCQUNYLGlDQUFDLFNBQUksV0FBVzdKLEtBQUs2Six3QkFBd0IsUUFBUSxjQUFjLElBQy9EO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTLGNBQWNOLEtBQUs7QUFBQSxnQkFDNUIsV0FBVTtBQUFBLGdCQUNUdkosZUFBSzZKLHdCQUF3QixRQUMxQjtBQUFBO0FBQUEsa0JBQ2tCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxJQUVBO0FBQUE7QUFBQSxjQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxJQUFJLGNBQWNOLEtBQUs7QUFBQSxnQkFDdkIsT0FBT3ZKLEtBQUtxSyxhQUFhdkwsbUJBQW1CLElBQUk0QixLQUFLVixLQUFLcUssVUFBVSxDQUFDLElBQUk7QUFBQSxnQkFDekUsVUFBVSxDQUFBbkgsTUFBS29HLGlCQUFpQkMsT0FBTyxjQUFjckcsRUFBRWdHLE9BQU90RixLQUFLO0FBQUEsZ0JBQ25FLFdBQVc0TDtBQUFBQSxnQkFDWCxVQUFVeFAsS0FBSzZKLHdCQUF3QjtBQUFBLGdCQUFPLGNBQWE7QUFBQTtBQUFBLGNBTi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1vRTtBQUFBLGVBbEJ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHFDQUFvQyxxQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxTQUFJLFdBQVUsbUVBQ1g7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsT0FBTzdKLEtBQUs0RDtBQUFBQSxrQkFDWixVQUFVLENBQUErTCxRQUFPckcsaUJBQWlCQyxPQUFPLFNBQVNvRyxHQUFHO0FBQUEsa0JBQ3JELGFBQVk7QUFBQSxrQkFDWixXQUFXLEdBQUdILFVBQVU7QUFBQTtBQUFBLGdCQUw1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLeUQ7QUFBQSxjQUV6RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNN0IsZ0NBQWdDcEUsS0FBSztBQUFBLGtCQUNwRCxVQUFVdUQsT0FBT3hDLGVBQWU7QUFBQSxrQkFDaEMsV0FBVTtBQUFBLGtCQUNWLE9BQU07QUFBQSxrQkFDTixjQUFXO0FBQUEsa0JBRVgsaUNBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUE7QUFBQSxnQkFSbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLGNBQVc7QUFBQSxrQkFDWCxNQUFLO0FBQUEsa0JBQVMsU0FBUyxNQUFNZ0IsV0FBVy9CLEtBQUs7QUFBQSxrQkFBRyxXQUFVO0FBQUEsa0JBQzFELGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBUTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxpQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxlQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0N2SixLQUFLNkosd0JBQXdCLFNBQzFCLHVCQUFDLFNBQUksV0FBVSxvRkFDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLHFDQUFDLFdBQU0sU0FBUyxrQkFBa0JOLEtBQUssSUFBSSxXQUFVLHFDQUFvQyxtQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEc7QUFBQSxjQUM1RztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsSUFBSSxrQkFBa0JBLEtBQUs7QUFBQSxrQkFDM0IsT0FBT3ZKLEtBQUs2RCxpQkFBaUIvRSxtQkFBbUIsSUFBSTRCLEtBQUtWLEtBQUs2RCxjQUFjLENBQUMsSUFBSTtBQUFBLGtCQUNqRixVQUFVLENBQUFYLE1BQUtvRyxpQkFBaUJDLE9BQU8sa0JBQWtCckcsRUFBRWdHLE9BQU90RixLQUFLO0FBQUEsa0JBQ3ZFLFdBQVc0TDtBQUFBQSxrQkFBWSxjQUFhO0FBQUE7QUFBQSxnQkFMeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSzZDO0FBQUEsaUJBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLHFDQUFDLFdBQU0sU0FBUyxvQkFBb0JqRyxLQUFLLElBQUksV0FBVSxxQ0FBb0MsMEJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFHO0FBQUEsY0FDckc7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLElBQUksb0JBQW9CQSxLQUFLO0FBQUEsa0JBQzdCLE9BQU92SixLQUFLa0Usb0JBQW9CO0FBQUEsa0JBQ2hDLFVBQVUsQ0FBQWhCLE1BQUtvRyxpQkFBaUJDLE9BQU8sb0JBQW9CckcsRUFBRWdHLE9BQU90RixLQUFLO0FBQUEsa0JBQ3pFLFdBQVc0TDtBQUFBQSxrQkFDWCxXQUFXO0FBQUEsa0JBQUssY0FBYTtBQUFBO0FBQUEsZ0JBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1zQztBQUFBLGlCQVIxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ1gsaUNBQUMsV0FBTSxXQUFVLGlEQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVN2TCxRQUFRakUsS0FBS2dFLFdBQVc7QUFBQSxrQkFDakMsVUFBVSxDQUFBZCxNQUFLb0csaUJBQWlCQyxPQUFPLGVBQWVyRyxFQUFFZ0csT0FBTzRHLE9BQU87QUFBQSxrQkFDdEUsV0FBVTtBQUFBLGtCQUEwQixjQUFhO0FBQUE7QUFBQSxnQkFKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTBEO0FBQUEsY0FDMUQsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQywwQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxpQkFObEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLHFDQUFDLFdBQU0sU0FBUyxlQUFldkcsS0FBSyxJQUFJLFdBQVUscUNBQW9DLGlDQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RztBQUFBLGNBQ3ZHO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLElBQUksZUFBZUEsS0FBSztBQUFBLGtCQUN4QixPQUFPdkosS0FBS21FLHlCQUF5QixPQUFPLFFBQVE7QUFBQSxrQkFDcEQsVUFBVSxDQUFBakIsTUFBSztBQUNYLDBCQUFNNk0sUUFBUTdNLEVBQUVnRyxPQUFPdEYsVUFBVTtBQUNqQzBGLHFDQUFpQkMsT0FBTyx3QkFBd0J3RyxLQUFLO0FBQ3JELHdCQUFJLENBQUNBLE9BQU87QUFDUnpHLHVDQUFpQkMsT0FBTyxlQUFlLElBQUk7QUFDM0NELHVDQUFpQkMsT0FBTyxnQkFBZ0IsSUFBSTtBQUFBLG9CQUNoRDtBQUFBLGtCQUNKO0FBQUEsa0JBQ0EsV0FBV2lHO0FBQUFBLGtCQUVYO0FBQUEsMkNBQUMsWUFBTyxPQUFNLE1BQUssa0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFCO0FBQUEsb0JBQ3JCLHVCQUFDLFlBQU8sT0FBTSxPQUFNLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzQjtBQUFBO0FBQUE7QUFBQSxnQkFkMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxpQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUNDeFAsS0FBS21FLHlCQUF5QixRQUMzQixtQ0FDSTtBQUFBLHFDQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLHVDQUFDLFdBQU0sU0FBUyxnQkFBZ0JvRixLQUFLLElBQUksV0FBVSxxQ0FBb0MsaUNBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdHO0FBQUEsZ0JBQ3hHO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxJQUFJLGdCQUFnQkEsS0FBSztBQUFBLG9CQUN6QixPQUFPdkosS0FBSzhELGdCQUFnQjtBQUFBLG9CQUM1QixVQUFVLENBQUFaLE1BQUtvRyxpQkFBaUJDLE9BQU8sZ0JBQWdCckcsRUFBRWdHLE9BQU90RixLQUFLO0FBQUEsb0JBQ3JFLFdBQVc0TDtBQUFBQSxvQkFDWCxXQUFXO0FBQUEsb0JBQUssY0FBYTtBQUFBO0FBQUEsa0JBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNc0M7QUFBQSxtQkFSMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNYO0FBQUEsdUNBQUMsV0FBTSxTQUFTLGVBQWVqRyxLQUFLLElBQUksV0FBVSxxQ0FBb0MscUNBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJHO0FBQUEsZ0JBQzNHO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxJQUFJLGVBQWVBLEtBQUs7QUFBQSxvQkFDeEIsT0FBT3ZKLEtBQUsrRCxlQUFlO0FBQUEsb0JBQzNCLFVBQVUsQ0FBQWIsTUFBS29HLGlCQUFpQkMsT0FBTyxlQUFldEssVUFBVSxRQUFRaUUsRUFBRWdHLE9BQU90RixLQUFLLENBQUM7QUFBQSxvQkFDdkYsUUFBUSxDQUFBVixNQUFLO0FBQ1QsNEJBQU0yTSxPQUFPM00sRUFBRWdHLE9BQU90RixTQUFTLElBQUlRLEtBQUs7QUFDeEMsMEJBQUl5TCxPQUFPLENBQUMzUSxhQUFhLFFBQVEyUSxHQUFHLEdBQUc7QUFDbkMsOEJBQU1mLE9BQU8zUCxRQUFRLE1BQU07QUFDM0IvQiw4QkFBTTJOLEtBQUsrRCxNQUFNQyxnQkFBZ0IsZUFBZTtBQUFBLHNCQUNwRDtBQUFBLG9CQUNKO0FBQUEsb0JBQ0EsV0FBV1M7QUFBQUEsb0JBQ1gsYUFBWTtBQUFBLG9CQUNaLFdBQVdyUSxRQUFRLE1BQU0sR0FBRzZRLGFBQWE7QUFBQSxvQkFBSSxjQUFhO0FBQUE7QUFBQSxrQkFkOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWNtRTtBQUFBLG1CQWhCdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxlQS9FUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlGQTtBQUFBLGFBL01FaFEsS0FBSzJELFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtOQTtBQUFBLE1BRVI7QUFBQSxNQUVDN0MsYUFBYWlHLFNBQVMsS0FDbkIsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDhCQUE2QixxQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2xFLHVCQUFDLFVBQUssV0FBVSxxQkFBcUJsSSxzQkFBWWlPLE9BQU9VLFdBQVcsVUFBVSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsV0FGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FwVVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNVQTtBQUFBLElBSUEsdUJBQUMsU0FBSSxXQUFVLDhDQUVYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlEQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyx3Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFFBZXpFVixPQUFPSyxhQUFhcEcsU0FBUyxJQUMxQitGLE9BQU9LLGFBQWF6SjtBQUFBQSxVQUFJLENBQUFnSCxRQUNwQix1QkFBQyxTQUFxQixXQUFVLHVDQUM1QjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzREFBc0RBO0FBQUFBLGtCQUFJNEM7QUFBQUEsY0FBUztBQUFBLGNBQUc1QyxJQUFJQztBQUFBQSxjQUFLO0FBQUEsaUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFFakcsdUJBQUMsVUFBSyxXQUFVLG9FQUNYOUwsc0JBQVk2TCxJQUFJZ0IsUUFBUSxVQUFVLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUxNaEIsSUFBSTJDLFFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFFBQ0gsSUFFRCx1QkFBQyxPQUFFLFdBQVUsOEJBQ1I5TSxpQkFBT3VGLFlBQVksK0RBQStELHFEQUR2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQTdCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMENBQXlDLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsUUFDOUQsdUJBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0I7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNakgsc0JBQVlpTyxPQUFPeEMsYUFBYSxVQUFVLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsYUFBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSTtBQUFBLFFBSXBJLHVCQUFDLFNBQUksV0FBVSw2Q0FBNEM7QUFBQSxpQ0FBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFBTztBQUFBLFVBQUMsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBR3pMLFlBQVlpTyxPQUFPdEMsWUFBWSxVQUFVO0FBQUEsZUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxhQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdKO0FBQUEsUUFDaEosdUJBQUMsU0FBSSxXQUFVLGtDQUFpQztBQUFBLGlDQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0I7QUFBQSxVQUFPO0FBQUEsVUFBQyx1QkFBQyxVQUFNM0wsc0JBQVlpTyxPQUFPVyxnQkFBZ0IsVUFBVSxLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUk7QUFBQSxRQUN6SSx1QkFBQyxTQUFJLFdBQVUsNkRBQTREO0FBQUEsaUNBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQU87QUFBQSxVQUFDLHVCQUFDLFVBQU01TyxzQkFBWWlPLE9BQU9VLFdBQVcsVUFBVSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLGFBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0o7QUFBQSxXQVJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU0xTixTQUFTSixrQkFBa0IzQixzQkFBc0IyUSxTQUFTLENBQUMsR0FBRyxXQUFVLDhJQUE2SSx3QkFBMVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrUTtBQUFBLE1BQ2xRLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNDLFlBQVksVUFBVW5NLFlBQVlkLHdCQUF3QixXQUFVLDZLQUM5RmM7QUFBQUEsbUJBQVcsdUJBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdELElBQU0sdUJBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBRHpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFHQ04sZUFBZUksZUFDWjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUUo7QUFBQUEsUUFDUixTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFFBQ25DLFVBQVVpSDtBQUFBQSxRQUNWLFFBQVE5RztBQUFBQTtBQUFBQSxNQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUl3QjtBQUFBLE9BcmhCaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdoQkE7QUFFUjtBQUFFMUMsR0EvdUNXRCxtQkFBaUI7QUFBQSxVQUNYeEMsV0FDRUQsYUFRYlEsYUFDOEJxQixRQUFRO0FBQUE7QUFBQWtSLEtBWGpDdFE7QUFBaUIsSUFBQXNRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VDYWxsYmFjayIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidG9hc3QiLCJGYVNhdmUiLCJGYVNwaW5uZXIiLCJGYVBsdXMiLCJGYVRyYXNoIiwiRmFGaWxsRHJpcCIsInVzZUNydWRJdGVtIiwiZ2V0QnlJZCIsImdldEFsbCIsInNlYXJjaCIsInNlYXJjaEJ5RmllbGQiLCJjb2JyYW56YXNNb2R1bGVDb25maWciLCJidWlsZEFwcGxpZWRDcmVkaXROb3Rlc0ZvclNhdmUiLCJidWlsZEFwcGxpZWRJbnZvaWNlc0ZvclNhdmUiLCJidWlsZEFwcGxpZWRTYWxlc0ZpbmFuY2lhbE5vdGVzRm9yU2F2ZSIsImNvbXB1dGVDb2xsZWN0aW9uR3Jvc3NBbW91bnQiLCJpc0FkanVzdG1lbnRPbmx5Q29sbGVjdGlvbiIsInN1bUFwcGxpZWRBbW91bnRzUmVjb3JkIiwiY2xpZW50ZXNNb2R1bGVDb25maWciLCJwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnIiwiUmVsYXRpb25hbElucHV0IiwiRGVjaW1hbElucHV0IiwiUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlIiwiU2VhcmNoTW9kYWwiLCJMb2FkaW5nU3Bpbm5lciIsImZvcm1hdFZhbHVlIiwiZm9ybWF0RGF0ZUZvcklucHV0IiwidXNlTW9kYWwiLCJiYW5jb3NNb2R1bGVDb25maWciLCJhcHBseU1hc2siLCJ2YWxpZGF0ZU1hc2siLCJnZXRNYXNrIiwidGF4ZXNNb2R1bGVDb25maWciLCJjbGFtcEFwcGxpZWRUb1NpZ25lZEJhbGFuY2UiLCJzaWduZWRDcmVkaXROb3RlQmFsYW5jZSIsInNpZ25lZENyZWRpdE5vdGVUb3RhbCIsInNpZ25lZFR5cGVkQmFsYW5jZSIsInNpZ25lZFR5cGVkVG90YWwiLCJnZXRMaXN0UmV0dXJuUGF0aCIsIkNvYnJhbnphc0Zvcm1QYWdlIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwibW9kZSIsIml0ZW0iLCJvcmlnaW5hbERhdGEiLCJsb2FkaW5nIiwibG9hZGluZ0RhdGEiLCJlcnJvciIsInNhdmVJdGVtIiwic2hvd0NvbmZpcm1hdGlvbk1vZGFsIiwiaGVhZGVyIiwic2V0SGVhZGVyIiwiY29sbGVjdGlvbl9kYXRlIiwiRGF0ZSIsImRpc2NvdW50X2Ftb3VudCIsImNsaWVudENvZGVJbnB1dCIsInNldENsaWVudENvZGVJbnB1dCIsInBheW1lbnRJdGVtcyIsInNldFBheW1lbnRJdGVtcyIsImNsaWVudFRheGVzIiwic2V0Q2xpZW50VGF4ZXMiLCJjbGllbnRBZHZhbmNlQmFsYW5jZSIsInNldENsaWVudEFkdmFuY2VCYWxhbmNlIiwib3V0c3RhbmRpbmdJbnZvaWNlcyIsInNldE91dHN0YW5kaW5nSW52b2ljZXMiLCJwZW5kaW5nQ3JlZGl0Tm90ZXMiLCJzZXRQZW5kaW5nQ3JlZGl0Tm90ZXMiLCJwZW5kaW5nRmluYW5jaWFsTm90ZXMiLCJzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMiLCJsb2FkaW5nQ2xpZW50RG9jdW1lbnRzIiwic2V0TG9hZGluZ0NsaWVudERvY3VtZW50cyIsImFwcGxpZWRBbW91bnRzIiwic2V0QXBwbGllZEFtb3VudHMiLCJhcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHMiLCJzZXRBcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHMiLCJhcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMiLCJzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJtb2RhbENvbmZpZyIsInNldE1vZGFsQ29uZmlnIiwiaXNTYXZpbmciLCJzZXRJc1NhdmluZyIsInJldGVudGlvblRheGVzIiwic2V0UmV0ZW50aW9uVGF4ZXMiLCJjYW5jZWxsZWQiLCJyZXMiLCJlbmRwb2ludCIsInR5cGUiLCJwZXJfcGFnZSIsImRhdGEiLCJlIiwiY29uc29sZSIsIk51bWJlciIsImNsaWVudCIsImN1aXQiLCJTdHJpbmciLCJmb3JtYXR0ZWRJdGVtcyIsIml0ZW1zIiwibWFwIiwidGVtcElkIiwidmFsdWUiLCJjaGVja19kdWVfZGF0ZSIsImNoZWNrX2hvbGRlciIsImlzc3Vlcl9jdWl0IiwiaXNfdG9fb3JkZXIiLCJCb29sZWFuIiwicmVmZXJlbmNlX251bWJlciIsImlzX3RoaXJkX3BhcnR5X2NoZWNrIiwidHJpbSIsInVpX2FjY291bnRfY29kZSIsImNoYXJ0X2FjY291bnQiLCJjb2RlIiwidWlfYmFua19jb2RlIiwiYmFua19pZCIsImFwcGxpZWQiLCJhcHBsaWVkX2ludm9pY2VzIiwicmVkdWNlIiwiYWNjIiwiYXBwIiwic2FsZXNfaW52b2ljZSIsImFtb3VudF9hcHBsaWVkIiwiYXBwbGllZF9jcmVkaXRfbm90ZXMiLCJjcmVkaXRBcHBsaWVkIiwiY3JlZGl0X25vdGUiLCJhcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyIsImZpbmFuY2lhbEFwcGxpZWQiLCJmaW5hbmNpYWxfbm90ZSIsImxvYWRFZGl0RGF0YSIsImNsaWVudElkIiwiZnVsbENsaWVudCIsInRheGVzIiwiYWR2YW5jZV9iYWxhbmNlIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiY2xpZW50X2lkIiwidG9TdHJpbmciLCJoYXNfYmFsYW5jZSIsImFwcGxpZWRDcmVkaXRJZHMiLCJhbiIsImFwcGxpZWRGaW5hbmNpYWxJZHMiLCJhcHBsaWVkQ3JlZGl0UHJvbWlzZXMiLCJub3RlSWQiLCJhcHBsaWVkRmluYW5jaWFsUHJvbWlzZXMiLCJpbnZvaWNlc1Jlc3BvbnNlIiwiY3JlZGl0Tm90ZXNSZXNwb25zZSIsImZpbmFuY2lhbE5vdGVzUmVzcG9uc2UiLCJmZXRjaGVkQXBwbGllZCIsIlByb21pc2UiLCJhbGwiLCJmZXRjaGVkQXBwbGllZENyZWRpdE5vdGVzIiwic2xpY2UiLCJsZW5ndGgiLCJmZXRjaGVkQXBwbGllZEZpbmFuY2lhbE5vdGVzIiwiYWxsSW52b2ljZXNNYXAiLCJNYXAiLCJpbnYiLCJmb3JFYWNoIiwiYXBwbGllZEludm9pY2UiLCJvcmlnaW5hbEJhbGFuY2UiLCJiYWxhbmNlIiwic2V0IiwiQXJyYXkiLCJmcm9tIiwidmFsdWVzIiwiYWxsQ3JlZGl0Tm90ZXNNYXAiLCJuIiwiaGFzIiwiZmluYWxDcmVkaXROb3RlcyIsImFwcGxpZWREZXRhaWwiLCJmaW5kIiwiY3VycmVudEJhbGFuY2UiLCJhbGxGaW5hbmNpYWxOb3Rlc01hcCIsImZpbmFsRmluYW5jaWFsTm90ZXMiLCJlcnIiLCJhcHBseUNsaWVudFNlbGVjdGlvbiIsInNlbGVjdGVkQ2xpZW50IiwicHJldiIsImN1c3RvbWVyX2NvZGUiLCJoYW5kbGVDbGllbnRDb2RlU3VibWl0IiwiZm91bmRJdGVtIiwiZmllbGROYW1lIiwic3VjY2VzcyIsIm5hbWUiLCJ3YXJuaW5nIiwidW5kZWZpbmVkIiwib3Blbk1vZGFsIiwidGFyZ2V0IiwiY29uZmlnIiwiaGFuZGxlU2VsZWN0TW9kYWwiLCJzZWxlY3RlZEl0ZW0iLCJoYW5kbGVJdGVtQ2hhbmdlIiwiaW5kZXgiLCJmaWVsZCIsInN1bU90aGVyU2FsIiwiZmlsdGVyIiwiaXQiLCJpIiwicGF5bWVudF9tZXRob2RfY29kZSIsInMiLCJtYXhBZHZhbmNlRm9ySXRlbSIsIk1hdGgiLCJtYXgiLCJ1cGRhdGVkSXRlbSIsImJhbmtfbmFtZSIsImNoZWNrX251bWJlciIsImNoZWNrX2RhdGUiLCJncm9zc0Ftb3VudCIsImRpc2NvdW50IiwidG90YWxUYXhlcyIsInN1bSIsInRheCIsInJhdGUiLCJuZXRBbW91bnRUb1BheSIsIm1pbiIsIm51bVZhbCIsIndhcm4iLCJoYW5kbGVJdGVtQ29kZVN1Ym1pdCIsImNvZGVUb1NlYXJjaCIsImZvdW5kIiwiYWRkTmV3SXRlbSIsIm5vdyIsImNoZWNrX2tleSIsInJlbW92ZUl0ZW0iLCJfIiwiaGFuZGxlQXBwbHlBbW91bnQiLCJpbnZvaWNlSWQiLCJhbW91bnQiLCJudW1lcmljQW1vdW50IiwiaGFuZGxlU2lnbmVkRG9jdW1lbnRBbW91bnRDaGFuZ2UiLCJzZXR0ZXIiLCJjbGFtcGVkIiwibnVtZXJpY1ZhbHVlIiwiaGFuZGxlQ3JlZGl0Tm90ZUFtb3VudENoYW5nZSIsIm5vdGUiLCJoYW5kbGVGaW5hbmNpYWxOb3RlQW1vdW50Q2hhbmdlIiwiY3JlZGl0Tm90ZVJvd3MiLCJ0b3RhbCIsInRvdGFsX2Ftb3VudCIsImRvY051bWJlciIsImludm9pY2VfbnVtYmVyIiwidm91Y2hlcl9udW1iZXIiLCJkb2NMYWJlbCIsImRhdGUiLCJpc3N1ZV9kYXRlIiwiYmFsYW5jZURpc3BsYXkiLCJmaW5hbmNpYWxOb3RlUm93cyIsInRvdGFscyIsImludm9pY2VzR3Jvc3NBbW91bnQiLCJjcmVkaXROb3Rlc0dyb3NzQW1vdW50IiwiZmluYW5jaWFsTm90ZXNHcm9zc0Ftb3VudCIsInRheGFibGVCYXNlIiwiYXBwbGllZFRheGVzIiwidGF4QW1vdW50IiwidGF4X2lkIiwidGF4X25hbWUiLCJjaGFydF9hY2NvdW50X2lkIiwidG90YWxQYWlkIiwicmVtYWluaW5nVG9QYXkiLCJyb3VuZCIsImZpbGxQYXltZW50TGluZUZyb21BcHBsaWVkVG90YWwiLCJ0b3RhbEFwbGljYWRvIiwic3VtT3Ryb3MiLCJtb250byIsInBlcmZvcm1TYXZlQ29icmFuemEiLCJpdGVtc1RvU2F2ZSIsImJhc2UiLCJyZWYiLCJhcHBsaWVkSW52b2ljZXNUb1NhdmUiLCJ0YXhlc1RvU2F2ZSIsImRhdGFUb1NhdmUiLCJwYXltZW50X2RhdGUiLCJncm9zc19hbW91bnQiLCJjdXJyZW5jeV9pZCIsInNhdmVFcnJvciIsImJhc2VSb3V0ZSIsImhhbmRsZVNhdmUiLCJlbWlzc2lvbiIsImN1aXRWYWwiLCJtYXNrIiwiZXJyb3JNZXNzYWdlIiwiaGFzQXBwbGllZEludm9pY2VzIiwic2tpcEJhbGFuY2VDaGVjayIsInJlbWFpbmluZyIsImFkdmFuY2VBbW91bnQiLCJhYnMiLCJ0aXRsZSIsIm1lc3NhZ2UiLCJvbkNvbmZpcm0iLCJpbnB1dFN0eWxlIiwibW9kdWxlTmFtZSIsImludm9pY2VfZGF0ZSIsIm51bSIsImVudGVyZWRBbW91bnQiLCJ2YWwiLCJjaGVja2VkIiwiaXNZZXMiLCJtYXhMZW5ndGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb2JyYW56YXNGb3JtUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlQ2FsbGJhY2ssIHR5cGUgRGlzcGF0Y2gsIHR5cGUgU2V0U3RhdGVBY3Rpb24gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IEZhU2F2ZSwgRmFTcGlubmVyLCBGYVBsdXMsIEZhVHJhc2gsIEZhRmlsbERyaXAgfSBmcm9tICdyZWFjdC1pY29ucy9mYSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IGdldEJ5SWQsIGdldEFsbCwgc2VhcmNoLCBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQge1xuICAgIGNvYnJhbnphc01vZHVsZUNvbmZpZyxcbiAgICB0eXBlIEN1c3RvbWVyUGF5bWVudCxcbiAgICB0eXBlIEN1c3RvbWVyUGF5bWVudEl0ZW0sXG59IGZyb20gJy4uL2NvYnJhbnphcy5jb25maWcnO1xuaW1wb3J0IHtcbiAgICBidWlsZEFwcGxpZWRDcmVkaXROb3Rlc0ZvclNhdmUsXG4gICAgYnVpbGRBcHBsaWVkSW52b2ljZXNGb3JTYXZlLFxuICAgIGJ1aWxkQXBwbGllZFNhbGVzRmluYW5jaWFsTm90ZXNGb3JTYXZlLFxuICAgIGNvbXB1dGVDb2xsZWN0aW9uR3Jvc3NBbW91bnQsXG4gICAgaXNBZGp1c3RtZW50T25seUNvbGxlY3Rpb24sXG4gICAgc3VtQXBwbGllZEFtb3VudHNSZWNvcmQsXG59IGZyb20gJy4uL2J1aWxkQXBwbGllZENvbGxlY3Rpb25QYXlsb2FkJztcbmltcG9ydCB7IHR5cGUgQ2xpZW50ZSwgY2xpZW50ZXNNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9jbGllbnRlcy9jbGllbnRlcy5jb25maWcnO1xuaW1wb3J0IHsgdHlwZSBTYWxlc0ludm9pY2UgfSBmcm9tICcuLi8uLi9mYWN0dXJhc192ZW50YS9mYWN0dXJhc192ZW50YS5jb25maWcnO1xuaW1wb3J0IHsgdHlwZSBDcmVkaXROb3RlIH0gZnJvbSAnLi4vLi4vbm90YXNfY3JlZGl0by9ub3Rhc19jcmVkaXRvLmNvbmZpZyc7XG5pbXBvcnQgeyB0eXBlIEZpbmFuY2lhbE5vdGUgfSBmcm9tICcuLi8uLi9ub3Rhc19maW5hbmNpZXJhcy9ub3Rhc19maW5hbmNpZXJhcy5jb25maWcnO1xuaW1wb3J0IHsgcGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZywgdHlwZSBQbGFuRGVDdWVudGFzIH0gZnJvbSAnLi4vLi4vcGxhbl9kZV9jdWVudGFzL3BsYW5fZGVfY3VlbnRhcy5jb25maWcnO1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQge1xuICAgIFBlbmRpbmdTaWduZWREb2N1bWVudHNUYWJsZSxcbiAgICB0eXBlIFBlbmRpbmdTaWduZWREb2N1bWVudFJvdyxcbn0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlJztcbmltcG9ydCB7IFNlYXJjaE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlLCBmb3JtYXREYXRlRm9ySW5wdXQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IHVzZU1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29udGV4dC9Nb2RhbENvbnRleHQnO1xuaW1wb3J0IHsgYmFuY29zTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vYmFuY29zL2JhbmNvcy5jb25maWcnO1xuaW1wb3J0IHsgYXBwbHlNYXNrLCB2YWxpZGF0ZU1hc2ssIGdldE1hc2sgfSBmcm9tICcuLi8uLi8uLi91dGlscy9tYXNrcyc7XG5pbXBvcnQgdHlwZSB7IEFwcGxpZWRUYXgsIFJlbGF0ZWRUYXggfSBmcm9tICcuLi8uLi8uLi90eXBlcy9hcHBsaWVkVGF4ZXMnO1xuaW1wb3J0IHsgdGF4ZXNNb2R1bGVDb25maWcsIHR5cGUgVGF4IH0gZnJvbSAnLi4vLi4vaW1wdWVzdG9zL2ltcHVlc3Rvcy5jb25maWcnO1xuaW1wb3J0IHtcbiAgICBjbGFtcEFwcGxpZWRUb1NpZ25lZEJhbGFuY2UsXG4gICAgc2lnbmVkQ3JlZGl0Tm90ZUJhbGFuY2UsXG4gICAgc2lnbmVkQ3JlZGl0Tm90ZVRvdGFsLFxuICAgIHNpZ25lZFR5cGVkQmFsYW5jZSxcbiAgICBzaWduZWRUeXBlZFRvdGFsLFxufSBmcm9tICcuLi8uLi8uLi91dGlscy9hcHBsaWVkU2lnbmVkRG9jdW1lbnRzJztcbmltcG9ydCB7IGdldExpc3RSZXR1cm5QYXRoIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbGlzdFJldHVybk5hdmlnYXRpb24nO1xuXG4vLyBUaXBvcyBwYXJhIGVsIGZvcm11bGFyaW9cbnR5cGUgRWRpdGluZ1RhcmdldCA9ICdjbGllbnQnIHwgeyB0eXBlOiAnaXRlbUFjY291bnQnOyBpbmRleDogbnVtYmVyIH0gfCB7IHR5cGU6ICdpdGVtQmFuayc7IGluZGV4OiBudW1iZXIgfTtcbnR5cGUgQ2xpZW50V2l0aFRheGVzID0gQ2xpZW50ZSAmIHsgdGF4ZXM/OiBSZWxhdGVkVGF4W107IGFkdmFuY2VfYmFsYW5jZT86IG51bWJlciB9O1xuXG50eXBlIEZvcm1DdXN0b21lclBheW1lbnRJdGVtID0gT21pdDxDdXN0b21lclBheW1lbnRJdGVtLCAnaWQnIHwgJ2NoYXJ0X2FjY291bnQnIHwgJ3ZhbHVlJz4gJiB7XG4gICAgaWQ/OiBudW1iZXI7XG4gICAgdmFsdWU6IG51bWJlciB8IHN0cmluZztcbiAgICBjaGFydF9hY2NvdW50OiBQbGFuRGVDdWVudGFzIHwgbnVsbDtcbiAgICB0ZW1wSWQ6IHN0cmluZztcblxuICAgIC8vIENhbXBvcyB0ZW1wb3JhbGVzIHBhcmEgaW5wdXRzIGNvbnRyb2xhZG9zXG4gICAgdWlfYWNjb3VudF9jb2RlOiBzdHJpbmc7XG4gICAgdWlfYmFua19jb2RlOiBzdHJpbmc7XG4gICAgLyoqIFNvbG8gVUk6IGNvbnRyb2xhIHNpIHNlIG11ZXN0cmEgZWwgY2FtcG8gQ1VJVCBlbWlzb3IgKGNoZXF1ZSBkZSB0ZXJjZXJvKS4gTm8gc2UgZW52w61hIGFsIGJhY2tlbmQuICovXG4gICAgaXNfdGhpcmRfcGFydHlfY2hlY2s/OiBib29sZWFuO1xufTtcblxuZXhwb3J0IGNvbnN0IENvYnJhbnphc0Zvcm1QYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgbW9kZSA9IGlkID8gJ2VkaXQnIDogJ2NyZWF0ZSc7XG5cbiAgICBjb25zdCB7XG4gICAgICAgIGl0ZW06IG9yaWdpbmFsRGF0YSxcbiAgICAgICAgbG9hZGluZzogbG9hZGluZ0RhdGEsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBzYXZlSXRlbSxcbiAgICB9ID0gdXNlQ3J1ZEl0ZW08Q3VzdG9tZXJQYXltZW50Pihjb2JyYW56YXNNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCB7IHNob3dDb25maXJtYXRpb25Nb2RhbCB9ID0gdXNlTW9kYWwoKTtcblxuICAgIC8vIC0tLSBFU1RBRE9TIFBSSU5DSVBBTEVTIC0tLVxuICAgIGNvbnN0IFtoZWFkZXIsIHNldEhlYWRlcl0gPSB1c2VTdGF0ZTxQYXJ0aWFsPEN1c3RvbWVyUGF5bWVudD4+KHtcbiAgICAgICAgY29sbGVjdGlvbl9kYXRlOiBmb3JtYXREYXRlRm9ySW5wdXQobmV3IERhdGUoKSksXG4gICAgICAgIGRpc2NvdW50X2Ftb3VudDogMCxcbiAgICB9KTtcblxuICAgIC8vIOKchSBQQVRSw5NOOiBFc3RhZG8gbG9jYWwgcGFyYSBlbCBDw5NESUdPIGRlbCBjbGllbnRlICh0ZXh0byBlZGl0YWJsZSlcbiAgICBjb25zdCBbY2xpZW50Q29kZUlucHV0LCBzZXRDbGllbnRDb2RlSW5wdXRdID0gdXNlU3RhdGUoJycpO1xuXG5cbiAgICBjb25zdCBbcGF5bWVudEl0ZW1zLCBzZXRQYXltZW50SXRlbXNdID0gdXNlU3RhdGU8Rm9ybUN1c3RvbWVyUGF5bWVudEl0ZW1bXT4oW10pO1xuICAgIGNvbnN0IFtjbGllbnRUYXhlcywgc2V0Q2xpZW50VGF4ZXNdID0gdXNlU3RhdGU8UmVsYXRlZFRheFtdPihbXSk7IC8vIFJldGVuY2lvbmVzIGRlbCBjbGllbnRlXG4gICAgY29uc3QgW2NsaWVudEFkdmFuY2VCYWxhbmNlLCBzZXRDbGllbnRBZHZhbmNlQmFsYW5jZV0gPSB1c2VTdGF0ZSgwKTtcblxuICAgIC8vIEzDk0dJQ0EgQ0xBVkU6IEZhY3R1cmFzIHkgQXBsaWNhY2lvbmVzXG4gICAgY29uc3QgW291dHN0YW5kaW5nSW52b2ljZXMsIHNldE91dHN0YW5kaW5nSW52b2ljZXNdID0gdXNlU3RhdGU8U2FsZXNJbnZvaWNlW10+KFtdKTtcbiAgICBjb25zdCBbcGVuZGluZ0NyZWRpdE5vdGVzLCBzZXRQZW5kaW5nQ3JlZGl0Tm90ZXNdID0gdXNlU3RhdGU8Q3JlZGl0Tm90ZVtdPihbXSk7XG4gICAgY29uc3QgW3BlbmRpbmdGaW5hbmNpYWxOb3Rlcywgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzXSA9IHVzZVN0YXRlPEZpbmFuY2lhbE5vdGVbXT4oW10pO1xuICAgIGNvbnN0IFtsb2FkaW5nQ2xpZW50RG9jdW1lbnRzLCBzZXRMb2FkaW5nQ2xpZW50RG9jdW1lbnRzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbYXBwbGllZEFtb3VudHMsIHNldEFwcGxpZWRBbW91bnRzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIG51bWJlciB8IHN0cmluZz4+KHt9KTtcbiAgICBjb25zdCBbYXBwbGllZENyZWRpdE5vdGVBbW91bnRzLCBzZXRBcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPj4oe30pO1xuICAgIGNvbnN0IFthcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMsIHNldEFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50c10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBudW1iZXIgfCBzdHJpbmc+Pih7fSk7XG5cbiAgICAvLyAtLS0gRVNUQURPUyBERSBNT0RBTEVTIFkgVUkgLS0tXG4gICAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2VkaXRpbmdUYXJnZXQsIHNldEVkaXRpbmdUYXJnZXRdID0gdXNlU3RhdGU8RWRpdGluZ1RhcmdldCB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFttb2RhbENvbmZpZywgc2V0TW9kYWxDb25maWddID0gdXNlU3RhdGU8YW55PihudWxsKTsgLy8gQ29uZmlnIHBhcmEgZWwgU2VhcmNoTW9kYWxcbiAgICBjb25zdCBbaXNTYXZpbmcsIHNldElzU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbcmV0ZW50aW9uVGF4ZXMsIHNldFJldGVudGlvblRheGVzXSA9IHVzZVN0YXRlPFRheFtdPihbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2V0QWxsPFRheD4odGF4ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIHsgdHlwZTogMywgcGVyX3BhZ2U6IDUwMCB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgc2V0UmV0ZW50aW9uVGF4ZXMocmVzLmRhdGEgPz8gW10pO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHRvYXN0LmVycm9yKCdObyBzZSBwdWRpZXJvbiBjYXJnYXIgbG9zIGltcHVlc3RvcyBkZSByZXRlbmNpw7NuLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KSgpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG5cbiAgICAvLyBDYXJnYSBpbmljaWFsIGRlIGRhdG9zIGVuIG1vZG8gZWRpY2nDs25cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICAvLyDinIUgTMOTR0lDQSBERSBFRElDScOTTiBNRUpPUkFEQVxuICAgICAgICBpZiAob3JpZ2luYWxEYXRhICYmIG1vZGUgPT09ICdlZGl0Jykge1xuXG4gICAgICAgICAgICAvLyAxLiBQb2JsYXIgY2FiZWNlcmEgKGluY2x1eWVuZG8gZGVzY3VlbnRvKVxuICAgICAgICAgICAgc2V0SGVhZGVyKHtcbiAgICAgICAgICAgICAgICAuLi5vcmlnaW5hbERhdGEsXG4gICAgICAgICAgICAgICAgY29sbGVjdGlvbl9kYXRlOiBmb3JtYXREYXRlRm9ySW5wdXQobmV3IERhdGUob3JpZ2luYWxEYXRhLmNvbGxlY3Rpb25fZGF0ZSkpLFxuICAgICAgICAgICAgICAgIGRpc2NvdW50X2Ftb3VudDogTnVtYmVyKG9yaWdpbmFsRGF0YS5kaXNjb3VudF9hbW91bnQpIHx8IDAsIC8vIFBvYmxhciBkZXNjdWVudG9cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyAyLiBQb2JsYXIgbWVkaW9zIGRlIHBhZ28gKGl0ZW1zKVxuICAgICAgICAgICAgaWYgKG9yaWdpbmFsRGF0YS5jbGllbnQpIHtcbiAgICAgICAgICAgICAgICBzZXRDbGllbnRDb2RlSW5wdXQob3JpZ2luYWxEYXRhLmNsaWVudC5jdWl0IHx8IFN0cmluZyhvcmlnaW5hbERhdGEuY2xpZW50LmlkKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZEl0ZW1zID0gb3JpZ2luYWxEYXRhLml0ZW1zLm1hcChpdGVtID0+ICh7XG4gICAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgICB0ZW1wSWQ6IGBpdGVtLSR7aXRlbS5pZH1gLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBOdW1iZXIoaXRlbS52YWx1ZSkgfHwgMCxcbiAgICAgICAgICAgICAgICBjaGVja19kdWVfZGF0ZTogaXRlbS5jaGVja19kdWVfZGF0ZSA/PyBudWxsLFxuICAgICAgICAgICAgICAgIGNoZWNrX2hvbGRlcjogaXRlbS5jaGVja19ob2xkZXIgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICBpc3N1ZXJfY3VpdDogaXRlbS5pc3N1ZXJfY3VpdCA/PyBudWxsLFxuICAgICAgICAgICAgICAgIGlzX3RvX29yZGVyOiBCb29sZWFuKGl0ZW0uaXNfdG9fb3JkZXIpLFxuICAgICAgICAgICAgICAgIHJlZmVyZW5jZV9udW1iZXI6IGl0ZW0ucmVmZXJlbmNlX251bWJlciA/PyBudWxsLFxuICAgICAgICAgICAgICAgIGlzX3RoaXJkX3BhcnR5X2NoZWNrOiBCb29sZWFuKGl0ZW0uaXNzdWVyX2N1aXQ/LnRyaW0oKSksXG4gICAgICAgICAgICAgICAgdWlfYWNjb3VudF9jb2RlOiBpdGVtLmNoYXJ0X2FjY291bnQ/LmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgdWlfYmFua19jb2RlOiBpdGVtLmJhbmtfaWQgPyBTdHJpbmcoaXRlbS5iYW5rX2lkKSA6ICcnLFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgc2V0UGF5bWVudEl0ZW1zKGZvcm1hdHRlZEl0ZW1zKTtcblxuICAgICAgICAgICAgLy8gMy4gUG9ibGFyIG1vbnRvcyBhcGxpY2Fkb3NcbiAgICAgICAgICAgIGNvbnN0IGFwcGxpZWQgPSAob3JpZ2luYWxEYXRhLmFwcGxpZWRfaW52b2ljZXMgPz8gW10pLnJlZHVjZSgoYWNjLCBhcHApID0+IHtcbiAgICAgICAgICAgICAgICAvLyBVc2Ftb3Mgc2FsZXNfaW52b2ljZS5pZCBjb21vIGxhIGNsYXZlXG4gICAgICAgICAgICAgICAgYWNjW2FwcC5zYWxlc19pbnZvaWNlLmlkXSA9IE51bWJlcihhcHAuYW1vdW50X2FwcGxpZWQpIHx8IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgICAgICAgIH0sIHt9IGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj4pO1xuICAgICAgICAgICAgc2V0QXBwbGllZEFtb3VudHMoYXBwbGllZCk7XG5cbiAgICAgICAgICAgIGlmIChvcmlnaW5hbERhdGEuYXBwbGllZF9jcmVkaXRfbm90ZXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjcmVkaXRBcHBsaWVkID0gb3JpZ2luYWxEYXRhLmFwcGxpZWRfY3JlZGl0X25vdGVzLnJlZHVjZSgoYWNjLCBhcHApID0+IHtcbiAgICAgICAgICAgICAgICAgICAgYWNjW2FwcC5jcmVkaXRfbm90ZS5pZF0gPSBOdW1iZXIoYXBwLmFtb3VudF9hcHBsaWVkKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgICAgICAgICAgIH0sIHt9IGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj4pO1xuICAgICAgICAgICAgICAgIHNldEFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyhjcmVkaXRBcHBsaWVkKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG9yaWdpbmFsRGF0YS5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpbmFuY2lhbEFwcGxpZWQgPSBvcmlnaW5hbERhdGEuYXBwbGllZF9maW5hbmNpYWxfbm90ZXMucmVkdWNlKChhY2MsIGFwcCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhY2NbYXBwLmZpbmFuY2lhbF9ub3RlLmlkXSA9IE51bWJlcihhcHAuYW1vdW50X2FwcGxpZWQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2M7XG4gICAgICAgICAgICAgICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPik7XG4gICAgICAgICAgICAgICAgc2V0QXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzKGZpbmFuY2lhbEFwcGxpZWQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyA0LiBGdW5jacOzbiBhc8OtbmNyb25hIHBhcmEgY2FyZ2FyIGRhdG9zIHJlbGFjaW9uYWRvcyAoaW1wdWVzdG9zIHkgZmFjdHVyYXMpXG4gICAgICAgICAgICBjb25zdCBsb2FkRWRpdERhdGEgPSBhc3luYyAoY2xpZW50SWQ6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgIHNldExvYWRpbmdDbGllbnREb2N1bWVudHModHJ1ZSk7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZnVsbENsaWVudCA9IGF3YWl0IGdldEJ5SWQ8Q2xpZW50V2l0aFRheGVzPihjbGllbnRlc01vZHVsZUNvbmZpZy5lbmRwb2ludCwgY2xpZW50SWQpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhmdWxsQ2xpZW50LnRheGVzIHx8IFtdKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWR2YW5jZUJhbGFuY2UoKE51bWJlcihmdWxsQ2xpZW50LmFkdmFuY2VfYmFsYW5jZSkgfHwgMCkgKiAtMSk7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IGNsaWVudElkLnRvU3RyaW5nKCksXG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNfYmFsYW5jZTogJ3RydWUnLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZENyZWRpdElkcyA9IG9yaWdpbmFsRGF0YS5hcHBsaWVkX2NyZWRpdF9ub3Rlcz8ubWFwKGFuID0+IGFuLmNyZWRpdF9ub3RlLmlkKSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZEZpbmFuY2lhbElkcyA9IG9yaWdpbmFsRGF0YS5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcz8ubWFwKGFuID0+IGFuLmZpbmFuY2lhbF9ub3RlLmlkKSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZENyZWRpdFByb21pc2VzID0gYXBwbGllZENyZWRpdElkcy5tYXAobm90ZUlkID0+IGdldEJ5SWQ8Q3JlZGl0Tm90ZT4oJ2NyZWRpdC1ub3RlcycsIG5vdGVJZCkpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBhcHBsaWVkRmluYW5jaWFsUHJvbWlzZXMgPSBhcHBsaWVkRmluYW5jaWFsSWRzLm1hcChub3RlSWQgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGdldEJ5SWQ8RmluYW5jaWFsTm90ZT4oJ2ZpbmFuY2lhbC1ub3RlcycsIG5vdGVJZClcbiAgICAgICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBbaW52b2ljZXNSZXNwb25zZSwgY3JlZGl0Tm90ZXNSZXNwb25zZSwgZmluYW5jaWFsTm90ZXNSZXNwb25zZSwgLi4uZmV0Y2hlZEFwcGxpZWRdID1cbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2g8U2FsZXNJbnZvaWNlPihgc2FsZXMtaW52b2ljZXM/JHtwYXJhbXMudG9TdHJpbmcoKX1gKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2g8Q3JlZGl0Tm90ZT4oYGNyZWRpdC1ub3Rlcz8ke3BhcmFtcy50b1N0cmluZygpfWApLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlYXJjaDxGaW5hbmNpYWxOb3RlPihgZmluYW5jaWFsLW5vdGVzPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uYXBwbGllZENyZWRpdFByb21pc2VzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmFwcGxpZWRGaW5hbmNpYWxQcm9taXNlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0pO1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZldGNoZWRBcHBsaWVkQ3JlZGl0Tm90ZXMgPSBmZXRjaGVkQXBwbGllZC5zbGljZSgwLCBhcHBsaWVkQ3JlZGl0UHJvbWlzZXMubGVuZ3RoKSBhcyBDcmVkaXROb3RlW107XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZldGNoZWRBcHBsaWVkRmluYW5jaWFsTm90ZXMgPSBmZXRjaGVkQXBwbGllZC5zbGljZShhcHBsaWVkQ3JlZGl0UHJvbWlzZXMubGVuZ3RoKSBhcyBGaW5hbmNpYWxOb3RlW107XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYWxsSW52b2ljZXNNYXAgPSBuZXcgTWFwPG51bWJlciwgU2FsZXNJbnZvaWNlPihcbiAgICAgICAgICAgICAgICAgICAgICAgIGludm9pY2VzUmVzcG9uc2UuZGF0YS5tYXAoaW52ID0+IFtpbnYuaWQsIGludl0pXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIChvcmlnaW5hbERhdGEuYXBwbGllZF9pbnZvaWNlcyA/PyBbXSkuZm9yRWFjaChhcHAgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZEludm9pY2UgPSBhcHAuc2FsZXNfaW52b2ljZSBhcyBTYWxlc0ludm9pY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvcmlnaW5hbEJhbGFuY2UgPSAoTnVtYmVyKGFwcGxpZWRJbnZvaWNlLmJhbGFuY2UpIHx8IDApICsgKE51bWJlcihhcHAuYW1vdW50X2FwcGxpZWQpIHx8IDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxsSW52b2ljZXNNYXAuc2V0KGFwcGxpZWRJbnZvaWNlLmlkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGFwcGxpZWRJbnZvaWNlIGFzIFNhbGVzSW52b2ljZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFsYW5jZTogb3JpZ2luYWxCYWxhbmNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBzZXRPdXRzdGFuZGluZ0ludm9pY2VzKEFycmF5LmZyb20oYWxsSW52b2ljZXNNYXAudmFsdWVzKCkpKTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBhbGxDcmVkaXROb3Rlc01hcCA9IG5ldyBNYXA8bnVtYmVyLCBDcmVkaXROb3RlPigpO1xuICAgICAgICAgICAgICAgICAgICBmZXRjaGVkQXBwbGllZENyZWRpdE5vdGVzLmZvckVhY2gobiA9PiB7IGlmIChuKSBhbGxDcmVkaXROb3Rlc01hcC5zZXQobi5pZCwgbik7IH0pO1xuICAgICAgICAgICAgICAgICAgICBjcmVkaXROb3Rlc1Jlc3BvbnNlLmRhdGEuZm9yRWFjaChuID0+IHsgaWYgKCFhbGxDcmVkaXROb3Rlc01hcC5oYXMobi5pZCkpIGFsbENyZWRpdE5vdGVzTWFwLnNldChuLmlkLCBuKTsgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbmFsQ3JlZGl0Tm90ZXMgPSBBcnJheS5mcm9tKGFsbENyZWRpdE5vdGVzTWFwLnZhbHVlcygpKS5tYXAobiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhcHBsaWVkRGV0YWlsID0gb3JpZ2luYWxEYXRhLmFwcGxpZWRfY3JlZGl0X25vdGVzPy5maW5kKGFuID0+IGFuLmNyZWRpdF9ub3RlLmlkID09PSBuLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhcHBsaWVkRGV0YWlsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudEJhbGFuY2UgPSBzaWduZWRDcmVkaXROb3RlQmFsYW5jZShuLmJhbGFuY2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLm4sIGJhbGFuY2U6IGN1cnJlbnRCYWxhbmNlICsgKE51bWJlcihhcHBsaWVkRGV0YWlsLmFtb3VudF9hcHBsaWVkKSB8fCAwKSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG47XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBzZXRQZW5kaW5nQ3JlZGl0Tm90ZXMoZmluYWxDcmVkaXROb3Rlcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYWxsRmluYW5jaWFsTm90ZXNNYXAgPSBuZXcgTWFwPG51bWJlciwgRmluYW5jaWFsTm90ZT4oKTtcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hlZEFwcGxpZWRGaW5hbmNpYWxOb3Rlcy5mb3JFYWNoKG4gPT4geyBpZiAobikgYWxsRmluYW5jaWFsTm90ZXNNYXAuc2V0KG4uaWQsIG4pOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgZmluYW5jaWFsTm90ZXNSZXNwb25zZS5kYXRhLmZvckVhY2gobiA9PiB7IGlmICghYWxsRmluYW5jaWFsTm90ZXNNYXAuaGFzKG4uaWQpKSBhbGxGaW5hbmNpYWxOb3Rlc01hcC5zZXQobi5pZCwgbik7IH0pO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaW5hbEZpbmFuY2lhbE5vdGVzID0gQXJyYXkuZnJvbShhbGxGaW5hbmNpYWxOb3Rlc01hcC52YWx1ZXMoKSkubWFwKG4gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXBwbGllZERldGFpbCA9IG9yaWdpbmFsRGF0YS5hcHBsaWVkX2ZpbmFuY2lhbF9ub3Rlcz8uZmluZChhbiA9PiBhbi5maW5hbmNpYWxfbm90ZS5pZCA9PT0gbi5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXBwbGllZERldGFpbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRCYWxhbmNlID0gc2lnbmVkVHlwZWRCYWxhbmNlKG4udHlwZSwgbi5iYWxhbmNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5uLCBiYWxhbmNlOiBjdXJyZW50QmFsYW5jZSArIChOdW1iZXIoYXBwbGllZERldGFpbC5hbW91bnRfYXBwbGllZCkgfHwgMCkgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzKGZpbmFsRmluYW5jaWFsTm90ZXMpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgZGF0b3MgZGUgZWRpY2nDs246JywgZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBkYXRvcyByZWxhY2lvbmFkb3MgcGFyYSBsYSBlZGljacOzbi4nKTtcbiAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICBzZXRMb2FkaW5nQ2xpZW50RG9jdW1lbnRzKGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvLyBFamVjdXRhciBsYSBjYXJnYVxuICAgICAgICAgICAgbG9hZEVkaXREYXRhKG9yaWdpbmFsRGF0YS5jbGllbnRfaWQpO1xuICAgICAgICB9XG4gICAgfSwgW29yaWdpbmFsRGF0YSwgbW9kZV0pO1xuXG5cbiAgICAvLyBMw5NHSUNBIENMQVZFOiBDYXJnYXIgZmFjdHVyYXMgcGVuZGllbnRlcyBhbCBzZWxlY2Npb25hciB1biBjbGllbnRlIChNT0RPIENSRUFDScOTTilcbiAgICBjb25zdCBhcHBseUNsaWVudFNlbGVjdGlvbiA9IGFzeW5jIChzZWxlY3RlZENsaWVudDogQ2xpZW50ZSkgPT4ge1xuICAgICAgICBzZXRIZWFkZXIocHJldiA9PiAoeyAuLi5wcmV2LCBjbGllbnRfaWQ6IHNlbGVjdGVkQ2xpZW50LmlkLCBjbGllbnQ6IHNlbGVjdGVkQ2xpZW50IH0pKTtcbiAgICAgICAgc2V0Q2xpZW50Q29kZUlucHV0KHNlbGVjdGVkQ2xpZW50LmN1c3RvbWVyX2NvZGUgfHwgU3RyaW5nKHNlbGVjdGVkQ2xpZW50LmlkKSk7XG4gICAgICAgIHNldE91dHN0YW5kaW5nSW52b2ljZXMoW10pO1xuICAgICAgICBzZXRQZW5kaW5nQ3JlZGl0Tm90ZXMoW10pO1xuICAgICAgICBzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMoW10pO1xuICAgICAgICBzZXRBcHBsaWVkQW1vdW50cyh7fSk7XG4gICAgICAgIHNldEFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyh7fSk7XG4gICAgICAgIHNldEFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyh7fSk7XG4gICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgc2V0Q2xpZW50QWR2YW5jZUJhbGFuY2UoMCk7XG4gICAgICAgIHNldExvYWRpbmdDbGllbnREb2N1bWVudHModHJ1ZSk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxDbGllbnQgPSBhd2FpdCBnZXRCeUlkPENsaWVudFdpdGhUYXhlcz4oY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIHNlbGVjdGVkQ2xpZW50LmlkKTtcbiAgICAgICAgICAgIGlmIChmdWxsQ2xpZW50LnRheGVzKSB7XG4gICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMoZnVsbENsaWVudC50YXhlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRDbGllbnRBZHZhbmNlQmFsYW5jZSgoTnVtYmVyKGZ1bGxDbGllbnQuYWR2YW5jZV9iYWxhbmNlKSB8fCAwKSAqIC0xKTtcblxuICAgICAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7XG4gICAgICAgICAgICAgICAgY2xpZW50X2lkOiBzZWxlY3RlZENsaWVudC5pZC50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgIGhhc19iYWxhbmNlOiAndHJ1ZScsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IFtpbnZvaWNlc1Jlc3BvbnNlLCBjcmVkaXROb3Rlc1Jlc3BvbnNlLCBmaW5hbmNpYWxOb3Rlc1Jlc3BvbnNlXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICBzZWFyY2g8U2FsZXNJbnZvaWNlPihgc2FsZXMtaW52b2ljZXM/JHtwYXJhbXMudG9TdHJpbmcoKX1gKSxcbiAgICAgICAgICAgICAgICBzZWFyY2g8Q3JlZGl0Tm90ZT4oYGNyZWRpdC1ub3Rlcz8ke3BhcmFtcy50b1N0cmluZygpfWApLFxuICAgICAgICAgICAgICAgIHNlYXJjaDxGaW5hbmNpYWxOb3RlPihgZmluYW5jaWFsLW5vdGVzPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCksXG4gICAgICAgICAgICBdKTtcblxuICAgICAgICAgICAgc2V0T3V0c3RhbmRpbmdJbnZvaWNlcyhpbnZvaWNlc1Jlc3BvbnNlLmRhdGEpO1xuICAgICAgICAgICAgc2V0UGVuZGluZ0NyZWRpdE5vdGVzKGNyZWRpdE5vdGVzUmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICBzZXRQZW5kaW5nRmluYW5jaWFsTm90ZXMoZmluYW5jaWFsTm90ZXNSZXNwb25zZS5kYXRhKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgZGF0b3MgZGVsIGNsaWVudGU6JywgZXJyKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBjYXJnYXIgZGF0b3MgZGVsIGNsaWVudGUgbyBzdXMgZG9jdW1lbnRvcyBwZW5kaWVudGVzLicpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZ0NsaWVudERvY3VtZW50cyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gMi4gTWFuZWphZG9yIGRlIGLDunNxdWVkYSBwb3IgQ8OTRElHTyAoRW50ZXIvQmx1cilcbiAgICBjb25zdCBoYW5kbGVDbGllbnRDb2RlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWNsaWVudENvZGVJbnB1dC50cmltKCkpIHJldHVybjsgLy8gTm8gYnVzY2FyIHNpIGVzdMOhIHZhY8Otb1xuXG4gICAgICAgIC8vIFNpIHlhIHRlbmVtb3MgdW4gY2xpZW50ZSBzZWxlY2Npb25hZG8geSBlbCBjw7NkaWdvIGNvaW5jaWRlLCBubyBoYWNlbW9zIG5hZGFcbiAgICAgICAgaWYgKGhlYWRlci5jbGllbnQgJiYgKGhlYWRlci5jbGllbnQuY3VpdCA9PT0gY2xpZW50Q29kZUlucHV0IHx8IFN0cmluZyhoZWFkZXIuY2xpZW50LmlkKSA9PT0gY2xpZW50Q29kZUlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIOKchSBCw5pTUVVFREEgR0VOw4lSSUNBOiBBanVzdGEgJ2N1aXQnIHBvciBlbCBjYW1wbyByZWFsIGRlIGLDunNxdWVkYSBkZSB0dSBBUElcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kSXRlbSA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8Q2xpZW50ZT4oXG4gICAgICAgICAgICAgICAgY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgW3sgZmllbGROYW1lOiAnY3VzdG9tZXJfY29kZScsIHZhbHVlOiBjbGllbnRDb2RlSW5wdXQgfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcbiAgICAgICAgICAgICAgICBhcHBseUNsaWVudFNlbGVjdGlvbihmb3VuZEl0ZW0pO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYENsaWVudGUgZW5jb250cmFkbzogJHtmb3VuZEl0ZW0ubmFtZX1gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3Qud2FybmluZygnQ2xpZW50ZSBubyBlbmNvbnRyYWRvIGNvbiBlc2UgY8OzZGlnby4nKTtcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXIocHJldiA9PiAoeyAuLi5wcmV2LCBjbGllbnRfaWQ6IHVuZGVmaW5lZCwgY2xpZW50OiB1bmRlZmluZWQgfSkpO1xuICAgICAgICAgICAgICAgIHNldE91dHN0YW5kaW5nSW52b2ljZXMoW10pO1xuICAgICAgICAgICAgICAgIHNldFBlbmRpbmdDcmVkaXROb3RlcyhbXSk7XG4gICAgICAgICAgICAgICAgc2V0UGVuZGluZ0ZpbmFuY2lhbE5vdGVzKFtdKTtcbiAgICAgICAgICAgICAgICBzZXRBcHBsaWVkQW1vdW50cyh7fSk7XG4gICAgICAgICAgICAgICAgc2V0QXBwbGllZENyZWRpdE5vdGVBbW91bnRzKHt9KTtcbiAgICAgICAgICAgICAgICBzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMoe30pO1xuICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgICAgICBzZXRDbGllbnRBZHZhbmNlQmFsYW5jZSgwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ0Vycm9yIGFsIGJ1c2NhciBjbGllbnRlLicpO1xuICAgICAgICB9XG4gICAgfTtcblxuXG4gICAgLy8gLS0tIE1BTkVKTyBERSBNT0RBTEVTIC0tLVxuICAgIGNvbnN0IG9wZW5Nb2RhbCA9ICh0YXJnZXQ6IEVkaXRpbmdUYXJnZXQsIGNvbmZpZzogYW55KSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdUYXJnZXQodGFyZ2V0KTtcbiAgICAgICAgc2V0TW9kYWxDb25maWcoY29uZmlnKTtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdE1vZGFsID0gKHNlbGVjdGVkSXRlbTogYW55KSA9PiB7XG4gICAgICAgIGlmICghZWRpdGluZ1RhcmdldCkgcmV0dXJuO1xuXG4gICAgICAgIGlmIChlZGl0aW5nVGFyZ2V0ID09PSAnY2xpZW50Jykge1xuICAgICAgICAgICAgYXBwbHlDbGllbnRTZWxlY3Rpb24oc2VsZWN0ZWRJdGVtIGFzIENsaWVudGUpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBlZGl0aW5nVGFyZ2V0ID09PSAnb2JqZWN0JyAmJiBlZGl0aW5nVGFyZ2V0LnR5cGUgPT09ICdpdGVtQWNjb3VudCcpIHtcbiAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoZWRpdGluZ1RhcmdldC5pbmRleCwgJ2NoYXJ0X2FjY291bnQnLCBzZWxlY3RlZEl0ZW0gYXMgUGxhbkRlQ3VlbnRhcyk7XG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGVkaXRpbmdUYXJnZXQuaW5kZXgsICd1aV9hY2NvdW50X2NvZGUnLCBzZWxlY3RlZEl0ZW0uY29kZSk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGVkaXRpbmdUYXJnZXQgPT09ICdvYmplY3QnICYmIGVkaXRpbmdUYXJnZXQudHlwZSA9PT0gJ2l0ZW1CYW5rJykge1xuICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShlZGl0aW5nVGFyZ2V0LmluZGV4LCAnYmFua19pZCcsIHNlbGVjdGVkSXRlbS5pZCk7XG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGVkaXRpbmdUYXJnZXQuaW5kZXgsICdiYW5rX25hbWUnLCBzZWxlY3RlZEl0ZW0ubmFtZSk7XG4gICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGVkaXRpbmdUYXJnZXQuaW5kZXgsICd1aV9iYW5rX2NvZGUnLCBTdHJpbmcoc2VsZWN0ZWRJdGVtLmlkKSk7IC8vIE8gYmFua19jb2RlXG4gICAgICAgIH1cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KG51bGwpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gTUFORUpPIERFIElURU1TIChNZWRpb3MgZGUgUGFnbykgLS0tXG4gICAgY29uc3QgaGFuZGxlSXRlbUNoYW5nZSA9IChpbmRleDogbnVtYmVyLCBmaWVsZDoga2V5b2YgRm9ybUN1c3RvbWVyUGF5bWVudEl0ZW0sIHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgc2V0UGF5bWVudEl0ZW1zKHByZXYgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3VtT3RoZXJTYWwgPSBwcmV2XG4gICAgICAgICAgICAgICAgLmZpbHRlcigoaXQsIGkpID0+IGkgIT09IGluZGV4ICYmIGl0LnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdTQUwnKVxuICAgICAgICAgICAgICAgIC5yZWR1Y2UoKHMsIGl0KSA9PiBzICsgKE51bWJlcihpdC52YWx1ZSkgfHwgMCksIDApO1xuICAgICAgICAgICAgY29uc3QgbWF4QWR2YW5jZUZvckl0ZW0gPSBNYXRoLm1heCgwLCAoY2xpZW50QWR2YW5jZUJhbGFuY2UgfHwgMCkgLSBzdW1PdGhlclNhbCk7XG5cbiAgICAgICAgICAgIHJldHVybiBwcmV2Lm1hcCgoaXRlbSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChpICE9PSBpbmRleCkgcmV0dXJuIGl0ZW07XG4gICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZEl0ZW0gPSB7IC4uLml0ZW0sIFtmaWVsZF06IHZhbHVlIH0gYXMgRm9ybUN1c3RvbWVyUGF5bWVudEl0ZW07XG5cbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgPT09ICdwYXltZW50X21ldGhvZF9jb2RlJykge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5iYW5rX2lkID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uYmFua19uYW1lID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uY2hlY2tfbnVtYmVyID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uY2hlY2tfZGF0ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnVpX2JhbmtfY29kZSA9ICcnO1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgIT09ICdDSEUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5jaGVja19kdWVfZGF0ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5jaGVja19ob2xkZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0uaXNzdWVyX2N1aXQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0ucmVmZXJlbmNlX251bWJlciA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkSXRlbS5pc190aGlyZF9wYXJ0eV9jaGVjayA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJ1NBTCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3NzQW1vdW50ID0gY29tcHV0ZUNvbGxlY3Rpb25Hcm9zc0Ftb3VudChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBsaWVkQW1vdW50cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzY291bnQgPSBOdW1iZXIoaGVhZGVyLmRpc2NvdW50X2Ftb3VudCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsVGF4ZXMgPSAoY2xpZW50VGF4ZXMgfHwgW10pLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIGRpc2NvdW50ICogKCh0YXgucmF0ZSB8fCAwKSAvIDEwMCksIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV0QW1vdW50VG9QYXkgPSBncm9zc0Ftb3VudCAtIGRpc2NvdW50IC0gdG90YWxUYXhlcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRJdGVtLnZhbHVlID0gTWF0aC5tYXgoMCwgTWF0aC5taW4obmV0QW1vdW50VG9QYXksIG1heEFkdmFuY2VGb3JJdGVtKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSAndmFsdWUnICYmIGl0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ1NBTCcpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbnVtVmFsID0gTnVtYmVyKHZhbHVlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBpZiAobnVtVmFsID4gbWF4QWR2YW5jZUZvckl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIG1vbnRvIG5vIHB1ZWRlIHN1cGVyYXIgZWwgc2FsZG8gYW50aWNpcGFkbyBkaXNwb25pYmxlICgke2Zvcm1hdFZhbHVlKG1heEFkdmFuY2VGb3JJdGVtLCAnY3VycmVuY3knKX0pLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEl0ZW0udmFsdWUgPSBtYXhBZHZhbmNlRm9ySXRlbTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdXBkYXRlZEl0ZW07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIOKchSBOVUVWTzogSGFuZGxlciBlc3BlY8OtZmljbyBwYXJhIGxhIGLDunNxdWVkYSBwb3IgY8OzZGlnbyBkZW50cm8gZGUgdW4gSVRFTSAoQXJyYXkpXG4gICAgY29uc3QgaGFuZGxlSXRlbUNvZGVTdWJtaXQgPSBhc3luYyAoaW5kZXg6IG51bWJlciwgdHlwZTogJ2FjY291bnQnIHwgJ2JhbmsnKSA9PiB7XG4gICAgICAgIGNvbnN0IGl0ZW0gPSBwYXltZW50SXRlbXNbaW5kZXhdO1xuICAgICAgICBjb25zdCBjb2RlVG9TZWFyY2ggPSB0eXBlID09PSAnYWNjb3VudCcgPyBpdGVtLnVpX2FjY291bnRfY29kZSA6IGl0ZW0udWlfYmFua19jb2RlO1xuXG4gICAgICAgIGlmICghY29kZVRvU2VhcmNoKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICh0eXBlID09PSAnYWNjb3VudCcpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8UGxhbkRlQ3VlbnRhcz4oXG4gICAgICAgICAgICAgICAgICAgIHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcuZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ2NvZGUnLCB2YWx1ZTogY29kZVRvU2VhcmNoIH1dXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICBpZiAoZm91bmQpIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2NoYXJ0X2FjY291bnQnLCBmb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIEFjdHVhbGl6YW1vcyBlbCBjw7NkaWdvIHZpc3VhbCBwb3Igc2kgZWwgdXN1YXJpbyBlc2NyaWJpw7MgcGFyY2lhbG1lbnRlIHkgbGEgQVBJIGRldm9sdmnDsyBlbCBjb3JyZWN0b1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndWlfYWNjb3VudF9jb2RlJywgZm91bmQuY29kZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdG9hc3Qud2FybignQ3VlbnRhIGNvbnRhYmxlIG5vIGVuY29udHJhZGEnKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2NoYXJ0X2FjY291bnQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlID09PSAnYmFuaycpIHtcbiAgICAgICAgICAgICAgICAvLyBUaXA6IFVzYSBlbCB0aXBvICdCYW5jbycgcmVhbCBzaSBsbyB0aWVuZXMgaW1wb3J0YWRvLCBhcXXDrSB1c28gJ2FueScgcGFyYSBxdWUgbm8gdGUgZGUgZXJyb3IgYWwgcGVnYXJcbiAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8YW55PihcbiAgICAgICAgICAgICAgICAgICAgYmFuY29zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgICAgICAvLyDimqDvuI8gT0pPOiBTaSB0dXMgdXN1YXJpb3MgZXNjcmliZW4gZWwgSUQgZW4gdmV6IGRlbCBjw7NkaWdvLCBjYW1iaWEgJ2NvZGUnIHBvciAnaWQnXG4gICAgICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ2NvZGUnLCB2YWx1ZTogY29kZVRvU2VhcmNoIH1dXG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAnYmFua19pZCcsIGZvdW5kLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2JhbmtfbmFtZScsIGZvdW5kLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAvLyBBY3R1YWxpemFtb3MgZWwgaW5wdXQgdmlzdWFsIGNvbiBlbCBjw7NkaWdvIG9maWNpYWwgcXVlIHZpbm8gZGUgbGEgQkQgKG8gZWwgSUQgc2kgbm8gaGF5IGPDs2RpZ28pXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICd1aV9iYW5rX2NvZGUnLCBmb3VuZC5jb2RlIHx8IFN0cmluZyhmb3VuZC5pZCkpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oJ0JhbmNvIG5vIGVuY29udHJhZG8nKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2JhbmtfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2JhbmtfbmFtZScsIG51bGwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIC4uLiBSZXBldGlyIGzDs2dpY2Egc2ltaWxhciBwYXJhIEJhbmNvIHNpIGFwbGljYSAuLi5cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgfVxuICAgIH07XG5cblxuICAgIGNvbnN0IGFkZE5ld0l0ZW0gPSAoKSA9PiB7XG4gICAgICAgIHNldFBheW1lbnRJdGVtcyhwcmV2ID0+IFtcbiAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGVtcElkOiBgbmV3LSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgICAgICAgIHBheW1lbnRfbWV0aG9kX2NvZGU6ICdFRkUnLFxuICAgICAgICAgICAgICAgIGJhbmtfaWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgYmFua19uYW1lOiBudWxsLFxuICAgICAgICAgICAgICAgIGNoZWNrX251bWJlcjogbnVsbCxcbiAgICAgICAgICAgICAgICBjaGVja19kYXRlOiBudWxsLFxuICAgICAgICAgICAgICAgIGNoZWNrX2R1ZV9kYXRlOiBudWxsLFxuICAgICAgICAgICAgICAgIGNoZWNrX2hvbGRlcjogbnVsbCxcbiAgICAgICAgICAgICAgICBpc3N1ZXJfY3VpdDogbnVsbCxcbiAgICAgICAgICAgICAgICBpc190b19vcmRlcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlX251bWJlcjogbnVsbCxcbiAgICAgICAgICAgICAgICBpc190aGlyZF9wYXJ0eV9jaGVjazogZmFsc2UsXG4gICAgICAgICAgICAgICAgdmFsdWU6IDAsXG4gICAgICAgICAgICAgICAgY2hlY2tfa2V5OiBudWxsLFxuICAgICAgICAgICAgICAgIGNoYXJ0X2FjY291bnQ6IG51bGwsXG4gICAgICAgICAgICAgICAgdWlfYWNjb3VudF9jb2RlOiAnJyxcbiAgICAgICAgICAgICAgICB1aV9iYW5rX2NvZGU6ICcnXG4gICAgICAgICAgICB9XG4gICAgICAgIF0pO1xuICAgIH07XG5cbiAgICBjb25zdCByZW1vdmVJdGVtID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgc2V0UGF5bWVudEl0ZW1zKHByZXYgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUFwcGx5QW1vdW50ID0gKGludm9pY2VJZDogbnVtYmVyLCBhbW91bnQ6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBudW1lcmljQW1vdW50ID0gTnVtYmVyKGFtb3VudCkgfHwgMDtcbiAgICAgICAgc2V0QXBwbGllZEFtb3VudHMocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtpbnZvaWNlSWRdOiBudW1lcmljQW1vdW50LFxuICAgICAgICB9KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNpZ25lZERvY3VtZW50QW1vdW50Q2hhbmdlID0gKFxuICAgICAgICBub3RlSWQ6IG51bWJlcixcbiAgICAgICAgYmFsYW5jZTogbnVtYmVyLFxuICAgICAgICB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyLFxuICAgICAgICBzZXR0ZXI6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFJlY29yZDxzdHJpbmcsIG51bWJlciB8IHN0cmluZz4+PixcbiAgICApID0+IHtcbiAgICAgICAgY29uc3QgY2xhbXBlZCA9IGNsYW1wQXBwbGllZFRvU2lnbmVkQmFsYW5jZSh2YWx1ZSwgYmFsYW5jZSk7XG4gICAgICAgIGNvbnN0IG51bWVyaWNWYWx1ZSA9IE51bWJlcih2YWx1ZSkgfHwgMDtcbiAgICAgICAgaWYgKGNsYW1wZWQgIT09IG51bWVyaWNWYWx1ZSkge1xuICAgICAgICAgICAgdG9hc3Qud2FybihgRWwgbW9udG8gbm8gcHVlZGUgc3VwZXJhciBlbCBzYWxkbyAoJHtmb3JtYXRWYWx1ZShiYWxhbmNlLCAnY3VycmVuY3knKX0pYCk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0dGVyKHByZXYgPT4gKHsgLi4ucHJldiwgW25vdGVJZF06IGNsYW1wZWQgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDcmVkaXROb3RlQW1vdW50Q2hhbmdlID0gKG5vdGVJZDogbnVtYmVyLCB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyKSA9PiB7XG4gICAgICAgIGNvbnN0IG5vdGUgPSBwZW5kaW5nQ3JlZGl0Tm90ZXMuZmluZChuID0+IG4uaWQgPT09IG5vdGVJZCk7XG4gICAgICAgIGlmICghbm90ZSkgcmV0dXJuO1xuICAgICAgICBoYW5kbGVTaWduZWREb2N1bWVudEFtb3VudENoYW5nZShcbiAgICAgICAgICAgIG5vdGVJZCxcbiAgICAgICAgICAgIHNpZ25lZENyZWRpdE5vdGVCYWxhbmNlKG5vdGUuYmFsYW5jZSksXG4gICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgIHNldEFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyxcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRmluYW5jaWFsTm90ZUFtb3VudENoYW5nZSA9IChub3RlSWQ6IG51bWJlciwgdmFsdWU6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBub3RlID0gcGVuZGluZ0ZpbmFuY2lhbE5vdGVzLmZpbmQobiA9PiBuLmlkID09PSBub3RlSWQpO1xuICAgICAgICBpZiAoIW5vdGUpIHJldHVybjtcbiAgICAgICAgaGFuZGxlU2lnbmVkRG9jdW1lbnRBbW91bnRDaGFuZ2UoXG4gICAgICAgICAgICBub3RlSWQsXG4gICAgICAgICAgICBzaWduZWRUeXBlZEJhbGFuY2Uobm90ZS50eXBlLCBub3RlLmJhbGFuY2UpLFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICBzZXRBcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMsXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIGNvbnN0IGNyZWRpdE5vdGVSb3dzID0gdXNlTWVtbygoKTogUGVuZGluZ1NpZ25lZERvY3VtZW50Um93W10gPT4ge1xuICAgICAgICByZXR1cm4gcGVuZGluZ0NyZWRpdE5vdGVzLm1hcChub3RlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJhbGFuY2UgPSBzaWduZWRDcmVkaXROb3RlQmFsYW5jZShub3RlLmJhbGFuY2UpO1xuICAgICAgICAgICAgY29uc3QgdG90YWwgPSBzaWduZWRDcmVkaXROb3RlVG90YWwobm90ZS50b3RhbF9hbW91bnQpO1xuICAgICAgICAgICAgY29uc3QgZG9jTnVtYmVyID0gbm90ZS5zYWxlc19pbnZvaWNlPy5pbnZvaWNlX251bWJlciB8fCBub3RlLnZvdWNoZXJfbnVtYmVyIHx8ICctJztcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgaWQ6IG5vdGUuaWQsXG4gICAgICAgICAgICAgICAgZG9jTGFiZWw6IGRvY051bWJlcixcbiAgICAgICAgICAgICAgICBiYWxhbmNlLFxuICAgICAgICAgICAgICAgIGRhdGU6IGZvcm1hdFZhbHVlKG5vdGUuaXNzdWVfZGF0ZSwgJ2RhdGUnKSBhcyBzdHJpbmcsXG4gICAgICAgICAgICAgICAgZG9jTnVtYmVyLFxuICAgICAgICAgICAgICAgIHRvdGFsLFxuICAgICAgICAgICAgICAgIGJhbGFuY2VEaXNwbGF5OiBiYWxhbmNlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgfSwgW3BlbmRpbmdDcmVkaXROb3Rlc10pO1xuXG4gICAgY29uc3QgZmluYW5jaWFsTm90ZVJvd3MgPSB1c2VNZW1vKCgpOiBQZW5kaW5nU2lnbmVkRG9jdW1lbnRSb3dbXSA9PiB7XG4gICAgICAgIHJldHVybiBwZW5kaW5nRmluYW5jaWFsTm90ZXMubWFwKG5vdGUgPT4ge1xuICAgICAgICAgICAgY29uc3QgYmFsYW5jZSA9IHNpZ25lZFR5cGVkQmFsYW5jZShub3RlLnR5cGUsIG5vdGUuYmFsYW5jZSk7XG4gICAgICAgICAgICBjb25zdCB0b3RhbCA9IHNpZ25lZFR5cGVkVG90YWwobm90ZS50eXBlLCBub3RlLnRvdGFsX2Ftb3VudCk7XG4gICAgICAgICAgICBjb25zdCBkb2NOdW1iZXIgPSBub3RlLnNhbGVzX2ludm9pY2U/Lmludm9pY2VfbnVtYmVyIHx8IG5vdGUudm91Y2hlcl9udW1iZXIgfHwgJy0nO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBpZDogbm90ZS5pZCxcbiAgICAgICAgICAgICAgICBkb2NMYWJlbDogZG9jTnVtYmVyLFxuICAgICAgICAgICAgICAgIGJhbGFuY2UsXG4gICAgICAgICAgICAgICAgZGF0ZTogZm9ybWF0VmFsdWUobm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpIGFzIHN0cmluZyxcbiAgICAgICAgICAgICAgICBkb2NOdW1iZXIsXG4gICAgICAgICAgICAgICAgdG90YWwsXG4gICAgICAgICAgICAgICAgYmFsYW5jZURpc3BsYXk6IGJhbGFuY2UsXG4gICAgICAgICAgICAgICAgdHlwZTogbm90ZS50eXBlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgfSwgW3BlbmRpbmdGaW5hbmNpYWxOb3Rlc10pO1xuXG4gICAgLy8gLS0tIEPDgUxDVUxPUyAoRXNwZWpvIGRlIE9yZGVuZXNQYWdvKSAtLS1cbiAgICBjb25zdCB0b3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3QgaW52b2ljZXNHcm9zc0Ftb3VudCA9IHN1bUFwcGxpZWRBbW91bnRzUmVjb3JkKGFwcGxpZWRBbW91bnRzKTtcbiAgICAgICAgY29uc3QgY3JlZGl0Tm90ZXNHcm9zc0Ftb3VudCA9IHN1bUFwcGxpZWRBbW91bnRzUmVjb3JkKGFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyk7XG4gICAgICAgIGNvbnN0IGZpbmFuY2lhbE5vdGVzR3Jvc3NBbW91bnQgPSBzdW1BcHBsaWVkQW1vdW50c1JlY29yZChhcHBsaWVkRmluYW5jaWFsTm90ZUFtb3VudHMpO1xuICAgICAgICBjb25zdCBncm9zc0Ftb3VudCA9IGNvbXB1dGVDb2xsZWN0aW9uR3Jvc3NBbW91bnQoXG4gICAgICAgICAgICBhcHBsaWVkQW1vdW50cyxcbiAgICAgICAgICAgIGFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyxcbiAgICAgICAgICAgIGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50c1xuICAgICAgICApO1xuXG4gICAgICAgIC8vIDIuIERlc2N1ZW50byAoSW5ncmVzYWRvIG1hbnVhbG1lbnRlKVxuICAgICAgICBjb25zdCBkaXNjb3VudCA9IE51bWJlcihoZWFkZXIuZGlzY291bnRfYW1vdW50KSB8fCAwO1xuXG4gICAgICAgIGNvbnN0IHRheGFibGVCYXNlID0gZGlzY291bnQ7XG5cbiAgICAgICAgLy8gMy4gUmV0ZW5jaW9uZXMgKEltcHVlc3RvcyBkZWwgY2xpZW50ZSBhcGxpY2Fkb3MgYWwgZGVzY3VlbnRvKVxuICAgICAgICBjb25zdCBhcHBsaWVkVGF4ZXM6IEFwcGxpZWRUYXhbXSA9IGNsaWVudFRheGVzLm1hcCh0YXggPT4ge1xuICAgICAgICAgICAgY29uc3QgdGF4QW1vdW50ID0gKHRheGFibGVCYXNlICogKHRheC5yYXRlIC8gMTAwKSk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHRheF9pZDogdGF4LmlkLFxuICAgICAgICAgICAgICAgIHRheF9uYW1lOiB0YXgubmFtZSxcbiAgICAgICAgICAgICAgICByYXRlOiB0YXgucmF0ZSxcbiAgICAgICAgICAgICAgICBhbW91bnQ6IHRheEFtb3VudCxcbiAgICAgICAgICAgICAgICBjaGFydF9hY2NvdW50X2lkOiB0YXguY2hhcnRfYWNjb3VudF9pZFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHRvdGFsVGF4ZXMgPSBhcHBsaWVkVGF4ZXMucmVkdWNlKChzdW0sIHRheCkgPT4gc3VtICsgdGF4LmFtb3VudCwgMCk7XG5cbiAgICAgICAgLy8gNC4gTmV0byBhIENvYnJhclxuICAgICAgICBjb25zdCBuZXRBbW91bnRUb1BheSA9IGdyb3NzQW1vdW50IC0gZGlzY291bnQgLSB0b3RhbFRheGVzO1xuXG4gICAgICAgIC8vIDUuIFRvdGFsIENvYnJhZG8gKFN1bWEgZGUgbWVkaW9zIGRlIHBhZ28pXG4gICAgICAgIGNvbnN0IHRvdGFsUGFpZCA9IHBheW1lbnRJdGVtcy5yZWR1Y2UoXG4gICAgICAgICAgICAoc3VtOiBudW1iZXIsIGl0ZW06IEZvcm1DdXN0b21lclBheW1lbnRJdGVtKSA9PiBzdW0gKyAoTnVtYmVyKGl0ZW0udmFsdWUpIHx8IDApLCAwXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgcmVtYWluaW5nVG9QYXkgPSBNYXRoLnJvdW5kKChuZXRBbW91bnRUb1BheSAtIHRvdGFsUGFpZCkgKiAxMDApIC8gMTAwO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBncm9zc0Ftb3VudCxcbiAgICAgICAgICAgIGludm9pY2VzR3Jvc3NBbW91bnQsXG4gICAgICAgICAgICBjcmVkaXROb3Rlc0dyb3NzQW1vdW50LFxuICAgICAgICAgICAgZmluYW5jaWFsTm90ZXNHcm9zc0Ftb3VudCxcbiAgICAgICAgICAgIGRpc2NvdW50LFxuICAgICAgICAgICAgYXBwbGllZFRheGVzLFxuICAgICAgICAgICAgdG90YWxUYXhlcyxcbiAgICAgICAgICAgIG5ldEFtb3VudFRvUGF5LFxuICAgICAgICAgICAgdG90YWxQYWlkLFxuICAgICAgICAgICAgcmVtYWluaW5nVG9QYXksXG4gICAgICAgIH07XG4gICAgfSwgW2FwcGxpZWRBbW91bnRzLCBhcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHMsIGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cywgY2xpZW50VGF4ZXMsIGhlYWRlci5kaXNjb3VudF9hbW91bnQsIHBheW1lbnRJdGVtc10pO1xuXG4gICAgLyoqIENvbXBsZXRhIGVsIHZhbG9yIGRlIGxhIGzDrW5lYSBjb24gKHRvdGFsIGFwbGljYWRvIGEgZmFjdHVyYXMpIOKIkiAoc3VtYSBkZSBkZW3DoXMgbWVkaW9zIGRlIHBhZ28pLiAqL1xuICAgIGNvbnN0IGZpbGxQYXltZW50TGluZUZyb21BcHBsaWVkVG90YWwgPSAoaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCB0b3RhbEFwbGljYWRvID0gdG90YWxzLmdyb3NzQW1vdW50O1xuICAgICAgICBjb25zdCBzdW1PdHJvcyA9IHBheW1lbnRJdGVtcy5yZWR1Y2UoXG4gICAgICAgICAgICAocywgaXQsIGkpID0+IChpID09PSBpbmRleCA/IHMgOiBzICsgKE51bWJlcihpdC52YWx1ZSkgfHwgMCkpLFxuICAgICAgICAgICAgMFxuICAgICAgICApO1xuICAgICAgICBsZXQgbW9udG8gPSBNYXRoLnJvdW5kKCh0b3RhbEFwbGljYWRvIC0gc3VtT3Ryb3MpICogMTAwKSAvIDEwMDtcbiAgICAgICAgaWYgKG1vbnRvIDwgMCkge1xuICAgICAgICAgICAgdG9hc3Qud2FybihcbiAgICAgICAgICAgICAgICAnRWwgdG90YWwgYXBsaWNhZG8gZXMgbWVub3IgcXVlIGxhIHN1bWEgZGUgbG9zIGRlbcOhcyBtZWRpb3MgZGUgcGFnbzsgc2UgdXNhcsOhIDAgZW4gZXN0YSBsw61uZWEuJ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIG1vbnRvID0gMDtcbiAgICAgICAgfVxuICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndmFsdWUnLCBtb250byk7XG4gICAgfTtcblxuICAgIGNvbnN0IHBlcmZvcm1TYXZlQ29icmFuemEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGl0ZW1zVG9TYXZlID0gcGF5bWVudEl0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJhc2U6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICAgICAgICAgIGlkOiAoaXRlbSBhcyBhbnkpLmlkIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBwYXltZW50X21ldGhvZF9jb2RlOiBpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUsXG4gICAgICAgICAgICAgICAgYmFua19pZDogaXRlbS5iYW5rX2lkLFxuICAgICAgICAgICAgICAgIGNoZWNrX251bWJlcjogaXRlbS5jaGVja19udW1iZXIgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICBjaGVja19kYXRlOiBpdGVtLmNoZWNrX2RhdGUgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICB2YWx1ZTogTnVtYmVyKGl0ZW0udmFsdWUpIHx8IDAsXG4gICAgICAgICAgICAgICAgY2hhcnRfYWNjb3VudF9pZDogaXRlbS5jaGFydF9hY2NvdW50Py5pZCB8fCBudWxsLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSEUnKSB7XG4gICAgICAgICAgICAgICAgYmFzZS5jaGVja19kdWVfZGF0ZSA9IGl0ZW0uY2hlY2tfZHVlX2RhdGUgPz8gbnVsbDtcbiAgICAgICAgICAgICAgICBiYXNlLmNoZWNrX2hvbGRlciA9IGl0ZW0uY2hlY2tfaG9sZGVyID8/IG51bGw7XG4gICAgICAgICAgICAgICAgYmFzZS5pc3N1ZXJfY3VpdCA9IGl0ZW0uaXNzdWVyX2N1aXQgPz8gbnVsbDtcbiAgICAgICAgICAgICAgICBiYXNlLmlzX3RvX29yZGVyID0gQm9vbGVhbihpdGVtLmlzX3RvX29yZGVyKTtcbiAgICAgICAgICAgICAgICBiYXNlLnJlZmVyZW5jZV9udW1iZXIgPSBpdGVtLnJlZmVyZW5jZV9udW1iZXIgPz8gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdSRVQnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVmID0gaXRlbS5yZWZlcmVuY2VfbnVtYmVyICE9IG51bGwgPyBTdHJpbmcoaXRlbS5yZWZlcmVuY2VfbnVtYmVyKS50cmltKCkgOiAnJztcbiAgICAgICAgICAgICAgICBiYXNlLnJlZmVyZW5jZV9udW1iZXIgPSByZWYgIT09ICcnID8gcmVmIDogbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBiYXNlO1xuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBhcHBsaWVkSW52b2ljZXNUb1NhdmUgPSBidWlsZEFwcGxpZWRJbnZvaWNlc0ZvclNhdmUoYXBwbGllZEFtb3VudHMpO1xuICAgICAgICBjb25zdCBhcHBsaWVkX2NyZWRpdF9ub3RlcyA9IGJ1aWxkQXBwbGllZENyZWRpdE5vdGVzRm9yU2F2ZShhcHBsaWVkQ3JlZGl0Tm90ZUFtb3VudHMpO1xuICAgICAgICBjb25zdCBhcHBsaWVkX2ZpbmFuY2lhbF9ub3RlcyA9IGJ1aWxkQXBwbGllZFNhbGVzRmluYW5jaWFsTm90ZXNGb3JTYXZlKGFwcGxpZWRGaW5hbmNpYWxOb3RlQW1vdW50cyk7XG5cbiAgICAgICAgY29uc3QgdGF4ZXNUb1NhdmUgPSB0b3RhbHMuYXBwbGllZFRheGVzLmZpbHRlcih0YXggPT4gdGF4LmFtb3VudCA+IDApO1xuXG4gICAgICAgIGNvbnN0IGRhdGFUb1NhdmUgPSB7XG4gICAgICAgICAgICAuLi5oZWFkZXIsXG4gICAgICAgICAgICBjbGllbnRfaWQ6IGhlYWRlci5jbGllbnRfaWQsXG4gICAgICAgICAgICBwYXltZW50X2RhdGU6IGhlYWRlci5jb2xsZWN0aW9uX2RhdGUsXG4gICAgICAgICAgICBncm9zc19hbW91bnQ6IHRvdGFscy5ncm9zc0Ftb3VudCxcbiAgICAgICAgICAgIGRpc2NvdW50OiB0b3RhbHMuZGlzY291bnQsXG4gICAgICAgICAgICB0b3RhbF9hbW91bnQ6IHRvdGFscy50b3RhbFBhaWQsXG4gICAgICAgICAgICB0YXhlczogdGF4ZXNUb1NhdmUsXG4gICAgICAgICAgICBpdGVtczogaXRlbXNUb1NhdmUsXG4gICAgICAgICAgICBhcHBsaWVkX2ludm9pY2VzOiBhcHBsaWVkSW52b2ljZXNUb1NhdmUsXG4gICAgICAgICAgICBhcHBsaWVkX2NyZWRpdF9ub3RlcyxcbiAgICAgICAgICAgIGFwcGxpZWRfZmluYW5jaWFsX25vdGVzLFxuICAgICAgICAgICAgY3VycmVuY3lfaWQ6IDEsXG4gICAgICAgIH07XG5cbiAgICAgICAgZGVsZXRlIGRhdGFUb1NhdmUuY2xpZW50O1xuICAgICAgICBkZWxldGUgZGF0YVRvU2F2ZS5jaGFydF9hY2NvdW50O1xuXG4gICAgICAgIHNldElzU2F2aW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgc2F2ZUl0ZW0oZGF0YVRvU2F2ZSBhcyB1bmtub3duIGFzIFBhcnRpYWw8Q3VzdG9tZXJQYXltZW50Pik7XG4gICAgICAgICAgICBjb25zdCBzYXZlRXJyb3IgPSAodXNlQ3J1ZEl0ZW0gYXMgYW55KS5lcnJvcjtcbiAgICAgICAgICAgIGlmICghc2F2ZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgdG9hc3Quc3VjY2VzcygnQ29icmFuemEgZ3VhcmRhZGEgY29uIMOpeGl0byEnKTtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChjb2JyYW56YXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKHNhdmVFcnJvcjogdW5rbm93bikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGd1YXJkYXI6XCIsIHNhdmVFcnJvcik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1NhdmluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIHBheW1lbnRJdGVtcyxcbiAgICAgICAgYXBwbGllZEFtb3VudHMsXG4gICAgICAgIGFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyxcbiAgICAgICAgYXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzLFxuICAgICAgICB0b3RhbHMuYXBwbGllZFRheGVzLFxuICAgICAgICB0b3RhbHMuZ3Jvc3NBbW91bnQsXG4gICAgICAgIHRvdGFscy5kaXNjb3VudCxcbiAgICAgICAgdG90YWxzLnRvdGFsUGFpZCxcbiAgICAgICAgaGVhZGVyLFxuICAgICAgICBzYXZlSXRlbSxcbiAgICAgICAgbmF2aWdhdGUsXG4gICAgXSk7XG5cbiAgICAvLyAtLS0gR1VBUkRBUiAtLS1cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWhlYWRlci5jbGllbnRfaWQpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRGViZSBzZWxlY2Npb25hciB1biBjbGllbnRlLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBwYXltZW50SXRlbXMpIHtcbiAgICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdUUkEnICYmICFpdGVtLmJhbmtfaWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignUGFyYSB0cmFuc2ZlcmVuY2lhcyBkZWJlIHNlbGVjY2lvbmFyIHVuIGJhbmNvLicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdSRVQnICYmIE51bWJlcihpdGVtLnZhbHVlKSA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZWYgPSBpdGVtLnJlZmVyZW5jZV9udW1iZXIgIT0gbnVsbCA/IFN0cmluZyhpdGVtLnJlZmVyZW5jZV9udW1iZXIpLnRyaW0oKSA6ICcnO1xuICAgICAgICAgICAgICAgIGlmICghcmVmKSB7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdQYXJhIHJldGVuY2nDs24gZGViZSBzZWxlY2Npb25hciBlbCB0aXBvIGRlIHJldGVuY2nDs24gKGltcHVlc3RvKS4nKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSEUnICYmIE51bWJlcihpdGVtLnZhbHVlKSA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbWlzc2lvbiA9IGl0ZW0uY2hlY2tfZGF0ZSAhPSBudWxsID8gU3RyaW5nKGl0ZW0uY2hlY2tfZGF0ZSkudHJpbSgpIDogJyc7XG4gICAgICAgICAgICAgICAgaWYgKCFlbWlzc2lvbikge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignUGFyYSBjaGVxdWVzIGRlYmUgaW5ncmVzYXIgbGEgZmVjaGEgZGUgZW1pc2nDs24uJyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXRlbS5wYXltZW50X21ldGhvZF9jb2RlICE9PSAnQ0hFJyB8fCBpdGVtLmlzX3RoaXJkX3BhcnR5X2NoZWNrICE9PSB0cnVlKSBjb250aW51ZTtcbiAgICAgICAgICAgIGNvbnN0IGN1aXRWYWwgPSAoaXRlbS5pc3N1ZXJfY3VpdCB8fCAnJykudHJpbSgpO1xuICAgICAgICAgICAgaWYgKCFjdWl0VmFsKSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1NpIGVsIGNoZXF1ZSBlcyBkZSB0ZXJjZXJvLCBkZWJlIGluZ3Jlc2FyIGVsIENVSVQgZGVsIGVtaXNvci4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlTWFzaygnY3VpdCcsIGN1aXRWYWwpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWFzayA9IGdldE1hc2soJ2N1aXQnKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihtYXNrPy5lcnJvck1lc3NhZ2UgPz8gJ0NVSVQgZGVsIGVtaXNvciBpbnbDoWxpZG8uIFJldmlzZSBlbCBmb3JtYXRvIChYWC1YWFhYWFhYWC1YKS4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBoYXNBcHBsaWVkSW52b2ljZXMgPSBidWlsZEFwcGxpZWRJbnZvaWNlc0ZvclNhdmUoYXBwbGllZEFtb3VudHMpLmxlbmd0aCA+IDA7XG4gICAgICAgIGNvbnN0IHNraXBCYWxhbmNlQ2hlY2sgPSBpc0FkanVzdG1lbnRPbmx5Q29sbGVjdGlvbihwYXltZW50SXRlbXMpICYmICFoYXNBcHBsaWVkSW52b2ljZXM7XG4gICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IHRvdGFscy5yZW1haW5pbmdUb1BheTtcbiAgICAgICAgaWYgKCFza2lwQmFsYW5jZUNoZWNrKSB7XG4gICAgICAgICAgICBpZiAocmVtYWluaW5nID4gMC4wMSkge1xuICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKGBGYWx0YSBjb2JyYXIgJHtmb3JtYXRWYWx1ZShyZW1haW5pbmcsICdjdXJyZW5jeScpfS4gRWwgdG90YWwgY29icmFkbyAoJHtmb3JtYXRWYWx1ZSh0b3RhbHMudG90YWxQYWlkLCAnY3VycmVuY3knKX0pIGVzIG1lbm9yIHF1ZSBlbCBuZXRvIGEgY29icmFyICgke2Zvcm1hdFZhbHVlKHRvdGFscy5uZXRBbW91bnRUb1BheSwgJ2N1cnJlbmN5Jyl9KS5gKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVtYWluaW5nIDwgLTAuMDEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhZHZhbmNlQW1vdW50ID0gTWF0aC5hYnMocmVtYWluaW5nKTtcbiAgICAgICAgICAgICAgICBzaG93Q29uZmlybWF0aW9uTW9kYWwoe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1NhbGRvIGEgZmF2b3IgZGVsIGNsaWVudGUnLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOlxuICAgICAgICAgICAgICAgICAgICAgICAgYEVsIG5ldG8gYSBjb2JyYXIgZXMgbWVub3IgcXVlIGVsIHRvdGFsIGRlIG1lZGlvcyBkZSBwYWdvLiBTZSBnZW5lcmFyw6EgdW4gc2FsZG8gYSBmYXZvciAoYW50aWNpcG8pIGRlbCBjbGllbnRlIHBvciAke2Zvcm1hdFZhbHVlKGFkdmFuY2VBbW91bnQsICdjdXJyZW5jeScpfS4gwr9EZXNlYSBjb250aW51YXI/YCxcbiAgICAgICAgICAgICAgICAgICAgb25Db25maXJtOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2b2lkIHBlcmZvcm1TYXZlQ29icmFuemEoKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBwZXJmb3JtU2F2ZUNvYnJhbnphKCk7XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nRGF0YSAmJiBtb2RlID09PSAnZWRpdCcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz47XG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5FcnJvciBhbCBjYXJnYXIgZGF0b3M6IHtlcnJvcn08L2Rpdj47XG5cbiAgICAvLyAtLS0gUkVOREVSIC0tLVxuICAgIGNvbnN0IGlucHV0U3R5bGUgPSBcInctZnVsbCBweC0zIHB5LTIgbXQtMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgc206dGV4dC1zbVwiO1xuXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00XCI+XG4gICAgICAgICAgICAgICAge21vZGUgPT09ICdjcmVhdGUnID8gJ0NyZWFyJyA6ICdFZGl0YXInfSB7Y29icmFuemFzTW9kdWxlQ29uZmlnLm1vZHVsZU5hbWV9XG4gICAgICAgICAgICA8L2gyPlxuXG4gICAgICAgICAgICB7LyogLS0tIENBQkVDRVJBIChDbGllbnRlIHkgRmVjaGEpIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi00IHAtNCBib3JkZXIgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+Q2xpZW50ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Y2xpZW50Q29kZUlucHV0fSAvLyBFbCB0ZXh0byBxdWUgZXNjcmliZSBlbCB1c3VhcmlvXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2hlYWRlci5jbGllbnQ/Lm5hbWUgfHwgbnVsbH0gLy8gRWwgbm9tYnJlIHNvbG8gbGVjdHVyYVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXtzZXRDbGllbnRDb2RlSW5wdXR9IC8vIEFjdHVhbGl6YSBlbCB0ZXh0byBtaWVudHJhcyBlc2NyaWJlXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9e2hhbmRsZUNsaWVudENvZGVTdWJtaXR9IC8vIEJ1c2NhIGFsIGRhciBFbnRlci9CbHVyXG4gICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBvcGVuTW9kYWwoJ2NsaWVudCcsIGNsaWVudGVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEhlYWRlcihwcmV2ID0+ICh7IC4uLnByZXYsIGNsaWVudF9pZDogdW5kZWZpbmVkLCBjbGllbnQ6IHVuZGVmaW5lZCB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50Q29kZUlucHV0KCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRPdXRzdGFuZGluZ0ludm9pY2VzKFtdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQZW5kaW5nQ3JlZGl0Tm90ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBlbmRpbmdGaW5hbmNpYWxOb3RlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXBwbGllZEFtb3VudHMoe30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFwcGxpZWRDcmVkaXROb3RlQW1vdW50cyh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzKHt9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhlcyhbXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50QWR2YW5jZUJhbGFuY2UoMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21vZGUgPT09ICdlZGl0J31cblxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICB7Y2xpZW50QWR2YW5jZUJhbGFuY2UgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+U2FsZG8gYW50aWNpcGFkbyBkaXNwb25pYmxlOiB7Zm9ybWF0VmFsdWUoY2xpZW50QWR2YW5jZUJhbGFuY2UsICdjdXJyZW5jeScpfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb2xsZWN0aW9uX2RhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmVjaGEgZGUgQ29icm88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29sbGVjdGlvbl9kYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtoZWFkZXIuY29sbGVjdGlvbl9kYXRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0SGVhZGVyKHByZXYgPT4gKHsgLi4ucHJldiwgY29sbGVjdGlvbl9kYXRlOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9IGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBCTE9RVUUgMTogRkFDVFVSQVMgUEVORElFTlRFUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgcC00IGJvcmRlciByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbWItMlwiPkZhY3R1cmFzIFBlbmRpZW50ZXMgZGUgQ29icm88L2gzPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLTk2XCI+XG4gICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nQ2xpZW50RG9jdW1lbnRzID8gPExvYWRpbmdTcGlubmVyIC8+IDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+RmFjdHVyYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5GZWNoYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+VG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlNhbGRvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdy00MFwiPk1vbnRvIGEgQXBsaWNhcjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvdXRzdGFuZGluZ0ludm9pY2VzLmxlbmd0aCA+IDAgPyBvdXRzdGFuZGluZ0ludm9pY2VzLm1hcChpbnYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aW52LmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc21cIj57aW52Lmludm9pY2VfbnVtYmVyfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtXCI+e2Zvcm1hdFZhbHVlKGludi5pbnZvaWNlX2RhdGUsICdkYXRlJyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1yaWdodFwiPntmb3JtYXRWYWx1ZShpbnYudG90YWxfYW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtXCI+e2Zvcm1hdFZhbHVlKGludi5iYWxhbmNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbGllZEFtb3VudHNbaW52LmlkXX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZUFwcGx5QW1vdW50KGludi5pZCwgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZW50ZXJlZEFtb3VudCA9IE51bWJlcihhcHBsaWVkQW1vdW50c1tpbnYuaWRdKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBiYWxhbmNlID0gTnVtYmVyKGludi5iYWxhbmNlKSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZW50ZXJlZEFtb3VudCA+IGJhbGFuY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIG1vbnRvIGFwbGljYWRvICgke2Zvcm1hdFZhbHVlKGVudGVyZWRBbW91bnQsICdjdXJyZW5jeScpfSkgbm8gcHVlZGUgc3VwZXJhciBlbCBzYWxkbyAoJHtmb3JtYXRWYWx1ZShiYWxhbmNlLCAnY3VycmVuY3knKX0pYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBcHBseUFtb3VudChpbnYuaWQsIGJhbGFuY2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIHRleHQtcmlnaHQgcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFwcGx5QW1vdW50KGludi5pZCwgTnVtYmVyKGludi5iYWxhbmNlKSB8fCAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHAtMS41IHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6YmctaW5kaWdvLTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBob3Zlcjpib3JkZXItaW5kaWdvLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMbGVuYXIgY29uIHNhbGRvIHBlbmRpZW50ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEFwbGljYXIgc2FsZG8gY29tcGxldG8gKCR7Zm9ybWF0VmFsdWUoaW52LmJhbGFuY2UsICdjdXJyZW5jeScpfSkgcGFyYSBmYWN0dXJhICR7aW52Lmludm9pY2VfbnVtYmVyfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRmlsbERyaXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs1fSBjbGFzc05hbWU9XCJweC00IHB5LTQgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoZWFkZXIuY2xpZW50X2lkID8gJ0VzdGUgY2xpZW50ZSBubyB0aWVuZSBmYWN0dXJhcyBwZW5kaWVudGVzLicgOiAnU2VsZWNjaW9uZSB1biBjbGllbnRlIHBhcmEgdmVyIHN1cyBmYWN0dXJhcy4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvb3RlciBvcGNpb25hbCBwYXJhIG1vc3RyYXIgdG90YWwgYXBsaWNhZG8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge291dHN0YW5kaW5nSW52b2ljZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Zm9vdCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezR9IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlRvdGFsIEFwbGljYWRvOjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkXCI+e2Zvcm1hdFZhbHVlKHRvdGFscy5pbnZvaWNlc0dyb3NzQW1vdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Zm9vdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8UGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJOb3RhcyBkZSBDcsOpZGl0byBQZW5kaWVudGVzXCJcbiAgICAgICAgICAgICAgICByb3dzPXtjcmVkaXROb3RlUm93c31cbiAgICAgICAgICAgICAgICBhcHBsaWVkQW1vdW50cz17YXBwbGllZENyZWRpdE5vdGVBbW91bnRzfVxuICAgICAgICAgICAgICAgIGZvb3RlclRvdGFsPXt0b3RhbHMuY3JlZGl0Tm90ZXNHcm9zc0Ftb3VudH1cbiAgICAgICAgICAgICAgICBvbkFtb3VudENoYW5nZT17aGFuZGxlQ3JlZGl0Tm90ZUFtb3VudENoYW5nZX1cbiAgICAgICAgICAgICAgICBvbkZpbGxCYWxhbmNlPXsobm90ZUlkLCBiYWxhbmNlKSA9PiBoYW5kbGVDcmVkaXROb3RlQW1vdW50Q2hhbmdlKG5vdGVJZCwgYmFsYW5jZSl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8UGVuZGluZ1NpZ25lZERvY3VtZW50c1RhYmxlXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJOb3RhcyBGaW5hbmNpZXJhcyBQZW5kaWVudGVzXCJcbiAgICAgICAgICAgICAgICByb3dzPXtmaW5hbmNpYWxOb3RlUm93c31cbiAgICAgICAgICAgICAgICBhcHBsaWVkQW1vdW50cz17YXBwbGllZEZpbmFuY2lhbE5vdGVBbW91bnRzfVxuICAgICAgICAgICAgICAgIGZvb3RlclRvdGFsPXt0b3RhbHMuZmluYW5jaWFsTm90ZXNHcm9zc0Ftb3VudH1cbiAgICAgICAgICAgICAgICBzaG93VHlwZUNvbHVtblxuICAgICAgICAgICAgICAgIG9uQW1vdW50Q2hhbmdlPXtoYW5kbGVGaW5hbmNpYWxOb3RlQW1vdW50Q2hhbmdlfVxuICAgICAgICAgICAgICAgIG9uRmlsbEJhbGFuY2U9eyhub3RlSWQsIGJhbGFuY2UpID0+IGhhbmRsZUZpbmFuY2lhbE5vdGVBbW91bnRDaGFuZ2Uobm90ZUlkLCBiYWxhbmNlKX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gQkxPUVVFIDI6IE1FRElPUyBERSBQQUdPIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwLTQgYm9yZGVyIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+TWVkaW9zIGRlIFBhZ288L2gzPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXthZGROZXdJdGVtfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIHJvdW5kZWQtbWQgaG92ZXI6YmctaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTFcIiAvPiBBw7FhZGlyIE1lZGlvXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtwYXltZW50SXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT5cbiAgICAgICAgICAgICAgICAgICAgaXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnUkVUJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLnRlbXBJZH0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTIgZ2FwLXgtNCBnYXAteS0yIHAtMiBib3JkZXItYiBpdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTEyIG1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BwYXltZW50X21ldGhvZF9yZXRfJHtpbmRleH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5NZWRpbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgcGF5bWVudF9tZXRob2RfcmV0XyR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAncGF5bWVudF9tZXRob2RfY29kZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVGRVwiPkVmZWN0aXZvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ0hFXCI+Q2hlcXVlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVFJBXCI+VHJhbnNmZXJlbmNpYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRPQ1wiPkRvY3VtZW50bzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJFVFwiPlJldGVuY2nDs248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjbGllbnRBZHZhbmNlQmFsYW5jZSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTQUxcIj5TYWxkbyBBbnRpY2lwYWRvICh7Zm9ybWF0VmFsdWUoY2xpZW50QWR2YW5jZUJhbGFuY2UsICdjdXJyZW5jeScpfSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgbWQ6Y29sLXNwYW4tM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+Q3VlbnRhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtpdGVtLnVpX2FjY291bnRfY29kZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5jaGFydF9hY2NvdW50Py5uYW1lIHx8IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICd1aV9hY2NvdW50X2NvZGUnLCB2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVJdGVtQ29kZVN1Ym1pdChpbmRleCwgJ2FjY291bnQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IG9wZW5Nb2RhbCh7IHR5cGU6ICdpdGVtQWNjb3VudCcsIGluZGV4IH0sIHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2NoYXJ0X2FjY291bnQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndWlfYWNjb3VudF9jb2RlJywgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTEyIG1kOmNvbC1zcGFuLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2ByZXRlbnRpb25fdGF4XyR7aW5kZXh9YH0gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+VGlwbyBkZSByZXRlbmNpw7NuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2ByZXRlbnRpb25fdGF4XyR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnJlZmVyZW5jZV9udW1iZXIgIT0gbnVsbCA/IFN0cmluZyhpdGVtLnJlZmVyZW5jZV9udW1iZXIpIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAncmVmZXJlbmNlX251bWJlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID09PSAnJyA/IG51bGwgOiBlLnRhcmdldC52YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjY2lvbmXigKY8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXRlbnRpb25UYXhlcy5tYXAodGF4ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dGF4LmlkfSB2YWx1ZT17U3RyaW5nKHRheC5pZCl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGF4Lm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0xMiBtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgcmV0X2NlcnRfJHtpbmRleH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5OwrogY2VydGlmaWNhZG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgcmV0X2NlcnRfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0uY2hlY2tfbnVtYmVyIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2NoZWNrX251bWJlcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjU1fSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgbWQ6Y29sLXNwYW4tM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+VmFsb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ3ZhbHVlJywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aW5wdXRTdHlsZX0gdGV4dC1yaWdodCBmbGV4LTEgbWluLXctMGB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGxQYXltZW50TGluZUZyb21BcHBsaWVkVG90YWwoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0b3RhbHMuZ3Jvc3NBbW91bnQgPD0gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHAtMS41IHRleHQtaW5kaWdvLTYwMCBob3Zlcjp0ZXh0LWluZGlnby04MDAgaG92ZXI6YmctaW5kaWdvLTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBob3Zlcjpib3JkZXItaW5kaWdvLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29tcGxldGFyIGNvbiBlbCBmYWx0YW50ZSByZXNwZWN0byBhbCB0b3RhbCBhcGxpY2FkbyAoZXhjbHV5ZSBlc3RhIGzDrW5lYSlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDb21wbGV0YXIgdmFsb3IgY29uIGVsIGZhbHRhbnRlIHJlc3BlY3RvIGFsIHRvdGFsIGFwbGljYWRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFGaWxsRHJpcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJFbGltaW5hciDDrXRlbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlSXRlbShpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMCBwLTEgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLnRlbXBJZH0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTIgZ2FwLXgtNCBnYXAteS0yIHAtMiBib3JkZXItYiBpdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGlwbyBkZSBQYWdvICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgbWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9e2BwYXltZW50X21ldGhvZF8ke2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5NZWRpbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAncGF5bWVudF9tZXRob2RfY29kZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgcGF5bWVudF9tZXRob2RfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRUZFXCI+RWZlY3Rpdm88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDSEVcIj5DaGVxdWU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUUkFcIj5UcmFuc2ZlcmVuY2lhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRE9DXCI+RG9jdW1lbnRvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUkVUXCI+UmV0ZW5jacOzbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFKVVwiPkFqdXN0ZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NsaWVudEFkdmFuY2VCYWxhbmNlID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNBTFwiPlNhbGRvIEFudGljaXBhZG8gKHtmb3JtYXRWYWx1ZShjbGllbnRBZHZhbmNlQmFsYW5jZSwgJ2N1cnJlbmN5Jyl9KTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEN1ZW50YSBDb250YWJsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTEyIG1kOmNvbC1zcGFuLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkN1ZW50YTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17aXRlbS51aV9hY2NvdW50X2NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2l0ZW0uY2hhcnRfYWNjb3VudD8ubmFtZSB8fCBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndWlfYWNjb3VudF9jb2RlJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSXRlbUNvZGVTdWJtaXQoaW5kZXgsICdhY2NvdW50Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBvcGVuTW9kYWwoeyB0eXBlOiAnaXRlbUFjY291bnQnLCBpbmRleCB9LCBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdjaGFydF9hY2NvdW50JywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ3VpX2FjY291bnRfY29kZScsICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJhbmNvICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17aXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnRUZFJyA/ICdpbnZpc2libGUnIDogJyd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkJhbmNvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e2l0ZW0udWlfYmFua19jb2RlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWVWYWx1ZT17aXRlbS5iYW5rX25hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVDaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICd1aV9iYW5rX2NvZGUnLCB2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSXRlbUNvZGVTdWJtaXQoaW5kZXgsICdiYW5rJyl9IC8vIE5lY2VzaXRhcsOhcyBpbXBsZW1lbnRhciBlc3RhIHBhcnRlIGVuIGhhbmRsZUl0ZW1Db2RlU3VibWl0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gb3Blbk1vZGFsKHsgdHlwZTogJ2l0ZW1CYW5rJywgaW5kZXggfSwgYmFuY29zTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2JhbmtfaWQnLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2JhbmtfbmFtZScsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAndWlfYmFua19jb2RlJywgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2l0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ1NBTCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTsK6IENoZXF1ZSAvIFJlZmVyZW5jaWEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi02IG1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2l0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ0VGRScgPyAnaW52aXNpYmxlJyA6ICcnfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9e2BjaGVja19udW1iZXJfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPntpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSEUnID8gJ07CuiBDaGVxdWUnIDogJ1JlZmVyZW5jaWEnfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD17YGNoZWNrX251bWJlcl8ke2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmNoZWNrX251bWJlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAnY2hlY2tfbnVtYmVyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnU0FMJ30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZlY2hhIChjaGVja19kYXRlKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTYgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17aXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnRUZFJyA/ICdpbnZpc2libGUnIDogJyd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj17YGNoZWNrX2RhdGVfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnBheW1lbnRfbWV0aG9kX2NvZGUgPT09ICdDSEUnID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRmVjaGEgZW1pc2nDs24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ0ZlY2hhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgY2hlY2tfZGF0ZV8ke2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0uY2hlY2tfZGF0ZSA/IGZvcm1hdERhdGVGb3JJbnB1dChuZXcgRGF0ZShpdGVtLmNoZWNrX2RhdGUpKSA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdjaGVja19kYXRlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXRlbS5wYXltZW50X21ldGhvZF9jb2RlID09PSAnU0FMJ30gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFZhbG9yICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTAgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+VmFsb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTIgbWQ6Y29sLXNwYW4tMSBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS52YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17bnVtID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICd2YWx1ZScsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwLjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake2lucHV0U3R5bGV9IHRleHQtcmlnaHQgZmxleC0xIG1pbi13LTBgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxsUGF5bWVudExpbmVGcm9tQXBwbGllZFRvdGFsKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dG90YWxzLmdyb3NzQW1vdW50IDw9IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBwLTEuNSB0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOmJnLWluZGlnby01MCByb3VuZGVkIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6Ym9yZGVyLWluZGlnby0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNvbXBsZXRhciBjb24gZWwgZmFsdGFudGUgcmVzcGVjdG8gYWwgdG90YWwgYXBsaWNhZG8gKGV4Y2x1eWUgZXN0YSBsw61uZWEpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ29tcGxldGFyIHZhbG9yIGNvbiBlbCBmYWx0YW50ZSByZXNwZWN0byBhbCB0b3RhbCBhcGxpY2Fkb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRmlsbERyaXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiRWxpbWluYXIgw610ZW1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW1vdmVJdGVtKGluZGV4KX0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMCBwLTEgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFUcmFzaCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENhbXBvcyBhZGljaW9uYWxlcyBzb2xvIHBhcmEgw610ZW0gdGlwbyBDaGVxdWUgKENIRSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGF5bWVudF9tZXRob2RfY29kZSA9PT0gJ0NIRScgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTEyIGdyaWQgZ3JpZC1jb2xzLTEyIGdhcC14LTQgZ2FwLXktMiBwdC0yIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTYgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgY2hlY2tfZHVlX2RhdGVfJHtpbmRleH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5GZWNoYSBkZSBwYWdvL2NvYnJvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD17YGNoZWNrX2R1ZV9kYXRlXyR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0uY2hlY2tfZHVlX2RhdGUgPyBmb3JtYXREYXRlRm9ySW5wdXQobmV3IERhdGUoaXRlbS5jaGVja19kdWVfZGF0ZSkpIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdjaGVja19kdWVfZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dFN0eWxlfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTYgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgcmVmZXJlbmNlX251bWJlcl8ke2luZGV4fWB9IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlJlZmVyZW5jaWE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgcmVmZXJlbmNlX251bWJlcl8ke2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnJlZmVyZW5jZV9udW1iZXIgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdyZWZlcmVuY2VfbnVtYmVyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjU1fSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTYgbWQ6Y29sLXNwYW4tMiBmbGV4IGl0ZW1zLWVuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Qm9vbGVhbihpdGVtLmlzX3RvX29yZGVyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUl0ZW1DaGFuZ2UoaW5kZXgsICdpc190b19vcmRlcicsIGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItZ3JheS0zMDBcIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5BIGxhIG9yZGVuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tNiBtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2B0aGlyZF9wYXJ0eV8ke2luZGV4fWB9IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkNoZXF1ZSBkZSB0ZXJjZXJvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgdGhpcmRfcGFydHlfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5pc190aGlyZF9wYXJ0eV9jaGVjayA9PT0gdHJ1ZSA/ICd5ZXMnIDogJ25vJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNZZXMgPSBlLnRhcmdldC52YWx1ZSA9PT0gJ3llcyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAnaXNfdGhpcmRfcGFydHlfY2hlY2snLCBpc1llcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzWWVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2lzc3Vlcl9jdWl0JywgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSXRlbUNoYW5nZShpbmRleCwgJ2NoZWNrX2hvbGRlcicsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0U3R5bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibm9cIj5Obzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwieWVzXCI+U8OtPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmlzX3RoaXJkX3BhcnR5X2NoZWNrID09PSB0cnVlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTYgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BjaGVja19ob2xkZXJfJHtpbmRleH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5FbWlzb3IgZGVsIGNoZXF1ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BjaGVja19ob2xkZXJfJHtpbmRleH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmNoZWNrX2hvbGRlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAnY2hlY2tfaG9sZGVyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezI1NX0gYXV0b0NvbXBsZXRlPVwib2ZmXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tNiBtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YGlzc3Vlcl9jdWl0XyR7aW5kZXh9YH0gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+Q1VJVCBlbWlzb3IgKHRlcmNlcm8pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD17YGlzc3Vlcl9jdWl0XyR7aW5kZXh9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5pc3N1ZXJfY3VpdCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVJdGVtQ2hhbmdlKGluZGV4LCAnaXNzdWVyX2N1aXQnLCBhcHBseU1hc2soJ2N1aXQnLCBlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQmx1cj17ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IChlLnRhcmdldC52YWx1ZSB8fCAnJykudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsICYmICF2YWxpZGF0ZU1hc2soJ2N1aXQnLCB2YWwpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXNrID0gZ2V0TWFzaygnY3VpdCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9hc3Qud2FybihtYXNrPy5lcnJvck1lc3NhZ2UgPz8gJ0NVSVQgaW52w6FsaWRvJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRTdHlsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiAzMC0xMjM0NTY3OC05XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9e2dldE1hc2soJ2N1aXQnKT8ubWF4TGVuZ3RoID8/IDEzfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7LyogRm9vdGVyIG9wY2lvbmFsIHBhcmEgbW9zdHJhciB0b3RhbCBwYWdhZG8gKi99XG4gICAgICAgICAgICAgICAge3BheW1lbnRJdGVtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTIgcHQtMiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIG1yLTJcIj5Ub3RhbCBNZWRpb3MgZGUgUGFnbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZFwiPntmb3JtYXRWYWx1ZSh0b3RhbHMudG90YWxQYWlkLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBCTE9RVUUgMzogVE9UQUxFUyAoTGF5b3V0IEFqdXN0YWRvKSAtLS0gKi99XG4gICAgICAgICAgICB7Lyog4pyFIENPUlJFQ0NJw5NOOiBMYXlvdXQgZGUgdG90YWxlcyBhanVzdGFkbyBhIDIgY29sdW1uYXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTMgZ2FwLTggbWItNlwiPlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIEl6cXVpZXJkYTogRGVzY3VlbnRvcyBlIEltcHVlc3RvcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgcC00IGJvcmRlciByb3VuZGVkLWxnIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+RGVzY3VlbnRvcyB5IFJldGVuY2lvbmVzPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFVJIG9jdWx0YTogZGVzY3VlbnRvIChsw7NnaWNhIGFjdGl2YSBlbiBlc3RhZG8sIHVzZU1lbW8geSBndWFyZGFkbylcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJkaXNjb3VudFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+RGVzY3VlbnRvICgtKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkaXNjb3VudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtoZWFkZXIuZGlzY291bnRfYW1vdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtudW0gPT4gc2V0SGVhZGVyKHByZXYgPT4gKHsgLi4ucHJldiwgZGlzY291bnRfYW1vdW50OiBudW0gfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aW5wdXRTdHlsZX0gdGV4dC1yaWdodGB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwLjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAqL31cbiAgICAgICAgICAgICAgICAgICAgey8qIExpc3RhIGRlIFJldGVuY2lvbmVzIChJbXB1ZXN0b3MgQXBsaWNhZG9zKSAqL31cbiAgICAgICAgICAgICAgICAgICAge3RvdGFscy5hcHBsaWVkVGF4ZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFscy5hcHBsaWVkVGF4ZXMubWFwKHRheCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3RheC50YXhfaWR9IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBjb2wtc3Bhbi0yXCI+e3RheC50YXhfbmFtZX0gKHt0YXgucmF0ZX0lKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vc3RyYW1vcyBlbCBtb250byBjYWxjdWxhZG8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgdGV4dC1yaWdodCB0ZXh0LWdyYXktODAwIGJnLWdyYXktMTAwIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB0LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2hlYWRlci5jbGllbnRfaWQgPyAnRWwgY2xpZW50ZSBubyB0aWVuZSByZXRlbmNpb25lcyBjb25maWd1cmFkYXMgbyBhcGxpY2FibGVzLicgOiAnU2VsZWNjaW9uZSB1biBjbGllbnRlIHBhcmEgdmVyIHN1cyByZXRlbmNpb25lcy4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIENvbHVtbmEgRGVyZWNoYTogUmVzdW1lbiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgYm9yZGVyIHJvdW5kZWQtbGcgc3BhY2UteS0yIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaC1maXRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBtYi00XCI+UmVzdW1lbjwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbVwiPjxzcGFuPkltcG9ydGUgQnJ1dG86PC9zcGFuPiA8c3Bhbj57Zm9ybWF0VmFsdWUodG90YWxzLmdyb3NzQW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBVSSBvY3VsdGE6IGzDrW5lYSBEZXNjdWVudG8gZW4gcmVzdW1lbiAodG90YWxzLmRpc2NvdW50IHNpZ3VlIGVuIGPDoWxjdWxvIHkgZ3VhcmRhZG8pXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj48c3Bhbj5EZXNjdWVudG86PC9zcGFuPiA8c3Bhbj4tIHtmb3JtYXRWYWx1ZSh0b3RhbHMuZGlzY291bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj48c3Bhbj5SZXRlbmNpb25lczo8L3NwYW4+IDxzcGFuPi0ge2Zvcm1hdFZhbHVlKHRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gZm9udC1ib2xkXCI+PHNwYW4+TmV0byBhIENvYnJhcjo8L3NwYW4+IDxzcGFuPntmb3JtYXRWYWx1ZSh0b3RhbHMucmVtYWluaW5nVG9QYXksICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBmb250LWJvbGQgdGV4dC1sZyBib3JkZXItdCBwdC0yIG10LTJcIj48c3Bhbj5UT1RBTCBDT0JSQURPOjwvc3Bhbj4gPHNwYW4+e2Zvcm1hdFZhbHVlKHRvdGFscy50b3RhbFBhaWQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIEJPVE9ORVMgREUgQUNDScOTTiAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKGNvYnJhbnphc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCI+Q2FuY2VsYXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVTYXZlfSBkaXNhYmxlZD17aXNTYXZpbmcgfHwgbG9hZGluZ0NsaWVudERvY3VtZW50c30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBtbC0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ncmVlbi02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmVlbi03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgICAgICAgICAgICB7aXNTYXZpbmcgPyA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgQ29icmFuemFcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogLS0tIE1PREFMIC0tLSAqL31cbiAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiBtb2RhbENvbmZpZyAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9e2hhbmRsZVNlbGVjdE1vZGFsfVxuICAgICAgICAgICAgICAgICAgICBjb25maWc9e21vZGFsQ29uZmlnfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9jb2JyYW56YXMvcGFnZXMvQ29icmFuemFzRm9ybVBhZ2UudHN4In0=