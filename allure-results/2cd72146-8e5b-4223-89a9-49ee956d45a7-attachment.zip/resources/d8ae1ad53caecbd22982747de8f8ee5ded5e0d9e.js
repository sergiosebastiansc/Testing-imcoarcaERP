import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
import { buildAutorizacionPedidosModuleConfig } from "/src/features/autorizacion_pedidos/autorizacion_pedidos.config.tsx";
export const AutorizacionPedidosListPage = () => {
  _s();
  const [listMode, setListMode] = useState("pending");
  const moduleConfig = useMemo(
    () => buildAutorizacionPedidosModuleConfig(
      listMode === "pending" ? "sales-orders/authorization/pending" : "sales-orders/authorization/authorized",
      listMode === "pending" ? "Pedidos por autorizar" : "Pedidos autorizados"
    ),
    [listMode]
  );
  const {
    response,
    loading,
    isAppending,
    error,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(moduleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
    lineNumber: 57,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setListMode("pending"),
          className: `inline-flex items-center px-4 py-2 text-sm font-medium rounded-md border ${listMode === "pending" ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"}`,
          children: "Por autorizar"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
          lineNumber: 62,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setListMode("authorized"),
          className: `inline-flex items-center px-4 py-2 text-sm font-medium rounded-md border ${listMode === "authorized" ? "bg-indigo-600 text-white border-indigo-600" : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"}`,
          children: "Pedidos autorizados"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
          lineNumber: 73,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
      lineNumber: 61,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      GenericListPage,
      {
        config: moduleConfig,
        paginationResponse: response,
        loading,
        isAppending,
        onSort: handleSort,
        sortBy,
        sortDirection,
        onPageChange: handlePageChange,
        onLoadMore: handleLoadMore,
        onSearch: handleSearch,
        searchTerm: searchParams.term ?? "",
        dateFilterStart: searchParams.startDate ?? "",
        dateFilterEnd: searchParams.endDate ?? "",
        enableDateRangeFilter: true,
        canDelete: false,
        canEdit: false
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
        lineNumber: 85,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
};
_s(AutorizacionPedidosListPage, "KMdHnkCOHHW87nZrW2FQHZtsxbk=", false, function() {
  return [useCrud];
});
_c = AutorizacionPedidosListPage;
var _c;
$RefreshReg$(_c, "AutorizacionPedidosListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/autorizacion_pedidos/pages/AutorizacionPedidosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQ3RCLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsNENBQTRDO0FBSzlDLGFBQU1DLDhCQUE4QkEsTUFBTTtBQUFBQyxLQUFBO0FBQzdDLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJUixTQUFtQixTQUFTO0FBRTVELFFBQU1TLGVBQWVWO0FBQUFBLElBQ2pCLE1BQ0lLO0FBQUFBLE1BQ0lHLGFBQWEsWUFDUCx1Q0FDQTtBQUFBLE1BQ05BLGFBQWEsWUFBWSwwQkFBMEI7QUFBQSxJQUN2RDtBQUFBLElBQ0osQ0FBQ0EsUUFBUTtBQUFBLEVBQ2I7QUFFQSxRQUFNO0FBQUEsSUFDRkc7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJbEIsUUFBb0JPLGNBQWNOLHdCQUF3QixDQUFDO0FBRS9ELE1BQUlVLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTUwsWUFBWSxTQUFTO0FBQUEsVUFDcEMsV0FBVyw0RUFDUEQsYUFBYSxZQUNQLCtDQUNBLHlEQUF5RDtBQUFBLFVBQ2hFO0FBQUE7QUFBQSxRQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNQyxZQUFZLFlBQVk7QUFBQSxVQUN2QyxXQUFXLDRFQUNQRCxhQUFhLGVBQ1AsK0NBQ0EseURBQXlEO0FBQUEsVUFDaEU7QUFBQTtBQUFBLFFBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxTQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csUUFBUUU7QUFBQUEsUUFDUixvQkFBb0JDO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsUUFBUUk7QUFBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBLGNBQWNHO0FBQUFBLFFBQ2QsWUFBWUM7QUFBQUEsUUFDWixVQUFVQztBQUFBQSxRQUNWLFlBQVlDLGFBQWFDLFFBQVE7QUFBQSxRQUNqQyxpQkFBaUJELGFBQWFFLGFBQWE7QUFBQSxRQUMzQyxlQUFlRixhQUFhRyxXQUFXO0FBQUEsUUFDdkMsdUJBQXVCO0FBQUEsUUFDdkIsV0FBVztBQUFBLFFBQ1gsU0FBUztBQUFBO0FBQUEsTUFoQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0JtQjtBQUFBLE9BekN2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkNBO0FBRVI7QUFBRWpCLEdBNUVXRCw2QkFBMkI7QUFBQSxVQTBCaENILE9BQU87QUFBQTtBQUFBc0IsS0ExQkZuQjtBQUEyQixJQUFBbUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIkdlbmVyaWNMaXN0UGFnZSIsInVzZUNydWQiLCJnZXREZWZhdWx0TGlzdERhdGVSYW5nZSIsImJ1aWxkQXV0b3JpemFjaW9uUGVkaWRvc01vZHVsZUNvbmZpZyIsIkF1dG9yaXphY2lvblBlZGlkb3NMaXN0UGFnZSIsIl9zIiwibGlzdE1vZGUiLCJzZXRMaXN0TW9kZSIsIm1vZHVsZUNvbmZpZyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJoYW5kbGVTb3J0Iiwic29ydEJ5Iiwic29ydERpcmVjdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVMb2FkTW9yZSIsImhhbmRsZVNlYXJjaCIsInNlYXJjaFBhcmFtcyIsInRlcm0iLCJzdGFydERhdGUiLCJlbmREYXRlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0b3JpemFjaW9uUGVkaWRvc0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3REYXRlUmFuZ2UnO1xuaW1wb3J0IHsgYnVpbGRBdXRvcml6YWNpb25QZWRpZG9zTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vYXV0b3JpemFjaW9uX3BlZGlkb3MuY29uZmlnJztcbmltcG9ydCB0eXBlIHsgU2FsZXNPcmRlciB9IGZyb20gJy4uLy4uL3BlZGlkb3NfdmVudGEvcGVkaWRvc192ZW50YV9jb25maWcnO1xuXG50eXBlIExpc3RNb2RlID0gJ3BlbmRpbmcnIHwgJ2F1dGhvcml6ZWQnO1xuXG5leHBvcnQgY29uc3QgQXV0b3JpemFjaW9uUGVkaWRvc0xpc3RQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IFtsaXN0TW9kZSwgc2V0TGlzdE1vZGVdID0gdXNlU3RhdGU8TGlzdE1vZGU+KCdwZW5kaW5nJyk7XG5cbiAgICBjb25zdCBtb2R1bGVDb25maWcgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PlxuICAgICAgICAgICAgYnVpbGRBdXRvcml6YWNpb25QZWRpZG9zTW9kdWxlQ29uZmlnKFxuICAgICAgICAgICAgICAgIGxpc3RNb2RlID09PSAncGVuZGluZydcbiAgICAgICAgICAgICAgICAgICAgPyAnc2FsZXMtb3JkZXJzL2F1dGhvcml6YXRpb24vcGVuZGluZydcbiAgICAgICAgICAgICAgICAgICAgOiAnc2FsZXMtb3JkZXJzL2F1dGhvcml6YXRpb24vYXV0aG9yaXplZCcsXG4gICAgICAgICAgICAgICAgbGlzdE1vZGUgPT09ICdwZW5kaW5nJyA/ICdQZWRpZG9zIHBvciBhdXRvcml6YXInIDogJ1BlZGlkb3MgYXV0b3JpemFkb3MnXG4gICAgICAgICAgICApLFxuICAgICAgICBbbGlzdE1vZGVdXG4gICAgKTtcblxuICAgIGNvbnN0IHtcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGxvYWRpbmcsXG4gICAgICAgIGlzQXBwZW5kaW5nLFxuICAgICAgICBlcnJvcixcbiAgICAgICAgaGFuZGxlU29ydCxcbiAgICAgICAgc29ydEJ5LFxuICAgICAgICBzb3J0RGlyZWN0aW9uLFxuICAgICAgICBoYW5kbGVQYWdlQ2hhbmdlLFxuICAgICAgICBoYW5kbGVMb2FkTW9yZSxcbiAgICAgICAgaGFuZGxlU2VhcmNoLFxuICAgICAgICBzZWFyY2hQYXJhbXMsXG4gICAgfSA9IHVzZUNydWQ8U2FsZXNPcmRlcj4obW9kdWxlQ29uZmlnLCBnZXREZWZhdWx0TGlzdERhdGVSYW5nZSgpKTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpc3RNb2RlKCdwZW5kaW5nJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLW1kIGJvcmRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgbGlzdE1vZGUgPT09ICdwZW5kaW5nJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby02MDAgdGV4dC13aGl0ZSBib3JkZXItaW5kaWdvLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGJvcmRlci1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTUwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFBvciBhdXRvcml6YXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMaXN0TW9kZSgnYXV0aG9yaXplZCcpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1tZCBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpc3RNb2RlID09PSAnYXV0aG9yaXplZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1pbmRpZ28tNjAwIHRleHQtd2hpdGUgYm9yZGVyLWluZGlnby02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgdGV4dC1ncmF5LTcwMCBib3JkZXItZ3JheS0zMDAgaG92ZXI6YmctZ3JheS01MCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBQZWRpZG9zIGF1dG9yaXphZG9zXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8U2FsZXNPcmRlcj5cbiAgICAgICAgICAgICAgICBjb25maWc9e21vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgaXNBcHBlbmRpbmc9e2lzQXBwZW5kaW5nfVxuICAgICAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgICAgICBzb3J0Qnk9e3NvcnRCeX1cbiAgICAgICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgICAgICBvbkxvYWRNb3JlPXtoYW5kbGVMb2FkTW9yZX1cbiAgICAgICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAgICAgICAgIGRhdGVGaWx0ZXJTdGFydD17c2VhcmNoUGFyYW1zLnN0YXJ0RGF0ZSA/PyAnJ31cbiAgICAgICAgICAgICAgICBkYXRlRmlsdGVyRW5kPXtzZWFyY2hQYXJhbXMuZW5kRGF0ZSA/PyAnJ31cbiAgICAgICAgICAgICAgICBlbmFibGVEYXRlUmFuZ2VGaWx0ZXI9e3RydWV9XG4gICAgICAgICAgICAgICAgY2FuRGVsZXRlPXtmYWxzZX1cbiAgICAgICAgICAgICAgICBjYW5FZGl0PXtmYWxzZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9hdXRvcml6YWNpb25fcGVkaWRvcy9wYWdlcy9BdXRvcml6YWNpb25QZWRpZG9zTGlzdFBhZ2UudHN4In0=