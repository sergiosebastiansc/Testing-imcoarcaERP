import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/clientes/pages/ClientesFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/clientes/pages/ClientesFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { GenericFormWithTaxes } from "/src/components/common/GenericFormWithTaxes.tsx";
const CLIENTE_TAX_TYPE_GROUPS = [
  { type: 1, label: "Impuestos" },
  { type: 2, label: "Percepciones" }
];
export const ClientesFormPage = ({ mode, initialData, loading: loadingItem, error: errorItem }) => {
  return /* @__PURE__ */ jsxDEV(
    GenericFormWithTaxes,
    {
      mode,
      moduleConfig: clientesModuleConfig,
      taxFilterQuery: { positive_rate_only: "1" },
      taxTypeGroups: CLIENTE_TAX_TYPE_GROUPS,
      taxBlockTitle: "Impuestos y Retenciones del Cliente",
      initialData,
      loadingItem,
      errorItem
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/clientes/pages/ClientesFormPage.tsx",
      lineNumber: 42,
      columnNumber: 5
    },
    this
  );
};
_c = ClientesFormPage;
var _c;
$RefreshReg$(_c, "ClientesFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/clientes/pages/ClientesFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/clientes/pages/ClientesFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBckJSLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsNEJBQTBDO0FBQ25ELFNBQVNDLDRCQUE0QjtBQUlyQyxNQUFNQywwQkFBMEM7QUFBQSxFQUM1QyxFQUFFQyxNQUFNLEdBQUdDLE9BQU8sWUFBWTtBQUFBLEVBQzlCLEVBQUVELE1BQU0sR0FBR0MsT0FBTyxlQUFlO0FBQUM7QUFXL0IsYUFBTUMsbUJBQW9EQSxDQUFDLEVBQUVDLE1BQU1DLGFBQWFDLFNBQVNDLGFBQWFDLE9BQU9DLFVBQVUsTUFBTTtBQUNoSSxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRztBQUFBLE1BQ0EsY0FBY1g7QUFBQUEsTUFFZCxnQkFBZ0IsRUFBRVksb0JBQW9CLElBQUk7QUFBQSxNQUMxQyxlQUFlVjtBQUFBQSxNQUNmLGVBQWM7QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLElBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU3lCO0FBR2pDO0FBQUVXLEtBZFdSO0FBQWlELElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsImNsaWVudGVzTW9kdWxlQ29uZmlnIiwiR2VuZXJpY0Zvcm1XaXRoVGF4ZXMiLCJDTElFTlRFX1RBWF9UWVBFX0dST1VQUyIsInR5cGUiLCJsYWJlbCIsIkNsaWVudGVzRm9ybVBhZ2UiLCJtb2RlIiwiaW5pdGlhbERhdGEiLCJsb2FkaW5nIiwibG9hZGluZ0l0ZW0iLCJlcnJvciIsImVycm9ySXRlbSIsInBvc2l0aXZlX3JhdGVfb25seSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNsaWVudGVzRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9jbGllbnRlcy9wYWdlcy9DbGllbnRlc0Zvcm1QYWdlLnRzeFxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsaWVudGVzTW9kdWxlQ29uZmlnLCB0eXBlIENsaWVudGUgfSBmcm9tICcuLi9jbGllbnRlcy5jb25maWcnO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1XaXRoVGF4ZXMgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljRm9ybVdpdGhUYXhlcyc7XG5pbXBvcnQgdHlwZSB7IFRheFR5cGVHcm91cCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1RheFNlbGVjdGlvbkJsb2NrJztcblxuLyoqIFJlZmVyZW5jaWEgZXN0YWJsZSBwYXJhIG5vIGRpc3BhcmFyIHJlZmV0Y2ggZW4gY2FkYSByZW5kZXIgZGVsIHBhZHJlLiAqL1xuY29uc3QgQ0xJRU5URV9UQVhfVFlQRV9HUk9VUFM6IFRheFR5cGVHcm91cFtdID0gW1xuICAgIHsgdHlwZTogMSwgbGFiZWw6ICdJbXB1ZXN0b3MnIH0sXG4gICAgeyB0eXBlOiAyLCBsYWJlbDogJ1BlcmNlcGNpb25lcycgfSxcbl07XG5cbi8vIFByb3BzIGlkw6ludGljYXMgYSBsYXMgZGUgQXJ0aWN1bG9zRm9ybVBhZ2VcbmludGVyZmFjZSBDbGllbnRlc0Zvcm1QYWdlUHJvcHMge1xuICAgIG1vZGU6ICdjcmVhdGUnIHwgJ2VkaXQnO1xuICAgIGluaXRpYWxEYXRhPzogQ2xpZW50ZTtcbiAgICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgICBlcnJvcj86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBjb25zdCBDbGllbnRlc0Zvcm1QYWdlOiBSZWFjdC5GQzxDbGllbnRlc0Zvcm1QYWdlUHJvcHM+ID0gKHsgbW9kZSwgaW5pdGlhbERhdGEsIGxvYWRpbmc6IGxvYWRpbmdJdGVtLCBlcnJvcjogZXJyb3JJdGVtIH0pID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0Zvcm1XaXRoVGF4ZXNcbiAgICAgICAgICAgIG1vZGU9e21vZGV9XG4gICAgICAgICAgICBtb2R1bGVDb25maWc9e2NsaWVudGVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgLy8g4pyFIENMQVZFOiBGaWx0cmFtb3MgcG9yIGltcHVlc3RvcyBkZSB0aXBvIFwiZ2VuZXJhbFwiXG4gICAgICAgICAgICB0YXhGaWx0ZXJRdWVyeT17eyBwb3NpdGl2ZV9yYXRlX29ubHk6ICcxJyB9fVxuICAgICAgICAgICAgdGF4VHlwZUdyb3Vwcz17Q0xJRU5URV9UQVhfVFlQRV9HUk9VUFN9XG4gICAgICAgICAgICB0YXhCbG9ja1RpdGxlPVwiSW1wdWVzdG9zIHkgUmV0ZW5jaW9uZXMgZGVsIENsaWVudGVcIlxuICAgICAgICAgICAgaW5pdGlhbERhdGE9e2luaXRpYWxEYXRhIX1cbiAgICAgICAgICAgIGxvYWRpbmdJdGVtPXtsb2FkaW5nSXRlbX1cbiAgICAgICAgICAgIGVycm9ySXRlbT17ZXJyb3JJdGVtfVxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvY2xpZW50ZXMvcGFnZXMvQ2xpZW50ZXNGb3JtUGFnZS50c3gifQ==