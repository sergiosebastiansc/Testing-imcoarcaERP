import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/monedas/pages/MonedasEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/monedas/pages/MonedasEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericFormPage } from "/src/components/common/GenericFormPage.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
export const MonedasEditPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item, loading, error, saveItem } = useCrudItem(monedasModuleConfig, id);
  const handleSave = async (data) => {
    const updatedItem = await saveItem(data);
    if (updatedItem) {
      toast.info(`Moneda actualizada con éxito!`);
      navigate(getListReturnPath(monedasModuleConfig.baseRoute));
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasEditPage.tsx",
    lineNumber: 41,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasEditPage.tsx",
    lineNumber: 42,
    columnNumber: 21
  }, this);
  if (!item) return /* @__PURE__ */ jsxDEV("div", { children: "Moneda no encontrada." }, void 0, false, {
    fileName: "/app/src/features/monedas/pages/MonedasEditPage.tsx",
    lineNumber: 43,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericFormPage,
    {
      config: monedasModuleConfig,
      initialData: item,
      onSave: handleSave,
      mode: "edit"
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/monedas/pages/MonedasEditPage.tsx",
      lineNumber: 46,
      columnNumber: 5
    },
    this
  );
};
_s(MonedasEditPage, "G8hjKIGDzF+QHmsnD2By/ug4KkU=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = MonedasEditPage;
var _c;
$RefreshReg$(_c, "MonedasEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/monedas/pages/MonedasEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/monedas/pages/MonedasEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQnhCLFNBQVNBLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsMkJBQXdDO0FBQ2pELFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx5QkFBeUI7QUFFM0IsYUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxHQUFHLElBQUlWLFVBQTBCO0FBQ3pDLFFBQU1XLFdBQVdWLFlBQVk7QUFDN0IsUUFBTSxFQUFFVyxNQUFNQyxTQUFTQyxPQUFPQyxTQUFTLElBQUlYLFlBQW9CRCxxQkFBcUJPLEVBQUU7QUFFdEYsUUFBTU0sYUFBYSxPQUFPQyxTQUFpQjtBQUN2QyxVQUFNQyxjQUFjLE1BQU1ILFNBQVNFLElBQUk7QUFDdkMsUUFBSUMsYUFBYTtBQUNiYixZQUFNYyxLQUFLLCtCQUErQjtBQUMxQ1IsZUFBU0osa0JBQWtCSixvQkFBb0JpQixTQUFTLENBQUM7QUFBQSxJQUM3RDtBQUFBLEVBQ0o7QUFFQSxNQUFJUCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLEtBQU0sUUFBTyx1QkFBQyxTQUFJLHFDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEI7QUFFNUMsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVQ7QUFBQUEsTUFDUixhQUFhUztBQUFBQSxNQUNiLFFBQVFJO0FBQUFBLE1BQ1IsTUFBSztBQUFBO0FBQUEsSUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJZTtBQUd2QjtBQUFFUCxHQXpCV0QsaUJBQWU7QUFBQSxVQUNUUixXQUNFQyxhQUMwQkcsV0FBVztBQUFBO0FBQUFpQixLQUg3Q2I7QUFBZSxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJHZW5lcmljRm9ybVBhZ2UiLCJtb25lZGFzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJ0b2FzdCIsIkxvYWRpbmdTcGlubmVyIiwiZ2V0TGlzdFJldHVyblBhdGgiLCJNb25lZGFzRWRpdFBhZ2UiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJpdGVtIiwibG9hZGluZyIsImVycm9yIiwic2F2ZUl0ZW0iLCJoYW5kbGVTYXZlIiwiZGF0YSIsInVwZGF0ZWRJdGVtIiwiaW5mbyIsImJhc2VSb3V0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vbmVkYXNFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgR2VuZXJpY0Zvcm1QYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0Zvcm1QYWdlJztcbmltcG9ydCB7IG1vbmVkYXNNb2R1bGVDb25maWcsIHR5cGUgTW9uZWRhIH0gZnJvbSAnLi4vbW9uZWRhcy5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuZXhwb3J0IGNvbnN0IE1vbmVkYXNFZGl0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbSwgbG9hZGluZywgZXJyb3IsIHNhdmVJdGVtIH0gPSB1c2VDcnVkSXRlbTxNb25lZGE+KG1vbmVkYXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoZGF0YTogTW9uZWRhKSA9PiB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRJdGVtID0gYXdhaXQgc2F2ZUl0ZW0oZGF0YSk7XG4gICAgICAgIGlmICh1cGRhdGVkSXRlbSkge1xuICAgICAgICAgICAgdG9hc3QuaW5mbyhgTW9uZWRhIGFjdHVhbGl6YWRhIGNvbiDDqXhpdG8hYCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChtb25lZGFzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWl0ZW0pIHJldHVybiA8ZGl2Pk1vbmVkYSBubyBlbmNvbnRyYWRhLjwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljRm9ybVBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17bW9uZWRhc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXtpdGVtfVxuICAgICAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgbW9kZT1cImVkaXRcIlxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbW9uZWRhcy9wYWdlcy9Nb25lZGFzRWRpdFBhZ2UudHN4In0=