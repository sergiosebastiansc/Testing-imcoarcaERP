import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/fractionings/pages/FractioningCreatePage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/fractionings/pages/FractioningCreatePage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaPlus, FaSave, FaSpinner, FaTrash, FaUndoAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { createFractioning, searchByField } from "/src/services/apiService.ts";
export const FractioningCreatePage = () => {
  _s();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [date, setDate] = useState((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const [sourceProducts, setSourceProducts] = useState([]);
  const [resultingProducts, setResultingProducts] = useState([]);
  const [remnantProducts, setRemnantProducts] = useState([]);
  const [sourceProductCodes, setSourceProductCodes] = useState({});
  const [resultingProductCodes, setResultingProductCodes] = useState({});
  const [remnantProductCodes, setRemnantProductCodes] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const handleAddSourceRow = () => {
    const newId = crypto.randomUUID();
    setSourceProducts((p) => [...p, { tempId: newId, product: null, productId: null, productName: "", quantity: 1 }]);
    setSourceProductCodes((prev) => ({ ...prev, [newId]: "" }));
  };
  const handleRemoveSourceRow = (id) => {
    setSourceProducts((p) => p.filter((i) => i.tempId !== id));
    setSourceProductCodes((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };
  const handleUpdateSourceRow = (id, field, val) => setSourceProducts((p) => p.map((i) => i.tempId === id ? { ...i, [field]: val } : i));
  const handleClearSourceProduct = (id) => {
    setSourceProducts((p) => p.map((i) => i.tempId === id ? { ...i, product: null, productId: null, productName: null } : i));
    setSourceProductCodes((prev) => ({ ...prev, [id]: "" }));
  };
  const handleAddResultingRow = () => {
    const newId = crypto.randomUUID();
    setResultingProducts((p) => [...p, { tempId: newId, product: null, productId: null, productName: "", quantity: 1, additionalCost: 0, observation: "" }]);
    setResultingProductCodes((prev) => ({ ...prev, [newId]: "" }));
  };
  const handleRemoveResultingRow = (id) => {
    setResultingProducts((p) => p.filter((i) => i.tempId !== id));
    setResultingProductCodes((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };
  const handleUpdateResultingRow = (id, field, val) => setResultingProducts((p) => p.map((i) => i.tempId === id ? { ...i, [field]: val } : i));
  const handleClearResultingProduct = (id) => {
    setResultingProducts((p) => p.map((i) => i.tempId === id ? { ...i, product: null, productId: null, productName: null } : i));
    setResultingProductCodes((prev) => ({ ...prev, [id]: "" }));
  };
  const handleAddRemnantRow = () => {
    const newId = crypto.randomUUID();
    setRemnantProducts((p) => [...p, { tempId: newId, product: null, productId: null, productName: "", quantity: 1 }]);
    setRemnantProductCodes((prev) => ({ ...prev, [newId]: "" }));
  };
  const handleRemoveRemnantRow = (id) => {
    setRemnantProducts((p) => p.filter((i) => i.tempId !== id));
    setRemnantProductCodes((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };
  const handleUpdateRemnantRow = (id, field, val) => setRemnantProducts((p) => p.map((i) => i.tempId === id ? { ...i, [field]: val } : i));
  const handleClearRemnantProduct = (id) => {
    setRemnantProducts((p) => p.map((i) => i.tempId === id ? { ...i, product: null, productId: null, productName: null } : i));
    setRemnantProductCodes((prev) => ({ ...prev, [id]: "" }));
  };
  const handleOpenModal = (list, index) => {
    setEditingTarget({ list, index });
    setIsModalOpen(true);
  };
  const handleSourceProductCodeSubmit = async (tempId) => {
    const codeToSearch = sourceProductCodes[tempId]?.trim();
    if (!codeToSearch) return;
    try {
      const found = await searchByField(
        articulosModuleConfig.endpoint,
        [{ fieldName: "sku", value: codeToSearch }]
      );
      if (found) {
        setSourceProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: found, productId: found.id, productName: found.name } : item
        ));
        setSourceProductCodes((prev) => ({ ...prev, [tempId]: found.sku || String(found.id) }));
        toast.success(`Producto encontrado: ${found.name}`);
      } else {
        toast.warning("Producto no encontrado con ese código.");
        setSourceProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: null, productId: null, productName: null } : item
        ));
      }
    } catch (error) {
      toast.error("Error al buscar producto por código.");
      console.error(error);
    }
  };
  const handleResultingProductCodeSubmit = async (tempId) => {
    const codeToSearch = resultingProductCodes[tempId]?.trim();
    if (!codeToSearch) return;
    try {
      const found = await searchByField(
        articulosModuleConfig.endpoint,
        [{ fieldName: "sku", value: codeToSearch }]
      );
      if (found) {
        setResultingProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: found, productId: found.id, productName: found.name } : item
        ));
        setResultingProductCodes((prev) => ({ ...prev, [tempId]: found.sku || String(found.id) }));
        toast.success(`Producto encontrado: ${found.name}`);
      } else {
        toast.warning("Producto no encontrado con ese código.");
        setResultingProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: null, productId: null, productName: null } : item
        ));
      }
    } catch (error) {
      toast.error("Error al buscar producto por código.");
      console.error(error);
    }
  };
  const handleRemnantProductCodeSubmit = async (tempId) => {
    const codeToSearch = remnantProductCodes[tempId]?.trim();
    if (!codeToSearch) return;
    try {
      const found = await searchByField(
        articulosModuleConfig.endpoint,
        [{ fieldName: "sku", value: codeToSearch }]
      );
      if (found) {
        setRemnantProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: found, productId: found.id, productName: found.name } : item
        ));
        setRemnantProductCodes((prev) => ({ ...prev, [tempId]: found.sku || String(found.id) }));
        toast.success(`Producto encontrado: ${found.name}`);
      } else {
        toast.warning("Producto no encontrado con ese código.");
        setRemnantProducts((p) => p.map(
          (item) => item.tempId === tempId ? { ...item, product: null, productId: null, productName: null } : item
        ));
      }
    } catch (error) {
      toast.error("Error al buscar producto por código.");
      console.error(error);
    }
  };
  const handleSelectProduct = (selectedProduct) => {
    if (!editingTarget) return;
    const { list, index } = editingTarget;
    const productData = {
      product: selectedProduct,
      productId: selectedProduct.id,
      productName: selectedProduct.name
    };
    if (list === "source") {
      const item = sourceProducts[index];
      setSourceProducts((p) => p.map((i, idx) => idx === index ? { ...i, ...productData } : i));
      setSourceProductCodes((prev) => ({ ...prev, [item.tempId]: selectedProduct.sku || String(selectedProduct.id) }));
    } else if (list === "resulting") {
      const item = resultingProducts[index];
      setResultingProducts((p) => p.map((i, idx) => idx === index ? { ...i, ...productData } : i));
      setResultingProductCodes((prev) => ({ ...prev, [item.tempId]: selectedProduct.sku || String(selectedProduct.id) }));
    } else if (list === "remnant") {
      const item = remnantProducts[index];
      setRemnantProducts((p) => p.map((i, idx) => idx === index ? { ...i, ...productData } : i));
      setRemnantProductCodes((prev) => ({ ...prev, [item.tempId]: selectedProduct.sku || String(selectedProduct.id) }));
    }
    setIsModalOpen(false);
    setEditingTarget(null);
  };
  const handleSave = async () => {
    if (sourceProducts.length === 0 || sourceProducts.some((p) => !p.product)) {
      toast.error("Debe añadir al menos un producto de origen válido.");
      return;
    }
    if (resultingProducts.length === 0 && remnantProducts.length === 0) {
      toast.error("Debe añadir al menos un producto resultante o remanente.");
      return;
    }
    setLoading(true);
    const combinedResulting = [
      ...resultingProducts.map((p) => ({
        product_id: p.productId,
        quantity: p.quantity,
        additional_cost: p.additionalCost,
        observation: p.observation,
        is_remanente: false
      })),
      ...remnantProducts.map((p) => ({
        product_id: p.productId,
        quantity: p.quantity,
        additional_cost: 0,
        // Los remanentes no tienen costo adicional
        observation: "Remanente del proceso",
        is_remanente: true
      }))
    ];
    const payload = {
      fractioning_date: date,
      source_products: sourceProducts.map((p) => ({
        product_id: p.productId,
        quantity: p.quantity
      })),
      resulting_products: combinedResulting
    };
    try {
      await createFractioning(payload);
      toast.success("Fraccionamiento registrado con éxito!");
      navigate("/stock/fraccionamientos");
    } catch (error) {
      console.error("Error al guardar:", error);
      toast.error("Hubo un error al guardar el fraccionamiento.");
    } finally {
      setLoading(false);
    }
  };
  const tableInputStyles = "w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between sm:items-start gap-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: "Crear Nuevo Fraccionamiento / Impresión" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 322,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:w-auto", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "fraction-date", className: "block text-sm font-medium text-gray-700", children: "Fecha del Movimiento" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 324,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("input", { id: "fraction-date", type: "date", value: date, onChange: (e) => setDate(e.target.value), className: "block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm", autoComplete: "off" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 325,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 323,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
      lineNumber: 321,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos de Origen (a consumir)" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 331,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-3/5", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 336,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cantidad a Consumir" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 337,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 338,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 335,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 334,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: sourceProducts.map(
          (p, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: sourceProductCodes[p.tempId] || "",
                nameValue: p.productName || null,
                onCodeChange: (val) => setSourceProductCodes((prev) => ({ ...prev, [p.tempId]: val })),
                onCodeSubmit: () => handleSourceProductCodeSubmit(p.tempId),
                onSearchClick: () => handleOpenModal("source", index),
                onClearClick: () => handleClearSourceProduct(p.tempId)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
                lineNumber: 345,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 344,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: p.quantity, onChange: (num) => handleUpdateSourceRow(p.tempId, "quantity", num), className: tableInputStyles }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 354,
              columnNumber: 63
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 354,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveSourceRow(p.tempId), className: "text-red-500 hover:text-red-700", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 355,
              columnNumber: 187
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 355,
              columnNumber: 87
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 355,
              columnNumber: 37
            }, this)
          ] }, p.tempId, true, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 343,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 341,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 333,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 332,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleAddSourceRow, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-blue-600 rounded-md shadow-sm hover:bg-blue-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 361,
          columnNumber: 188
        }, this),
        "Añadir Origen"
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 361,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
      lineNumber: 330,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos Generados (nuevos)" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 368,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-2/5", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 373,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cantidad" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 374,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Costo Adicional" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 375,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Observación" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 376,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 377,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 372,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 371,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: resultingProducts.map(
          (p, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: resultingProductCodes[p.tempId] || "",
                nameValue: p.productName || null,
                onCodeChange: (val) => setResultingProductCodes((prev) => ({ ...prev, [p.tempId]: val })),
                onCodeSubmit: () => handleResultingProductCodeSubmit(p.tempId),
                onSearchClick: () => handleOpenModal("resulting", index),
                onClearClick: () => handleClearResultingProduct(p.tempId)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
                lineNumber: 384,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 383,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: p.quantity, onChange: (num) => handleUpdateResultingRow(p.tempId, "quantity", num), className: tableInputStyles }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 393,
              columnNumber: 63
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 393,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: p.additionalCost, onChange: (num) => handleUpdateResultingRow(p.tempId, "additionalCost", num), className: tableInputStyles }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 394,
              columnNumber: 63
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 394,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV("input", { type: "text", value: p.observation, onChange: (e) => handleUpdateResultingRow(p.tempId, "observation", e.target.value), className: tableInputStyles, autoComplete: "off" }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 395,
              columnNumber: 63
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 395,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveResultingRow(p.tempId), className: "text-red-500 hover:text-red-700", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 396,
              columnNumber: 190
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 396,
              columnNumber: 87
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 396,
              columnNumber: 37
            }, this)
          ] }, p.tempId, true, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 382,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 380,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 370,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 369,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleAddResultingRow, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 402,
          columnNumber: 195
        }, this),
        "Añadir Generado"
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 402,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
      lineNumber: 367,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-medium text-gray-800", children: "Productos Remanentes (devueltos a stock)" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 407,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-x-auto ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 w-3/5", children: "Producto" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 412,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-left text-sm font-semibold text-gray-900", children: "Cantidad Remanente" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 413,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "relative py-3.5 pl-3 pr-4 sm:pr-6" }, void 0, false, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 414,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 411,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 410,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: remnantProducts.map(
          (p, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm font-medium sm:pl-6", children: /* @__PURE__ */ jsxDEV(
              RelationalInput,
              {
                codeValue: remnantProductCodes[p.tempId] || "",
                nameValue: p.productName || null,
                onCodeChange: (val) => setRemnantProductCodes((prev) => ({ ...prev, [p.tempId]: val })),
                onCodeSubmit: () => handleRemnantProductCodeSubmit(p.tempId),
                onSearchClick: () => handleOpenModal("remnant", index),
                onClearClick: () => handleClearRemnantProduct(p.tempId)
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
                lineNumber: 421,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 420,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4", children: /* @__PURE__ */ jsxDEV(DecimalInput, { value: p.quantity, onChange: (num) => handleUpdateRemnantRow(p.tempId, "quantity", num), className: tableInputStyles }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 430,
              columnNumber: 63
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 430,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-right sm:pr-6", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => handleRemoveRemnantRow(p.tempId), className: "text-red-500 hover:text-red-700", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 431,
              columnNumber: 188
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 431,
              columnNumber: 87
            }, this) }, void 0, false, {
              fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
              lineNumber: 431,
              columnNumber: 37
            }, this)
          ] }, p.tempId, true, {
            fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
            lineNumber: 419,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 417,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 409,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 408,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleAddRemnantRow, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 rounded-md shadow-sm hover:bg-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaUndoAlt, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 437,
          columnNumber: 189
        }, this),
        "Añadir Remanente"
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 437,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
      lineNumber: 406,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate("/inventario/fraccionamientos"), className: "px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50", children: "Cancelar" }, void 0, false, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 441,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleSave, disabled: loading, className: "inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 disabled:bg-green-400", children: [
        loading ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 443,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(FaSave, { className: "w-5 h-5 mr-2" }, void 0, false, {
          fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
          lineNumber: 443,
          columnNumber: 73
        }, this),
        "Guardar Movimiento"
      ] }, void 0, true, {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 442,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
      lineNumber: 440,
      columnNumber: 13
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: () => setIsModalOpen(false),
        onSelect: handleSelectProduct,
        config: articulosModuleConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
        lineNumber: 449,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/fractionings/pages/FractioningCreatePage.tsx",
    lineNumber: 320,
    columnNumber: 5
  }, this);
};
_s(FractioningCreatePage, "5cdmCBxajBKfh+XgZhJI/0ID9/4=", false, function() {
  return [useNavigate];
});
_c = FractioningCreatePage;
var _c;
$RefreshReg$(_c, "FractioningCreatePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/fractionings/pages/FractioningCreatePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/fractionings/pages/FractioningCreatePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFNnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE3U2hCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxRQUFRQyxXQUFXQyxTQUFTQyxpQkFBaUI7QUFDOUQsU0FBU0MsNkJBQTRDO0FBQ3JELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLG1CQUFtQkMscUJBQXFCO0FBc0IxQyxhQUFNQyx3QkFBd0JBLE1BQU07QUFBQUMsS0FBQTtBQUN2QyxRQUFNQyxXQUFXZixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2dCLFNBQVNDLFVBQVUsSUFBSWxCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNtQixNQUFNQyxPQUFPLElBQUlwQixVQUFTLG9CQUFJcUIsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUd2RSxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUl6QixTQUFzQixFQUFFO0FBQ3BFLFFBQU0sQ0FBQzBCLG1CQUFtQkMsb0JBQW9CLElBQUkzQixTQUE2QixFQUFFO0FBQ2pGLFFBQU0sQ0FBQzRCLGlCQUFpQkMsa0JBQWtCLElBQUk3QixTQUFzQixFQUFFO0FBR3RFLFFBQU0sQ0FBQzhCLG9CQUFvQkMscUJBQXFCLElBQUkvQixTQUFpQyxDQUFDLENBQUM7QUFDdkYsUUFBTSxDQUFDZ0MsdUJBQXVCQyx3QkFBd0IsSUFBSWpDLFNBQWlDLENBQUMsQ0FBQztBQUM3RixRQUFNLENBQUNrQyxxQkFBcUJDLHNCQUFzQixJQUFJbkMsU0FBaUMsQ0FBQyxDQUFDO0FBRXpGLFFBQU0sQ0FBQ29DLGFBQWFDLGNBQWMsSUFBSXJDLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNzQyxlQUFlQyxnQkFBZ0IsSUFBSXZDLFNBQXdCLElBQUk7QUFHdEUsUUFBTXdDLHFCQUFxQkEsTUFBTTtBQUM3QixVQUFNQyxRQUFRQyxPQUFPQyxXQUFXO0FBQ2hDbEIsc0JBQWtCLENBQUFtQixNQUFLLENBQUMsR0FBR0EsR0FBRyxFQUFFQyxRQUFRSixPQUFPSyxTQUFTLE1BQU1DLFdBQVcsTUFBTUMsYUFBYSxJQUFJQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0FBQzlHbEIsMEJBQXNCLENBQUFtQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDVCxLQUFLLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDNUQ7QUFDQSxRQUFNVSx3QkFBd0JBLENBQUNDLE9BQWU7QUFDMUMzQixzQkFBa0IsQ0FBQW1CLE1BQUtBLEVBQUVTLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRVQsV0FBV08sRUFBRSxDQUFDO0FBQ3JEckIsMEJBQXNCLENBQUFtQixTQUFRO0FBQzFCLFlBQU1LLFVBQVUsRUFBRSxHQUFHTCxLQUFLO0FBQzFCLGFBQU9LLFFBQVFILEVBQUU7QUFDakIsYUFBT0c7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUNBLFFBQU1DLHdCQUF3QkEsQ0FBQ0osSUFBWUssT0FBd0JDLFFBQWFqQyxrQkFBa0IsQ0FBQW1CLE1BQUtBLEVBQUVlLElBQUksQ0FBQUwsTUFBS0EsRUFBRVQsV0FBV08sS0FBSyxFQUFFLEdBQUdFLEdBQUcsQ0FBQ0csS0FBSyxHQUFHQyxJQUFJLElBQUlKLENBQUMsQ0FBQztBQUMvSixRQUFNTSwyQkFBMkJBLENBQUNSLE9BQWU7QUFDN0MzQixzQkFBa0IsQ0FBQW1CLE1BQUtBLEVBQUVlLElBQUksQ0FBQUwsTUFBS0EsRUFBRVQsV0FBV08sS0FBSyxFQUFFLEdBQUdFLEdBQUdSLFNBQVMsTUFBTUMsV0FBVyxNQUFNQyxhQUFhLEtBQUssSUFBSU0sQ0FBQyxDQUFDO0FBQ3BIdkIsMEJBQXNCLENBQUFtQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDRSxFQUFFLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDekQ7QUFHQSxRQUFNUyx3QkFBd0JBLE1BQU07QUFDaEMsVUFBTXBCLFFBQVFDLE9BQU9DLFdBQVc7QUFDaENoQix5QkFBcUIsQ0FBQWlCLE1BQUssQ0FBQyxHQUFHQSxHQUFHLEVBQUVDLFFBQVFKLE9BQU9LLFNBQVMsTUFBTUMsV0FBVyxNQUFNQyxhQUFhLElBQUlDLFVBQVUsR0FBR2EsZ0JBQWdCLEdBQUdDLGFBQWEsR0FBRyxDQUFDLENBQUM7QUFDcko5Qiw2QkFBeUIsQ0FBQWlCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNULEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvRDtBQUNBLFFBQU11QiwyQkFBMkJBLENBQUNaLE9BQWU7QUFDN0N6Qix5QkFBcUIsQ0FBQWlCLE1BQUtBLEVBQUVTLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRVQsV0FBV08sRUFBRSxDQUFDO0FBQ3hEbkIsNkJBQXlCLENBQUFpQixTQUFRO0FBQzdCLFlBQU1LLFVBQVUsRUFBRSxHQUFHTCxLQUFLO0FBQzFCLGFBQU9LLFFBQVFILEVBQUU7QUFDakIsYUFBT0c7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUNBLFFBQU1VLDJCQUEyQkEsQ0FBQ2IsSUFBWUssT0FBK0JDLFFBQWEvQixxQkFBcUIsQ0FBQWlCLE1BQUtBLEVBQUVlLElBQUksQ0FBQUwsTUFBS0EsRUFBRVQsV0FBV08sS0FBSyxFQUFFLEdBQUdFLEdBQUcsQ0FBQ0csS0FBSyxHQUFHQyxJQUFJLElBQUlKLENBQUMsQ0FBQztBQUM1SyxRQUFNWSw4QkFBOEJBLENBQUNkLE9BQWU7QUFDaER6Qix5QkFBcUIsQ0FBQWlCLE1BQUtBLEVBQUVlLElBQUksQ0FBQUwsTUFBS0EsRUFBRVQsV0FBV08sS0FBSyxFQUFFLEdBQUdFLEdBQUdSLFNBQVMsTUFBTUMsV0FBVyxNQUFNQyxhQUFhLEtBQUssSUFBSU0sQ0FBQyxDQUFDO0FBQ3ZIckIsNkJBQXlCLENBQUFpQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDRSxFQUFFLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDNUQ7QUFHQSxRQUFNZSxzQkFBc0JBLE1BQU07QUFDOUIsVUFBTTFCLFFBQVFDLE9BQU9DLFdBQVc7QUFDaENkLHVCQUFtQixDQUFBZSxNQUFLLENBQUMsR0FBR0EsR0FBRyxFQUFFQyxRQUFRSixPQUFPSyxTQUFTLE1BQU1DLFdBQVcsTUFBTUMsYUFBYSxJQUFJQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0FBQy9HZCwyQkFBdUIsQ0FBQWUsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1QsS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzdEO0FBQ0EsUUFBTTJCLHlCQUF5QkEsQ0FBQ2hCLE9BQWU7QUFDM0N2Qix1QkFBbUIsQ0FBQWUsTUFBS0EsRUFBRVMsT0FBTyxDQUFBQyxNQUFLQSxFQUFFVCxXQUFXTyxFQUFFLENBQUM7QUFDdERqQiwyQkFBdUIsQ0FBQWUsU0FBUTtBQUMzQixZQUFNSyxVQUFVLEVBQUUsR0FBR0wsS0FBSztBQUMxQixhQUFPSyxRQUFRSCxFQUFFO0FBQ2pCLGFBQU9HO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFDQSxRQUFNYyx5QkFBeUJBLENBQUNqQixJQUFZSyxPQUF3QkMsUUFBYTdCLG1CQUFtQixDQUFBZSxNQUFLQSxFQUFFZSxJQUFJLENBQUFMLE1BQUtBLEVBQUVULFdBQVdPLEtBQUssRUFBRSxHQUFHRSxHQUFHLENBQUNHLEtBQUssR0FBR0MsSUFBSSxJQUFJSixDQUFDLENBQUM7QUFDakssUUFBTWdCLDRCQUE0QkEsQ0FBQ2xCLE9BQWU7QUFDOUN2Qix1QkFBbUIsQ0FBQWUsTUFBS0EsRUFBRWUsSUFBSSxDQUFBTCxNQUFLQSxFQUFFVCxXQUFXTyxLQUFLLEVBQUUsR0FBR0UsR0FBR1IsU0FBUyxNQUFNQyxXQUFXLE1BQU1DLGFBQWEsS0FBSyxJQUFJTSxDQUFDLENBQUM7QUFDckhuQiwyQkFBdUIsQ0FBQWUsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0UsRUFBRSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzFEO0FBR0EsUUFBTW1CLGtCQUFrQkEsQ0FBQ0MsTUFBeUJDLFVBQWtCO0FBQ2hFbEMscUJBQWlCLEVBQUVpQyxNQUFNQyxNQUFNLENBQUM7QUFDaENwQyxtQkFBZSxJQUFJO0FBQUEsRUFDdkI7QUFHQSxRQUFNcUMsZ0NBQWdDLE9BQU83QixXQUFtQjtBQUM1RCxVQUFNOEIsZUFBZTdDLG1CQUFtQmUsTUFBTSxHQUFHK0IsS0FBSztBQUN0RCxRQUFJLENBQUNELGFBQWM7QUFFbkIsUUFBSTtBQUNBLFlBQU1FLFFBQVEsTUFBTWhFO0FBQUFBLFFBQ2hCTCxzQkFBc0JzRTtBQUFBQSxRQUN0QixDQUFDLEVBQUVDLFdBQVcsT0FBT0MsT0FBT0wsYUFBYSxDQUFDO0FBQUEsTUFDOUM7QUFFQSxVQUFJRSxPQUFPO0FBQ1BwRCwwQkFBa0IsQ0FBQW1CLE1BQUtBLEVBQUVlO0FBQUFBLFVBQUksQ0FBQXNCLFNBQ3pCQSxLQUFLcEMsV0FBV0EsU0FDVixFQUFFLEdBQUdvQyxNQUFNbkMsU0FBUytCLE9BQU85QixXQUFXOEIsTUFBTXpCLElBQUlKLGFBQWE2QixNQUFNSyxLQUFLLElBQ3hFRDtBQUFBQSxRQUNWLENBQUM7QUFFRGxELDhCQUFzQixDQUFBbUIsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0wsTUFBTSxHQUFHZ0MsTUFBTU0sT0FBT0MsT0FBT1AsTUFBTXpCLEVBQUUsRUFBRSxFQUFFO0FBQ3BGbEQsY0FBTW1GLFFBQVEsd0JBQXdCUixNQUFNSyxJQUFJLEVBQUU7QUFBQSxNQUN0RCxPQUFPO0FBQ0hoRixjQUFNb0YsUUFBUSx3Q0FBd0M7QUFDdEQ3RCwwQkFBa0IsQ0FBQW1CLE1BQUtBLEVBQUVlO0FBQUFBLFVBQUksQ0FBQXNCLFNBQ3pCQSxLQUFLcEMsV0FBV0EsU0FDVixFQUFFLEdBQUdvQyxNQUFNbkMsU0FBUyxNQUFNQyxXQUFXLE1BQU1DLGFBQWEsS0FBSyxJQUM3RGlDO0FBQUFBLFFBQ1YsQ0FBQztBQUFBLE1BQ0w7QUFBQSxJQUNKLFNBQVNNLE9BQU87QUFDWnJGLFlBQU1xRixNQUFNLHNDQUFzQztBQUNsREMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUdBLFFBQU1FLG1DQUFtQyxPQUFPNUMsV0FBbUI7QUFDL0QsVUFBTThCLGVBQWUzQyxzQkFBc0JhLE1BQU0sR0FBRytCLEtBQUs7QUFDekQsUUFBSSxDQUFDRCxhQUFjO0FBRW5CLFFBQUk7QUFDQSxZQUFNRSxRQUFRLE1BQU1oRTtBQUFBQSxRQUNoQkwsc0JBQXNCc0U7QUFBQUEsUUFDdEIsQ0FBQyxFQUFFQyxXQUFXLE9BQU9DLE9BQU9MLGFBQWEsQ0FBQztBQUFBLE1BQzlDO0FBRUEsVUFBSUUsT0FBTztBQUNQbEQsNkJBQXFCLENBQUFpQixNQUFLQSxFQUFFZTtBQUFBQSxVQUFJLENBQUFzQixTQUM1QkEsS0FBS3BDLFdBQVdBLFNBQ1YsRUFBRSxHQUFHb0MsTUFBTW5DLFNBQVMrQixPQUFPOUIsV0FBVzhCLE1BQU16QixJQUFJSixhQUFhNkIsTUFBTUssS0FBSyxJQUN4RUQ7QUFBQUEsUUFDVixDQUFDO0FBQ0RoRCxpQ0FBeUIsQ0FBQWlCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNMLE1BQU0sR0FBR2dDLE1BQU1NLE9BQU9DLE9BQU9QLE1BQU16QixFQUFFLEVBQUUsRUFBRTtBQUN2RmxELGNBQU1tRixRQUFRLHdCQUF3QlIsTUFBTUssSUFBSSxFQUFFO0FBQUEsTUFDdEQsT0FBTztBQUNIaEYsY0FBTW9GLFFBQVEsd0NBQXdDO0FBQ3REM0QsNkJBQXFCLENBQUFpQixNQUFLQSxFQUFFZTtBQUFBQSxVQUFJLENBQUFzQixTQUM1QkEsS0FBS3BDLFdBQVdBLFNBQ1YsRUFBRSxHQUFHb0MsTUFBTW5DLFNBQVMsTUFBTUMsV0FBVyxNQUFNQyxhQUFhLEtBQUssSUFDN0RpQztBQUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSixTQUFTTSxPQUFPO0FBQ1pyRixZQUFNcUYsTUFBTSxzQ0FBc0M7QUFDbERDLGNBQVFELE1BQU1BLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNRyxpQ0FBaUMsT0FBTzdDLFdBQW1CO0FBQzdELFVBQU04QixlQUFlekMsb0JBQW9CVyxNQUFNLEdBQUcrQixLQUFLO0FBQ3ZELFFBQUksQ0FBQ0QsYUFBYztBQUVuQixRQUFJO0FBQ0EsWUFBTUUsUUFBUSxNQUFNaEU7QUFBQUEsUUFDaEJMLHNCQUFzQnNFO0FBQUFBLFFBQ3RCLENBQUMsRUFBRUMsV0FBVyxPQUFPQyxPQUFPTCxhQUFhLENBQUM7QUFBQSxNQUM5QztBQUVBLFVBQUlFLE9BQU87QUFDUGhELDJCQUFtQixDQUFBZSxNQUFLQSxFQUFFZTtBQUFBQSxVQUFJLENBQUFzQixTQUMxQkEsS0FBS3BDLFdBQVdBLFNBQ1YsRUFBRSxHQUFHb0MsTUFBTW5DLFNBQVMrQixPQUFPOUIsV0FBVzhCLE1BQU16QixJQUFJSixhQUFhNkIsTUFBTUssS0FBSyxJQUN4RUQ7QUFBQUEsUUFDVixDQUFDO0FBQ0Q5QywrQkFBdUIsQ0FBQWUsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0wsTUFBTSxHQUFHZ0MsTUFBTU0sT0FBT0MsT0FBT1AsTUFBTXpCLEVBQUUsRUFBRSxFQUFFO0FBQ3JGbEQsY0FBTW1GLFFBQVEsd0JBQXdCUixNQUFNSyxJQUFJLEVBQUU7QUFBQSxNQUN0RCxPQUFPO0FBQ0hoRixjQUFNb0YsUUFBUSx3Q0FBd0M7QUFDdER6RCwyQkFBbUIsQ0FBQWUsTUFBS0EsRUFBRWU7QUFBQUEsVUFBSSxDQUFBc0IsU0FDMUJBLEtBQUtwQyxXQUFXQSxTQUNWLEVBQUUsR0FBR29DLE1BQU1uQyxTQUFTLE1BQU1DLFdBQVcsTUFBTUMsYUFBYSxLQUFLLElBQzdEaUM7QUFBQUEsUUFDVixDQUFDO0FBQUEsTUFDTDtBQUFBLElBQ0osU0FBU00sT0FBTztBQUNackYsWUFBTXFGLE1BQU0sc0NBQXNDO0FBQ2xEQyxjQUFRRCxNQUFNQSxLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNKO0FBR0EsUUFBTUksc0JBQXNCQSxDQUFDQyxvQkFBOEI7QUFDdkQsUUFBSSxDQUFDdEQsY0FBZTtBQUNwQixVQUFNLEVBQUVrQyxNQUFNQyxNQUFNLElBQUluQztBQUN4QixVQUFNdUQsY0FBYztBQUFBLE1BQ2hCL0MsU0FBUzhDO0FBQUFBLE1BQ1Q3QyxXQUFXNkMsZ0JBQWdCeEM7QUFBQUEsTUFDM0JKLGFBQWE0QyxnQkFBZ0JWO0FBQUFBLElBQ2pDO0FBRUEsUUFBSVYsU0FBUyxVQUFVO0FBQ25CLFlBQU1TLE9BQU96RCxlQUFlaUQsS0FBSztBQUNqQ2hELHdCQUFrQixDQUFBbUIsTUFBS0EsRUFBRWUsSUFBSSxDQUFDTCxHQUFHd0MsUUFBUUEsUUFBUXJCLFFBQVEsRUFBRSxHQUFHbkIsR0FBRyxHQUFHdUMsWUFBWSxJQUFJdkMsQ0FBQyxDQUFDO0FBRXRGdkIsNEJBQXNCLENBQUFtQixVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDK0IsS0FBS3BDLE1BQU0sR0FBRytDLGdCQUFnQlQsT0FBT0MsT0FBT1EsZ0JBQWdCeEMsRUFBRSxFQUFFLEVBQUU7QUFBQSxJQUNqSCxXQUFXb0IsU0FBUyxhQUFhO0FBQzdCLFlBQU1TLE9BQU92RCxrQkFBa0IrQyxLQUFLO0FBQ3BDOUMsMkJBQXFCLENBQUFpQixNQUFLQSxFQUFFZSxJQUFJLENBQUNMLEdBQUd3QyxRQUFRQSxRQUFRckIsUUFBUSxFQUFFLEdBQUduQixHQUFHLEdBQUd1QyxZQUFZLElBQUl2QyxDQUFDLENBQUM7QUFDekZyQiwrQkFBeUIsQ0FBQWlCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMrQixLQUFLcEMsTUFBTSxHQUFHK0MsZ0JBQWdCVCxPQUFPQyxPQUFPUSxnQkFBZ0J4QyxFQUFFLEVBQUUsRUFBRTtBQUFBLElBQ3BILFdBQVdvQixTQUFTLFdBQVc7QUFDM0IsWUFBTVMsT0FBT3JELGdCQUFnQjZDLEtBQUs7QUFDbEM1Qyx5QkFBbUIsQ0FBQWUsTUFBS0EsRUFBRWUsSUFBSSxDQUFDTCxHQUFHd0MsUUFBUUEsUUFBUXJCLFFBQVEsRUFBRSxHQUFHbkIsR0FBRyxHQUFHdUMsWUFBWSxJQUFJdkMsQ0FBQyxDQUFDO0FBQ3ZGbkIsNkJBQXVCLENBQUFlLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMrQixLQUFLcEMsTUFBTSxHQUFHK0MsZ0JBQWdCVCxPQUFPQyxPQUFPUSxnQkFBZ0J4QyxFQUFFLEVBQUUsRUFBRTtBQUFBLElBQ2xIO0FBRUFmLG1CQUFlLEtBQUs7QUFDcEJFLHFCQUFpQixJQUFJO0FBQUEsRUFDekI7QUFHQSxRQUFNd0QsYUFBYSxZQUFZO0FBQzNCLFFBQUl2RSxlQUFld0UsV0FBVyxLQUFLeEUsZUFBZXlFLEtBQUssQ0FBQXJELE1BQUssQ0FBQ0EsRUFBRUUsT0FBTyxHQUFHO0FBQ3JFNUMsWUFBTXFGLE1BQU0sb0RBQW9EO0FBQ2hFO0FBQUEsSUFDSjtBQUNBLFFBQUk3RCxrQkFBa0JzRSxXQUFXLEtBQUtwRSxnQkFBZ0JvRSxXQUFXLEdBQUc7QUFDaEU5RixZQUFNcUYsTUFBTSwwREFBMEQ7QUFDdEU7QUFBQSxJQUNKO0FBRUFyRSxlQUFXLElBQUk7QUFHZixVQUFNZ0Ysb0JBQW9CO0FBQUEsTUFDdEIsR0FBR3hFLGtCQUFrQmlDLElBQUksQ0FBQWYsT0FBTTtBQUFBLFFBQzNCdUQsWUFBWXZELEVBQUVHO0FBQUFBLFFBQ2RFLFVBQVVMLEVBQUVLO0FBQUFBLFFBQ1ptRCxpQkFBaUJ4RCxFQUFFa0I7QUFBQUEsUUFDbkJDLGFBQWFuQixFQUFFbUI7QUFBQUEsUUFDZnNDLGNBQWM7QUFBQSxNQUNsQixFQUFFO0FBQUEsTUFDRixHQUFHekUsZ0JBQWdCK0IsSUFBSSxDQUFBZixPQUFNO0FBQUEsUUFDekJ1RCxZQUFZdkQsRUFBRUc7QUFBQUEsUUFDZEUsVUFBVUwsRUFBRUs7QUFBQUEsUUFDWm1ELGlCQUFpQjtBQUFBO0FBQUEsUUFDakJyQyxhQUFhO0FBQUEsUUFDYnNDLGNBQWM7QUFBQSxNQUNsQixFQUFFO0FBQUEsSUFBQztBQUdQLFVBQU1DLFVBQThCO0FBQUEsTUFDaENDLGtCQUFrQnBGO0FBQUFBLE1BQ2xCcUYsaUJBQWlCaEYsZUFBZW1DLElBQUksQ0FBQWYsT0FBTTtBQUFBLFFBQ3RDdUQsWUFBWXZELEVBQUVHO0FBQUFBLFFBQ2RFLFVBQVVMLEVBQUVLO0FBQUFBLE1BQ2hCLEVBQUU7QUFBQSxNQUNGd0Qsb0JBQW9CUDtBQUFBQSxJQUN4QjtBQUVBLFFBQUk7QUFDQSxZQUFNdEYsa0JBQWtCMEYsT0FBTztBQUMvQnBHLFlBQU1tRixRQUFRLHVDQUF1QztBQUNyRHJFLGVBQVMseUJBQXlCO0FBQUEsSUFDdEMsU0FBU3VFLE9BQU87QUFDWkMsY0FBUUQsTUFBTSxxQkFBcUJBLEtBQUs7QUFDeENyRixZQUFNcUYsTUFBTSw4Q0FBOEM7QUFBQSxJQUM5RCxVQUFDO0FBQ0dyRSxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTXdGLG1CQUFtQjtBQUV6QixTQUNJLHVCQUFDLFNBQUksV0FBVSxzREFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSxrRUFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsdURBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxNQUMzRix1QkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSwrQkFBQyxXQUFNLFNBQVEsaUJBQWdCLFdBQVUsMkNBQTBDLG9DQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsUUFDdkcsdUJBQUMsV0FBTSxJQUFHLGlCQUFnQixNQUFLLFFBQU8sT0FBT3ZGLE1BQU0sVUFBVSxDQUFBd0YsTUFBS3ZGLFFBQVF1RixFQUFFQyxPQUFPNUIsS0FBSyxHQUFHLFdBQVUsdUpBQXNKLGNBQWEsU0FBeFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2UTtBQUFBLFdBRmpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLGdEQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGO0FBQUEsTUFDbEYsdUJBQUMsU0FBSSxXQUFVLHlFQUNYLGlDQUFDLFdBQU0sV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUNiLGlDQUFDLFFBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsZ0ZBQStFLHdCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRztBQUFBLFVBQ3JHLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsbUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZGO0FBQUEsVUFDN0YsdUJBQUMsUUFBRyxXQUFVLHVDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p4RCx5QkFBZW1DO0FBQUFBLFVBQUksQ0FBQ2YsR0FBRzZCLFVBQ3BCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFXM0MsbUJBQW1CYyxFQUFFQyxNQUFNLEtBQUs7QUFBQSxnQkFDM0MsV0FBV0QsRUFBRUksZUFBZTtBQUFBLGdCQUM1QixjQUFjLENBQUNVLFFBQVEzQixzQkFBc0IsQ0FBQW1CLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUNOLEVBQUVDLE1BQU0sR0FBR2EsSUFBSSxFQUFFO0FBQUEsZ0JBQ25GLGNBQWMsTUFBTWdCLDhCQUE4QjlCLEVBQUVDLE1BQU07QUFBQSxnQkFDMUQsZUFBZSxNQUFNMEIsZ0JBQWdCLFVBQVVFLEtBQUs7QUFBQSxnQkFDcEQsY0FBYyxNQUFNYix5QkFBeUJoQixFQUFFQyxNQUFNO0FBQUE7QUFBQSxjQU56RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNMkQsS0FQL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsZ0JBQWEsT0FBT0QsRUFBRUssVUFBVSxVQUFVLENBQUE0RCxRQUFPckQsc0JBQXNCWixFQUFFQyxRQUFRLFlBQVlnRSxHQUFHLEdBQUcsV0FBV0gsb0JBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdJLEtBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZKO0FBQUEsWUFDN0osdUJBQUMsUUFBRyxXQUFVLHFDQUFvQyxpQ0FBQyxZQUFPLFNBQVMsTUFBTXZELHNCQUFzQlAsRUFBRUMsTUFBTSxHQUFHLFdBQVUsbUNBQWtDLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUSxLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRyxLQUFqSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSztBQUFBLGVBWnJLRCxFQUFFQyxRQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxRQUNILEtBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBLEtBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sU0FBU0wsb0JBQW9CLFdBQVUsNkhBQTRIO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBQTlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMk47QUFBQSxTQS9CL047QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQTtBQUFBLElBS0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFDQUFvQyw0Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFLHVCQUFDLFNBQUksV0FBVSx5RUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdGQUErRSx3QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUc7QUFBQSxVQUNyRyx1QkFBQyxRQUFHLFdBQVUsNkRBQTRELHdCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsK0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCwyQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxRQUFHLFdBQVUsdUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUx0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWmQsNEJBQWtCaUM7QUFBQUEsVUFBSSxDQUFDZixHQUFHNkIsVUFDdkIsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFdBQVd6QyxzQkFBc0JZLEVBQUVDLE1BQU0sS0FBSztBQUFBLGdCQUM5QyxXQUFXRCxFQUFFSSxlQUFlO0FBQUEsZ0JBQzVCLGNBQWMsQ0FBQ1UsUUFBUXpCLHlCQUF5QixDQUFBaUIsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ04sRUFBRUMsTUFBTSxHQUFHYSxJQUFJLEVBQUU7QUFBQSxnQkFDdEYsY0FBYyxNQUFNK0IsaUNBQWlDN0MsRUFBRUMsTUFBTTtBQUFBLGdCQUM3RCxlQUFlLE1BQU0wQixnQkFBZ0IsYUFBYUUsS0FBSztBQUFBLGdCQUN2RCxjQUFjLE1BQU1QLDRCQUE0QnRCLEVBQUVDLE1BQU07QUFBQTtBQUFBLGNBTjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU04RCxLQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFBWSxpQ0FBQyxnQkFBYSxPQUFPRCxFQUFFSyxVQUFVLFVBQVUsQ0FBQTRELFFBQU81Qyx5QkFBeUJyQixFQUFFQyxRQUFRLFlBQVlnRSxHQUFHLEdBQUcsV0FBV0gsb0JBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1JLEtBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdLO0FBQUEsWUFDaEssdUJBQUMsUUFBRyxXQUFVLGFBQVksaUNBQUMsZ0JBQWEsT0FBTzlELEVBQUVrQixnQkFBZ0IsVUFBVSxDQUFBK0MsUUFBTzVDLHlCQUF5QnJCLEVBQUVDLFFBQVEsa0JBQWtCZ0UsR0FBRyxHQUFHLFdBQVdILG9CQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErSSxLQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SztBQUFBLFlBQzVLLHVCQUFDLFFBQUcsV0FBVSxhQUFZLGlDQUFDLFdBQU0sTUFBSyxRQUFPLE9BQU85RCxFQUFFbUIsYUFBYSxVQUFVLENBQUE0QyxNQUFLMUMseUJBQXlCckIsRUFBRUMsUUFBUSxlQUFlOEQsRUFBRUMsT0FBTzVCLEtBQUssR0FBRyxXQUFXMEIsa0JBQWtCLGNBQWEsU0FBcks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEssS0FBcE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdU07QUFBQSxZQUN2TSx1QkFBQyxRQUFHLFdBQVUscUNBQW9DLGlDQUFDLFlBQU8sU0FBUyxNQUFNMUMseUJBQXlCcEIsRUFBRUMsTUFBTSxHQUFHLFdBQVUsbUNBQWtDLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUSxLQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSCxLQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SztBQUFBLGVBZHhLRCxFQUFFQyxRQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxRQUNILEtBbEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBLEtBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sU0FBU2dCLHVCQUF1QixXQUFVLGlJQUFnSTtBQUFBLCtCQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBQUc7QUFBQSxXQUFyTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9PO0FBQUEsU0FuQ3hPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0Msd0RBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEY7QUFBQSxNQUMxRix1QkFBQyxTQUFJLFdBQVUseUVBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxnRkFBK0Usd0JBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFHO0FBQUEsVUFDckcsdUJBQUMsUUFBRyxXQUFVLDZEQUE0RCxrQ0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxRQUFHLFdBQVUsdUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUh0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUEsS0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDWmpDLDBCQUFnQitCO0FBQUFBLFVBQUksQ0FBQ2YsR0FBRzZCLFVBQ3JCLHVCQUFDLFFBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFXdkMsb0JBQW9CVSxFQUFFQyxNQUFNLEtBQUs7QUFBQSxnQkFDNUMsV0FBV0QsRUFBRUksZUFBZTtBQUFBLGdCQUM1QixjQUFjLENBQUNVLFFBQVF2Qix1QkFBdUIsQ0FBQWUsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ04sRUFBRUMsTUFBTSxHQUFHYSxJQUFJLEVBQUU7QUFBQSxnQkFDcEYsY0FBYyxNQUFNZ0MsK0JBQStCOUMsRUFBRUMsTUFBTTtBQUFBLGdCQUMzRCxlQUFlLE1BQU0wQixnQkFBZ0IsV0FBV0UsS0FBSztBQUFBLGdCQUNyRCxjQUFjLE1BQU1ILDBCQUEwQjFCLEVBQUVDLE1BQU07QUFBQTtBQUFBLGNBTjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU00RCxLQVBoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFBWSxpQ0FBQyxnQkFBYSxPQUFPRCxFQUFFSyxVQUFVLFVBQVUsQ0FBQTRELFFBQU94Qyx1QkFBdUJ6QixFQUFFQyxRQUFRLFlBQVlnRSxHQUFHLEdBQUcsV0FBV0gsb0JBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlJLEtBQTNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThKO0FBQUEsWUFDOUosdUJBQUMsUUFBRyxXQUFVLHFDQUFvQyxpQ0FBQyxZQUFPLFNBQVMsTUFBTXRDLHVCQUF1QnhCLEVBQUVDLE1BQU0sR0FBRyxXQUFVLG1DQUFrQyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVEsS0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0gsS0FBbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMks7QUFBQSxlQVp0S0QsRUFBRUMsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsUUFDSCxLQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQSxLQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFNBQVNzQixxQkFBcUIsV0FBVSw2SEFBNEg7QUFBQSwrQkFBQyxhQUFVLFdBQVUsa0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUFHO0FBQUEsV0FBbE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrTztBQUFBLFNBL0J0TztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1uRCxTQUFTLDhCQUE4QixHQUFHLFdBQVUscUhBQW9ILHdCQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFOO0FBQUEsTUFDck4sdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUytFLFlBQVksVUFBVTlFLFNBQVMsV0FBVSwrS0FDbkVBO0FBQUFBLGtCQUFVLHVCQUFDLGFBQVUsV0FBVSxrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQyxJQUFNLHVCQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBQUc7QUFBQSxXQUQzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRUNtQixlQUNHO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRQTtBQUFBQSxRQUNSLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsUUFDbkMsVUFBVXNEO0FBQUFBLFFBQ1YsUUFBUW5GO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWtDO0FBQUEsT0FySTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SUE7QUFFUjtBQUFFTyxHQXRaV0QsdUJBQXFCO0FBQUEsVUFDYmIsV0FBVztBQUFBO0FBQUE2RyxLQURuQmhHO0FBQXFCLElBQUFnRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwiRmFQbHVzIiwiRmFTYXZlIiwiRmFTcGlubmVyIiwiRmFUcmFzaCIsIkZhVW5kb0FsdCIsImFydGljdWxvc01vZHVsZUNvbmZpZyIsIlJlbGF0aW9uYWxJbnB1dCIsIkRlY2ltYWxJbnB1dCIsIlNlYXJjaE1vZGFsIiwiY3JlYXRlRnJhY3Rpb25pbmciLCJzZWFyY2hCeUZpZWxkIiwiRnJhY3Rpb25pbmdDcmVhdGVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGF0ZSIsInNldERhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNvdXJjZVByb2R1Y3RzIiwic2V0U291cmNlUHJvZHVjdHMiLCJyZXN1bHRpbmdQcm9kdWN0cyIsInNldFJlc3VsdGluZ1Byb2R1Y3RzIiwicmVtbmFudFByb2R1Y3RzIiwic2V0UmVtbmFudFByb2R1Y3RzIiwic291cmNlUHJvZHVjdENvZGVzIiwic2V0U291cmNlUHJvZHVjdENvZGVzIiwicmVzdWx0aW5nUHJvZHVjdENvZGVzIiwic2V0UmVzdWx0aW5nUHJvZHVjdENvZGVzIiwicmVtbmFudFByb2R1Y3RDb2RlcyIsInNldFJlbW5hbnRQcm9kdWN0Q29kZXMiLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZWRpdGluZ1RhcmdldCIsInNldEVkaXRpbmdUYXJnZXQiLCJoYW5kbGVBZGRTb3VyY2VSb3ciLCJuZXdJZCIsImNyeXB0byIsInJhbmRvbVVVSUQiLCJwIiwidGVtcElkIiwicHJvZHVjdCIsInByb2R1Y3RJZCIsInByb2R1Y3ROYW1lIiwicXVhbnRpdHkiLCJwcmV2IiwiaGFuZGxlUmVtb3ZlU291cmNlUm93IiwiaWQiLCJmaWx0ZXIiLCJpIiwidXBkYXRlZCIsImhhbmRsZVVwZGF0ZVNvdXJjZVJvdyIsImZpZWxkIiwidmFsIiwibWFwIiwiaGFuZGxlQ2xlYXJTb3VyY2VQcm9kdWN0IiwiaGFuZGxlQWRkUmVzdWx0aW5nUm93IiwiYWRkaXRpb25hbENvc3QiLCJvYnNlcnZhdGlvbiIsImhhbmRsZVJlbW92ZVJlc3VsdGluZ1JvdyIsImhhbmRsZVVwZGF0ZVJlc3VsdGluZ1JvdyIsImhhbmRsZUNsZWFyUmVzdWx0aW5nUHJvZHVjdCIsImhhbmRsZUFkZFJlbW5hbnRSb3ciLCJoYW5kbGVSZW1vdmVSZW1uYW50Um93IiwiaGFuZGxlVXBkYXRlUmVtbmFudFJvdyIsImhhbmRsZUNsZWFyUmVtbmFudFByb2R1Y3QiLCJoYW5kbGVPcGVuTW9kYWwiLCJsaXN0IiwiaW5kZXgiLCJoYW5kbGVTb3VyY2VQcm9kdWN0Q29kZVN1Ym1pdCIsImNvZGVUb1NlYXJjaCIsInRyaW0iLCJmb3VuZCIsImVuZHBvaW50IiwiZmllbGROYW1lIiwidmFsdWUiLCJpdGVtIiwibmFtZSIsInNrdSIsIlN0cmluZyIsInN1Y2Nlc3MiLCJ3YXJuaW5nIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlUmVzdWx0aW5nUHJvZHVjdENvZGVTdWJtaXQiLCJoYW5kbGVSZW1uYW50UHJvZHVjdENvZGVTdWJtaXQiLCJoYW5kbGVTZWxlY3RQcm9kdWN0Iiwic2VsZWN0ZWRQcm9kdWN0IiwicHJvZHVjdERhdGEiLCJpZHgiLCJoYW5kbGVTYXZlIiwibGVuZ3RoIiwic29tZSIsImNvbWJpbmVkUmVzdWx0aW5nIiwicHJvZHVjdF9pZCIsImFkZGl0aW9uYWxfY29zdCIsImlzX3JlbWFuZW50ZSIsInBheWxvYWQiLCJmcmFjdGlvbmluZ19kYXRlIiwic291cmNlX3Byb2R1Y3RzIiwicmVzdWx0aW5nX3Byb2R1Y3RzIiwidGFibGVJbnB1dFN0eWxlcyIsImUiLCJ0YXJnZXQiLCJudW0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGcmFjdGlvbmluZ0NyZWF0ZVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgRmFQbHVzLCBGYVNhdmUsIEZhU3Bpbm5lciwgRmFUcmFzaCwgRmFVbmRvQWx0IH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCB0eXBlIEFydGljdWxvIH0gZnJvbSAnLi4vLi4vYXJ0aWN1bG9zL2FydGljdWxvcy5jb25maWcnO1xuaW1wb3J0IHsgUmVsYXRpb25hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vUmVsYXRpb25hbElucHV0JztcbmltcG9ydCB7IERlY2ltYWxJbnB1dCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0RlY2ltYWxJbnB1dCc7XG5pbXBvcnQgeyBTZWFyY2hNb2RhbCB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL1NlYXJjaE1vZGFsJztcbmltcG9ydCB0eXBlIHsgRnJhY3Rpb25pbmdQYXlsb2FkIH0gZnJvbSAnLi4vLi4vLi4vaW50ZXJmYWNlcy9BcGlQYXlsb2Fkcyc7XG5pbXBvcnQgeyBjcmVhdGVGcmFjdGlvbmluZywgc2VhcmNoQnlGaWVsZCB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2FwaVNlcnZpY2UnO1xuXG5cbi8vIC0tLSBJTlRFUkZBQ0VTIC0tLVxuaW50ZXJmYWNlIFN0b2NrSXRlbSB7XG4gICAgdGVtcElkOiBzdHJpbmc7XG4gICAgcHJvZHVjdDogQXJ0aWN1bG8gfCBudWxsO1xuICAgIHByb2R1Y3RJZDogbnVtYmVyIHwgbnVsbDtcbiAgICBwcm9kdWN0TmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgICBxdWFudGl0eTogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgUmVzdWx0aW5nUHJvZHVjdCBleHRlbmRzIFN0b2NrSXRlbSB7XG4gICAgYWRkaXRpb25hbENvc3Q6IG51bWJlcjtcbiAgICBvYnNlcnZhdGlvbjogc3RyaW5nO1xufVxuXG4vLyBUaXBvIHBhcmEgaWRlbnRpZmljYXIgcXXDqSBsaXN0YSBlc3RhbW9zIGVkaXRhbmRvXG50eXBlIEVkaXRpbmdUYXJnZXRMaXN0ID0gJ3NvdXJjZScgfCAncmVzdWx0aW5nJyB8ICdyZW1uYW50JztcbnR5cGUgRWRpdGluZ1RhcmdldCA9IHsgbGlzdDogRWRpdGluZ1RhcmdldExpc3Q7IGluZGV4OiBudW1iZXIgfSB8IG51bGw7XG5cblxuZXhwb3J0IGNvbnN0IEZyYWN0aW9uaW5nQ3JlYXRlUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtkYXRlLCBzZXREYXRlXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdKTtcblxuICAgIC8vIOKchSBUUkVTIEVTVEFET1MgU0VQQVJBRE9TIFBBUkEgQ0FEQSBUQUJMQVxuICAgIGNvbnN0IFtzb3VyY2VQcm9kdWN0cywgc2V0U291cmNlUHJvZHVjdHNdID0gdXNlU3RhdGU8U3RvY2tJdGVtW10+KFtdKTtcbiAgICBjb25zdCBbcmVzdWx0aW5nUHJvZHVjdHMsIHNldFJlc3VsdGluZ1Byb2R1Y3RzXSA9IHVzZVN0YXRlPFJlc3VsdGluZ1Byb2R1Y3RbXT4oW10pO1xuICAgIGNvbnN0IFtyZW1uYW50UHJvZHVjdHMsIHNldFJlbW5hbnRQcm9kdWN0c10gPSB1c2VTdGF0ZTxTdG9ja0l0ZW1bXT4oW10pO1xuXG4gICAgLy8g4pyFIE5VRVZPOiBFc3RhZG9zIHBhcmEgbG9zIGPDs2RpZ29zIGRlIHByb2R1Y3RvIChsbyBxdWUgZWwgdXN1YXJpbyBlc2NyaWJlKVxuICAgIGNvbnN0IFtzb3VyY2VQcm9kdWN0Q29kZXMsIHNldFNvdXJjZVByb2R1Y3RDb2Rlc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XG4gICAgY29uc3QgW3Jlc3VsdGluZ1Byb2R1Y3RDb2Rlcywgc2V0UmVzdWx0aW5nUHJvZHVjdENvZGVzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcbiAgICBjb25zdCBbcmVtbmFudFByb2R1Y3RDb2Rlcywgc2V0UmVtbmFudFByb2R1Y3RDb2Rlc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XG5cbiAgICBjb25zdCBbaXNNb2RhbE9wZW4sIHNldElzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZWRpdGluZ1RhcmdldCwgc2V0RWRpdGluZ1RhcmdldF0gPSB1c2VTdGF0ZTxFZGl0aW5nVGFyZ2V0PihudWxsKTtcblxuICAgIC8vIC0tLSBIQU5ETEVSUyBQQVJBIFBST0RVQ1RPUyBERSBPUklHRU4gLS0tXG4gICAgY29uc3QgaGFuZGxlQWRkU291cmNlUm93ID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgICAgIHNldFNvdXJjZVByb2R1Y3RzKHAgPT4gWy4uLnAsIHsgdGVtcElkOiBuZXdJZCwgcHJvZHVjdDogbnVsbCwgcHJvZHVjdElkOiBudWxsLCBwcm9kdWN0TmFtZTogJycsIHF1YW50aXR5OiAxIH1dKTtcbiAgICAgICAgc2V0U291cmNlUHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW25ld0lkXTogJycgfSkpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlU291cmNlUm93ID0gKGlkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0U291cmNlUHJvZHVjdHMocCA9PiBwLmZpbHRlcihpID0+IGkudGVtcElkICE9PSBpZCkpO1xuICAgICAgICBzZXRTb3VyY2VQcm9kdWN0Q29kZXMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgdXBkYXRlZFtpZF07XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZDtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVVcGRhdGVTb3VyY2VSb3cgPSAoaWQ6IHN0cmluZywgZmllbGQ6IGtleW9mIFN0b2NrSXRlbSwgdmFsOiBhbnkpID0+IHNldFNvdXJjZVByb2R1Y3RzKHAgPT4gcC5tYXAoaSA9PiBpLnRlbXBJZCA9PT0gaWQgPyB7IC4uLmksIFtmaWVsZF06IHZhbCB9IDogaSkpO1xuICAgIGNvbnN0IGhhbmRsZUNsZWFyU291cmNlUHJvZHVjdCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldFNvdXJjZVByb2R1Y3RzKHAgPT4gcC5tYXAoaSA9PiBpLnRlbXBJZCA9PT0gaWQgPyB7IC4uLmksIHByb2R1Y3Q6IG51bGwsIHByb2R1Y3RJZDogbnVsbCwgcHJvZHVjdE5hbWU6IG51bGwgfSA6IGkpKTtcbiAgICAgICAgc2V0U291cmNlUHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW2lkXTogJycgfSkpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gSEFORExFUlMgUEFSQSBQUk9EVUNUT1MgUkVTVUxUQU5URVMgLS0tXG4gICAgY29uc3QgaGFuZGxlQWRkUmVzdWx0aW5nUm93ID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgICAgIHNldFJlc3VsdGluZ1Byb2R1Y3RzKHAgPT4gWy4uLnAsIHsgdGVtcElkOiBuZXdJZCwgcHJvZHVjdDogbnVsbCwgcHJvZHVjdElkOiBudWxsLCBwcm9kdWN0TmFtZTogJycsIHF1YW50aXR5OiAxLCBhZGRpdGlvbmFsQ29zdDogMCwgb2JzZXJ2YXRpb246ICcnIH1dKTtcbiAgICAgICAgc2V0UmVzdWx0aW5nUHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW25ld0lkXTogJycgfSkpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlUmVzdWx0aW5nUm93ID0gKGlkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0UmVzdWx0aW5nUHJvZHVjdHMocCA9PiBwLmZpbHRlcihpID0+IGkudGVtcElkICE9PSBpZCkpO1xuICAgICAgICBzZXRSZXN1bHRpbmdQcm9kdWN0Q29kZXMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgdXBkYXRlZFtpZF07XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZDtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVVcGRhdGVSZXN1bHRpbmdSb3cgPSAoaWQ6IHN0cmluZywgZmllbGQ6IGtleW9mIFJlc3VsdGluZ1Byb2R1Y3QsIHZhbDogYW55KSA9PiBzZXRSZXN1bHRpbmdQcm9kdWN0cyhwID0+IHAubWFwKGkgPT4gaS50ZW1wSWQgPT09IGlkID8geyAuLi5pLCBbZmllbGRdOiB2YWwgfSA6IGkpKTtcbiAgICBjb25zdCBoYW5kbGVDbGVhclJlc3VsdGluZ1Byb2R1Y3QgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgICAgICBzZXRSZXN1bHRpbmdQcm9kdWN0cyhwID0+IHAubWFwKGkgPT4gaS50ZW1wSWQgPT09IGlkID8geyAuLi5pLCBwcm9kdWN0OiBudWxsLCBwcm9kdWN0SWQ6IG51bGwsIHByb2R1Y3ROYW1lOiBudWxsIH0gOiBpKSk7XG4gICAgICAgIHNldFJlc3VsdGluZ1Byb2R1Y3RDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtpZF06ICcnIH0pKTtcbiAgICB9O1xuXG4gICAgLy8gLS0tIEhBTkRMRVJTIFBBUkEgUFJPRFVDVE9TIFJFTUFORU5URVMgLS0tXG4gICAgY29uc3QgaGFuZGxlQWRkUmVtbmFudFJvdyA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgbmV3SWQgPSBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgICAgICBzZXRSZW1uYW50UHJvZHVjdHMocCA9PiBbLi4ucCwgeyB0ZW1wSWQ6IG5ld0lkLCBwcm9kdWN0OiBudWxsLCBwcm9kdWN0SWQ6IG51bGwsIHByb2R1Y3ROYW1lOiAnJywgcXVhbnRpdHk6IDEgfV0pO1xuICAgICAgICBzZXRSZW1uYW50UHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW25ld0lkXTogJycgfSkpO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlUmVtbmFudFJvdyA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldFJlbW5hbnRQcm9kdWN0cyhwID0+IHAuZmlsdGVyKGkgPT4gaS50ZW1wSWQgIT09IGlkKSk7XG4gICAgICAgIHNldFJlbW5hbnRQcm9kdWN0Q29kZXMocHJldiA9PiB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5wcmV2IH07XG4gICAgICAgICAgICBkZWxldGUgdXBkYXRlZFtpZF07XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZDtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVVcGRhdGVSZW1uYW50Um93ID0gKGlkOiBzdHJpbmcsIGZpZWxkOiBrZXlvZiBTdG9ja0l0ZW0sIHZhbDogYW55KSA9PiBzZXRSZW1uYW50UHJvZHVjdHMocCA9PiBwLm1hcChpID0+IGkudGVtcElkID09PSBpZCA/IHsgLi4uaSwgW2ZpZWxkXTogdmFsIH0gOiBpKSk7XG4gICAgY29uc3QgaGFuZGxlQ2xlYXJSZW1uYW50UHJvZHVjdCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIHNldFJlbW5hbnRQcm9kdWN0cyhwID0+IHAubWFwKGkgPT4gaS50ZW1wSWQgPT09IGlkID8geyAuLi5pLCBwcm9kdWN0OiBudWxsLCBwcm9kdWN0SWQ6IG51bGwsIHByb2R1Y3ROYW1lOiBudWxsIH0gOiBpKSk7XG4gICAgICAgIHNldFJlbW5hbnRQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbaWRdOiAnJyB9KSk7XG4gICAgfTtcblxuICAgIC8vIC0tLSBMw5NHSUNBIERFIE1PREFMIEFDVFVBTElaQURBIC0tLVxuICAgIGNvbnN0IGhhbmRsZU9wZW5Nb2RhbCA9IChsaXN0OiBFZGl0aW5nVGFyZ2V0TGlzdCwgaW5kZXg6IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KHsgbGlzdCwgaW5kZXggfSk7XG4gICAgICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICAvLyDinIUgTlVFVk86IEhhbmRsZXIgcGFyYSBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28gZW4gcHJvZHVjdG9zIGRlIG9yaWdlblxuICAgIGNvbnN0IGhhbmRsZVNvdXJjZVByb2R1Y3RDb2RlU3VibWl0ID0gYXN5bmMgKHRlbXBJZDogc3RyaW5nKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvZGVUb1NlYXJjaCA9IHNvdXJjZVByb2R1Y3RDb2Rlc1t0ZW1wSWRdPy50cmltKCk7XG4gICAgICAgIGlmICghY29kZVRvU2VhcmNoKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxBcnRpY3Vsbz4oXG4gICAgICAgICAgICAgICAgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ3NrdScsIHZhbHVlOiBjb2RlVG9TZWFyY2ggfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIHNldFNvdXJjZVByb2R1Y3RzKHAgPT4gcC5tYXAoaXRlbSA9PlxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4uaXRlbSwgcHJvZHVjdDogZm91bmQsIHByb2R1Y3RJZDogZm91bmQuaWQsIHByb2R1Y3ROYW1lOiBmb3VuZC5uYW1lIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbVxuICAgICAgICAgICAgICAgICkpO1xuICAgICAgICAgICAgICAgIC8vIEFjdHVhbGl6YXIgZWwgY8OzZGlnbyB2aXN1YWwgY29uIGVsIFNLVSBvZmljaWFsXG4gICAgICAgICAgICAgICAgc2V0U291cmNlUHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW3RlbXBJZF06IGZvdW5kLnNrdSB8fCBTdHJpbmcoZm91bmQuaWQpIH0pKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBQcm9kdWN0byBlbmNvbnRyYWRvOiAke2ZvdW5kLm5hbWV9YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm5pbmcoJ1Byb2R1Y3RvIG5vIGVuY29udHJhZG8gY29uIGVzZSBjw7NkaWdvLicpO1xuICAgICAgICAgICAgICAgIHNldFNvdXJjZVByb2R1Y3RzKHAgPT4gcC5tYXAoaXRlbSA9PlxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4uaXRlbSwgcHJvZHVjdDogbnVsbCwgcHJvZHVjdElkOiBudWxsLCBwcm9kdWN0TmFtZTogbnVsbCB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cbiAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28uJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDinIUgTlVFVk86IEhhbmRsZXIgcGFyYSBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28gZW4gcHJvZHVjdG9zIHJlc3VsdGFudGVzXG4gICAgY29uc3QgaGFuZGxlUmVzdWx0aW5nUHJvZHVjdENvZGVTdWJtaXQgPSBhc3luYyAodGVtcElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgY29kZVRvU2VhcmNoID0gcmVzdWx0aW5nUHJvZHVjdENvZGVzW3RlbXBJZF0/LnRyaW0oKTtcbiAgICAgICAgaWYgKCFjb2RlVG9TZWFyY2gpIHJldHVybjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZm91bmQgPSBhd2FpdCBzZWFyY2hCeUZpZWxkPEFydGljdWxvPihcbiAgICAgICAgICAgICAgICBhcnRpY3Vsb3NNb2R1bGVDb25maWcuZW5kcG9pbnQsXG4gICAgICAgICAgICAgICAgW3sgZmllbGROYW1lOiAnc2t1JywgdmFsdWU6IGNvZGVUb1NlYXJjaCB9XVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICAgICAgc2V0UmVzdWx0aW5nUHJvZHVjdHMocCA9PiBwLm1hcChpdGVtID0+XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udGVtcElkID09PSB0ZW1wSWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5pdGVtLCBwcm9kdWN0OiBmb3VuZCwgcHJvZHVjdElkOiBmb3VuZC5pZCwgcHJvZHVjdE5hbWU6IGZvdW5kLm5hbWUgfVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBpdGVtXG4gICAgICAgICAgICAgICAgKSk7XG4gICAgICAgICAgICAgICAgc2V0UmVzdWx0aW5nUHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW3RlbXBJZF06IGZvdW5kLnNrdSB8fCBTdHJpbmcoZm91bmQuaWQpIH0pKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBQcm9kdWN0byBlbmNvbnRyYWRvOiAke2ZvdW5kLm5hbWV9YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm5pbmcoJ1Byb2R1Y3RvIG5vIGVuY29udHJhZG8gY29uIGVzZSBjw7NkaWdvLicpO1xuICAgICAgICAgICAgICAgIHNldFJlc3VsdGluZ1Byb2R1Y3RzKHAgPT4gcC5tYXAoaXRlbSA9PlxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRlbXBJZCA9PT0gdGVtcElkXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4uaXRlbSwgcHJvZHVjdDogbnVsbCwgcHJvZHVjdElkOiBudWxsLCBwcm9kdWN0TmFtZTogbnVsbCB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cbiAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKCdFcnJvciBhbCBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28uJyk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyDinIUgTlVFVk86IEhhbmRsZXIgcGFyYSBidXNjYXIgcHJvZHVjdG8gcG9yIGPDs2RpZ28gZW4gcHJvZHVjdG9zIHJlbWFuZW50ZXNcbiAgICBjb25zdCBoYW5kbGVSZW1uYW50UHJvZHVjdENvZGVTdWJtaXQgPSBhc3luYyAodGVtcElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3QgY29kZVRvU2VhcmNoID0gcmVtbmFudFByb2R1Y3RDb2Rlc1t0ZW1wSWRdPy50cmltKCk7XG4gICAgICAgIGlmICghY29kZVRvU2VhcmNoKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gYXdhaXQgc2VhcmNoQnlGaWVsZDxBcnRpY3Vsbz4oXG4gICAgICAgICAgICAgICAgYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ3NrdScsIHZhbHVlOiBjb2RlVG9TZWFyY2ggfV1cbiAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgICAgICAgIHNldFJlbW5hbnRQcm9kdWN0cyhwID0+IHAubWFwKGl0ZW0gPT5cbiAgICAgICAgICAgICAgICAgICAgaXRlbS50ZW1wSWQgPT09IHRlbXBJZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyB7IC4uLml0ZW0sIHByb2R1Y3Q6IGZvdW5kLCBwcm9kdWN0SWQ6IGZvdW5kLmlkLCBwcm9kdWN0TmFtZTogZm91bmQubmFtZSB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cbiAgICAgICAgICAgICAgICApKTtcbiAgICAgICAgICAgICAgICBzZXRSZW1uYW50UHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW3RlbXBJZF06IGZvdW5kLnNrdSB8fCBTdHJpbmcoZm91bmQuaWQpIH0pKTtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBQcm9kdWN0byBlbmNvbnRyYWRvOiAke2ZvdW5kLm5hbWV9YCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRvYXN0Lndhcm5pbmcoJ1Byb2R1Y3RvIG5vIGVuY29udHJhZG8gY29uIGVzZSBjw7NkaWdvLicpO1xuICAgICAgICAgICAgICAgIHNldFJlbW5hbnRQcm9kdWN0cyhwID0+IHAubWFwKGl0ZW0gPT5cbiAgICAgICAgICAgICAgICAgICAgaXRlbS50ZW1wSWQgPT09IHRlbXBJZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyB7IC4uLml0ZW0sIHByb2R1Y3Q6IG51bGwsIHByb2R1Y3RJZDogbnVsbCwgcHJvZHVjdE5hbWU6IG51bGwgfVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBpdGVtXG4gICAgICAgICAgICAgICAgKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignRXJyb3IgYWwgYnVzY2FyIHByb2R1Y3RvIHBvciBjw7NkaWdvLicpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8g4pyFIEFDVFVBTElaQURPOiBIYW5kbGVyIHBhcmEgc2VsZWNjaW9uYXIgcHJvZHVjdG8gZGVzZGUgbW9kYWxcbiAgICBjb25zdCBoYW5kbGVTZWxlY3RQcm9kdWN0ID0gKHNlbGVjdGVkUHJvZHVjdDogQXJ0aWN1bG8pID0+IHtcbiAgICAgICAgaWYgKCFlZGl0aW5nVGFyZ2V0KSByZXR1cm47XG4gICAgICAgIGNvbnN0IHsgbGlzdCwgaW5kZXggfSA9IGVkaXRpbmdUYXJnZXQ7XG4gICAgICAgIGNvbnN0IHByb2R1Y3REYXRhID0ge1xuICAgICAgICAgICAgcHJvZHVjdDogc2VsZWN0ZWRQcm9kdWN0LFxuICAgICAgICAgICAgcHJvZHVjdElkOiBzZWxlY3RlZFByb2R1Y3QuaWQsXG4gICAgICAgICAgICBwcm9kdWN0TmFtZTogc2VsZWN0ZWRQcm9kdWN0Lm5hbWVcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAobGlzdCA9PT0gJ3NvdXJjZScpIHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBzb3VyY2VQcm9kdWN0c1tpbmRleF07XG4gICAgICAgICAgICBzZXRTb3VyY2VQcm9kdWN0cyhwID0+IHAubWFwKChpLCBpZHgpID0+IGlkeCA9PT0gaW5kZXggPyB7IC4uLmksIC4uLnByb2R1Y3REYXRhIH0gOiBpKSk7XG4gICAgICAgICAgICAvLyBBY3R1YWxpemFyIGVsIGPDs2RpZ28gdmlzdWFsXG4gICAgICAgICAgICBzZXRTb3VyY2VQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbaXRlbS50ZW1wSWRdOiBzZWxlY3RlZFByb2R1Y3Quc2t1IHx8IFN0cmluZyhzZWxlY3RlZFByb2R1Y3QuaWQpIH0pKTtcbiAgICAgICAgfSBlbHNlIGlmIChsaXN0ID09PSAncmVzdWx0aW5nJykge1xuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHJlc3VsdGluZ1Byb2R1Y3RzW2luZGV4XTtcbiAgICAgICAgICAgIHNldFJlc3VsdGluZ1Byb2R1Y3RzKHAgPT4gcC5tYXAoKGksIGlkeCkgPT4gaWR4ID09PSBpbmRleCA/IHsgLi4uaSwgLi4ucHJvZHVjdERhdGEgfSA6IGkpKTtcbiAgICAgICAgICAgIHNldFJlc3VsdGluZ1Byb2R1Y3RDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtpdGVtLnRlbXBJZF06IHNlbGVjdGVkUHJvZHVjdC5za3UgfHwgU3RyaW5nKHNlbGVjdGVkUHJvZHVjdC5pZCkgfSkpO1xuICAgICAgICB9IGVsc2UgaWYgKGxpc3QgPT09ICdyZW1uYW50Jykge1xuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHJlbW5hbnRQcm9kdWN0c1tpbmRleF07XG4gICAgICAgICAgICBzZXRSZW1uYW50UHJvZHVjdHMocCA9PiBwLm1hcCgoaSwgaWR4KSA9PiBpZHggPT09IGluZGV4ID8geyAuLi5pLCAuLi5wcm9kdWN0RGF0YSB9IDogaSkpO1xuICAgICAgICAgICAgc2V0UmVtbmFudFByb2R1Y3RDb2RlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtpdGVtLnRlbXBJZF06IHNlbGVjdGVkUHJvZHVjdC5za3UgfHwgU3RyaW5nKHNlbGVjdGVkUHJvZHVjdC5pZCkgfSkpO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KG51bGwpO1xuICAgIH07XG5cbiAgICAvLyAtLS0gTMOTR0lDQSBERSBHVUFSREFETyBBQ1RVQUxJWkFEQSAtLS1cbiAgICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoc291cmNlUHJvZHVjdHMubGVuZ3RoID09PSAwIHx8IHNvdXJjZVByb2R1Y3RzLnNvbWUocCA9PiAhcC5wcm9kdWN0KSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJEZWJlIGHDsWFkaXIgYWwgbWVub3MgdW4gcHJvZHVjdG8gZGUgb3JpZ2VuIHbDoWxpZG8uXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHRpbmdQcm9kdWN0cy5sZW5ndGggPT09IDAgJiYgcmVtbmFudFByb2R1Y3RzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJEZWJlIGHDsWFkaXIgYWwgbWVub3MgdW4gcHJvZHVjdG8gcmVzdWx0YW50ZSBvIHJlbWFuZW50ZS5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuXG4gICAgICAgIC8vIENvbWJpbmFtb3MgbG9zIHByb2R1Y3RvcyByZXN1bHRhbnRlcyB5IGxvcyByZW1hbmVudGVzIHBhcmEgZWwgcGF5bG9hZFxuICAgICAgICBjb25zdCBjb21iaW5lZFJlc3VsdGluZyA9IFtcbiAgICAgICAgICAgIC4uLnJlc3VsdGluZ1Byb2R1Y3RzLm1hcChwID0+ICh7XG4gICAgICAgICAgICAgICAgcHJvZHVjdF9pZDogcC5wcm9kdWN0SWQsXG4gICAgICAgICAgICAgICAgcXVhbnRpdHk6IHAucXVhbnRpdHksXG4gICAgICAgICAgICAgICAgYWRkaXRpb25hbF9jb3N0OiBwLmFkZGl0aW9uYWxDb3N0LFxuICAgICAgICAgICAgICAgIG9ic2VydmF0aW9uOiBwLm9ic2VydmF0aW9uLFxuICAgICAgICAgICAgICAgIGlzX3JlbWFuZW50ZTogZmFsc2VcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIC4uLnJlbW5hbnRQcm9kdWN0cy5tYXAocCA9PiAoe1xuICAgICAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHAucHJvZHVjdElkLFxuICAgICAgICAgICAgICAgIHF1YW50aXR5OiBwLnF1YW50aXR5LFxuICAgICAgICAgICAgICAgIGFkZGl0aW9uYWxfY29zdDogMCwgLy8gTG9zIHJlbWFuZW50ZXMgbm8gdGllbmVuIGNvc3RvIGFkaWNpb25hbFxuICAgICAgICAgICAgICAgIG9ic2VydmF0aW9uOiAnUmVtYW5lbnRlIGRlbCBwcm9jZXNvJyxcbiAgICAgICAgICAgICAgICBpc19yZW1hbmVudGU6IHRydWVcbiAgICAgICAgICAgIH0pKVxuICAgICAgICBdO1xuXG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IEZyYWN0aW9uaW5nUGF5bG9hZCA9IHtcbiAgICAgICAgICAgIGZyYWN0aW9uaW5nX2RhdGU6IGRhdGUsXG4gICAgICAgICAgICBzb3VyY2VfcHJvZHVjdHM6IHNvdXJjZVByb2R1Y3RzLm1hcChwID0+ICh7XG4gICAgICAgICAgICAgICAgcHJvZHVjdF9pZDogcC5wcm9kdWN0SWQsXG4gICAgICAgICAgICAgICAgcXVhbnRpdHk6IHAucXVhbnRpdHksXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgICByZXN1bHRpbmdfcHJvZHVjdHM6IGNvbWJpbmVkUmVzdWx0aW5nLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBjcmVhdGVGcmFjdGlvbmluZyhwYXlsb2FkKTtcbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJGcmFjY2lvbmFtaWVudG8gcmVnaXN0cmFkbyBjb24gw6l4aXRvIVwiKTtcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvc3RvY2svZnJhY2Npb25hbWllbnRvcycpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGd1YXJkYXI6XCIsIGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiSHVibyB1biBlcnJvciBhbCBndWFyZGFyIGVsIGZyYWNjaW9uYW1pZW50by5cIik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB0YWJsZUlucHV0U3R5bGVzID0gXCJ3LWZ1bGwgcHgtMiBweS0xIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBzbTp0ZXh0LXNtXCI7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzbTpwLTYgc3BhY2UteS04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNtOml0ZW1zLXN0YXJ0IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q3JlYXIgTnVldm8gRnJhY2Npb25hbWllbnRvIC8gSW1wcmVzacOzbjwvaDE+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZnJhY3Rpb24tZGF0ZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkZlY2hhIGRlbCBNb3ZpbWllbnRvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiZnJhY3Rpb24tZGF0ZVwiIHR5cGU9XCJkYXRlXCIgdmFsdWU9e2RhdGV9IG9uQ2hhbmdlPXtlID0+IHNldERhdGUoZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcHgtMyBweS0yIG10LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHNtOnRleHQtc21cIiBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gVEFCTEEgUFJPRFVDVE9TIERFIE9SSUdFTiAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5Qcm9kdWN0b3MgZGUgT3JpZ2VuIChhIGNvbnN1bWlyKTwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTYgdy0zLzVcIj5Qcm9kdWN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DYW50aWRhZCBhIENvbnN1bWlyPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB5LTMuNSBwbC0zIHByLTQgc206cHItNlwiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NvdXJjZVByb2R1Y3RzLm1hcCgocCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cC50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtzb3VyY2VQcm9kdWN0Q29kZXNbcC50ZW1wSWRdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e3AucHJvZHVjdE5hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBzZXRTb3VyY2VQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbcC50ZW1wSWRdOiB2YWwgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZVNvdXJjZVByb2R1Y3RDb2RlU3VibWl0KHAudGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdzb3VyY2UnLCBpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlQ2xlYXJTb3VyY2VQcm9kdWN0KHAudGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTRcIj48RGVjaW1hbElucHV0IHZhbHVlPXtwLnF1YW50aXR5fSBvbkNoYW5nZT17bnVtID0+IGhhbmRsZVVwZGF0ZVNvdXJjZVJvdyhwLnRlbXBJZCwgJ3F1YW50aXR5JywgbnVtKX0gY2xhc3NOYW1lPXt0YWJsZUlucHV0U3R5bGVzfSAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC0zIHByLTQgdGV4dC1yaWdodCBzbTpwci02XCI+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVTb3VyY2VSb3cocC50ZW1wSWQpfSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwXCI+PEZhVHJhc2ggLz48L2J1dHRvbj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUFkZFNvdXJjZVJvd30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiBtdC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ibHVlLTYwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ibHVlLTcwMFwiPjxGYVBsdXMgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz5Bw7FhZGlyIE9yaWdlbjwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cblxuXG4gICAgICAgICAgICB7LyogLS0tIFRBQkxBIFBST0RVQ1RPUyBHRU5FUkFET1MgLS0tICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+UHJvZHVjdG9zIEdlbmVyYWRvcyAobnVldm9zKTwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IC1teC00IG92ZXJmbG93LXgtYXV0byByaW5nLTEgcmluZy1ncmF5LTMwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTYgdy0yLzVcIj5Qcm9kdWN0bzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5DYW50aWRhZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5Db3N0byBBZGljaW9uYWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+T2JzZXJ2YWNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB5LTMuNSBwbC0zIHByLTQgc206cHItNlwiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdGluZ1Byb2R1Y3RzLm1hcCgocCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cC50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTQgcGwtNCBwci0zIHRleHQtc20gZm9udC1tZWRpdW0gc206cGwtNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdGlvbmFsSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtyZXN1bHRpbmdQcm9kdWN0Q29kZXNbcC50ZW1wSWRdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e3AucHJvZHVjdE5hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBzZXRSZXN1bHRpbmdQcm9kdWN0Q29kZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbcC50ZW1wSWRdOiB2YWwgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZVJlc3VsdGluZ1Byb2R1Y3RDb2RlU3VibWl0KHAudGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCdyZXN1bHRpbmcnLCBpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlQ2xlYXJSZXN1bHRpbmdQcm9kdWN0KHAudGVtcElkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTRcIj48RGVjaW1hbElucHV0IHZhbHVlPXtwLnF1YW50aXR5fSBvbkNoYW5nZT17bnVtID0+IGhhbmRsZVVwZGF0ZVJlc3VsdGluZ1JvdyhwLnRlbXBJZCwgJ3F1YW50aXR5JywgbnVtKX0gY2xhc3NOYW1lPXt0YWJsZUlucHV0U3R5bGVzfSAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00XCI+PERlY2ltYWxJbnB1dCB2YWx1ZT17cC5hZGRpdGlvbmFsQ29zdH0gb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVSZXN1bHRpbmdSb3cocC50ZW1wSWQsICdhZGRpdGlvbmFsQ29zdCcsIG51bSl9IGNsYXNzTmFtZT17dGFibGVJbnB1dFN0eWxlc30gLz48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNFwiPjxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtwLm9ic2VydmF0aW9ufSBvbkNoYW5nZT17ZSA9PiBoYW5kbGVVcGRhdGVSZXN1bHRpbmdSb3cocC50ZW1wSWQsICdvYnNlcnZhdGlvbicsIGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPXt0YWJsZUlucHV0U3R5bGVzfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC0zIHByLTQgdGV4dC1yaWdodCBzbTpwci02XCI+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVSZXN1bHRpbmdSb3cocC50ZW1wSWQpfSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwXCI+PEZhVHJhc2ggLz48L2J1dHRvbj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUFkZFJlc3VsdGluZ1Jvd30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiBtdC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1pbmRpZ28tNjAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWluZGlnby03MDBcIj48RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+QcOxYWRpciBHZW5lcmFkbzwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0g4pyFIE5VRVZBIFRBQkxBIFBBUkEgUkVNQU5FTlRFUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXIgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5Qcm9kdWN0b3MgUmVtYW5lbnRlcyAoZGV2dWVsdG9zIGEgc3RvY2spPC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgLW14LTQgb3ZlcmZsb3cteC1hdXRvIHJpbmctMSByaW5nLWdyYXktMzAwIHNtOm14LTAgc206cm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTQgcHItMyB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc206cGwtNiB3LTMvNVwiPlByb2R1Y3RvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnRpZGFkIFJlbWFuZW50ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweS0zLjUgcGwtMyBwci00IHNtOnByLTZcIj48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW1uYW50UHJvZHVjdHMubWFwKChwLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtwLnRlbXBJZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBmb250LW1lZGl1bSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2RlVmFsdWU9e3JlbW5hbnRQcm9kdWN0Q29kZXNbcC50ZW1wSWRdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e3AucHJvZHVjdE5hbWUgfHwgbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsodmFsKSA9PiBzZXRSZW1uYW50UHJvZHVjdENvZGVzKHByZXYgPT4gKHsgLi4ucHJldiwgW3AudGVtcElkXTogdmFsIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXsoKSA9PiBoYW5kbGVSZW1uYW50UHJvZHVjdENvZGVTdWJtaXQocC50ZW1wSWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoJ3JlbW5hbnQnLCBpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlQ2xlYXJSZW1uYW50UHJvZHVjdChwLnRlbXBJZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00XCI+PERlY2ltYWxJbnB1dCB2YWx1ZT17cC5xdWFudGl0eX0gb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVSZW1uYW50Um93KHAudGVtcElkLCAncXVhbnRpdHknLCBudW0pfSBjbGFzc05hbWU9e3RhYmxlSW5wdXRTdHlsZXN9IC8+PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHNtOnByLTZcIj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVJlbW5hbnRSb3cocC50ZW1wSWQpfSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwXCI+PEZhVHJhc2ggLz48L2J1dHRvbj48L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUFkZFJlbW5hbnRSb3d9IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgbXQtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctZ3JheS02MDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS03MDBcIj48RmFVbmRvQWx0IGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+QcOxYWRpciBSZW1hbmVudGU8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvaW52ZW50YXJpby9mcmFjY2lvbmFtaWVudG9zJyl9IGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwXCI+Q2FuY2VsYXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVTYXZlfSBkaXNhYmxlZD17bG9hZGluZ30gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBtbC0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1ncmVlbi02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmVlbi03MDAgZGlzYWJsZWQ6YmctZ3JlZW4tNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTJcIiAvPiA6IDxGYVNhdmUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0yXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgTW92aW1pZW50b1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtpc01vZGFsT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPFNlYXJjaE1vZGFsXG4gICAgICAgICAgICAgICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9e2hhbmRsZVNlbGVjdFByb2R1Y3R9XG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZz17YXJ0aWN1bG9zTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTtcblxuIl0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9mcmFjdGlvbmluZ3MvcGFnZXMvRnJhY3Rpb25pbmdDcmVhdGVQYWdlLnRzeCJ9