import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cajas/pages/CajasDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/cajas/pages/CajasDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { cajasModuleConfig } from "/src/features/cajas/cajas.config.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
export const CajasDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: caja, loading, error } = useCrudItem(cajasModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando detalle del movimiento..." }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasDetailPage.tsx",
    lineNumber: 30,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasDetailPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  if (!caja) return /* @__PURE__ */ jsxDEV("div", { children: "Movimiento de caja no encontrado." }, void 0, false, {
    fileName: "/app/src/features/cajas/pages/CajasDetailPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  const isOriginatedFromBank = !!caja.source_type && caja.source_id != null && caja.source_type.includes("BankMovement");
  return /* @__PURE__ */ jsxDEV(
    GenericDetailPage,
    {
      config: cajasModuleConfig,
      item: caja,
      canEditOverride: !isOriginatedFromBank
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/cajas/pages/CajasDetailPage.tsx",
      lineNumber: 40,
      columnNumber: 5
    },
    this
  );
};
_s(CajasDetailPage, "uRLyb1nYTHKifwslsVZ5saRTw90=", false, function() {
  return [useParams, useCrudItem];
});
_c = CajasDetailPage;
var _c;
$RefreshReg$(_c, "CajasDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/cajas/pages/CajasDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/cajas/pages/CajasDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVXdCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHlCQUFvQztBQUM3QyxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsTUFBTUMsU0FBU0MsTUFBTSxJQUFJUCxZQUFrQkQsbUJBQW1CSSxFQUFFO0FBRTlFLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLGtEQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUM7QUFDM0QsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsS0FBTSxRQUFPLHVCQUFDLFNBQUksaURBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzQztBQUV4RCxRQUFNRyx1QkFDRixDQUFDLENBQUNILEtBQUtJLGVBQ1BKLEtBQUtLLGFBQWEsUUFDbEJMLEtBQUtJLFlBQVlFLFNBQVMsY0FBYztBQUU1QyxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRWjtBQUFBQSxNQUNSLE1BQU1NO0FBQUFBLE1BQ04saUJBQWlCLENBQUNHO0FBQUFBO0FBQUFBLElBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUcyQztBQUduRDtBQUFFTixHQXBCV0QsaUJBQWU7QUFBQSxVQUNUSixXQUN3QkcsV0FBVztBQUFBO0FBQUFZLEtBRnpDWDtBQUFlLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJHZW5lcmljRGV0YWlsUGFnZSIsImNhamFzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZEl0ZW0iLCJDYWphc0RldGFpbFBhZ2UiLCJfcyIsImlkIiwiaXRlbSIsImNhamEiLCJsb2FkaW5nIiwiZXJyb3IiLCJpc09yaWdpbmF0ZWRGcm9tQmFuayIsInNvdXJjZV90eXBlIiwic291cmNlX2lkIiwiaW5jbHVkZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYWphc0RldGFpbFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9mZWF0dXJlcy9jYWphcy9wYWdlcy9DYWphc0RldGFpbFBhZ2UudHN4XG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IEdlbmVyaWNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgY2FqYXNNb2R1bGVDb25maWcsIHR5cGUgQ2FqYSB9IGZyb20gJy4uL2NhamFzLmNvbmZpZyc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcblxuZXhwb3J0IGNvbnN0IENhamFzRGV0YWlsUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgeyBpdGVtOiBjYWphLCBsb2FkaW5nLCBlcnJvciB9ID0gdXNlQ3J1ZEl0ZW08Q2FqYT4oY2FqYXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdj5DYXJnYW5kbyBkZXRhbGxlIGRlbCBtb3ZpbWllbnRvLi4uPC9kaXY+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIWNhamEpIHJldHVybiA8ZGl2Pk1vdmltaWVudG8gZGUgY2FqYSBubyBlbmNvbnRyYWRvLjwvZGl2PjtcblxuICAgIGNvbnN0IGlzT3JpZ2luYXRlZEZyb21CYW5rID1cbiAgICAgICAgISFjYWphLnNvdXJjZV90eXBlICYmXG4gICAgICAgIGNhamEuc291cmNlX2lkICE9IG51bGwgJiZcbiAgICAgICAgY2FqYS5zb3VyY2VfdHlwZS5pbmNsdWRlcygnQmFua01vdmVtZW50Jyk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2VcbiAgICAgICAgICAgIGNvbmZpZz17Y2FqYXNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBpdGVtPXtjYWphfVxuICAgICAgICAgICAgY2FuRWRpdE92ZXJyaWRlPXshaXNPcmlnaW5hdGVkRnJvbUJhbmt9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2NhamFzL3BhZ2VzL0NhamFzRGV0YWlsUGFnZS50c3gifQ==