import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/proveedores/pages/ProveedoresDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
import { proveedoresModuleConfig } from "/src/features/proveedores/proveedores.config.tsx";
import { planDeCuentasModuleConfig } from "/src/features/plan_de_cuentas/plan_de_cuentas.config.tsx";
import { searchByField } from "/src/services/apiService.ts";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { EntityDetailPageLayout } from "/src/components/common/EntityDetailPageLayout.tsx";
import { GenericDetailPage } from "/src/components/common/GenericDetailPage.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
const ProveedorDetailContent = ({ config, item }) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(GenericDetailPage, { config, item, hideHeader: true }, void 0, false, {
      fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
      lineNumber: 36,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 border rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2 bg-gray-50 rounded-t-md", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium text-gray-800", children: "Impuestos y Retenciones Asignadas" }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 41,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 40,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: item.relatedTaxes && item.relatedTaxes.length > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 space-y-2", children: item.relatedTaxes.map(
        (tax) => /* @__PURE__ */ jsxDEV("li", { className: "text-base text-gray-900", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: tax.name }, void 0, false, {
            fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
            lineNumber: 48,
            columnNumber: 37
          }, this),
          " (",
          tax.rate,
          "%)"
        ] }, tax.id, true, {
          fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 45,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Este proveedor no tiene impuestos específicos asignados." }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 53,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 43,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
      lineNumber: 39,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_c = ProveedorDetailContent;
export const ProveedorDetailPage = () => {
  _s();
  const { id } = useParams();
  const { item: proveedor, loading, error } = useCrudItem(proveedoresModuleConfig, id);
  const [hydratedItem, setHydratedItem] = useState(null);
  useEffect(() => {
    if (!proveedor) {
      setHydratedItem(null);
      return;
    }
    const code = proveedor.account_code;
    if (!code || proveedor.account_name != null && proveedor.account_name !== "") {
      setHydratedItem(proveedor);
      return;
    }
    let cancelled = false;
    searchByField(
      planDeCuentasModuleConfig.endpoint,
      [{ fieldName: "code", value: code }]
    ).then((account) => {
      if (cancelled || !account) return;
      setHydratedItem({
        ...proveedor,
        account_id: account.id,
        account_code: account.code,
        account_name: account.name ?? null
      });
    }).catch(() => setHydratedItem(proveedor));
    return () => {
      cancelled = true;
    };
  }, [proveedor]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
    lineNumber: 97,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
    lineNumber: 98,
    columnNumber: 21
  }, this);
  if (!proveedor) return /* @__PURE__ */ jsxDEV("div", { children: "Proveedor no encontrado." }, void 0, false, {
    fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
    lineNumber: 99,
    columnNumber: 26
  }, this);
  const itemToShow = hydratedItem ?? proveedor;
  const tabs = [
    { id: "details", name: "Detalles" },
    { id: "movements", name: "Cuenta Corriente" }
  ];
  return /* @__PURE__ */ jsxDEV(
    EntityDetailPageLayout,
    {
      config: proveedoresModuleConfig,
      item: itemToShow,
      entityType: "provider",
      customDetailComponent: /* @__PURE__ */ jsxDEV(ProveedorDetailContent, { config: proveedoresModuleConfig, item: itemToShow }, void 0, false, {
        fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
        lineNumber: 113,
        columnNumber: 30
      }, this),
      tabs
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx",
      lineNumber: 109,
      columnNumber: 5
    },
    this
  );
};
_s(ProveedorDetailPage, "3FhrtTdF0tuGe/Ux9GtmEZOJhbY=", false, function() {
  return [useParams, useCrudItem];
});
_c2 = ProveedorDetailPage;
var _c, _c2;
$RefreshReg$(_c, "ProveedorDetailContent");
$RefreshReg$(_c2, "ProveedorDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/proveedores/pages/ProveedoresDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWZaLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsK0JBQStDO0FBQ3hELFNBQVNDLGlDQUFpQztBQUMxQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0Msc0JBQXNCO0FBRy9CLE1BQU1DLHlCQUFnR0EsQ0FBQyxFQUFFQyxRQUFRQyxLQUFLLE1BQU07QUFDeEgsU0FDSSx1QkFBQyxTQUVHO0FBQUEsMkJBQUMscUJBQWtCLFFBQWdCLE1BQVksWUFBWSxRQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdFO0FBQUEsSUFHaEUsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFFBQUcsV0FBVSxxQ0FBb0MsaURBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUYsS0FEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDVkEsZUFBS0MsZ0JBQWdCRCxLQUFLQyxhQUFhQyxTQUFTLElBQzdDLHVCQUFDLFFBQUcsV0FBVSw0QkFDVEYsZUFBS0MsYUFBYUU7QUFBQUEsUUFBSSxDQUFBQyxRQUNuQix1QkFBQyxRQUFnQixXQUFVLDJCQUN2QjtBQUFBLGlDQUFDLFVBQUssV0FBVSxlQUFlQSxjQUFJQyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQU87QUFBQSxVQUFHRCxJQUFJRTtBQUFBQSxVQUFLO0FBQUEsYUFEdERGLElBQUlHLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFDSCxLQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0VBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkYsS0FWckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFUjtBQUVBQyxLQTdCTVY7QUE4QkMsYUFBTVcsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxFQUFFSCxHQUFHLElBQUluQixVQUEwQjtBQUN6QyxRQUFNLEVBQUVZLE1BQU1XLFdBQVdDLFNBQVNDLE1BQU0sSUFBSW5CLFlBQXVCSCx5QkFBeUJnQixFQUFFO0FBQzlGLFFBQU0sQ0FBQ08sY0FBY0MsZUFBZSxJQUFJekIsU0FBMkIsSUFBSTtBQUd2RUQsWUFBVSxNQUFNO0FBQ1osUUFBSSxDQUFDc0IsV0FBVztBQUNaSSxzQkFBZ0IsSUFBSTtBQUNwQjtBQUFBLElBQ0o7QUFDQSxVQUFNQyxPQUFPTCxVQUFVTTtBQUN2QixRQUFJLENBQUNELFFBQVNMLFVBQVVPLGdCQUFnQixRQUFRUCxVQUFVTyxpQkFBaUIsSUFBSztBQUM1RUgsc0JBQWdCSixTQUFTO0FBQ3pCO0FBQUEsSUFDSjtBQUNBLFFBQUlRLFlBQVk7QUFDaEIxQjtBQUFBQSxNQUNJRCwwQkFBMEI0QjtBQUFBQSxNQUMxQixDQUFDLEVBQUVDLFdBQVcsUUFBUUMsT0FBT04sS0FBSyxDQUFDO0FBQUEsSUFDdkMsRUFDS08sS0FBSyxDQUFDQyxZQUFZO0FBQ2YsVUFBSUwsYUFBYSxDQUFDSyxRQUFTO0FBQzNCVCxzQkFBZ0I7QUFBQSxRQUNaLEdBQUdKO0FBQUFBLFFBQ0hjLFlBQVlELFFBQVFqQjtBQUFBQSxRQUNwQlUsY0FBY08sUUFBUVI7QUFBQUEsUUFDdEJFLGNBQWNNLFFBQVFuQixRQUFRO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0wsQ0FBQyxFQUNBcUIsTUFBTSxNQUFNWCxnQkFBZ0JKLFNBQVMsQ0FBQztBQUUzQyxXQUFPLE1BQU07QUFBRVEsa0JBQVk7QUFBQSxJQUFNO0FBQUEsRUFDckMsR0FBRyxDQUFDUixTQUFTLENBQUM7QUFFZCxNQUFJQyxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUlDLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUN2RCxNQUFJLENBQUNGLFVBQVcsUUFBTyx1QkFBQyxTQUFJLHdDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkI7QUFFcEQsUUFBTWdCLGFBQWFiLGdCQUFnQkg7QUFFbkMsUUFBTWlCLE9BQU87QUFBQSxJQUNULEVBQUVyQixJQUFJLFdBQVdGLE1BQU0sV0FBVztBQUFBLElBQ2xDLEVBQUVFLElBQUksYUFBYUYsTUFBTSxtQkFBbUI7QUFBQSxFQUFDO0FBR2pELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFkO0FBQUFBLE1BQ1IsTUFBTW9DO0FBQUFBLE1BQ04sWUFBVztBQUFBLE1BQ1gsdUJBQXVCLHVCQUFDLDBCQUF1QixRQUFRcEMseUJBQXlCLE1BQU1vQyxjQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDakc7QUFBQTtBQUFBLElBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2U7QUFHdkI7QUFBRWpCLEdBdkRXRCxxQkFBbUI7QUFBQSxVQUNickIsV0FDNkJNLFdBQVc7QUFBQTtBQUFBbUMsTUFGOUNwQjtBQUFtQixJQUFBRCxJQUFBcUI7QUFBQUMsYUFBQXRCLElBQUE7QUFBQXNCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInByb3ZlZWRvcmVzTW9kdWxlQ29uZmlnIiwicGxhbkRlQ3VlbnRhc01vZHVsZUNvbmZpZyIsInNlYXJjaEJ5RmllbGQiLCJ1c2VDcnVkSXRlbSIsIkVudGl0eURldGFpbFBhZ2VMYXlvdXQiLCJHZW5lcmljRGV0YWlsUGFnZSIsIkxvYWRpbmdTcGlubmVyIiwiUHJvdmVlZG9yRGV0YWlsQ29udGVudCIsImNvbmZpZyIsIml0ZW0iLCJyZWxhdGVkVGF4ZXMiLCJsZW5ndGgiLCJtYXAiLCJ0YXgiLCJuYW1lIiwicmF0ZSIsImlkIiwiX2MiLCJQcm92ZWVkb3JEZXRhaWxQYWdlIiwiX3MiLCJwcm92ZWVkb3IiLCJsb2FkaW5nIiwiZXJyb3IiLCJoeWRyYXRlZEl0ZW0iLCJzZXRIeWRyYXRlZEl0ZW0iLCJjb2RlIiwiYWNjb3VudF9jb2RlIiwiYWNjb3VudF9uYW1lIiwiY2FuY2VsbGVkIiwiZW5kcG9pbnQiLCJmaWVsZE5hbWUiLCJ2YWx1ZSIsInRoZW4iLCJhY2NvdW50IiwiYWNjb3VudF9pZCIsImNhdGNoIiwiaXRlbVRvU2hvdyIsInRhYnMiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvdmVlZG9yZXNEZXRhaWxQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvZmVhdHVyZXMvcHJvdmVlZG9yZXMvcGFnZXMvUHJvdmVlZG9yZXNEZXRhaWxQYWdlLnRzeFxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgcHJvdmVlZG9yZXNNb2R1bGVDb25maWcsIHR5cGUgUHJvdmVlZG9yIH0gZnJvbSAnLi4vcHJvdmVlZG9yZXMuY29uZmlnJztcbmltcG9ydCB7IHBsYW5EZUN1ZW50YXNNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi9wbGFuX2RlX2N1ZW50YXMvcGxhbl9kZV9jdWVudGFzLmNvbmZpZyc7XG5pbXBvcnQgeyBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbmltcG9ydCB7IEVudGl0eURldGFpbFBhZ2VMYXlvdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9FbnRpdHlEZXRhaWxQYWdlTGF5b3V0JztcbmltcG9ydCB7IEdlbmVyaWNEZXRhaWxQYWdlIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vR2VuZXJpY0RldGFpbFBhZ2UnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcblxuLy8gV3JhcHBlciBwYXJhIGVsIGNvbnRlbmlkbyBkZWwgZGV0YWxsZVxuY29uc3QgUHJvdmVlZG9yRGV0YWlsQ29udGVudDogUmVhY3QuRkM8eyBjb25maWc6IHR5cGVvZiBwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZzsgaXRlbTogUHJvdmVlZG9yIH0+ID0gKHsgY29uZmlnLCBpdGVtIH0pID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgey8qIDEuIERldGFsbGUgR2Vuw6lyaWNvIChjYW1wb3MgZGVsIGNvbmZpZykgKi99XG4gICAgICAgICAgICA8R2VuZXJpY0RldGFpbFBhZ2UgY29uZmlnPXtjb25maWd9IGl0ZW09e2l0ZW19IGhpZGVIZWFkZXI9e3RydWV9IC8+XG5cbiAgICAgICAgICAgIHsvKiAyLiBCbG9xdWUgZGUgSW1wdWVzdG9zIChjYW1wb3MgZGUgbGEgcmVsYWNpw7NuKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBib3JkZXIgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWdyYXktNTAgcm91bmRlZC10LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgeSBSZXRlbmNpb25lcyBBc2lnbmFkYXM8L2g0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlbGF0ZWRUYXhlcyAmJiBpdGVtLnJlbGF0ZWRUYXhlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBwbC01IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlbGF0ZWRUYXhlcy5tYXAodGF4ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17dGF4LmlkfSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57dGF4Lm5hbWV9PC9zcGFuPiAoe3RheC5yYXRlfSUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+RXN0ZSBwcm92ZWVkb3Igbm8gdGllbmUgaW1wdWVzdG9zIGVzcGVjw61maWNvcyBhc2lnbmFkb3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuXG4vLyBQw6FnaW5hIGRlIERldGFsbGVcbmV4cG9ydCBjb25zdCBQcm92ZWVkb3JEZXRhaWxQYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcbiAgICBjb25zdCB7IGl0ZW06IHByb3ZlZWRvciwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPFByb3ZlZWRvcj4ocHJvdmVlZG9yZXNNb2R1bGVDb25maWcsIGlkKTtcbiAgICBjb25zdCBbaHlkcmF0ZWRJdGVtLCBzZXRIeWRyYXRlZEl0ZW1dID0gdXNlU3RhdGU8UHJvdmVlZG9yIHwgbnVsbD4obnVsbCk7XG5cbiAgICAvLyBIaWRyYXRhciBhY2NvdW50X25hbWUgKHkgYWNjb3VudF9pZCkgY3VhbmRvIGxhIEFQSSBzb2xvIGRldnVlbHZlIGFjY291bnRfY29kZSwgcGFyYSBxdWUgbGEgdmlzdGEgZGV0YWxsZSBtdWVzdHJlIGxhIGN1ZW50YSBjb250YWJsZVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghcHJvdmVlZG9yKSB7XG4gICAgICAgICAgICBzZXRIeWRyYXRlZEl0ZW0obnVsbCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY29kZSA9IHByb3ZlZWRvci5hY2NvdW50X2NvZGU7XG4gICAgICAgIGlmICghY29kZSB8fCAocHJvdmVlZG9yLmFjY291bnRfbmFtZSAhPSBudWxsICYmIHByb3ZlZWRvci5hY2NvdW50X25hbWUgIT09ICcnKSkge1xuICAgICAgICAgICAgc2V0SHlkcmF0ZWRJdGVtKHByb3ZlZWRvcik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgICAgICBzZWFyY2hCeUZpZWxkPHsgaWQ6IG51bWJlcjsgY29kZTogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfT4oXG4gICAgICAgICAgICBwbGFuRGVDdWVudGFzTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgW3sgZmllbGROYW1lOiAnY29kZScsIHZhbHVlOiBjb2RlIH1dXG4gICAgICAgIClcbiAgICAgICAgICAgIC50aGVuKChhY2NvdW50KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGNhbmNlbGxlZCB8fCAhYWNjb3VudCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHNldEh5ZHJhdGVkSXRlbSh7XG4gICAgICAgICAgICAgICAgICAgIC4uLnByb3ZlZWRvcixcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudF9pZDogYWNjb3VudC5pZCxcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudF9jb2RlOiBhY2NvdW50LmNvZGUsXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnRfbmFtZTogYWNjb3VudC5uYW1lID8/IG51bGwsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNldEh5ZHJhdGVkSXRlbShwcm92ZWVkb3IpKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4geyBjYW5jZWxsZWQgPSB0cnVlOyB9O1xuICAgIH0sIFtwcm92ZWVkb3JdKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcbiAgICBpZiAoIXByb3ZlZWRvcikgcmV0dXJuIDxkaXY+UHJvdmVlZG9yIG5vIGVuY29udHJhZG8uPC9kaXY+O1xuXG4gICAgY29uc3QgaXRlbVRvU2hvdyA9IGh5ZHJhdGVkSXRlbSA/PyBwcm92ZWVkb3I7XG5cbiAgICBjb25zdCB0YWJzID0gW1xuICAgICAgICB7IGlkOiAnZGV0YWlscycsIG5hbWU6ICdEZXRhbGxlcycgfSxcbiAgICAgICAgeyBpZDogJ21vdmVtZW50cycsIG5hbWU6ICdDdWVudGEgQ29ycmllbnRlJyB9LFxuICAgIF07XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8RW50aXR5RGV0YWlsUGFnZUxheW91dFxuICAgICAgICAgICAgY29uZmlnPXtwcm92ZWVkb3Jlc01vZHVsZUNvbmZpZ31cbiAgICAgICAgICAgIGl0ZW09e2l0ZW1Ub1Nob3d9XG4gICAgICAgICAgICBlbnRpdHlUeXBlPVwicHJvdmlkZXJcIlxuICAgICAgICAgICAgY3VzdG9tRGV0YWlsQ29tcG9uZW50PXs8UHJvdmVlZG9yRGV0YWlsQ29udGVudCBjb25maWc9e3Byb3ZlZWRvcmVzTW9kdWxlQ29uZmlnfSBpdGVtPXtpdGVtVG9TaG93fSAvPn1cbiAgICAgICAgICAgIHRhYnM9e3RhYnN9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9wcm92ZWVkb3Jlcy9wYWdlcy9Qcm92ZWVkb3Jlc0RldGFpbFBhZ2UudHN4In0=