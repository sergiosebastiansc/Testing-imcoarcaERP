import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=cc4fbb62"; const ReactDOM = __vite__cjsImport1_reactDom_client.__esModule ? __vite__cjsImport1_reactDom_client.default : __vite__cjsImport1_reactDom_client;
import App from "/src/App.tsx";
import "/src/index.css";
import { AuthProvider } from "/src/context/AuthContext.tsx";
import { OrganizationProvider } from "/src/context/OrganizationContext.tsx";
import { ModalProvider } from "/src/context/ModalContext.tsx";
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(OrganizationProvider, { children: /* @__PURE__ */ jsxDEV(ModalProvider, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/app/src/main.tsx",
    lineNumber: 14,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/app/src/main.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/app/src/main.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/app/src/main.tsx",
    lineNumber: 11,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7QUFaUixPQUFPQSxjQUFjO0FBQ3JCLE9BQU9DLFNBQVM7QUFDaEIsT0FBTztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MscUJBQXFCO0FBRTlCSixTQUFTSyxXQUFXQyxTQUFTQyxlQUFlLE1BQU0sQ0FBRSxFQUFFQztBQUFBQSxFQUVwRCx1QkFBQyxnQkFDQyxpQ0FBQyx3QkFDQyxpQ0FBQyxpQkFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVGIiwibmFtZXMiOlsiUmVhY3RET00iLCJBcHAiLCJBdXRoUHJvdmlkZXIiLCJPcmdhbml6YXRpb25Qcm92aWRlciIsIk1vZGFsUHJvdmlkZXIiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvbWFpbi50c3hcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAudHN4JztcbmltcG9ydCAnLi9pbmRleC5jc3MnOyAvLyBBc2Vnw7pyYXRlIGRlIHF1ZSBUYWlsd2luZCBlc3TDqSBpbXBvcnRhZG8gYXF1w61cbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dC50c3gnO1xuaW1wb3J0IHsgT3JnYW5pemF0aW9uUHJvdmlkZXIgfSBmcm9tICcuL2NvbnRleHQvT3JnYW5pemF0aW9uQ29udGV4dC50c3gnO1xuaW1wb3J0IHsgTW9kYWxQcm92aWRlciB9IGZyb20gJy4vY29udGV4dC9Nb2RhbENvbnRleHQudHN4JztcblxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpISkucmVuZGVyKFxuXG4gIDxBdXRoUHJvdmlkZXI+XG4gICAgPE9yZ2FuaXphdGlvblByb3ZpZGVyPlxuICAgICAgPE1vZGFsUHJvdmlkZXI+XG4gICAgICAgIDxBcHAgLz5cbiAgICAgIDwvTW9kYWxQcm92aWRlcj5cbiAgICA8L09yZ2FuaXphdGlvblByb3ZpZGVyPlxuICA8L0F1dGhQcm92aWRlcj5cblxuKTsiXSwiZmlsZSI6Ii9hcHAvc3JjL21haW4udHN4In0=