import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/articulos/pages/ArticulosEditPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/articulos/pages/ArticulosEditPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { ArticulosFormPage } from "/src/features/articulos/pages/ArticulosFormPage.tsx";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { articulosModuleConfig } from "/src/features/articulos/articulos.config.tsx";
export const ArticuloEditPage = () => {
  _s();
  const { id } = useParams();
  const { item: articulo, loading, error } = useCrudItem(articulosModuleConfig, id);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { children: "Cargando datos del artículo..." }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosEditPage.tsx",
    lineNumber: 31,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosEditPage.tsx",
    lineNumber: 32,
    columnNumber: 21
  }, this);
  if (!articulo) return /* @__PURE__ */ jsxDEV("div", { children: "Artículo no encontrado (o estás intentando editar una URL inválIDA)." }, void 0, false, {
    fileName: "/app/src/features/articulos/pages/ArticulosEditPage.tsx",
    lineNumber: 33,
    columnNumber: 25
  }, this);
  return (
    // ✅ CAMBIO: Renderizamos el nuevo formulario en modo 'edit'
    /* @__PURE__ */ jsxDEV(
      ArticulosFormPage,
      {
        mode: "edit",
        initialData: articulo,
        loading,
        error
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/articulos/pages/ArticulosEditPage.tsx",
        lineNumber: 37,
        columnNumber: 5
      },
      this
    )
  );
};
_s(ArticuloEditPage, "mpSUQAolkRZGTw+tDUUcmyOwymY=", false, function() {
  return [useParams, useCrudItem];
});
_c = ArticuloEditPage;
var _c;
$RefreshReg$(_c, "ArticuloEditPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/articulos/pages/ArticulosEditPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/articulos/pages/ArticulosEditPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3dCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVR4QixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyw2QkFBNEM7QUFFOUMsYUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQTBCO0FBQ3pDLFFBQU0sRUFBRU8sTUFBTUMsVUFBVUMsU0FBU0MsTUFBTSxJQUFJUixZQUFzQkMsdUJBQXVCRyxFQUFFO0FBRTFGLE1BQUlHLFFBQVMsUUFBTyx1QkFBQyxTQUFJLDhDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUM7QUFDdkQsTUFBSUMsTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQ3ZELE1BQUksQ0FBQ0YsU0FBVSxRQUFPLHVCQUFDLFNBQUksb0ZBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5RTtBQUUvRjtBQUFBO0FBQUEsSUFFSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsYUFBYUE7QUFBQUEsUUFDYjtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWlCO0FBQUE7QUFHekI7QUFBRUgsR0FqQldELGtCQUFnQjtBQUFBLFVBQ1ZKLFdBQzRCRSxXQUFXO0FBQUE7QUFBQVMsS0FGN0NQO0FBQWdCLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VQYXJhbXMiLCJBcnRpY3Vsb3NGb3JtUGFnZSIsInVzZUNydWRJdGVtIiwiYXJ0aWN1bG9zTW9kdWxlQ29uZmlnIiwiQXJ0aWN1bG9FZGl0UGFnZSIsIl9zIiwiaWQiLCJpdGVtIiwiYXJ0aWN1bG8iLCJsb2FkaW5nIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcnRpY3Vsb3NFZGl0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL2ZlYXR1cmVzL2FydGljdWxvcy9wYWdlcy9BcnRpY3Vsb3NFZGl0UGFnZS50c3hcblxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBBcnRpY3Vsb3NGb3JtUGFnZSB9IGZyb20gJy4vQXJ0aWN1bG9zRm9ybVBhZ2UnOyAvLyDinIUgTlVFVk86IEltcG9ydGFtb3MgZWwgZm9ybXVsYXJpbyBwZXJzb25hbGl6YWRvXG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJzsgLy8gSW1wb3J0YW1vcyBlbCBudWV2byBob29rXG5pbXBvcnQgeyBhcnRpY3Vsb3NNb2R1bGVDb25maWcsIHR5cGUgQXJ0aWN1bG8gfSBmcm9tICcuLi9hcnRpY3Vsb3MuY29uZmlnJztcblxuZXhwb3J0IGNvbnN0IEFydGljdWxvRWRpdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xuICAgIGNvbnN0IHsgaXRlbTogYXJ0aWN1bG8sIGxvYWRpbmcsIGVycm9yIH0gPSB1c2VDcnVkSXRlbTxBcnRpY3Vsbz4oYXJ0aWN1bG9zTW9kdWxlQ29uZmlnLCBpZCk7XG5cbiAgICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXY+Q2FyZ2FuZG8gZGF0b3MgZGVsIGFydMOtY3Vsby4uLjwvZGl2PjtcbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG4gICAgaWYgKCFhcnRpY3VsbykgcmV0dXJuIDxkaXY+QXJ0w61jdWxvIG5vIGVuY29udHJhZG8gKG8gZXN0w6FzIGludGVudGFuZG8gZWRpdGFyIHVuYSBVUkwgaW52w6FsSURBKS48L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICAvLyDinIUgQ0FNQklPOiBSZW5kZXJpemFtb3MgZWwgbnVldm8gZm9ybXVsYXJpbyBlbiBtb2RvICdlZGl0J1xuICAgICAgICA8QXJ0aWN1bG9zRm9ybVBhZ2VcbiAgICAgICAgICAgIG1vZGU9XCJlZGl0XCJcbiAgICAgICAgICAgIGluaXRpYWxEYXRhPXthcnRpY3Vsb31cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBlcnJvcj17ZXJyb3J9XG4gICAgICAgIC8+XG4gICAgKTtcbn07Il0sImZpbGUiOiIvYXBwL3NyYy9mZWF0dXJlcy9hcnRpY3Vsb3MvcGFnZXMvQXJ0aWN1bG9zRWRpdFBhZ2UudHN4In0=