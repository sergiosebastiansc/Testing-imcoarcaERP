import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { FaSave, FaSpinner, FaInfoCircle, FaPlus, FaTrash } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { getById, searchByField } from "/src/services/apiService.ts";
import { notasFinancierasModuleConfig } from "/src/features/notas_financieras/notas_financieras.config.tsx";
import { salesInvoicesModuleConfig } from "/src/features/facturas_venta/facturas_venta.config.tsx";
import { clientesModuleConfig } from "/src/features/clientes/clientes.config.tsx";
import { vendedoresModuleConfig } from "/src/features/vendedores/vendedores.config.tsx";
import { compradoresModuleConfig } from "/src/features/compradores/compradores.config.tsx";
import { monedasModuleConfig } from "/src/features/monedas/monedas.config.tsx";
import { RelationalInput } from "/src/components/common/RelationalInput.tsx";
import { DecimalInput } from "/src/components/common/DecimalInput.tsx";
import { SearchModal } from "/src/components/common/SearchModal.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { useModal } from "/src/context/ModalContext.tsx";
import { formatValue } from "/src/utils/formatters.ts";
import { formatAppliedTaxTitle } from "/src/utils/taxDisplay.ts";
import {} from "/src/types/appliedTaxes.ts";
import {
  getEffectiveClientTaxes,
  isClientLeyExportacionTdfExempt,
  sanitizeTaxPayloadForExemptClient
} from "/src/utils/clientTaxExemption.ts";
import { computeSalesAppliedTaxes } from "/src/utils/salesRelatedTaxComputation.ts";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const defaultInitialData = {
  id: 0,
  type: "DEBIT",
  series: "B",
  issue_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  total_amount: 0,
  exchange_rate: 1,
  discount_percentage: 0,
  withouttax_amount: 0,
  concept: "",
  notes: null,
  has_item_level_taxes: false,
  emit_now: true,
  // Siempre true
  client_id: null,
  salesperson_id: null,
  buyer_id: null,
  currency_id: null,
  sales_invoice_id: null,
  items: [],
  taxes: []
};
const defaultItem = {
  line_number: 1,
  description: "",
  concept_code: "NOTA-FINANCIERA",
  quantity: 1,
  unit_price: 0,
  discount_percentage: 0,
  taxes: []
};
export const NotasFinancierasFormPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const mode = id ? "edit" : "create";
  const { showConfirmationModal } = useModal();
  const { item: loadedData, loading: loadingData, saveItem } = useCrudItem(notasFinancierasModuleConfig, id);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState(defaultInitialData);
  const [items, setItems] = useState(() => [{ ...defaultItem, tempId: crypto.randomUUID() }]);
  const [clientTaxes, setClientTaxes] = useState([]);
  const [clientTaxCondition, setClientTaxCondition] = useState(null);
  const [isClientTaxExempt, setIsClientTaxExempt] = useState(false);
  const [appliedTaxes, setAppliedTaxes] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState(null);
  const [editingTarget, setEditingTarget] = useState(null);
  useEffect(() => {
    if (mode === "edit" && loadedData) {
      if (loadedData.cae_number) {
        toast.error("No se puede editar una Nota Financiera que ya tiene CAE.");
        navigate(getListReturnPath(notasFinancierasModuleConfig.baseRoute));
        return;
      }
      const hydrated = {
        ...defaultInitialData,
        ...loadedData,
        client_code: loadedData.client?.customer_code || "",
        client_name: loadedData.client?.name || "",
        salesperson_code: loadedData.salesperson?.code || "",
        salesperson_name: loadedData.salesperson?.name || "",
        buyer_code: loadedData.buyer?.code || "",
        buyer_name: loadedData.buyer?.name || "",
        currency_code: loadedData.currency?.code || "",
        currency_name: loadedData.currency?.name || "",
        sales_invoice_number: loadedData.sales_invoice?.invoice_number || null
      };
      setFormData(hydrated);
      const loadedItems = (hydrated.items || []).length ? (hydrated.items || []).map((it) => ({ ...it, concept_code: it.concept_code || "NOTA-FINANCIERA", quantity: it.quantity ?? 1, tempId: crypto.randomUUID() })) : [{ ...defaultItem, tempId: crypto.randomUUID() }];
      setItems(loadedItems);
      if (loadedData.client_id) {
        getById(clientesModuleConfig.endpoint, loadedData.client_id).then((c) => {
          const exempt = isClientLeyExportacionTdfExempt(c);
          setIsClientTaxExempt(exempt);
          setClientTaxes(getEffectiveClientTaxes(c, c.relatedTaxes));
          setClientTaxCondition(c.tax ?? null);
          if (exempt) {
            setAppliedTaxes([]);
            setFormData((prev) => ({ ...prev, withouttax_amount: 0 }));
          }
        });
      }
    }
  }, [mode, loadedData, navigate]);
  useEffect(() => {
    if (formData.client_id) {
      getById(clientesModuleConfig.endpoint, formData.client_id).then((clientData) => {
        const exempt = isClientLeyExportacionTdfExempt(clientData);
        const newClientTaxes = getEffectiveClientTaxes(clientData, clientData.relatedTaxes);
        setIsClientTaxExempt(exempt);
        setClientTaxes(newClientTaxes);
        setClientTaxCondition(clientData.tax ?? null);
        if (exempt) {
          setAppliedTaxes([]);
          setFormData((prev) => ({ ...prev, withouttax_amount: 0 }));
        }
      }).catch(() => {
        toast.error("No se pudieron cargar los impuestos del cliente.");
        setIsClientTaxExempt(false);
        setClientTaxCondition(null);
        setClientTaxes([]);
      });
    } else {
      setIsClientTaxExempt(false);
      setClientTaxCondition(null);
      setClientTaxes([]);
      setAppliedTaxes([]);
    }
  }, [formData.client_id]);
  const calculatedTotals = useMemo(() => {
    const subtotal = items.reduce((s, i) => s + Number(i.quantity) * Number(i.unit_price), 0);
    const discountAmount = subtotal * (Number(formData.discount_percentage) || 0) / 100;
    const withouttax_amount = isClientTaxExempt ? 0 : formData.withouttax_amount ?? 0;
    const taxBase = Math.max(0, subtotal - discountAmount - withouttax_amount);
    const subtotalAfterDiscount = subtotal - discountAmount;
    const totalTaxes = isClientTaxExempt ? 0 : appliedTaxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
    const total = subtotalAfterDiscount + totalTaxes;
    return { subtotal, discountAmount, withouttax_amount, taxBase, totalTaxes, total };
  }, [items, appliedTaxes, formData.withouttax_amount, formData.discount_percentage, isClientTaxExempt]);
  useEffect(() => {
    if (isClientTaxExempt) {
      setAppliedTaxes([]);
      return;
    }
    if (clientTaxes.length > 0) {
      const { taxBase } = calculatedTotals;
      const newAppliedTaxes = computeSalesAppliedTaxes({
        netBase: taxBase,
        clientTaxCondition,
        taxes: clientTaxes
      });
      setAppliedTaxes(newAppliedTaxes);
    } else {
      setAppliedTaxes([]);
    }
  }, [calculatedTotals.taxBase, clientTaxes, clientTaxCondition, isClientTaxExempt]);
  const handleInvoiceSelected = async (invoice) => {
    try {
      const fullInvoice = await getById(salesInvoicesModuleConfig.endpoint, invoice.id);
      let loadedClientTaxes = [];
      let invoiceClientExempt = false;
      if (fullInvoice.client_id) {
        const client = await getById(clientesModuleConfig.endpoint, fullInvoice.client_id);
        invoiceClientExempt = isClientLeyExportacionTdfExempt(client);
        loadedClientTaxes = getEffectiveClientTaxes(client, client.relatedTaxes);
        setIsClientTaxExempt(invoiceClientExempt);
        setClientTaxCondition(client.tax ?? null);
        setClientTaxes(loadedClientTaxes);
        if (invoiceClientExempt) {
          setAppliedTaxes([]);
        }
      }
      setFormData((prev) => ({
        ...prev,
        sales_invoice_id: fullInvoice.id,
        sales_invoice_number: fullInvoice.invoice_number,
        series: fullInvoice.series,
        // Copiar serie de la factura
        client_id: fullInvoice.client_id,
        client_name: fullInvoice.client?.name,
        client_code: fullInvoice.client?.customer_code || "",
        salesperson_id: fullInvoice.salesperson_id,
        salesperson_name: fullInvoice.salesperson?.name,
        salesperson_code: fullInvoice.salesperson?.code || "",
        buyer_id: fullInvoice.buyer_id,
        buyer_name: fullInvoice.buyer?.name,
        buyer_code: fullInvoice.buyer?.code || "",
        currency_id: fullInvoice.currency_id,
        currency_name: fullInvoice.currency?.name,
        currency_code: fullInvoice.currency?.code || "",
        exchange_rate: Number(fullInvoice.exchange_rate) || 1,
        has_item_level_taxes: false,
        // Siempre false para notas financieras
        withouttax_amount: invoiceClientExempt ? 0 : prev.withouttax_amount
      }));
      toast.success(`Factura cargada. Serie ${fullInvoice.series} copiada.`);
    } catch (error) {
      console.error(error);
      toast.error("Error al cargar los datos de la factura.");
    }
  };
  const handleInvoiceCodeSubmit = async () => {
    const codeValue = formData.sales_invoice_number;
    if (!codeValue) return;
    try {
      const result = await searchByField(
        salesInvoicesModuleConfig.endpoint,
        [{ fieldName: "invoice_number", value: codeValue }]
      );
      if (result) {
        await handleInvoiceSelected(result);
      } else {
        toast.error(`No se encontró ninguna factura con el número "${codeValue}".`);
      }
    } catch (error) {
      console.error(error);
      toast.error("Error al buscar la factura por código.");
    }
  };
  const handleClearInvoice = () => {
    setFormData((prev) => ({
      ...prev,
      sales_invoice_id: null,
      sales_invoice_number: null
    }));
  };
  const handleHeaderChange = (e) => {
    const { name, value } = e.target;
    let finalValue = value;
    if (name === "discount_percentage" || name === "exchange_rate" || name === "withouttax_amount") {
      finalValue = value === "" ? 0 : Number(value) || 0;
    }
    setFormData((prev) => ({ ...prev, [name]: finalValue }));
  };
  const handleAddItem = () => setItems((prev) => [...prev, { ...defaultItem, tempId: crypto.randomUUID() }]);
  const handleRemoveItem = (tempId) => setItems((prev) => prev.length > 1 ? prev.filter((i) => i.tempId !== tempId) : prev);
  const handleUpdateItem = (tempId, field, value) => {
    setItems((prev) => prev.map((i) => i.tempId === tempId ? { ...i, [field]: value } : i));
  };
  const applyHeaderSelection = async (field, selectedItem) => {
    const moduleConfigMap = {
      "client": clientesModuleConfig,
      "salesperson": vendedoresModuleConfig,
      "buyer": compradoresModuleConfig,
      "currency": monedasModuleConfig,
      "sales_invoice": salesInvoicesModuleConfig
    };
    const moduleConfig = moduleConfigMap[field];
    if (!moduleConfig || !moduleConfig.relationalFields) {
      toast.error(`Error: Falta 'relationalFields' en la config de ${field}`);
      return;
    }
    const { codeField, nameField } = moduleConfig.relationalFields;
    if (field === "sales_invoice") {
      await handleInvoiceSelected(selectedItem);
    } else {
      setFormData((prev) => {
        const updated = { ...prev };
        if (field === "client") {
          updated.client_id = selectedItem.id;
          updated.client_code = selectedItem[codeField];
          updated.client_name = selectedItem[nameField];
          if (selectedItem.serie) {
            updated.series = selectedItem.serie;
          }
          if (selectedItem.salesrep) {
            updated.salesperson_id = selectedItem.salesrep;
            updated.salesperson_code = selectedItem.salesRepRelation?.code || null;
            updated.salesperson_name = selectedItem.salesRepRelation?.name || null;
          }
          if (selectedItem.currency_id) {
            updated.currency_id = selectedItem.currency_id;
            updated.currency_code = selectedItem.currency?.code || null;
            updated.currency_name = selectedItem.currency?.name || null;
            updated.exchange_rate = Number(selectedItem.currency?.exchange_rate) || 1;
          }
        } else if (field === "salesperson") {
          updated.salesperson_id = selectedItem.id;
          updated.salesperson_code = selectedItem[codeField];
          updated.salesperson_name = selectedItem[nameField];
        } else if (field === "buyer") {
          updated.buyer_id = selectedItem.id;
          updated.buyer_code = selectedItem[codeField];
          updated.buyer_name = selectedItem[nameField];
        } else if (field === "currency") {
          updated.currency_id = selectedItem.id;
          updated.currency_code = selectedItem[codeField];
          updated.currency_name = selectedItem[nameField];
          updated.exchange_rate = Number(selectedItem.exchange_rate) || 1;
        }
        return updated;
      });
    }
  };
  const handleOpenSearch = (target, config) => {
    setEditingTarget(target);
    setModalConfig(config);
    setIsModalOpen(true);
  };
  const handleSelectFromModal = async (selectedItem) => {
    if (!editingTarget) return;
    await applyHeaderSelection(editingTarget, selectedItem);
    setIsModalOpen(false);
  };
  const handleHeaderCodeChange = (field, newCode) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: newCode,
      [`${field}_name`]: ""
    }));
    if (field === "client") setClientTaxes([]);
  };
  const handleHeaderCodeSubmit = async (field, config) => {
    const codeValue = formData[`${field}_code`];
    if (!codeValue) return;
    if (!config?.relationalFields) return toast.error(`Configuración relacional faltante para ${field}`);
    const { endpoint, relationalFields } = config;
    try {
      const item = await searchByField(endpoint, [{ fieldName: relationalFields.codeField, value: codeValue }]);
      if (item) {
        await applyHeaderSelection(field, item);
        toast.success(`'${item[relationalFields.nameField]}' seleccionado.`);
      } else {
        toast.error(`No se encontró ítem con ese código.`);
      }
    } catch (err) {
      toast.error("Error al buscar por código.");
    }
  };
  const handleHeaderClear = (field) => {
    setFormData((prev) => ({
      ...prev,
      [`${field}_id`]: null,
      [`${field}_code`]: null,
      [`${field}_name`]: null
    }));
    if (field === "client") setClientTaxes([]);
  };
  const handleSave = async () => {
    if (isSaving) return;
    if (!formData.client_id || !formData.currency_id) {
      toast.error("Cliente y Moneda son obligatorios.");
      return;
    }
    if (items.length === 0 || items.some((it) => !it.description?.trim())) {
      toast.error("Cada ítem debe tener descripción.");
      return;
    }
    if (!formData.series) {
      toast.error("La serie es obligatoria.");
      return;
    }
    if (!formData.sales_invoice_id) {
      showConfirmationModal({
        title: "Nota Financiera Independiente",
        message: "Está creando una nota financiera sin factura relacionada. ¿Desea continuar?",
        onConfirm: performSave
      });
      return;
    }
    await performSave();
  };
  const performSave = async () => {
    if (isSaving) return;
    setIsSaving(true);
    const cleanItems = items.map((it, idx) => {
      const { tempId, ...rest } = it;
      return { ...rest, concept_code: "NOTA-FINANCIERA", line_number: idx + 1 };
    });
    const sanitized = isClientTaxExempt ? sanitizeTaxPayloadForExemptClient({
      taxes: appliedTaxes,
      items: cleanItems,
      has_item_level_taxes: false,
      withouttax_amount: formData.withouttax_amount
    }) : null;
    const payload = {
      ...formData,
      concept: formData.concept ?? "",
      items: sanitized?.items ?? cleanItems,
      total_amount: calculatedTotals.total,
      withouttax_amount: sanitized?.withouttax_amount ?? formData.withouttax_amount ?? 0,
      emit_now: true,
      has_item_level_taxes: false,
      taxes: sanitized ? sanitized.taxes : appliedTaxes.filter((t) => Number(t.amount) > 0)
    };
    try {
      const saved = await saveItem(payload);
      if (saved) {
        toast.success("Nota Financiera guardada con éxito.");
        navigate(getListReturnPath(notasFinancierasModuleConfig.baseRoute));
      }
    } catch (e) {
      toast.error(`Error al guardar: ${e.message || "Error desconocido"}`);
    } finally {
      setIsSaving(false);
    }
  };
  if (loadingData) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
    lineNumber: 505,
    columnNumber: 27
  }, this);
  const totalLabelStyle = "text-sm text-gray-700";
  const totalValueStyle = "text-sm font-semibold text-gray-800 text-right";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-6 relative", children: [
    isSaving && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 bg-white/80 rounded-lg flex flex-col items-center justify-center backdrop-blur-[1px] transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-6 bg-white shadow-xl rounded-2xl border border-indigo-100", children: [
      /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-10 h-10 text-indigo-600 animate-spin mb-3" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 515,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-800", children: "Conectando con ARCA" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 516,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 animate-pulse", children: "Obteniendo CAE y validando datos..." }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 517,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 514,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 513,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-900", children: mode === "create" ? "Nueva Nota Financiera" : `Editar Nota #${formData.voucher_number}` }, void 0, false, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 522,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 531,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "type",
              value: formData.type,
              onChange: handleHeaderChange,
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "DEBIT", children: "Nota de Débito" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                  lineNumber: 538,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "CREDIT", children: "Nota de Crédito" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                  lineNumber: 539,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 532,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 530,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Factura Relacionada" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 544,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.sales_invoice_number || "",
              nameValue: formData.sales_invoice_number ? `Factura ${formData.sales_invoice_number}` : "",
              onCodeChange: (c) => setFormData((prev) => ({ ...prev, sales_invoice_number: c })),
              onCodeSubmit: handleInvoiceCodeSubmit,
              onSearchClick: () => handleOpenSearch("sales_invoice", salesInvoicesModuleConfig),
              onClearClick: handleClearInvoice
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 545,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-1 text-xs text-blue-600", children: [
            /* @__PURE__ */ jsxDEV(FaInfoCircle, { className: "mr-1" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 554,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Opcional. Si no se selecciona, se creará una nota independiente." }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 555,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 553,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 543,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Serie (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 560,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "series",
              value: formData.series || "B",
              onChange: handleHeaderChange,
              disabled: !!formData.sales_invoice_id,
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm bg-white disabled:bg-gray-100",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "A", children: "A" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                  lineNumber: 568,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "B", children: "B" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                  lineNumber: 569,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "C", children: "C" }, void 0, false, {
                  fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                  lineNumber: 570,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 561,
              columnNumber: 25
            },
            this
          ),
          formData.sales_invoice_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500", children: "Serie copiada de la factura relacionada" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 573,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 559,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Fecha Emisión (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 578,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              name: "issue_date",
              value: formData.issue_date || "",
              onChange: handleHeaderChange,
              autoComplete: "off",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 579,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 577,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 529,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Cliente (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 592,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.client_code || "",
              nameValue: formData.client_name || "",
              onCodeChange: (c) => handleHeaderCodeChange("client", c),
              onCodeSubmit: () => handleHeaderCodeSubmit("client", clientesModuleConfig),
              onSearchClick: () => handleOpenSearch("client", clientesModuleConfig),
              onClearClick: () => handleHeaderClear("client")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 593,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 591,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Vendedor" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 604,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.salesperson_code || "",
              nameValue: formData.salesperson_name || "",
              onCodeChange: (c) => handleHeaderCodeChange("salesperson", c),
              onCodeSubmit: () => handleHeaderCodeSubmit("salesperson", vendedoresModuleConfig),
              onSearchClick: () => handleOpenSearch("salesperson", vendedoresModuleConfig),
              onClearClick: () => handleHeaderClear("salesperson")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 605,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 603,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Comprador" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 616,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.buyer_code || "",
              nameValue: formData.buyer_name || "",
              onCodeChange: (c) => handleHeaderCodeChange("buyer", c),
              onCodeSubmit: () => handleHeaderCodeSubmit("buyer", compradoresModuleConfig),
              onSearchClick: () => handleOpenSearch("buyer", compradoresModuleConfig),
              onClearClick: () => handleHeaderClear("buyer")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 617,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 615,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 590,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Moneda (*)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 631,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            RelationalInput,
            {
              codeValue: formData.currency_code || "",
              nameValue: formData.currency_name || "",
              onCodeChange: (c) => handleHeaderCodeChange("currency", c),
              onCodeSubmit: () => handleHeaderCodeSubmit("currency", monedasModuleConfig),
              onSearchClick: () => handleOpenSearch("currency", monedasModuleConfig),
              onClearClick: () => handleHeaderClear("currency")
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 632,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 630,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Tipo de Cambio" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 643,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              name: "exchange_rate",
              value: formData.exchange_rate ?? 1,
              emptyWhenZero: false,
              onChange: (num) => setFormData((prev) => ({ ...prev, exchange_rate: num || 1 })),
              step: "0.01",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 644,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 642,
          columnNumber: 21
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Valor no gravado (-)" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 656,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            DecimalInput,
            {
              name: "withouttax_amount",
              value: formData.withouttax_amount,
              onChange: (num) => setFormData((prev) => ({ ...prev, withouttax_amount: num ?? 0 })),
              step: "0.01",
              className: "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm sm:text-sm"
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 657,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 655,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 629,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 527,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-4", children: "Ítems" }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 672,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase", children: "Descripción" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 677,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 678,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 679,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 680,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 w-10" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 681,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 676,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 675,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: items.map(
          (row) => /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: row.description,
                onChange: (e) => handleUpdateItem(row.tempId, "description", e.target.value),
                className: "w-full px-2 py-1 border border-gray-300 rounded text-sm",
                placeholder: "Ej: Intereses por mora en factura #0001-00000123",
                autoComplete: "off"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                lineNumber: 688,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 687,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                min: 0,
                step: "0.01",
                value: row.quantity,
                onChange: (num) => handleUpdateItem(row.tempId, "quantity", num),
                className: "w-20 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                lineNumber: 696,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 695,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsxDEV(
              DecimalInput,
              {
                step: "0.01",
                value: row.unit_price,
                onChange: (num) => handleUpdateItem(row.tempId, "unit_price", num),
                className: "w-32 px-2 py-1 text-right border border-gray-300 rounded text-sm"
              },
              void 0,
              false,
              {
                fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
                lineNumber: 705,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 704,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-sm font-medium", children: formatValue(Number(row.quantity) * Number(row.unit_price), "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 712,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => handleRemoveItem(row.tempId), className: "text-red-500 hover:text-red-700", title: "Quitar ítem", children: /* @__PURE__ */ jsxDEV(FaTrash, {}, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 714,
              columnNumber: 172
            }, this) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 714,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 713,
              columnNumber: 37
            }, this)
          ] }, row.tempId, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 686,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 684,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 674,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 673,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleAddItem, className: "inline-flex items-center px-3 py-2 mt-4 text-sm font-medium text-white bg-gray-600 border border-transparent rounded-md shadow-sm hover:bg-gray-700", children: [
        /* @__PURE__ */ jsxDEV(FaPlus, { className: "w-4 h-4 mr-2" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 722,
          columnNumber: 21
        }, this),
        " Añadir ítem"
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 721,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 671,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Notas" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 729,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 3,
            name: "notes",
            value: formData.notes || "",
            onChange: handleHeaderChange,
            autoComplete: "off",
            className: "mt-1 block w-full border border-gray-300 rounded-md shadow-sm sm:text-sm"
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 730,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 728,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && appliedTaxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 742,
          columnNumber: 29
        }, this),
        appliedTaxes.map(
          (tax, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: formatAppliedTaxTitle(tax) }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 745,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 746,
              columnNumber: 37
            }, this)
          ] }, idx, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 744,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 741,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 739,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 755,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 756,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 754,
          columnNumber: 21
        }, this),
        calculatedTotals.discountAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Descuento:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 760,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.discountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 761,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 759,
          columnNumber: 11
        }, this),
        !isClientTaxExempt && calculatedTotals.withouttax_amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-red-600`, children: "Valor No Gravado:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 766,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} text-red-600`, children: [
            "- ",
            formatValue(calculatedTotals.withouttax_amount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 767,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 765,
          columnNumber: 11
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 773,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 774,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 772,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 777,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 778,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 776,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 771,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-900", children: "Total:" }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 783,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-indigo-600", children: formatValue(calculatedTotals.total, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 784,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 782,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 753,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 727,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => navigate(getListReturnPath(notasFinancierasModuleConfig.baseRoute)),
          className: "px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",
          children: "Cancelar"
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 791,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: isSaving,
          className: `inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white disabled:opacity-50 ${isSaving ? "bg-indigo-500 cursor-wait" : "bg-indigo-600 hover:bg-indigo-700"}`,
          children: isSaving ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin w-5 h-5 mr-2" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 806,
              columnNumber: 29
            }, this),
            "Procesando en ARCA..."
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 805,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(FaSave, { className: "mr-2" }, void 0, false, {
              fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
              lineNumber: 811,
              columnNumber: 29
            }, this),
            " Guardar Nota"
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
            lineNumber: 810,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
          lineNumber: 798,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
      lineNumber: 790,
      columnNumber: 13
    }, this),
    isModalOpen && modalConfig && /* @__PURE__ */ jsxDEV(
      SearchModal,
      {
        isOpen: isModalOpen,
        onClose: () => setIsModalOpen(false),
        onSelect: handleSelectFromModal,
        config: modalConfig
      },
      void 0,
      false,
      {
        fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
        lineNumber: 819,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx",
    lineNumber: 511,
    columnNumber: 5
  }, this);
};
_s(NotasFinancierasFormPage, "TCocF9HvXap8qLT5Fi0Aj5WBNMQ=", false, function() {
  return [useParams, useNavigate, useModal, useCrudItem];
});
_c = NotasFinancierasFormPage;
var _c;
$RefreshReg$(_c, "NotasFinancierasFormPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_financieras/pages/NotasFinancierasFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcWU0QixTQTBRSixVQTFRSTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuZTVCLFNBQVNBLFVBQVVDLFdBQVdDLGVBQWU7QUFDN0MsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsV0FBV0MsY0FBY0MsUUFBUUMsZUFBZTtBQUNqRSxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsU0FBU0MscUJBQXFCO0FBQ3ZDLFNBQVNDLG9DQUFnRjtBQUN6RixTQUFTQyxpQ0FBb0Q7QUFDN0QsU0FBU0MsNEJBQTBDO0FBQ25ELFNBQVNDLDhCQUE4QjtBQUN2QyxTQUFTQywrQkFBK0I7QUFDeEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDZCQUE2QjtBQUV0QyxlQUE4RDtBQUM5RDtBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0c7QUFDUCxTQUFTQyxnQ0FBZ0M7QUFDekMsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLHFCQUE2QztBQUFBLEVBQy9DQyxJQUFJO0FBQUEsRUFDSkMsTUFBTTtBQUFBLEVBQ05DLFFBQVE7QUFBQSxFQUNSQyxhQUFZLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pEQyxjQUFjO0FBQUEsRUFDZEMsZUFBZTtBQUFBLEVBQ2ZDLHFCQUFxQjtBQUFBLEVBQ3JCQyxtQkFBbUI7QUFBQSxFQUNuQkMsU0FBUztBQUFBLEVBQ1RDLE9BQU87QUFBQSxFQUNQQyxzQkFBc0I7QUFBQSxFQUN0QkMsVUFBVTtBQUFBO0FBQUEsRUFDVkMsV0FBVztBQUFBLEVBQ1hDLGdCQUFnQjtBQUFBLEVBQ2hCQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLGtCQUFrQjtBQUFBLEVBQ2xCQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUNYO0FBRUEsTUFBTUMsY0FBaUM7QUFBQSxFQUNuQ0MsYUFBYTtBQUFBLEVBQ2JDLGFBQWE7QUFBQSxFQUNiQyxjQUFjO0FBQUEsRUFDZEMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNabEIscUJBQXFCO0FBQUEsRUFDckJZLE9BQU87QUFDWDtBQUlPLGFBQU1PLDJCQUEyQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFDLFFBQU0sRUFBRTdCLEdBQUcsSUFBSTdCLFVBQTBCO0FBQ3pDLFFBQU0yRCxXQUFXNUQsWUFBWTtBQUM3QixRQUFNNkQsT0FBTy9CLEtBQUssU0FBUztBQUMzQixRQUFNLEVBQUVnQyxzQkFBc0IsSUFBSXpDLFNBQVM7QUFFM0MsUUFBTSxFQUFFMEMsTUFBTUMsWUFBWUMsU0FBU0MsYUFBYUMsU0FBUyxJQUFJM0QsWUFBMkJHLDhCQUE4Qm1CLEVBQUU7QUFHeEgsUUFBTSxDQUFDc0MsVUFBVUMsV0FBVyxJQUFJeEUsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQ3lFLFVBQVVDLFdBQVcsSUFBSTFFLFNBQWlDZ0Msa0JBQWtCO0FBQ25GLFFBQU0sQ0FBQ3FCLE9BQU9zQixRQUFRLElBQUkzRSxTQUFxQixNQUFNLENBQUMsRUFBRSxHQUFHdUQsYUFBYXFCLFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDdEcsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUloRixTQUFzQixFQUFFO0FBQzlELFFBQU0sQ0FBQ2lGLG9CQUFvQkMscUJBQXFCLElBQUlsRixTQUF3QixJQUFJO0FBQ2hGLFFBQU0sQ0FBQ21GLG1CQUFtQkMsb0JBQW9CLElBQUlwRixTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDcUYsY0FBY0MsZUFBZSxJQUFJdEYsU0FBdUIsRUFBRTtBQUdqRSxRQUFNLENBQUN1RixhQUFhQyxjQUFjLElBQUl4RixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDeUYsYUFBYUMsY0FBYyxJQUFJMUYsU0FBbUMsSUFBSTtBQUM3RSxRQUFNLENBQUMyRixlQUFlQyxnQkFBZ0IsSUFBSTVGLFNBQXdCLElBQUk7QUFHdEVDLFlBQVUsTUFBTTtBQUNaLFFBQUkrRCxTQUFTLFVBQVVHLFlBQVk7QUFFL0IsVUFBSUEsV0FBVzBCLFlBQVk7QUFDdkJ4RixjQUFNeUYsTUFBTSwwREFBMEQ7QUFDdEUvQixpQkFBU2hDLGtCQUFrQmpCLDZCQUE2QmlGLFNBQVMsQ0FBQztBQUNsRTtBQUFBLE1BQ0o7QUFFQSxZQUFNQyxXQUFXO0FBQUEsUUFDYixHQUFHaEU7QUFBQUEsUUFDSCxHQUFHbUM7QUFBQUEsUUFDSDhCLGFBQWM5QixXQUFXK0IsUUFBZ0JDLGlCQUFpQjtBQUFBLFFBQzFEQyxhQUFhakMsV0FBVytCLFFBQVFHLFFBQVE7QUFBQSxRQUN4Q0Msa0JBQW1CbkMsV0FBV29DLGFBQXFCQyxRQUFRO0FBQUEsUUFDM0RDLGtCQUFrQnRDLFdBQVdvQyxhQUFhRixRQUFRO0FBQUEsUUFDbERLLFlBQWF2QyxXQUFXd0MsT0FBZUgsUUFBUTtBQUFBLFFBQy9DSSxZQUFZekMsV0FBV3dDLE9BQU9OLFFBQVE7QUFBQSxRQUN0Q1EsZUFBZ0IxQyxXQUFXMkMsVUFBa0JOLFFBQVE7QUFBQSxRQUNyRE8sZUFBZTVDLFdBQVcyQyxVQUFVVCxRQUFRO0FBQUEsUUFDNUNXLHNCQUFzQjdDLFdBQVc4QyxlQUFlQyxrQkFBa0I7QUFBQSxNQUN0RTtBQUNBeEMsa0JBQVlzQixRQUFRO0FBQ3BCLFlBQU1tQixlQUFlbkIsU0FBUzNDLFNBQVMsSUFBSStELFVBQ3BDcEIsU0FBUzNDLFNBQVMsSUFBSWdFLElBQUksQ0FBQ0MsUUFBMkIsRUFBRSxHQUFHQSxJQUFJNUQsY0FBYzRELEdBQUc1RCxnQkFBZ0IsbUJBQW1CQyxVQUFVMkQsR0FBRzNELFlBQVksR0FBR2lCLFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxFQUFjLElBQzFMLENBQUMsRUFBRSxHQUFHdkIsYUFBYXFCLFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDO0FBQ3RESCxlQUFTd0MsV0FBVztBQUVwQixVQUFJaEQsV0FBV25CLFdBQVc7QUFDdEJwQyxnQkFBaUJJLHFCQUFxQnVHLFVBQVVwRCxXQUFXbkIsU0FBUyxFQUMvRHdFLEtBQUssQ0FBQUMsTUFBSztBQUNQLGdCQUFNQyxTQUFTOUYsZ0NBQWdDNkYsQ0FBQztBQUNoRHJDLCtCQUFxQnNDLE1BQU07QUFDM0IxQyx5QkFBZXJELHdCQUF3QjhGLEdBQUdBLEVBQUVFLFlBQVksQ0FBQztBQUN6RHpDLGdDQUFzQnVDLEVBQUVHLE9BQU8sSUFBSTtBQUNuQyxjQUFJRixRQUFRO0FBQ1JwQyw0QkFBZ0IsRUFBRTtBQUNsQlosd0JBQVksQ0FBQW1ELFVBQVMsRUFBRSxHQUFHQSxNQUFNbEYsbUJBQW1CLEVBQUUsRUFBRTtBQUFBLFVBQzNEO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDVDtBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsQ0FBQ3FCLE1BQU1HLFlBQVlKLFFBQVEsQ0FBQztBQUcvQjlELFlBQVUsTUFBTTtBQUNaLFFBQUl3RSxTQUFTekIsV0FBVztBQUNwQnBDLGNBQWlCSSxxQkFBcUJ1RyxVQUFVOUMsU0FBU3pCLFNBQVMsRUFDN0R3RSxLQUFLLENBQUFNLGVBQWM7QUFDaEIsY0FBTUosU0FBUzlGLGdDQUFnQ2tHLFVBQVU7QUFDekQsY0FBTUMsaUJBQWlCcEcsd0JBQXdCbUcsWUFBWUEsV0FBV0gsWUFBWTtBQUNsRnZDLDZCQUFxQnNDLE1BQU07QUFDM0IxQyx1QkFBZStDLGNBQWM7QUFDN0I3Qyw4QkFBc0I0QyxXQUFXRixPQUFPLElBQUk7QUFDNUMsWUFBSUYsUUFBUTtBQUNScEMsMEJBQWdCLEVBQUU7QUFDbEJaLHNCQUFZLENBQUFtRCxVQUFTLEVBQUUsR0FBR0EsTUFBTWxGLG1CQUFtQixFQUFFLEVBQUU7QUFBQSxRQUMzRDtBQUFBLE1BQ0osQ0FBQyxFQUNBcUYsTUFBTSxNQUFNO0FBQ1QzSCxjQUFNeUYsTUFBTSxrREFBa0Q7QUFDOURWLDZCQUFxQixLQUFLO0FBQzFCRiw4QkFBc0IsSUFBSTtBQUMxQkYsdUJBQWUsRUFBRTtBQUFBLE1BQ3JCLENBQUM7QUFBQSxJQUNULE9BQU87QUFDSEksMkJBQXFCLEtBQUs7QUFDMUJGLDRCQUFzQixJQUFJO0FBQzFCRixxQkFBZSxFQUFFO0FBQ2pCTSxzQkFBZ0IsRUFBRTtBQUFBLElBQ3RCO0FBQUEsRUFDSixHQUFHLENBQUNiLFNBQVN6QixTQUFTLENBQUM7QUFHdkIsUUFBTWlGLG1CQUFtQi9ILFFBQVEsTUFBTTtBQUNuQyxVQUFNZ0ksV0FBVzdFLE1BQU04RSxPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlFLE9BQU9ELEVBQUUxRSxRQUFRLElBQUkyRSxPQUFPRCxFQUFFekUsVUFBVSxHQUFHLENBQUM7QUFDeEYsVUFBTTJFLGlCQUFpQkwsWUFBWUksT0FBTzdELFNBQVMvQixtQkFBbUIsS0FBSyxLQUFLO0FBQ2hGLFVBQU1DLG9CQUFvQndDLG9CQUFvQixJQUFLVixTQUFTOUIscUJBQXFCO0FBQ2pGLFVBQU02RixVQUFVQyxLQUFLQyxJQUFJLEdBQUdSLFdBQVdLLGlCQUFpQjVGLGlCQUFpQjtBQUN6RSxVQUFNZ0csd0JBQXdCVCxXQUFXSztBQUV6QyxVQUFNSyxhQUFhekQsb0JBQ2IsSUFDQUUsYUFBYThDLE9BQU8sQ0FBQ1UsS0FBS2pCLFFBQVFpQixNQUFNUCxPQUFPVixJQUFJa0IsTUFBTSxHQUFHLENBQUM7QUFDbkUsVUFBTUMsUUFBUUosd0JBQXdCQztBQUN0QyxXQUFPLEVBQUVWLFVBQVVLLGdCQUFnQjVGLG1CQUFtQjZGLFNBQVNJLFlBQVlHLE1BQU07QUFBQSxFQUNyRixHQUFHLENBQUMxRixPQUFPZ0MsY0FBY1osU0FBUzlCLG1CQUFtQjhCLFNBQVMvQixxQkFBcUJ5QyxpQkFBaUIsQ0FBQztBQUdyR2xGLFlBQVUsTUFBTTtBQUNaLFFBQUlrRixtQkFBbUI7QUFDbkJHLHNCQUFnQixFQUFFO0FBQ2xCO0FBQUEsSUFDSjtBQUVBLFFBQUlQLFlBQVlxQyxTQUFTLEdBQUc7QUFDeEIsWUFBTSxFQUFFb0IsUUFBUSxJQUFJUDtBQUNwQixZQUFNZSxrQkFBa0JsSCx5QkFBeUI7QUFBQSxRQUM3Q21ILFNBQVNUO0FBQUFBLFFBQ1R2RDtBQUFBQSxRQUNBM0IsT0FBT3lCO0FBQUFBLE1BQ1gsQ0FBQztBQUNETyxzQkFBZ0IwRCxlQUFlO0FBQUEsSUFDbkMsT0FBTztBQUNIMUQsc0JBQWdCLEVBQUU7QUFBQSxJQUN0QjtBQUFBLEVBQ0osR0FBRyxDQUFDMkMsaUJBQWlCTyxTQUFTekQsYUFBYUUsb0JBQW9CRSxpQkFBaUIsQ0FBQztBQUdqRixRQUFNK0Qsd0JBQXdCLE9BQU9DLFlBQTBCO0FBQzNELFFBQUk7QUFDQSxZQUFNQyxjQUFjLE1BQU14SSxRQUFzQkcsMEJBQTBCd0csVUFBVTRCLFFBQVFsSCxFQUFFO0FBRTlGLFVBQUlvSCxvQkFBaUM7QUFDckMsVUFBSUMsc0JBQXNCO0FBQzFCLFVBQUlGLFlBQVlwRyxXQUFXO0FBQ3ZCLGNBQU1rRCxTQUFTLE1BQU10RixRQUFpQkkscUJBQXFCdUcsVUFBVTZCLFlBQVlwRyxTQUFTO0FBQzFGc0csOEJBQXNCMUgsZ0NBQWdDc0UsTUFBTTtBQUM1RG1ELDRCQUFvQjFILHdCQUF3QnVFLFFBQVFBLE9BQU95QixZQUFZO0FBQ3ZFdkMsNkJBQXFCa0UsbUJBQW1CO0FBQ3hDcEUsOEJBQXNCZ0IsT0FBTzBCLE9BQU8sSUFBSTtBQUN4QzVDLHVCQUFlcUUsaUJBQWlCO0FBQ2hDLFlBQUlDLHFCQUFxQjtBQUNyQmhFLDBCQUFnQixFQUFFO0FBQUEsUUFDdEI7QUFBQSxNQUNKO0FBRUFaLGtCQUFZLENBQUFtRCxVQUFTO0FBQUEsUUFDakIsR0FBR0E7QUFBQUEsUUFDSHpFLGtCQUFrQmdHLFlBQVluSDtBQUFBQSxRQUM5QitFLHNCQUFzQm9DLFlBQVlsQztBQUFBQSxRQUNsQy9FLFFBQVFpSCxZQUFZakg7QUFBQUE7QUFBQUEsUUFDcEJhLFdBQVdvRyxZQUFZcEc7QUFBQUEsUUFDdkJvRCxhQUFhZ0QsWUFBWWxELFFBQVFHO0FBQUFBLFFBQ2pDSixhQUFjbUQsWUFBWWxELFFBQWdCQyxpQkFBaUI7QUFBQSxRQUMzRGxELGdCQUFnQm1HLFlBQVluRztBQUFBQSxRQUM1QndELGtCQUFrQjJDLFlBQVk3QyxhQUFhRjtBQUFBQSxRQUMzQ0Msa0JBQW1COEMsWUFBWTdDLGFBQXFCQyxRQUFRO0FBQUEsUUFDNUR0RCxVQUFVa0csWUFBWWxHO0FBQUFBLFFBQ3RCMEQsWUFBWXdDLFlBQVl6QyxPQUFPTjtBQUFBQSxRQUMvQkssWUFBYTBDLFlBQVl6QyxPQUFlSCxRQUFRO0FBQUEsUUFDaERyRCxhQUFhaUcsWUFBWWpHO0FBQUFBLFFBQ3pCNEQsZUFBZXFDLFlBQVl0QyxVQUFVVDtBQUFBQSxRQUNyQ1EsZUFBZ0J1QyxZQUFZdEMsVUFBa0JOLFFBQVE7QUFBQSxRQUN0RC9ELGVBQWU2RixPQUFPYyxZQUFZM0csYUFBYSxLQUFLO0FBQUEsUUFDcERLLHNCQUFzQjtBQUFBO0FBQUEsUUFDdEJILG1CQUFtQjJHLHNCQUFzQixJQUFJekIsS0FBS2xGO0FBQUFBLE1BQ3RELEVBQUU7QUFFRnRDLFlBQU1rSixRQUFRLDBCQUEwQkgsWUFBWWpILE1BQU0sV0FBVztBQUFBLElBQ3pFLFNBQVMyRCxPQUFPO0FBQ1owRCxjQUFRMUQsTUFBTUEsS0FBSztBQUNuQnpGLFlBQU15RixNQUFNLDBDQUEwQztBQUFBLElBQzFEO0FBQUEsRUFDSjtBQUVBLFFBQU0yRCwwQkFBMEIsWUFBWTtBQUN4QyxVQUFNQyxZQUFZakYsU0FBU3VDO0FBQzNCLFFBQUksQ0FBQzBDLFVBQVc7QUFFaEIsUUFBSTtBQUNBLFlBQU1DLFNBQVMsTUFBTTlJO0FBQUFBLFFBQ2pCRSwwQkFBMEJ3RztBQUFBQSxRQUMxQixDQUFDLEVBQUVxQyxXQUFXLGtCQUFrQkMsT0FBT0gsVUFBVSxDQUFDO0FBQUEsTUFDdEQ7QUFFQSxVQUFJQyxRQUFRO0FBQ1IsY0FBTVQsc0JBQXNCUyxNQUFNO0FBQUEsTUFDdEMsT0FBTztBQUNIdEosY0FBTXlGLE1BQU0saURBQWlENEQsU0FBUyxJQUFJO0FBQUEsTUFDOUU7QUFBQSxJQUNKLFNBQVM1RCxPQUFPO0FBQ1owRCxjQUFRMUQsTUFBTUEsS0FBSztBQUNuQnpGLFlBQU15RixNQUFNLHdDQUF3QztBQUFBLElBQ3hEO0FBQUEsRUFDSjtBQUdBLFFBQU1nRSxxQkFBcUJBLE1BQU07QUFDN0JwRixnQkFBWSxDQUFBbUQsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0h6RSxrQkFBa0I7QUFBQSxNQUNsQjRELHNCQUFzQjtBQUFBLElBQzFCLEVBQUU7QUFBQSxFQUNOO0FBR0EsUUFBTStDLHFCQUFxQkEsQ0FBQ0MsTUFBcUY7QUFDN0csVUFBTSxFQUFFM0QsTUFBTXdELE1BQU0sSUFBSUcsRUFBRUM7QUFDMUIsUUFBSUMsYUFBa0JMO0FBQ3RCLFFBQUl4RCxTQUFTLHlCQUF5QkEsU0FBUyxtQkFBbUJBLFNBQVMscUJBQXFCO0FBQzVGNkQsbUJBQWFMLFVBQVUsS0FBSyxJQUFJdkIsT0FBT3VCLEtBQUssS0FBSztBQUFBLElBQ3JEO0FBQ0FuRixnQkFBWSxDQUFBbUQsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3hCLElBQUksR0FBRzZELFdBQVcsRUFBRTtBQUFBLEVBQ3pEO0FBRUEsUUFBTUMsZ0JBQWdCQSxNQUFNeEYsU0FBUyxDQUFBa0QsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRSxHQUFHdEUsYUFBYXFCLFFBQVFDLE9BQU9DLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDdkcsUUFBTXNGLG1CQUFtQkEsQ0FBQ3hGLFdBQW1CRCxTQUFTLENBQUFrRCxTQUFTQSxLQUFLVCxTQUFTLElBQUlTLEtBQUt3QyxPQUFPLENBQUFoQyxNQUFLQSxFQUFFekQsV0FBV0EsTUFBTSxJQUFJaUQsSUFBSztBQUM5SCxRQUFNeUMsbUJBQW1CQSxDQUFDMUYsUUFBZ0IyRixPQUFnQ1YsVUFBMkI7QUFDakdsRixhQUFTLENBQUFrRCxTQUFRQSxLQUFLUixJQUFJLENBQUFnQixNQUFNQSxFQUFFekQsV0FBV0EsU0FBUyxFQUFFLEdBQUd5RCxHQUFHLENBQUNrQyxLQUFLLEdBQUdWLE1BQU0sSUFBSXhCLENBQUUsQ0FBQztBQUFBLEVBQ3hGO0FBR0EsUUFBTW1DLHVCQUF1QixPQUFPRCxPQUFlRSxpQkFBc0I7QUFDckUsVUFBTUMsa0JBQXFEO0FBQUEsTUFDdkQsVUFBVTFKO0FBQUFBLE1BQ1YsZUFBZUM7QUFBQUEsTUFDZixTQUFTQztBQUFBQSxNQUNULFlBQVlDO0FBQUFBLE1BQ1osaUJBQWlCSjtBQUFBQSxJQUNyQjtBQUVBLFVBQU00SixlQUFlRCxnQkFBZ0JILEtBQUs7QUFDMUMsUUFBSSxDQUFDSSxnQkFBZ0IsQ0FBQ0EsYUFBYUMsa0JBQWtCO0FBQ2pEdkssWUFBTXlGLE1BQU0sbURBQW1EeUUsS0FBSyxFQUFFO0FBQ3RFO0FBQUEsSUFDSjtBQUVBLFVBQU0sRUFBRU0sV0FBV0MsVUFBVSxJQUFJSCxhQUFhQztBQUU5QyxRQUFJTCxVQUFVLGlCQUFpQjtBQUMzQixZQUFNckIsc0JBQXNCdUIsWUFBWTtBQUFBLElBQzVDLE9BQU87QUFDSC9GLGtCQUFZLENBQUFtRCxTQUFRO0FBQ2hCLGNBQU1rRCxVQUFrQyxFQUFFLEdBQUdsRCxLQUFLO0FBR2xELFlBQUkwQyxVQUFVLFVBQVU7QUFDcEJRLGtCQUFRL0gsWUFBWXlILGFBQWF4STtBQUNqQzhJLGtCQUFROUUsY0FBY3dFLGFBQWFJLFNBQW1CO0FBQ3RERSxrQkFBUTNFLGNBQWNxRSxhQUFhSyxTQUFtQjtBQUV0RCxjQUFJTCxhQUFhTyxPQUFPO0FBQ3BCRCxvQkFBUTVJLFNBQVNzSSxhQUFhTztBQUFBQSxVQUNsQztBQUVBLGNBQUlQLGFBQWFRLFVBQVU7QUFDdkJGLG9CQUFROUgsaUJBQWlCd0gsYUFBYVE7QUFDdENGLG9CQUFRekUsbUJBQW9CbUUsYUFBYVMsa0JBQTBCMUUsUUFBUTtBQUMzRXVFLG9CQUFRdEUsbUJBQW9CZ0UsYUFBYVMsa0JBQTBCN0UsUUFBUTtBQUFBLFVBQy9FO0FBRUEsY0FBSW9FLGFBQWF0SCxhQUFhO0FBQzFCNEgsb0JBQVE1SCxjQUFjc0gsYUFBYXRIO0FBQ25DNEgsb0JBQVFsRSxnQkFBaUI0RCxhQUFhM0QsVUFBa0JOLFFBQVE7QUFDaEV1RSxvQkFBUWhFLGdCQUFpQjBELGFBQWEzRCxVQUFrQlQsUUFBUTtBQUNoRTBFLG9CQUFRdEksZ0JBQWdCNkYsT0FBUW1DLGFBQWEzRCxVQUFrQnJFLGFBQWEsS0FBSztBQUFBLFVBQ3JGO0FBQUEsUUFDSixXQUFXOEgsVUFBVSxlQUFlO0FBQ2hDUSxrQkFBUTlILGlCQUFpQndILGFBQWF4STtBQUN0QzhJLGtCQUFRekUsbUJBQW1CbUUsYUFBYUksU0FBbUI7QUFDM0RFLGtCQUFRdEUsbUJBQW1CZ0UsYUFBYUssU0FBbUI7QUFBQSxRQUMvRCxXQUFXUCxVQUFVLFNBQVM7QUFDMUJRLGtCQUFRN0gsV0FBV3VILGFBQWF4STtBQUNoQzhJLGtCQUFRckUsYUFBYStELGFBQWFJLFNBQW1CO0FBQ3JERSxrQkFBUW5FLGFBQWE2RCxhQUFhSyxTQUFtQjtBQUFBLFFBQ3pELFdBQVdQLFVBQVUsWUFBWTtBQUM3QlEsa0JBQVE1SCxjQUFjc0gsYUFBYXhJO0FBQ25DOEksa0JBQVFsRSxnQkFBZ0I0RCxhQUFhSSxTQUFtQjtBQUN4REUsa0JBQVFoRSxnQkFBZ0IwRCxhQUFhSyxTQUFtQjtBQUN4REMsa0JBQVF0SSxnQkFBZ0I2RixPQUFPbUMsYUFBYWhJLGFBQWEsS0FBSztBQUFBLFFBQ2xFO0FBRUEsZUFBT3NJO0FBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKO0FBR0EsUUFBTUksbUJBQW1CQSxDQUFDbEIsUUFBZ0JtQixXQUE4QjtBQUNwRXhGLHFCQUFpQnFFLE1BQU07QUFDdkJ2RSxtQkFBZTBGLE1BQU07QUFDckI1RixtQkFBZSxJQUFJO0FBQUEsRUFDdkI7QUFHQSxRQUFNNkYsd0JBQXdCLE9BQU9aLGlCQUFzQjtBQUN2RCxRQUFJLENBQUM5RSxjQUFlO0FBQ3BCLFVBQU02RSxxQkFBcUI3RSxlQUFlOEUsWUFBWTtBQUN0RGpGLG1CQUFlLEtBQUs7QUFBQSxFQUN4QjtBQUdBLFFBQU04Rix5QkFBeUJBLENBQUNmLE9BQWVnQixZQUFvQjtBQUMvRDdHLGdCQUFZLENBQUFtRCxVQUFTO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDLEdBQUcwQyxLQUFLLEtBQUssR0FBRztBQUFBLE1BQ2pCLENBQUMsR0FBR0EsS0FBSyxPQUFPLEdBQUdnQjtBQUFBQSxNQUNuQixDQUFDLEdBQUdoQixLQUFLLE9BQU8sR0FBRztBQUFBLElBQ3ZCLEVBQUU7QUFDRixRQUFJQSxVQUFVLFNBQVV2RixnQkFBZSxFQUFFO0FBQUEsRUFDN0M7QUFFQSxRQUFNd0cseUJBQXlCLE9BQU9qQixPQUFlYSxXQUE4QjtBQUMvRSxVQUFNMUIsWUFBWWpGLFNBQVMsR0FBRzhGLEtBQUssT0FBOEI7QUFDakUsUUFBSSxDQUFDYixVQUFXO0FBQ2hCLFFBQUksQ0FBQzBCLFFBQVFSLGlCQUFrQixRQUFPdkssTUFBTXlGLE1BQU0sMENBQTBDeUUsS0FBSyxFQUFFO0FBRW5HLFVBQU0sRUFBRWhELFVBQVVxRCxpQkFBaUIsSUFBSVE7QUFDdkMsUUFBSTtBQUNBLFlBQU1sSCxPQUFPLE1BQU1yRCxjQUFtQjBHLFVBQVUsQ0FBQyxFQUFFcUMsV0FBV2dCLGlCQUFpQkMsV0FBcUJoQixPQUFPSCxVQUFVLENBQUMsQ0FBQztBQUN2SCxVQUFJeEYsTUFBTTtBQUNOLGNBQU1zRyxxQkFBcUJELE9BQU9yRyxJQUFJO0FBQ3RDN0QsY0FBTWtKLFFBQVEsSUFBSXJGLEtBQUswRyxpQkFBaUJFLFNBQW1CLENBQUMsaUJBQWlCO0FBQUEsTUFDakYsT0FBTztBQUNIekssY0FBTXlGLE1BQU0scUNBQXFDO0FBQUEsTUFDckQ7QUFBQSxJQUNKLFNBQVMyRixLQUFLO0FBQ1ZwTCxZQUFNeUYsTUFBTSw2QkFBNkI7QUFBQSxJQUM3QztBQUFBLEVBQ0o7QUFFQSxRQUFNNEYsb0JBQW9CQSxDQUFDbkIsVUFBa0I7QUFDekM3RixnQkFBWSxDQUFBbUQsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQyxHQUFHMEMsS0FBSyxLQUFLLEdBQUc7QUFBQSxNQUNqQixDQUFDLEdBQUdBLEtBQUssT0FBTyxHQUFHO0FBQUEsTUFDbkIsQ0FBQyxHQUFHQSxLQUFLLE9BQU8sR0FBRztBQUFBLElBQ3ZCLEVBQUU7QUFDRixRQUFJQSxVQUFVLFNBQVV2RixnQkFBZSxFQUFFO0FBQUEsRUFDN0M7QUFPQSxRQUFNMkcsYUFBYSxZQUFZO0FBQzNCLFFBQUlwSCxTQUFVO0FBRWQsUUFBSSxDQUFDRSxTQUFTekIsYUFBYSxDQUFDeUIsU0FBU3RCLGFBQWE7QUFDOUM5QyxZQUFNeUYsTUFBTSxvQ0FBb0M7QUFDaEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSXpDLE1BQU0rRCxXQUFXLEtBQUsvRCxNQUFNdUksS0FBSyxDQUFBdEUsT0FBTSxDQUFDQSxHQUFHN0QsYUFBYW9JLEtBQUssQ0FBQyxHQUFHO0FBQ2pFeEwsWUFBTXlGLE1BQU0sbUNBQW1DO0FBQy9DO0FBQUEsSUFDSjtBQUNBLFFBQUksQ0FBQ3JCLFNBQVN0QyxRQUFRO0FBQ2xCOUIsWUFBTXlGLE1BQU0sMEJBQTBCO0FBQ3RDO0FBQUEsSUFDSjtBQUdBLFFBQUksQ0FBQ3JCLFNBQVNyQixrQkFBa0I7QUFDNUJhLDRCQUFzQjtBQUFBLFFBQ2xCNkgsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxXQUFXQztBQUFBQSxNQUNmLENBQUM7QUFDRDtBQUFBLElBQ0o7QUFFQSxVQUFNQSxZQUFZO0FBQUEsRUFDdEI7QUFFQSxRQUFNQSxjQUFjLFlBQVk7QUFDNUIsUUFBSTFILFNBQVU7QUFFZEMsZ0JBQVksSUFBSTtBQUNoQixVQUFNMEgsYUFBYTdJLE1BQU1nRSxJQUFJLENBQUNDLElBQUk2RSxRQUFRO0FBQ3RDLFlBQU0sRUFBRXZILFFBQVEsR0FBR3dILEtBQUssSUFBSTlFO0FBQzVCLGFBQU8sRUFBRSxHQUFHOEUsTUFBTTFJLGNBQWMsbUJBQW1CRixhQUFhMkksTUFBTSxFQUFFO0FBQUEsSUFDNUUsQ0FBQztBQUNELFVBQU1FLFlBQVlsSCxvQkFDWnRELGtDQUFrQztBQUFBLE1BQ2hDeUIsT0FBTytCO0FBQUFBLE1BQ1BoQyxPQUFPNkk7QUFBQUEsTUFDUHBKLHNCQUFzQjtBQUFBLE1BQ3RCSCxtQkFBbUI4QixTQUFTOUI7QUFBQUEsSUFDaEMsQ0FBQyxJQUNDO0FBRU4sVUFBTTJKLFVBQXlCO0FBQUEsTUFDM0IsR0FBSTdIO0FBQUFBLE1BQ0o3QixTQUFVNkIsU0FBMkI3QixXQUFXO0FBQUEsTUFDaERTLE9BQU9nSixXQUFXaEosU0FBUzZJO0FBQUFBLE1BQzNCMUosY0FBY3lGLGlCQUFpQmM7QUFBQUEsTUFDL0JwRyxtQkFBbUIwSixXQUFXMUoscUJBQXNCOEIsU0FBUzlCLHFCQUFxQjtBQUFBLE1BQ2xGSSxVQUFVO0FBQUEsTUFDVkQsc0JBQXNCO0FBQUEsTUFDdEJRLE9BQU8rSSxZQUFZQSxVQUFVL0ksUUFBUStCLGFBQWFnRixPQUFPLENBQUFrQyxNQUFLakUsT0FBT2lFLEVBQUV6RCxNQUFNLElBQUksQ0FBQztBQUFBLElBQ3RGO0FBRUEsUUFBSTtBQUNBLFlBQU0wRCxRQUFRLE1BQU1sSSxTQUFTZ0ksT0FBTztBQUNwQyxVQUFJRSxPQUFPO0FBQ1BuTSxjQUFNa0osUUFBUSxxQ0FBcUM7QUFDbkR4RixpQkFBU2hDLGtCQUFrQmpCLDZCQUE2QmlGLFNBQVMsQ0FBQztBQUFBLE1BQ3RFO0FBQUEsSUFDSixTQUFTaUUsR0FBUTtBQUNiM0osWUFBTXlGLE1BQU0scUJBQXFCa0UsRUFBRStCLFdBQVcsbUJBQW1CLEVBQUU7QUFBQSxJQUN2RSxVQUFDO0FBQ0d2SCxrQkFBWSxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNKO0FBRUEsTUFBSUgsWUFBYSxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUV2QyxRQUFNb0ksa0JBQWtCO0FBQ3hCLFFBQU1DLGtCQUFrQjtBQUV4QixTQUNJLHVCQUFDLFNBQUksV0FBVSwrREFDVm5JO0FBQUFBLGdCQUNHLHVCQUFDLFNBQUksV0FBVSwwSUFDWCxpQ0FBQyxTQUFJLFdBQVUsMEZBQ1g7QUFBQSw2QkFBQyxhQUFVLFdBQVUsaURBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxNQUNsRSx1QkFBQyxRQUFHLFdBQVUsbUNBQWtDLG1DQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFDbkUsdUJBQUMsT0FBRSxXQUFVLHVDQUFzQyxtREFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRjtBQUFBLFNBSDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBR0osdUJBQUMsUUFBRyxXQUFVLHVDQUNUUCxtQkFBUyxXQUFXLDBCQUEwQixnQkFBZ0JTLFNBQVNrSSxjQUFjLE1BRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUVYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE9BQU9sSSxTQUFTdkM7QUFBQUEsY0FDaEIsVUFBVTZIO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sU0FBUSw4QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQSxnQkFDcEMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsK0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUE7QUFBQTtBQUFBLFlBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLG1DQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXdEYsU0FBU3VDLHdCQUF3QjtBQUFBLGNBQzVDLFdBQVd2QyxTQUFTdUMsdUJBQXVCLFdBQVd2QyxTQUFTdUMsb0JBQW9CLEtBQUs7QUFBQSxjQUN4RixjQUFjLENBQUNTLE1BQU0vQyxZQUFZLENBQUFtRCxVQUFTLEVBQUUsR0FBR0EsTUFBTWIsc0JBQXNCUyxFQUFFLEVBQUU7QUFBQSxjQUMvRSxjQUFjZ0M7QUFBQUEsY0FDZCxlQUFlLE1BQU0wQixpQkFBaUIsaUJBQWlCcEsseUJBQXlCO0FBQUEsY0FDaEYsY0FBYytJO0FBQUFBO0FBQUFBLFlBTmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1xQztBQUFBLFVBRXJDLHVCQUFDLFNBQUksV0FBVSxnREFDWDtBQUFBLG1DQUFDLGdCQUFhLFdBQVUsVUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxVQUFLLGdGQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNwRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsT0FBT3JGLFNBQVN0QyxVQUFVO0FBQUEsY0FDMUIsVUFBVTRIO0FBQUFBLGNBQ1YsVUFBVSxDQUFDLENBQUN0RixTQUFTckI7QUFBQUEsY0FDckIsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sS0FBSSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUI7QUFBQSxnQkFDbkIsdUJBQUMsWUFBTyxPQUFNLEtBQUksaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsZ0JBQ25CLHVCQUFDLFlBQU8sT0FBTSxLQUFJLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQjtBQUFBO0FBQUE7QUFBQSxZQVR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0NxQixTQUFTckIsb0JBQ04sdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix1REFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxhQWR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFFQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT3FCLFNBQVNyQyxjQUFjO0FBQUEsY0FDOUIsVUFBVTJIO0FBQUFBLGNBQ1YsY0FBYTtBQUFBLGNBQU0sV0FBVTtBQUFBO0FBQUEsWUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3FIO0FBQUEsYUFQekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0F6REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsMkJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDdEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVd0RixTQUFTd0IsZUFBZTtBQUFBLGNBQ25DLFdBQVd4QixTQUFTMkIsZUFBZTtBQUFBLGNBQ25DLGNBQWMsQ0FBQ3FCLE1BQU02RCx1QkFBdUIsVUFBVTdELENBQUM7QUFBQSxjQUN2RCxjQUFjLE1BQU0rRCx1QkFBdUIsVUFBVXhLLG9CQUFvQjtBQUFBLGNBQ3pFLGVBQWUsTUFBTW1LLGlCQUFpQixVQUFVbkssb0JBQW9CO0FBQUEsY0FDcEUsY0FBYyxNQUFNMEssa0JBQWtCLFFBQVE7QUFBQTtBQUFBLFlBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1vRDtBQUFBLGFBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsd0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVdqSCxTQUFTNkIsb0JBQW9CO0FBQUEsY0FDeEMsV0FBVzdCLFNBQVNnQyxvQkFBb0I7QUFBQSxjQUN4QyxjQUFjLENBQUNnQixNQUFNNkQsdUJBQXVCLGVBQWU3RCxDQUFDO0FBQUEsY0FDNUQsY0FBYyxNQUFNK0QsdUJBQXVCLGVBQWV2SyxzQkFBc0I7QUFBQSxjQUNoRixlQUFlLE1BQU1rSyxpQkFBaUIsZUFBZWxLLHNCQUFzQjtBQUFBLGNBQzNFLGNBQWMsTUFBTXlLLGtCQUFrQixhQUFhO0FBQUE7QUFBQSxZQU52RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNeUQ7QUFBQSxhQVI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLHlCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXakgsU0FBU2lDLGNBQWM7QUFBQSxjQUNsQyxXQUFXakMsU0FBU21DLGNBQWM7QUFBQSxjQUNsQyxjQUFjLENBQUNhLE1BQU02RCx1QkFBdUIsU0FBUzdELENBQUM7QUFBQSxjQUN0RCxjQUFjLE1BQU0rRCx1QkFBdUIsU0FBU3RLLHVCQUF1QjtBQUFBLGNBQzNFLGVBQWUsTUFBTWlLLGlCQUFpQixTQUFTakssdUJBQXVCO0FBQUEsY0FDdEUsY0FBYyxNQUFNd0ssa0JBQWtCLE9BQU87QUFBQTtBQUFBLFlBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1tRDtBQUFBLGFBUnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDBCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFXakgsU0FBU29DLGlCQUFpQjtBQUFBLGNBQ3JDLFdBQVdwQyxTQUFTc0MsaUJBQWlCO0FBQUEsY0FDckMsY0FBYyxDQUFDVSxNQUFNNkQsdUJBQXVCLFlBQVk3RCxDQUFDO0FBQUEsY0FDekQsY0FBYyxNQUFNK0QsdUJBQXVCLFlBQVlySyxtQkFBbUI7QUFBQSxjQUMxRSxlQUFlLE1BQU1nSyxpQkFBaUIsWUFBWWhLLG1CQUFtQjtBQUFBLGNBQ3JFLGNBQWMsTUFBTXVLLGtCQUFrQixVQUFVO0FBQUE7QUFBQSxZQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNc0Q7QUFBQSxhQVIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsMkNBQTBDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxPQUFPakgsU0FBU2hDLGlCQUFpQjtBQUFBLGNBQ2pDLGVBQWU7QUFBQSxjQUNmLFVBQVUsQ0FBQW1LLFFBQU9sSSxZQUFZLENBQUFtRCxVQUFTLEVBQUUsR0FBR0EsTUFBTXBGLGVBQWVtSyxPQUFPLEVBQUUsRUFBRTtBQUFBLGNBQzNFLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQTtBQUFBLFlBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTWtHO0FBQUEsYUFSdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQyxDQUFDekgscUJBQ0UsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSwyQ0FBMEMsb0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE9BQU9WLFNBQVM5QjtBQUFBQSxjQUNoQixVQUFVLENBQUFpSyxRQUFPbEksWUFBWSxDQUFBbUQsVUFBUyxFQUFFLEdBQUdBLE1BQU1sRixtQkFBbUJpSyxPQUFPLEVBQUUsRUFBRTtBQUFBLGNBQy9FLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQTtBQUFBLFlBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2tHO0FBQUEsYUFQdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FuQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLFNBNUlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2SUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLDZCQUFDLFFBQUcsV0FBVSwwQ0FBeUMscUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxTQUFJLFdBQVUscUNBQ1gsaUNBQUMsV0FBTSxXQUFVLHVDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQ2IsaUNBQUMsUUFDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxtRUFBa0UsMkJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDM0YsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSxxQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLHdCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUsd0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsUUFBRyxXQUFVLG9CQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsYUFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ1p2SixnQkFBTWdFO0FBQUFBLFVBQUksQ0FBQ3dGLFFBQ1IsdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxhQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLE9BQU9BLElBQUlwSjtBQUFBQSxnQkFDWCxVQUFVLENBQUN1RyxNQUFNTSxpQkFBaUJ1QyxJQUFJakksUUFBUSxlQUFlb0YsRUFBRUMsT0FBT0osS0FBSztBQUFBLGdCQUMzRSxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUFtRCxjQUFhO0FBQUE7QUFBQSxjQUxoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLcUYsS0FOekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csS0FBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPZ0QsSUFBSWxKO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQWlKLFFBQU90QyxpQkFBaUJ1QyxJQUFJakksUUFBUSxZQUFZZ0ksR0FBRztBQUFBLGdCQUM3RCxXQUFVO0FBQUE7QUFBQSxjQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtnRixLQU5wRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsd0JBQ1Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0MsSUFBSWpKO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQWdKLFFBQU90QyxpQkFBaUJ1QyxJQUFJakksUUFBUSxjQUFjZ0ksR0FBRztBQUFBLGdCQUMvRCxXQUFVO0FBQUE7QUFBQSxjQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlnRixLQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsNENBQTRDbkwsc0JBQVk2RyxPQUFPdUUsSUFBSWxKLFFBQVEsSUFBSTJFLE9BQU91RSxJQUFJakosVUFBVSxHQUFHLFVBQVUsS0FBL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUk7QUFBQSxZQUNqSSx1QkFBQyxRQUFHLFdBQVUsYUFDVixpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU13RyxpQkFBaUJ5QyxJQUFJakksTUFBTSxHQUFHLFdBQVUsbUNBQWtDLE9BQU0sZUFBYyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVEsS0FBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEksS0FEbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBN0JLaUksSUFBSWpJLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxRQUNILEtBakNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxXQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBLEtBOUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQ0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVN1RixlQUFlLFdBQVUsdUpBQ3BEO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFBRztBQUFBLFdBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx1REFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSwyQ0FBMEMscUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUNoRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBTzFGLFNBQVM1QixTQUFTO0FBQUEsWUFDekIsVUFBVWtIO0FBQUFBLFlBQ1YsY0FBYTtBQUFBLFlBQU0sV0FBVTtBQUFBO0FBQUEsVUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzJHO0FBQUEsV0FQL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1YsV0FBQzVFLHFCQUFxQkUsYUFBYStCLFNBQVMsS0FDekMsdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVUscUNBQW9DLDRDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDN0UvQixhQUFhZ0M7QUFBQUEsVUFBSSxDQUFDTyxLQUFLdUUsUUFDcEIsdUJBQUMsU0FBYyxXQUFVLHFDQUNyQjtBQUFBLG1DQUFDLFVBQUssV0FBV00saUJBQWtCL0ssZ0NBQXNCa0csR0FBRyxLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFVBQUssV0FBVzhFLGlCQUFrQmpMLHNCQUFZbUcsSUFBSWtCLFFBQVEsVUFBVSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmpFcUQsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFDSDtBQUFBLFdBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVdNLGlCQUFpQix5QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxVQUFLLFdBQVdDLGlCQUFrQmpMLHNCQUFZd0csaUJBQWlCQyxVQUFVLFVBQVUsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxhQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDRCxpQkFBaUJNLGlCQUFpQixLQUMvQix1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxpQ0FBQyxVQUFLLFdBQVdrRSxpQkFBaUIsMEJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsVUFBSyxXQUFXQyxpQkFBaUI7QUFBQTtBQUFBLFlBQUdqTCxZQUFZd0csaUJBQWlCTSxnQkFBZ0IsVUFBVTtBQUFBLGVBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsYUFGbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFSCxDQUFDcEQscUJBQXFCOEMsaUJBQWlCdEYsb0JBQW9CLEtBQ3hELHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLGlDQUFDLFVBQUssV0FBVyxHQUFHOEosZUFBZSxpQkFBaUIsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDckUsdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGVBQWUsaUJBQWlCO0FBQUE7QUFBQSxZQUFHakwsWUFBWXdHLGlCQUFpQnRGLG1CQUFtQixVQUFVO0FBQUEsZUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUg7QUFBQSxhQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVILENBQUN3QyxxQkFDRSxtQ0FDSTtBQUFBLGlDQUFDLFNBQUksV0FBVSx3REFDWDtBQUFBLG1DQUFDLFVBQUssV0FBVyxHQUFHc0gsZUFBZSxrQkFBa0IsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGVBQWUsa0JBQW1Cakwsc0JBQVl3RyxpQkFBaUJPLFNBQVMsVUFBVSxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLGVBRjVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBV2lFLGlCQUFpQixtQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxVQUFLLFdBQVdDLGlCQUFpQjtBQUFBO0FBQUEsY0FBR2pMLFlBQVl3RyxpQkFBaUJXLFlBQVksVUFBVTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUosdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1DQUFrQyxzQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUN4RCx1QkFBQyxVQUFLLFdBQVUscUNBQXFDbkgsc0JBQVl3RyxpQkFBaUJjLE9BQU8sVUFBVSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRztBQUFBLGFBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNERBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNaEYsU0FBU2hDLGtCQUFrQmpCLDZCQUE2QmlGLFNBQVMsQ0FBQztBQUFBLFVBQ2pGLFdBQVU7QUFBQSxVQUFtSDtBQUFBO0FBQUEsUUFIakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTNEY7QUFBQUEsVUFDVCxVQUFVcEg7QUFBQUEsVUFDVixXQUFXLHdJQUF3SUEsV0FBVyw4QkFBOEIsbUNBQW1DO0FBQUEsVUFFOU5BLHFCQUNHLG1DQUNJO0FBQUEsbUNBQUMsYUFBVSxXQUFVLCtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBO0FBQUEsZUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxJQUVBLG1DQUNJO0FBQUEsbUNBQUMsVUFBTyxXQUFVLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUEsWUFBRztBQUFBLGVBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBZFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ0JBO0FBQUEsU0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBR0NnQixlQUFlRSxlQUNaO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRRjtBQUFBQSxRQUNSLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsUUFDbkMsVUFBVTZGO0FBQUFBLFFBQ1YsUUFBUTVGO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXdCO0FBQUEsT0F4VGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2VEE7QUFFUjtBQUFFM0IsR0F6dUJXRCwwQkFBd0I7QUFBQSxVQUNsQnpELFdBQ0VELGFBRWlCcUIsVUFFMkJiLFdBQVc7QUFBQTtBQUFBbU0sS0FOL0RqSjtBQUF3QixJQUFBaUo7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwidG9hc3QiLCJGYVNhdmUiLCJGYVNwaW5uZXIiLCJGYUluZm9DaXJjbGUiLCJGYVBsdXMiLCJGYVRyYXNoIiwidXNlQ3J1ZEl0ZW0iLCJnZXRCeUlkIiwic2VhcmNoQnlGaWVsZCIsIm5vdGFzRmluYW5jaWVyYXNNb2R1bGVDb25maWciLCJzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnIiwiY2xpZW50ZXNNb2R1bGVDb25maWciLCJ2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnIiwiY29tcHJhZG9yZXNNb2R1bGVDb25maWciLCJtb25lZGFzTW9kdWxlQ29uZmlnIiwiUmVsYXRpb25hbElucHV0IiwiRGVjaW1hbElucHV0IiwiU2VhcmNoTW9kYWwiLCJMb2FkaW5nU3Bpbm5lciIsInVzZU1vZGFsIiwiZm9ybWF0VmFsdWUiLCJmb3JtYXRBcHBsaWVkVGF4VGl0bGUiLCJnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJzYW5pdGl6ZVRheFBheWxvYWRGb3JFeGVtcHRDbGllbnQiLCJjb21wdXRlU2FsZXNBcHBsaWVkVGF4ZXMiLCJnZXRMaXN0UmV0dXJuUGF0aCIsImRlZmF1bHRJbml0aWFsRGF0YSIsImlkIiwidHlwZSIsInNlcmllcyIsImlzc3VlX2RhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvdGFsX2Ftb3VudCIsImV4Y2hhbmdlX3JhdGUiLCJkaXNjb3VudF9wZXJjZW50YWdlIiwid2l0aG91dHRheF9hbW91bnQiLCJjb25jZXB0Iiwibm90ZXMiLCJoYXNfaXRlbV9sZXZlbF90YXhlcyIsImVtaXRfbm93IiwiY2xpZW50X2lkIiwic2FsZXNwZXJzb25faWQiLCJidXllcl9pZCIsImN1cnJlbmN5X2lkIiwic2FsZXNfaW52b2ljZV9pZCIsIml0ZW1zIiwidGF4ZXMiLCJkZWZhdWx0SXRlbSIsImxpbmVfbnVtYmVyIiwiZGVzY3JpcHRpb24iLCJjb25jZXB0X2NvZGUiLCJxdWFudGl0eSIsInVuaXRfcHJpY2UiLCJOb3Rhc0ZpbmFuY2llcmFzRm9ybVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwibW9kZSIsInNob3dDb25maXJtYXRpb25Nb2RhbCIsIml0ZW0iLCJsb2FkZWREYXRhIiwibG9hZGluZyIsImxvYWRpbmdEYXRhIiwic2F2ZUl0ZW0iLCJpc1NhdmluZyIsInNldElzU2F2aW5nIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInNldEl0ZW1zIiwidGVtcElkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsImNsaWVudFRheGVzIiwic2V0Q2xpZW50VGF4ZXMiLCJjbGllbnRUYXhDb25kaXRpb24iLCJzZXRDbGllbnRUYXhDb25kaXRpb24iLCJpc0NsaWVudFRheEV4ZW1wdCIsInNldElzQ2xpZW50VGF4RXhlbXB0IiwiYXBwbGllZFRheGVzIiwic2V0QXBwbGllZFRheGVzIiwiaXNNb2RhbE9wZW4iLCJzZXRJc01vZGFsT3BlbiIsIm1vZGFsQ29uZmlnIiwic2V0TW9kYWxDb25maWciLCJlZGl0aW5nVGFyZ2V0Iiwic2V0RWRpdGluZ1RhcmdldCIsImNhZV9udW1iZXIiLCJlcnJvciIsImJhc2VSb3V0ZSIsImh5ZHJhdGVkIiwiY2xpZW50X2NvZGUiLCJjbGllbnQiLCJjdXN0b21lcl9jb2RlIiwiY2xpZW50X25hbWUiLCJuYW1lIiwic2FsZXNwZXJzb25fY29kZSIsInNhbGVzcGVyc29uIiwiY29kZSIsInNhbGVzcGVyc29uX25hbWUiLCJidXllcl9jb2RlIiwiYnV5ZXIiLCJidXllcl9uYW1lIiwiY3VycmVuY3lfY29kZSIsImN1cnJlbmN5IiwiY3VycmVuY3lfbmFtZSIsInNhbGVzX2ludm9pY2VfbnVtYmVyIiwic2FsZXNfaW52b2ljZSIsImludm9pY2VfbnVtYmVyIiwibG9hZGVkSXRlbXMiLCJsZW5ndGgiLCJtYXAiLCJpdCIsImVuZHBvaW50IiwidGhlbiIsImMiLCJleGVtcHQiLCJyZWxhdGVkVGF4ZXMiLCJ0YXgiLCJwcmV2IiwiY2xpZW50RGF0YSIsIm5ld0NsaWVudFRheGVzIiwiY2F0Y2giLCJjYWxjdWxhdGVkVG90YWxzIiwic3VidG90YWwiLCJyZWR1Y2UiLCJzIiwiaSIsIk51bWJlciIsImRpc2NvdW50QW1vdW50IiwidGF4QmFzZSIsIk1hdGgiLCJtYXgiLCJzdWJ0b3RhbEFmdGVyRGlzY291bnQiLCJ0b3RhbFRheGVzIiwic3VtIiwiYW1vdW50IiwidG90YWwiLCJuZXdBcHBsaWVkVGF4ZXMiLCJuZXRCYXNlIiwiaGFuZGxlSW52b2ljZVNlbGVjdGVkIiwiaW52b2ljZSIsImZ1bGxJbnZvaWNlIiwibG9hZGVkQ2xpZW50VGF4ZXMiLCJpbnZvaWNlQ2xpZW50RXhlbXB0Iiwic3VjY2VzcyIsImNvbnNvbGUiLCJoYW5kbGVJbnZvaWNlQ29kZVN1Ym1pdCIsImNvZGVWYWx1ZSIsInJlc3VsdCIsImZpZWxkTmFtZSIsInZhbHVlIiwiaGFuZGxlQ2xlYXJJbnZvaWNlIiwiaGFuZGxlSGVhZGVyQ2hhbmdlIiwiZSIsInRhcmdldCIsImZpbmFsVmFsdWUiLCJoYW5kbGVBZGRJdGVtIiwiaGFuZGxlUmVtb3ZlSXRlbSIsImZpbHRlciIsImhhbmRsZVVwZGF0ZUl0ZW0iLCJmaWVsZCIsImFwcGx5SGVhZGVyU2VsZWN0aW9uIiwic2VsZWN0ZWRJdGVtIiwibW9kdWxlQ29uZmlnTWFwIiwibW9kdWxlQ29uZmlnIiwicmVsYXRpb25hbEZpZWxkcyIsImNvZGVGaWVsZCIsIm5hbWVGaWVsZCIsInVwZGF0ZWQiLCJzZXJpZSIsInNhbGVzcmVwIiwic2FsZXNSZXBSZWxhdGlvbiIsImhhbmRsZU9wZW5TZWFyY2giLCJjb25maWciLCJoYW5kbGVTZWxlY3RGcm9tTW9kYWwiLCJoYW5kbGVIZWFkZXJDb2RlQ2hhbmdlIiwibmV3Q29kZSIsImhhbmRsZUhlYWRlckNvZGVTdWJtaXQiLCJlcnIiLCJoYW5kbGVIZWFkZXJDbGVhciIsImhhbmRsZVNhdmUiLCJzb21lIiwidHJpbSIsInRpdGxlIiwibWVzc2FnZSIsIm9uQ29uZmlybSIsInBlcmZvcm1TYXZlIiwiY2xlYW5JdGVtcyIsImlkeCIsInJlc3QiLCJzYW5pdGl6ZWQiLCJwYXlsb2FkIiwidCIsInNhdmVkIiwidG90YWxMYWJlbFN0eWxlIiwidG90YWxWYWx1ZVN0eWxlIiwidm91Y2hlcl9udW1iZXIiLCJudW0iLCJyb3ciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3Rhc0ZpbmFuY2llcmFzRm9ybVBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFycyAqL1xuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgRmFTYXZlLCBGYVNwaW5uZXIsIEZhSW5mb0NpcmNsZSwgRmFQbHVzLCBGYVRyYXNoIH0gZnJvbSAncmVhY3QtaWNvbnMvZmEnO1xuaW1wb3J0IHsgdXNlQ3J1ZEl0ZW0gfSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDcnVkSXRlbSc7XG5pbXBvcnQgeyBnZXRCeUlkLCBzZWFyY2hCeUZpZWxkIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvYXBpU2VydmljZSc7XG5pbXBvcnQgeyBub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnLCB0eXBlIEZpbmFuY2lhbE5vdGUsIHR5cGUgRmluYW5jaWFsTm90ZUl0ZW0gfSBmcm9tICcuLi9ub3Rhc19maW5hbmNpZXJhcy5jb25maWcnO1xuaW1wb3J0IHsgc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZywgdHlwZSBTYWxlc0ludm9pY2UgfSBmcm9tICcuLi8uLi9mYWN0dXJhc192ZW50YS9mYWN0dXJhc192ZW50YS5jb25maWcnO1xuaW1wb3J0IHsgY2xpZW50ZXNNb2R1bGVDb25maWcsIHR5cGUgQ2xpZW50ZSB9IGZyb20gJy4uLy4uL2NsaWVudGVzL2NsaWVudGVzLmNvbmZpZyc7XG5pbXBvcnQgeyB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vdmVuZGVkb3Jlcy92ZW5kZWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBjb21wcmFkb3Jlc01vZHVsZUNvbmZpZyB9IGZyb20gJy4uLy4uL2NvbXByYWRvcmVzL2NvbXByYWRvcmVzLmNvbmZpZyc7XG5pbXBvcnQgeyBtb25lZGFzTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi4vLi4vbW9uZWRhcy9tb25lZGFzLmNvbmZpZyc7XG5pbXBvcnQgeyBSZWxhdGlvbmFsSW5wdXQgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9SZWxhdGlvbmFsSW5wdXQnO1xuaW1wb3J0IHsgRGVjaW1hbElucHV0IH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vRGVjaW1hbElucHV0JztcbmltcG9ydCB7IFNlYXJjaE1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9jb21tb24vU2VhcmNoTW9kYWwnO1xuaW1wb3J0IHsgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL3VpL0xvYWRpbmdTcGlubmVyJztcbmltcG9ydCB7IHVzZU1vZGFsIH0gZnJvbSAnLi4vLi4vLi4vY29udGV4dC9Nb2RhbENvbnRleHQnO1xuaW1wb3J0IHsgZm9ybWF0VmFsdWUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IGZvcm1hdEFwcGxpZWRUYXhUaXRsZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL3RheERpc3BsYXknO1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgdHlwZSBBcHBsaWVkVGF4LCB0eXBlIFJlbGF0ZWRUYXggYXMgQ2xpZW50VGF4IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvYXBwbGllZFRheGVzJztcbmltcG9ydCB7XG4gICAgZ2V0RWZmZWN0aXZlQ2xpZW50VGF4ZXMsXG4gICAgaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdCxcbiAgICBzYW5pdGl6ZVRheFBheWxvYWRGb3JFeGVtcHRDbGllbnQsXG59IGZyb20gJy4uLy4uLy4uL3V0aWxzL2NsaWVudFRheEV4ZW1wdGlvbic7XG5pbXBvcnQgeyBjb21wdXRlU2FsZXNBcHBsaWVkVGF4ZXMgfSBmcm9tICcuLi8uLi8uLi91dGlscy9zYWxlc1JlbGF0ZWRUYXhDb21wdXRhdGlvbic7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuY29uc3QgZGVmYXVsdEluaXRpYWxEYXRhOiBQYXJ0aWFsPEZpbmFuY2lhbE5vdGU+ID0ge1xuICAgIGlkOiAwLFxuICAgIHR5cGU6ICdERUJJVCcsXG4gICAgc2VyaWVzOiAnQicsXG4gICAgaXNzdWVfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgdG90YWxfYW1vdW50OiAwLFxuICAgIGV4Y2hhbmdlX3JhdGU6IDEsXG4gICAgZGlzY291bnRfcGVyY2VudGFnZTogMCxcbiAgICB3aXRob3V0dGF4X2Ftb3VudDogMCxcbiAgICBjb25jZXB0OiAnJyxcbiAgICBub3RlczogbnVsbCxcbiAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsXG4gICAgZW1pdF9ub3c6IHRydWUsIC8vIFNpZW1wcmUgdHJ1ZVxuICAgIGNsaWVudF9pZDogbnVsbCxcbiAgICBzYWxlc3BlcnNvbl9pZDogbnVsbCxcbiAgICBidXllcl9pZDogbnVsbCxcbiAgICBjdXJyZW5jeV9pZDogbnVsbCxcbiAgICBzYWxlc19pbnZvaWNlX2lkOiBudWxsLFxuICAgIGl0ZW1zOiBbXSxcbiAgICB0YXhlczogW10sXG59O1xuXG5jb25zdCBkZWZhdWx0SXRlbTogRmluYW5jaWFsTm90ZUl0ZW0gPSB7XG4gICAgbGluZV9udW1iZXI6IDEsXG4gICAgZGVzY3JpcHRpb246ICcnLFxuICAgIGNvbmNlcHRfY29kZTogJ05PVEEtRklOQU5DSUVSQScsXG4gICAgcXVhbnRpdHk6IDEsXG4gICAgdW5pdF9wcmljZTogMCxcbiAgICBkaXNjb3VudF9wZXJjZW50YWdlOiAwLFxuICAgIHRheGVzOiBbXSxcbn07XG5cbnR5cGUgRm9ybUl0ZW0gPSBGaW5hbmNpYWxOb3RlSXRlbSAmIHsgdGVtcElkOiBzdHJpbmcgfTtcblxuZXhwb3J0IGNvbnN0IE5vdGFzRmluYW5jaWVyYXNGb3JtUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IG1vZGUgPSBpZCA/ICdlZGl0JyA6ICdjcmVhdGUnO1xuICAgIGNvbnN0IHsgc2hvd0NvbmZpcm1hdGlvbk1vZGFsIH0gPSB1c2VNb2RhbCgpO1xuXG4gICAgY29uc3QgeyBpdGVtOiBsb2FkZWREYXRhLCBsb2FkaW5nOiBsb2FkaW5nRGF0YSwgc2F2ZUl0ZW0gfSA9IHVzZUNydWRJdGVtPEZpbmFuY2lhbE5vdGU+KG5vdGFzRmluYW5jaWVyYXNNb2R1bGVDb25maWcsIGlkKTtcblxuICAgIC8vIEVzdGFkb3NcbiAgICBjb25zdCBbaXNTYXZpbmcsIHNldElzU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPFBhcnRpYWw8RmluYW5jaWFsTm90ZT4+KGRlZmF1bHRJbml0aWFsRGF0YSk7XG4gICAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZTxGb3JtSXRlbVtdPigoKSA9PiBbeyAuLi5kZWZhdWx0SXRlbSwgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpIH1dKTtcbiAgICBjb25zdCBbY2xpZW50VGF4ZXMsIHNldENsaWVudFRheGVzXSA9IHVzZVN0YXRlPENsaWVudFRheFtdPihbXSk7XG4gICAgY29uc3QgW2NsaWVudFRheENvbmRpdGlvbiwgc2V0Q2xpZW50VGF4Q29uZGl0aW9uXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAgIGNvbnN0IFtpc0NsaWVudFRheEV4ZW1wdCwgc2V0SXNDbGllbnRUYXhFeGVtcHRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFthcHBsaWVkVGF4ZXMsIHNldEFwcGxpZWRUYXhlc10gPSB1c2VTdGF0ZTxBcHBsaWVkVGF4W10+KFtdKTtcblxuICAgIC8vIEVzdGFkb3MgTW9kYWxlc1xuICAgIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFttb2RhbENvbmZpZywgc2V0TW9kYWxDb25maWddID0gdXNlU3RhdGU8TW9kdWxlQ29uZmlnPGFueT4gfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZWRpdGluZ1RhcmdldCwgc2V0RWRpdGluZ1RhcmdldF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAgIC8vIENhcmdhIGluaWNpYWwgZW4gbW9kbyBFZGljacOzblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChtb2RlID09PSAnZWRpdCcgJiYgbG9hZGVkRGF0YSkge1xuICAgICAgICAgICAgLy8g4puUIFNpIHlhIHRpZW5lIENBRSwgbm8gcGVybWl0aW1vcyBlZGl0YXJcbiAgICAgICAgICAgIGlmIChsb2FkZWREYXRhLmNhZV9udW1iZXIpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVlZGUgZWRpdGFyIHVuYSBOb3RhIEZpbmFuY2llcmEgcXVlIHlhIHRpZW5lIENBRS4nKTtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZShnZXRMaXN0UmV0dXJuUGF0aChub3Rhc0ZpbmFuY2llcmFzTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgaHlkcmF0ZWQgPSB7XG4gICAgICAgICAgICAgICAgLi4uZGVmYXVsdEluaXRpYWxEYXRhLFxuICAgICAgICAgICAgICAgIC4uLmxvYWRlZERhdGEsXG4gICAgICAgICAgICAgICAgY2xpZW50X2NvZGU6IChsb2FkZWREYXRhLmNsaWVudCBhcyBhbnkpPy5jdXN0b21lcl9jb2RlIHx8ICcnLFxuICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiBsb2FkZWREYXRhLmNsaWVudD8ubmFtZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBzYWxlc3BlcnNvbl9jb2RlOiAobG9hZGVkRGF0YS5zYWxlc3BlcnNvbiBhcyBhbnkpPy5jb2RlIHx8ICcnLFxuICAgICAgICAgICAgICAgIHNhbGVzcGVyc29uX25hbWU6IGxvYWRlZERhdGEuc2FsZXNwZXJzb24/Lm5hbWUgfHwgJycsXG4gICAgICAgICAgICAgICAgYnV5ZXJfY29kZTogKGxvYWRlZERhdGEuYnV5ZXIgYXMgYW55KT8uY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBidXllcl9uYW1lOiBsb2FkZWREYXRhLmJ1eWVyPy5uYW1lIHx8ICcnLFxuICAgICAgICAgICAgICAgIGN1cnJlbmN5X2NvZGU6IChsb2FkZWREYXRhLmN1cnJlbmN5IGFzIGFueSk/LmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgY3VycmVuY3lfbmFtZTogbG9hZGVkRGF0YS5jdXJyZW5jeT8ubmFtZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBzYWxlc19pbnZvaWNlX251bWJlcjogbG9hZGVkRGF0YS5zYWxlc19pbnZvaWNlPy5pbnZvaWNlX251bWJlciB8fCBudWxsLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKGh5ZHJhdGVkKTtcbiAgICAgICAgICAgIGNvbnN0IGxvYWRlZEl0ZW1zID0gKGh5ZHJhdGVkLml0ZW1zIHx8IFtdKS5sZW5ndGhcbiAgICAgICAgICAgICAgICA/IChoeWRyYXRlZC5pdGVtcyB8fCBbXSkubWFwKChpdDogRmluYW5jaWFsTm90ZUl0ZW0pID0+ICh7IC4uLml0LCBjb25jZXB0X2NvZGU6IGl0LmNvbmNlcHRfY29kZSB8fCAnTk9UQS1GSU5BTkNJRVJBJywgcXVhbnRpdHk6IGl0LnF1YW50aXR5ID8/IDEsIHRlbXBJZDogY3J5cHRvLnJhbmRvbVVVSUQoKSB9IGFzIEZvcm1JdGVtKSlcbiAgICAgICAgICAgICAgICA6IFt7IC4uLmRlZmF1bHRJdGVtLCB0ZW1wSWQ6IGNyeXB0by5yYW5kb21VVUlEKCkgfV07XG4gICAgICAgICAgICBzZXRJdGVtcyhsb2FkZWRJdGVtcyk7XG5cbiAgICAgICAgICAgIGlmIChsb2FkZWREYXRhLmNsaWVudF9pZCkge1xuICAgICAgICAgICAgICAgIGdldEJ5SWQ8Q2xpZW50ZT4oY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGxvYWRlZERhdGEuY2xpZW50X2lkKVxuICAgICAgICAgICAgICAgICAgICAudGhlbihjID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4ZW1wdCA9IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQoYyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0NsaWVudFRheEV4ZW1wdChleGVtcHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4ZXMoZ2V0RWZmZWN0aXZlQ2xpZW50VGF4ZXMoYywgYy5yZWxhdGVkVGF4ZXMpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihjLnRheCA/PyBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGVtcHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgd2l0aG91dHRheF9hbW91bnQ6IDAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFttb2RlLCBsb2FkZWREYXRhLCBuYXZpZ2F0ZV0pO1xuXG4gICAgLy8gRWZlY3RvIHBhcmEgY2FyZ2FyIGltcHVlc3RvcyBkZWwgY2xpZW50ZVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChmb3JtRGF0YS5jbGllbnRfaWQpIHtcbiAgICAgICAgICAgIGdldEJ5SWQ8Q2xpZW50ZT4oY2xpZW50ZXNNb2R1bGVDb25maWcuZW5kcG9pbnQsIGZvcm1EYXRhLmNsaWVudF9pZClcbiAgICAgICAgICAgICAgICAudGhlbihjbGllbnREYXRhID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhlbXB0ID0gaXNDbGllbnRMZXlFeHBvcnRhY2lvblRkZkV4ZW1wdChjbGllbnREYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3Q2xpZW50VGF4ZXMgPSBnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyhjbGllbnREYXRhLCBjbGllbnREYXRhLnJlbGF0ZWRUYXhlcyk7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGV4ZW1wdCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKG5ld0NsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2xpZW50VGF4Q29uZGl0aW9uKGNsaWVudERhdGEudGF4ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhlbXB0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB3aXRob3V0dGF4X2Ftb3VudDogMCB9KSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LmVycm9yKCdObyBzZSBwdWRpZXJvbiBjYXJnYXIgbG9zIGltcHVlc3RvcyBkZWwgY2xpZW50ZS4nKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNDbGllbnRUYXhFeGVtcHQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDbGllbnRUYXhDb25kaXRpb24obnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGZhbHNlKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihudWxsKTtcbiAgICAgICAgICAgIHNldENsaWVudFRheGVzKFtdKTtcbiAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgIH1cbiAgICB9LCBbZm9ybURhdGEuY2xpZW50X2lkXSk7XG5cbiAgICAvLyBDw6FsY3Vsb3MgZGUgdG90YWxlc1xuICAgIGNvbnN0IGNhbGN1bGF0ZWRUb3RhbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAgICAgY29uc3Qgc3VidG90YWwgPSBpdGVtcy5yZWR1Y2UoKHMsIGkpID0+IHMgKyBOdW1iZXIoaS5xdWFudGl0eSkgKiBOdW1iZXIoaS51bml0X3ByaWNlKSwgMCk7XG4gICAgICAgIGNvbnN0IGRpc2NvdW50QW1vdW50ID0gc3VidG90YWwgKiAoTnVtYmVyKGZvcm1EYXRhLmRpc2NvdW50X3BlcmNlbnRhZ2UpIHx8IDApIC8gMTAwO1xuICAgICAgICBjb25zdCB3aXRob3V0dGF4X2Ftb3VudCA9IGlzQ2xpZW50VGF4RXhlbXB0ID8gMCA6IChmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCA/PyAwKTtcbiAgICAgICAgY29uc3QgdGF4QmFzZSA9IE1hdGgubWF4KDAsIHN1YnRvdGFsIC0gZGlzY291bnRBbW91bnQgLSB3aXRob3V0dGF4X2Ftb3VudCk7XG4gICAgICAgIGNvbnN0IHN1YnRvdGFsQWZ0ZXJEaXNjb3VudCA9IHN1YnRvdGFsIC0gZGlzY291bnRBbW91bnQ7XG5cbiAgICAgICAgY29uc3QgdG90YWxUYXhlcyA9IGlzQ2xpZW50VGF4RXhlbXB0XG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogYXBwbGllZFRheGVzLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG4gICAgICAgIGNvbnN0IHRvdGFsID0gc3VidG90YWxBZnRlckRpc2NvdW50ICsgdG90YWxUYXhlcztcbiAgICAgICAgcmV0dXJuIHsgc3VidG90YWwsIGRpc2NvdW50QW1vdW50LCB3aXRob3V0dGF4X2Ftb3VudCwgdGF4QmFzZSwgdG90YWxUYXhlcywgdG90YWwgfTtcbiAgICB9LCBbaXRlbXMsIGFwcGxpZWRUYXhlcywgZm9ybURhdGEud2l0aG91dHRheF9hbW91bnQsIGZvcm1EYXRhLmRpc2NvdW50X3BlcmNlbnRhZ2UsIGlzQ2xpZW50VGF4RXhlbXB0XSk7XG5cbiAgICAvLyBFZmVjdG8gcGFyYSBjYWxjdWxhciBpbXB1ZXN0b3MgZ2xvYmFsZXNcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhbXSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgc2llbXByZSBmYWxzZSwgc2llbXByZSBzZSB1c2FuIGltcHVlc3RvcyBnbG9iYWxlc1xuICAgICAgICBpZiAoY2xpZW50VGF4ZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgeyB0YXhCYXNlIH0gPSBjYWxjdWxhdGVkVG90YWxzO1xuICAgICAgICAgICAgY29uc3QgbmV3QXBwbGllZFRheGVzID0gY29tcHV0ZVNhbGVzQXBwbGllZFRheGVzKHtcbiAgICAgICAgICAgICAgICBuZXRCYXNlOiB0YXhCYXNlLFxuICAgICAgICAgICAgICAgIGNsaWVudFRheENvbmRpdGlvbixcbiAgICAgICAgICAgICAgICB0YXhlczogY2xpZW50VGF4ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNldEFwcGxpZWRUYXhlcyhuZXdBcHBsaWVkVGF4ZXMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0QXBwbGllZFRheGVzKFtdKTtcbiAgICAgICAgfVxuICAgIH0sIFtjYWxjdWxhdGVkVG90YWxzLnRheEJhc2UsIGNsaWVudFRheGVzLCBjbGllbnRUYXhDb25kaXRpb24sIGlzQ2xpZW50VGF4RXhlbXB0XSk7XG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgY2FyZ2FyIGZhY3R1cmFcbiAgICBjb25zdCBoYW5kbGVJbnZvaWNlU2VsZWN0ZWQgPSBhc3luYyAoaW52b2ljZTogU2FsZXNJbnZvaWNlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBmdWxsSW52b2ljZSA9IGF3YWl0IGdldEJ5SWQ8U2FsZXNJbnZvaWNlPihzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBpbnZvaWNlLmlkKTtcblxuICAgICAgICAgICAgbGV0IGxvYWRlZENsaWVudFRheGVzOiBDbGllbnRUYXhbXSA9IFtdO1xuICAgICAgICAgICAgbGV0IGludm9pY2VDbGllbnRFeGVtcHQgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChmdWxsSW52b2ljZS5jbGllbnRfaWQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBnZXRCeUlkPENsaWVudGU+KGNsaWVudGVzTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBmdWxsSW52b2ljZS5jbGllbnRfaWQpO1xuICAgICAgICAgICAgICAgIGludm9pY2VDbGllbnRFeGVtcHQgPSBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0KGNsaWVudCk7XG4gICAgICAgICAgICAgICAgbG9hZGVkQ2xpZW50VGF4ZXMgPSBnZXRFZmZlY3RpdmVDbGllbnRUYXhlcyhjbGllbnQsIGNsaWVudC5yZWxhdGVkVGF4ZXMpO1xuICAgICAgICAgICAgICAgIHNldElzQ2xpZW50VGF4RXhlbXB0KGludm9pY2VDbGllbnRFeGVtcHQpO1xuICAgICAgICAgICAgICAgIHNldENsaWVudFRheENvbmRpdGlvbihjbGllbnQudGF4ID8/IG51bGwpO1xuICAgICAgICAgICAgICAgIHNldENsaWVudFRheGVzKGxvYWRlZENsaWVudFRheGVzKTtcbiAgICAgICAgICAgICAgICBpZiAoaW52b2ljZUNsaWVudEV4ZW1wdCkge1xuICAgICAgICAgICAgICAgICAgICBzZXRBcHBsaWVkVGF4ZXMoW10pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgc2FsZXNfaW52b2ljZV9pZDogZnVsbEludm9pY2UuaWQsXG4gICAgICAgICAgICAgICAgc2FsZXNfaW52b2ljZV9udW1iZXI6IGZ1bGxJbnZvaWNlLmludm9pY2VfbnVtYmVyLFxuICAgICAgICAgICAgICAgIHNlcmllczogZnVsbEludm9pY2Uuc2VyaWVzLCAvLyBDb3BpYXIgc2VyaWUgZGUgbGEgZmFjdHVyYVxuICAgICAgICAgICAgICAgIGNsaWVudF9pZDogZnVsbEludm9pY2UuY2xpZW50X2lkLFxuICAgICAgICAgICAgICAgIGNsaWVudF9uYW1lOiBmdWxsSW52b2ljZS5jbGllbnQ/Lm5hbWUsXG4gICAgICAgICAgICAgICAgY2xpZW50X2NvZGU6IChmdWxsSW52b2ljZS5jbGllbnQgYXMgYW55KT8uY3VzdG9tZXJfY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBzYWxlc3BlcnNvbl9pZDogZnVsbEludm9pY2Uuc2FsZXNwZXJzb25faWQsXG4gICAgICAgICAgICAgICAgc2FsZXNwZXJzb25fbmFtZTogZnVsbEludm9pY2Uuc2FsZXNwZXJzb24/Lm5hbWUsXG4gICAgICAgICAgICAgICAgc2FsZXNwZXJzb25fY29kZTogKGZ1bGxJbnZvaWNlLnNhbGVzcGVyc29uIGFzIGFueSk/LmNvZGUgfHwgJycsXG4gICAgICAgICAgICAgICAgYnV5ZXJfaWQ6IGZ1bGxJbnZvaWNlLmJ1eWVyX2lkLFxuICAgICAgICAgICAgICAgIGJ1eWVyX25hbWU6IGZ1bGxJbnZvaWNlLmJ1eWVyPy5uYW1lLFxuICAgICAgICAgICAgICAgIGJ1eWVyX2NvZGU6IChmdWxsSW52b2ljZS5idXllciBhcyBhbnkpPy5jb2RlIHx8ICcnLFxuICAgICAgICAgICAgICAgIGN1cnJlbmN5X2lkOiBmdWxsSW52b2ljZS5jdXJyZW5jeV9pZCxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeV9uYW1lOiBmdWxsSW52b2ljZS5jdXJyZW5jeT8ubmFtZSxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeV9jb2RlOiAoZnVsbEludm9pY2UuY3VycmVuY3kgYXMgYW55KT8uY29kZSB8fCAnJyxcbiAgICAgICAgICAgICAgICBleGNoYW5nZV9yYXRlOiBOdW1iZXIoZnVsbEludm9pY2UuZXhjaGFuZ2VfcmF0ZSkgfHwgMSxcbiAgICAgICAgICAgICAgICBoYXNfaXRlbV9sZXZlbF90YXhlczogZmFsc2UsIC8vIFNpZW1wcmUgZmFsc2UgcGFyYSBub3RhcyBmaW5hbmNpZXJhc1xuICAgICAgICAgICAgICAgIHdpdGhvdXR0YXhfYW1vdW50OiBpbnZvaWNlQ2xpZW50RXhlbXB0ID8gMCA6IHByZXYud2l0aG91dHRheF9hbW91bnQsXG4gICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYEZhY3R1cmEgY2FyZ2FkYS4gU2VyaWUgJHtmdWxsSW52b2ljZS5zZXJpZXN9IGNvcGlhZGEuYCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIHRvYXN0LmVycm9yKFwiRXJyb3IgYWwgY2FyZ2FyIGxvcyBkYXRvcyBkZSBsYSBmYWN0dXJhLlwiKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVJbnZvaWNlQ29kZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY29kZVZhbHVlID0gZm9ybURhdGEuc2FsZXNfaW52b2ljZV9udW1iZXI7XG4gICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHNlYXJjaEJ5RmllbGQ8U2FsZXNJbnZvaWNlPihcbiAgICAgICAgICAgICAgICBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLmVuZHBvaW50LFxuICAgICAgICAgICAgICAgIFt7IGZpZWxkTmFtZTogJ2ludm9pY2VfbnVtYmVyJywgdmFsdWU6IGNvZGVWYWx1ZSB9XVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGhhbmRsZUludm9pY2VTZWxlY3RlZChyZXN1bHQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5lcnJvcihgTm8gc2UgZW5jb250csOzIG5pbmd1bmEgZmFjdHVyYSBjb24gZWwgbsO6bWVybyBcIiR7Y29kZVZhbHVlfVwiLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFsIGJ1c2NhciBsYSBmYWN0dXJhIHBvciBjw7NkaWdvLlwiKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgbGltcGlhciBmYWN0dXJhXG4gICAgY29uc3QgaGFuZGxlQ2xlYXJJbnZvaWNlID0gKCkgPT4ge1xuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgc2FsZXNfaW52b2ljZV9pZDogbnVsbCxcbiAgICAgICAgICAgIHNhbGVzX2ludm9pY2VfbnVtYmVyOiBudWxsLFxuICAgICAgICB9KSk7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZXIgcGFyYSBjYW1iaW9zIGVuIGNhbXBvcyByZWxhY2lvbmFsZXNcbiAgICBjb25zdCBoYW5kbGVIZWFkZXJDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudCB8IEhUTUxUZXh0QXJlYUVsZW1lbnQgfCBIVE1MU2VsZWN0RWxlbWVudD4pID0+IHtcbiAgICAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XG4gICAgICAgIGxldCBmaW5hbFZhbHVlOiBhbnkgPSB2YWx1ZTtcbiAgICAgICAgaWYgKG5hbWUgPT09ICdkaXNjb3VudF9wZXJjZW50YWdlJyB8fCBuYW1lID09PSAnZXhjaGFuZ2VfcmF0ZScgfHwgbmFtZSA9PT0gJ3dpdGhvdXR0YXhfYW1vdW50Jykge1xuICAgICAgICAgICAgZmluYWxWYWx1ZSA9IHZhbHVlID09PSAnJyA/IDAgOiBOdW1iZXIodmFsdWUpIHx8IDA7XG4gICAgICAgIH1cbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IGZpbmFsVmFsdWUgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVBZGRJdGVtID0gKCkgPT4gc2V0SXRlbXMocHJldiA9PiBbLi4ucHJldiwgeyAuLi5kZWZhdWx0SXRlbSwgdGVtcElkOiBjcnlwdG8ucmFuZG9tVVVJRCgpIH1dKTtcbiAgICBjb25zdCBoYW5kbGVSZW1vdmVJdGVtID0gKHRlbXBJZDogc3RyaW5nKSA9PiBzZXRJdGVtcyhwcmV2ID0+IChwcmV2Lmxlbmd0aCA+IDEgPyBwcmV2LmZpbHRlcihpID0+IGkudGVtcElkICE9PSB0ZW1wSWQpIDogcHJldikpO1xuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZUl0ZW0gPSAodGVtcElkOiBzdHJpbmcsIGZpZWxkOiBrZXlvZiBGaW5hbmNpYWxOb3RlSXRlbSwgdmFsdWU6IHN0cmluZyB8IG51bWJlcikgPT4ge1xuICAgICAgICBzZXRJdGVtcyhwcmV2ID0+IHByZXYubWFwKGkgPT4gKGkudGVtcElkID09PSB0ZW1wSWQgPyB7IC4uLmksIFtmaWVsZF06IHZhbHVlIH0gOiBpKSkpO1xuICAgIH07XG5cbiAgICAvLyBGdW5jacOzbiBwYXJhIGFwbGljYXIgbGEgc2VsZWNjacOzbiBkZSB1biBjYW1wbyByZWxhY2lvbmFsXG4gICAgY29uc3QgYXBwbHlIZWFkZXJTZWxlY3Rpb24gPSBhc3luYyAoZmllbGQ6IHN0cmluZywgc2VsZWN0ZWRJdGVtOiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgbW9kdWxlQ29uZmlnTWFwOiBSZWNvcmQ8c3RyaW5nLCBNb2R1bGVDb25maWc8YW55Pj4gPSB7XG4gICAgICAgICAgICAnY2xpZW50JzogY2xpZW50ZXNNb2R1bGVDb25maWcsXG4gICAgICAgICAgICAnc2FsZXNwZXJzb24nOiB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ2J1eWVyJzogY29tcHJhZG9yZXNNb2R1bGVDb25maWcsXG4gICAgICAgICAgICAnY3VycmVuY3knOiBtb25lZGFzTW9kdWxlQ29uZmlnLFxuICAgICAgICAgICAgJ3NhbGVzX2ludm9pY2UnOiBzYWxlc0ludm9pY2VzTW9kdWxlQ29uZmlnLFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IG1vZHVsZUNvbmZpZyA9IG1vZHVsZUNvbmZpZ01hcFtmaWVsZF07XG4gICAgICAgIGlmICghbW9kdWxlQ29uZmlnIHx8ICFtb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcykge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoYEVycm9yOiBGYWx0YSAncmVsYXRpb25hbEZpZWxkcycgZW4gbGEgY29uZmlnIGRlICR7ZmllbGR9YCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGNvZGVGaWVsZCwgbmFtZUZpZWxkIH0gPSBtb2R1bGVDb25maWcucmVsYXRpb25hbEZpZWxkcztcblxuICAgICAgICBpZiAoZmllbGQgPT09ICdzYWxlc19pbnZvaWNlJykge1xuICAgICAgICAgICAgYXdhaXQgaGFuZGxlSW52b2ljZVNlbGVjdGVkKHNlbGVjdGVkSXRlbSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkOiBQYXJ0aWFsPEZpbmFuY2lhbE5vdGU+ID0geyAuLi5wcmV2IH07XG5cbiAgICAgICAgICAgICAgICAvLyBBY3R1YWxpemFyIGNhbXBvcyBkaW7DoW1pY29zIGRlIGZvcm1hIHNlZ3VyYVxuICAgICAgICAgICAgICAgIGlmIChmaWVsZCA9PT0gJ2NsaWVudCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5jbGllbnRfaWQgPSBzZWxlY3RlZEl0ZW0uaWQ7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY2xpZW50X2NvZGUgPSBzZWxlY3RlZEl0ZW1bY29kZUZpZWxkIGFzIHN0cmluZ107XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY2xpZW50X25hbWUgPSBzZWxlY3RlZEl0ZW1bbmFtZUZpZWxkIGFzIHN0cmluZ107XG4gICAgICAgICAgICAgICAgICAgIC8vIEF1dG8tcmVsbGVuYXIgc2VyaWUgZGVsIGNsaWVudGVcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkSXRlbS5zZXJpZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5zZXJpZXMgPSBzZWxlY3RlZEl0ZW0uc2VyaWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gQXV0by1yZWxsZW5hciB2ZW5kZWRvciBzaSBlbCBjbGllbnRlIGxvIHRpZW5lXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEl0ZW0uc2FsZXNyZXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuc2FsZXNwZXJzb25faWQgPSBzZWxlY3RlZEl0ZW0uc2FsZXNyZXA7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLnNhbGVzcGVyc29uX2NvZGUgPSAoc2VsZWN0ZWRJdGVtLnNhbGVzUmVwUmVsYXRpb24gYXMgYW55KT8uY29kZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5zYWxlc3BlcnNvbl9uYW1lID0gKHNlbGVjdGVkSXRlbS5zYWxlc1JlcFJlbGF0aW9uIGFzIGFueSk/Lm5hbWUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBBdXRvLXJlbGxlbmFyIG1vbmVkYSBzaSBlbCBjbGllbnRlIGxvIHRpZW5lXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEl0ZW0uY3VycmVuY3lfaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY3VycmVuY3lfaWQgPSBzZWxlY3RlZEl0ZW0uY3VycmVuY3lfaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLmN1cnJlbmN5X2NvZGUgPSAoc2VsZWN0ZWRJdGVtLmN1cnJlbmN5IGFzIGFueSk/LmNvZGUgfHwgbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY3VycmVuY3lfbmFtZSA9IChzZWxlY3RlZEl0ZW0uY3VycmVuY3kgYXMgYW55KT8ubmFtZSB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5leGNoYW5nZV9yYXRlID0gTnVtYmVyKChzZWxlY3RlZEl0ZW0uY3VycmVuY3kgYXMgYW55KT8uZXhjaGFuZ2VfcmF0ZSkgfHwgMTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZmllbGQgPT09ICdzYWxlc3BlcnNvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5zYWxlc3BlcnNvbl9pZCA9IHNlbGVjdGVkSXRlbS5pZDtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5zYWxlc3BlcnNvbl9jb2RlID0gc2VsZWN0ZWRJdGVtW2NvZGVGaWVsZCBhcyBzdHJpbmddO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLnNhbGVzcGVyc29uX25hbWUgPSBzZWxlY3RlZEl0ZW1bbmFtZUZpZWxkIGFzIHN0cmluZ107XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChmaWVsZCA9PT0gJ2J1eWVyJykge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLmJ1eWVyX2lkID0gc2VsZWN0ZWRJdGVtLmlkO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLmJ1eWVyX2NvZGUgPSBzZWxlY3RlZEl0ZW1bY29kZUZpZWxkIGFzIHN0cmluZ107XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuYnV5ZXJfbmFtZSA9IHNlbGVjdGVkSXRlbVtuYW1lRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGZpZWxkID09PSAnY3VycmVuY3knKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY3VycmVuY3lfaWQgPSBzZWxlY3RlZEl0ZW0uaWQ7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWQuY3VycmVuY3lfY29kZSA9IHNlbGVjdGVkSXRlbVtjb2RlRmllbGQgYXMgc3RyaW5nXTtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZC5jdXJyZW5jeV9uYW1lID0gc2VsZWN0ZWRJdGVtW25hbWVGaWVsZCBhcyBzdHJpbmddO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkLmV4Y2hhbmdlX3JhdGUgPSBOdW1iZXIoc2VsZWN0ZWRJdGVtLmV4Y2hhbmdlX3JhdGUpIHx8IDE7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgYWJyaXIgbW9kYWwgZGUgYsO6c3F1ZWRhXG4gICAgY29uc3QgaGFuZGxlT3BlblNlYXJjaCA9ICh0YXJnZXQ6IHN0cmluZywgY29uZmlnOiBNb2R1bGVDb25maWc8YW55PikgPT4ge1xuICAgICAgICBzZXRFZGl0aW5nVGFyZ2V0KHRhcmdldCk7XG4gICAgICAgIHNldE1vZGFsQ29uZmlnKGNvbmZpZyk7XG4gICAgICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgc2VsZWNjacOzbiBkZXNkZSBtb2RhbFxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEZyb21Nb2RhbCA9IGFzeW5jIChzZWxlY3RlZEl0ZW06IGFueSkgPT4ge1xuICAgICAgICBpZiAoIWVkaXRpbmdUYXJnZXQpIHJldHVybjtcbiAgICAgICAgYXdhaXQgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZWRpdGluZ1RhcmdldCwgc2VsZWN0ZWRJdGVtKTtcbiAgICAgICAgc2V0SXNNb2RhbE9wZW4oZmFsc2UpO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGVyIHBhcmEgY8OzZGlnbyBkZSBjYW1wb3MgcmVsYWNpb25hbGVzXG4gICAgY29uc3QgaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSA9IChmaWVsZDogc3RyaW5nLCBuZXdDb2RlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtgJHtmaWVsZH1faWRgXTogbnVsbCxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1fY29kZWBdOiBuZXdDb2RlLFxuICAgICAgICAgICAgW2Ake2ZpZWxkfV9uYW1lYF06ICcnLFxuICAgICAgICB9KSk7XG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ2NsaWVudCcpIHNldENsaWVudFRheGVzKFtdKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCA9IGFzeW5jIChmaWVsZDogc3RyaW5nLCBjb25maWc6IE1vZHVsZUNvbmZpZzxhbnk+KSA9PiB7XG4gICAgICAgIGNvbnN0IGNvZGVWYWx1ZSA9IGZvcm1EYXRhW2Ake2ZpZWxkfV9jb2RlYCBhcyBrZXlvZiBGaW5hbmNpYWxOb3RlXSBhcyBzdHJpbmc7XG4gICAgICAgIGlmICghY29kZVZhbHVlKSByZXR1cm47XG4gICAgICAgIGlmICghY29uZmlnPy5yZWxhdGlvbmFsRmllbGRzKSByZXR1cm4gdG9hc3QuZXJyb3IoYENvbmZpZ3VyYWNpw7NuIHJlbGFjaW9uYWwgZmFsdGFudGUgcGFyYSAke2ZpZWxkfWApO1xuXG4gICAgICAgIGNvbnN0IHsgZW5kcG9pbnQsIHJlbGF0aW9uYWxGaWVsZHMgfSA9IGNvbmZpZztcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBzZWFyY2hCeUZpZWxkPGFueT4oZW5kcG9pbnQsIFt7IGZpZWxkTmFtZTogcmVsYXRpb25hbEZpZWxkcy5jb2RlRmllbGQgYXMgc3RyaW5nLCB2YWx1ZTogY29kZVZhbHVlIH1dKTtcbiAgICAgICAgICAgIGlmIChpdGVtKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgYXBwbHlIZWFkZXJTZWxlY3Rpb24oZmllbGQsIGl0ZW0pO1xuICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYCcke2l0ZW1bcmVsYXRpb25hbEZpZWxkcy5uYW1lRmllbGQgYXMgc3RyaW5nXX0nIHNlbGVjY2lvbmFkby5gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdG9hc3QuZXJyb3IoYE5vIHNlIGVuY29udHLDsyDDrXRlbSBjb24gZXNlIGPDs2RpZ28uYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvciBhbCBidXNjYXIgcG9yIGPDs2RpZ28uXCIpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUhlYWRlckNsZWFyID0gKGZpZWxkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIFtgJHtmaWVsZH1faWRgXTogbnVsbCxcbiAgICAgICAgICAgIFtgJHtmaWVsZH1fY29kZWBdOiBudWxsLFxuICAgICAgICAgICAgW2Ake2ZpZWxkfV9uYW1lYF06IG51bGwsXG4gICAgICAgIH0pKTtcbiAgICAgICAgaWYgKGZpZWxkID09PSAnY2xpZW50Jykgc2V0Q2xpZW50VGF4ZXMoW10pO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGVycyBkZSBpbXB1ZXN0b3MgcG9yIGl0ZW0gcmVtb3ZpZG9zIC0gaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgc2llbXByZSBmYWxzZVxuXG4gICAgLy8gaGFuZGxlVGF4TW9kZUNoYW5nZSByZW1vdmlkbyAtIGhhc19pdGVtX2xldmVsX3RheGVzIHNpZW1wcmUgZmFsc2VcblxuICAgIC8vIEhhbmRsZXIgcGFyYSBndWFyZGFyXG4gICAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKGlzU2F2aW5nKSByZXR1cm47XG5cbiAgICAgICAgaWYgKCFmb3JtRGF0YS5jbGllbnRfaWQgfHwgIWZvcm1EYXRhLmN1cnJlbmN5X2lkKSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihcIkNsaWVudGUgeSBNb25lZGEgc29uIG9ibGlnYXRvcmlvcy5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCB8fCBpdGVtcy5zb21lKGl0ID0+ICFpdC5kZXNjcmlwdGlvbj8udHJpbSgpKSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJDYWRhIMOtdGVtIGRlYmUgdGVuZXIgZGVzY3JpcGNpw7NuLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWZvcm1EYXRhLnNlcmllcykge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoXCJMYSBzZXJpZSBlcyBvYmxpZ2F0b3JpYS5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBWZXJpZmljYXIgc2kgZXMgbm90YSBpbmRlcGVuZGllbnRlIHkgbW9zdHJhciBhZHZlcnRlbmNpYVxuICAgICAgICBpZiAoIWZvcm1EYXRhLnNhbGVzX2ludm9pY2VfaWQpIHtcbiAgICAgICAgICAgIHNob3dDb25maXJtYXRpb25Nb2RhbCh7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICdOb3RhIEZpbmFuY2llcmEgSW5kZXBlbmRpZW50ZScsXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogJ0VzdMOhIGNyZWFuZG8gdW5hIG5vdGEgZmluYW5jaWVyYSBzaW4gZmFjdHVyYSByZWxhY2lvbmFkYS4gwr9EZXNlYSBjb250aW51YXI/JyxcbiAgICAgICAgICAgICAgICBvbkNvbmZpcm06IHBlcmZvcm1TYXZlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBwZXJmb3JtU2F2ZSgpO1xuICAgIH07XG5cbiAgICBjb25zdCBwZXJmb3JtU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKGlzU2F2aW5nKSByZXR1cm47XG5cbiAgICAgICAgc2V0SXNTYXZpbmcodHJ1ZSk7XG4gICAgICAgIGNvbnN0IGNsZWFuSXRlbXMgPSBpdGVtcy5tYXAoKGl0LCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHsgdGVtcElkLCAuLi5yZXN0IH0gPSBpdDtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLnJlc3QsIGNvbmNlcHRfY29kZTogJ05PVEEtRklOQU5DSUVSQScsIGxpbmVfbnVtYmVyOiBpZHggKyAxIH07XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBzYW5pdGl6ZWQgPSBpc0NsaWVudFRheEV4ZW1wdFxuICAgICAgICAgICAgPyBzYW5pdGl6ZVRheFBheWxvYWRGb3JFeGVtcHRDbGllbnQoe1xuICAgICAgICAgICAgICAgIHRheGVzOiBhcHBsaWVkVGF4ZXMsXG4gICAgICAgICAgICAgICAgaXRlbXM6IGNsZWFuSXRlbXMsXG4gICAgICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHdpdGhvdXR0YXhfYW1vdW50OiBmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICA6IG51bGw7XG5cbiAgICAgICAgY29uc3QgcGF5bG9hZDogRmluYW5jaWFsTm90ZSA9IHtcbiAgICAgICAgICAgIC4uLihmb3JtRGF0YSBhcyBGaW5hbmNpYWxOb3RlKSxcbiAgICAgICAgICAgIGNvbmNlcHQ6IChmb3JtRGF0YSBhcyBGaW5hbmNpYWxOb3RlKS5jb25jZXB0ID8/ICcnLFxuICAgICAgICAgICAgaXRlbXM6IHNhbml0aXplZD8uaXRlbXMgPz8gY2xlYW5JdGVtcyxcbiAgICAgICAgICAgIHRvdGFsX2Ftb3VudDogY2FsY3VsYXRlZFRvdGFscy50b3RhbCxcbiAgICAgICAgICAgIHdpdGhvdXR0YXhfYW1vdW50OiBzYW5pdGl6ZWQ/LndpdGhvdXR0YXhfYW1vdW50ID8/IChmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudCA/PyAwKSxcbiAgICAgICAgICAgIGVtaXRfbm93OiB0cnVlLFxuICAgICAgICAgICAgaGFzX2l0ZW1fbGV2ZWxfdGF4ZXM6IGZhbHNlLFxuICAgICAgICAgICAgdGF4ZXM6IHNhbml0aXplZCA/IHNhbml0aXplZC50YXhlcyA6IGFwcGxpZWRUYXhlcy5maWx0ZXIodCA9PiBOdW1iZXIodC5hbW91bnQpID4gMCksXG4gICAgICAgIH07XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHNhdmVkID0gYXdhaXQgc2F2ZUl0ZW0ocGF5bG9hZCk7XG4gICAgICAgICAgICBpZiAoc2F2ZWQpIHtcbiAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFwiTm90YSBGaW5hbmNpZXJhIGd1YXJkYWRhIGNvbiDDqXhpdG8uXCIpO1xuICAgICAgICAgICAgICAgIG5hdmlnYXRlKGdldExpc3RSZXR1cm5QYXRoKG5vdGFzRmluYW5jaWVyYXNNb2R1bGVDb25maWcuYmFzZVJvdXRlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoYEVycm9yIGFsIGd1YXJkYXI6ICR7ZS5tZXNzYWdlIHx8ICdFcnJvciBkZXNjb25vY2lkbyd9YCk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc1NhdmluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKGxvYWRpbmdEYXRhKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuXG4gICAgY29uc3QgdG90YWxMYWJlbFN0eWxlID0gXCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIjtcbiAgICBjb25zdCB0b3RhbFZhbHVlU3R5bGUgPSBcInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtcmlnaHRcIjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LTYgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgIHtpc1NhdmluZyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHotNTAgYmctd2hpdGUvODAgcm91bmRlZC1sZyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiYWNrZHJvcC1ibHVyLVsxcHhdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHAtNiBiZy13aGl0ZSBzaGFkb3cteGwgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmRpZ28tMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFTcGlubmVyIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWluZGlnby02MDAgYW5pbWF0ZS1zcGluIG1iLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5Db25lY3RhbmRvIGNvbiBBUkNBPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBhbmltYXRlLXB1bHNlXCI+T2J0ZW5pZW5kbyBDQUUgeSB2YWxpZGFuZG8gZGF0b3MuLi48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAge21vZGUgPT09ICdjcmVhdGUnID8gJ051ZXZhIE5vdGEgRmluYW5jaWVyYScgOiBgRWRpdGFyIE5vdGEgIyR7Zm9ybURhdGEudm91Y2hlcl9udW1iZXJ9YH1cbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIHsvKiBDQUJFQ0VSQSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICAgICAgICAgIHsvKiBDT0xVTU5BIDEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlRpcG8gKCopPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHlwZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnR5cGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUhlYWRlckNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiREVCSVRcIj5Ob3RhIGRlIETDqWJpdG88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1JFRElUXCI+Tm90YSBkZSBDcsOpZGl0bzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RmFjdHVyYSBSZWxhY2lvbmFkYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtmb3JtRGF0YS5zYWxlc19pbnZvaWNlX251bWJlciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnNhbGVzX2ludm9pY2VfbnVtYmVyID8gYEZhY3R1cmEgJHtmb3JtRGF0YS5zYWxlc19pbnZvaWNlX251bWJlcn1gIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBzYWxlc19pbnZvaWNlX251bWJlcjogYyB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlU3VibWl0PXtoYW5kbGVJbnZvaWNlQ29kZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlYXJjaENsaWNrPXsoKSA9PiBoYW5kbGVPcGVuU2VhcmNoKCdzYWxlc19pbnZvaWNlJywgc2FsZXNJbnZvaWNlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhckNsaWNrPXtoYW5kbGVDbGVhckludm9pY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtdC0xIHRleHQteHMgdGV4dC1ibHVlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUluZm9DaXJjbGUgY2xhc3NOYW1lPVwibXItMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+T3BjaW9uYWwuIFNpIG5vIHNlIHNlbGVjY2lvbmEsIHNlIGNyZWFyw6EgdW5hIG5vdGEgaW5kZXBlbmRpZW50ZS48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5TZXJpZSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzZXJpZXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zZXJpZXMgfHwgJ0InfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVIZWFkZXJDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyEhZm9ybURhdGEuc2FsZXNfaW52b2ljZV9pZH0gLy8gRGVzaGFiaWxpdGFkbyBzaSBoYXkgZmFjdHVyYSAoc2UgY29waWEgYXV0b23DoXRpY2FtZW50ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtIGJnLXdoaXRlIGRpc2FibGVkOmJnLWdyYXktMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQVwiPkE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQlwiPkI8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ1wiPkM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnNhbGVzX2ludm9pY2VfaWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+U2VyaWUgY29waWFkYSBkZSBsYSBmYWN0dXJhIHJlbGFjaW9uYWRhPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5GZWNoYSBFbWlzacOzbiAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJpc3N1ZV9kYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuaXNzdWVfZGF0ZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIHNtOnRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQ09MVU1OQSAyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5DbGllbnRlICgqKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRpb25hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZVZhbHVlPXtmb3JtRGF0YS5jbGllbnRfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLmNsaWVudF9uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZUNoYW5nZT17KGMpID0+IGhhbmRsZUhlYWRlckNvZGVDaGFuZ2UoJ2NsaWVudCcsIGMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29kZVN1Ym1pdD17KCkgPT4gaGFuZGxlSGVhZGVyQ29kZVN1Ym1pdCgnY2xpZW50JywgY2xpZW50ZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5TZWFyY2goJ2NsaWVudCcsIGNsaWVudGVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IGhhbmRsZUhlYWRlckNsZWFyKCdjbGllbnQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VmVuZGVkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuc2FsZXNwZXJzb25fY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLnNhbGVzcGVyc29uX25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnc2FsZXNwZXJzb24nLCBjKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ3NhbGVzcGVyc29uJywgdmVuZGVkb3Jlc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3BlblNlYXJjaCgnc2FsZXNwZXJzb24nLCB2ZW5kZWRvcmVzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IGhhbmRsZUhlYWRlckNsZWFyKCdzYWxlc3BlcnNvbicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Db21wcmFkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuYnV5ZXJfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLmJ1eWVyX25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnYnV5ZXInLCBjKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ2J1eWVyJywgY29tcHJhZG9yZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VhcmNoQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5TZWFyY2goJ2J1eWVyJywgY29tcHJhZG9yZXNNb2R1bGVDb25maWcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJDbGljaz17KCkgPT4gaGFuZGxlSGVhZGVyQ2xlYXIoJ2J1eWVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDT0xVTU5BIDMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk1vbmVkYSAoKik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFJlbGF0aW9uYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVWYWx1ZT17Zm9ybURhdGEuY3VycmVuY3lfY29kZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lVmFsdWU9e2Zvcm1EYXRhLmN1cnJlbmN5X25hbWUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db2RlQ2hhbmdlPXsoYykgPT4gaGFuZGxlSGVhZGVyQ29kZUNoYW5nZSgnY3VycmVuY3knLCBjKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvZGVTdWJtaXQ9eygpID0+IGhhbmRsZUhlYWRlckNvZGVTdWJtaXQoJ2N1cnJlbmN5JywgbW9uZWRhc01vZHVsZUNvbmZpZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWFyY2hDbGljaz17KCkgPT4gaGFuZGxlT3BlblNlYXJjaCgnY3VycmVuY3knLCBtb25lZGFzTW9kdWxlQ29uZmlnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsZWFyQ2xpY2s9eygpID0+IGhhbmRsZUhlYWRlckNsZWFyKCdjdXJyZW5jeScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5UaXBvIGRlIENhbWJpbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImV4Y2hhbmdlX3JhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5leGNoYW5nZV9yYXRlID8/IDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1wdHlXaGVuWmVybz17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGV4Y2hhbmdlX3JhdGU6IG51bSB8fCAxIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlZhbG9yIG5vIGdyYXZhZG8gKC0pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVjaW1hbElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ3aXRob3V0dGF4X2Ftb3VudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS53aXRob3V0dGF4X2Ftb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHdpdGhvdXR0YXhfYW1vdW50OiBudW0gPz8gMCB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gc206dGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIMONVEVNUyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItNFwiPsONdGVtczwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gYm9yZGVyIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkRlc2NyaXBjacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+Q2FudC48L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtcmlnaHQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlAuIFVuaXQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LXJpZ2h0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5TdWJ0b3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdy0xMFwiPjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Jvdy50ZW1wSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3cuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlVXBkYXRlSXRlbShyb3cudGVtcElkLCAnZGVzY3JpcHRpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBJbnRlcmVzZXMgcG9yIG1vcmEgZW4gZmFjdHVyYSAjMDAwMS0wMDAwMDEyM1wiIGF1dG9Db21wbGV0ZT1cIm9mZlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Jvdy5xdWFudGl0eX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVJdGVtKHJvdy50ZW1wSWQsICdxdWFudGl0eScsIG51bSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjAgcHgtMiBweS0xIHRleHQtcmlnaHQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERlY2ltYWxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3cudW5pdF9wcmljZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e251bSA9PiBoYW5kbGVVcGRhdGVJdGVtKHJvdy50ZW1wSWQsICd1bml0X3ByaWNlJywgbnVtKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zMiBweC0yIHB5LTEgdGV4dC1yaWdodCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1zbSBmb250LW1lZGl1bVwiPntmb3JtYXRWYWx1ZShOdW1iZXIocm93LnF1YW50aXR5KSAqIE51bWJlcihyb3cudW5pdF9wcmljZSksICdjdXJyZW5jeScpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlSXRlbShyb3cudGVtcElkKX0gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMFwiIHRpdGxlPVwiUXVpdGFyIMOtdGVtXCI+PEZhVHJhc2ggLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZUFkZEl0ZW19IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgbXQtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctZ3JheS02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8RmFQbHVzIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiIC8+IEHDsWFkaXIgw610ZW1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gREUgVE9UQUxFUyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Ob3RhczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3Rlc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSGVhZGVyQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCIgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBzbTp0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIGFwcGxpZWRUYXhlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPkltcHVlc3RvcyBHbG9iYWxlcyBBcGxpY2Fkb3M8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBsaWVkVGF4ZXMubWFwKCh0YXgsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT57Zm9ybWF0QXBwbGllZFRheFRpdGxlKHRheCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pntmb3JtYXRWYWx1ZSh0YXguYW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5TdWJ0b3RhbDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuc3VidG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkVG90YWxzLmRpc2NvdW50QW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5EZXNjdWVudG86PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxWYWx1ZVN0eWxlfT4tIHtmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLmRpc2NvdW50QW1vdW50LCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiBjYWxjdWxhdGVkVG90YWxzLndpdGhvdXR0YXhfYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSB0ZXh0LXJlZC02MDBgfT5WYWxvciBObyBHcmF2YWRvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3RvdGFsVmFsdWVTdHlsZX0gdGV4dC1yZWQtNjAwYH0+LSB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy53aXRob3V0dGF4X2Ftb3VudCwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IGZvbnQtc2VtaWJvbGRgfT5CYXNlIEltcG9uaWJsZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxWYWx1ZVN0eWxlfSBmb250LXNlbWlib2xkYH0+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudGF4QmFzZSwgJ2N1cnJlbmN5Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5JbXB1ZXN0b3MgKEdsb2JhbCk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+KyB7Zm9ybWF0VmFsdWUoY2FsY3VsYXRlZFRvdGFscy50b3RhbFRheGVzLCAnY3VycmVuY3knKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+VG90YWw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+e2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWwsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJPVE9ORVJBICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC02IGJvcmRlci10XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNGaW5hbmNpZXJhc01vZHVsZUNvbmZpZy5iYXNlUm91dGUpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGhvdmVyOmJnLWdyYXktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgZGlzYWJsZWQ6b3BhY2l0eS01MCAke2lzU2F2aW5nID8gJ2JnLWluZGlnby01MDAgY3Vyc29yLXdhaXQnIDogJ2JnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCd9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpc1NhdmluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdy01IGgtNSBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9jZXNhbmRvIGVuIEFSQ0EuLi5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFTYXZlIGNsYXNzTmFtZT1cIm1yLTJcIiAvPiBHdWFyZGFyIE5vdGFcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNb2RhbGVzICovfVxuICAgICAgICAgICAge2lzTW9kYWxPcGVuICYmIG1vZGFsQ29uZmlnICYmIChcbiAgICAgICAgICAgICAgICA8U2VhcmNoTW9kYWxcbiAgICAgICAgICAgICAgICAgICAgaXNPcGVuPXtpc01vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17aGFuZGxlU2VsZWN0RnJvbU1vZGFsfVxuICAgICAgICAgICAgICAgICAgICBjb25maWc9e21vZGFsQ29uZmlnfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogTW9kYWwgZGUgaW1wdWVzdG9zIHBvciBpdGVtIHJlbW92aWRvIC0gaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMgc2llbXByZSBmYWxzZSAqL31cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG5cbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbm90YXNfZmluYW5jaWVyYXMvcGFnZXMvTm90YXNGaW5hbmNpZXJhc0Zvcm1QYWdlLnRzeCJ9