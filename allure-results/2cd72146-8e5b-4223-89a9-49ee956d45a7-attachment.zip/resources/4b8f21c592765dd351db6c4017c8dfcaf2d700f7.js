import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transportes/pages/TransportesListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/transportes/pages/TransportesListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { transportesModuleConfig } from "/src/features/transportes/transportes.config.tsx";
export const TransportesListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(transportesModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/transportes/pages/TransportesListPage.tsx",
    lineNumber: 40,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: transportesModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? ""
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/transportes/pages/TransportesListPage.tsx",
      lineNumber: 43,
      columnNumber: 5
    },
    this
  );
};
_s(TransportesListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = TransportesListPage;
var _c;
$RefreshReg$(_c, "TransportesListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/transportes/pages/TransportesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/transportes/pages/TransportesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLCtCQUFnRDtBQUVsRCxhQUFNQyxzQkFBc0JBLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZixRQUFvQkMsdUJBQXVCO0FBRS9DLE1BQUlNLE1BQU8sUUFBTyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCQSxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQztBQUV2RCxTQUNJO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDRyxRQUFRTjtBQUFBQSxNQUNSLG9CQUFvQkc7QUFBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVSTtBQUFBQSxNQUNWLFFBQVFDO0FBQUFBLE1BQ1I7QUFBQSxNQUNBO0FBQUEsTUFDQSxjQUFjRztBQUFBQSxNQUNkLFlBQVlDO0FBQUFBLE1BQ1osVUFBVUM7QUFBQUEsTUFDVixZQUFZQyxhQUFhQyxRQUFRO0FBQUE7QUFBQSxJQVpyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZd0M7QUFHaEQ7QUFBRWIsR0FsQ1dELHFCQUFtQjtBQUFBLFVBY3hCRixPQUFPO0FBQUE7QUFBQWlCLEtBZEZmO0FBQW1CLElBQUFlO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHZW5lcmljTGlzdFBhZ2UiLCJ1c2VDcnVkIiwidHJhbnNwb3J0ZXNNb2R1bGVDb25maWciLCJUcmFuc3BvcnRlc0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRyYW5zcG9ydGVzTGlzdFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlbmVyaWNMaXN0UGFnZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL0dlbmVyaWNMaXN0UGFnZSc7XG5pbXBvcnQgeyB1c2VDcnVkIH0gZnJvbSAnLi4vLi4vLi4vaG9va3MvdXNlQ3J1ZCc7XG5pbXBvcnQgeyB0cmFuc3BvcnRlc01vZHVsZUNvbmZpZywgdHlwZSBUcmFuc3BvcnRlIH0gZnJvbSAnLi4vdHJhbnNwb3J0ZXMuY29uZmlnJztcblxuZXhwb3J0IGNvbnN0IFRyYW5zcG9ydGVzTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgbG9hZGluZyxcbiAgICAgICAgaXNBcHBlbmRpbmcsXG4gICAgICAgIGVycm9yLFxuICAgICAgICBkZWxldGVJdGVtLFxuICAgICAgICBoYW5kbGVTb3J0LFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sXG4gICAgICAgIGhhbmRsZVBhZ2VDaGFuZ2UsXG4gICAgICAgIGhhbmRsZUxvYWRNb3JlLFxuICAgICAgICBoYW5kbGVTZWFyY2gsXG4gICAgICAgIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxUcmFuc3BvcnRlPih0cmFuc3BvcnRlc01vZHVsZUNvbmZpZyk7XG5cbiAgICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPntlcnJvcn08L2Rpdj47XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8R2VuZXJpY0xpc3RQYWdlPFRyYW5zcG9ydGU+XG4gICAgICAgICAgICBjb25maWc9e3RyYW5zcG9ydGVzTW9kdWxlQ29uZmlnfVxuICAgICAgICAgICAgcGFnaW5hdGlvblJlc3BvbnNlPXtyZXNwb25zZX1cbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgICBpc0FwcGVuZGluZz17aXNBcHBlbmRpbmd9XG4gICAgICAgICAgICBvbkRlbGV0ZT17ZGVsZXRlSXRlbX1cbiAgICAgICAgICAgIG9uU29ydD17aGFuZGxlU29ydH1cbiAgICAgICAgICAgIHNvcnRCeT17c29ydEJ5fVxuICAgICAgICAgICAgc29ydERpcmVjdGlvbj17c29ydERpcmVjdGlvbn1cbiAgICAgICAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgICAgICAgIG9uTG9hZE1vcmU9e2hhbmRsZUxvYWRNb3JlfVxuICAgICAgICAgICAgb25TZWFyY2g9e2hhbmRsZVNlYXJjaH1cbiAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFBhcmFtcy50ZXJtID8/ICcnfVxuICAgICAgICAvPlxuICAgICk7XG59OyJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvdHJhbnNwb3J0ZXMvcGFnZXMvVHJhbnNwb3J0ZXNMaXN0UGFnZS50c3gifQ==