import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/leads/pages/LeadsListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/leads/pages/LeadsListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { leadsModuleConfig } from "/src/features/leads/leads.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
export const LeadsListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(leadsModuleConfig);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/leads/pages/LeadsListPage.tsx",
    lineNumber: 41,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: leadsModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? ""
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/leads/pages/LeadsListPage.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
};
_s(LeadsListPage, "9ndbT1JT8SUQ3PnODSHlVmUht4k=", false, function() {
  return [useCrud];
});
_c = LeadsListPage;
var _c;
$RefreshReg$(_c, "LeadsListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/leads/pages/LeadsListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/leads/pages/LeadsListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQnRCLFNBQVNBLHVCQUF1QjtBQUNoQyxTQUFTQyx5QkFBb0M7QUFDN0MsU0FBU0MsZUFBZTtBQUVqQixhQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNO0FBQUEsSUFDRkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDSixJQUFJZCxRQUFjRCxpQkFBaUI7QUFFbkMsTUFBSU8sTUFBTyxRQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBRXZELFNBQ0k7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNHLFFBQVFQO0FBQUFBLE1BQ1Isb0JBQW9CSTtBQUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVVJO0FBQUFBLE1BQ1YsUUFBUUM7QUFBQUEsTUFDUjtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQWNHO0FBQUFBLE1BQ2QsWUFBWUM7QUFBQUEsTUFDWixVQUFVQztBQUFBQSxNQUNWLFlBQVlDLGFBQWFDLFFBQVE7QUFBQTtBQUFBLElBWnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVl3QztBQUdoRDtBQUFFYixHQWxDV0QsZUFBYTtBQUFBLFVBY2xCRCxPQUFPO0FBQUE7QUFBQWdCLEtBZEZmO0FBQWEsSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkdlbmVyaWNMaXN0UGFnZSIsImxlYWRzTW9kdWxlQ29uZmlnIiwidXNlQ3J1ZCIsIkxlYWRzTGlzdFBhZ2UiLCJfcyIsInJlc3BvbnNlIiwibG9hZGluZyIsImlzQXBwZW5kaW5nIiwiZXJyb3IiLCJkZWxldGVJdGVtIiwiaGFuZGxlU29ydCIsInNvcnRCeSIsInNvcnREaXJlY3Rpb24iLCJoYW5kbGVQYWdlQ2hhbmdlIiwiaGFuZGxlTG9hZE1vcmUiLCJoYW5kbGVTZWFyY2giLCJzZWFyY2hQYXJhbXMiLCJ0ZXJtIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZHNMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgbGVhZHNNb2R1bGVDb25maWcsIHR5cGUgTGVhZCB9IGZyb20gJy4uL2xlYWRzLmNvbmZpZy50c3gnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuXG5leHBvcnQgY29uc3QgTGVhZHNMaXN0UGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7XG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgICBsb2FkaW5nLFxuICAgICAgICBpc0FwcGVuZGluZyxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIGRlbGV0ZUl0ZW0sXG4gICAgICAgIGhhbmRsZVNvcnQsXG4gICAgICAgIHNvcnRCeSxcbiAgICAgICAgc29ydERpcmVjdGlvbixcbiAgICAgICAgaGFuZGxlUGFnZUNoYW5nZSxcbiAgICAgICAgaGFuZGxlTG9hZE1vcmUsXG4gICAgICAgIGhhbmRsZVNlYXJjaCxcbiAgICAgICAgc2VhcmNoUGFyYW1zLFxuICAgIH0gPSB1c2VDcnVkPExlYWQ+KGxlYWRzTW9kdWxlQ29uZmlnKTtcblxuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+e2Vycm9yfTwvZGl2PjtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxHZW5lcmljTGlzdFBhZ2U8TGVhZD5cbiAgICAgICAgICAgIGNvbmZpZz17bGVhZHNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfVxuICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgc2VhcmNoVGVybT17c2VhcmNoUGFyYW1zLnRlcm0gPz8gJyd9XG4gICAgICAgIC8+XG4gICAgKTtcbn07XG4iXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL2xlYWRzL3BhZ2VzL0xlYWRzTGlzdFBhZ2UudHN4In0=