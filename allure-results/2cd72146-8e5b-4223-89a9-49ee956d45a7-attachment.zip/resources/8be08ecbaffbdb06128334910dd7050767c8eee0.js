import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=cc4fbb62";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cc4fbb62"; const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];
import { useCrudItem } from "/src/hooks/useCrudItem.ts";
import { notasCreditoModuleConfig } from "/src/features/notas_credito/notas_credito.config.tsx";
import { LoadingSpinner } from "/src/components/ui/LoadingSpinner.tsx";
import { IoArrowBack, IoBan, IoPrint, IoDocumentText } from "/node_modules/.vite/deps/react-icons_io5.js?v=cc4fbb62";
import { FaSpinner, FaWhatsapp, FaEnvelope } from "/node_modules/.vite/deps/react-icons_fa.js?v=cc4fbb62";
import { formatValue, formatLinkedSalesInvoiceRef } from "/src/utils/formatters.ts";
import { isClientLeyExportacionTdfExempt } from "/src/utils/clientTaxExemption.ts";
import { patch } from "/src/services/apiService.ts";
import { beginPdfPreview, finishPdfPreview } from "/src/utils/blobHelper.ts";
import { toast } from "/node_modules/.vite/deps/react-toastify.js?v=cc4fbb62";
import { getListReturnPath } from "/src/utils/listReturnNavigation.ts";
const getItemTaxTotal = (item) => {
  if (!item.taxes || item.taxes.length === 0) return 0;
  return item.taxes.reduce((sum, tax) => sum + Number(tax.amount), 0);
};
export const NotasCreditoDetailPage = () => {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { item: creditNote, loading, error } = useCrudItem(notasCreditoModuleConfig, id);
  const [isPrinting, setIsPrinting] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const isClientTaxExempt = useMemo(
    () => isClientLeyExportacionTdfExempt(creditNote?.client),
    [creditNote?.client]
  );
  const calculatedTotals = useMemo(() => {
    if (!creditNote) return { subtotal: 0, totalItemDiscounts: 0, globalDiscountAmount: 0, taxBase: 0, totalTaxes: 0 };
    const items = creditNote.items || [];
    const subtotal = items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unit_price), 0);
    const totalItemDiscounts = items.reduce((sum, item) => sum + (Number(item.discount_amount) || 0), 0);
    const globalDiscountAmount = 0;
    const taxBase = subtotal - totalItemDiscounts - globalDiscountAmount;
    let totalTaxes = 0;
    if (!isClientTaxExempt) {
      if (creditNote.has_item_level_taxes) {
        totalTaxes = items.reduce((sum, item) => sum + getItemTaxTotal(item), 0);
      } else {
        totalTaxes = (creditNote.taxes || []).reduce((sum, tax) => sum + Number(tax.amount), 0);
      }
    }
    return { subtotal, totalItemDiscounts, globalDiscountAmount, taxBase, totalTaxes };
  }, [creditNote, isClientTaxExempt]);
  const emailLink = useMemo(() => {
    const email = creditNote?.client?.email;
    if (!email) return void 0;
    const total = creditNote ? formatValue(creditNote.total_amount, "currency") : "$0";
    const number = `${creditNote?.series || ""}-${creditNote?.voucher_number}`;
    const params = new URLSearchParams();
    params.append("subject", `Nota de Crédito ${number} - ${creditNote?.client?.name}`);
    params.append("body", `Estimado cliente, adjuntamos el detalle de su Nota de Crédito ${number} por un total de ${total}.`);
    const queryString = params.toString().replace(/\+/g, "%20");
    return `mailto:${email}?${queryString}`;
  }, [creditNote]);
  const whatsappLink = useMemo(() => {
    const phone = creditNote?.client?.phone;
    if (!phone) return "#";
    const cleanPhone = phone.replace(/[^0-9]/g, "");
    const number = `${creditNote?.series || ""}-${creditNote?.voucher_number}`;
    const message = `Hola ${creditNote.client?.name}, le enviamos los detalles de su Nota de Crédito ${number}. Total: ${formatValue(creditNote.total_amount, "currency")}`;
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  }, [creditNote]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
    lineNumber: 105,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: [
    "Error al cargar la nota de crédito: ",
    error
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
    lineNumber: 106,
    columnNumber: 21
  }, this);
  if (!creditNote) return /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500", children: "No se encontró el documento." }, void 0, false, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
    lineNumber: 107,
    columnNumber: 27
  }, this);
  const getStatusText = (status) => {
    switch (String(status)) {
      case "1":
        return "Pendiente";
      // O 'Emitida' según tu backend
      case "2":
        return "Aplicada";
      case "0":
        return "Anulada";
      case "VOID":
        return "Anulada";
      case "ISSUED":
        return "Emitida (ARCA)";
      default:
        return "Borrador";
    }
  };
  const getStatusClassName = (status) => {
    switch (String(status)) {
      case "1":
        return "bg-yellow-100 text-yellow-800";
      case "2":
        return "bg-green-100 text-green-800";
      case "0":
        return "bg-red-100 text-red-800";
      case "VOID":
        return "bg-red-100 text-red-800";
      case "ISSUED":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const totalLabelStyle = "text-sm font-medium text-gray-600";
  const totalValueStyle = "text-sm font-semibold text-gray-900 text-right";
  const handleCancelCreditNote = async () => {
    if (!creditNote) return;
    const confirmMessage = `¿Está seguro de que desea ANULAR la Nota de Crédito ${creditNote.series}-${creditNote.voucher_number}?

Esta acción es irreversible.`;
    if (!window.confirm(confirmMessage)) return;
    setIsCancelling(true);
    try {
      await patch(notasCreditoModuleConfig.endpoint, creditNote.id, {
        status: "VOID"
        // O '0', ajusta según tu backend para anular NC
      });
      toast.success("Nota de crédito anulada correctamente.");
      window.location.reload();
    } catch (err) {
      console.error(err);
      toast.error(`Error al anular: ${err.message || "Error desconocido"}`);
    } finally {
      setIsCancelling(false);
    }
  };
  const handlePrint = async () => {
    if (!creditNote) return;
    const session = beginPdfPreview();
    if (!session) {
      toast.error("Permití ventanas emergentes para ver el PDF.");
      return;
    }
    setIsPrinting(true);
    try {
      await finishPdfPreview(session, `/credit-notes/${creditNote.id}/pdf`);
    } catch (error2) {
      if (!session.window.closed) session.window.close();
      console.error("Error al generar el PDF:", error2);
      toast.error("No se pudo generar el comprobante PDF.");
    } finally {
      setIsPrinting(false);
    }
  };
  const handleLinkClick = (e, type) => {
    const data = type === "email" ? creditNote?.client?.email : creditNote?.client?.phone;
    if (!data) {
      e.preventDefault();
      toast.warn(`El cliente no tiene ${type === "email" ? "email" : "teléfono"} registrado.`);
    }
  };
  const isCancelled = String(creditNote.status) === "0" || String(creditNote.status) === "VOID";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-lg shadow-sm sm:p-6 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pb-4 mb-4 border-b sm:flex sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(getListReturnPath(notasCreditoModuleConfig.baseRoute)), className: "p-2 text-gray-500 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(IoArrowBack, { className: "w-6 h-6" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 193,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 192,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold leading-6 text-gray-900", children: [
            "NC: ",
            creditNote.series,
            "-",
            creditNote.voucher_number
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 196,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClassName(creditNote.status)}`, children: getStatusText(creditNote.status) }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 199,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 195,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 191,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:mt-0 sm:ml-4 flex flex-wrap gap-2", children: [
        creditNote.client && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: emailLink,
              onClick: (e) => handleLinkClick(e, "email"),
              className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 cursor-pointer",
              title: "Enviar por Email",
              children: /* @__PURE__ */ jsxDEV(FaEnvelope, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 215,
                columnNumber: 33
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 209,
              columnNumber: 29
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "a",
            {
              href: whatsappLink,
              onClick: (e) => handleLinkClick(e, "whatsapp"),
              target: "_blank",
              rel: "noopener noreferrer",
              className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 cursor-pointer",
              title: "Enviar por WhatsApp",
              children: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 225,
                columnNumber: 33
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 217,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 208,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrint,
            disabled: isPrinting,
            className: "inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-wait",
            children: isPrinting ? /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 animate-spin" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 237,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(IoPrint, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 239,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 230,
            columnNumber: 21
          },
          this
        ),
        !isCancelled && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleCancelCreditNote,
            disabled: isCancelling,
            className: "inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700 focus:outline-none disabled:opacity-70 disabled:cursor-wait",
            children: isCancelling ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(FaSpinner, { className: "w-5 h-5 mr-2 animate-spin" }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 252,
                columnNumber: 37
              }, this),
              "Anulando..."
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 251,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(IoBan, { className: "w-5 h-5 mr-2 -ml-1" }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 257,
                columnNumber: 37
              }, this),
              "Anular NC"
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 256,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 244,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 206,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
      lineNumber: 190,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2 lg:grid-cols-4", children: [
      creditNote.cae_number && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "CAE Autorizado" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 271,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-xl font-mono font-bold text-green-900 tracking-wider", children: creditNote.cae_number }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 272,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 270,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1 bg-green-50 p-3 rounded-md border border-green-200", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-xs font-bold text-green-700 uppercase tracking-wide", children: "Vencimiento CAE" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 275,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-lg font-medium text-green-900", children: formatValue(creditNote.cae_due_date, "date") }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 276,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 274,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 269,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Cliente" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 281,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: /* @__PURE__ */ jsxDEV(Link, { to: `/clientes/${creditNote.client?.id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: creditNote.client?.name || creditNote.client_name || "N/A" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 283,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 282,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 280,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Fecha Emisión" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 289,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: formatValue(creditNote.issue_date, "date") }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 290,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 288,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Factura Asociada" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 295,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.sales_invoice ? /* @__PURE__ */ jsxDEV(Link, { to: `/facturas-de-venta/${creditNote.sales_invoice.id}`, className: "inline-flex items-center text-indigo-600 hover:underline", children: [
          /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "mr-1" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 299,
            columnNumber: 33
          }, this),
          formatLinkedSalesInvoiceRef(creditNote.sales_invoice)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 298,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: creditNote.sales_invoice_id ? `ID: ${creditNote.sales_invoice_id}` : "Sin Referencia" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 303,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 296,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 294,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Comprobante Orig." }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 309,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.document_voucher || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 310,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 308,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Vendedor" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 313,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.salesperson?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 314,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 312,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Transporte" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 317,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.transport?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 318,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 316,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Moneda" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 321,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.currency?.name || "-" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 322,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 320,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Tipo de Cambio" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 325,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.exchange_rate ? Number(creditNote.exchange_rate).toFixed(2) : "1.00" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 326,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 324,
        columnNumber: 17
      }, this),
      creditNote.afip_pos && /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Punto de Venta" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 330,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900", children: creditNote.afip_pos }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 331,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 329,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
      lineNumber: 267,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium leading-6 text-gray-900", children: "Items de la Nota de Crédito" }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 338,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 -mx-4 overflow-hidden border border-gray-200 sm:mx-0 sm:rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-300", children: [
        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6", children: "Artículo" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 343,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Cant." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 344,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "P. Unit." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 345,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900 hidden", children: "Desc." }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 346,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Subtotal" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 347,
            columnNumber: 33
          }, this),
          !isClientTaxExempt && creditNote.has_item_level_taxes && /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3.5 text-right text-sm font-semibold text-gray-900", children: "Impuestos" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 348,
            columnNumber: 91
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-6", children: "Total Línea" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 349,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 342,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 341,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: creditNote.items.map((item, index) => {
          const subtotal = Number(item.quantity) * Number(item.unit_price);
          const discount = Number(item.discount_amount) || 0;
          const lineSubtotal = subtotal - discount;
          const itemTax = !isClientTaxExempt && creditNote.has_item_level_taxes ? getItemTaxTotal(item) : 0;
          const lineTotal = lineSubtotal + itemTax;
          return /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-4 pr-3 text-sm sm:pl-6", children: item.product_id ? /* @__PURE__ */ jsxDEV(Link, { to: `/articulos/${item.product_id}`, className: "text-indigo-600 hover:text-indigo-800 hover:underline", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 364,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 365,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 363,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: item.product_name }, void 0, false, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 369,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500", children: [
                "(",
                item.product_code,
                ")"
              ] }, void 0, true, {
                fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
                lineNumber: 370,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 368,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 361,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: Number(item.quantity).toFixed(2) }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 374,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(item.unit_price, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 375,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500 hidden", children: formatValue(discount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 376,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(lineSubtotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 377,
              columnNumber: 41
            }, this),
            !isClientTaxExempt && creditNote.has_item_level_taxes && /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-4 text-sm text-right text-gray-500", children: formatValue(itemTax, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 378,
              columnNumber: 99
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-4 pl-3 pr-4 text-sm text-right font-medium text-gray-800 sm:pr-6", children: formatValue(lineTotal, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 379,
              columnNumber: 41
            }, this)
          ] }, item.id || index, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 360,
            columnNumber: 19
          }, this);
        }) }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 352,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 340,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 339,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
      lineNumber: 337,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-4 space-y-4", children: [
        creditNote.rejection_reason && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 p-3 rounded border border-red-200 text-sm text-red-800", children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Motivo Rechazo:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 395,
            columnNumber: 33
          }, this),
          " ",
          creditNote.rejection_reason
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 394,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("dt", { className: totalLabelStyle, children: "Notas" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 399,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-base text-gray-900 whitespace-pre-wrap", children: creditNote.notes || "-" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 400,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 398,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 392,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 391,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1", children: !isClientTaxExempt && !creditNote.has_item_level_taxes && creditNote.taxes && creditNote.taxes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-medium text-gray-800", children: "Impuestos Globales Aplicados" }, void 0, false, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 409,
          columnNumber: 29
        }, this),
        creditNote.taxes.map(
          (tax, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle.replace("text-gray-600", "text-gray-700"), children: [
              tax.tax_name,
              " (",
              tax.rate,
              "%)"
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 412,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(tax.amount, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 413,
              columnNumber: 37
            }, this)
          ] }, tax.tax_id || index, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 411,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 408,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 406,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-1 p-4 bg-gray-50 rounded-lg space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Subtotal (Items):" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 422,
            columnNumber: 72
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: formatValue(calculatedTotals.subtotal, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 422,
            columnNumber: 130
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 422,
          columnNumber: 21
        }, this),
        calculatedTotals.globalDiscountAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: "Desc. Global:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 426,
            columnNumber: 62
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
            "- ",
            formatValue(calculatedTotals.globalDiscountAmount, "currency")
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 426,
            columnNumber: 116
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 426,
          columnNumber: 11
        }, this),
        !isClientTaxExempt && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} font-semibold`, children: "Base Imponible:" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 431,
              columnNumber: 99
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-base")} font-semibold`, children: formatValue(calculatedTotals.taxBase, "currency") }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 431,
              columnNumber: 174
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 431,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: totalLabelStyle, children: creditNote.has_item_level_taxes ? "Impuestos (Items):" : "Impuestos (Global):" }, void 0, false, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 432,
              columnNumber: 80
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: totalValueStyle, children: [
              "+ ",
              formatValue(calculatedTotals.totalTaxes, "currency")
            ] }, void 0, true, {
              fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
              lineNumber: 432,
              columnNumber: 201
            }, this)
          ] }, void 0, true, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 432,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 430,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t mt-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${totalLabelStyle} text-lg font-semibold`, children: "Total Final:" }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 435,
            columnNumber: 91
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `${totalValueStyle.replace("text-sm", "text-lg")} font-bold text-indigo-600`, children: formatValue(creditNote.total_amount, "currency") }, void 0, false, {
            fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
            lineNumber: 435,
            columnNumber: 171
          }, this)
        ] }, void 0, true, {
          fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
          lineNumber: 435,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
        lineNumber: 421,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
      lineNumber: 389,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx",
    lineNumber: 187,
    columnNumber: 5
  }, this);
};
_s(NotasCreditoDetailPage, "SbIsiU4+lbkDt3WO0BKsPvBZyXM=", false, function() {
  return [useParams, useNavigate, useCrudItem];
});
_c = NotasCreditoDetailPage;
var _c;
$RefreshReg$(_c, "NotasCreditoDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/notas_credito/pages/NotasCreditoDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZ3QixTQXVHQSxVQXZHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRnhCLFNBQVNBLFdBQVdDLGFBQWFDLFlBQVk7QUFDN0MsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxnQ0FBc0U7QUFDL0UsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWFDLE9BQU9DLFNBQVNDLHNCQUFzQjtBQUM1RCxTQUFTQyxXQUFXQyxZQUFZQyxrQkFBa0I7QUFDbEQsU0FBU0MsYUFBYUMsbUNBQW1DO0FBQ3pELFNBQVNDLHVDQUF1QztBQUNoRCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGlCQUFpQkMsd0JBQXdCO0FBQ2xELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBR2xDLE1BQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBeUI7QUFDOUMsTUFBSSxDQUFDQSxLQUFLQyxTQUFTRCxLQUFLQyxNQUFNQyxXQUFXLEVBQUcsUUFBTztBQUNuRCxTQUFPRixLQUFLQyxNQUFNRSxPQUFPLENBQUNDLEtBQUtDLFFBQVFELE1BQU1FLE9BQU9ELElBQUlFLE1BQU0sR0FBRyxDQUFDO0FBQ3RFO0FBRU8sYUFBTUMseUJBQXlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEMsUUFBTSxFQUFFQyxHQUFHLElBQUlsQyxVQUEwQjtBQUN6QyxRQUFNbUMsV0FBV2xDLFlBQVk7QUFDN0IsUUFBTSxFQUFFdUIsTUFBTVksWUFBWUMsU0FBU0MsTUFBTSxJQUFJakMsWUFBd0JDLDBCQUEwQjRCLEVBQUU7QUFDakcsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUlwQyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDcUMsY0FBY0MsZUFBZSxJQUFJdEMsU0FBUyxLQUFLO0FBRXRELFFBQU11QyxvQkFBb0J4QztBQUFBQSxJQUN0QixNQUFNYyxnQ0FBZ0NtQixZQUFZUSxNQUFNO0FBQUEsSUFDeEQsQ0FBQ1IsWUFBWVEsTUFBTTtBQUFBLEVBQ3ZCO0FBR0EsUUFBTUMsbUJBQW1CMUMsUUFBUSxNQUFNO0FBQ25DLFFBQUksQ0FBQ2lDLFdBQVksUUFBTyxFQUFFVSxVQUFVLEdBQUdDLG9CQUFvQixHQUFHQyxzQkFBc0IsR0FBR0MsU0FBUyxHQUFHQyxZQUFZLEVBQUU7QUFDakgsVUFBTUMsUUFBUWYsV0FBV2UsU0FBUztBQUVsQyxVQUFNTCxXQUFXSyxNQUFNeEIsT0FBTyxDQUFDQyxLQUFLSixTQUFTSSxNQUFPRSxPQUFPTixLQUFLNEIsUUFBUSxJQUFJdEIsT0FBT04sS0FBSzZCLFVBQVUsR0FBSSxDQUFDO0FBQ3ZHLFVBQU1OLHFCQUFxQkksTUFBTXhCLE9BQU8sQ0FBQ0MsS0FBS0osU0FBU0ksT0FBT0UsT0FBT04sS0FBSzhCLGVBQWUsS0FBSyxJQUFJLENBQUM7QUFJbkcsVUFBTU4sdUJBQXVCO0FBRTdCLFVBQU1DLFVBQVVILFdBQVdDLHFCQUFxQkM7QUFFaEQsUUFBSUUsYUFBYTtBQUNqQixRQUFJLENBQUNQLG1CQUFtQjtBQUNwQixVQUFJUCxXQUFXbUIsc0JBQXNCO0FBQ2pDTCxxQkFBYUMsTUFBTXhCLE9BQU8sQ0FBQ0MsS0FBS0osU0FBU0ksTUFBTUwsZ0JBQWdCQyxJQUFJLEdBQUcsQ0FBQztBQUFBLE1BQzNFLE9BQU87QUFDSDBCLHNCQUFjZCxXQUFXWCxTQUFTLElBQUlFLE9BQU8sQ0FBQ0MsS0FBS0MsUUFBUUQsTUFBTUUsT0FBT0QsSUFBSUUsTUFBTSxHQUFHLENBQUM7QUFBQSxNQUMxRjtBQUFBLElBQ0o7QUFDQSxXQUFPLEVBQUVlLFVBQVVDLG9CQUFvQkMsc0JBQXNCQyxTQUFTQyxXQUFXO0FBQUEsRUFDckYsR0FBRyxDQUFDZCxZQUFZTyxpQkFBaUIsQ0FBQztBQUVsQyxRQUFNYSxZQUFZckQsUUFBUSxNQUFNO0FBQzVCLFVBQU1zRCxRQUFRckIsWUFBWVEsUUFBUWE7QUFDbEMsUUFBSSxDQUFDQSxNQUFPLFFBQU9DO0FBRW5CLFVBQU1DLFFBQVF2QixhQUFhckIsWUFBWXFCLFdBQVd3QixjQUFjLFVBQVUsSUFBSTtBQUM5RSxVQUFNQyxTQUFTLEdBQUd6QixZQUFZMEIsVUFBVSxFQUFFLElBQUkxQixZQUFZMkIsY0FBYztBQUV4RSxVQUFNQyxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsV0FBT0UsT0FBTyxXQUFXLG1CQUFtQkwsTUFBTSxNQUFNekIsWUFBWVEsUUFBUXVCLElBQUksRUFBRTtBQUNsRkgsV0FBT0UsT0FBTyxRQUFRLGlFQUFpRUwsTUFBTSxvQkFBb0JGLEtBQUssR0FBRztBQUV6SCxVQUFNUyxjQUFjSixPQUFPSyxTQUFTLEVBQUVDLFFBQVEsT0FBTyxLQUFLO0FBQzFELFdBQU8sVUFBVWIsS0FBSyxJQUFJVyxXQUFXO0FBQUEsRUFDekMsR0FBRyxDQUFDaEMsVUFBVSxDQUFDO0FBRWYsUUFBTW1DLGVBQWVwRSxRQUFRLE1BQU07QUFDL0IsVUFBTXFFLFFBQVFwQyxZQUFZUSxRQUFRNEI7QUFDbEMsUUFBSSxDQUFDQSxNQUFPLFFBQU87QUFFbkIsVUFBTUMsYUFBYUQsTUFBTUYsUUFBUSxXQUFXLEVBQUU7QUFDOUMsVUFBTVQsU0FBUyxHQUFHekIsWUFBWTBCLFVBQVUsRUFBRSxJQUFJMUIsWUFBWTJCLGNBQWM7QUFDeEUsVUFBTVcsVUFBVSxRQUFRdEMsV0FBV1EsUUFBUXVCLElBQUksb0RBQW9ETixNQUFNLFlBQVk5QyxZQUFZcUIsV0FBV3dCLGNBQWMsVUFBVSxDQUFDO0FBRXJLLFdBQU8saUJBQWlCYSxVQUFVLFNBQVNFLG1CQUFtQkQsT0FBTyxDQUFDO0FBQUEsRUFDMUUsR0FBRyxDQUFDdEMsVUFBVSxDQUFDO0FBRWYsTUFBSUMsUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJQyxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUE7QUFBQSxJQUFxQ0E7QUFBQUEsT0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRjtBQUNyRyxNQUFJLENBQUNGLFdBQVksUUFBTyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLDRDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVFO0FBRy9GLFFBQU13QyxnQkFBZ0JBLENBQUNDLFdBQW1CO0FBQ3RDLFlBQVFDLE9BQU9ELE1BQU0sR0FBQztBQUFBLE1BQ2xCLEtBQUs7QUFBSyxlQUFPO0FBQUE7QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFRLGVBQU87QUFBQSxNQUNwQixLQUFLO0FBQVUsZUFBTztBQUFBLE1BQ3RCO0FBQVMsZUFBTztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUNBLFFBQU1FLHFCQUFxQkEsQ0FBQ0YsV0FBbUI7QUFDM0MsWUFBUUMsT0FBT0QsTUFBTSxHQUFDO0FBQUEsTUFDbEIsS0FBSztBQUFLLGVBQU87QUFBQSxNQUNqQixLQUFLO0FBQUssZUFBTztBQUFBLE1BQ2pCLEtBQUs7QUFBSyxlQUFPO0FBQUEsTUFDakIsS0FBSztBQUFRLGVBQU87QUFBQSxNQUNwQixLQUFLO0FBQVUsZUFBTztBQUFBLE1BQ3RCO0FBQVMsZUFBTztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU1HLGtCQUFrQjtBQUN4QixRQUFNQyxrQkFBa0I7QUFFeEIsUUFBTUMseUJBQXlCLFlBQVk7QUFDdkMsUUFBSSxDQUFDOUMsV0FBWTtBQUNqQixVQUFNK0MsaUJBQWlCLHVEQUF1RC9DLFdBQVcwQixNQUFNLElBQUkxQixXQUFXMkIsY0FBYztBQUFBO0FBQUE7QUFDNUgsUUFBSSxDQUFDcUIsT0FBT0MsUUFBUUYsY0FBYyxFQUFHO0FBRXJDekMsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNBLFlBQU14QixNQUFNWix5QkFBeUJnRixVQUFVbEQsV0FBV0YsSUFBSTtBQUFBLFFBQzFEMkMsUUFBUTtBQUFBO0FBQUEsTUFDWixDQUFDO0FBQ0R4RCxZQUFNa0UsUUFBUSx3Q0FBd0M7QUFDdERILGFBQU9JLFNBQVNDLE9BQU87QUFBQSxJQUUzQixTQUFTQyxLQUFVO0FBQ2ZDLGNBQVFyRCxNQUFNb0QsR0FBRztBQUNqQnJFLFlBQU1pQixNQUFNLG9CQUFvQm9ELElBQUloQixXQUFXLG1CQUFtQixFQUFFO0FBQUEsSUFDeEUsVUFBQztBQUNHaEMsc0JBQWdCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0o7QUFFQSxRQUFNa0QsY0FBYyxZQUFZO0FBQzVCLFFBQUksQ0FBQ3hELFdBQVk7QUFFakIsVUFBTXlELFVBQVUxRSxnQkFBZ0I7QUFDaEMsUUFBSSxDQUFDMEUsU0FBUztBQUNWeEUsWUFBTWlCLE1BQU0sOENBQThDO0FBQzFEO0FBQUEsSUFDSjtBQUVBRSxrQkFBYyxJQUFJO0FBQ2xCLFFBQUk7QUFDQSxZQUFNcEIsaUJBQWlCeUUsU0FBUyxpQkFBaUJ6RCxXQUFXRixFQUFFLE1BQU07QUFBQSxJQUN4RSxTQUFTSSxRQUFPO0FBQ1osVUFBSSxDQUFDdUQsUUFBUVQsT0FBT1UsT0FBUUQsU0FBUVQsT0FBT1csTUFBTTtBQUNqREosY0FBUXJELE1BQU0sNEJBQTRCQSxNQUFLO0FBQy9DakIsWUFBTWlCLE1BQU0sd0NBQXdDO0FBQUEsSUFDeEQsVUFBQztBQUNHRSxvQkFBYyxLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNKO0FBRUEsUUFBTXdELGtCQUFrQkEsQ0FBQ0MsR0FBcUJDLFNBQStCO0FBQ3pFLFVBQU1DLE9BQU9ELFNBQVMsVUFBVTlELFlBQVlRLFFBQVFhLFFBQVFyQixZQUFZUSxRQUFRNEI7QUFDaEYsUUFBSSxDQUFDMkIsTUFBTTtBQUNQRixRQUFFRyxlQUFlO0FBQ2pCL0UsWUFBTWdGLEtBQUssdUJBQXVCSCxTQUFTLFVBQVUsVUFBVSxVQUFVLGNBQWM7QUFBQSxJQUMzRjtBQUFBLEVBQ0o7QUFFQSxRQUFNSSxjQUFjeEIsT0FBTzFDLFdBQVd5QyxNQUFNLE1BQU0sT0FBT0MsT0FBTzFDLFdBQVd5QyxNQUFNLE1BQU07QUFFdkYsU0FDSSx1QkFBQyxTQUFJLFdBQVUsc0RBR1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUVBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTTFDLFNBQVNiLGtCQUFrQmhCLHlCQUF5QmlHLFNBQVMsQ0FBQyxHQUFHLFdBQVUsb0RBQzlGLGlDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFFBQUcsV0FBVSxpREFBK0M7QUFBQTtBQUFBLFlBQ3BEbkUsV0FBVzBCO0FBQUFBLFlBQU87QUFBQSxZQUFFMUIsV0FBVzJCO0FBQUFBLGVBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVyx1REFBdURnQixtQkFBbUIzQyxXQUFXeUMsTUFBTSxDQUFDLElBQ3hHRCx3QkFBY3hDLFdBQVd5QyxNQUFNLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ1Z6QztBQUFBQSxtQkFBV1EsVUFDUixtQ0FDSTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNWTtBQUFBQSxjQUNOLFNBQVMsQ0FBQ3lDLE1BQU1ELGdCQUFnQkMsR0FBRyxPQUFPO0FBQUEsY0FDMUMsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU4saUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBO0FBQUEsWUFOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNMUI7QUFBQUEsY0FDTixTQUFTLENBQUMwQixNQUFNRCxnQkFBZ0JDLEdBQUcsVUFBVTtBQUFBLGNBQzdDLFFBQU87QUFBQSxjQUNQLEtBQUk7QUFBQSxjQUNKLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQTtBQUFBLFlBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBR0o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNMO0FBQUFBLFlBQ1QsVUFBVXJEO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLHVCQUNHLHVCQUFDLGFBQVUsV0FBVSwwQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsSUFFM0MsdUJBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUE7QUFBQSxVQVRwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBRUMsQ0FBQytELGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFNBQVNwQjtBQUFBQSxZQUNULFVBQVV6QztBQUFBQSxZQUNWLFdBQVU7QUFBQSxZQUVUQSx5QkFDRyxtQ0FDSTtBQUFBLHFDQUFDLGFBQVUsV0FBVSwrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQTtBQUFBLGlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLElBRUEsbUNBQ0k7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsd0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUE7QUFBQSxpQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBO0FBQUEsVUFmUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkE7QUFBQSxXQXZEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeURBO0FBQUEsU0F6RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBFQTtBQUFBLElBR0EsdUJBQUMsUUFBRyxXQUFVLGtFQUNUTDtBQUFBQSxpQkFBV29FLGNBQ1IsbUNBQ0k7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0VBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTJELDhCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBQ3ZGLHVCQUFDLFFBQUcsV0FBVSxrRUFBa0VwRSxxQkFBV29FLGNBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsYUFGMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsb0VBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTJELCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMkN6RixzQkFBWXFCLFdBQVdxRSxjQUFjLE1BQU0sS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxhQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUosdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXekIsaUJBQWlCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdkMsdUJBQUMsUUFBRyxXQUFVLGdDQUNWLGlDQUFDLFFBQUssSUFBSSxhQUFhNUMsV0FBV1EsUUFBUVYsRUFBRSxJQUFJLFdBQVUseURBQ3JERSxxQkFBV1EsUUFBUXVCLFFBQVEvQixXQUFXc0UsZUFBZSxTQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXMUIsaUJBQWlCLDZCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ2pFLHNCQUFZcUIsV0FBV3VFLFlBQVksTUFBTSxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FGN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVczQixpQkFBaUIsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxRQUNoRCx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1Q1QyxxQkFBV3dFLGdCQUNSLHVCQUFDLFFBQUssSUFBSSxzQkFBc0J4RSxXQUFXd0UsY0FBYzFFLEVBQUUsSUFBSSxXQUFVLDREQUNyRTtBQUFBLGlDQUFDLGtCQUFlLFdBQVUsVUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUMvQmxCLDRCQUE0Qm9CLFdBQVd3RSxhQUFhO0FBQUEsYUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQnhFLHFCQUFXeUUsbUJBQW1CLE9BQU96RSxXQUFXeUUsZ0JBQWdCLEtBQUssb0JBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUgsS0FQL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVzdCLGlCQUFpQixpQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0M1QyxxQkFBVzBFLG9CQUFvQixPQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsV0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVc5QixpQkFBaUIsd0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDNUMscUJBQVcyRSxhQUFhNUMsUUFBUSxPQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsV0FGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxRQUFHLFdBQVdhLGlCQUFpQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0M1QyxxQkFBVzRFLFdBQVc3QyxRQUFRLE9BQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxXQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV2EsaUJBQWlCLHNCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFDdEMsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQzVDLHFCQUFXNkUsVUFBVTlDLFFBQVEsT0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFdBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFXYSxpQkFBaUIsOEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxRQUFHLFdBQVUsZ0NBQWdDNUMscUJBQVc4RSxnQkFBZ0JwRixPQUFPTSxXQUFXOEUsYUFBYSxFQUFFQyxRQUFRLENBQUMsSUFBSSxVQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsV0FGbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQy9FLFdBQVdnRixZQUNSLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBV3BDLGlCQUFpQiw4QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBQzlDLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0M1QyxxQkFBV2dGLFlBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxXQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWpFUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUVBO0FBQUEsSUFHQSx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtDQUE4QywyQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLE1BQ3ZGLHVCQUFDLFNBQUksV0FBVSwyRUFDWCxpQ0FBQyxXQUFNLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FDYixpQ0FBQyxRQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBFQUF5RSx3QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsd0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsUUFBRyxXQUFVLHFFQUFvRSxxQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUN2Rix1QkFBQyxRQUFHLFdBQVUsOERBQTZELHdCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ2xGLENBQUN6RSxxQkFBcUJQLFdBQVdtQix3QkFBd0IsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCx5QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUM5SSx1QkFBQyxRQUFHLFdBQVUsMkVBQTBFLDJCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBUHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNabkIscUJBQVdlLE1BQU1rRSxJQUFJLENBQUM3RixNQUFNOEYsVUFBVTtBQUNuQyxnQkFBTXhFLFdBQVdoQixPQUFPTixLQUFLNEIsUUFBUSxJQUFJdEIsT0FBT04sS0FBSzZCLFVBQVU7QUFDL0QsZ0JBQU1rRSxXQUFXekYsT0FBT04sS0FBSzhCLGVBQWUsS0FBSztBQUNqRCxnQkFBTWtFLGVBQWUxRSxXQUFXeUU7QUFDaEMsZ0JBQU1FLFVBQVUsQ0FBQzlFLHFCQUFxQlAsV0FBV21CLHVCQUF1QmhDLGdCQUFnQkMsSUFBSSxJQUFJO0FBQ2hHLGdCQUFNa0csWUFBWUYsZUFBZUM7QUFDakMsaUJBQ0ksdUJBQUMsUUFDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSxrQ0FDVGpHLGVBQUttRyxhQUNGLHVCQUFDLFFBQUssSUFBSSxjQUFjbkcsS0FBS21HLFVBQVUsSUFBSSxXQUFVLHlEQUNqRDtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFBNkJuRyxlQUFLb0csZ0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FDOUQsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBO0FBQUEsZ0JBQUVwRyxLQUFLcUc7QUFBQUEsZ0JBQWE7QUFBQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxJQUVBLG1DQUNJO0FBQUEscUNBQUMsU0FBSSxXQUFVLDZCQUE2QnJHLGVBQUtvRyxnQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxnQkFBRXBHLEtBQUtxRztBQUFBQSxnQkFBYTtBQUFBLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Qy9GLGlCQUFPTixLQUFLNEIsUUFBUSxFQUFFK0QsUUFBUSxDQUFDLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0YsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3BHLHNCQUFZUyxLQUFLNkIsWUFBWSxVQUFVLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckcsdUJBQUMsUUFBRyxXQUFVLHFEQUFxRHRDLHNCQUFZd0csVUFBVSxVQUFVLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckcsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q3hHLHNCQUFZeUcsY0FBYyxVQUFVLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUEsWUFDakcsQ0FBQzdFLHFCQUFxQlAsV0FBV21CLHdCQUF3Qix1QkFBQyxRQUFHLFdBQVUsOENBQThDeEMsc0JBQVkwRyxTQUFTLFVBQVUsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxZQUN2Six1QkFBQyxRQUFHLFdBQVUsdUVBQXVFMUcsc0JBQVkyRyxXQUFXLFVBQVUsS0FBdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxlQW5CbkhsRyxLQUFLVSxNQUFNb0YsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxRQUVSLENBQUMsS0E5Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFdBM0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0EsS0E3Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThDQTtBQUFBLFNBaERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx1REFFWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDWCxpQ0FBQyxTQUFJLFdBQVUsMkJBQ1ZsRjtBQUFBQSxtQkFBVzBGLG9CQUNSLHVCQUFDLFNBQUksV0FBVSxvRUFDWDtBQUFBLGlDQUFDLFlBQU8sK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFTO0FBQUEsVUFBRTFGLFdBQVcwRjtBQUFBQSxhQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVKLHVCQUFDLFNBQ0c7QUFBQSxpQ0FBQyxRQUFHLFdBQVc5QyxpQkFBaUIscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFDckMsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRDVDLHFCQUFXMkYsU0FBUyxPQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLGFBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1YsV0FBQ3BGLHFCQUFxQixDQUFDUCxXQUFXbUIsd0JBQXdCbkIsV0FBV1gsU0FBU1csV0FBV1gsTUFBTUMsU0FBUyxLQUNyRyx1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNENBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM3RVUsV0FBV1gsTUFBTTRGO0FBQUFBLFVBQUksQ0FBQ3hGLEtBQUt5RixVQUN4Qix1QkFBQyxTQUE4QixXQUFVLHFDQUNyQztBQUFBLG1DQUFDLFVBQUssV0FBV3RDLGdCQUFnQlYsUUFBUSxpQkFBaUIsZUFBZSxHQUFJekM7QUFBQUEsa0JBQUltRztBQUFBQSxjQUFTO0FBQUEsY0FBR25HLElBQUlvRztBQUFBQSxjQUFLO0FBQUEsaUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsVUFBSyxXQUFXaEQsaUJBQWtCbEUsc0JBQVljLElBQUlFLFFBQVEsVUFBVSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRmpFRixJQUFJcUcsVUFBVVosT0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0g7QUFBQSxXQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLGlDQUFDLFVBQUssV0FBV3RDLGlCQUFpQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBV0MsaUJBQWtCbEUsc0JBQVk4QixpQkFBaUJDLFVBQVUsVUFBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLGFBQW5NO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBME07QUFBQSxRQUd6TUQsaUJBQWlCRyx1QkFBdUIsS0FDckMsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLGlDQUFDLFVBQUssV0FBV2dDLGlCQUFpQiw2QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUFPLHVCQUFDLFVBQUssV0FBV0MsaUJBQWlCO0FBQUE7QUFBQSxZQUFHbEUsWUFBWThCLGlCQUFpQkcsc0JBQXNCLFVBQVU7QUFBQSxlQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLGFBQTdNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb047QUFBQSxRQUd2TixDQUFDTCxxQkFDRSxtQ0FDSTtBQUFBLGlDQUFDLFNBQUksV0FBVSx3REFBdUQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsR0FBR3FDLGVBQWUsa0JBQWtCLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGdCQUFnQlgsUUFBUSxXQUFXLFdBQVcsQ0FBQyxrQkFBbUJ2RCxzQkFBWThCLGlCQUFpQkksU0FBUyxVQUFVLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdJO0FBQUEsZUFBelI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ1M7QUFBQSxVQUNoUyx1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUEsbUNBQUMsVUFBSyxXQUFXK0IsaUJBQWtCNUMscUJBQVdtQix1QkFBdUIsdUJBQXVCLHlCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSDtBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFXMEIsaUJBQWlCO0FBQUE7QUFBQSxjQUFHbEUsWUFBWThCLGlCQUFpQkssWUFBWSxVQUFVO0FBQUEsaUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsZUFBdFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlE7QUFBQSxhQUZqUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVKLHVCQUFDLFNBQUksV0FBVSx3REFBdUQ7QUFBQSxpQ0FBQyxVQUFLLFdBQVcsR0FBRzhCLGVBQWUsMEJBQTBCLDRCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdDLGdCQUFnQlgsUUFBUSxXQUFXLFNBQVMsQ0FBQyw4QkFBK0J2RCxzQkFBWXFCLFdBQVd3QixjQUFjLFVBQVUsS0FBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUo7QUFBQSxhQUF2UztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThTO0FBQUEsV0FkbFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0EvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLE9BMVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyUEE7QUFFUjtBQUFFM0IsR0E5WVdELHdCQUFzQjtBQUFBLFVBQ2hCaEMsV0FDRUMsYUFDNEJJLFdBQVc7QUFBQTtBQUFBOEgsS0FIL0NuRztBQUFzQixJQUFBbUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiTGluayIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUNydWRJdGVtIiwibm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnIiwiTG9hZGluZ1NwaW5uZXIiLCJJb0Fycm93QmFjayIsIklvQmFuIiwiSW9QcmludCIsIklvRG9jdW1lbnRUZXh0IiwiRmFTcGlubmVyIiwiRmFXaGF0c2FwcCIsIkZhRW52ZWxvcGUiLCJmb3JtYXRWYWx1ZSIsImZvcm1hdExpbmtlZFNhbGVzSW52b2ljZVJlZiIsImlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQiLCJwYXRjaCIsImJlZ2luUGRmUHJldmlldyIsImZpbmlzaFBkZlByZXZpZXciLCJ0b2FzdCIsImdldExpc3RSZXR1cm5QYXRoIiwiZ2V0SXRlbVRheFRvdGFsIiwiaXRlbSIsInRheGVzIiwibGVuZ3RoIiwicmVkdWNlIiwic3VtIiwidGF4IiwiTnVtYmVyIiwiYW1vdW50IiwiTm90YXNDcmVkaXRvRGV0YWlsUGFnZSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsImNyZWRpdE5vdGUiLCJsb2FkaW5nIiwiZXJyb3IiLCJpc1ByaW50aW5nIiwic2V0SXNQcmludGluZyIsImlzQ2FuY2VsbGluZyIsInNldElzQ2FuY2VsbGluZyIsImlzQ2xpZW50VGF4RXhlbXB0IiwiY2xpZW50IiwiY2FsY3VsYXRlZFRvdGFscyIsInN1YnRvdGFsIiwidG90YWxJdGVtRGlzY291bnRzIiwiZ2xvYmFsRGlzY291bnRBbW91bnQiLCJ0YXhCYXNlIiwidG90YWxUYXhlcyIsIml0ZW1zIiwicXVhbnRpdHkiLCJ1bml0X3ByaWNlIiwiZGlzY291bnRfYW1vdW50IiwiaGFzX2l0ZW1fbGV2ZWxfdGF4ZXMiLCJlbWFpbExpbmsiLCJlbWFpbCIsInVuZGVmaW5lZCIsInRvdGFsIiwidG90YWxfYW1vdW50IiwibnVtYmVyIiwic2VyaWVzIiwidm91Y2hlcl9udW1iZXIiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJuYW1lIiwicXVlcnlTdHJpbmciLCJ0b1N0cmluZyIsInJlcGxhY2UiLCJ3aGF0c2FwcExpbmsiLCJwaG9uZSIsImNsZWFuUGhvbmUiLCJtZXNzYWdlIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZ2V0U3RhdHVzVGV4dCIsInN0YXR1cyIsIlN0cmluZyIsImdldFN0YXR1c0NsYXNzTmFtZSIsInRvdGFsTGFiZWxTdHlsZSIsInRvdGFsVmFsdWVTdHlsZSIsImhhbmRsZUNhbmNlbENyZWRpdE5vdGUiLCJjb25maXJtTWVzc2FnZSIsIndpbmRvdyIsImNvbmZpcm0iLCJlbmRwb2ludCIsInN1Y2Nlc3MiLCJsb2NhdGlvbiIsInJlbG9hZCIsImVyciIsImNvbnNvbGUiLCJoYW5kbGVQcmludCIsInNlc3Npb24iLCJjbG9zZWQiLCJjbG9zZSIsImhhbmRsZUxpbmtDbGljayIsImUiLCJ0eXBlIiwiZGF0YSIsInByZXZlbnREZWZhdWx0Iiwid2FybiIsImlzQ2FuY2VsbGVkIiwiYmFzZVJvdXRlIiwiY2FlX251bWJlciIsImNhZV9kdWVfZGF0ZSIsImNsaWVudF9uYW1lIiwiaXNzdWVfZGF0ZSIsInNhbGVzX2ludm9pY2UiLCJzYWxlc19pbnZvaWNlX2lkIiwiZG9jdW1lbnRfdm91Y2hlciIsInNhbGVzcGVyc29uIiwidHJhbnNwb3J0IiwiY3VycmVuY3kiLCJleGNoYW5nZV9yYXRlIiwidG9GaXhlZCIsImFmaXBfcG9zIiwibWFwIiwiaW5kZXgiLCJkaXNjb3VudCIsImxpbmVTdWJ0b3RhbCIsIml0ZW1UYXgiLCJsaW5lVG90YWwiLCJwcm9kdWN0X2lkIiwicHJvZHVjdF9uYW1lIiwicHJvZHVjdF9jb2RlIiwicmVqZWN0aW9uX3JlYXNvbiIsIm5vdGVzIiwidGF4X25hbWUiLCJyYXRlIiwidGF4X2lkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90YXNDcmVkaXRvRGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3JjL21vZHVsZXMvbm90YXNfY3JlZGl0by9wYWdlcy9Ob3Rhc0NyZWRpdG9EZXRhaWxQYWdlLnRzeFxuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDcnVkSXRlbSB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWRJdGVtJztcbi8vIENvbmZpZyB5IFRpcG9zXG5pbXBvcnQgeyBub3Rhc0NyZWRpdG9Nb2R1bGVDb25maWcsIHR5cGUgQ3JlZGl0Tm90ZSwgdHlwZSBDcmVkaXROb3RlSXRlbSB9IGZyb20gJy4uL25vdGFzX2NyZWRpdG8uY29uZmlnJztcbmltcG9ydCB7IExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS9Mb2FkaW5nU3Bpbm5lcic7XG5pbXBvcnQgeyBJb0Fycm93QmFjaywgSW9CYW4sIElvUHJpbnQsIElvRG9jdW1lbnRUZXh0IH0gZnJvbSAncmVhY3QtaWNvbnMvaW81JztcbmltcG9ydCB7IEZhU3Bpbm5lciwgRmFXaGF0c2FwcCwgRmFFbnZlbG9wZSB9IGZyb20gJ3JlYWN0LWljb25zL2ZhJztcbmltcG9ydCB7IGZvcm1hdFZhbHVlLCBmb3JtYXRMaW5rZWRTYWxlc0ludm9pY2VSZWYgfSBmcm9tICcuLi8uLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcbmltcG9ydCB7IGlzQ2xpZW50TGV5RXhwb3J0YWNpb25UZGZFeGVtcHQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9jbGllbnRUYXhFeGVtcHRpb24nO1xuaW1wb3J0IHsgcGF0Y2ggfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hcGlTZXJ2aWNlJztcbmltcG9ydCB7IGJlZ2luUGRmUHJldmlldywgZmluaXNoUGRmUHJldmlldyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2Jsb2JIZWxwZXInO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgeyBnZXRMaXN0UmV0dXJuUGF0aCB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xpc3RSZXR1cm5OYXZpZ2F0aW9uJztcblxuLy8gSGVscGVyIHBhcmEgY2FsY3VsYXIgaW1wdWVzdG9zIGRlIHVuIMOtdGVtIChJZ3VhbCBxdWUgZW4gRmFjdHVyYXMpXG5jb25zdCBnZXRJdGVtVGF4VG90YWwgPSAoaXRlbTogQ3JlZGl0Tm90ZUl0ZW0pID0+IHtcbiAgICBpZiAoIWl0ZW0udGF4ZXMgfHwgaXRlbS50YXhlcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICAgIHJldHVybiBpdGVtLnRheGVzLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG59O1xuXG5leHBvcnQgY29uc3QgTm90YXNDcmVkaXRvRGV0YWlsUGFnZSA9ICgpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IHsgaXRlbTogY3JlZGl0Tm90ZSwgbG9hZGluZywgZXJyb3IgfSA9IHVzZUNydWRJdGVtPENyZWRpdE5vdGU+KG5vdGFzQ3JlZGl0b01vZHVsZUNvbmZpZywgaWQpO1xuICAgIGNvbnN0IFtpc1ByaW50aW5nLCBzZXRJc1ByaW50aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaXNDYW5jZWxsaW5nLCBzZXRJc0NhbmNlbGxpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgY29uc3QgaXNDbGllbnRUYXhFeGVtcHQgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBpc0NsaWVudExleUV4cG9ydGFjaW9uVGRmRXhlbXB0KGNyZWRpdE5vdGU/LmNsaWVudCksXG4gICAgICAgIFtjcmVkaXROb3RlPy5jbGllbnRdXG4gICAgKTtcblxuICAgIC8vIEzDs2dpY2EgZGUgY8OhbGN1bG8gaWTDqW50aWNhIGEgRmFjdHVyYXNcbiAgICBjb25zdCBjYWxjdWxhdGVkVG90YWxzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICghY3JlZGl0Tm90ZSkgcmV0dXJuIHsgc3VidG90YWw6IDAsIHRvdGFsSXRlbURpc2NvdW50czogMCwgZ2xvYmFsRGlzY291bnRBbW91bnQ6IDAsIHRheEJhc2U6IDAsIHRvdGFsVGF4ZXM6IDAgfTtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBjcmVkaXROb3RlLml0ZW1zIHx8IFtdO1xuXG4gICAgICAgIGNvbnN0IHN1YnRvdGFsID0gaXRlbXMucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKSksIDApO1xuICAgICAgICBjb25zdCB0b3RhbEl0ZW1EaXNjb3VudHMgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgKE51bWJlcihpdGVtLmRpc2NvdW50X2Ftb3VudCkgfHwgMCksIDApO1xuXG4gICAgICAgIC8vIEVuIE5DIGEgdmVjZXMgZWwgZGVzY3VlbnRvIGdsb2JhbCB2aWVuZSBjb21vIHBvcmNlbnRhamUgbyBtb250bywgYXN1bWltb3MgbW9udG8gc2kgZXhpc3RlLCBzaW5vIGNhbGN1bGFtb3NcbiAgICAgICAgLy8gQWp1c3RhIGVzdG8gc2Vnw7puIGPDs21vIGd1YXJkZXMgZWwgZGVzY3VlbnRvIGdsb2JhbCBlbiBOQ1xuICAgICAgICBjb25zdCBnbG9iYWxEaXNjb3VudEFtb3VudCA9IDA7IC8vIFBvciBhaG9yYSAwIHNpIG5vIHRpZW5lcyBjYW1wbyBleHBsw61jaXRvIGRlIG1vbnRvIGRlc2N1ZW50byBnbG9iYWwgZW4gTkNcblxuICAgICAgICBjb25zdCB0YXhCYXNlID0gc3VidG90YWwgLSB0b3RhbEl0ZW1EaXNjb3VudHMgLSBnbG9iYWxEaXNjb3VudEFtb3VudDtcblxuICAgICAgICBsZXQgdG90YWxUYXhlcyA9IDA7XG4gICAgICAgIGlmICghaXNDbGllbnRUYXhFeGVtcHQpIHtcbiAgICAgICAgICAgIGlmIChjcmVkaXROb3RlLmhhc19pdGVtX2xldmVsX3RheGVzKSB7XG4gICAgICAgICAgICAgICAgdG90YWxUYXhlcyA9IGl0ZW1zLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyBnZXRJdGVtVGF4VG90YWwoaXRlbSksIDApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b3RhbFRheGVzID0gKGNyZWRpdE5vdGUudGF4ZXMgfHwgW10pLnJlZHVjZSgoc3VtLCB0YXgpID0+IHN1bSArIE51bWJlcih0YXguYW1vdW50KSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgc3VidG90YWwsIHRvdGFsSXRlbURpc2NvdW50cywgZ2xvYmFsRGlzY291bnRBbW91bnQsIHRheEJhc2UsIHRvdGFsVGF4ZXMgfTtcbiAgICB9LCBbY3JlZGl0Tm90ZSwgaXNDbGllbnRUYXhFeGVtcHRdKTtcblxuICAgIGNvbnN0IGVtYWlsTGluayA9IHVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBlbWFpbCA9IGNyZWRpdE5vdGU/LmNsaWVudD8uZW1haWw7XG4gICAgICAgIGlmICghZW1haWwpIHJldHVybiB1bmRlZmluZWQ7XG5cbiAgICAgICAgY29uc3QgdG90YWwgPSBjcmVkaXROb3RlID8gZm9ybWF0VmFsdWUoY3JlZGl0Tm90ZS50b3RhbF9hbW91bnQsICdjdXJyZW5jeScpIDogJyQwJztcbiAgICAgICAgY29uc3QgbnVtYmVyID0gYCR7Y3JlZGl0Tm90ZT8uc2VyaWVzIHx8ICcnfS0ke2NyZWRpdE5vdGU/LnZvdWNoZXJfbnVtYmVyfWA7XG5cbiAgICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgICAgICBwYXJhbXMuYXBwZW5kKCdzdWJqZWN0JywgYE5vdGEgZGUgQ3LDqWRpdG8gJHtudW1iZXJ9IC0gJHtjcmVkaXROb3RlPy5jbGllbnQ/Lm5hbWV9YCk7XG4gICAgICAgIHBhcmFtcy5hcHBlbmQoJ2JvZHknLCBgRXN0aW1hZG8gY2xpZW50ZSwgYWRqdW50YW1vcyBlbCBkZXRhbGxlIGRlIHN1IE5vdGEgZGUgQ3LDqWRpdG8gJHtudW1iZXJ9IHBvciB1biB0b3RhbCBkZSAke3RvdGFsfS5gKTtcblxuICAgICAgICBjb25zdCBxdWVyeVN0cmluZyA9IHBhcmFtcy50b1N0cmluZygpLnJlcGxhY2UoL1xcKy9nLCAnJTIwJyk7XG4gICAgICAgIHJldHVybiBgbWFpbHRvOiR7ZW1haWx9PyR7cXVlcnlTdHJpbmd9YDtcbiAgICB9LCBbY3JlZGl0Tm90ZV0pO1xuXG4gICAgY29uc3Qgd2hhdHNhcHBMaW5rID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHBob25lID0gY3JlZGl0Tm90ZT8uY2xpZW50Py5waG9uZTtcbiAgICAgICAgaWYgKCFwaG9uZSkgcmV0dXJuICcjJztcblxuICAgICAgICBjb25zdCBjbGVhblBob25lID0gcGhvbmUucmVwbGFjZSgvW14wLTldL2csICcnKTtcbiAgICAgICAgY29uc3QgbnVtYmVyID0gYCR7Y3JlZGl0Tm90ZT8uc2VyaWVzIHx8ICcnfS0ke2NyZWRpdE5vdGU/LnZvdWNoZXJfbnVtYmVyfWA7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBgSG9sYSAke2NyZWRpdE5vdGUuY2xpZW50Py5uYW1lfSwgbGUgZW52aWFtb3MgbG9zIGRldGFsbGVzIGRlIHN1IE5vdGEgZGUgQ3LDqWRpdG8gJHtudW1iZXJ9LiBUb3RhbDogJHtmb3JtYXRWYWx1ZShjcmVkaXROb3RlLnRvdGFsX2Ftb3VudCwgJ2N1cnJlbmN5Jyl9YDtcblxuICAgICAgICByZXR1cm4gYGh0dHBzOi8vd2EubWUvJHtjbGVhblBob25lfT90ZXh0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KG1lc3NhZ2UpfWA7XG4gICAgfSwgW2NyZWRpdE5vdGVdKTtcblxuICAgIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICAgIGlmIChlcnJvcikgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+RXJyb3IgYWwgY2FyZ2FyIGxhIG5vdGEgZGUgY3LDqWRpdG86IHtlcnJvciBhcyBzdHJpbmd9PC9kaXY+O1xuICAgIGlmICghY3JlZGl0Tm90ZSkgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPk5vIHNlIGVuY29udHLDsyBlbCBkb2N1bWVudG8uPC9kaXY+O1xuXG4gICAgLy8gLS0tIEzDk0dJQ0EgREUgRVNUQURPIC0tLVxuICAgIGNvbnN0IGdldFN0YXR1c1RleHQgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc3dpdGNoIChTdHJpbmcoc3RhdHVzKSkge1xuICAgICAgICAgICAgY2FzZSAnMSc6IHJldHVybiAnUGVuZGllbnRlJzsgLy8gTyAnRW1pdGlkYScgc2Vnw7puIHR1IGJhY2tlbmRcbiAgICAgICAgICAgIGNhc2UgJzInOiByZXR1cm4gJ0FwbGljYWRhJztcbiAgICAgICAgICAgIGNhc2UgJzAnOiByZXR1cm4gJ0FudWxhZGEnO1xuICAgICAgICAgICAgY2FzZSAnVk9JRCc6IHJldHVybiAnQW51bGFkYSc7XG4gICAgICAgICAgICBjYXNlICdJU1NVRUQnOiByZXR1cm4gJ0VtaXRpZGEgKEFSQ0EpJztcbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiAnQm9ycmFkb3InO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBnZXRTdGF0dXNDbGFzc05hbWUgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcbiAgICAgICAgc3dpdGNoIChTdHJpbmcoc3RhdHVzKSkge1xuICAgICAgICAgICAgY2FzZSAnMSc6IHJldHVybiAnYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDAnO1xuICAgICAgICAgICAgY2FzZSAnMic6IHJldHVybiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgICAgICAgIGNhc2UgJzAnOiByZXR1cm4gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJztcbiAgICAgICAgICAgIGNhc2UgJ1ZPSUQnOiByZXR1cm4gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJztcbiAgICAgICAgICAgIGNhc2UgJ0lTU1VFRCc6IHJldHVybiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgdG90YWxMYWJlbFN0eWxlID0gXCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIjtcbiAgICBjb25zdCB0b3RhbFZhbHVlU3R5bGUgPSBcInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRleHQtcmlnaHRcIjtcblxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbENyZWRpdE5vdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghY3JlZGl0Tm90ZSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBjb25maXJtTWVzc2FnZSA9IGDCv0VzdMOhIHNlZ3VybyBkZSBxdWUgZGVzZWEgQU5VTEFSIGxhIE5vdGEgZGUgQ3LDqWRpdG8gJHtjcmVkaXROb3RlLnNlcmllc30tJHtjcmVkaXROb3RlLnZvdWNoZXJfbnVtYmVyfT9cXG5cXG5Fc3RhIGFjY2nDs24gZXMgaXJyZXZlcnNpYmxlLmA7XG4gICAgICAgIGlmICghd2luZG93LmNvbmZpcm0oY29uZmlybU1lc3NhZ2UpKSByZXR1cm47XG5cbiAgICAgICAgc2V0SXNDYW5jZWxsaW5nKHRydWUpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgcGF0Y2gobm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmVuZHBvaW50LCBjcmVkaXROb3RlLmlkLCB7XG4gICAgICAgICAgICAgICAgc3RhdHVzOiAnVk9JRCcgLy8gTyAnMCcsIGFqdXN0YSBzZWfDum4gdHUgYmFja2VuZCBwYXJhIGFudWxhciBOQ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0b2FzdC5zdWNjZXNzKCdOb3RhIGRlIGNyw6lkaXRvIGFudWxhZGEgY29ycmVjdGFtZW50ZS4nKTtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihgRXJyb3IgYWwgYW51bGFyOiAke2Vyci5tZXNzYWdlIHx8ICdFcnJvciBkZXNjb25vY2lkbyd9YCk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc0NhbmNlbGxpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVByaW50ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIWNyZWRpdE5vdGUpIHJldHVybjtcblxuICAgICAgICBjb25zdCBzZXNzaW9uID0gYmVnaW5QZGZQcmV2aWV3KCk7XG4gICAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICAgICAgdG9hc3QuZXJyb3IoJ1Blcm1pdMOtIHZlbnRhbmFzIGVtZXJnZW50ZXMgcGFyYSB2ZXIgZWwgUERGLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNQcmludGluZyh0cnVlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGZpbmlzaFBkZlByZXZpZXcoc2Vzc2lvbiwgYC9jcmVkaXQtbm90ZXMvJHtjcmVkaXROb3RlLmlkfS9wZGZgKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmICghc2Vzc2lvbi53aW5kb3cuY2xvc2VkKSBzZXNzaW9uLndpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGdlbmVyYXIgZWwgUERGOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcignTm8gc2UgcHVkbyBnZW5lcmFyIGVsIGNvbXByb2JhbnRlIFBERi4nKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldElzUHJpbnRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUxpbmtDbGljayA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50LCB0eXBlOiAnZW1haWwnIHwgJ3doYXRzYXBwJykgPT4ge1xuICAgICAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gJ2VtYWlsJyA/IGNyZWRpdE5vdGU/LmNsaWVudD8uZW1haWwgOiBjcmVkaXROb3RlPy5jbGllbnQ/LnBob25lO1xuICAgICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oYEVsIGNsaWVudGUgbm8gdGllbmUgJHt0eXBlID09PSAnZW1haWwnID8gJ2VtYWlsJyA6ICd0ZWzDqWZvbm8nfSByZWdpc3RyYWRvLmApO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGlzQ2FuY2VsbGVkID0gU3RyaW5nKGNyZWRpdE5vdGUuc3RhdHVzKSA9PT0gJzAnIHx8IFN0cmluZyhjcmVkaXROb3RlLnN0YXR1cykgPT09ICdWT0lEJztcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHNtOnAtNiBzcGFjZS15LThcIj5cblxuICAgICAgICAgICAgey8qIC0tLSBFTkNBQkVaQURPIC0tLSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGItNCBtYi00IGJvcmRlci1iIHNtOmZsZXggc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoZ2V0TGlzdFJldHVyblBhdGgobm90YXNDcmVkaXRvTW9kdWxlQ29uZmlnLmJhc2VSb3V0ZSkpfSBjbGFzc05hbWU9XCJwLTIgdGV4dC1ncmF5LTUwMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Fycm93QmFjayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTkM6IHtjcmVkaXROb3RlLnNlcmllc30te2NyZWRpdE5vdGUudm91Y2hlcl9udW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbXQtMSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtICR7Z2V0U3RhdHVzQ2xhc3NOYW1lKGNyZWRpdE5vdGUuc3RhdHVzKX1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzVGV4dChjcmVkaXROb3RlLnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEJPVE9ORVJBIERFIEFDQ0lPTkVTICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzbTptdC0wIHNtOm1sLTQgZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAge2NyZWRpdE5vdGUuY2xpZW50ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17ZW1haWxMaW5rfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlTGlua0NsaWNrKGUsICdlbWFpbCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgc2hhZG93LXNtIGhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVudmlhciBwb3IgRW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRW52ZWxvcGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17d2hhdHNhcHBMaW5rfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlTGlua0NsaWNrKGUsICd3aGF0c2FwcCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTUwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFbnZpYXIgcG9yIFdoYXRzQXBwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNQcmludGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBzaGFkb3ctc20gaG92ZXI6YmctZ3JheS01MCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzUHJpbnRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb1ByaW50IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NhbmNlbGxlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2FuY2VsQ3JlZGl0Tm90ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDYW5jZWxsaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXJlZC02MDAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLW1kIHNoYWRvdy1zbSBob3ZlcjpiZy1yZWQtNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBkaXNhYmxlZDpvcGFjaXR5LTcwIGRpc2FibGVkOmN1cnNvci13YWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDYW5jZWxsaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3Bpbm5lciBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTIgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFudWxhbmRvLi4uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9CYW4gY2xhc3NOYW1lPVwidy01IGgtNSBtci0yIC1tbC0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFudWxhciBOQ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIC0tLSBERVRBTExFUyBERSBDQUJFQ0VSQSAtLS0gKi99XG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAteC00IGdhcC15LTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICB7Y3JlZGl0Tm90ZS5jYWVfbnVtYmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMSBiZy1ncmVlbi01MCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPkNBRSBBdXRvcml6YWRvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhsIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ncmVlbi05MDAgdHJhY2tpbmctd2lkZXJcIj57Y3JlZGl0Tm90ZS5jYWVfbnVtYmVyfTwvZGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMSBiZy1ncmVlbi01MCBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlZlbmNpbWllbnRvIENBRTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTkwMFwiPntmb3JtYXRWYWx1ZShjcmVkaXROb3RlLmNhZV9kdWVfZGF0ZSwgJ2RhdGUnKX08L2RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q2xpZW50ZTwvZHQ+XG4gICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9jbGllbnRlcy8ke2NyZWRpdE5vdGUuY2xpZW50Py5pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby02MDAgaG92ZXI6dGV4dC1pbmRpZ28tODAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjcmVkaXROb3RlLmNsaWVudD8ubmFtZSB8fCBjcmVkaXROb3RlLmNsaWVudF9uYW1lIHx8ICdOL0EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZlY2hhIEVtaXNpw7NuPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Zm9ybWF0VmFsdWUoY3JlZGl0Tm90ZS5pc3N1ZV9kYXRlLCAnZGF0ZScpfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUmVmZXJlbmNpYSBhIEZhY3R1cmEgKERpZmVyZW5jaWEgY2xhdmUgY29uIEZhY3R1cmFEZXRhaWwpICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkZhY3R1cmEgQXNvY2lhZGE8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NyZWRpdE5vdGUuc2FsZXNfaW52b2ljZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9mYWN0dXJhcy1kZS12ZW50YS8ke2NyZWRpdE5vdGUuc2FsZXNfaW52b2ljZS5pZH1gfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1pbmRpZ28tNjAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb2N1bWVudFRleHQgY2xhc3NOYW1lPVwibXItMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRMaW5rZWRTYWxlc0ludm9pY2VSZWYoY3JlZGl0Tm90ZS5zYWxlc19pbnZvaWNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57Y3JlZGl0Tm90ZS5zYWxlc19pbnZvaWNlX2lkID8gYElEOiAke2NyZWRpdE5vdGUuc2FsZXNfaW52b2ljZV9pZH1gIDogJ1NpbiBSZWZlcmVuY2lhJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Q29tcHJvYmFudGUgT3JpZy48L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntjcmVkaXROb3RlLmRvY3VtZW50X3ZvdWNoZXIgfHwgJy0nfTwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+VmVuZGVkb3I8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntjcmVkaXROb3RlLnNhbGVzcGVyc29uPy5uYW1lIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlRyYW5zcG9ydGU8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntjcmVkaXROb3RlLnRyYW5zcG9ydD8ubmFtZSB8fCAnLSd9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT5Nb25lZGE8L2R0PlxuICAgICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWJhc2UgdGV4dC1ncmF5LTkwMFwiPntjcmVkaXROb3RlLmN1cnJlbmN5Py5uYW1lIHx8ICctJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlRpcG8gZGUgQ2FtYmlvPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1iYXNlIHRleHQtZ3JheS05MDBcIj57Y3JlZGl0Tm90ZS5leGNoYW5nZV9yYXRlID8gTnVtYmVyKGNyZWRpdE5vdGUuZXhjaGFuZ2VfcmF0ZSkudG9GaXhlZCgyKSA6ICcxLjAwJ308L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtjcmVkaXROb3RlLmFmaXBfcG9zICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PlB1bnRvIGRlIFZlbnRhPC9kdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwXCI+e2NyZWRpdE5vdGUuYWZpcF9wb3N9PC9kZD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGw+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gVEFCTEEgSVRFTVMgLS0tICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPkl0ZW1zIGRlIGxhIE5vdGEgZGUgQ3LDqWRpdG88L2gzPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCAtbXgtNCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzbTpteC0wIHNtOnJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBwbC00IHByLTMgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnBsLTZcIj5BcnTDrWN1bG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNhbnQuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5QLiBVbml0LjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTMuNSB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGhpZGRlblwiPkRlc2MuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMy41IHRleHQtcmlnaHQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5TdWJ0b3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgY3JlZGl0Tm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0zLjUgdGV4dC1yaWdodCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPkltcHVlc3RvczwvdGg+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHBsLTMgcHItNCB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNtOnByLTZcIj5Ub3RhbCBMw61uZWE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjcmVkaXROb3RlLml0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VidG90YWwgPSBOdW1iZXIoaXRlbS5xdWFudGl0eSkgKiBOdW1iZXIoaXRlbS51bml0X3ByaWNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzY291bnQgPSBOdW1iZXIoaXRlbS5kaXNjb3VudF9hbW91bnQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVTdWJ0b3RhbCA9IHN1YnRvdGFsIC0gZGlzY291bnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1UYXggPSAhaXNDbGllbnRUYXhFeGVtcHQgJiYgY3JlZGl0Tm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IGdldEl0ZW1UYXhUb3RhbChpdGVtKSA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVUb3RhbCA9IGxpbmVTdWJ0b3RhbCArIGl0ZW1UYXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLmlkIHx8IGluZGV4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwbC00IHByLTMgdGV4dC1zbSBzbTpwbC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2R1Y3RfaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9hcnRpY3Vsb3MvJHtpdGVtLnByb2R1Y3RfaWR9YH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGhvdmVyOnRleHQtaW5kaWdvLTgwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+KHtpdGVtLnByb2R1Y3RfY29kZX0pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntpdGVtLnByb2R1Y3RfbmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj4oe2l0ZW0ucHJvZHVjdF9jb2RlfSk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktNCB0ZXh0LXNtIHRleHQtcmlnaHQgdGV4dC1ncmF5LTUwMFwiPntOdW1iZXIoaXRlbS5xdWFudGl0eSkudG9GaXhlZCgyKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUoaXRlbS51bml0X3ByaWNlLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDAgaGlkZGVuXCI+e2Zvcm1hdFZhbHVlKGRpc2NvdW50LCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTQgdGV4dC1zbSB0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDBcIj57Zm9ybWF0VmFsdWUobGluZVN1YnRvdGFsLCAnY3VycmVuY3knKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNDbGllbnRUYXhFeGVtcHQgJiYgY3JlZGl0Tm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS00IHRleHQtc20gdGV4dC1yaWdodCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFZhbHVlKGl0ZW1UYXgsICdjdXJyZW5jeScpfTwvdGQ+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHBsLTMgcHItNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBzbTpwci02XCI+e2Zvcm1hdFZhbHVlKGxpbmVUb3RhbCwgJ2N1cnJlbmN5Jyl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiAtLS0gU0VDQ0nDk04gREUgVE9UQUxFUyAtLS0gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTYgcHQtNiBib3JkZXItdFwiPlxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIEl6cXVpZXJkYTogTm90YXMgeSBSZWNoYXpvICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3JlZGl0Tm90ZS5yZWplY3Rpb25fcmVhc29uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MCBwLTMgcm91bmRlZCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgdGV4dC1zbSB0ZXh0LXJlZC04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Nb3Rpdm8gUmVjaGF6bzo8L3N0cm9uZz4ge2NyZWRpdE5vdGUucmVqZWN0aW9uX3JlYXNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+Tm90YXM8L2R0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJtdC0xIHRleHQtYmFzZSB0ZXh0LWdyYXktOTAwIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj57Y3JlZGl0Tm90ZS5ub3RlcyB8fCAnLSd9PC9kZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIENlbnRyYWw6IEltcHVlc3RvcyBHbG9iYWxlcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgeyFpc0NsaWVudFRheEV4ZW1wdCAmJiAhY3JlZGl0Tm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyAmJiBjcmVkaXROb3RlLnRheGVzICYmIGNyZWRpdE5vdGUudGF4ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5JbXB1ZXN0b3MgR2xvYmFsZXMgQXBsaWNhZG9zPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3JlZGl0Tm90ZS50YXhlcy5tYXAoKHRheCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3RheC50YXhfaWQgfHwgaW5kZXh9IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGUucmVwbGFjZSgndGV4dC1ncmF5LTYwMCcsICd0ZXh0LWdyYXktNzAwJyl9Pnt0YXgudGF4X25hbWV9ICh7dGF4LnJhdGV9JSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3RvdGFsVmFsdWVTdHlsZX0+e2Zvcm1hdFZhbHVlKHRheC5hbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb2x1bW5hIERlcmVjaGE6IFRvdGFsZXMgRmluYWxlcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTEgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj48c3BhbiBjbGFzc05hbWU9e3RvdGFsTGFiZWxTdHlsZX0+U3VidG90YWwgKEl0ZW1zKTo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnN1YnRvdGFsLCAnY3VycmVuY3knKX08L3NwYW4+PC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFNpIGh1YmllcmEgZGVzY3VlbnRvcyBnbG9iYWxlcyAqL31cbiAgICAgICAgICAgICAgICAgICAge2NhbGN1bGF0ZWRUb3RhbHMuZ2xvYmFsRGlzY291bnRBbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbExhYmVsU3R5bGV9PkRlc2MuIEdsb2JhbDo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pi0ge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMuZ2xvYmFsRGlzY291bnRBbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7IWlzQ2xpZW50VGF4RXhlbXB0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBtdC0yXCI+PHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbExhYmVsU3R5bGV9IGZvbnQtc2VtaWJvbGRgfT5CYXNlIEltcG9uaWJsZTo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbFZhbHVlU3R5bGUucmVwbGFjZSgndGV4dC1zbScsICd0ZXh0LWJhc2UnKX0gZm9udC1zZW1pYm9sZGB9Pntmb3JtYXRWYWx1ZShjYWxjdWxhdGVkVG90YWxzLnRheEJhc2UsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPjxzcGFuIGNsYXNzTmFtZT17dG90YWxMYWJlbFN0eWxlfT57Y3JlZGl0Tm90ZS5oYXNfaXRlbV9sZXZlbF90YXhlcyA/IFwiSW1wdWVzdG9zIChJdGVtcyk6XCIgOiBcIkltcHVlc3RvcyAoR2xvYmFsKTpcIn08L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXt0b3RhbFZhbHVlU3R5bGV9Pisge2Zvcm1hdFZhbHVlKGNhbGN1bGF0ZWRUb3RhbHMudG90YWxUYXhlcywgJ2N1cnJlbmN5Jyl9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTIgYm9yZGVyLXQgbXQtMlwiPjxzcGFuIGNsYXNzTmFtZT17YCR7dG90YWxMYWJlbFN0eWxlfSB0ZXh0LWxnIGZvbnQtc2VtaWJvbGRgfT5Ub3RhbCBGaW5hbDo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPXtgJHt0b3RhbFZhbHVlU3R5bGUucmVwbGFjZSgndGV4dC1zbScsICd0ZXh0LWxnJyl9IGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDBgfT57Zm9ybWF0VmFsdWUoY3JlZGl0Tm90ZS50b3RhbF9hbW91bnQsICdjdXJyZW5jeScpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufTsiXSwiZmlsZSI6Ii9hcHAvc3JjL2ZlYXR1cmVzL25vdGFzX2NyZWRpdG8vcGFnZXMvTm90YXNDcmVkaXRvRGV0YWlsUGFnZS50c3gifQ==