import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/mov_stock/pages/MovStockListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cc4fbb62"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/features/mov_stock/pages/MovStockListPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { GenericListPage } from "/src/components/common/GenericListPage.tsx";
import { stockMovementsModuleConfig } from "/src/features/mov_stock/movStock.config.tsx";
import { useCrud } from "/src/hooks/useCrud.ts";
import { getDefaultListDateRange } from "/src/utils/listDateRange.ts";
export const MovStockListPage = () => {
  _s();
  const {
    response,
    loading,
    isAppending,
    error,
    deleteItem,
    handleSort,
    sortBy,
    sortDirection,
    handlePageChange,
    handleLoadMore,
    handleSearch,
    searchParams
  } = useCrud(stockMovementsModuleConfig, getDefaultListDateRange());
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-red-500", children: error }, void 0, false, {
    fileName: "/app/src/features/mov_stock/pages/MovStockListPage.tsx",
    lineNumber: 31,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(
    GenericListPage,
    {
      config: stockMovementsModuleConfig,
      paginationResponse: response,
      loading,
      isAppending,
      onDelete: deleteItem,
      onSort: handleSort,
      sortBy,
      sortDirection,
      onPageChange: handlePageChange,
      onLoadMore: handleLoadMore,
      onSearch: handleSearch,
      searchTerm: searchParams.term ?? "",
      dateFilterStart: searchParams.startDate ?? "",
      dateFilterEnd: searchParams.endDate ?? "",
      enableDateRangeFilter: true
    },
    void 0,
    false,
    {
      fileName: "/app/src/features/mov_stock/pages/MovStockListPage.tsx",
      lineNumber: 34,
      columnNumber: 5
    },
    this
  );
};
_s(MovStockListPage, "OpZ0ArL+5wGVsfZK9Ifi0y1Fv3w=", false, function() {
  return [useCrud];
});
_c = MovStockListPage;
var _c;
$RefreshReg$(_c, "MovStockListPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/features/mov_stock/pages/MovStockListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/features/mov_stock/pages/MovStockListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV3NCOzs7Ozs7Ozs7Ozs7Ozs7OztBQVh0QixTQUFTQSx1QkFBdUI7QUFDaEMsU0FBU0Msa0NBQWlEO0FBQzFELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsK0JBQStCO0FBRWpDLGFBQU1DLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU07QUFBQSxJQUNGQztBQUFBQSxJQUFVQztBQUFBQSxJQUFTQztBQUFBQSxJQUFhQztBQUFBQSxJQUFPQztBQUFBQSxJQUFZQztBQUFBQSxJQUFZQztBQUFBQSxJQUMvREM7QUFBQUEsSUFBZUM7QUFBQUEsSUFBa0JDO0FBQUFBLElBQWdCQztBQUFBQSxJQUFjQztBQUFBQSxFQUNuRSxJQUFJZixRQUFrQkQsNEJBQTRCRSx3QkFBd0IsQ0FBQztBQUUzRSxNQUFJTSxNQUFPLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGdCQUFnQkEsbUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFdkQsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csUUFBUVI7QUFBQUEsTUFDUixvQkFBb0JLO0FBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBVUk7QUFBQUEsTUFDVixRQUFRQztBQUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0EsY0FBY0c7QUFBQUEsTUFDZCxZQUFZQztBQUFBQSxNQUNaLFVBQVVDO0FBQUFBLE1BQ1YsWUFBWUMsYUFBYUMsUUFBUTtBQUFBLE1BQ2pDLGlCQUFpQkQsYUFBYUUsYUFBYTtBQUFBLE1BQzNDLGVBQWVGLGFBQWFHLFdBQVc7QUFBQSxNQUN2Qyx1QkFBdUI7QUFBQTtBQUFBLElBZjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWVnQztBQUd4QztBQUFFZixHQTNCV0Qsa0JBQWdCO0FBQUEsVUFJckJGLE9BQU87QUFBQTtBQUFBbUIsS0FKRmpCO0FBQWdCLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiR2VuZXJpY0xpc3RQYWdlIiwic3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWciLCJ1c2VDcnVkIiwiZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UiLCJNb3ZTdG9ja0xpc3RQYWdlIiwiX3MiLCJyZXNwb25zZSIsImxvYWRpbmciLCJpc0FwcGVuZGluZyIsImVycm9yIiwiZGVsZXRlSXRlbSIsImhhbmRsZVNvcnQiLCJzb3J0QnkiLCJzb3J0RGlyZWN0aW9uIiwiaGFuZGxlUGFnZUNoYW5nZSIsImhhbmRsZUxvYWRNb3JlIiwiaGFuZGxlU2VhcmNoIiwic2VhcmNoUGFyYW1zIiwidGVybSIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNb3ZTdG9ja0xpc3RQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHZW5lcmljTGlzdFBhZ2UgfSBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL2NvbW1vbi9HZW5lcmljTGlzdFBhZ2UnO1xuaW1wb3J0IHsgc3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWcsIHR5cGUgTW92U3RvY2sgfSBmcm9tICcuLi9tb3ZTdG9jay5jb25maWcnO1xuaW1wb3J0IHsgdXNlQ3J1ZCB9IGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZUNydWQnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdExpc3REYXRlUmFuZ2UgfSBmcm9tICcuLi8uLi8uLi91dGlscy9saXN0RGF0ZVJhbmdlJztcblxuZXhwb3J0IGNvbnN0IE1vdlN0b2NrTGlzdFBhZ2UgPSAoKSA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgICByZXNwb25zZSwgbG9hZGluZywgaXNBcHBlbmRpbmcsIGVycm9yLCBkZWxldGVJdGVtLCBoYW5kbGVTb3J0LCBzb3J0QnksXG4gICAgICAgIHNvcnREaXJlY3Rpb24sIGhhbmRsZVBhZ2VDaGFuZ2UsIGhhbmRsZUxvYWRNb3JlLCBoYW5kbGVTZWFyY2gsIHNlYXJjaFBhcmFtcyxcbiAgICB9ID0gdXNlQ3J1ZDxNb3ZTdG9jaz4oc3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWcsIGdldERlZmF1bHRMaXN0RGF0ZVJhbmdlKCkpO1xuXG4gICAgaWYgKGVycm9yKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj57ZXJyb3J9PC9kaXY+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPEdlbmVyaWNMaXN0UGFnZTxNb3ZTdG9jaz5cbiAgICAgICAgICAgIGNvbmZpZz17c3RvY2tNb3ZlbWVudHNNb2R1bGVDb25maWd9XG4gICAgICAgICAgICBwYWdpbmF0aW9uUmVzcG9uc2U9e3Jlc3BvbnNlfVxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cbiAgICAgICAgICAgIGlzQXBwZW5kaW5nPXtpc0FwcGVuZGluZ31cbiAgICAgICAgICAgIG9uRGVsZXRlPXtkZWxldGVJdGVtfVxuICAgICAgICAgICAgb25Tb3J0PXtoYW5kbGVTb3J0fVxuICAgICAgICAgICAgc29ydEJ5PXtzb3J0Qnl9XG4gICAgICAgICAgICBzb3J0RGlyZWN0aW9uPXtzb3J0RGlyZWN0aW9ufVxuICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdlQ2hhbmdlfVxuICAgICAgICAgICAgb25Mb2FkTW9yZT17aGFuZGxlTG9hZE1vcmV9XG4gICAgICAgICAgICBvblNlYXJjaD17aGFuZGxlU2VhcmNofVxuICAgICAgICAgICAgc2VhcmNoVGVybT17c2VhcmNoUGFyYW1zLnRlcm0gPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyU3RhcnQ9e3NlYXJjaFBhcmFtcy5zdGFydERhdGUgPz8gJyd9XG4gICAgICAgICAgICBkYXRlRmlsdGVyRW5kPXtzZWFyY2hQYXJhbXMuZW5kRGF0ZSA/PyAnJ31cbiAgICAgICAgICAgIGVuYWJsZURhdGVSYW5nZUZpbHRlcj17dHJ1ZX1cbiAgICAgICAgLz5cbiAgICApO1xufTtcbiJdLCJmaWxlIjoiL2FwcC9zcmMvZmVhdHVyZXMvbW92X3N0b2NrL3BhZ2VzL01vdlN0b2NrTGlzdFBhZ2UudHN4In0=